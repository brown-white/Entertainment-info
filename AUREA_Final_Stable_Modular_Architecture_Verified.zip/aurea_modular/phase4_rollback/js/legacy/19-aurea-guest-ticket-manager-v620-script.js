
(()=>{
'use strict';
if(window.__AUREA_GUEST_TICKET_MANAGER_V620)return;
window.__AUREA_GUEST_TICKET_MANAGER_V620=true;

const pending620=new Map();
const esc620=v=>esc(String(v??''));
const orderRoom620=o=>typeof window.AUREA_GUEST_LIFECYCLE?.visibleRoom==='function'?window.AUREA_GUEST_LIFECYCLE.visibleRoom(o.room):String(o.room||'');
const ticket620=id=>(S.tickets||[]).find(x=>String(x.id)===String(id));
const orderStatus620=o=>String(o.status||'reserved').toLowerCase()==='paid'?'paid':'reserved';
function team620(){
  return (S.users||[])
    .filter(u=>u&&u.active!==false&&String(u.role||'').toLowerCase()!=='manager')
    .map(u=>({id:u.id,name:String(u.display_name||u.name||u.username||'').trim()}))
    .filter(x=>x.name)
    .sort((a,b)=>a.name.localeCompare(b.name));
}
function currentOrders620(){
  /* managerView's V6.19 operational wrapper already supplies only current-stay orders.
     Keep this function simple so it follows that single source of truth. */
  return (S.orders||[]).slice().sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')));
}
function counts620(list){
  return{all:list.length,reserved:list.filter(o=>orderStatus620(o)==='reserved').length,paid:list.filter(o=>orderStatus620(o)==='paid').length};
}
function guestTicketsManagerInnerV620(){
  const all=currentOrders620(),mode=S.gt620Filter||'all',q=String(S.gt620Search||'').trim().toLowerCase(),c=counts620(all);
  const list=all.filter(o=>mode==='all'||orderStatus620(o)===mode);
  return `<div class="gt620-head"><div class="k">Guest ticket orders</div><h3>Tickets</h3><p>Manage the guest's ticket order here. Ticket event setup remains in Program → Tickets.</p></div>
    <div class="gt620-stats"><div class="gt620-stat"><b>${c.all}</b><span>Orders</span></div><div class="gt620-stat"><b>${c.reserved}</b><span>Pending payment</span></div><div class="gt620-stat"><b>${c.paid}</b><span>Paid / handed over</span></div></div>
    <div class="gt620-tools"><input id="gt620-search" enterkeyhint="done" autocomplete="off" autocorrect="off" value="${esc620(S.gt620Search||'')}" placeholder="Search guest, room, ticket or entertainer"><button class="btn ghost sm" id="gt620-events">Manage ticket events</button></div>
    <div class="gt620-filter"><button class="btn ${mode==='all'?'':'ghost'} sm" data-gt620-filter="all">All</button><button class="btn ${mode==='reserved'?'':'ghost'} sm" data-gt620-filter="reserved">Pending</button><button class="btn ${mode==='paid'?'':'ghost'} sm" data-gt620-filter="paid">Paid</button></div>
    <div class="gt620-list">${list.length?list.map(o=>{
      const tk=ticket620(o.ticket_id),status=orderStatus620(o);
      const searchText=[o.guest_name,orderRoom620(o),o.collect_from,tk&&tk.name].map(v=>String(v||'').toLowerCase()).join(' ');
      return `<article class="gt620-order" data-gt620-searchtext="${esc620(searchText)}"><div class="gt620-main"><b>${esc620(o.guest_name||'Guest')} · Room ${esc620(orderRoom620(o)||'—')} · ×${Math.max(1,+o.qty||1)}</b><div class="event">${esc620(tk?tk.name:'Ticket event')}</div><div class="meta">${tk?`${esc620((t('days')||[])[tk.day]||'')} · ${esc620(tk.time||'')} · ${esc620(tk.location||'')}<br>`:''}${o.created_at?`Ordered ${esc620(whenLabel(o.created_at))}`:''}</div>${o.collect_from?`<span class="collect">${esc620(t('handTo'))}: ${esc620(o.collect_from)}</span>`:''}</div><div class="gt620-side"><span class="gt620-status ${status}">${status==='paid'?'Paid · ticket handed over':'Reserved · payment pending'}</span><div class="gt620-actions"><button class="btn ghost sm" data-gt620-edit="${esc620(o.id)}">${ic('pen',14)} Edit</button><button class="btn warn sm" data-gt620-del="${esc620(o.id)}">${ic('trash',14)}</button></div></div></article>`;
    }).join(''):`<div class="gt620-empty">No ticket orders match this view.</div>`}<div class="gt620-empty" id="gt620-search-empty" style="display:none">No ticket orders match your search.</div></div>`;
}
window.guestTicketsManagerInnerV620=guestTicketsManagerInnerV620;

async function saveOrder620(id,patch){
  const key=String(id)+'|'+JSON.stringify(patch);
  if(pending620.has(key))return pending620.get(key);
  const job=(async()=>{
    if(REMOTE)await sb('ticket_orders?id=eq.'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(patch)});
    const o=(S.orders||[]).find(x=>String(x.id)===String(id));if(o)Object.assign(o,patch);
    return o;
  })().finally(()=>pending620.delete(key));
  pending620.set(key,job);return job;
}
function openOrderEdit620(id){
  const o=(S.orders||[]).find(x=>String(x.id)===String(id));if(!o)return;
  const teams=team620(),tickets=S.tickets||[];
  const wrap=baseModal(`<h3>Edit ticket order</h3><div class="gt620-identity"><b>${esc620(o.guest_name||'Guest')} · Room ${esc620(orderRoom620(o)||'—')}</b><span>This edits the guest's existing ticket order. It does not create a new order.</span></div>
    <label>Ticket event</label><select id="gt620-ticket">${tickets.map(tk=>`<option value="${esc620(tk.id)}" ${String(tk.id)===String(o.ticket_id)?'selected':''}>${esc620(tk.name)}</option>`).join('')}</select>
    <div class="gt620-modal-grid"><div><label>Quantity</label><input type="number" min="1" id="gt620-qty" value="${Math.max(1,+o.qty||1)}"></div><div><label>Status</label><select id="gt620-status"><option value="reserved" ${orderStatus620(o)==='reserved'?'selected':''}>Reserved / payment pending</option><option value="paid" ${orderStatus620(o)==='paid'?'selected':''}>Paid / physical ticket handed over</option></select></div></div>
    <label>Pay / collect ticket from</label><select id="gt620-member"><option value="">Entertainment Team</option>${teams.map(m=>`<option value="${esc620(m.name)}" ${String(m.name)===String(o.collect_from||'')?'selected':''}>${esc620(m.name)}</option>`).join('')}</select>
    <button class="btn" id="gt620-save">Save changes</button><button class="btn ghost" id="gt620-close">Close</button>`);
  wrap.querySelector('#gt620-close').onclick=()=>wrap.remove();
  wrap.querySelector('#gt620-save').onclick=async()=>{
    const btn=wrap.querySelector('#gt620-save');if(btn.disabled)return;
    const qty=Math.max(1,parseInt(wrap.querySelector('#gt620-qty').value,10)||1);
    const patch={ticket_id:wrap.querySelector('#gt620-ticket').value,qty,status:wrap.querySelector('#gt620-status').value,collect_from:wrap.querySelector('#gt620-member').value};
    btn.disabled=true;btn.textContent='Saving…';
    try{await saveOrder620(o.id,patch);wrap.remove();toastOk(t('saved'));render();}catch(e){console.error('ticket order edit',e);btn.disabled=false;btn.textContent='Save changes';toastErr(t('errSave'));}
  };
}
async function deleteOrder620(id){
  const o=(S.orders||[]).find(x=>String(x.id)===String(id));if(!o)return;
  const tk=ticket620(o.ticket_id);
  if(!await confirmAction({question:'Delete this ticket order?',detail:`${o.guest_name||'Guest'} · Room ${orderRoom620(o)||'—'}${tk?' · '+tk.name:''}. This cannot be undone.`,confirmLabel:'Delete order',danger:true}))return;
  await DB.deleteOrder(id);toastOk(t('deleted'));render();
}
const oldWire620=wireCommon;
wireCommon=function(){
  oldWire620();
  if(!(S.session&&S.session.role==='manager'&&S.tab==='guests'&&S.sub.guests==='tickets'))return;
  const search=document.querySelector('#gt620-search');if(search && !search.dataset.searchFixedV6242){
    search.dataset.searchFixedV6242='1';
    const filterTickets=()=>{
      S.gt620Search=search.value;
      const q=search.value.trim().toLowerCase();
      const rows=[...document.querySelectorAll('[data-gt620-searchtext]')];
      let shown=0;
      rows.forEach(row=>{
        const ok=!q||String(row.dataset.gt620Searchtext||'').includes(q);
        row.style.display=ok?'':'none';
        if(ok)shown++;
      });
      const empty=document.querySelector('#gt620-search-empty');
      if(empty)empty.style.display=(rows.length&&shown===0)?'':'none';
    };
    search.oninput=filterTickets;
    search.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();filterTickets();search.blur();}};
    search.onsearch=()=>{filterTickets();search.blur();};
    filterTickets();
  }
  document.querySelectorAll('[data-gt620-filter]').forEach(b=>b.onclick=()=>{S.gt620Filter=b.dataset.gt620Filter;render();});
  document.querySelectorAll('[data-gt620-edit]').forEach(b=>b.onclick=()=>openOrderEdit620(b.dataset.gt620Edit));
  document.querySelectorAll('[data-gt620-del]').forEach(b=>b.onclick=()=>deleteOrder620(b.dataset.gt620Del));
  const events=document.querySelector('#gt620-events');if(events)events.onclick=()=>{S.tab='program';S.sub.program='tickets';render();};
};
window.openGuestTicketOrderEditV620=openOrderEdit620;
})();
