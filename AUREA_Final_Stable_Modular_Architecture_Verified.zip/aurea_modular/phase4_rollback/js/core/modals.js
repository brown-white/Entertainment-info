/* ---------------- modals ---------------- */
function baseModal(html){
  const wrap=document.createElement("div"); wrap.className="modal-bg";
  wrap.innerHTML=`<div class="modal"><div class="grab"></div>${html}</div>`;
  document.body.appendChild(wrap);
  wrap.onclick=e=>{ if(e.target===wrap) wrap.remove(); };
  return wrap;
}
function openBookModal(a){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const wrap=baseModal(`
    <h3>${esc(a.name)}</h3>
    <p class="mini">${mi("clock")}${esc(a.time)} · ${mi("pin")}${esc(a.location)}${unlimited?"":" · "+(full?t("full"):left+" "+t("seatsLeft"))}</p>
    <p style="margin-top:8px">${esc(a.desc)}</p>
    <label>${t("persons")}</label>
    <input id="m-ad" type="number" min="1" max="20" value="1" inputmode="numeric">
    <button class="btn" id="m-go">${full?t("waitlist"):t("confirm")}</button>
    <button class="btn ghost" id="m-x">${t("close")}</button>`);
  wrap.querySelector("#m-x").onclick=()=>wrap.remove();
  wrap.querySelector("#m-go").onclick=async ()=>{
    const g=S.session;
    await DB.addBooking({activity_id:a.id,room:g.room,guest_name:g.name,phone:g.phone||"",nationality:g.nationality||"",
      adults:Math.max(1,+wrap.querySelector("#m-ad").value||1),children:0,
      status: full?"waitlist":"booked"});
    wrap.remove(); toast(full?t("waitOk"):t("bookingOk")); render();
  };
}
function openTicketBuyModal(tk){
  const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
  const max=left!==null?Math.max(1,Math.min(10,left)):10;
  const team=teamMemberList();
  let chosen="";
  const wrap=baseModal(`
    <h3>${esc(tk.name)}</h3>
    <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}</p>
    <p style="margin-top:8px">${esc(tk.desc)}</p>
    <p class="mini" style="margin-top:8px">${t("payNote")}</p>
    <div class="row2" style="align-items:end">
      <div><label>${t("qty")}</label><input id="tq" type="number" min="1" max="${max}" value="1"></div>
      <div style="text-align:end;font-family:var(--font-display);font-size:24px;color:var(--cacao);padding-bottom:10px">${esc(tk.price||"")}</div>
    </div>
    ${team.length?`<label>${t("collectFrom")}</label>
    <div class="memberrow">
      ${team.map(m=>`<button type="button" class="memb" data-memb="${esc(m.name)}">
        <span class="mb-av">${m.photo?`<img src="${esc(m.photo)}" alt="">`:esc(m.name.trim().charAt(0).toUpperCase())}</span>
        <span class="mb-nm">${esc(m.name)}</span>
      </button>`).join("")}
    </div>`:""}
    <button class="btn" id="t-go">${t("buyTicket")}</button>
    <div class="err" id="t-err"></div>
    <button class="btn ghost" id="t-x">${t("close")}</button>`);
  wrap.querySelector("#t-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-memb]").forEach(b=>b.onclick=()=>{
    chosen=b.dataset.memb;
    wrap.querySelectorAll(".memb").forEach(x=>x.classList.toggle("on",x===b));
    wrap.querySelector("#t-err").textContent="";
  });
  wrap.querySelector("#t-go").onclick=async ()=>{
    if(team.length && !chosen){ wrap.querySelector("#t-err").textContent=t("chooseMember"); return; }
    const g=S.session;
    const qty=Math.max(1,Math.min(max,+wrap.querySelector("#tq").value||1));
    await DB.addOrder({ticket_id:tk.id,room:g.room,guest_name:g.name,nationality:g.nationality||"",
      qty,status:"reserved",collect_from:chosen});
    wrap.remove(); toast(t("ticketOk")); render();
  };
}
function openRequestModal(type){
  const isSong=type==="song";
  const wrap=baseModal(`
    <h3>${ic(isSong?"music":"gift",20)} ${isSong?t("songRequest"):t("birthdayRequest")}</h3>
    <label>${isSong?t("songName"):t("forWhom")}</label><input id="r-detail">
    ${isSong?"":`<label>${t("birthdayDate")}</label><input id="r-date" type="date">`}
    <label>${t("reqNote")}</label><textarea id="r-note" rows="2"></textarea>
    <button class="btn" id="r-go">${t("send")}</button>
    <button class="btn ghost" id="r-x">${t("close")}</button>`);
  wrap.querySelector("#r-x").onclick=()=>wrap.remove();
  wrap.querySelector("#r-go").onclick=async ()=>{
    const detail=wrap.querySelector("#r-detail").value.trim();
    if(!detail) return;
    const g=S.session;
    await DB.addRequest({room:g.room,guest_name:g.name,type,detail,
      date:isSong?"":(wrap.querySelector("#r-date").value||""),
      note:wrap.querySelector("#r-note").value.trim(),status:"new"});
    wrap.remove(); toast(t("saved")); render();
  };
}
function openTaskAddModal(){
  const staffOpts=S.users.filter(u=>u.role==="staff").map(u=>`<option value="${esc(u.username)}">${esc(u.display_name||u.username)}</option>`).join("");
  const typeOpts=TASK_TYPES.map(ty=>`<option value="${ty}">${taskTypeLabel(ty)}</option>`).join("");
  const wrap=baseModal(`
    <h3>${t("addTask")}</h3>
    <label>${t("taskType")}</label><select id="tk-type">${typeOpts}</select>
    <label>${t("actName")}</label><input id="tk-title">
    <label>${t("location")}</label><input id="tk-loc">
    <label>${t("desc")}</label><textarea id="tk-desc" rows="2"></textarea>
    <label>${t("taskFor")}</label>
    <select id="tk-for"><option value="">${t("allTeam")}</option>${staffOpts}</select>
    <label>${t("taskPriority")}</label>
    <select id="tk-pri">${PRIORITIES.map(([k,lb])=>`<option value="${k}" ${k==="normal"?"selected":""}>${t(lb)}</option>`).join("")}</select>
    <label>${t("dueLbl")}</label><input id="tk-due" type="datetime-local">
    <button class="btn" id="tk-go">${t("save")}</button>
    <button class="btn ghost" id="tk-x">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tk-go").onclick=async ()=>{
    const title=wrap.querySelector("#tk-title").value.trim();
    if(!title) return;
    await DB.addTask({type:wrap.querySelector("#tk-type").value,title,
      location:wrap.querySelector("#tk-loc").value.trim(),
      desc:wrap.querySelector("#tk-desc").value.trim(),
      assigned_to:wrap.querySelector("#tk-for").value,
      due:wrap.querySelector("#tk-due").value||"",
      priority:wrap.querySelector("#tk-pri").value,
      created_by:S.session.name||S.session.username||"",
      status:"new",was_still:false,
      history:[{at:new Date().toISOString(), by:S.session.name||S.session.username||"", to:"new"}],
      comments:[]});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* The full feedback sheet: who the guest is and a 1-5 score per department.
   Nothing is compulsory except the room number, so a guest who only wants to
   rate the food can still be recorded. */
function openFeedbackModal(id){
  const ex = id!=null ? (S.feedback||[]).find(f=>String(f.id)===String(id)) : null;
  const vals = ex ? {...fbDepts(ex)} : {};
  const rooms=knownRooms();
  const wrap=baseModal(`
    <h3>${ic("star",18)} ${ex?t("fbEdit"):t("fbNew")}</h3>
    <label>${t("room")}</label>
    <input id="fb-room" inputmode="numeric" list="fbroomlist" autocomplete="off" value="${esc(ex&&ex.room||"")}">
    <datalist id="fbroomlist">${rooms.map(r=>`<option value="${esc(r)}">`).join("")}</datalist>
    ${rooms.length?`<div class="fb-rooms" id="fb-roomchips">${rooms.slice(0,40).map(r=>
      `<button class="fb-rchip" data-fbroom="${esc(r)}">${esc(r)}</button>`).join("")}</div>`:""}
    <p class="mini" id="fb-found" style="margin:6px 0 0">${t("fbRoomHint")}</p>
    <label style="margin-top:12px">${t("fbGuestName")}</label><input id="fb-name" value="${esc(ex&&ex.guest_name||"")}">
    <label>${t("nationality")}</label>
    ${nationField("fb-natsel","fb-nattxt", ex&&ex.nationality||"")}
    <p class="mini" style="margin:4px 0 0">${t("natOtherHint")}</p>
    <label style="margin-top:12px">${t("fbByDept")}</label>
    <p class="mini" style="margin:-4px 0 6px">${t("fbFormHint")}</p>
    <div class="card" id="fb-depts" style="padding:4px 14px"></div>
    <label style="margin-top:12px">${t("comment")}</label><textarea id="fb-com" rows="2">${esc(ex?fbComment(ex):"")}</textarea>
    <button class="btn" id="fb-go">${t("save")}</button>
    <button class="btn ghost" id="fb-x">${t("close")}</button>`);
  const box=wrap.querySelector("#fb-depts");
  const paint=()=>{
    box.innerHTML=fbDeptKeys().map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>
      <span class="fb-stars">${[1,2,3,4,5].map(i=>
        `<button class="fb-st ${i<=(+vals[k]||0)?"on":""}" data-fbset="${k}|${i}" aria-label="${i}">${i<=(+vals[k]||0)?"\u2605":"\u2606"}</button>`).join("")}</span>
      <button class="fb-clear" data-fbclr="${k}" aria-label="${t("fbNotRated")}" ${vals[k]?"":'style="visibility:hidden"'}>\u00d7</button>
    </div>`).join("");
    box.querySelectorAll("[data-fbset]").forEach(b=>b.onclick=()=>{
      const [k,v]=b.dataset.fbset.split("|"); vals[k]=+v; paint();
    });
    box.querySelectorAll("[data-fbclr]").forEach(b=>b.onclick=()=>{ delete vals[b.dataset.fbclr]; paint(); });
  };
  paint();
  wireNatPicker(wrap,"fb-natsel","fb-nattxt");
  /* Look the room up as she types: a registered guest fills in their own name
     and nationality, but anything she typed herself is left alone. */
  const roomIn=wrap.querySelector("#fb-room");
  const nameIn=wrap.querySelector("#fb-name");
  const natSel=wrap.querySelector("#fb-natsel");
  const natTxt=wrap.querySelector("#fb-nattxt");
  const found=wrap.querySelector("#fb-found");
  let nameTouched=!!(ex&&ex.guest_name), natTouched=!!(ex&&ex.nationality);
  if(nameIn) nameIn.oninput=()=>{ nameTouched=true; };
  if(natSel) natSel.addEventListener("change",()=>{ natTouched=true; });
  if(natTxt) natTxt.oninput=()=>{ natTouched=true; };
  const setNat=v=>{
    if(!natSel) return;
    const known=NATIONS.includes(v);
    natSel.value = v ? (known?v:"Other") : "";
    if(natTxt){ natTxt.value = (v && !known) ? v : ""; natTxt.style.display = natSel.value==="Other" ? "" : "none"; }
  };
  const lookup=()=>{
    const g=guestForRoom(roomIn?roomIn.value:"");
    if(!found) return;
    if(!roomIn || !roomIn.value.trim()){ found.textContent=t("fbRoomHint"); return; }
    if(!g){ found.textContent=t("noGuestAccount"); return; }
    found.textContent=t("fbFoundGuest")+": "+(g.name||g.room)+(g.nationality?" \u00b7 "+g.nationality:"");
    if(!nameTouched && nameIn) nameIn.value=g.name||"";
    if(!natTouched) setNat(g.nationality||"");
  };
  if(roomIn){ roomIn.oninput=lookup; roomIn.onchange=lookup; }
  wrap.querySelectorAll("[data-fbroom]").forEach(b=>b.onclick=()=>{
    if(roomIn){ roomIn.value=b.dataset.fbroom; lookup(); }
  });
  lookup();
  wrap.querySelector("#fb-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fb-go").onclick=async ()=>{
    const room=wrap.querySelector("#fb-room").value.trim();
    if(!room){ toastErr(t("fbNeedRoom")); return; }
    const dep={}; fbDeptKeys().forEach(k=>{ if(+vals[k]>0) dep[k]=+vals[k]; });
    const scores=Object.values(dep);
    const rate = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : (ex?+ex.rate||5:5);
    const payload={
      room, guest_name:wrap.querySelector("#fb-name").value.trim(),
      nationality:readNatField(wrap,"fb-natsel","fb-nattxt"),
      rate, depts:JSON.stringify(dep),
      comment:wrap.querySelector("#fb-com").value.trim()
    };
    try{
      if(ex) await DB.updateFeedback(ex.id,payload);
      else await DB.addFeedback({...payload, by_user:(S.session&&S.session.username)||""});
      wrap.remove();
      if(S.fbOldDb){ S.fbOldDb=false; openFbSqlNote(); } else toastOk(t("saved"));
      render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* Shown once if her database is still missing the two new columns. */
function openFbSqlNote(){
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbSqlNote")}</h3>
    <p class="mini">${t("fbOldDb")}</p>
    <div class="fb-sql">${esc(FB_SQL)}</div>
    <button class="btn" id="fq-x">${t("close")}</button>`);
  wrap.querySelector("#fq-x").onclick=()=>wrap.remove();
}
/* One feedback, opened up: every department it scored, then edit or delete. */
function openFeedbackDetail(id){
  const f=(S.feedback||[]).find(x=>String(x.id)===String(id));
  if(!f) return;
  const d=fbDepts(f);
  const rated=fbDeptKeys().filter(k=>+d[k]>0);
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("fbDetails")}</h3>
    <p class="mini">${t("room")} ${esc(f.room)}${f.guest_name?" \u00b7 "+esc(f.guest_name):""}${f.nationality?" \u00b7 "+esc(f.nationality):""}</p>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${fbOverall(f)?fbOverall(f).toFixed(1)+" \u2605":"\u2014"}</b><span>${t("fbOverall")}</span></div>
      <div class="stat"><b>${rated.length}</b><span>${t("fbDepartments")}</span></div>
    </div>
    ${rated.length?`<div class="card" style="padding:4px 14px">${rated.map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>${fbStars(d[k])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    ${fbComment(f)?`<p style="margin-top:10px">${esc(fbComment(f))}</p>`:""}
    <p class="mini">${mi("user")}${t("fbCollectedBy")}: ${esc(teamName(f.by_user))} \u00b7 ${fmtTime(f.created_at)}</p>
    ${fbCanEdit(f)?`<button class="btn" id="fd-edit">${ic("pen",16)} ${t("fbEdit")}</button>
    <button class="btn ghost warn" id="fd-del">${ic("trash",16)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="fd-x">${t("close")}</button>`);
  wrap.querySelector("#fd-x").onclick=()=>wrap.remove();
  const ed=wrap.querySelector("#fd-edit");
  if(ed) ed.onclick=()=>{ wrap.remove(); openFeedbackModal(f.id); };
  const del=wrap.querySelector("#fd-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),note:t("cannotUndo"),danger:true})) return;
    try{ await DB.deleteFeedback(f.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
/* One department, opened up: every rating behind the average. */
function openDeptDetail(key){
  const all=S.feedback||[];
  const list=all.filter(f=>+fbDepts(f)[key]>0)
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const st=fbDeptStats(all).find(x=>x.k===key)||{avg:0,n:0};
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${esc(fbDeptLabel(key))}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${st.avg?st.avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${st.n}</b><span>${t("fbResponses")}</span></div>
    </div>
    ${list.length?`<div class="card">${list.map(f=>`<div class="fb-line" data-fbjump="${esc(String(f.id))}">
      <span style="min-width:0"><b>${t("room")} ${esc(f.room)}</b>${f.guest_name?" \u00b7 "+esc(f.guest_name):""}
        <br><span class="mini">${fmtTime(f.created_at)}${fbComment(f)?" \u00b7 "+esc(fbComment(f)):""}</span></span>
      ${fbStars(fbDepts(f)[key])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    <button class="btn ghost" id="dd-x">${t("close")}</button>`);
  wrap.querySelector("#dd-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-fbjump]").forEach(b=>b.onclick=()=>{
    const fid=b.dataset.fbjump; wrap.remove(); openFeedbackDetail(fid);
  });
}
/* Excel or PDF, straight from the feedback page: the sheet plus a department summary. */
/* The manager decides what guests get asked about. Keys are never reused or
   rewritten, so renaming a department keeps every rating it already has. */
function openDeptEditor(){
  let rows=fbDeptRows();
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbDeptsEdit")}</h3>
    <p class="mini">${t("fbDeptsHint")}</p>
    <div id="de-box"></div>
    <button class="btn ghost" id="de-add">\uFF0B ${t("fbAddDept")}</button>
    <button class="btn" id="de-go">${t("save")}</button>
    <button class="btn ghost" id="de-reset">${t("fbResetDepts")}</button>
    <button class="btn ghost" id="de-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#de-box");
  const label=r=>r.name || (t("d_"+r.key)==="d_"+r.key ? r.key : t("d_"+r.key));
  const paint=()=>{
    box.innerHTML=rows.map((r,i)=>`<div class="ar-it">
      <span class="ar-nm">${esc(label(r))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-deup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-dedown="${i}" ${i===rows.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b" data-dename="${i}" aria-label="${t("rename")}">${ic("pen",14)}</button>
        <button class="bd-b warn" data-dedel="${i}" aria-label="${t("delete")}">${ic("trash",14)}</button>
      </span></div>`).join("");
    box.querySelectorAll("[data-deup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.deup; [rows[i-1],rows[i]]=[rows[i],rows[i-1]]; paint(); });
    box.querySelectorAll("[data-dedown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dedown; [rows[i+1],rows[i]]=[rows[i],rows[i+1]]; paint(); });
    box.querySelectorAll("[data-dename]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dename;
      openTextPrompt(t("fbDeptName"), label(rows[i]), v=>{ if(v){ rows[i]={...rows[i], name:v}; paint(); } });
    });
    box.querySelectorAll("[data-dedel]").forEach(b=>b.onclick=async ()=>{
      const i=+b.dataset.dedel;
      if(rows.length<=1){ toastErr(t("fbLastDept")); return; }
      if(!await confirmAction({question:label(rows[i]),note:t("fbDeptGone"),danger:true})) return;
      rows.splice(i,1); paint();
    });
  };
  paint();
  wrap.querySelector("#de-add").onclick=()=>openTextPrompt(t("fbDeptName"),"",v=>{
    if(!v) return;
    rows.push({key:fbNewDeptKeyFrom(rows,v), name:v}); paint();
  });
  wrap.querySelector("#de-x").onclick=()=>wrap.remove();
  const save=async list=>{
    try{
      await DB.saveSettings({...S.settings, fbDepts:list});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#de-reset").onclick=()=>save(FB_DEPT_KEYS.map(k=>({key:k,name:""})));
  wrap.querySelector("#de-go").onclick=()=>save(rows);
}
/* A key that is unique inside the list being edited, not just the saved one. */
function fbNewDeptKeyFrom(rows,name){
  const slug=String(name||"").toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,20);
  const base="x_"+(slug||"dept");
  const taken=rows.map(r=>String(r.key)).concat(FB_DEPT_KEYS);
  let k=base, i=2;
  while(taken.includes(k)) k=base+"_"+(i++);
  return k;
}
/* A one-field prompt — used for renaming and adding departments. */
function openTextPrompt(title, value, done){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${esc(title)}</h3>
    <input id="tp-v" value="${esc(value||"")}" autocapitalize="words">
    <button class="btn" id="tp-go">${t("save")}</button>
    <button class="btn ghost" id="tp-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#tp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tp-go").onclick=()=>{
    const v=wrap.querySelector("#tp-v").value.trim();
    wrap.remove(); done(v);
  };
}
