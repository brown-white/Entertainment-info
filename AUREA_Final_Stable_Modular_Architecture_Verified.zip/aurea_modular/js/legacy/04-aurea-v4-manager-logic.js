
(function(){
  function v4Dj(){ return (S.users||[]).find(u=>u.role==="staff" && +u.number===DJ_NUMBER && u.active!==false && !hasLeft(u)); }
  function v4Special(a){ return a && normCat(a)!=="mAdult"; }
  function v4Owner(a,day){
    if(v4Special(a)){
      const dj=v4Dj();
      if(!dj) return {name:"DJ not configured",raw:"",bad:true};
      const ok=typeof availableOn==="function" ? availableOn(dj,day,assignDateStr(day)) : true;
      return {name:(dj.display_name||dj.username)+" · DJ",raw:dj.username,bad:!ok};
    }
    const raw=String(a&&a.entertainer||"").trim();
    return {name:raw?entertainerName(raw):"",raw,bad:false};
  }
  async function v4RepairDj(){
    if(!S.session || S.session.role!=="manager") return;
    const dj=v4Dj(); if(!dj) return;
    const bad=(S.activities||[]).filter(a=>v4Special(a) && String(a.entertainer||"").trim().toLowerCase()!==String(dj.username||"").toLowerCase());
    const sig=bad.map(a=>String(a.id)).sort().join("|")+"::"+dj.username;
    if(!bad.length || window.__aureaV4DjRepair===sig) return;
    window.__aureaV4DjRepair=sig;
    for(const a of bad){
      a.entertainer=dj.username;
      try{ await DB.saveActivity({...a,entertainer:dj.username}); }catch(e){ console.warn("DJ assignment repair",e&&e.message); }
    }
  }
  window.__aureaRepairDjAssignments=v4RepairDj;

  function v4EventRows(day){
    return (S.activities||[]).filter(a=>a&&a.day===day && ["mEvents","eParty"].includes(normCat(a)))
      .slice().sort((a,b)=>(timeToMin(a.time)||0)-(timeToMin(b.time)||0));
  }
  function v4DayInfoHtml(day){
    const dp=dayPlanFor(day), evs=v4EventRows(day);
    const events=evs.length?evs.map(a=>`<div class="dayinfo-event-v4"><b>${esc(a.name)}</b><small>${esc(String(a.time||""))}${a.location?" · "+esc(a.location):""}</small></div>`).join(""):`<b>—</b>`;
    return `<div class="card dayinfo-v4"><div class="dayinfo-grid-v4">
      <div class="dayinfo-item-v4"><span>${t("restaurantTheme")}</span><b>${esc(dp.theme||"—")}</b></div>
      <div class="dayinfo-item-v4"><span>${t("dressCode")}</span><b>${esc(dp.dress||"—")}</b></div>
      <div class="dayinfo-item-v4"><span>${t("eventsToday")}</span>${events}</div>
      <div class="dayinfo-item-v4"><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>${dp.showTime?`<small>${esc(dp.showTime)}${dp.showLoc?" · "+esc(dp.showLoc):""}</small>`:""}</div>
      <div class="dayinfo-item-v4"><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
      <div class="dayinfo-item-v4"><span>${t("dayOff")}</span><b>${personTags(dp.off)||"—"}</b></div>
      <div class="dayinfo-item-v4 wide"><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
    </div></div>`;
  }
  window.dayPlanInfoCard=function(day){ const dp=dayPlanFor(day); return `<div class="sec"><h3>${ic("calendar",18)} ${esc(t("days")[dp.day]||dp.name)}</h3>${v4DayInfoHtml(day)}</div>`; };
  window.workdayCompactInfo=function(day){ return `<div class="sec wd-dayinfo"><h3>${ic("calendar",18)} ${t("dayInfoSec")}</h3>${v4DayInfoHtml(day)}</div>`; };

  window.liveOpsCard=function(){
    const day=todayIndex(), hn=hotelNow(), now=hn.getHours()*60+hn.getMinutes()+hn.getSeconds()/60, rows=[];
    (S.activities||[]).filter(a=>a&&a.day===day).forEach(a=>{
      const ws=activityWindows(a); const use=ws.length?ws:[{s0:timeToMin(a.time)||0,e0:(timeToMin(a.time)||0)+45,start:String(a.time||""),end:""}];
      use.forEach((w,idx)=>rows.push({a,w,idx,total:use.length}));
    });
    rows.sort((x,y)=>x.w.s0-y.w.s0);
    let show=rows.filter(x=>x.w.e0>=now-20 && x.w.s0<=now+240).slice(0,4);
    if(!show.length){ const past=rows.filter(x=>x.w.e0<now).slice(-1); const future=rows.filter(x=>x.w.s0>now).slice(0,3); show=past.concat(future); }
    if(!show.length) return "";
    setTimeout(v4RepairDj,50);
    const row=x=>{
      const a=x.a,w=x.w,own=v4Owner(a,day),live=w.s0<=now&&now<w.e0,finished=now>=w.e0,soon=!live&&!finished&&(w.s0-now)<=60;
      const state=live?"Live now":finished?"Finished":soon?"Starting soon":"Upcoming";
      const cls=live?"is-live":finished?"is-finished":"";
      const timer=live?"Live · "+fmtCountdown((w.e0-now)*60):finished?"Finished":"Starts · "+fmtCountdown((w.s0-now)*60);
      const cat=v4Special(a)?catLabel(normCat(a)):t("activities");
      return `<div class="live-row-v4 ${cls}" data-actopen="${esc(String(a.id))}">
        <div><div class="live-eyebrow"><i></i>${esc(state)} · ${esc(cat)}</div><div class="live-name">${esc(a.name)}</div>
          <div class="live-meta">${esc((w.start||"")+(w.end?" – "+w.end:""))}${x.total>1?` · Set ${x.idx+1}/${x.total}`:""}${a.location?" · "+esc(a.location):""}</div>
          <div class="live-owner ${own.bad?"unavailable":""}">${ic("user",13)} ${own.name?esc(own.name):t("liveNoStaff")}${own.bad?" · unavailable":""}</div></div>
        <div class="live-clock-v4 ${live?"live":soon?"soon":finished?"finished":""}" data-live-s="${w.s0}" data-live-e="${w.e0}">${timer}</div>
      </div>`;
    };
    return `<div class="sec"><h3>${ic("clock",18)} ${t("liveOps")}</h3><div class="card live-card-v4">${show.map(row).join("")}</div></div>`;
  };

  window.feedbackAnalyticsCard=function(){
    const list=S.feedback||[], sum=fbSummary(list), st=(sum.stat||[]).slice().sort((a,b)=>a.avg-b.avg), mini=st.slice(0,5);
    const weak=sum.weak;
    return `<div class="sec"><h3>${ic("star",18)} ${t("fbAnalytics")}</h3>
      <div class="card mgr-fb-v4">
        <div class="fb-hero-v4">
          <div class="fb-kpi-v4"><strong>${sum.overall?sum.overall.toFixed(1):"—"}</strong><small>${t("avgRate")}</small></div>
          <div class="fb-kpi-v4"><strong>${sum.count}</strong><small>${t("feedback")}</small></div>
          <div class="fb-kpi-v4 ${sum.toReview?"warn":""}"><strong>${sum.toReview}</strong><small>${t("fbToReview")}</small></div>
        </div>
        ${weak?`<button class="fb-attention-v4" data-fbdept="${esc(weak.k)}"><span><b>${t("attentionHead")}</b><span>${esc(fbDeptLabel(weak.k))} · ${weak.n} ${t("fbResponses")}</span></span><strong class="score">${weak.avg.toFixed(1)}</strong></button>`:""}
        ${mini.length?`<div class="fb-mini-list-v4">${mini.map(d=>`<button class="fb-mini-v4" data-fbdept="${esc(d.k)}"><b>${esc(fbDeptLabel(d.k))}</b><span class="bar"><i style="width:${Math.round(d.avg/5*100)}%"></i></span><em>${d.avg.toFixed(1)}</em></button>`).join("")}</div>`:""}
        <button class="btn sm ghost fb-more-v4" id="btn-fbseeall">View all feedback</button>
      </div>
    </div>`;
  };

  setTimeout(v4RepairDj,900);
})();
