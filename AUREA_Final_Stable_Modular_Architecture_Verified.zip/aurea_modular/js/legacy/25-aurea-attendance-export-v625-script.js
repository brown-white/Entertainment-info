
(()=>{
'use strict';
if(window.__AUREA_ATTENDANCE_EXPORT_V625)return;
window.__AUREA_ATTENDANCE_EXPORT_V625=true;

function attDetailedDatasetV625(mk){
  const n=monthDays(mk),team=attTeamFor(mk);
  const headers=[t("displayName")].concat(Array.from({length:n},(_,i)=>String(i+1))).concat(["P","O","A","V"]);
  const rows=team.map(u=>{
    const tot=attTotals(u,mk);
    return [u.display_name||u.username].concat(Array.from({length:n},(_,i)=>{
      const d=i+1; return isFutureDay(mk,d)?"":attStatus(u,mk,d);
    })).concat([String(tot.P),String(tot.O),String(tot.A),String(tot.V)]);
  });
  return {title:"Detailed Monthly Attendance — "+monthLabel(mk),headers,rows,landscape:true,signatures:false,
    sourceNote:"Manager copy: P = Present · O = Day Off · A = Absent · V = Vacation · N = not employed/not counted."};
}
function attHotelDatasetV625(mk){
  const n=monthDays(mk),team=attTeamFor(mk);
  const headers=[t("displayName")].concat(Array.from({length:n},(_,i)=>String(i+1))).concat(["Present total"]);
  const rows=team.map(u=>{
    const tot=attTotals(u,mk);
    const days=Array.from({length:n},(_,i)=>{
      const d=i+1;
      if(isFutureDay(mk,d))return "";
      const st=attStatus(u,mk,d);
      if(st==="V"||st==="N")return "N";
      if(st==="P"||st==="O")return "P";
      return ""; // absence is not printed as a hotel attendance status
    });
    return [u.display_name||u.username].concat(days).concat([String(tot.P+tot.O)]);
  });
  const total=team.reduce((n,u)=>{const x=attTotals(u,mk);return n+x.P+x.O;},0);
  if(team.length)rows.push([t("totalRow")].concat(Array.from({length:n},()=>"")).concat([String(total)]));
  return {title:((S.settings&&(S.settings.hotelName||S.settings.name))||"Hotel")+" — Hotel Monthly Attendance — "+monthLabel(mk),
    headers,rows,landscape:true,signatures:true,
    sourceNote:"Hotel copy: Present and Day Off are printed as P and both count in Present total. Vacation is N and is not counted. Absence is left blank."};
}
window.buildHotelAttendanceV625=attHotelDatasetV625;
window.buildDetailedAttendanceV625=attDetailedDatasetV625;

window.openAttendanceExportV625=function(){
  const mk=currentAttMonth();
  const wrap=baseModal(`<h3>${ic("download",20)} Monthly attendance exports</h3>
    <p class="mini">Month: <b>${esc(monthLabel(mk))}</b></p>
    <div class="att-export-v625">
      <div class="att-export-card-v625"><h4>Hotel attendance file</h4><p>Only the hotel attendance view. Present + Day Off are P and count as Present. Vacation is N and does not count. Absence is left blank.</p>
        <div class="att-export-actions-v625"><button class="btn" id="a625-hotel-xlsx">Excel</button><button class="btn ghost" id="a625-hotel-pdf">PDF / Print</button></div></div>
      <div class="att-export-card-v625"><h4>Detailed Manager attendance</h4><p>Your complete operational copy with P / O / A / V / N kept separately and individual totals.</p>
        <div class="att-export-actions-v625"><button class="btn" id="a625-detail-xlsx">Excel</button><button class="btn ghost" id="a625-detail-pdf">PDF / Print</button></div></div>
    </div><button class="btn ghost" id="a625-close">${t("close")}</button>`);
  const fn="attendance-"+mk;
  wrap.querySelector("#a625-close").onclick=()=>wrap.remove();
  wrap.querySelector("#a625-hotel-xlsx").onclick=async()=>{await exportExcelSets([attHotelDatasetV625(mk)],fn+"-hotel");toastOk(t("saved"));};
  wrap.querySelector("#a625-hotel-pdf").onclick=()=>exportPdfSets([attHotelDatasetV625(mk)],attHotelDatasetV625(mk).title);
  wrap.querySelector("#a625-detail-xlsx").onclick=async()=>{await exportExcelSets([attDetailedDatasetV625(mk)],fn+"-detailed");toastOk(t("saved"));};
  wrap.querySelector("#a625-detail-pdf").onclick=()=>exportPdfSets([attDetailedDatasetV625(mk)],attDetailedDatasetV625(mk).title);
};

/* Keep the central Smart Export's Monthly Attendance as the detailed manager version. */
const buildBeforeV625=window.buildDataset;
window.buildDataset=buildDataset=function(kind){
  if(kind==="monthatt")return attDetailedDatasetV625(S.exportMonth||currentAttMonth());
  return buildBeforeV625(kind);
};

/* UI cleanup/wiring without touching any other page. */
const wireBeforeV625=window.wireCommon;
window.wireCommon=wireCommon=function(){
  wireBeforeV625();
  const fb=document.querySelector("#btn-fbexport");
  if(fb){
    const row=fb.parentElement; fb.remove();
    if(row)row.style.gridTemplateColumns="1fr";
  }
  const ax=document.querySelector("#att-export");
  if(ax)ax.onclick=()=>window.openAttendanceExportV625();
};

window.AUREA_ATTENDANCE_V625={
  dayDate:typeof dayDutyDate==="function"?dayDutyDate:null,
  hotelDataset:attHotelDatasetV625,
  detailedDataset:attDetailedDatasetV625
};
})();
