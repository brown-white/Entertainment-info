
(function(){
  function enhance(){
    try{
      document.querySelectorAll('button:not([type])').forEach(function(b){ b.type='button'; });
      document.querySelectorAll('.modal').forEach(function(m){ m.setAttribute('role','dialog'); m.setAttribute('aria-modal','true'); });
      document.querySelectorAll('.dr-it.on').forEach(function(x){ x.setAttribute('aria-current','page'); });
      document.querySelectorAll('img').forEach(function(img){
        if(!img.closest('.hero') && !img.hasAttribute('loading')) img.loading='lazy';
        if(!img.hasAttribute('decoding')) img.decoding='async';
      });
      var p=document.getElementById('f-pass'); if(p) p.autocomplete='current-password';
      var gp=document.getElementById('f-gpass'); if(gp) gp.autocomplete='current-password';
      var u=document.getElementById('f-user'); if(u) u.autocomplete='username';
    }catch(e){}
  }
  var obs=new MutationObserver(function(){ window.clearTimeout(window.__aureaEnhanceTimer); window.__aureaEnhanceTimer=window.setTimeout(enhance,40); });
  function start(){ enhance(); var app=document.getElementById('app'); if(app) obs.observe(app,{childList:true,subtree:true}); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
