
(()=>{
'use strict';
if(window.__AUREA_OPERATIONS_DATE_V621)return;
window.__AUREA_OPERATIONS_DATE_V621=true;

function todayRequirementItemsV621(){
  const d=todayIndex();
  return (S.activities||[]).filter(a=>a&&a.day===d&&["mEvents","eShow"].includes(normCat(a)))
    .slice().sort((a,b)=>(timeToMin(reqStartTime(a))||0)-(timeToMin(reqStartTime(b))||0));
}
function responsibleDisplayV621(a){
  const direct=entertainerName(a&&a.entertainer);
  if(direct)return direct;
  const dj=(S.users||[]).find(u=>u.role==="staff"&&+u.number===DJ_NUMBER&&u.active!==false&&!hasLeft(u));
  return dj?(dj.display_name||dj.username||""):"—";
}
function typeV621(a){return normCat(a)==="mEvents"?"Event":"Show";}
window.tonightCard=tonightCard=function(){
  const list=todayRequirementItemsV621();
  if(!list.length)return"";
  return `<div class="sec"><h3>${ic("sparkle",18)} ${t("today")}</h3><div class="v621-today-list">${list.map(a=>{
    const sh=reqSheetForAct(a), rows=(sh&&sh.rows)||[],done=rows.filter(r=>r.done).length,pct=rows.length?Math.round(done/rows.length*100):0;
    return `<div class="v621-today-item"><div class="v621-today-top" data-actopen="${esc(String(a.id))}"><div><div class="v621-today-type">${typeV621(a)}</div><div class="v621-today-name">${esc(a.name||"")}</div><div class="v621-today-meta">${esc(a.time||"")}${a.location?" · "+esc(a.location):""}</div><div class="v621-today-team">${ic("user",13)} ${esc(responsibleDisplayV621(a))}</div></div><span>${ic("back",16)}</span></div>
      <div class="v621-today-req">${sh?`<span class="mini">Requirements ${pct}% ready · ${done}/${rows.length}</span><button class="btn ghost sm" data-v621-openreq="${esc(String(sh.id))}">${ic("clipboard",13)} Open sheet</button>`:`<span class="mini">Requirement sheet suggested for this ${typeV621(a).toLowerCase()}.</span><button class="btn ghost sm" data-v621-makereq="${esc(String(a.id))}">${ic("clipboard",13)} Make sheet</button>`}</div></div>`;
  }).join("")}</div></div>`;
};
const oldWireV621=wireCommon;
window.wireCommon=wireCommon=function(){
  oldWireV621();
  document.querySelectorAll("[data-v621-makereq]").forEach(b=>b.onclick=e=>{e.stopPropagation();window.openReqEditor(null,b.dataset.v621Makereq);});
  document.querySelectorAll("[data-v621-openreq]").forEach(b=>b.onclick=e=>{e.stopPropagation();window.openReqEditor(b.dataset.v621Openreq);});
};
window.AUREA_OPERATION_WINDOWS_V621={morning:[600,750],afternoon:[900,1050],evening:[1170,1380],slot:operationSlotFromMinutes};
})();
