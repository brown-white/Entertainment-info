
(function(){
  'use strict';
  var baseBrowseViewV610=browseView;

  function hasOwn(o,k){ return !!o && Object.prototype.hasOwnProperty.call(o,k); }
  function allDesign(){ return (S.settings&&S.settings.guestProgramDays)||{}; }
  function dayDesign(day){ return allDesign()[String(day)]||{}; }
  function defaultTheme(day){ var dp=dayPlanFor(day); return String((dp&&dp.theme)||''); }
  function displayTheme(day){
    var info=(S.settings&&S.settings.dayInfoOverrides&&S.settings.dayInfoOverrides[String(day)])||{};
    if(hasOwn(info,'theme')) return String(info.theme||'');
    var d=dayDesign(day);
    return hasOwn(d,'restaurantTheme')?String(d.restaurantTheme||''):defaultTheme(day);
  }
  function displayDayName(day){ var d=dayDesign(day); return String(d.dayName||'').trim(); }
  function coverState(day,op){
    var d=dayDesign(day), covers=d.covers||{};
    if(hasOwn(covers,op)) return {custom:true,url:String(covers[op]||'')};
    return {custom:false,url:opImage(op)};
  }
  window.guestProgrammeDayDesignV610=dayDesign;

  function dayMetaHtml(day){
    var dn=displayDayName(day), th=displayTheme(day), weekday=String((t('days')||[])[day]||'');
    var manager=S.session&&S.session.role==='manager';
    if(!dn&&!th&&!manager) return '';
    return `<section class="gp10-daymeta">
      <div class="gp10-daymeta-top"><div>
        <div class="gp10-daymeta-kicker">Today's identity</div>
        <div class="gp10-daymeta-title">${esc(weekday)}${dn?` · ${esc(dn)}`:''}
          ${dn?`<small>${esc(weekday)} programme</small>`:''}
        </div>
      </div>${manager?`<button type="button" class="btn sm ghost gp10-edit" id="gp10-edit-day">${ic('pen',14)} Edit</button>`:''}</div>
      ${th?`<div class="gp10-daymeta-theme">${ic('sparkle',14)} <span>${t('restaurantTheme')}</span><b>${esc(th)}</b></div>`:''}
    </section>`;
  }

  function modernOperationCard(op){
    var acts=(S.activities||[]).filter(a=>a.day===S.day&&actOp(a)===op.id);
    var cs=coverState(S.day,op.id), img=cs.url;
    return `<button class="opcard guest-opcard gp10-opcard go-${esc(op.id)}${img?'':' no-cover'}" data-op="${esc(op.id)}">
      ${img?`<img src="${esc(img)}" alt="" loading="lazy">`:''}<div class="veil"></div>
      <div class="opc-txt"><h3>${esc(opLabel(op.id))}</h3><span>${acts.length} ${t('activities')}</span></div>
      <span class="opc-go">${ic('back',18)}</span>
    </button>`;
  }

  /* Root programme only. Deeper category/activity views remain the tested V6.9 logic. */
  browseView=function(title){
    if(S.op) return baseBrowseViewV610(title);
    var html=baseBrowseViewV610(title);
    if(!(S.session&&(S.session.role==='guest'||S.session.role==='manager'))) return html;
    /* Remove old restaurant banner if it exists. */
    html=html.replace(/<div class="theme-banner">[\s\S]*?<\/div>/,'');
    var meta=dayMetaHtml(S.day);
    var cards=`<div class="opgrid gp10-grid">${OPS.map(modernOperationCard).join('')}</div>`;
    html=html.replace(/<div class="opgrid">[\s\S]*?<\/div>\s*<\/div>$/,(m)=>cards+'</div>');
    if(html.indexOf('gp10-grid')<0){
      /* Conservative fallback if future markup changes: replace opening only, then rely on existing cards. */
      html=html.replace('<div class="opgrid">','<div class="opgrid gp10-grid">');
    }
    html=html.replace('<div class="opgrid gp10-grid">',meta+'<div class="opgrid gp10-grid">');
    return html;
  };

  function editorCoverLabel(op){
    return {daytime:'Daytime Activities',dayevents:'Daytime Events',evening:'Evening Operation',special:'Special Events'}[op]||op;
  }
  function readFileUrl(file){
    return new Promise(function(resolve,reject){
      try{ var r=new FileReader(); r.onload=()=>resolve(String(r.result||'')); r.onerror=reject; r.readAsDataURL(file); }
      catch(e){ reject(e); }
    });
  }

  window.openGuestProgrammeDesignV610=function(day){
    if(!(S.session&&S.session.role==='manager')) return;
    day=Number(day); if(!Number.isFinite(day)) day=S.day;
    var all={...allDesign()}, original=all[String(day)]||{}, draft={...original,covers:{...(original.covers||{})}};
    var weekday=String((t('days')||[])[day]||'');
    var wrap=baseModal(`<h3>${ic('sparkle',20)} Programme appearance · ${esc(weekday)}</h3>
      <div class="gp10-editor-note">Day Name and Restaurant Theme can be added, changed or left empty. Each programme cover can use the default image, a custom image, or no image.</div>
      <div class="gp10-inline"><div><label>Day Name</label><input id="gp10-dayname" placeholder="e.g. Habibi Day" value="${esc(String(draft.dayName||''))}"><button type="button" class="btn sm ghost" id="gp10-clear-dayname" style="margin-top:7px">Clear Day Name</button></div>
      <div><label>${t('restaurantTheme')}</label><input id="gp10-theme" placeholder="e.g. Seafood" value="${esc(displayTheme(day))}"><button type="button" class="btn sm ghost" id="gp10-clear-theme" style="margin-top:7px">Delete Restaurant Theme</button></div></div>
      <div class="gp10-cover-list" id="gp10-covers"></div>
      <button class="btn" id="gp10-save">${t('save')}</button>
      <button class="btn ghost" id="gp10-reset-day">Reset Day Name & Restaurant Theme</button>
      <button class="btn ghost" id="gp10-close">${t('close')}</button>`);
    var box=wrap.querySelector('#gp10-covers');
    function paint(){
      box.innerHTML=OPS.map(function(op){
        var state=hasOwn(draft.covers,op.id)?{custom:true,url:String(draft.covers[op.id]||'')}:{custom:false,url:opImage(op.id)};
        return `<div class="gp10-cover-row"><div class="gp10-cover-head"><b>${esc(editorCoverLabel(op.id))}</b><span class="mini">${state.custom?(state.url?'Custom':'No photo'):'Default'}</span></div>
          <div class="gp10-cover-preview">${state.url?`<img src="${esc(state.url)}" alt="">`:`<span>${ic('photo',22)} No cover photo</span>`}</div>
          <div class="gp10-cover-actions">
            <button type="button" class="btn sm ghost" data-gp10-upload="${esc(op.id)}">Change photo</button>
            <button type="button" class="btn sm ghost" data-gp10-clear="${esc(op.id)}">Delete photo</button>
            <button type="button" class="btn sm ghost" data-gp10-default="${esc(op.id)}">Use default</button>
          </div><input type="file" accept="image/*" data-gp10-file="${esc(op.id)}" hidden></div>`;
      }).join('');
      box.querySelectorAll('[data-gp10-upload]').forEach(function(b){ b.onclick=function(){ var f=box.querySelector('[data-gp10-file="'+b.dataset.gp10Upload+'"]'); if(f) f.click(); }; });
      box.querySelectorAll('[data-gp10-clear]').forEach(function(b){ b.onclick=function(){ draft.covers[b.dataset.gp10Clear]=''; paint(); }; });
      box.querySelectorAll('[data-gp10-default]').forEach(function(b){ b.onclick=function(){ delete draft.covers[b.dataset.gp10Default]; paint(); }; });
      box.querySelectorAll('[data-gp10-file]').forEach(function(inp){ inp.onchange=async function(){
        var file=inp.files&&inp.files[0]; if(!file) return;
        try{
          var url='';
          if(typeof uploadAvatar==='function'&&REMOTE){ url=await uploadAvatar(file); }
          else { url=await readFileUrl(file); }
          draft.covers[inp.dataset.gp10File]=url; paint();
        }catch(e){ console.error('programme cover upload',e); toastErr(t('uploadErr')); }
      }; });
    }
    paint();
    wrap.querySelector('#gp10-close').onclick=()=>wrap.remove();
    wrap.querySelector('#gp10-clear-dayname').onclick=function(){ wrap.querySelector('#gp10-dayname').value=''; };
    wrap.querySelector('#gp10-clear-theme').onclick=function(){ wrap.querySelector('#gp10-theme').value=''; };
    wrap.querySelector('#gp10-reset-day').onclick=function(){
      wrap.querySelector('#gp10-dayname').value='';
      wrap.querySelector('#gp10-theme').value=defaultTheme(day);
      delete draft.dayName; delete draft.restaurantTheme;
    };
    wrap.querySelector('#gp10-save').onclick=async function(){
      var dayName=wrap.querySelector('#gp10-dayname').value.trim();
      var theme=wrap.querySelector('#gp10-theme').value.trim();
      draft.dayName=dayName;
      delete draft.restaurantTheme; /* V6.10 uses the shared Day Information theme source. */
      if(!Object.keys(draft.covers||{}).length) delete draft.covers;
      all[String(day)]=draft;
      var infoAll={...((S.settings&&S.settings.dayInfoOverrides)||{})};
      infoAll[String(day)]={...(infoAll[String(day)]||{}),theme:theme};
      try{ await DB.saveSettings({...S.settings,guestProgramDays:all,dayInfoOverrides:infoAll}); wrap.remove(); toastOk(t('saved')); render(); }
      catch(e){ console.error('programme appearance save',e); toastErr(t('errSave')); }
    };
  };

  /* Manager editor binding after every render without replacing the core bind system. */
  document.addEventListener('click',function(e){
    var b=e.target&&e.target.closest?e.target.closest('#gp10-edit-day'):null;
    if(!b) return;
    e.preventDefault(); e.stopPropagation();
    openGuestProgrammeDesignV610(S.day);
  });
})();
