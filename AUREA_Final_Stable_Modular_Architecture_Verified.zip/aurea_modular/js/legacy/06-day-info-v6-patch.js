
(()=>{
  function diActs(day, cats){
    return (S.activities||[]).filter(a=>a&&a.day===day&&cats.includes(normCat(a)))
      .slice().sort((a,b)=>(timeToMin(a.time)||0)-(timeToMin(b.time)||0));
  }
  function diActText(a){
    const ws=(typeof activityTimeSets==='function'?activityTimeSets(a):[]);
    const times=ws&&ws.length?ws.map(x=>[x.start,x.end].filter(Boolean).join('–')).join(' · '):String(a.time||'');
    return `${a.name||'—'}${times?' · '+times:''}${a.location?' · '+a.location:''}`;
  }
  function diAuto(day){
    const events=diActs(day,['mEvents','eParty']);
    const live=diActs(day,['eLive']);
    const shows=diActs(day,['eShow']);
    return {
      events:events.map(diActText).join('\n'),
      live:live.map(diActText).join('\n'),
      show:shows.map(diActText).join('\n')
    };
  }
  function diOverride(day){
    const all=(S.settings&&S.settings.dayInfoOverrides)||{};
    return all[String(day)]||null;
  }
  function diDisplay(day){
    const auto=diAuto(day), ov=diOverride(day), dp=dayPlanFor(day);
    return {
      events:ov&&Object.prototype.hasOwnProperty.call(ov,'events')?ov.events:auto.events,
      live:ov&&Object.prototype.hasOwnProperty.call(ov,'live')?ov.live:auto.live,
      show:ov&&Object.prototype.hasOwnProperty.call(ov,'show')?ov.show:auto.show,
      entrance:personTag(dp.entrance)||'—',
      off:personTags(dp.off)||'—',
      custom:!!ov
    };
  }
  function valueHtml(v){ return `<b>${esc(v||'—')}</b>`; }
  window.v6DayInfoHtml=function(day){
    const d=diDisplay(day);
    return `<div class="card dayinfo-v6"><div class="dayinfo-grid-v6">
      <div class="dayinfo-item-v6 wide"><span>${t('eventsToday')}</span>${valueHtml(d.events)}</div>
      <div class="dayinfo-item-v6"><span>Live music</span>${valueHtml(d.live)}</div>
      <div class="dayinfo-item-v6"><span>Show time</span>${valueHtml(d.show)}</div>
      <div class="dayinfo-item-v6"><span>${t('entranceDuty')}</span>${valueHtml(d.entrance)}</div>
      <div class="dayinfo-item-v6"><span>${t('dayOff')}</span>${valueHtml(d.off)}</div>
    </div></div>`;
  };
  function managerHead(day,label){
    const mgr=S.session&&S.session.role==='manager';
    return `<div class="dayinfo-head-v6"><h3>${ic('calendar',18)} ${label}</h3>${mgr?`<button class="btn sm ghost dayinfo-edit-v6" type="button" onclick="openDayInfoEditorV6(${day})">${ic('pen',14)} Edit</button>`:''}</div>`;
  }
  window.dayPlanInfoCard=function(day){
    const dp=dayPlanFor(day);
    return `<div class="sec">${managerHead(day,esc(t('days')[dp.day]||dp.name))}${v6DayInfoHtml(day)}</div>`;
  };
  window.workdayCompactInfo=function(day){
    return `<div class="sec wd-dayinfo">${managerHead(day,t('dayInfoSec'))}${v6DayInfoHtml(day)}</div>`;
  };
  window.openDayInfoEditorV6=function(day){
    if(!(S.session&&S.session.role==='manager')) return;
    const auto=diAuto(day), ov=diOverride(day)||{}, dp=dayPlanFor(day);
    const staff=(S.users||[]).filter(u=>u&&u.role==='staff'&&u.active!==false&&!hasLeft(u)&&u.number).sort((a,b)=>(a.number||99)-(b.number||99));
    const cur=(key)=>Object.prototype.hasOwnProperty.call(ov,key)?ov[key]:auto[key];
    const checks=staff.map(u=>`<label class="di-v6-check"><input type="checkbox" data-di-off value="${u.number}" ${dp.off.includes(u.number)?'checked':''}><span>#${u.number} · ${esc(u.display_name||u.username||'')}</span></label>`).join('');
    const opts=['<option value="">— Nobody —</option>'].concat(staff.map(u=>`<option value="${u.number}" ${dp.entrance===u.number?'selected':''}>#${u.number} · ${esc(u.display_name||u.username||'')}</option>`)).join('');
    const wrap=baseModal(`<h3>${ic('calendar',20)} Edit day information</h3>
      <p class="mini">Events, live music and show time come from the programme automatically. Edit them here only when you want a custom display for this day.</p>
      <label>Events</label><textarea id="di-v6-events" rows="3">${esc(cur('events')||'')}</textarea>
      <div class="di-v6-grid"><div><label>Live music</label><textarea id="di-v6-live" rows="3">${esc(cur('live')||'')}</textarea></div><div><label>Show time</label><textarea id="di-v6-show" rows="3">${esc(cur('show')||'')}</textarea></div></div>
      <label>${t('entranceDuty')}</label><select id="di-v6-ent">${opts}</select>
      <label>${t('dayOff')}</label><div class="di-v6-checks">${checks||'<span class="mini">No team members</span>'}</div>
      <button class="btn" id="di-v6-save">Save changes</button>
      <button class="btn ghost" id="di-v6-reset">Reset text to programme</button>
      <button class="btn ghost" id="di-v6-close">${t('close')}</button>`);
    wrap.querySelector('#di-v6-close').onclick=()=>wrap.remove();
    wrap.querySelector('#di-v6-save').onclick=async()=>{
      const allInfo={...((S.settings&&S.settings.dayInfoOverrides)||{})};
      allInfo[String(day)]={
        events:wrap.querySelector('#di-v6-events').value.trim(),
        live:wrap.querySelector('#di-v6-live').value.trim(),
        show:wrap.querySelector('#di-v6-show').value.trim()
      };
      const allDuty={...((S.settings&&S.settings.dayOverrides)||{})};
      const off=[...wrap.querySelectorAll('[data-di-off]')].filter(x=>x.checked).map(x=>+x.value);
      const ent=wrap.querySelector('#di-v6-ent').value;
      allDuty[String(day)]={...(allDuty[String(day)]||{}),off,entrance:ent?+ent:null};
      try{
        await DB.saveSettings({...S.settings,dayInfoOverrides:allInfo,dayOverrides:allDuty});
        wrap.remove(); toastOk(t('saved')); render();
      }catch(e){ toastErr(t('errSave')); }
    };
    wrap.querySelector('#di-v6-reset').onclick=async()=>{
      const allInfo={...((S.settings&&S.settings.dayInfoOverrides)||{})}; delete allInfo[String(day)];
      try{ await DB.saveSettings({...S.settings,dayInfoOverrides:allInfo}); wrap.remove(); toastOk(t('saved')); render(); }
      catch(e){ toastErr(t('errSave')); }
    };
  };
})();
