
(()=>{
'use strict';
if(window.__AUREA_SMART_ASSIGNMENT_V622)return;
window.__AUREA_SMART_ASSIGNMENT_V622=true;

const norm622=v=>String(v??'').trim().toLowerCase();
const uname622=u=>norm622(u&&u.username);
const dayDate622=day=>assignDateStr(day);
const weight622=a=>{const t=typeof activityType==="function"?activityType(a):"balanced";return t==="active"?3:t==="relaxing"?1:2;};
const start622=a=>{const w=activityWindows(a);return w.length?w[0].s0:timeToMin(a&&a.time);};
const type622=a=>typeof activityType==="function"?activityType(a):"balanced";

function userFor622(v){
  const q=norm622(v);if(!q)return null;
  return (S.users||[]).find(u=>norm622(u.username)===q||norm622(u.display_name)===q)||null;
}
function genderMap622(){return (S.settings&&S.settings.activityGenderRequirements)||{};}
function requiredGender622(a){
  const explicit=norm622(a&&(a.required_gender||a.needs_gender||a.gender_requirement));
  if(explicit==="male"||explicit==="female")return explicit;
  const map=genderMap622(),g=norm622(map[actKey(a&&a.name)]);
  return g==="male"||g==="female"?g:"";
}
function genderAllowed622(u,a){
  const need=requiredGender622(a);
  if(!need)return true;
  return norm622(u&&u.gender)===need;
}
window.smartActivityGenderRequirementV622=requiredGender622;

function windowsOverlap622(a,b){
  const aw=activityWindows(a),bw=activityWindows(b);
  if(!aw.length||!bw.length)return false;
  return aw.some(x=>bw.some(y=>x.s0<y.e0&&x.e0>y.s0));
}
function assignedTo622(a,u){
  const me=uname622(u),dn=norm622(u&&u.display_name);
  return norm622(a&&a.entertainer).split(/\s*[,;\/]\s*/).filter(Boolean).some(x=>x===me||(dn&&x===dn));
}
function hardAvailable622(u,a,day){
  if(!u||!a)return false;
  const ds=dayDate622(day);
  if(!availableOn(u,day,ds))return false;               // day off / vacation / absent / inactive / left
  if(!canRunActivity(u,a))return false;                 // I can / I can't
  if(!genderAllowed622(u,a))return false;               // only when manager explicitly configured gender
  if(entranceConflict(u,day,a))return false;            // hard 16:00–18:30 exclusion
  return true;
}
function hardValidExisting622(a){
  if(activitySlot(a)==="event"){
    const u=userFor622(a.entertainer);
    return !!u&&+u.number===DJ_NUMBER&&availableOn(u,a.day,dayDate622(a.day));
  }
  const u=userFor622(a.entertainer);
  if(!hardAvailable622(u,a,a.day))return false;
  const clash=(S.activities||[]).some(b=>b!==a&&b.day===a.day&&activitySlot(b)!=="event"&&assignedTo622(b,u)&&windowsOverlap622(a,b));
  if(clash)return false;
  const sameOperation=(S.activities||[]).some(b=>b!==a&&b.day===a.day&&activitySlot(b)===activitySlot(a)&&assignedTo622(b,u));
  return !sameOperation;
}
window.smartAssignmentValidV622=hardValidExisting622;

function metrics622(excludedActs){
  const excluded=new Set(excludedActs||[]);
  const m={count:{},points:{},acts:{},times:{},types:{},days:{},slots:{}};
  (S.activities||[]).forEach(a=>{
    if(excluded.has(a)||activitySlot(a)==="event")return;
    const u=userFor622(a.entertainer);if(!u)return;
    bump622(m,u,a,a.day);
  });
  return m;
}
function k622(u){return uname622(u);}
function bump622(m,u,a,day){
  const k=k622(u),ak=actKey(a&&a.name),tm=start622(a),typ=type622(a),slot=activitySlot(a);
  m.count[k]=(m.count[k]||0)+1;
  m.points[k]=(m.points[k]||0)+weight622(a);
  if(ak)m.acts[k+"|"+ak]=(m.acts[k+"|"+ak]||0)+1;
  if(tm!=null)m.times[k+"|"+tm]=(m.times[k+"|"+tm]||0)+1;
  m.types[k+"|"+typ]=(m.types[k+"|"+typ]||0)+1;
  m.slots[k+"|"+day+"|"+slot]=(m.slots[k+"|"+day+"|"+slot]||0)+1;
  if(ak){m.days[k+"|"+ak]=m.days[k+"|"+ak]||[];m.days[k+"|"+ak].push(day);}
}
function sameActCount622(m,u,a){return m.acts[k622(u)+"|"+actKey(a&&a.name)]||0;}
function sameTimeCount622(m,u,a){const tm=start622(a);return tm==null?0:(m.times[k622(u)+"|"+tm]||0);}
function recentRepeat622(m,u,a,day){
  const ds=m.days[k622(u)+"|"+actKey(a&&a.name)]||[];
  return ds.some(d=>dayGap(d,day)<=1)?1:0;
}
function sameTypeCount622(m,u,a){return m.types[k622(u)+"|"+type622(a)]||0;}
function sameDaySlotCount622(m,u,a,day){return m.slots[k622(u)+"|"+day+"|"+activitySlot(a)]||0;}

function clashesWithReserved622(u,a,reserved){
  return (reserved||[]).some(x=>x.activity&&x.activity.day===a.day&&uname622(x.user||userFor622(x.username||x.activity.entertainer))===uname622(u)&&windowsOverlap622(a,x.activity));
}
function choose622(pool,m,reserved,a,day,variant){
  let candidates=(pool||[])
    .filter(u=>+u.number!==DJ_NUMBER)
    .filter(u=>hardAvailable622(u,a,day)&&!clashesWithReserved622(u,a,reserved))
    .filter(u=>sameDaySlotCount622(m,u,a,day)===0)
    .filter(u=>!(reserved||[]).some(x=>{
      const xu=x.user||userFor622(x.username||x.activity&&x.activity.entertainer);
      return xu&&uname622(xu)===uname622(u)&&x.activity&&x.activity.day===day&&activitySlot(x.activity)===activitySlot(a);
    }));
  if(!candidates.length)return null;

  /* Strong rule 1: do not repeat the same activity if somebody else valid has not done it. */
  const noSameAct=candidates.filter(u=>sameActCount622(m,u,a)===0);
  if(noSameAct.length)candidates=noSameAct;

  /* Strong rule 2: do not keep giving somebody the same clock-time when another valid person has not had it. */
  const noSameTime=candidates.filter(u=>sameTimeCount622(m,u,a)===0);
  if(noSameTime.length)candidates=noSameTime;

  const hash=(s)=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0;};
  const score=u=>{
    const k=k622(u);
    return (m.points[k]||0)*10000000 +               // hard/easy workload balance
      (m.count[k]||0)*1000000 +                     // total assignment balance
      sameDaySlotCount622(m,u,a,day)*300000 +        // avoid multiple activities in same operation
      sameTypeCount622(m,u,a)*80000 +                // avoid one person getting only active/relaxing work
      recentRepeat622(m,u,a,day)*50000 +             // avoid yesterday/tomorrow repetition
      sameActCount622(m,u,a)*12000 +
      sameTimeCount622(m,u,a)*6000 +
      (hash(k+"|"+actKey(a.name)+"|"+day+"|"+(variant||0))%900);
  };
  return candidates.slice().sort((a,b)=>score(a)-score(b)||(+(a.number||99)-+(b.number||99)))[0]||null;
}
window.pickFairest=function(pool,load,usedThisSlot,act,day){
  /* Compatibility for any older caller: use the new hard eligibility and fairness.
     `usedThisSlot` remains respected, but never overrides a hard safety rule. */
  const fake=metrics622([]);
  let c=(pool||[]).filter(u=>+u.number!==DJ_NUMBER&&hardAvailable622(u,act,day));
  const unused=c.filter(u=>!usedThisSlot||!usedThisSlot.has(u.username));if(unused.length)c=unused;
  return choose622(c,fake,[],act,day,0);
};

function eventPlans622(day,opts){
  const dj=eventsCrew(day,dayDate622(day))[0]||null;if(!dj)return[];
  return (S.activities||[]).filter(a=>a.day===day&&activitySlot(a)==="event")
    .filter(a=>(opts&&opts.onlyEmpty)?!norm622(a.entertainer):true)
    .map(a=>({activity:a,slot:"event",username:dj.username,name:dj.display_name||dj.username,day}));
}
function normalTargets622(day,opts){
  return (S.activities||[]).filter(a=>a.day===day&&["morning","afternoon"].includes(activitySlot(a)))
    .filter(a=>(opts&&opts.onlyEmpty)?!norm622(a.entertainer):true)
    .sort((a,b)=>(start622(a)||9999)-(start622(b)||9999)||String(a.name).localeCompare(String(b.name)));
}
function preserved622(day,targets){
  const set=new Set(targets);
  return (S.activities||[]).filter(a=>a.day===day&&!set.has(a)&&activitySlot(a)!=="event"&&norm622(a.entertainer))
    .map(a=>({activity:a,user:userFor622(a.entertainer),username:(userFor622(a.entertainer)||{}).username||a.entertainer}));
}
function planDay622(day,opts,sharedMetrics,variant,targetOverride){
  const o=opts||{},targets=targetOverride||normalTargets622(day,o),out=eventPlans622(day,o);
  const exclude=targetOverride?targets:((o.onlyEmpty)?[]:(S.activities||[]).filter(a=>a.day===day&&activitySlot(a)!=="event"));
  const m=sharedMetrics||metrics622(exclude);
  const reserved=preserved622(day,targets);
  const pool=assignableStaff(day,dayDate622(day)).filter(u=>+u.number!==DJ_NUMBER);
  targets.forEach(a=>{
    const pick=choose622(pool,m,reserved,a,day,variant||0);
    if(!pick)return;
    const item={activity:a,username:pick.username,name:pick.display_name||pick.username,slot:activitySlot(a),day,user:pick};
    out.push(item);reserved.push(item);bump622(m,pick,a,day);
  });
  return out;
}
window.autoAssignDay=function(day,opts,sharedLoad){return planDay622(day,opts,sharedLoad,0);};
window.autoAssignWeek=function(opts){
  const o=opts||{};
  const exclude=o.onlyEmpty?[]:(S.activities||[]).filter(a=>activitySlot(a)!=="event");
  const m=metrics622(exclude),out=[];
  for(let d=0;d<7;d++)out.push(...planDay622(d,o,m,d));
  return out;
};

const baseApply622=window.applyAssignments||applyAssignments;
window.applyAssignments=applyAssignments=async function(list){
  const reserved=[];
  for(const it of (list||[])){
    const a=it.activity,u=userFor622(it.username);
    if(activitySlot(a)==="event"){
      if(!u||+u.number!==DJ_NUMBER||!availableOn(u,a.day,dayDate622(a.day))){toastErr("This event/show assignment is not available.");return false;}
    }else{
      if(!hardAvailable622(u,a,a.day)||clashesWithReserved622(u,a,reserved)){
        toastErr((u?(u.display_name||u.username):"This entertainer")+" is not available for "+(a.name||"this activity")+". Check day off, vacation, absence, entrance duty, gender, capability and time conflicts.");
        return false;
      }
      reserved.push({activity:a,user:u,username:u.username});
    }
  }
  return baseApply622(list);
};

/* Repair only HARD-invalid saved assignments when duty/attendance changes.
   Fair-but-valid manual choices are never silently changed. */
let repairing622=false;
async function repairDay622(day){
  if(repairing622||!(S.session&&S.session.role==="manager"))return false;
  const invalid=(S.activities||[]).filter(a=>a.day===day&&activitySlot(a)!=="event"&&norm622(a.entertainer)&&!hardValidExisting622(a));
  if(!invalid.length)return false;
  repairing622=true;
  try{
    const m=metrics622(invalid),reserved=preserved622(day,invalid),pool=assignableStaff(day,dayDate622(day)).filter(u=>+u.number!==DJ_NUMBER);
    for(const a of invalid){
      const pick=choose622(pool,m,reserved,a,day,0);
      if(pick){
        await DB.saveActivity({...a,entertainer:pick.username});
        const it={activity:a,user:pick,username:pick.username};reserved.push(it);bump622(m,pick,a,day);
      }else{
        await DB.saveActivity({...a,entertainer:""});
      }
    }
    return true;
  }catch(e){console.error("V6.22 assignment repair",e);return false;}
  finally{repairing622=false;}
}
async function repairAll622(){
  let changed=false;for(let d=0;d<7;d++)changed=(await repairDay622(d))||changed;return changed;
}
window.repairSmartAssignmentsV622=repairAll622;

const oldSetAtt622=DB.setStaffAtt.bind(DB);
DB.setStaffAtt=async function(username,date,status){
  const r=await oldSetAtt622(username,date,status);
  const dt=new Date(String(date)+"T12:00:00"),day=isNaN(dt)?null:(dt.getDay()+6)%7;
  if(day!=null)await repairDay622(day);
  return r;
};
const oldSaveSettings622=DB.saveSettings.bind(DB);
DB.saveSettings=async function(next){
  const before=JSON.stringify((S.settings&&S.settings.dayOverrides)||{});
  const after=JSON.stringify((next&&next.dayOverrides)||{});
  const r=await oldSaveSettings622(next);
  if(before!==after&&S.session&&S.session.role==="manager"){
    for(let d=0;d<7;d++)await repairDay622(d);
  }
  return r;
};

/* Optional gender requirement. The engine does not stereotype activities:
   Any is the default. Male/Female is enforced only when the manager explicitly sets it. */
const oldEdit622=window.openEditModal;
window.openEditModal=function(input){
  oldEdit622(input);
  setTimeout(()=>{
    const sheets=[...document.querySelectorAll(".modal")],sheet=sheets[sheets.length-1];if(!sheet||sheet.querySelector("#as622-gender"))return;
    const name=sheet.querySelector("#e-name"),save=sheet.querySelector("#e-save"),cat=sheet.querySelector("#e-cat");if(!name||!save||!cat)return;
    const box=document.createElement("div");box.id="as622-gender";box.className="as622-gender";
    const cur=requiredGender622({name:name.value});
    box.innerHTML=`<label>Gender requirement for assignment</label><select id="as622-gender-select"><option value="" ${!cur?"selected":""}>Any gender</option><option value="male" ${cur==="male"?"selected":""}>${t("genderM")}</option><option value="female" ${cur==="female"?"selected":""}>${t("genderF")}</option></select><p class="mini">Optional. Smart Assign only uses gender when you explicitly set a requirement for this activity.</p>`;
    save.parentNode.insertBefore(box,save);
    save.addEventListener("click",()=>{
      const key=actKey(name.value),val=box.querySelector("#as622-gender-select").value,map={...genderMap622()};
      if(key){if(val)map[key]=val;else delete map[key];S.settings={...S.settings,activityGenderRequirements:map};DB.saveSettings({...S.settings,activityGenderRequirements:map}).catch(()=>{});}
    },true);
  },70);
};

/* Manager assignment overview uses the same hard validity rules. */
window.assignActsInner=function(day,ds,acts,openIgnored,working){
  const unresolved=acts.filter(a=>!hardValidExisting622(a));
  const dj=(S.users||[]).find(u=>u&&u.role==="staff"&&+u.number===DJ_NUMBER&&u.active!==false&&!hasLeft(u));
  const djState=()=>{
    if(!dj)return "DJ account unavailable";
    const st=(ds&&ds.length>=10)?attStatus(dj,ds.slice(0,7),+ds.slice(8,10)):"";
    if(st==="V")return "Vacation";
    if(st==="A")return "Absent";
    if(st==="N")return "Not working";
    if(dayPlanFor(day).off.includes(+DJ_NUMBER))return "Day off";
    return "";
  };
  const djProblem=djState();
  const djItems=(S.activities||[]).filter(a=>a.day===day&&activitySlot(a)==="event");
  const djWarnings=djProblem&&djItems.length?`<div class="as622-rule-note" style="border:1px solid rgba(176,82,57,.22);background:rgba(176,82,57,.05)"><b>DJ operational warning:</b> ${djItems.map(a=>esc(a.name)).join(", ")} ${djItems.length===1?"is":"are"} DJ programme, but ${esc(dj?dj.display_name||dj.username:"DJ")} is on <b>${esc(djProblem)}</b>. The app will not assign these events/shows/parties to an entertainer. Management needs to arrange DJ coverage.</div>`:"";
  return `<div class="g3-stats" style="margin-top:12px"><div class="stat"><b>${acts.length}</b><span>${t("activities")}</span></div><div class="stat"><b>${unresolved.length}</b><span>Needs assignment</span></div><div class="stat"><b>${working.length}</b><span>${t("workingToday")}</span></div></div>
    <div class="card ent-card" id="asg-ent" style="margin-top:12px"><span class="ent-ic">${ic("door",20)}</span><span class="asg-mid"><b>${t("entranceDuty")}</b><span class="mini">${personTag(dayPlanFor(day).entrance)||t("noOneEntrance")}</span></span><span class="ent-go">${ic("pen",15)}</span></div>
    <div class="as622-rule-note"><b>Smart assignment:</b> Maximum <b>1 activity per entertainer per operation</b>. Day off, vacation, absence and Entrance Duty are hard blocks. Entrance Duty allows an activity only when it is fully finished by 16:00; 15:30–16:00 is valid, 15:45–16:15 is not. The planner avoids repeated activities and repeated start-times, balances active/relaxing workload and total assignments, respects Can/Can't, and applies gender only when configured. DJ #3 is excluded from normal activities.</div>
    ${djWarnings}
    <div class="asg-actions-v5"><button class="btn" id="asg-auto">${ic("sparkle",18)} Generate plans</button><button class="btn ghost" id="asg-clearbad" title="Repair invalid assignments">↻</button></div>
    <div class="asg-status-v5 ${unresolved.length?"warn":""}">${unresolved.length?unresolved.length+" item(s) need a valid assignment":"All current assignments pass the hard availability checks"}</div>
    <div class="card" style="margin-top:12px">${acts.length?acts.map(a=>{const valid=hardValidExisting622(a),u=userFor622(a.entertainer),who=u?(u.display_name||u.username):String(a.entertainer||"").trim();return `<div class="asg-row" data-aopen="${a.id}"><span class="asg-t">${esc(a.time||"")}</span><span class="asg-mid"><b>${esc(a.name)}</b><span class="mini">${esc(whoCanRun(a))}${a.location?" · "+esc(a.location):""}</span><span class="asg-kind-v5">${activitySlot(a)==="event"?"DJ programme":type622(a)}</span></span>${valid?`<span class="asg-who">${esc(who)}</span>`:`<span class="asg-who none">Needs plan</span>`}</div>`}).join(""):`<p class="mini" style="padding:8px 2px">${t("noneToday")}</p>`}</div>`;
};

setTimeout(()=>{if(S.session&&S.session.role==="manager")repairAll622().then(changed=>{if(changed)render();});},1400);

window.AUREA_SMART_ASSIGNMENT_V622={
  version:"6.22",
  hardAvailable:hardAvailable622,
  valid:hardValidExisting622,
  requiredGender:requiredGender622,
  overlap:windowsOverlap622,
  repairDay:repairDay622,
  metrics:metrics622,
  choose:choose622,
  maxOnePerOperation:true,
  djExcludedFromActivities:true
};
})();
