
/* ================================================================
   ⚙️ SETUP — make it real in 2 steps:
   1) In Supabase: SQL Editor -> run supabase-setup.sql (one time)
   2) Paste your project values below (Supabase -> Settings -> API)
   While both are empty the app runs on sample data for preview.
================================================================ */
const CONFIG = {
  SUPABASE_URL: "https://smecztwnxieovszndxga.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_qY_DPSrOOR7nclHgXC05lQ_BMNSaf3V"
};
const REMOTE = !!(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_ANON_KEY);
const LS_KEY = "entapp_v3";

const DEFAULT_SETTINGS = {
  name:"Entertainment", subtitle:"", welcomeMsg:"",
  primary:"#3E2A1E", accent:"#B98A5C", bg:"#F7F2EA", textColor:"#2B1F16",
  navBg:"#FFFFFF", navActive:"#6B4A32",
  fontStyle:"elegant", buttonStyle:"rounded",
  menuHome:"", menuProgram:"", menuTickets:"", menuChat:"", menuStay:"",
  tripadvisor:"https://www.tripadvisor.com", google:"https://www.google.com/maps", holidaycheck:"https://www.holidaycheck.de",
  instagram:"", facebook:"", tiktok:"", youtube:"", whatsapp:"",
  busToHotel:"", busToHouse:"",
  aiEndpoint:"", pushEndpoint:"", palette:"brownWhite", dayOverrides:{}, hotelInfo:[], reviewAsk:true,
  logo:"", hotelName:"", timezone:"", currency:"EUR", contact:"", fontScale:"normal", autoDark:false,
  lat:"", lon:"",
  features:{quiz:true,tickets:true,gallery:true,bus:true,hotelinfo:true,weather:true}
};
const FONTS={
  aurea:["'DM Serif Display',serif","'Inter',sans-serif"],
  elegant:["'Cormorant Garamond',serif","'Jost',sans-serif"],
  royal:["'Playfair Display',serif","'Jost',sans-serif"],
  modern:["'Jost',sans-serif","'Jost',sans-serif"],
  soft:["'Nunito',sans-serif","'Nunito',sans-serif"]
};
const BTN_R={rounded:["14px","11px"],pill:["999px","999px"],square:["8px","7px"]};

/* ---------------- i18n ---------------- */
const LANGS=[["en","English"],["de","Deutsch"],["ru","Русский"],["pl","Polski"],["cs","Čeština"],["nl","Nederlands"],["fr","Français"],["ar","العربية"]];
const EXTRA={
en:{chat:"Chat",typeMessage:"Write a message…",send:"Send",noMessages:"No messages yet — say hello!",requests:"Requests",songRequest:"Song request",birthdayRequest:"Birthday",songName:"Song / artist",forWhom:"For whom?",birthdayDate:"Date",reqNote:"Message (optional)",myRequests:"My requests",statusNew:"New",done:"Done",markDone:"Mark done",tasks:"Tasks",addTask:"Add task",taskFor:"Assign to",allTeam:"Whole team",myTasks:"My tasks",noTasks:"No tasks — enjoy the sun!",attendance:"Attendance",present:"Present",notifications:"Notifications",newAnnouncement:"New notification",audience:"Send to",audAll:"Everyone",audGuests:"Guests",audTeam:"Team",noNotifs:"Nothing new right now.",rooms:"Rooms",addRooms:"Add rooms",roomsHint:"One room per line or separated by commas",activeLbl:"Active",roomNotFound:"This room number is not registered. Please ask at the reception.",guestAccounts:"Guest accounts",welcomeMsgLbl:"Welcome message (optional)",textC:"Text color",navC:"Menu color",navActiveC:"Active menu color",guestsTab:"Guests",teamTab:"Team",taskType:"Task type",ttCome:"Come to location",ttLeave:"Leave location",ttActivity:"Run activity",ttFeedback:"Collect feedback",ttCollect:"Collect guests",accept:"Accept",still:"Still working",cantDo:"I can't",accepted:"Accepted",late:"Late",points:"Points",rank:"Team ranking",exportReport:"Weekly report (Excel)",feedback:"Feedback",addFeedback:"Add feedback",rate:"Rating",comment:"Short comment",avgRate:"Average rating",taskStats:"Tasks per entertainer",dueLbl:"Deadline",aiTab:"AI Assistant",aiKeyLbl:"Anthropic API key",aiKeyHint:"Saved only in this browser — never in the app file or database.",aiAsk:"Ask your assistant…",aiIntro:"Professional help for planning, announcements, ideas and problems — it knows your live program and statistics.",aiErr:"AI request failed — check key and credit.",profile:"Profile",changePass:"Change password",newPass:"New password",yourLogin:"Your login details",saveThese:"Save these — you need them to sign in on other phones.",firstVisit:"First visit",accountExists:"This room already has an account — please sign in with the password.",editUser:"Edit user",overview:"Overview",menu:"Menu",logout:"Sign out",socialPage:"Social & Reviews",teamPage:"Meet the Team",contactWa:"Chat with us on WhatsApp",leaveReview:"Leave a review",ourTeam:"Our entertainment team",entertainersWord:"entertainers",profiles:"Profiles",addProfile:"Add profile",positionLbl:"Position",skills:"Skills",languagesLbl:"Languages",instagramLbl:"Instagram profile",whatsappLbl:"WhatsApp number",rememberMe:"Stay signed in",nextStep:"Next",backStep:"Back",createAccount:"Create account",chooseRoom:"Choose your room",chooseNat:"Choose your nationality",collectFrom:"Collect your tickets from",chooseMember:"Please choose a team member",handTo:"Hand over to",exportData:"Export data",exportExcel:"Export to Excel",exportPdf:"Export to PDF",exportWhat:"What would you like to export?",expBookings:"Bookings",expRequests:"Guest requests",expChat:"Chat messages",expUsers:"Team accounts",expGuests:"Guest list (rooms & nationality)",expTickets:"Ticket orders",expFeedback:"Guest feedback",expAll:"Everything",daysHere:"days in the app",joinedActs:"Joined activities",notifSound:"Sound & alerts",notifOn:"Notifications on",notifNew:"New notification",notifMsg:"New message",notifBooking:"New booking",notifTask:"New activity assigned",notifRequest:"New guest request",enableNotif:"Enable sound & pop-up alerts"},
de:{chat:"Chat",typeMessage:"Nachricht schreiben…",send:"Senden",noMessages:"Noch keine Nachrichten — sag Hallo!",requests:"Wünsche",songRequest:"Musikwunsch",birthdayRequest:"Geburtstag",songName:"Song / Künstler",forWhom:"Für wen?",birthdayDate:"Datum",reqNote:"Nachricht (optional)",myRequests:"Meine Wünsche",statusNew:"Neu",done:"Erledigt",markDone:"Als erledigt markieren",tasks:"Aufgaben",addTask:"Aufgabe hinzufügen",taskFor:"Zuweisen an",allTeam:"Ganzes Team",myTasks:"Meine Aufgaben",noTasks:"Keine Aufgaben — genieß die Sonne!",attendance:"Anwesenheit",present:"Anwesend",notifications:"Mitteilungen",newAnnouncement:"Neue Mitteilung",audience:"Senden an",audAll:"Alle",audGuests:"Gäste",audTeam:"Team",noNotifs:"Gerade nichts Neues.",rooms:"Zimmer",addRooms:"Zimmer hinzufügen",roomsHint:"Ein Zimmer pro Zeile oder mit Komma getrennt",activeLbl:"Aktiv",roomNotFound:"Diese Zimmernummer ist nicht registriert. Bitte frag an der Rezeption.",guestAccounts:"Gäste-Konten",welcomeMsgLbl:"Willkommenstext (optional)",textC:"Textfarbe",navC:"Menüfarbe",navActiveC:"Aktive Menüfarbe",guestsTab:"Gäste",teamTab:"Team",taskType:"Aufgabentyp",ttCome:"Zum Ort kommen",ttLeave:"Ort verlassen",ttActivity:"Aktivität durchführen",ttFeedback:"Feedback sammeln",ttCollect:"Gäste einsammeln",accept:"Annehmen",still:"Noch dabei",cantDo:"Ich kann nicht",accepted:"Angenommen",late:"Verspätet",points:"Punkte",rank:"Team-Rangliste",exportReport:"Wochenbericht (Excel)",feedback:"Feedback",addFeedback:"Feedback hinzufügen",rate:"Bewertung",comment:"Kurzer Kommentar",avgRate:"Ø Bewertung",taskStats:"Aufgaben pro Animateur",dueLbl:"Frist",aiTab:"KI-Assistent",aiKeyLbl:"Anthropic API-Schlüssel",aiKeyHint:"Nur in diesem Browser gespeichert — nie in der App-Datei oder Datenbank.",aiAsk:"Frag deinen Assistenten…",aiIntro:"Professionelle Hilfe für Planung, Mitteilungen, Ideen und Probleme — kennt dein Live-Programm und deine Statistiken.",aiErr:"KI-Anfrage fehlgeschlagen — prüfe Schlüssel und Guthaben.",profile:"Profil",changePass:"Passwort ändern",newPass:"Neues Passwort",yourLogin:"Deine Zugangsdaten",saveThese:"Speichere sie — du brauchst sie zum Anmelden auf anderen Handys.",firstVisit:"Erster Besuch",accountExists:"Dieses Zimmer hat bereits ein Konto — bitte mit Passwort anmelden.",editUser:"Nutzer bearbeiten",overview:"Statistik",menu:"Menü",logout:"Abmelden",socialPage:"Social & Bewertungen",teamPage:"Unser Team",contactWa:"Schreib uns auf WhatsApp",leaveReview:"Bewertung abgeben",ourTeam:"Unser Animationsteam",entertainersWord:"Animateure",profiles:"Profile",addProfile:"Profil hinzufügen",positionLbl:"Position",skills:"Fähigkeiten",languagesLbl:"Sprachen",instagramLbl:"Instagram-Profil",whatsappLbl:"WhatsApp-Nummer",rememberMe:"Angemeldet bleiben",nextStep:"Weiter",backStep:"Zurück",createAccount:"Konto erstellen",chooseRoom:"Zimmer wählen",chooseNat:"Nationalität wählen",collectFrom:"Tickets abholen bei",chooseMember:"Bitte ein Teammitglied wählen",handTo:"Übergabe durch",exportData:"Daten exportieren",exportExcel:"Als Excel exportieren",exportPdf:"Als PDF exportieren",exportWhat:"Was möchtest du exportieren?",expBookings:"Buchungen",expRequests:"Gästewünsche",expChat:"Chat-Nachrichten",expUsers:"Team-Konten",expGuests:"Gästeliste (Zimmer & Nationalität)",expTickets:"Ticket-Bestellungen",expFeedback:"Gästefeedback",expAll:"Alles",daysHere:"Tage in der App",joinedActs:"Teilgenommene Aktivitäten",notifSound:"Ton & Hinweise",notifOn:"Benachrichtigungen an",notifNew:"Neue Benachrichtigung",notifMsg:"Neue Nachricht",notifBooking:"Neue Buchung",notifTask:"Neue Aktivität zugewiesen",notifRequest:"Neuer Gästewunsch",enableNotif:"Ton & Pop-up-Hinweise aktivieren"},
ru:{chat:"Чат",typeMessage:"Напишите сообщение…",send:"Отправить",noMessages:"Пока нет сообщений — напишите нам!",requests:"Заявки",songRequest:"Заказ песни",birthdayRequest:"День рождения",songName:"Песня / исполнитель",forWhom:"Для кого?",birthdayDate:"Дата",reqNote:"Сообщение (необязательно)",myRequests:"Мои заявки",statusNew:"Новая",done:"Готово",markDone:"Отметить выполненной",tasks:"Задачи",addTask:"Добавить задачу",taskFor:"Назначить",allTeam:"Вся команда",myTasks:"Мои задачи",noTasks:"Задач нет — наслаждайтесь солнцем!",attendance:"Посещаемость",present:"Присутствует",notifications:"Уведомления",newAnnouncement:"Новое уведомление",audience:"Кому",audAll:"Всем",audGuests:"Гостям",audTeam:"Команде",noNotifs:"Пока ничего нового.",rooms:"Комнаты",addRooms:"Добавить комнаты",roomsHint:"По одной комнате в строке или через запятую",activeLbl:"Активна",roomNotFound:"Этот номер комнаты не зарегистрирован. Обратитесь на ресепшен.",guestAccounts:"Аккаунты гостей",welcomeMsgLbl:"Приветственный текст (необязательно)",textC:"Цвет текста",navC:"Цвет меню",navActiveC:"Цвет активного пункта",guestsTab:"Гости",teamTab:"Команда",taskType:"Тип задачи",ttCome:"Прийти в локацию",ttLeave:"Покинуть локацию",ttActivity:"Провести активность",ttFeedback:"Собрать отзывы",ttCollect:"Собрать гостей",accept:"Принять",still:"Ещё в процессе",cantDo:"Не могу",accepted:"Принято",late:"С опозданием",points:"Очки",rank:"Рейтинг команды",exportReport:"Недельный отчёт (Excel)",feedback:"Отзывы",addFeedback:"Добавить отзыв",rate:"Оценка",comment:"Короткий комментарий",avgRate:"Средняя оценка",taskStats:"Задачи по аниматорам",dueLbl:"Срок",aiTab:"ИИ-ассистент",aiKeyLbl:"API-ключ Anthropic",aiKeyHint:"Хранится только в этом браузере — не в файле приложения и не в базе.",aiAsk:"Спросите ассистента…",aiIntro:"Профессиональная помощь: планирование, тексты, идеи и проблемы — знает вашу программу и статистику.",aiErr:"Запрос к ИИ не удался — проверьте ключ и баланс.",profile:"Профиль",changePass:"Сменить пароль",newPass:"Новый пароль",yourLogin:"Ваши данные для входа",saveThese:"Сохраните их — они нужны для входа на других телефонах.",firstVisit:"Первый визит",accountExists:"У этой комнаты уже есть аккаунт — войдите с паролем.",editUser:"Редактировать пользователя",overview:"Статистика",menu:"Меню",logout:"Выйти",socialPage:"Соцсети и отзывы",teamPage:"Наша команда",contactWa:"Напишите нам в WhatsApp",leaveReview:"Оставить отзыв",ourTeam:"Наша команда анимации",entertainersWord:"аниматоров",profiles:"Профили",addProfile:"Добавить профиль",positionLbl:"Должность",skills:"Навыки",languagesLbl:"Языки",instagramLbl:"Профиль Instagram",whatsappLbl:"Номер WhatsApp",rememberMe:"Оставаться в системе",nextStep:"Далее",backStep:"Назад",createAccount:"Создать аккаунт",chooseRoom:"Выберите комнату",chooseNat:"Выберите национальность",collectFrom:"Забрать билеты у",chooseMember:"Пожалуйста, выберите сотрудника",handTo:"Выдаёт",exportData:"Экспорт данных",exportExcel:"Экспорт в Excel",exportPdf:"Экспорт в PDF",exportWhat:"Что вы хотите экспортировать?",expBookings:"Бронирования",expRequests:"Запросы гостей",expChat:"Сообщения чата",expUsers:"Аккаунты команды",expGuests:"Список гостей (комнаты и национальность)",expTickets:"Заказы билетов",expFeedback:"Отзывы гостей",expAll:"Всё",daysHere:"дней в приложении",joinedActs:"Посещённые активности",notifSound:"Звук и оповещения",notifOn:"Уведомления включены",notifNew:"Новое уведомление",notifMsg:"Новое сообщение",notifBooking:"Новая запись",notifTask:"Назначена новая активность",notifRequest:"Новый запрос гостя",enableNotif:"Включить звук и всплывающие оповещения"},
pl:{chat:"Czat",typeMessage:"Napisz wiadomość…",send:"Wyślij",noMessages:"Brak wiadomości — przywitaj się!",requests:"Prośby",songRequest:"Prośba o piosenkę",birthdayRequest:"Urodziny",songName:"Piosenka / wykonawca",forWhom:"Dla kogo?",birthdayDate:"Data",reqNote:"Wiadomość (opcjonalnie)",myRequests:"Moje prośby",statusNew:"Nowa",done:"Zrobione",markDone:"Oznacz jako zrobione",tasks:"Zadania",addTask:"Dodaj zadanie",taskFor:"Przypisz do",allTeam:"Cały zespół",myTasks:"Moje zadania",noTasks:"Brak zadań — ciesz się słońcem!",attendance:"Obecność",present:"Obecny",notifications:"Powiadomienia",newAnnouncement:"Nowe powiadomienie",audience:"Wyślij do",audAll:"Wszyscy",audGuests:"Goście",audTeam:"Zespół",noNotifs:"Na razie nic nowego.",rooms:"Pokoje",addRooms:"Dodaj pokoje",roomsHint:"Jeden pokój w linii lub po przecinku",activeLbl:"Aktywny",roomNotFound:"Ten numer pokoju nie jest zarejestrowany. Zapytaj w recepcji.",guestAccounts:"Konta gości",welcomeMsgLbl:"Tekst powitalny (opcjonalnie)",textC:"Kolor tekstu",navC:"Kolor menu",navActiveC:"Kolor aktywnego menu",guestsTab:"Goście",teamTab:"Zespół",taskType:"Typ zadania",ttCome:"Przyjdź na miejsce",ttLeave:"Opuść miejsce",ttActivity:"Poprowadź aktywność",ttFeedback:"Zbierz opinie",ttCollect:"Zbierz gości",accept:"Przyjmij",still:"Wciąż w trakcie",cantDo:"Nie mogę",accepted:"Przyjęte",late:"Po czasie",points:"Punkty",rank:"Ranking zespołu",exportReport:"Raport tygodniowy (Excel)",feedback:"Opinie",addFeedback:"Dodaj opinię",rate:"Ocena",comment:"Krótki komentarz",avgRate:"Średnia ocena",taskStats:"Zadania wg animatorów",dueLbl:"Termin",aiTab:"Asystent AI",aiKeyLbl:"Klucz API Anthropic",aiKeyHint:"Zapisany tylko w tej przeglądarce — nigdy w pliku aplikacji ani w bazie.",aiAsk:"Zapytaj asystenta…",aiIntro:"Profesjonalna pomoc: planowanie, komunikaty, pomysły i problemy — zna Twój program i statystyki.",aiErr:"Zapytanie AI nie powiodło się — sprawdź klucz i środki.",profile:"Profil",changePass:"Zmień hasło",newPass:"Nowe hasło",yourLogin:"Twoje dane logowania",saveThese:"Zapisz je — będą potrzebne do logowania na innych telefonach.",firstVisit:"Pierwsza wizyta",accountExists:"Ten pokój ma już konto — zaloguj się hasłem.",editUser:"Edytuj użytkownika",overview:"Statystyki",menu:"Menu",logout:"Wyloguj",socialPage:"Social i opinie",teamPage:"Nasz zespół",contactWa:"Napisz do nas na WhatsApp",leaveReview:"Zostaw opinię",ourTeam:"Nasz zespół animacji",entertainersWord:"animatorów",profiles:"Profile",addProfile:"Dodaj profil",positionLbl:"Stanowisko",skills:"Umiejętności",languagesLbl:"Języki",instagramLbl:"Profil na Instagramie",whatsappLbl:"Numer WhatsApp",rememberMe:"Nie wylogowuj mnie",nextStep:"Dalej",backStep:"Wstecz",createAccount:"Utwórz konto",chooseRoom:"Wybierz pokój",chooseNat:"Wybierz narodowość",collectFrom:"Odbiór biletów u",chooseMember:"Wybierz członka zespołu",handTo:"Wydaje",exportData:"Eksport danych",exportExcel:"Eksportuj do Excela",exportPdf:"Eksportuj do PDF",exportWhat:"Co chcesz wyeksportować?",expBookings:"Rezerwacje",expRequests:"Prośby gości",expChat:"Wiadomości czatu",expUsers:"Konta zespołu",expGuests:"Lista gości (pokoje i narodowość)",expTickets:"Zamówienia biletów",expFeedback:"Opinie gości",expAll:"Wszystko",daysHere:"dni w aplikacji",joinedActs:"Dołączone aktywności",notifSound:"Dźwięk i alerty",notifOn:"Powiadomienia włączone",notifNew:"Nowe powiadomienie",notifMsg:"Nowa wiadomość",notifBooking:"Nowa rezerwacja",notifTask:"Przypisano nową aktywność",notifRequest:"Nowa prośba gościa",enableNotif:"Włącz dźwięk i alerty pop-up"},
cs:{chat:"Chat",typeMessage:"Napište zprávu…",send:"Odeslat",noMessages:"Zatím žádné zprávy — pozdravte nás!",requests:"Přání",songRequest:"Přání písničky",birthdayRequest:"Narozeniny",songName:"Píseň / interpret",forWhom:"Pro koho?",birthdayDate:"Datum",reqNote:"Zpráva (volitelné)",myRequests:"Moje přání",statusNew:"Nové",done:"Hotovo",markDone:"Označit jako hotové",tasks:"Úkoly",addTask:"Přidat úkol",taskFor:"Přiřadit",allTeam:"Celý tým",myTasks:"Moje úkoly",noTasks:"Žádné úkoly — užijte si slunce!",attendance:"Docházka",present:"Přítomen",notifications:"Oznámení",newAnnouncement:"Nové oznámení",audience:"Komu",audAll:"Všem",audGuests:"Hostům",audTeam:"Týmu",noNotifs:"Zatím nic nového.",rooms:"Pokoje",addRooms:"Přidat pokoje",roomsHint:"Jeden pokoj na řádek nebo oddělené čárkou",activeLbl:"Aktivní",roomNotFound:"Toto číslo pokoje není registrováno. Zeptejte se na recepci.",guestAccounts:"Účty hostů",welcomeMsgLbl:"Uvítací text (volitelné)",textC:"Barva textu",navC:"Barva menu",navActiveC:"Barva aktivní položky",guestsTab:"Hosté",teamTab:"Tým",taskType:"Typ úkolu",ttCome:"Přijď na místo",ttLeave:"Opusť místo",ttActivity:"Veď aktivitu",ttFeedback:"Sbírej hodnocení",ttCollect:"Shromáždi hosty",accept:"Přijmout",still:"Stále na tom",cantDo:"Nemůžu",accepted:"Přijato",late:"Pozdě",points:"Body",rank:"Žebříček týmu",exportReport:"Týdenní report (Excel)",feedback:"Hodnocení hostů",addFeedback:"Přidat hodnocení",rate:"Hodnocení",comment:"Krátký komentář",avgRate:"Prům. hodnocení",taskStats:"Úkoly podle animátorů",dueLbl:"Termín",aiTab:"AI asistent",aiKeyLbl:"Anthropic API klíč",aiKeyHint:"Uložen jen v tomto prohlížeči — nikdy v souboru aplikace ani v databázi.",aiAsk:"Zeptej se asistenta…",aiIntro:"Profesionální pomoc: plánování, texty, nápady i problémy — zná tvůj program a statistiky.",aiErr:"AI požadavek selhal — zkontroluj klíč a kredit.",profile:"Profil",changePass:"Změnit heslo",newPass:"Nové heslo",yourLogin:"Vaše přihlašovací údaje",saveThese:"Uložte si je — potřebujete je pro přihlášení na dalších telefonech.",firstVisit:"První návštěva",accountExists:"Tento pokoj už má účet — přihlaste se heslem.",editUser:"Upravit uživatele",overview:"Statistiky",menu:"Menu",logout:"Odhlásit",socialPage:"Sociální sítě a recenze",teamPage:"Náš tým",contactWa:"Napište nám na WhatsApp",leaveReview:"Napsat recenzi",ourTeam:"Náš animační tým",entertainersWord:"animátorů",profiles:"Profily",addProfile:"Přidat profil",positionLbl:"Pozice",skills:"Dovednosti",languagesLbl:"Jazyky",instagramLbl:"Instagram profil",whatsappLbl:"Číslo WhatsApp",rememberMe:"Zůstat přihlášen",nextStep:"Další",backStep:"Zpět",createAccount:"Vytvořit účet",chooseRoom:"Vyberte pokoj",chooseNat:"Vyberte národnost",collectFrom:"Vyzvednout vstupenky u",chooseMember:"Vyberte prosím člena týmu",handTo:"Předá",exportData:"Exportovat data",exportExcel:"Exportovat do Excelu",exportPdf:"Exportovat do PDF",exportWhat:"Co chcete exportovat?",expBookings:"Rezervace",expRequests:"Přání hostů",expChat:"Zprávy chatu",expUsers:"Účty týmu",expGuests:"Seznam hostů (pokoje a národnost)",expTickets:"Objednávky vstupenek",expFeedback:"Hodnocení hostů",expAll:"Vše",daysHere:"dní v aplikaci",joinedActs:"Navštívené aktivity",notifSound:"Zvuk a upozornění",notifOn:"Oznámení zapnuta",notifNew:"Nové oznámení",notifMsg:"Nová zpráva",notifBooking:"Nová rezervace",notifTask:"Přiřazena nová aktivita",notifRequest:"Nové přání hosta",enableNotif:"Zapnout zvuk a vyskakovací upozornění"},
nl:{chat:"Chat",typeMessage:"Schrijf een bericht…",send:"Versturen",noMessages:"Nog geen berichten — zeg hallo!",requests:"Verzoeken",songRequest:"Muziekverzoek",birthdayRequest:"Verjaardag",songName:"Nummer / artiest",forWhom:"Voor wie?",birthdayDate:"Datum",reqNote:"Bericht (optioneel)",myRequests:"Mijn verzoeken",statusNew:"Nieuw",done:"Klaar",markDone:"Markeer als klaar",tasks:"Taken",addTask:"Taak toevoegen",taskFor:"Toewijzen aan",allTeam:"Hele team",myTasks:"Mijn taken",noTasks:"Geen taken — geniet van de zon!",attendance:"Aanwezigheid",present:"Aanwezig",notifications:"Meldingen",newAnnouncement:"Nieuwe melding",audience:"Versturen naar",audAll:"Iedereen",audGuests:"Gasten",audTeam:"Team",noNotifs:"Even niets nieuws.",rooms:"Kamers",addRooms:"Kamers toevoegen",roomsHint:"Eén kamer per regel of gescheiden door komma's",activeLbl:"Actief",roomNotFound:"Dit kamernummer is niet geregistreerd. Vraag het bij de receptie.",guestAccounts:"Gastaccounts",welcomeMsgLbl:"Welkomsttekst (optioneel)",textC:"Tekstkleur",navC:"Menukleur",navActiveC:"Actieve menukleur",guestsTab:"Gasten",teamTab:"Team",taskType:"Taaktype",ttCome:"Kom naar locatie",ttLeave:"Verlaat locatie",ttActivity:"Activiteit leiden",ttFeedback:"Feedback verzamelen",ttCollect:"Gasten verzamelen",accept:"Accepteren",still:"Nog bezig",cantDo:"Ik kan niet",accepted:"Geaccepteerd",late:"Te laat",points:"Punten",rank:"Teamranking",exportReport:"Weekrapport (Excel)",feedback:"Feedback",addFeedback:"Feedback toevoegen",rate:"Beoordeling",comment:"Korte opmerking",avgRate:"Gem. beoordeling",taskStats:"Taken per entertainer",dueLbl:"Deadline",aiTab:"AI-assistent",aiKeyLbl:"Anthropic API-sleutel",aiKeyHint:"Alleen in deze browser opgeslagen — nooit in het app-bestand of de database.",aiAsk:"Vraag je assistent…",aiIntro:"Professionele hulp: planning, teksten, ideeën en problemen — kent je programma en statistieken.",aiErr:"AI-verzoek mislukt — controleer sleutel en tegoed.",profile:"Profiel",changePass:"Wachtwoord wijzigen",newPass:"Nieuw wachtwoord",yourLogin:"Je inloggegevens",saveThese:"Bewaar ze — je hebt ze nodig om op andere telefoons in te loggen.",firstVisit:"Eerste bezoek",accountExists:"Deze kamer heeft al een account — log in met het wachtwoord.",editUser:"Gebruiker bewerken",overview:"Statistieken",menu:"Menu",logout:"Uitloggen",socialPage:"Social & Reviews",teamPage:"Ons team",contactWa:"App ons op WhatsApp",leaveReview:"Laat een review achter",ourTeam:"Ons animatieteam",entertainersWord:"entertainers",profiles:"Profielen",addProfile:"Profiel toevoegen",positionLbl:"Functie",skills:"Vaardigheden",languagesLbl:"Talen",instagramLbl:"Instagram-profiel",whatsappLbl:"WhatsApp-nummer",rememberMe:"Ingelogd blijven",nextStep:"Volgende",backStep:"Terug",createAccount:"Account aanmaken",chooseRoom:"Kies je kamer",chooseNat:"Kies je nationaliteit",collectFrom:"Tickets ophalen bij",chooseMember:"Kies een teamlid",handTo:"Overhandigd door",exportData:"Gegevens exporteren",exportExcel:"Naar Excel exporteren",exportPdf:"Naar PDF exporteren",exportWhat:"Wat wil je exporteren?",expBookings:"Boekingen",expRequests:"Gastverzoeken",expChat:"Chatberichten",expUsers:"Teamaccounts",expGuests:"Gastenlijst (kamers & nationaliteit)",expTickets:"Ticketbestellingen",expFeedback:"Gastfeedback",expAll:"Alles",daysHere:"dagen in de app",joinedActs:"Deelgenomen activiteiten",notifSound:"Geluid & meldingen",notifOn:"Meldingen aan",notifNew:"Nieuwe melding",notifMsg:"Nieuw bericht",notifBooking:"Nieuwe boeking",notifTask:"Nieuwe activiteit toegewezen",notifRequest:"Nieuw gastverzoek",enableNotif:"Geluid & pop-upmeldingen inschakelen"},
fr:{chat:"Chat",typeMessage:"Écrivez un message…",send:"Envoyer",noMessages:"Pas encore de messages — dites bonjour !",requests:"Demandes",songRequest:"Demande de chanson",birthdayRequest:"Anniversaire",songName:"Chanson / artiste",forWhom:"Pour qui ?",birthdayDate:"Date",reqNote:"Message (optionnel)",myRequests:"Mes demandes",statusNew:"Nouveau",done:"Fait",markDone:"Marquer comme fait",tasks:"Tâches",addTask:"Ajouter une tâche",taskFor:"Attribuer à",allTeam:"Toute l'équipe",myTasks:"Mes tâches",noTasks:"Aucune tâche — profitez du soleil !",attendance:"Présence",present:"Présent",notifications:"Notifications",newAnnouncement:"Nouvelle notification",audience:"Envoyer à",audAll:"Tout le monde",audGuests:"Invités",audTeam:"Équipe",noNotifs:"Rien de nouveau pour l'instant.",rooms:"Chambres",addRooms:"Ajouter des chambres",roomsHint:"Une chambre par ligne ou séparées par des virgules",activeLbl:"Active",roomNotFound:"Ce numéro de chambre n'est pas enregistré. Demandez à la réception.",guestAccounts:"Comptes invités",welcomeMsgLbl:"Message de bienvenue (optionnel)",textC:"Couleur du texte",navC:"Couleur du menu",navActiveC:"Couleur du menu actif",guestsTab:"Invités",teamTab:"Équipe",taskType:"Type de tâche",ttCome:"Venir sur place",ttLeave:"Quitter le lieu",ttActivity:"Animer l'activité",ttFeedback:"Recueillir des avis",ttCollect:"Rassembler les invités",accept:"Accepter",still:"Encore en cours",cantDo:"Je ne peux pas",accepted:"Acceptée",late:"En retard",points:"Points",rank:"Classement de l'équipe",exportReport:"Rapport hebdo (Excel)",feedback:"Avis",addFeedback:"Ajouter un avis",rate:"Note",comment:"Commentaire court",avgRate:"Note moyenne",taskStats:"Tâches par animateur",dueLbl:"Échéance",aiTab:"Assistant IA",aiKeyLbl:"Clé API Anthropic",aiKeyHint:"Enregistrée uniquement dans ce navigateur — jamais dans le fichier de l'app ni la base.",aiAsk:"Demandez à votre assistant…",aiIntro:"Aide professionnelle : planification, textes, idées et problèmes — il connaît votre programme et vos statistiques.",aiErr:"Échec de la requête IA — vérifiez la clé et le crédit.",profile:"Profil",changePass:"Changer le mot de passe",newPass:"Nouveau mot de passe",yourLogin:"Vos identifiants",saveThese:"Gardez-les — nécessaires pour vous connecter sur d'autres téléphones.",firstVisit:"Première visite",accountExists:"Cette chambre a déjà un compte — connectez-vous avec le mot de passe.",editUser:"Modifier l'utilisateur",overview:"Statistiques",menu:"Menu",logout:"Se déconnecter",socialPage:"Réseaux & Avis",teamPage:"Notre équipe",contactWa:"Écrivez-nous sur WhatsApp",leaveReview:"Laisser un avis",ourTeam:"Notre équipe d'animation",entertainersWord:"animateurs",profiles:"Profils",addProfile:"Ajouter un profil",positionLbl:"Poste",skills:"Compétences",languagesLbl:"Langues",instagramLbl:"Profil Instagram",whatsappLbl:"Numéro WhatsApp",rememberMe:"Rester connecté",nextStep:"Suivant",backStep:"Retour",createAccount:"Créer le compte",chooseRoom:"Choisir la chambre",chooseNat:"Choisir la nationalité",collectFrom:"Retirer vos billets auprès de",chooseMember:"Veuillez choisir un membre de l'équipe",handTo:"Remis par",exportData:"Exporter les données",exportExcel:"Exporter vers Excel",exportPdf:"Exporter en PDF",exportWhat:"Que souhaitez-vous exporter ?",expBookings:"Réservations",expRequests:"Demandes des clients",expChat:"Messages du chat",expUsers:"Comptes de l'équipe",expGuests:"Liste des clients (chambres & nationalité)",expTickets:"Commandes de billets",expFeedback:"Avis des clients",expAll:"Tout",daysHere:"jours dans l'app",joinedActs:"Activités rejointes",notifSound:"Son et alertes",notifOn:"Notifications activées",notifNew:"Nouvelle notification",notifMsg:"Nouveau message",notifBooking:"Nouvelle réservation",notifTask:"Nouvelle activité attribuée",notifRequest:"Nouvelle demande client",enableNotif:"Activer le son et les alertes pop-up"},
ar:{chat:"الدردشة",typeMessage:"اكتب رسالة…",send:"إرسال",noMessages:"لا توجد رسائل بعد — قل مرحباً!",requests:"الطلبات الخاصة",songRequest:"طلب أغنية",birthdayRequest:"عيد ميلاد",songName:"الأغنية / الفنان",forWhom:"لمن؟",birthdayDate:"التاريخ",reqNote:"رسالة (اختياري)",myRequests:"طلباتي الخاصة",statusNew:"جديد",done:"تم",markDone:"وضع علامة تم",tasks:"المهام",addTask:"إضافة مهمة",taskFor:"تعيين إلى",allTeam:"كل الفريق",myTasks:"مهامي",noTasks:"لا مهام — استمتع بالشمس!",attendance:"الحضور",present:"حاضر",notifications:"الإشعارات",newAnnouncement:"إشعار جديد",audience:"إرسال إلى",audAll:"الجميع",audGuests:"الضيوف",audTeam:"الفريق",noNotifs:"لا جديد الآن.",rooms:"الغرف",addRooms:"إضافة غرف",roomsHint:"غرفة واحدة في كل سطر أو مفصولة بفواصل",activeLbl:"مفعّلة",roomNotFound:"رقم الغرفة غير مسجل. يرجى السؤال في الاستقبال.",guestAccounts:"حسابات الضيوف",welcomeMsgLbl:"نص الترحيب (اختياري)",textC:"لون النص",navC:"لون القائمة",navActiveC:"لون القائمة النشط",guestsTab:"الضيوف",teamTab:"الفريق",taskType:"نوع المهمة",ttCome:"تعال إلى الموقع",ttLeave:"غادر الموقع",ttActivity:"قدّم النشاط",ttFeedback:"اجمع آراء الضيوف",ttCollect:"اجمع الضيوف",accept:"قبول",still:"ما زلت أعمل",cantDo:"لا أستطيع",accepted:"مقبولة",late:"متأخر",points:"نقاط",rank:"ترتيب الفريق",exportReport:"تقرير أسبوعي (Excel)",feedback:"آراء الضيوف",addFeedback:"إضافة رأي",rate:"التقييم",comment:"تعليق قصير",avgRate:"متوسط التقييم",taskStats:"المهام حسب المنشط",dueLbl:"الموعد النهائي",aiTab:"مساعد الذكاء",aiKeyLbl:"مفتاح Anthropic API",aiKeyHint:"يُحفظ في هذا المتصفح فقط — لا في ملف التطبيق ولا في قاعدة البيانات.",aiAsk:"اسأل مساعدك…",aiIntro:"مساعدة احترافية: التخطيط والنصوص والأفكار والمشكلات — يعرف برنامجك وإحصاءاتك.",aiErr:"فشل طلب الذكاء الاصطناعي — تحقق من المفتاح والرصيد.",profile:"الملف الشخصي",changePass:"تغيير كلمة المرور",newPass:"كلمة مرور جديدة",yourLogin:"بيانات دخولك",saveThese:"احفظها — ستحتاجها للدخول من هواتف أخرى.",firstVisit:"الزيارة الأولى",accountExists:"هذه الغرفة لديها حساب بالفعل — سجّل الدخول بكلمة المرور.",editUser:"تعديل المستخدم",overview:"نظرة عامة",menu:"القائمة",logout:"تسجيل الخروج",socialPage:"التواصل والتقييمات",teamPage:"تعرّف على الفريق",contactWa:"راسلنا على واتساب",leaveReview:"اترك تقييماً",ourTeam:"فريق الترفيه لدينا",entertainersWord:"منشطين",profiles:"الملفات الشخصية",addProfile:"إضافة ملف",positionLbl:"المنصب",skills:"المهارات",languagesLbl:"اللغات",instagramLbl:"حساب إنستغرام",whatsappLbl:"رقم واتساب",rememberMe:"ابقَ مسجلاً",nextStep:"التالي",backStep:"رجوع",createAccount:"إنشاء حساب",chooseRoom:"اختر الغرفة",chooseNat:"اختر الجنسية",collectFrom:"استلام التذاكر من",chooseMember:"يرجى اختيار أحد أفراد الفريق",handTo:"التسليم بواسطة",exportData:"تصدير البيانات",exportExcel:"تصدير إلى Excel",exportPdf:"تصدير إلى PDF",exportWhat:"ماذا تريد أن تصدّر؟",expBookings:"الحجوزات",expRequests:"طلبات الضيوف",expChat:"رسائل الدردشة",expUsers:"حسابات الفريق",expGuests:"قائمة الضيوف (الغرف والجنسية)",expTickets:"طلبات التذاكر",expFeedback:"آراء الضيوف",expAll:"كل شيء",daysHere:"أيام في التطبيق",joinedActs:"الأنشطة المنضمة",notifSound:"الصوت والتنبيهات",notifOn:"الإشعارات مفعّلة",notifNew:"إشعار جديد",notifMsg:"رسالة جديدة",notifBooking:"حجز جديد",notifTask:"تم إسناد نشاط جديد",notifRequest:"طلب ضيف جديد",enableNotif:"تفعيل الصوت والتنبيهات المنبثقة"}
};
const DICT = {
en:Object.assign({appSub:"Animation Team",guest:"Guest",staff:"Team",manager:"Manager",room:"Room number",name:"Your name",phone:"Mobile phone",user:"Username",pass:"Password",signin:"Sign in",welcome:"Welcome",today:"Today",highlight:"Highlight of the day",todayProgram:"Today's program",week:"Weekly program",myStay:"My stay",home:"Home",program:"Program",bookings:"Bookings",myBookings:"My bookings",favorites:"Favorites",book:"Book",booked:"Booked",full:"Full",waitlist:"Join waiting list",onWaitlist:"On waiting list",cancel:"Cancel booking",seatsLeft:"seats left",adults:"Adults",children:"Children",confirm:"Confirm booking",close:"Close",days:["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],daysShort:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],cats:{morning:"Morning",afternoon:"Afternoon",evening:"Evening",kids:"Kids Club",theme:"Theme day",mKids:"Kids Activities",mTeen:"Teenagers Activities",mAdult:"Activities",mEvents:"Events",eKidsStage:"Kids Stage",eLive:"Live Stage",eBefore:"Before Show",eShow:"Show Time",eAfter:"After Show",eParty:"Party"},guests:"guests",noBookings:"No bookings yet. Find something you love in today's program!",noFavs:"No favorites yet. Tap the heart on any activity.",schedule:"Schedule",team:"Team",guestsBooked:"Guests booked",noneToday:"Nothing scheduled here today.",dashboard:"Dashboard",manage:"Program",totalBookings:"Bookings this week",activities:"Activities",occupancy:"Avg. occupancy",waitlisted:"On waiting lists",addActivity:"Add activity",editActivity:"Edit activity",deleteActivity:"Delete",actName:"Activity name",desc:"Description",location:"Location",time:"Time",capacity:"Capacity",entertainer:"Entertainer(s)",imageUrl:"Photo URL (optional)",category:"Category",day:"Day",makeHighlight:"Highlight of the day",save:"Save",saved:"Saved",deleted:"Deleted",bookingOk:"Booking confirmed!",waitOk:"Added to waiting list",cancelled:"Cancelled",loginErr:"Please check your details and try again.",demoNote:"Preview mode with sample data — connect Supabase in the file to go live.",reviews:"Enjoying your holiday?",reviewsSub:"Share your experience — it means the world to our team.",followUs:"Follow the team",none:"—",arrival:"Arrival day",departure:"Departure day",otherUsers:"Team access",backToGuest:"← Guest login",usersTab:"Users",appTab:"App",appName:"App name",appSubtitle:"Subtitle",colorsHead:"Colors",primaryC:"Main color",accentC:"Accent color",linksHead:"Review links",socialHead:"Social media",addUser:"Add user",displayName:"Display name",roleLabel:"Role",teamAccounts:"Team accounts",guestStats:"Guest analytics",uniqueGuests:"Guest rooms",totalPeople:"People booked",language:"Language",userExists:"Username already exists",tickets:"Tickets",buyTicket:"Buy ticket",myTickets:"My tickets",price:"Price",qty:"Quantity",reserved:"Reserved",paid:"Paid",payNote:"Reserve in the app and pay at the entertainment desk or reception.",ticketOk:"Ticket reserved!",nationality:"Nationality",natStats:"Nationalities",addTicket:"Add ticket event",editTicket:"Edit ticket event",markPaid:"Mark paid",markReserved:"Mark reserved",styleHead:"Text style",buttonHead:"Button style",menuHead:"Menu titles",bgC:"Background",fontElegant:"Elegant",fontRoyal:"Royal",fontModern:"Modern",fontSoft:"Soft",btnRounded:"Rounded",btnPill:"Pill",btnSquare:"Square",ticketsNone:"No ticket events yet.",orders:"Orders",soldOut:"Sold out",opMorning:"Morning Operation",opAfternoon:"Afternoon Operation",opEvening:"Evening Operation",opDaytime:"Daytime Activities",opDayEvents:"Daytime Events",opSpecial:"Special Events",startTime:"Start time",endTime:"End time",operation:"Operation",chooseCat:"Choose a category",backToCats:"All categories",myActs:"My activities",myActsSub:"Activities assigned to you",chatManager:"Message the manager",teamChat:"Team chat",editMsg:"Edit message",deleteMsg:"Delete message",noStaffMsg:"No messages yet. Say hello to your manager!",shirtNumber:"Shirt number",myWorkDay:"My work day",dayPlan:"Day Plan",dayOff:"Day off",entranceDuty:"Entrance duty",dressCode:"Dress code",restaurantTheme:"Restaurant theme",dailyStandards:"Daily standards",eveningShowLbl:"Evening show",liveBandLbl:"Live band",makeupPractice:"Make-up practice",practiceToday:"Team practice today (45 min - Mon/Wed/Fri)",youAreOff:"You are OFF today - enjoy your day!",youHaveEntrance:"You have entrance duty today",teamPlanFull:"Full week plan",selectDay:"Select day",noNumber:"No shirt number set - ask your manager",djSchedule:"DJ schedule",std_breakfast:"Breakfast",std_mmeet:"Morning Meeting",std_start:"Starting Time — ready at positions",std_lunch:"Lunch",std_fmorning:"Finish Morning Operation",std_ameet:"Afternoon Meeting",std_fafternoon:"Finish Afternoon Operation",std_dinner:"Dinner",std_stage:"Stage Opens",std_emeet:"Evening Meeting",std_yoga:"Yoga / Sunset host goes home early",std_fevening:"Finish Evening Operation",n_sport:"Sport Uniform",n_mact:"Morning Activities 10:00–12:30",n_practice:"13:15 on Mon / Wed / Fri (45-min practice)",n_aact:"Afternoon Activities 15:00–17:30",n_yogahost:"17:15 for the Yoga / Sunset host",n_eshow:"Evening Show & Live Music from 20:00",n_special:"23:30 on special-event nights (e.g. Beach Party)",practiceInline:"13:15 today — 45-min practice",dj_wed:"No afternoon session — arrive 16:30 to run the Sunset Instrument Party (17:00–19:00), stay through close (23:00)",dj_thu:"Day off — Live Band covers the music (only 1 event: Foam Party)",dj_other:"Leave 16:30, return to open the Stage at 19:00",trainsToday:"trains individually today",busTimes:"Bus times",busSchedule:"Staff bus schedule",busToHotel:"Staff house → Hotel",busToHouse:"Hotel → Staff house",busEditHint:"One departure time per line",noBusTimes:"No bus times yet — add them in App settings.",busNextHint:"Next departure",addBus:"Add bus",editBus:"Edit bus",busDirection:"Direction",busTimeLbl:"Departure time",busNoteLbl:"Note (optional)",busNoteHint:"e.g. Only Fridays",settingsHub:"Settings",appSettingsItem:"App design & settings",aiItem:"AI Assistant",exportItem:"Export data (Excel/PDF)",busItem:"Bus schedule",settingsSub:"Everything to manage and customize your app",st_todo:"Not started",st_live:"In progress",st_done:"Finished",cancelBtn:"Cancel",confirmTitle:"Are you sure?",cannotUndo:"This action cannot be undone.",delActivityQ:"Delete this activity?",delUserQ:"Delete this account?",delReqQ:"Delete this request?",delBusQ:"Delete this bus?",delMsgQ:"Delete this message?",offlineMsg:"Offline — showing last saved information",backOnlineMsg:"Back online — syncing...",loadingMsg:"Loading...",errSave:"Could not save. Please try again.",errNet:"No connection. Please check your internet.",fieldRequired:"Please fill this in",invalidTime:"Use format 08:00",invalidNumber:"Enter a valid number",updateReady:"A new version is available — reopen the app to update",serverHead:"Secure server (optional)",serverHint:"Paste your Supabase Edge Function links here. With them, the AI key stays on the server instead of the phone.",errHttps:"Link must start with https://",noDataTitle:"Connected, but no data received",noDataMsg:"The app reached the database but got nothing back — usually the access rules. Run the repair script in Supabase, then reload.",noDataRooms:"No rooms found",eventsToday:"Events today",noEventsToday:"No special event today",practiceHead:"Team practice",practiceWindow:"12:30 – 13:15 (45 min)",makeupWindow:"45 min — individual",aiEndpointErr:"Server link not reachable — check it is deployed, or clear the box",aiEndpointFallback:"Server link not reachable — using the key on this device",themeHead:"App theme",themeHint:"Each theme has a light and a dark version — switch with the sun/moon in the menu.",themeCustom:"Custom colours",themeLight:"Light",themeDark:"Dark",quizTab:"Daily quiz",quizToday:"Today's question",quizAnswerPh:"Your answer...",quizSend:"Send answer",quizDone:"Answered — thank you!",quizNone:"No question today. Come back tomorrow!",quizMine:"Your answer",quizCenter:"Quiz Center",quizNew:"New question",quizFor:"For",quizForGuest:"Guests",quizForStaff:"Entertainers",quizQuestion:"Question",quizHint:"Hint (optional)",quizKey:"Correct answer (only you see this)",quizReplies:"Answers",quizNoReplies:"No answers yet",quizSaved:"Question published",quizAlready:"You already answered today",todayPlanExp:"Today's plan (for management)",navBack:"Back",navForward:"Forward",genderLbl:"Gender",genderM:"Male",genderF:"Female",genderNone:"Not set",teamSummary:"Team summary",totalEntertainers:"Total entertainers",byGender:"By gender",byNationality:"By nationality",teamOverview:"Team overview",typeNationality:"Type the nationality",natOtherHint:"Not in the list? Choose Other and type it.",editDuty:"Edit day off & entrance",dutyFor:"Duty for",selectDayOff:"Who is off",selectEntrance:"Entrance duty",resetDefault:"Reset to standard plan",customDay:"Changed",standardDay:"Standard plan",workingToday:"Working",dayOffToday:"On day off",totalTeam:"Total team",dutySaved:"Duty updated",noOneOff:"Nobody off",monthAtt:"Monthly attendance",attP:"Present",attO:"Day off",attA:"Absent",attLegend:"P = present · O = day off · A = absent",attTapHint:"Tap a day to change it. Grey means it comes from the plan.",attAuto:"From plan",attTotalsP:"Present days",attTotalsO:"Days off",attTotalsA:"Absent days",attExport:"Monthly attendance sheet",prevMonth:"Previous month",nextMonth:"Next month",attSaved:"Attendance updated",workDays:"Work days",monthTotals:"Month totals",teamWorkDays:"Team work days",avgPerPerson:"Average per person",hotelInfoTab:"Hotel info",hotelInfoHint:"Opening times, WiFi and the answers guests ask for most",addInfo:"Add information",infoTitle:"Title",infoValue:"Details",noInfo:"No information added yet",galleryTab:"Photos",galleryHint:"Pictures from our shows and activities",addPhoto:"Add photo",noPhotos:"No photos yet — check back after tonight's show!",photoCaption:"Caption (optional)",attentionHead:"Needs your attention",allGood:"All good — nothing needs you right now",attEmptyAct:"activities today with no bookings",attWaitReq:"guest requests waiting",attLowRate:"low ratings this week",attStaffReq:"team requests waiting",attNoShow:"team members not marked today",trendsHead:"Trends",last7:"Last 7 days",topActs:"Most popular",lowActs:"Least popular",bookingTrend:"Bookings per day",myAttendance:"My attendance",myFeedback:"My feedback",noMyFeedback:"No feedback yet",askManager:"Ask the manager",myRequestsTeam:"My requests",newTeamReq:"New request",reqDayOff:"Day off change",reqProblem:"Report a problem",reqCannot:"I can't do an activity",reqOther:"Something else",reqDetail:"Tell your manager",reqDateOpt:"Which day (optional)",teamRequests:"Team requests",noTeamReqs:"No requests from the team",reqApprove:"Approve",reqDecline:"Decline",reqReply:"Reply (optional)",statusOk:"Approved",statusNo:"Declined",reqSent:"Sent to your manager",thankYou:"Thank you!",shareExp:"Would you like to share your experience?",reviewLater:"Maybe later",howWasIt:"How was it?",qrTab:"QR code",qrHint:"Print this and put it at the pool, the bar and reception",qrDownload:"Open printable page",stayEnded:"Your stay has ended — thank you for visiting!",accountOff:"This account is not active. Please ask your manager.",activeAcc:"Account active",inactiveAcc:"Inactive",deactivate:"Deactivate",activate:"Activate",resetPass:"Reset password",newPassIs:"New password",passCopied:"Give this to the person — it replaces the old one",tooManyTries:"Too many attempts. Please wait a moment.",logoLbl:"Logo",logoHint:"Shown on the login screen",hotelNameLbl:"Hotel name",timezoneLbl:"Hotel timezone",timezoneHint:"Times and alarms follow the hotel clock, not the guest phone",currencyLbl:"Currency",contactLbl:"Contact",fontSizeLbl:"Text size",fsSmall:"Small",fsNormal:"Normal",fsLarge:"Large",fsXl:"Extra large",autoDarkLbl:"Follow phone dark mode",featuresLbl:"Features",featQuiz:"Daily quiz",featTickets:"Tickets",featGallery:"Photos",featBus:"Bus schedule",featInfo:"Hotel info",previewTheme:"Preview",applyTheme:"Use this theme",previewOn:"Preview — not saved yet",secIdentity:"Hotel identity",secLook:"Look & feel",secAccess:"Access",upToToday:"up to today",countedDays:"Days counted",workingEntToday:"Entertainers working today",weatherTab:"Weather",weatherToday:"Today",weatherWeek:"This week",weatherFail:"Weather unavailable right now",feelsLike:"Feels like",windLbl:"Wind",latLbl:"Latitude",lonLbl:"Longitude",weatherLoc:"Weather location",weatherLocHint:"Coordinates of the hotel (Hurghada by default)",wSun:"Sunny",wPartly:"Partly cloudy",wCloud:"Cloudy",wFog:"Fog",wDrizzle:"Drizzle",wRain:"Rain",wShower:"Showers",wSnow:"Snow",wStorm:"Thunderstorm",wWind:"Windy",setBrand:"Brand & identity",setBrandSub:"Logo, hotel name, contact",setTheme:"Theme & colours",setThemeSub:"Colours, fonts, text size, dark mode",setMenus:"Menus & pages",setMenusSub:"Rename, reorder, add your own pages",setNotif:"Notifications",setNotifSub:"Sound and alerts",setLinksT:"Links & reviews",setLinksSub:"Social media and review sites",setFeatures:"Features",setFeaturesSub:"Turn parts of the app on or off",setLocation:"Location & time",setLocationSub:"Timezone and weather location",setAdvanced:"Advanced",setAdvancedSub:"Secure server, AI, QR code,",setData:"Data",setDataSub:"Export everything to Excel or PDF",addTime:"Add another time",timesLbl:"Opening times",guestCrm:"Guest profiles",crmSearch:"Search room, name or nationality",guest360:"Guest profile",stayLen:"Stay",nights:"nights",attendedActs:"Activities attended",favActs:"Favourite activities",msgCount:"Messages",quizPart:"Quiz answers",appUsage:"Days using the app",noGuests:"No guests yet",openProfile:"Open profile",taskPriority:"Priority",prLow:"Low",prNormal:"Normal",prHigh:"High",prUrgent:"Urgent",taskLoc:"Location",taskDeadline:"Deadline",stNew:"New",stAccepted:"Accepted",stProgress:"In progress",stCompleted:"Completed",stVerified:"Verified",overdue:"Overdue",acceptTask:"Accept",startTask:"Start",completeTask:"Complete",verifyTask:"Verify",taskProof:"Proof photo",taskComments:"Comments",addComment:"Add a comment",taskHistory:"History",createdBy:"Created by",noTasks:"No tasks",employeeProfile:"Employee profile",employeeId:"Employee ID",positionLbl2:"Position",phoneLbl2:"Phone",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Hire date",suspend:"Suspend",assignedActs:"Assigned activities",performance:"Performance",guestRatings:"Guest ratings",pointsLbl:"Points",rankLbl:"Rank",tasksDone:"Tasks completed",onTime:"On time",viewProfile:"View profile",photosLbl:"Photos",addPhotos:"Add photos",removePhoto:"Remove photo",cropLogo:"Crop logo",cropHint:"Drag to move, pinch or slider to zoom",useCrop:"Use this",removeLogo:"Remove logo",photoOf:"of",requestChange:"Request a change",changeRequest:"Change request",whatToChange:"What should be changed?",reqSentMgr:"Sent to the manager",profileReadOnly:"Only the manager can change this",pageBuilder:"Page designer",pbHint:"Build a page from blocks — no code",pbNewPage:"New page",pbEditPage:"Edit page",pbBlocks:"Blocks",pbAddBlock:"Add block",blkHeading:"Heading",blkText:"Text",blkImage:"Image",blkGallery:"Gallery",blkButton:"Button",blkDivider:"Divider",blkSpacer:"Space",blkCard:"Card",blkList:"List",blkVideo:"Video",blkMap:"Map",pbContent:"Content",pbStyle:"Style",fontSizeB:"Font size",fontFamilyB:"Font",alignLbl:"Align",alignLeft:"Left",alignCenter:"Centre",alignRight:"Right",colorLbl:"Colour",bgLbl:"Background",btnShape:"Button shape",shapeRound:"Rounded",shapePill:"Pill",shapeSquare:"Square",btnSize:"Button size",sizeS:"Small",sizeM:"Medium",sizeL:"Large",btnLink:"Link (optional)",boldLbl:"Bold",moveBlockUp:"Move up",moveBlockDown:"Move down",dupBlock:"Duplicate",delBlock:"Delete block",pbPreview:"Preview",pbEmpty:"This page is empty — add your first block",pbSaved:"Page saved",listItems:"One item per line",videoUrl:"Video link (YouTube)",mapAddr:"Address or place",pbWho:"Who sees it",pbIcon:"Icon",pbTitle:"Page title",persons:"Number of people",personsShort:"people",attN:"Not employed yet",notHiredYet:"Before hire date",mapTab:"Live map",shareLoc:"Share my location",shareLocHint:"Only while this is on. Switch it off any time and your location is deleted.",locDenied:"Location permission was refused on this phone",noOneSharing:"Nobody is sharing their location right now",lastSeen:"Updated",mapHint:"Only people who switched sharing on appear here",minsAgo:"min ago",justNow:"just now",locTeam:"Team",locGuests:"Guests",assignCenter:"Assignments",asgActs:"Activities",asgWho:"Who can do what",asgOpen:"Nobody yet",asgNobody:"Nobody yet",allAssigned:"Everything is assigned",autoAssign:"Assign automatically",autoAssignHint:"Uses the day plan, day off, absences and what each person can do.",autoReviewHint:"Check the suggestions, change anyone you want, then apply.",applyAssign:"Apply",asgApplied:"assigned",asgSkip:"Leave empty",asgNoSkill:"Nobody available can do this",asgAllBusy:"Everyone able is already busy",nobodyWorking:"Nobody is working this day",asgWhoHint:"Tap a person to set what they can and cannot do",noSkillsSet:"Nothing set — can be assigned anything",skillEditHint:"Tap once = can do. Tap again = cannot do. Tap a third time to clear.",skCan:"can",skCant:"can't",skAny:"—",sk_sport:"Sport",sk_water:"Water",sk_dance:"Dance",sk_show:"Show",sk_kids:"Kids",sk_music:"Music",sk_dj:"DJ",sk_games:"Games",sk_fitness:"Fitness",sk_host:"Hosting",sk_craft:"Crafts",sk_beach:"Beach",needsSkill:"Needs skill",noActsYet:"Add activities to your programme first — then you can tick what each person can and cannot do.",canRunIt:"can run it",editDayOff:"Edit day off",noOneEntrance:"Nobody set",teamChatTab:"Team messages",guestChatTab:"Guest messages",attV:"Vacation",attLeft:"Left the hotel",markLeft:"Left the hotel",markLeftHint:"Their attendance is kept. Their number is freed for a new person.",leftDate:"Last working day",undoLeft:"They came back",leftTag:"Left",startPage:"Page the app opens on",startPageHint:"When you open the app you land here.",todayWord:"Today",yesterdayWord:"Yesterday",practiceDays:"Mon / Wed / Fri",arrangeSections:"Arrange this page",arrangeHint:"Move the parts of this page up or down. Saved for everyone.",dayInfoSec:"Day information",wholeDay:"The whole day",morningPart:"Morning",afternoonPart:"Afternoon",eveningPart:"Evening",itemsWord:"items",editBooking:"Edit booking",openGuest:"Open guest profile",bookedAt:"Booked",booked:"Booked",waitlist:"Waiting list",status:"Status",standardsHead:"Daily standards",noGuestAccount:"No guest account for this room",finishedChip:"Finished",setVacation:"Set holiday",setVacationHint:"Pick the person and the first and last day.",clearVacation:"Remove holiday",person:"Person",fromDate:"From",toDate:"To",daysWord:"days",checkDates:"Check the dates",dayWord:"Day",nightsWord:"nights",nightsLeft:"nights left",stayDayOf:"Day {n} of {t}",stayWelcome:"Welcome — your holiday starts today",stayLastDay:"Last day — we hope you had a lovely time",plannedAhead:"Planned ahead",addMember:"Add member",addAttOnly:"Attendance only",addAttOnlyHint:"Just a name and a number (11–50) for the attendance sheet. No login, no activities, not counted in the team.",attNumber:"Number (11–50)",attNumRange:"The number must be between 11 and 50",numberTaken:"That number is already used",nameNeeded:"Please write a name",attOnlyTag:"· attendance only",whichMonth:"Which month",whichDay:"Which day",selectMsgs:"Select messages",clearChat:"Clear chat",selectedWord:"selected",selectAll:"Select all",selectNone:"Select none",deleteMsgsQ:"Delete {n} messages?",clearChatQ:"Clear the whole chat?",clearChatHint:"All {n} messages will be deleted for everyone.",cannotUndo:"This cannot be undone.",deleteReqQ:"Delete this request?",allDays:"All days",whichTime:"Which time",allDayLong:"All day",filterNote:"Exporting only:",noFilterNote:"Exporting everything.",officialAtt:"{hotel} — Official Monthly Attendance",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"First day",lastDayOpt:"Last day (optional)",attDatesHint:"Days before the first day and after the last day are not counted.",delete:"Delete",deleteQ:"Delete this person?",attDeleteHint:"Their attendance record is deleted too. Leave the last day set instead if you want to keep it.",eventsCrewTag:"DJ — all events & shows",eventsCrewHint:"The DJ is automatically assigned to every event, party and show. The DJ is not part of the normal activity rota, so there is nothing to tick here.",wasBooked:"You were booked",bookNowLive:"Running — join",removeBooking:"Remove booking",removeBookingQ:"Remove this booking?",removeBookingHint:"The guest loses their place. This cannot be undone.",skillEditHint2:"Tick the activities from your programme. Tap once = can do. Tap again = cannot do. Third tap clears it.",autoAssign:"Auto-assign activities",autoHint:"One morning and one afternoon activity each — fairly shared. Events are for the whole team, and you and the DJ are never assigned.",autoDay:"This day",autoWeek:"Whole week",onlyEmptyLbl:"Only activities with nobody assigned",replaceAllLbl:"Replace everything",autoPreview:"Proposal",autoApply:"Apply this plan",autoNothing:"Nothing to assign — check the day off and the programme",autoDone:"Activities assigned",morningSlot:"Morning",afternoonSlot:"Afternoon",perPerson:"Per person",noOneAvailable:"Nobody available on this day",eventsAllTeam:"Events — whole team",changeWho:"Change",noneAssigned:"— nobody —",balanceLbl:"Balance",evenSpread:"Evenly shared",spreadOff:"Difference of",editHint:"Tap any name to change it before applying",recalc:"Balance again",fairest:"Fairest",activityCount:"activities",zoomLbl:"Zoom",totalAllTeam:"Total team (incl. manager)",infoTime:"Opening time",infoPlace:"Location",translateBtn:"Translate",translating:"Translating...",translateFail:"Could not translate",showOriginal:"Show original",builderTab:"Menu builder",builderHint:"Rename, reorder, hide or add items — for each role, without code",forRole:"For",roleGuest:"Guests",roleStaff:"Entertainers",roleManager:"Manager",moveUp:"Move up",moveDown:"Move down",hideItem:"Hidden",showItem:"Shown",renameItem:"Name",addLink:"Add your own page",linkTitle:"Title",linkUrl:"Web address",linkText:"Text to show",linkKind:"Type",kindLink:"Web link",kindPage:"Text page",resetMenu:"Reset to default",builderSaved:"Menu updated",customPage:"My page",openLink:"Open",translatedTag:"Translated",infoPhoto:"Photo",totalRow:"TOTAL",months:["January","February","March","April","May","June","July","August","September","October","November","December"],statusLegend:"Status",almSoonG:"Starts in 5 min",almStartG:"Starting now",almDoneG:"Finished",almSoonS:"Your activity starts in 5 min — be there now",almStartS:"Your activity is starting now",almDoneS:"Finished — please collect feedback with room number",almSoonTeam:"Starts in 5 min",almStartTeam:"Starting now",almDoneTeam:"Finished",secProgram:"Programme",secBookings:"My Bookings",secConnect:"Social & Team",secManage:"Management",secTeamwork:"My Work",secGuests:"Guests",secSettings:"Settings",uploadErr:"Upload failed — check Storage setup",photo:"Photo",uploadPhoto:"Tap to upload photo",changePhoto:"Change photo"},EXTRA.en),
de:Object.assign({appSub:"Animationsteam",guest:"Gast",staff:"Team",manager:"Manager",room:"Zimmernummer",name:"Dein Name",phone:"Handynummer",user:"Benutzername",pass:"Passwort",signin:"Anmelden",welcome:"Willkommen",today:"Heute",highlight:"Highlight des Tages",todayProgram:"Heutiges Programm",week:"Wochenprogramm",myStay:"Mein Urlaub",home:"Start",program:"Programm",bookings:"Buchungen",myBookings:"Meine Buchungen",favorites:"Favoriten",book:"Buchen",booked:"Gebucht",full:"Ausgebucht",waitlist:"Auf Warteliste",onWaitlist:"Auf der Warteliste",cancel:"Buchung stornieren",seatsLeft:"Plätze frei",adults:"Erwachsene",children:"Kinder",confirm:"Buchung bestätigen",close:"Schließen",days:["Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"],daysShort:["Mo","Di","Mi","Do","Fr","Sa","So"],cats:{morning:"Vormittag",afternoon:"Nachmittag",evening:"Abend",kids:"Kids Club",theme:"Mottotag",mKids:"Kinder-Aktivitäten",mTeen:"Teenager-Aktivitäten",mAdult:"Aktivitäten",mEvents:"Events",eKidsStage:"Kinder-Bühne",eLive:"Live-Bühne",eBefore:"Vor der Show",eShow:"Show-Time",eAfter:"Nach der Show",eParty:"Party"},guests:"Gäste",noBookings:"Noch keine Buchungen. Stöbere im heutigen Programm!",noFavs:"Noch keine Favoriten. Tippe auf das Herz bei einer Aktivität.",schedule:"Zeitplan",team:"Team",guestsBooked:"Gebuchte Gäste",noneToday:"Heute ist hier nichts geplant.",dashboard:"Übersicht",manage:"Programm",totalBookings:"Buchungen diese Woche",activities:"Aktivitäten",occupancy:"Ø Auslastung",waitlisted:"Auf Wartelisten",addActivity:"Aktivität hinzufügen",editActivity:"Aktivität bearbeiten",deleteActivity:"Löschen",actName:"Name der Aktivität",desc:"Beschreibung",location:"Ort",time:"Uhrzeit",capacity:"Kapazität",entertainer:"Animateur(e)",imageUrl:"Foto-URL (optional)",category:"Kategorie",day:"Tag",makeHighlight:"Highlight des Tages",save:"Speichern",saved:"Gespeichert",deleted:"Gelöscht",bookingOk:"Buchung bestätigt!",waitOk:"Zur Warteliste hinzugefügt",cancelled:"Storniert",loginErr:"Bitte prüfe deine Angaben und versuche es erneut.",demoNote:"Vorschau mit Beispieldaten — verbinde Supabase in der Datei, um live zu gehen.",reviews:"Gefällt dir dein Urlaub?",reviewsSub:"Teile deine Erfahrung — es bedeutet unserem Team die Welt.",followUs:"Folge dem Team",none:"—",arrival:"Anreisetag",departure:"Abreisetag",otherUsers:"Team-Zugang",backToGuest:"← Gast-Anmeldung",usersTab:"Nutzer",appTab:"App",appName:"App-Name",appSubtitle:"Untertitel",colorsHead:"Farben",primaryC:"Hauptfarbe",accentC:"Akzentfarbe",linksHead:"Bewertungs-Links",socialHead:"Social Media",addUser:"Nutzer hinzufügen",displayName:"Anzeigename",roleLabel:"Rolle",teamAccounts:"Team-Konten",guestStats:"Gäste-Statistik",uniqueGuests:"Gästezimmer",totalPeople:"Gebuchte Personen",language:"Sprache",userExists:"Benutzername existiert bereits",tickets:"Tickets",buyTicket:"Ticket kaufen",myTickets:"Meine Tickets",price:"Preis",qty:"Anzahl",reserved:"Reserviert",paid:"Bezahlt",payNote:"In der App reservieren und am Animationsstand oder an der Rezeption bezahlen.",ticketOk:"Ticket reserviert!",nationality:"Nationalität",natStats:"Nationalitäten",addTicket:"Ticket-Event hinzufügen",editTicket:"Ticket-Event bearbeiten",markPaid:"Als bezahlt markieren",markReserved:"Als reserviert markieren",styleHead:"Schriftstil",buttonHead:"Button-Stil",menuHead:"Menü-Titel",bgC:"Hintergrund",fontElegant:"Elegant",fontRoyal:"Royal",fontModern:"Modern",fontSoft:"Sanft",btnRounded:"Abgerundet",btnPill:"Pill",btnSquare:"Eckig",ticketsNone:"Noch keine Ticket-Events.",orders:"Bestellungen",soldOut:"Ausverkauft",opMorning:"Vormittags-Programm",opAfternoon:"Nachmittags-Programm",opEvening:"Abend-Programm",opDaytime:"Tagesaktivitäten",opDayEvents:"Tages-Events",opSpecial:"Spezial-Events",startTime:"Startzeit",endTime:"Endzeit",operation:"Programm",chooseCat:"Kategorie wählen",backToCats:"Alle Kategorien",myActs:"Meine Aktivitäten",myActsSub:"Dir zugewiesene Aktivitäten",chatManager:"Manager schreiben",teamChat:"Team-Chat",editMsg:"Nachricht bearbeiten",deleteMsg:"Nachricht löschen",noStaffMsg:"Noch keine Nachrichten. Grüße deinen Manager!",shirtNumber:"Trikotnummer",myWorkDay:"Mein Arbeitstag",dayPlan:"Tagesplan",dayOff:"Freier Tag",entranceDuty:"Eingangsdienst",dressCode:"Kleiderordnung",restaurantTheme:"Restaurant-Thema",dailyStandards:"Tagesablauf",eveningShowLbl:"Abendshow",liveBandLbl:"Live-Band",makeupPractice:"Nachhol-Training",practiceToday:"Team-Training heute (45 Min - Mo/Mi/Fr)",youAreOff:"Du hast heute FREI - genieße deinen Tag!",youHaveEntrance:"Du hast heute Eingangsdienst",teamPlanFull:"Ganzer Wochenplan",selectDay:"Tag wählen",noNumber:"Keine Trikotnummer - frag deinen Manager",djSchedule:"DJ-Plan",std_breakfast:"Frühstück",std_mmeet:"Morgen-Meeting",std_start:"Startzeit — bereit an den Positionen",std_lunch:"Mittagessen",std_fmorning:"Ende Vormittags-Betrieb",std_ameet:"Nachmittags-Meeting",std_fafternoon:"Ende Nachmittags-Betrieb",std_dinner:"Abendessen",std_stage:"Bühne öffnet",std_emeet:"Abend-Meeting",std_yoga:"Yoga-/Sunset-Host geht früher",std_fevening:"Ende Abend-Betrieb",n_sport:"Sport-Uniform",n_mact:"Vormittags-Aktivitäten 10:00–12:30",n_practice:"13:15 an Mo / Mi / Fr (45-Min-Training)",n_aact:"Nachmittags-Aktivitäten 15:00–17:00",n_yogahost:"17:15 für den Yoga-/Sunset-Host",n_eshow:"Abendshow & Live-Musik ab 20:00",n_special:"23:30 an Event-Abenden (z. B. Beach Party)",practiceInline:"13:15 heute — 45-Min-Training",dj_wed:"Keine Nachmittags-Schicht — 16:30 da für die Sunset Instrument Party (17:00–19:00), bleibt bis zum Schluss (23:00)",dj_thu:"Freier Tag — Live-Band übernimmt die Musik (nur 1 Event: Foam Party)",dj_other:"16:30 gehen, um 19:00 zurück, um die Bühne zu öffnen",trainsToday:"trainiert heute individuell",busTimes:"Buszeiten",busSchedule:"Team-Busplan",busToHotel:"Team-Haus → Hotel",busToHouse:"Hotel → Team-Haus",busEditHint:"Eine Abfahrtszeit pro Zeile",noBusTimes:"Noch keine Buszeiten — füge sie in den App-Einstellungen hinzu.",busNextHint:"Nächste Abfahrt",addBus:"Bus hinzufügen",editBus:"Bus bearbeiten",busDirection:"Richtung",busTimeLbl:"Abfahrtszeit",busNoteLbl:"Notiz (optional)",busNoteHint:"z. B. nur freitags",settingsHub:"Einstellungen",appSettingsItem:"App-Design & Einstellungen",aiItem:"KI-Assistent",exportItem:"Daten exportieren (Excel/PDF)",busItem:"Busplan",settingsSub:"Alles zum Verwalten und Anpassen deiner App",st_todo:"Nicht gestartet",st_live:"Läuft",st_done:"Beendet",cancelBtn:"Abbrechen",confirmTitle:"Bist du sicher?",cannotUndo:"Diese Aktion kann nicht rückgängig gemacht werden.",delActivityQ:"Diese Aktivität löschen?",delUserQ:"Dieses Konto löschen?",delReqQ:"Diesen Wunsch löschen?",delBusQ:"Diesen Bus löschen?",delMsgQ:"Diese Nachricht löschen?",offlineMsg:"Offline — zeige zuletzt gespeicherte Daten",backOnlineMsg:"Wieder online — synchronisiere...",loadingMsg:"Lädt...",errSave:"Konnte nicht speichern. Bitte erneut versuchen.",errNet:"Keine Verbindung. Bitte Internet prüfen.",fieldRequired:"Bitte ausfüllen",invalidTime:"Format 08:00 verwenden",invalidNumber:"Gültige Zahl eingeben",updateReady:"Neue Version verfügbar — App neu öffnen zum Aktualisieren",serverHead:"Sicherer Server (optional)",serverHint:"Füge hier deine Supabase-Edge-Function-Links ein. Damit bleibt der KI-Schlüssel auf dem Server statt auf dem Handy.",errHttps:"Link muss mit https:// beginnen",noDataTitle:"Verbunden, aber keine Daten",noDataMsg:"Die App erreicht die Datenbank, bekommt aber nichts zurück — meist die Zugriffsregeln. Führe das Reparatur-Skript in Supabase aus und lade neu.",noDataRooms:"Keine Zimmer gefunden",eventsToday:"Events heute",noEventsToday:"Heute kein Spezial-Event",practiceHead:"Team-Training",practiceWindow:"12:30 – 13:15 (45 Min)",makeupWindow:"45 Min — individuell",aiEndpointErr:"Server-Link nicht erreichbar — prüfe die Bereitstellung oder leere das Feld",aiEndpointFallback:"Server-Link nicht erreichbar — nutze den Schlüssel auf diesem Gerät",themeHead:"App-Design",themeHint:"Jedes Design hat eine helle und eine dunkle Variante — umschalten mit Sonne/Mond im Menü.",themeCustom:"Eigene Farben",themeLight:"Hell",themeDark:"Dunkel",quizTab:"Tagesquiz",quizToday:"Frage des Tages",quizAnswerPh:"Deine Antwort...",quizSend:"Antwort senden",quizDone:"Beantwortet — danke!",quizNone:"Heute keine Frage. Komm morgen wieder!",quizMine:"Deine Antwort",quizCenter:"Quiz-Center",quizNew:"Neue Frage",quizFor:"Für",quizForGuest:"Gäste",quizForStaff:"Entertainer",quizQuestion:"Frage",quizHint:"Hinweis (optional)",quizKey:"Richtige Antwort (nur du siehst das)",quizReplies:"Antworten",quizNoReplies:"Noch keine Antworten",quizSaved:"Frage veröffentlicht",quizAlready:"Du hast heute schon geantwortet",todayPlanExp:"Tagesplan heute (für die Direktion)",navBack:"Zurück",navForward:"Vorwärts",genderLbl:"Geschlecht",genderM:"Männlich",genderF:"Weiblich",genderNone:"Nicht angegeben",teamSummary:"Team-Übersicht",totalEntertainers:"Entertainer gesamt",byGender:"Nach Geschlecht",byNationality:"Nach Nationalität",teamOverview:"Team-Übersicht",typeNationality:"Nationalität eingeben",natOtherHint:"Nicht in der Liste? Wähle Andere und tippe sie ein.",editDuty:"Freien Tag & Eingang ändern",dutyFor:"Dienst für",selectDayOff:"Wer hat frei",selectEntrance:"Eingangsdienst",resetDefault:"Auf Standardplan zurücksetzen",customDay:"Geändert",standardDay:"Standardplan",workingToday:"Im Dienst",dayOffToday:"Frei",totalTeam:"Team gesamt",dutySaved:"Dienst aktualisiert",noOneOff:"Niemand frei",monthAtt:"Monatliche Anwesenheit",attP:"Anwesend",attO:"Frei",attA:"Abwesend",attLegend:"P = anwesend · O = frei · A = abwesend",attTapHint:"Tippe auf einen Tag zum Ändern. Grau kommt aus dem Plan.",attAuto:"Aus dem Plan",attTotalsP:"Arbeitstage",attTotalsO:"Freie Tage",attTotalsA:"Fehltage",attExport:"Monats-Anwesenheitsliste",prevMonth:"Voriger Monat",nextMonth:"Nächster Monat",attSaved:"Anwesenheit aktualisiert",workDays:"Arbeitstage",monthTotals:"Monatssummen",teamWorkDays:"Arbeitstage Team",avgPerPerson:"Durchschnitt pro Person",hotelInfoTab:"Hotel-Infos",hotelInfoHint:"Öffnungszeiten, WLAN und die häufigsten Gästefragen",addInfo:"Information hinzufügen",infoTitle:"Titel",infoValue:"Details",noInfo:"Noch keine Informationen",galleryTab:"Fotos",galleryHint:"Bilder von unseren Shows und Aktivitäten",addPhoto:"Foto hinzufügen",noPhotos:"Noch keine Fotos — schau nach der Show heute Abend wieder rein!",photoCaption:"Bildtext (optional)",attentionHead:"Braucht deine Aufmerksamkeit",allGood:"Alles gut — nichts zu tun",attEmptyAct:"Aktivitäten heute ohne Buchung",attWaitReq:"Gästewünsche warten",attLowRate:"schlechte Bewertungen diese Woche",attStaffReq:"Team-Anfragen warten",attNoShow:"Teammitglieder heute nicht erfasst",trendsHead:"Trends",last7:"Letzte 7 Tage",topActs:"Am beliebtesten",lowActs:"Am wenigsten beliebt",bookingTrend:"Buchungen pro Tag",myAttendance:"Meine Anwesenheit",myFeedback:"Mein Feedback",noMyFeedback:"Noch kein Feedback",askManager:"Manager fragen",myRequestsTeam:"Meine Anfragen",newTeamReq:"Neue Anfrage",reqDayOff:"Freien Tag ändern",reqProblem:"Problem melden",reqCannot:"Ich kann eine Aktivität nicht",reqOther:"Etwas anderes",reqDetail:"Schreib deinem Manager",reqDateOpt:"Welcher Tag (optional)",teamRequests:"Team-Anfragen",noTeamReqs:"Keine Anfragen vom Team",reqApprove:"Genehmigen",reqDecline:"Ablehnen",reqReply:"Antwort (optional)",statusOk:"Genehmigt",statusNo:"Abgelehnt",reqSent:"An deinen Manager gesendet",thankYou:"Danke!",shareExp:"Möchtest du deine Erfahrung teilen?",reviewLater:"Vielleicht später",howWasIt:"Wie war es?",qrTab:"QR-Code",qrHint:"Drucke das aus und stell es an Pool, Bar und Rezeption",qrDownload:"Druckseite öffnen",stayEnded:"Dein Aufenthalt ist beendet — danke für deinen Besuch!",accountOff:"Dieses Konto ist nicht aktiv. Bitte frag deinen Manager.",activeAcc:"Konto aktiv",inactiveAcc:"Inaktiv",deactivate:"Deaktivieren",activate:"Aktivieren",resetPass:"Passwort zurücksetzen",newPassIs:"Neues Passwort",passCopied:"Gib das der Person — es ersetzt das alte",tooManyTries:"Zu viele Versuche. Bitte kurz warten.",logoLbl:"Logo",logoHint:"Wird auf dem Login-Bildschirm gezeigt",hotelNameLbl:"Hotelname",timezoneLbl:"Hotel-Zeitzone",timezoneHint:"Zeiten und Alarme folgen der Hotel-Uhr, nicht dem Gäste-Handy",currencyLbl:"Währung",contactLbl:"Kontakt",fontSizeLbl:"Textgröße",fsSmall:"Klein",fsNormal:"Normal",fsLarge:"Groß",fsXl:"Sehr groß",autoDarkLbl:"Dunkelmodus vom Handy übernehmen",featuresLbl:"Funktionen",featQuiz:"Tagesquiz",featTickets:"Tickets",featGallery:"Fotos",featBus:"Busplan",featInfo:"Hotel-Infos",previewTheme:"Vorschau",applyTheme:"Dieses Design verwenden",previewOn:"Vorschau — noch nicht gespeichert",secIdentity:"Hotel-Identität",secLook:"Aussehen",secAccess:"Zugang",upToToday:"bis heute",countedDays:"Gezählte Tage",workingEntToday:"Entertainer heute im Dienst",weatherTab:"Wetter",weatherToday:"Heute",weatherWeek:"Diese Woche",weatherFail:"Wetter gerade nicht verfügbar",feelsLike:"Gefühlt",windLbl:"Wind",latLbl:"Breitengrad",lonLbl:"Längengrad",weatherLoc:"Wetter-Standort",weatherLocHint:"Koordinaten des Hotels (Standard: Hurghada)",wSun:"Sonnig",wPartly:"Teils bewölkt",wCloud:"Bewölkt",wFog:"Nebel",wDrizzle:"Nieselregen",wRain:"Regen",wShower:"Schauer",wSnow:"Schnee",wStorm:"Gewitter",wWind:"Windig",setBrand:"Marke & Identität",setBrandSub:"Logo, Hotelname, Kontakt",setTheme:"Design & Farben",setThemeSub:"Farben, Schriften, Textgröße, Dunkelmodus",setMenus:"Menüs & Seiten",setMenusSub:"Umbenennen, sortieren, eigene Seiten",setNotif:"Benachrichtigungen",setNotifSub:"Ton und Hinweise",setLinksT:"Links & Bewertungen",setLinksSub:"Social Media und Bewertungsseiten",setFeatures:"Funktionen",setFeaturesSub:"Teile der App ein- oder ausschalten",setLocation:"Ort & Zeit",setLocationSub:"Zeitzone und Wetter-Standort",setAdvanced:"Erweitert",setAdvancedSub:"Sicherer Server, KI, QR-Code",setData:"Daten",setDataSub:"Alles nach Excel oder PDF exportieren",addTime:"Weitere Zeit hinzufügen",timesLbl:"Öffnungszeiten",guestCrm:"Gästeprofile",crmSearch:"Zimmer, Name oder Nationalität suchen",guest360:"Gästeprofil",stayLen:"Aufenthalt",nights:"Nächte",attendedActs:"Besuchte Aktivitäten",favActs:"Lieblingsaktivitäten",msgCount:"Nachrichten",quizPart:"Quiz-Antworten",appUsage:"Tage in der App",noGuests:"Noch keine Gäste",openProfile:"Profil öffnen",taskPriority:"Priorität",prLow:"Niedrig",prNormal:"Normal",prHigh:"Hoch",prUrgent:"Dringend",taskLoc:"Ort",taskDeadline:"Frist",stNew:"Neu",stAccepted:"Angenommen",stProgress:"In Arbeit",stCompleted:"Erledigt",stVerified:"Geprüft",overdue:"Überfällig",acceptTask:"Annehmen",startTask:"Starten",completeTask:"Erledigen",verifyTask:"Prüfen",taskProof:"Nachweis-Foto",taskComments:"Kommentare",addComment:"Kommentar hinzufügen",taskHistory:"Verlauf",createdBy:"Erstellt von",noTasks:"Keine Aufgaben",employeeProfile:"Mitarbeiterprofil",employeeId:"Mitarbeiter-ID",positionLbl2:"Position",phoneLbl2:"Telefon",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Eintrittsdatum",suspend:"Sperren",assignedActs:"Zugewiesene Aktivitäten",performance:"Leistung",guestRatings:"Gästebewertungen",pointsLbl:"Punkte",rankLbl:"Rang",tasksDone:"Erledigte Aufgaben",onTime:"Pünktlich",viewProfile:"Profil ansehen",photosLbl:"Fotos",addPhotos:"Fotos hinzufügen",removePhoto:"Foto entfernen",cropLogo:"Logo zuschneiden",cropHint:"Ziehen zum Bewegen, Regler zum Zoomen",useCrop:"Übernehmen",removeLogo:"Logo entfernen",photoOf:"von",requestChange:"Änderung anfragen",changeRequest:"Änderungswunsch",whatToChange:"Was soll geändert werden?",reqSentMgr:"An den Manager gesendet",profileReadOnly:"Nur der Manager kann das ändern",pageBuilder:"Seiten-Designer",pbHint:"Baue eine Seite aus Blöcken — ohne Code",pbNewPage:"Neue Seite",pbEditPage:"Seite bearbeiten",pbBlocks:"Blöcke",pbAddBlock:"Block hinzufügen",blkHeading:"Überschrift",blkText:"Text",blkImage:"Bild",blkGallery:"Galerie",blkButton:"Button",blkDivider:"Trennlinie",blkSpacer:"Abstand",blkCard:"Karte",blkList:"Liste",blkVideo:"Video",blkMap:"Karte (Ort)",pbContent:"Inhalt",pbStyle:"Stil",fontSizeB:"Schriftgröße",fontFamilyB:"Schrift",alignLbl:"Ausrichtung",alignLeft:"Links",alignCenter:"Mitte",alignRight:"Rechts",colorLbl:"Farbe",bgLbl:"Hintergrund",btnShape:"Button-Form",shapeRound:"Abgerundet",shapePill:"Pille",shapeSquare:"Eckig",btnSize:"Button-Größe",sizeS:"Klein",sizeM:"Mittel",sizeL:"Groß",btnLink:"Link (optional)",boldLbl:"Fett",moveBlockUp:"Nach oben",moveBlockDown:"Nach unten",dupBlock:"Duplizieren",delBlock:"Block löschen",pbPreview:"Vorschau",pbEmpty:"Diese Seite ist leer — füge den ersten Block hinzu",pbSaved:"Seite gespeichert",listItems:"Ein Eintrag pro Zeile",videoUrl:"Video-Link (YouTube)",mapAddr:"Adresse oder Ort",pbWho:"Wer sieht es",pbIcon:"Symbol",pbTitle:"Seitentitel",persons:"Anzahl Personen",personsShort:"Pers.",attN:"Noch nicht angestellt",notHiredYet:"Vor Eintrittsdatum",mapTab:"Live-Karte",shareLoc:"Meinen Standort teilen",shareLocHint:"Nur solange dies an ist. Jederzeit ausschalten — dein Standort wird gelöscht.",locDenied:"Standortfreigabe wurde auf diesem Handy abgelehnt",noOneSharing:"Gerade teilt niemand seinen Standort",lastSeen:"Aktualisiert",mapHint:"Hier erscheinen nur Personen, die das Teilen eingeschaltet haben",minsAgo:"Min. her",justNow:"gerade eben",locTeam:"Team",locGuests:"Gäste",assignCenter:"Zuweisungen",asgActs:"Aktivitäten",asgWho:"Wer kann was",asgOpen:"Noch niemand",asgNobody:"Noch niemand",allAssigned:"Alles zugewiesen",autoAssign:"Automatisch zuweisen",autoAssignHint:"Nutzt Tagesplan, freie Tage, Abwesenheiten und Fähigkeiten.",autoReviewHint:"Prüfe die Vorschläge, ändere wen du willst, dann übernehmen.",applyAssign:"Übernehmen",asgApplied:"zugewiesen",asgSkip:"Leer lassen",asgNoSkill:"Niemand Verfügbares kann das",asgAllBusy:"Alle Geeigneten sind beschäftigt",nobodyWorking:"An diesem Tag arbeitet niemand",asgWhoHint:"Tippe auf eine Person, um Fähigkeiten festzulegen",noSkillsSet:"Nichts gesetzt — für alles einsetzbar",skillEditHint:"Einmal tippen = kann. Nochmal = kann nicht. Drittes Mal = zurücksetzen.",skCan:"kann",skCant:"kann nicht",skAny:"—",sk_sport:"Sport",sk_water:"Wasser",sk_dance:"Tanz",sk_show:"Show",sk_kids:"Kinder",sk_music:"Musik",sk_dj:"DJ",sk_games:"Spiele",sk_fitness:"Fitness",sk_host:"Moderation",sk_craft:"Basteln",sk_beach:"Strand",needsSkill:"Benötigte Fähigkeit",noActsYet:"Lege zuerst Aktivitäten im Programm an — dann kannst du festlegen, wer was kann.",canRunIt:"können es",editDayOff:"Freien Tag ändern",noOneEntrance:"Niemand festgelegt",teamChatTab:"Team-Nachrichten",guestChatTab:"Gäste-Nachrichten",attV:"Urlaub",attLeft:"Hotel verlassen",markLeft:"Hotel verlassen",markLeftHint:"Die Anwesenheit bleibt erhalten. Die Nummer wird frei.",leftDate:"Letzter Arbeitstag",undoLeft:"Wieder da",leftTag:"Weg",startPage:"Startseite der App",startPageHint:"Beim Öffnen landest du hier.",todayWord:"Heute",yesterdayWord:"Gestern",practiceDays:"Mo / Mi / Fr",arrangeSections:"Diese Seite ordnen",arrangeHint:"Verschiebe die Teile dieser Seite nach oben oder unten. Für alle gespeichert.",dayInfoSec:"Tagesinformationen",wholeDay:"Der ganze Tag",morningPart:"Vormittag",afternoonPart:"Nachmittag",eveningPart:"Abend",itemsWord:"Einträge",editBooking:"Buchung bearbeiten",openGuest:"Gastprofil öffnen",bookedAt:"Gebucht",booked:"Gebucht",waitlist:"Warteliste",status:"Status",standardsHead:"Tagesstandards",noGuestAccount:"Kein Gastkonto für dieses Zimmer",finishedChip:"Beendet",setVacation:"Urlaub eintragen",setVacationHint:"Wähle die Person und den ersten und letzten Tag.",clearVacation:"Urlaub entfernen",person:"Person",fromDate:"Von",toDate:"Bis",daysWord:"Tage",checkDates:"Daten prüfen",dayWord:"Tag",nightsWord:"Nächte",nightsLeft:"Nächte übrig",stayDayOf:"Tag {n} von {t}",stayWelcome:"Willkommen — dein Urlaub beginnt heute",stayLastDay:"Letzter Tag — wir hoffen, es war schön",plannedAhead:"Im Voraus geplant",addMember:"Mitglied hinzufügen",addAttOnly:"Nur Anwesenheit",addAttOnlyHint:"Nur Name und Nummer (11–50) für die Anwesenheitsliste. Kein Login, keine Aktivitäten, zählt nicht zum Team.",attNumber:"Nummer (11–50)",attNumRange:"Die Nummer muss zwischen 11 und 50 liegen",numberTaken:"Diese Nummer ist schon vergeben",nameNeeded:"Bitte einen Namen eingeben",attOnlyTag:"· nur Anwesenheit",whichMonth:"Welcher Monat",whichDay:"Welcher Tag",selectMsgs:"Nachrichten auswählen",clearChat:"Chat leeren",selectedWord:"ausgewählt",selectAll:"Alle auswählen",selectNone:"Keine auswählen",deleteMsgsQ:"{n} Nachrichten löschen?",clearChatQ:"Den ganzen Chat leeren?",clearChatHint:"Alle {n} Nachrichten werden für alle gelöscht.",cannotUndo:"Das kann nicht rückgängig gemacht werden.",deleteReqQ:"Diese Anfrage löschen?",allDays:"Alle Tage",whichTime:"Welche Zeit",allDayLong:"Ganzer Tag",filterNote:"Es wird nur exportiert:",noFilterNote:"Es wird alles exportiert.",officialAtt:"{hotel} — Offizielle Monatsanwesenheit",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"Erster Tag",lastDayOpt:"Letzter Tag (optional)",attDatesHint:"Tage vor dem ersten und nach dem letzten Tag werden nicht gezählt.",delete:"Löschen",deleteQ:"Diese Person löschen?",attDeleteHint:"Die Anwesenheit wird mitgelöscht. Setze stattdessen den letzten Tag, wenn du sie behalten willst.",eventsCrewTag:"Alle Events & Shows",eventsCrewHint:"Diese Person ist bei jedem Event und jeder Show dabei — der DJ für die Musik, Social Media zum Filmen. Sie steht nicht im Aktivitätenplan, daher gibt es hier nichts anzukreuzen.",wasBooked:"Du warst gebucht",bookNowLive:"Läuft — mitmachen",removeBooking:"Buchung entfernen",removeBookingQ:"Diese Buchung entfernen?",removeBookingHint:"Der Gast verliert seinen Platz. Nicht rückgängig zu machen.",skillEditHint2:"Wähle aus deinem Programm. Einmal tippen = kann. Nochmal = kann nicht. Drittes Mal = zurücksetzen.",autoAssign:"Aktivitäten automatisch verteilen",autoHint:"Je eine Aktivität am Vormittag und am Nachmittag — fair verteilt. Events macht das ganze Team, du und der DJ werden nie eingeteilt.",autoDay:"Dieser Tag",autoWeek:"Ganze Woche",onlyEmptyLbl:"Nur Aktivitäten ohne Zuteilung",replaceAllLbl:"Alles neu verteilen",autoPreview:"Vorschlag",autoApply:"Plan übernehmen",autoNothing:"Nichts zu verteilen — prüfe freie Tage und Programm",autoDone:"Aktivitäten verteilt",morningSlot:"Vormittag",afternoonSlot:"Nachmittag",perPerson:"Pro Person",noOneAvailable:"An diesem Tag ist niemand verfügbar",eventsAllTeam:"Events — ganzes Team",changeWho:"Ändern",noneAssigned:"— niemand —",balanceLbl:"Verteilung",evenSpread:"Gleichmäßig verteilt",spreadOff:"Unterschied von",editHint:"Tippe auf einen Namen, um ihn vor dem Übernehmen zu ändern",recalc:"Neu verteilen",fairest:"Am fairsten",activityCount:"Aktivitäten",zoomLbl:"Zoom",totalAllTeam:"Team gesamt (inkl. Manager)",infoTime:"Öffnungszeit",infoPlace:"Ort",translateBtn:"Übersetzen",translating:"Übersetze...",translateFail:"Übersetzung nicht möglich",showOriginal:"Original zeigen",builderTab:"Menü-Baukasten",builderHint:"Umbenennen, sortieren, ausblenden oder hinzufügen — pro Rolle, ohne Code",forRole:"Für",roleGuest:"Gäste",roleStaff:"Entertainer",roleManager:"Manager",moveUp:"Nach oben",moveDown:"Nach unten",hideItem:"Ausgeblendet",showItem:"Sichtbar",renameItem:"Name",addLink:"Eigene Seite hinzufügen",linkTitle:"Titel",linkUrl:"Webadresse",linkText:"Anzuzeigender Text",linkKind:"Typ",kindLink:"Weblink",kindPage:"Textseite",resetMenu:"Auf Standard zurücksetzen",builderSaved:"Menü aktualisiert",customPage:"Meine Seite",openLink:"Öffnen",translatedTag:"Übersetzt",infoPhoto:"Foto",totalRow:"GESAMT",months:["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"],statusLegend:"Status",almSoonG:"Beginnt in 5 Min",almStartG:"Beginnt jetzt",almDoneG:"Beendet",almSoonS:"Deine Aktivität beginnt in 5 Min — sei jetzt da",almStartS:"Deine Aktivität beginnt jetzt",almDoneS:"Beendet — bitte Feedback mit Zimmernummer einholen",almSoonTeam:"Beginnt in 5 Min",almStartTeam:"Beginnt jetzt",almDoneTeam:"Beendet",secProgram:"Programm",secBookings:"Meine Buchungen",secConnect:"Social & Team",secManage:"Verwaltung",secTeamwork:"Meine Arbeit",secGuests:"Gäste",secSettings:"Einstellungen",uploadErr:"Upload fehlgeschlagen — Storage prüfen",photo:"Foto",uploadPhoto:"Zum Hochladen tippen",changePhoto:"Foto ändern"},EXTRA.de),
ru:Object.assign({appSub:"Команда анимации",guest:"Гость",staff:"Команда",manager:"Менеджер",room:"Номер комнаты",name:"Ваше имя",phone:"Мобильный телефон",user:"Имя пользователя",pass:"Пароль",signin:"Войти",welcome:"Добро пожаловать",today:"Сегодня",highlight:"Событие дня",todayProgram:"Программа на сегодня",week:"Программа недели",myStay:"Мой отдых",home:"Главная",program:"Программа",bookings:"Брони",myBookings:"Мои брони",favorites:"Избранное",book:"Записаться",booked:"Записан",full:"Мест нет",waitlist:"В лист ожидания",onWaitlist:"В листе ожидания",cancel:"Отменить бронь",seatsLeft:"свободных мест",adults:"Взрослые",children:"Дети",confirm:"Подтвердить",close:"Закрыть",days:["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"],daysShort:["Пн","Вт","Ср","Чт","Пт","Сб","Вс"],cats:{morning:"Утро",afternoon:"День",evening:"Вечер",kids:"Детский клуб",theme:"Тематический день",mKids:"Детские активности",mTeen:"Подростковые активности",mAdult:"Активности",mEvents:"События",eKidsStage:"Детская сцена",eLive:"Живая сцена",eBefore:"Перед шоу",eShow:"Шоу",eAfter:"После шоу",eParty:"Вечеринка"},guests:"гостей",noBookings:"Пока нет броней. Загляните в программу дня!",noFavs:"Пока нет избранного. Нажмите на сердечко у активности.",schedule:"Расписание",team:"Команда",guestsBooked:"Записанные гости",noneToday:"На сегодня здесь ничего не запланировано.",dashboard:"Обзор",manage:"Программа",totalBookings:"Броней за неделю",activities:"Активности",occupancy:"Ср. заполняемость",waitlisted:"В листах ожидания",addActivity:"Добавить активность",editActivity:"Редактировать",deleteActivity:"Удалить",actName:"Название",desc:"Описание",location:"Место",time:"Время",capacity:"Вместимость",entertainer:"Аниматор(ы)",imageUrl:"Ссылка на фото (необязательно)",category:"Категория",day:"День",makeHighlight:"Событие дня",save:"Сохранить",saved:"Сохранено",deleted:"Удалено",bookingOk:"Бронь подтверждена!",waitOk:"Добавлено в лист ожидания",cancelled:"Отменено",loginErr:"Проверьте данные и попробуйте снова.",demoNote:"Режим предпросмотра с примерами — подключите Supabase в файле.",reviews:"Нравится отдых?",reviewsSub:"Поделитесь впечатлениями — для нашей команды это очень важно.",followUs:"Подписывайтесь на команду",none:"—",arrival:"День заезда",departure:"День отъезда",otherUsers:"Вход для команды",backToGuest:"← Вход для гостей",usersTab:"Люди",appTab:"App",appName:"Название приложения",appSubtitle:"Подзаголовок",colorsHead:"Цвета",primaryC:"Основной цвет",accentC:"Акцентный цвет",linksHead:"Ссылки на отзывы",socialHead:"Соцсети",addUser:"Добавить пользователя",displayName:"Отображаемое имя",roleLabel:"Роль",teamAccounts:"Аккаунты команды",guestStats:"Статистика гостей",uniqueGuests:"Комнат гостей",totalPeople:"Записано человек",language:"Язык",userExists:"Имя пользователя уже занято",tickets:"Билеты",buyTicket:"Купить билет",myTickets:"Мои билеты",price:"Цена",qty:"Количество",reserved:"Зарезервировано",paid:"Оплачено",payNote:"Зарезервируйте в приложении и оплатите у аниматоров или на ресепшене.",ticketOk:"Билет зарезервирован!",nationality:"Национальность",natStats:"Национальности",addTicket:"Добавить событие",editTicket:"Редактировать событие",markPaid:"Отметить оплаченным",markReserved:"Отметить резервом",styleHead:"Стиль текста",buttonHead:"Стиль кнопок",menuHead:"Названия меню",bgC:"Фон",fontElegant:"Элегантный",fontRoyal:"Королевский",fontModern:"Современный",fontSoft:"Мягкий",btnRounded:"Скруглённые",btnPill:"Пилюля",btnSquare:"Квадратные",ticketsNone:"Пока нет событий с билетами.",orders:"Заказы",soldOut:"Всё продано",opMorning:"Утренняя программа",opAfternoon:"Дневная программа",opEvening:"Вечерняя программа",opDaytime:"Дневные активности",opDayEvents:"Дневные события",opSpecial:"Спецсобытия",startTime:"Начало",endTime:"Окончание",operation:"Программа",chooseCat:"Выберите категорию",backToCats:"Все категории",myActs:"Мои активности",myActsSub:"Назначенные вам активности",chatManager:"Написать менеджеру",teamChat:"Чат команды",editMsg:"Изменить сообщение",deleteMsg:"Удалить сообщение",noStaffMsg:"Пока нет сообщений. Поздоровайтесь с менеджером!",shirtNumber:"Игровой номер",myWorkDay:"Мой рабочий день",dayPlan:"План дня",dayOff:"Выходной",entranceDuty:"Дежурство на входе",dressCode:"Дресс-код",restaurantTheme:"Тема ресторана",dailyStandards:"Распорядок дня",eveningShowLbl:"Вечернее шоу",liveBandLbl:"Живая музыка",makeupPractice:"Доп. репетиция",practiceToday:"Репетиция сегодня (45 мин - Пн/Ср/Пт)",youAreOff:"Сегодня у вас выходной - отдыхайте!",youHaveEntrance:"Сегодня у вас дежурство на входе",teamPlanFull:"План на неделю",selectDay:"Выберите день",noNumber:"Номер не задан - спросите менеджера",djSchedule:"График DJ",std_breakfast:"Завтрак",std_mmeet:"Утреннее собрание",std_start:"Начало — готовность на позициях",std_lunch:"Обед",std_fmorning:"Конец утренней смены",std_ameet:"Дневное собрание",std_fafternoon:"Конец дневной смены",std_dinner:"Ужин",std_stage:"Сцена открывается",std_emeet:"Вечернее собрание",std_yoga:"Ведущий йоги/заката уходит раньше",std_fevening:"Конец вечерней смены",n_sport:"Спортивная форма",n_mact:"Утренние активности 10:00–12:30",n_practice:"13:15 по Пн / Ср / Пт (45-мин репетиция)",n_aact:"Дневные активности 15:00–17:00",n_yogahost:"17:15 для ведущего йоги/заката",n_eshow:"Вечернее шоу и живая музыка с 20:00",n_special:"23:30 в дни спецсобытий (напр. Beach Party)",practiceInline:"13:15 сегодня — 45-мин репетиция",dj_wed:"Без дневной смены — прийти в 16:30 на Sunset Instrument Party (17:00–19:00), остаться до закрытия (23:00)",dj_thu:"Выходной — живая музыка от группы (только 1 событие: Foam Party)",dj_other:"Уйти в 16:30, вернуться к 19:00, чтобы открыть сцену",trainsToday:"тренируется индивидуально сегодня",busTimes:"Время автобуса",busSchedule:"Расписание автобуса персонала",busToHotel:"Дом персонала → Отель",busToHouse:"Отель → Дом персонала",busEditHint:"Одно время отправления на строку",noBusTimes:"Пока нет расписания — добавьте его в настройках приложения.",busNextHint:"Следующий рейс",addBus:"Добавить автобус",editBus:"Изменить автобус",busDirection:"Направление",busTimeLbl:"Время отправления",busNoteLbl:"Заметка (необязательно)",busNoteHint:"напр. только по пятницам",settingsHub:"Настройки",appSettingsItem:"Дизайн и настройки приложения",aiItem:"ИИ-ассистент",exportItem:"Экспорт данных (Excel/PDF)",busItem:"Расписание автобуса",settingsSub:"Всё для управления и настройки приложения",st_todo:"Не начата",st_live:"Идёт",st_done:"Завершена",cancelBtn:"Отмена",confirmTitle:"Вы уверены?",cannotUndo:"Это действие нельзя отменить.",delActivityQ:"Удалить эту активность?",delUserQ:"Удалить эту учётную запись?",delReqQ:"Удалить этот запрос?",delBusQ:"Удалить этот автобус?",delMsgQ:"Удалить это сообщение?",offlineMsg:"Оффлайн — показаны последние данные",backOnlineMsg:"Снова онлайн — синхронизация...",loadingMsg:"Загрузка...",errSave:"Не удалось сохранить. Попробуйте снова.",errNet:"Нет соединения. Проверьте интернет.",fieldRequired:"Пожалуйста, заполните",invalidTime:"Формат 08:00",invalidNumber:"Введите корректное число",updateReady:"Доступна новая версия — переоткройте приложение",serverHead:"Защищённый сервер (необязательно)",serverHint:"Вставьте ссылки Supabase Edge Function. Тогда ключ ИИ остаётся на сервере, а не в телефоне.",errHttps:"Ссылка должна начинаться с https://",noDataTitle:"Соединение есть, данных нет",noDataMsg:"Приложение связалось с базой, но ничего не получило — обычно это правила доступа. Запустите скрипт восстановления в Supabase и перезагрузите.",noDataRooms:"Комнаты не найдены",eventsToday:"События сегодня",noEventsToday:"Сегодня нет спецсобытия",practiceHead:"Репетиция команды",practiceWindow:"12:30 – 13:15 (45 мин)",makeupWindow:"45 мин — индивидуально",aiEndpointErr:"Ссылка на сервер недоступна — проверьте развёртывание или очистите поле",aiEndpointFallback:"Сервер недоступен — используется ключ на этом устройстве",themeHead:"Тема приложения",themeHint:"У каждой темы есть светлый и тёмный вариант — переключайте солнцем/луной в меню.",themeCustom:"Свои цвета",themeLight:"Светлая",themeDark:"Тёмная",quizTab:"Викторина дня",quizToday:"Вопрос дня",quizAnswerPh:"Ваш ответ...",quizSend:"Отправить ответ",quizDone:"Ответ принят — спасибо!",quizNone:"Сегодня вопроса нет. Приходите завтра!",quizMine:"Ваш ответ",quizCenter:"Центр викторины",quizNew:"Новый вопрос",quizFor:"Для",quizForGuest:"Гости",quizForStaff:"Аниматоры",quizQuestion:"Вопрос",quizHint:"Подсказка (необязательно)",quizKey:"Правильный ответ (видите только вы)",quizReplies:"Ответы",quizNoReplies:"Ответов пока нет",quizSaved:"Вопрос опубликован",quizAlready:"Вы уже отвечали сегодня",todayPlanExp:"План на сегодня (для дирекции)",navBack:"Назад",navForward:"Вперёд",genderLbl:"Пол",genderM:"Мужской",genderF:"Женский",genderNone:"Не указан",teamSummary:"Сводка по команде",totalEntertainers:"Всего аниматоров",byGender:"По полу",byNationality:"По национальности",teamOverview:"Обзор команды",typeNationality:"Введите национальность",natOtherHint:"Нет в списке? Выберите «Другое» и введите.",editDuty:"Изменить выходной и вход",dutyFor:"Дежурство на",selectDayOff:"Кто выходной",selectEntrance:"Дежурство на входе",resetDefault:"Вернуть стандартный план",customDay:"Изменено",standardDay:"Стандартный план",workingToday:"Работают",dayOffToday:"Выходной",totalTeam:"Всего в команде",dutySaved:"Дежурство обновлено",noOneOff:"Никто не отдыхает",monthAtt:"Посещаемость за месяц",attP:"Присутствует",attO:"Выходной",attA:"Отсутствует",attLegend:"P = присутствует · O = выходной · A = отсутствует",attTapHint:"Нажмите на день, чтобы изменить. Серое — из плана.",attAuto:"Из плана",attTotalsP:"Рабочих дней",attTotalsO:"Выходных",attTotalsA:"Пропусков",attExport:"Табель за месяц",prevMonth:"Предыдущий месяц",nextMonth:"Следующий месяц",attSaved:"Посещаемость обновлена",workDays:"Рабочие дни",monthTotals:"Итоги месяца",teamWorkDays:"Рабочих дней команды",avgPerPerson:"В среднем на человека",hotelInfoTab:"Информация об отеле",hotelInfoHint:"Часы работы, Wi-Fi и частые вопросы гостей",addInfo:"Добавить информацию",infoTitle:"Название",infoValue:"Детали",noInfo:"Информация ещё не добавлена",galleryTab:"Фото",galleryHint:"Снимки с наших шоу и активностей",addPhoto:"Добавить фото",noPhotos:"Фото пока нет — загляните после вечернего шоу!",photoCaption:"Подпись (необязательно)",attentionHead:"Требует внимания",allGood:"Всё хорошо — ничего срочного",attEmptyAct:"активностей сегодня без записей",attWaitReq:"запросов гостей ждут",attLowRate:"низких оценок на этой неделе",attStaffReq:"запросов команды ждут",attNoShow:"сотрудников не отмечено сегодня",trendsHead:"Тренды",last7:"Последние 7 дней",topActs:"Самые популярные",lowActs:"Наименее популярные",bookingTrend:"Записи по дням",myAttendance:"Моя посещаемость",myFeedback:"Мои отзывы",noMyFeedback:"Отзывов пока нет",askManager:"Спросить менеджера",myRequestsTeam:"Мои запросы",newTeamReq:"Новый запрос",reqDayOff:"Изменить выходной",reqProblem:"Сообщить о проблеме",reqCannot:"Не могу провести активность",reqOther:"Другое",reqDetail:"Напишите менеджеру",reqDateOpt:"Какой день (необязательно)",teamRequests:"Запросы команды",noTeamReqs:"Запросов от команды нет",reqApprove:"Одобрить",reqDecline:"Отклонить",reqReply:"Ответ (необязательно)",statusOk:"Одобрено",statusNo:"Отклонено",reqSent:"Отправлено менеджеру",thankYou:"Спасибо!",shareExp:"Хотите поделиться впечатлением?",reviewLater:"Может позже",howWasIt:"Как вам?",qrTab:"QR-код",qrHint:"Распечатайте и разместите у бассейна, бара и ресепшена",qrDownload:"Открыть страницу для печати",stayEnded:"Ваше пребывание завершено — спасибо за визит!",accountOff:"Аккаунт неактивен. Обратитесь к менеджеру.",activeAcc:"Аккаунт активен",inactiveAcc:"Неактивен",deactivate:"Деактивировать",activate:"Активировать",resetPass:"Сбросить пароль",newPassIs:"Новый пароль",passCopied:"Передайте это сотруднику — старый пароль больше не работает",tooManyTries:"Слишком много попыток. Подождите немного.",logoLbl:"Логотип",logoHint:"Показывается на экране входа",hotelNameLbl:"Название отеля",timezoneLbl:"Часовой пояс отеля",timezoneHint:"Время и напоминания идут по часам отеля, а не телефона гостя",currencyLbl:"Валюта",contactLbl:"Контакт",fontSizeLbl:"Размер текста",fsSmall:"Мелкий",fsNormal:"Обычный",fsLarge:"Крупный",fsXl:"Очень крупный",autoDarkLbl:"Тёмная тема как на телефоне",featuresLbl:"Функции",featQuiz:"Викторина дня",featTickets:"Билеты",featGallery:"Фото",featBus:"Расписание автобуса",featInfo:"Информация об отеле",previewTheme:"Предпросмотр",applyTheme:"Использовать эту тему",previewOn:"Предпросмотр — ещё не сохранено",secIdentity:"Об отеле",secLook:"Внешний вид",secAccess:"Доступ",upToToday:"по сегодня",countedDays:"Учтено дней",workingEntToday:"Аниматоров работает сегодня",weatherTab:"Погода",weatherToday:"Сегодня",weatherWeek:"На неделе",weatherFail:"Погода сейчас недоступна",feelsLike:"Ощущается",windLbl:"Ветер",latLbl:"Широта",lonLbl:"Долгота",weatherLoc:"Место для погоды",weatherLocHint:"Координаты отеля (по умолчанию Хургада)",wSun:"Солнечно",wPartly:"Переменная облачность",wCloud:"Облачно",wFog:"Туман",wDrizzle:"Морось",wRain:"Дождь",wShower:"Ливни",wSnow:"Снег",wStorm:"Гроза",wWind:"Ветрено",setBrand:"Бренд и айдентика",setBrandSub:"Логотип, название отеля, контакты",setTheme:"Тема и цвета",setThemeSub:"Цвета, шрифты, размер текста, тёмная тема",setMenus:"Меню и страницы",setMenusSub:"Переименование, порядок, свои страницы",setNotif:"Уведомления",setNotifSub:"Звук и оповещения",setLinksT:"Ссылки и отзывы",setLinksSub:"Соцсети и сайты отзывов",setFeatures:"Функции",setFeaturesSub:"Включить или выключить части приложения",setLocation:"Место и время",setLocationSub:"Часовой пояс и место для погоды",setAdvanced:"Дополнительно",setAdvancedSub:"Защищённый сервер, ИИ, QR-код",setData:"Данные",setDataSub:"Экспорт всего в Excel или PDF",addTime:"Добавить ещё время",timesLbl:"Часы работы",guestCrm:"Профили гостей",crmSearch:"Поиск по номеру, имени или стране",guest360:"Профиль гостя",stayLen:"Проживание",nights:"ночей",attendedActs:"Посещённые активности",favActs:"Любимые активности",msgCount:"Сообщения",quizPart:"Ответы в викторине",appUsage:"Дней в приложении",noGuests:"Гостей пока нет",openProfile:"Открыть профиль",taskPriority:"Приоритет",prLow:"Низкий",prNormal:"Обычный",prHigh:"Высокий",prUrgent:"Срочно",taskLoc:"Место",taskDeadline:"Срок",stNew:"Новая",stAccepted:"Принята",stProgress:"В работе",stCompleted:"Выполнена",stVerified:"Проверена",overdue:"Просрочено",acceptTask:"Принять",startTask:"Начать",completeTask:"Выполнить",verifyTask:"Проверить",taskProof:"Фото-подтверждение",taskComments:"Комментарии",addComment:"Добавить комментарий",taskHistory:"История",createdBy:"Создал",noTasks:"Нет задач",employeeProfile:"Профиль сотрудника",employeeId:"Табельный номер",positionLbl2:"Должность",phoneLbl2:"Телефон",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Дата приёма",suspend:"Отстранить",assignedActs:"Назначенные активности",performance:"Результаты",guestRatings:"Оценки гостей",pointsLbl:"Баллы",rankLbl:"Место",tasksDone:"Задач выполнено",onTime:"Вовремя",viewProfile:"Смотреть профиль",photosLbl:"Фото",addPhotos:"Добавить фото",removePhoto:"Удалить фото",cropLogo:"Обрезать логотип",cropHint:"Перетащите, ползунок для масштаба",useCrop:"Применить",removeLogo:"Удалить логотип",photoOf:"из",requestChange:"Запросить изменение",changeRequest:"Запрос на изменение",whatToChange:"Что нужно изменить?",reqSentMgr:"Отправлено менеджеру",profileReadOnly:"Изменить может только менеджер",pageBuilder:"Конструктор страниц",pbHint:"Соберите страницу из блоков — без кода",pbNewPage:"Новая страница",pbEditPage:"Изменить страницу",pbBlocks:"Блоки",pbAddBlock:"Добавить блок",blkHeading:"Заголовок",blkText:"Текст",blkImage:"Изображение",blkGallery:"Галерея",blkButton:"Кнопка",blkDivider:"Разделитель",blkSpacer:"Отступ",blkCard:"Карточка",blkList:"Список",blkVideo:"Видео",blkMap:"Карта",pbContent:"Содержимое",pbStyle:"Стиль",fontSizeB:"Размер шрифта",fontFamilyB:"Шрифт",alignLbl:"Выравнивание",alignLeft:"Слева",alignCenter:"По центру",alignRight:"Справа",colorLbl:"Цвет",bgLbl:"Фон",btnShape:"Форма кнопки",shapeRound:"Скруглённая",shapePill:"Овальная",shapeSquare:"Прямая",btnSize:"Размер кнопки",sizeS:"Маленькая",sizeM:"Средняя",sizeL:"Большая",btnLink:"Ссылка (необязательно)",boldLbl:"Жирный",moveBlockUp:"Вверх",moveBlockDown:"Вниз",dupBlock:"Дублировать",delBlock:"Удалить блок",pbPreview:"Предпросмотр",pbEmpty:"Страница пуста — добавьте первый блок",pbSaved:"Страница сохранена",listItems:"По одному пункту в строке",videoUrl:"Ссылка на видео (YouTube)",mapAddr:"Адрес или место",pbWho:"Кто видит",pbIcon:"Значок",pbTitle:"Заголовок страницы",persons:"Количество человек",personsShort:"чел.",attN:"Ещё не работал",notHiredYet:"До даты приёма",mapTab:"Карта онлайн",shareLoc:"Делиться геопозицией",shareLocHint:"Только пока включено. Выключите в любой момент — данные удалятся.",locDenied:"Доступ к геопозиции отклонён на этом телефоне",noOneSharing:"Сейчас никто не делится геопозицией",lastSeen:"Обновлено",mapHint:"Здесь видны только те, кто включил передачу",minsAgo:"мин назад",justNow:"только что",locTeam:"Команда",locGuests:"Гости",assignCenter:"Назначения",asgActs:"Активности",asgWho:"Кто что может",asgOpen:"Пока никого",asgNobody:"Пока никого",allAssigned:"Всё назначено",autoAssign:"Назначить автоматически",autoAssignHint:"Учитывает план дня, выходные, отсутствия и навыки.",autoReviewHint:"Проверьте предложения, измените кого нужно, затем примените.",applyAssign:"Применить",asgApplied:"назначено",asgSkip:"Оставить пустым",asgNoSkill:"Никто из доступных не может это провести",asgAllBusy:"Все подходящие заняты",nobodyWorking:"В этот день никто не работает",asgWhoHint:"Нажмите на человека, чтобы задать навыки",noSkillsSet:"Не задано — можно назначать на всё",skillEditHint:"Одно нажатие = может. Второе = не может. Третье = сброс.",skCan:"может",skCant:"не может",skAny:"—",sk_sport:"Спорт",sk_water:"Вода",sk_dance:"Танцы",sk_show:"Шоу",sk_kids:"Дети",sk_music:"Музыка",sk_dj:"DJ",sk_games:"Игры",sk_fitness:"Фитнес",sk_host:"Ведущий",sk_craft:"Творчество",sk_beach:"Пляж",needsSkill:"Нужен навык",noActsYet:"Сначала добавьте активности в программу — потом отметите, кто что может.",canRunIt:"могут",editDayOff:"Изменить выходной",noOneEntrance:"Никто не назначен",teamChatTab:"Сообщения команды",guestChatTab:"Сообщения гостей",attV:"Отпуск",attLeft:"Покинул отель",markLeft:"Покинул отель",markLeftHint:"Посещаемость сохраняется. Номер освобождается.",leftDate:"Последний рабочий день",undoLeft:"Вернулся",leftTag:"Ушёл",startPage:"Стартовая страница",startPageHint:"При открытии приложения вы попадёте сюда.",todayWord:"Сегодня",yesterdayWord:"Вчера",practiceDays:"Пн / Ср / Пт",arrangeSections:"Настроить страницу",arrangeHint:"Перемещайте части страницы вверх или вниз. Сохраняется для всех.",dayInfoSec:"Информация о дне",wholeDay:"Весь день",morningPart:"Утро",afternoonPart:"День",eveningPart:"Вечер",itemsWord:"записей",editBooking:"Изменить запись",openGuest:"Открыть профиль гостя",bookedAt:"Записано",booked:"Записан",waitlist:"Лист ожидания",status:"Статус",standardsHead:"Ежедневный распорядок",noGuestAccount:"Для этого номера нет аккаунта",finishedChip:"Завершено",setVacation:"Оформить отпуск",setVacationHint:"Выберите человека и первый и последний день.",clearVacation:"Убрать отпуск",person:"Сотрудник",fromDate:"С",toDate:"По",daysWord:"дней",checkDates:"Проверьте даты",dayWord:"День",nightsWord:"ночей",nightsLeft:"ночей осталось",stayDayOf:"День {n} из {t}",stayWelcome:"Добро пожаловать — отдых начинается сегодня",stayLastDay:"Последний день — надеемся, вам понравилось",plannedAhead:"Запланировано",addMember:"Добавить сотрудника",addAttOnly:"Только посещаемость",addAttOnlyHint:"Только имя и номер (11–50) для табеля. Без входа, без активностей, не входит в команду.",attNumber:"Номер (11–50)",attNumRange:"Номер должен быть от 11 до 50",numberTaken:"Этот номер уже занят",nameNeeded:"Введите имя",attOnlyTag:"· только табель",whichMonth:"Какой месяц",whichDay:"Какой день",selectMsgs:"Выбрать сообщения",clearChat:"Очистить чат",selectedWord:"выбрано",selectAll:"Выбрать все",selectNone:"Снять выбор",deleteMsgsQ:"Удалить {n} сообщений?",clearChatQ:"Очистить весь чат?",clearChatHint:"Все {n} сообщений будут удалены у всех.",cannotUndo:"Это нельзя отменить.",deleteReqQ:"Удалить этот запрос?",allDays:"Все дни",whichTime:"Какое время",allDayLong:"Весь день",filterNote:"Экспортируется только:",noFilterNote:"Экспортируется всё.",officialAtt:"{hotel} — Официальный табель за месяц",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"Первый день",lastDayOpt:"Последний день (необяз.)",attDatesHint:"Дни до первого и после последнего дня не считаются.",delete:"Удалить",deleteQ:"Удалить этого человека?",attDeleteHint:"Его посещаемость тоже удалится. Лучше укажите последний день, чтобы сохранить её.",eventsCrewTag:"Все события и шоу",eventsCrewHint:"Этот человек присутствует на каждом мероприятии и шоу — диджей для музыки, соцсети для съёмки. В расписании активностей он не участвует, поэтому отмечать нечего.",wasBooked:"Вы были записаны",bookNowLive:"Идёт — присоединиться",removeBooking:"Удалить запись",removeBookingQ:"Удалить эту запись?",removeBookingHint:"Гость теряет место. Отменить нельзя.",skillEditHint2:"Отметьте активности из программы. Одно нажатие = может. Второе = не может. Третье = сброс.",autoAssign:"Распределить активности",autoHint:"По одной активности утром и днём — справедливо. События проводит вся команда, вы и диджей не назначаются.",autoDay:"Этот день",autoWeek:"Вся неделя",onlyEmptyLbl:"Только без назначенного",replaceAllLbl:"Заменить всё",autoPreview:"Предложение",autoApply:"Применить план",autoNothing:"Нечего распределять — проверьте выходные и программу",autoDone:"Активности распределены",morningSlot:"Утро",afternoonSlot:"День",perPerson:"На человека",noOneAvailable:"В этот день никого нет",eventsAllTeam:"События — вся команда",changeWho:"Изменить",noneAssigned:"— никто —",balanceLbl:"Баланс",evenSpread:"Поровну",spreadOff:"Разница в",editHint:"Нажмите на имя, чтобы изменить перед применением",recalc:"Пересчитать",fairest:"Самое честное",activityCount:"активностей",zoomLbl:"Масштаб",totalAllTeam:"Всего в команде (с менеджером)",infoTime:"Время работы",infoPlace:"Место",translateBtn:"Перевести",translating:"Перевод...",translateFail:"Не удалось перевести",showOriginal:"Показать оригинал",builderTab:"Конструктор меню",builderHint:"Переименуйте, отсортируйте, скройте или добавьте пункты — для каждой роли, без кода",forRole:"Для",roleGuest:"Гости",roleStaff:"Аниматоры",roleManager:"Менеджер",moveUp:"Вверх",moveDown:"Вниз",hideItem:"Скрыто",showItem:"Показано",renameItem:"Название",addLink:"Добавить свою страницу",linkTitle:"Заголовок",linkUrl:"Веб-адрес",linkText:"Текст для показа",linkKind:"Тип",kindLink:"Ссылка",kindPage:"Текстовая страница",resetMenu:"Сбросить по умолчанию",builderSaved:"Меню обновлено",customPage:"Моя страница",openLink:"Открыть",translatedTag:"Переведено",infoPhoto:"Фото",totalRow:"ИТОГО",months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],statusLegend:"Статус",almSoonG:"Начнётся через 5 мин",almStartG:"Начинается сейчас",almDoneG:"Завершена",almSoonS:"Ваша активность через 5 мин — будьте на месте",almStartS:"Ваша активность начинается",almDoneS:"Завершена — соберите отзыв с номером комнаты",almSoonTeam:"Начнётся через 5 мин",almStartTeam:"Начинается сейчас",almDoneTeam:"Завершена",secProgram:"Программа",secBookings:"Мои брони",secConnect:"Соцсети и команда",secManage:"Управление",secTeamwork:"Моя работа",secGuests:"Гости",secSettings:"Настройки",uploadErr:"Ошибка загрузки — проверьте Storage",photo:"Фото",uploadPhoto:"Нажмите, чтобы загрузить фото",changePhoto:"Изменить фото"},EXTRA.ru),
pl:Object.assign({appSub:"Zespół animacji",guest:"Gość",staff:"Zespół",manager:"Menedżer",room:"Numer pokoju",name:"Twoje imię",phone:"Telefon komórkowy",user:"Nazwa użytkownika",pass:"Hasło",signin:"Zaloguj się",welcome:"Witamy",today:"Dziś",highlight:"Atrakcja dnia",todayProgram:"Dzisiejszy program",week:"Program tygodnia",myStay:"Mój pobyt",home:"Start",program:"Program",bookings:"Rezerwacje",myBookings:"Moje rezerwacje",favorites:"Ulubione",book:"Zarezerwuj",booked:"Zarezerwowano",full:"Brak miejsc",waitlist:"Lista oczekujących",onWaitlist:"Na liście oczekujących",cancel:"Anuluj rezerwację",seatsLeft:"wolnych miejsc",adults:"Dorośli",children:"Dzieci",confirm:"Potwierdź rezerwację",close:"Zamknij",days:["Poniedziałek","Wtorek","Środa","Czwartek","Piątek","Sobota","Niedziela"],daysShort:["Pon","Wt","Śr","Czw","Pt","Sob","Nd"],cats:{morning:"Rano",afternoon:"Popołudnie",evening:"Wieczór",kids:"Klub dziecięcy",theme:"Dzień tematyczny",mKids:"Zajęcia dla dzieci",mTeen:"Zajęcia dla nastolatków",mAdult:"Aktywności",mEvents:"Wydarzenia",eKidsStage:"Scena dziecięca",eLive:"Scena na żywo",eBefore:"Przed show",eShow:"Show",eAfter:"Po show",eParty:"Impreza"},guests:"gości",noBookings:"Brak rezerwacji. Zajrzyj do dzisiejszego programu!",noFavs:"Brak ulubionych. Dotknij serca przy aktywności.",schedule:"Harmonogram",team:"Zespół",guestsBooked:"Zapisani goście",noneToday:"Dziś nic tu nie zaplanowano.",dashboard:"Panel",manage:"Program",totalBookings:"Rezerwacje w tym tygodniu",activities:"Aktywności",occupancy:"Śr. obłożenie",waitlisted:"Na listach oczekujących",addActivity:"Dodaj aktywność",editActivity:"Edytuj aktywność",deleteActivity:"Usuń",actName:"Nazwa aktywności",desc:"Opis",location:"Miejsce",time:"Godzina",capacity:"Liczba miejsc",entertainer:"Animator(zy)",imageUrl:"Adres zdjęcia (opcjonalnie)",category:"Kategoria",day:"Dzień",makeHighlight:"Atrakcja dnia",save:"Zapisz",saved:"Zapisano",deleted:"Usunięto",bookingOk:"Rezerwacja potwierdzona!",waitOk:"Dodano do listy oczekujących",cancelled:"Anulowano",loginErr:"Sprawdź dane i spróbuj ponownie.",demoNote:"Tryb podglądu z przykładami — połącz Supabase w pliku.",reviews:"Podobają Ci się wakacje?",reviewsSub:"Podziel się opinią — to wiele znaczy dla naszego zespołu.",followUs:"Obserwuj zespół",none:"—",arrival:"Dzień przyjazdu",departure:"Dzień wyjazdu",otherUsers:"Dostęp dla zespołu",backToGuest:"← Logowanie gościa",usersTab:"Konta",appTab:"App",appName:"Nazwa aplikacji",appSubtitle:"Podtytuł",colorsHead:"Kolory",primaryC:"Kolor główny",accentC:"Kolor akcentu",linksHead:"Linki do opinii",socialHead:"Media społecznościowe",addUser:"Dodaj użytkownika",displayName:"Wyświetlana nazwa",roleLabel:"Rola",teamAccounts:"Konta zespołu",guestStats:"Statystyki gości",uniqueGuests:"Pokoje gości",totalPeople:"Zapisane osoby",language:"Język",userExists:"Ta nazwa użytkownika już istnieje",tickets:"Bilety",buyTicket:"Kup bilet",myTickets:"Moje bilety",price:"Cena",qty:"Ilość",reserved:"Zarezerwowano",paid:"Opłacone",payNote:"Zarezerwuj w aplikacji i zapłać przy stanowisku animacji lub w recepcji.",ticketOk:"Bilet zarezerwowany!",nationality:"Narodowość",natStats:"Narodowości",addTicket:"Dodaj wydarzenie",editTicket:"Edytuj wydarzenie",markPaid:"Oznacz jako opłacone",markReserved:"Oznacz jako rezerwację",styleHead:"Styl tekstu",buttonHead:"Styl przycisków",menuHead:"Tytuły menu",bgC:"Tło",fontElegant:"Elegancki",fontRoyal:"Królewski",fontModern:"Nowoczesny",fontSoft:"Miękki",btnRounded:"Zaokrąglone",btnPill:"Pigułka",btnSquare:"Kwadratowe",ticketsNone:"Brak wydarzeń biletowych.",orders:"Zamówienia",soldOut:"Wyprzedane",opMorning:"Program poranny",opAfternoon:"Program popołudniowy",opEvening:"Program wieczorny",opDaytime:"Aktywności dzienne",opDayEvents:"Wydarzenia dzienne",opSpecial:"Wydarzenia specjalne",startTime:"Początek",endTime:"Koniec",operation:"Program",chooseCat:"Wybierz kategorię",backToCats:"Wszystkie kategorie",myActs:"Moje aktywności",myActsSub:"Aktywności przypisane do Ciebie",chatManager:"Napisz do menedżera",teamChat:"Czat zespołu",editMsg:"Edytuj wiadomość",deleteMsg:"Usuń wiadomość",noStaffMsg:"Brak wiadomości. Przywitaj się z menedżerem!",shirtNumber:"Numer koszulki",myWorkDay:"Mój dzień pracy",dayPlan:"Plan dnia",dayOff:"Dzień wolny",entranceDuty:"Dyżur przy wejściu",dressCode:"Dress code",restaurantTheme:"Motyw restauracji",dailyStandards:"Rozkład dnia",eveningShowLbl:"Wieczorny pokaz",liveBandLbl:"Zespół na żywo",makeupPractice:"Trening wyrównawczy",practiceToday:"Trening zespołu dziś (45 min - Pon/Śr/Pt)",youAreOff:"Masz dziś wolne - miłego dnia!",youHaveEntrance:"Masz dziś dyżur przy wejściu",teamPlanFull:"Pełny plan tygodnia",selectDay:"Wybierz dzień",noNumber:"Brak numeru - zapytaj menedżera",djSchedule:"Grafik DJ",std_breakfast:"Śniadanie",std_mmeet:"Poranne spotkanie",std_start:"Start — gotowość na pozycjach",std_lunch:"Obiad",std_fmorning:"Koniec zmiany porannej",std_ameet:"Popołudniowe spotkanie",std_fafternoon:"Koniec zmiany popołudniowej",std_dinner:"Kolacja",std_stage:"Scena otwarta",std_emeet:"Wieczorne spotkanie",std_yoga:"Prowadzący jogę/zachód wychodzi wcześniej",std_fevening:"Koniec zmiany wieczornej",n_sport:"Strój sportowy",n_mact:"Aktywności poranne 10:00–12:30",n_practice:"13:15 w Pon / Śr / Pt (trening 45 min)",n_aact:"Aktywności popołudniowe 15:00–17:00",n_yogahost:"17:15 dla prowadzącego jogę/zachód",n_eshow:"Wieczorny pokaz i muzyka na żywo od 20:00",n_special:"23:30 w dni wydarzeń specjalnych (np. Beach Party)",practiceInline:"13:15 dziś — trening 45 min",dj_wed:"Brak zmiany popołudniowej — przyjście 16:30 na Sunset Instrument Party (17:00–19:00), do zamknięcia (23:00)",dj_thu:"Dzień wolny — zespół na żywo gra muzykę (tylko 1 wydarzenie: Foam Party)",dj_other:"Wyjście 16:30, powrót na 19:00, aby otworzyć scenę",trainsToday:"trenuje dziś indywidualnie",busTimes:"Godziny autobusu",busSchedule:"Rozkład autobusu dla personelu",busToHotel:"Dom personelu → Hotel",busToHouse:"Hotel → Dom personelu",busEditHint:"Jedna godzina odjazdu na wiersz",noBusTimes:"Brak godzin autobusu — dodaj je w ustawieniach aplikacji.",busNextHint:"Następny odjazd",addBus:"Dodaj autobus",editBus:"Edytuj autobus",busDirection:"Kierunek",busTimeLbl:"Godzina odjazdu",busNoteLbl:"Notatka (opcjonalnie)",busNoteHint:"np. tylko w piątki",settingsHub:"Ustawienia",appSettingsItem:"Wygląd i ustawienia aplikacji",aiItem:"Asystent AI",exportItem:"Eksport danych (Excel/PDF)",busItem:"Rozkład autobusu",settingsSub:"Wszystko do zarządzania i personalizacji aplikacji",st_todo:"Nierozpoczęte",st_live:"W toku",st_done:"Zakończone",cancelBtn:"Anuluj",confirmTitle:"Na pewno?",cannotUndo:"Tej akcji nie można cofnąć.",delActivityQ:"Usunąć tę aktywność?",delUserQ:"Usunąć to konto?",delReqQ:"Usunąć tę prośbę?",delBusQ:"Usunąć ten autobus?",delMsgQ:"Usunąć tę wiadomość?",offlineMsg:"Offline — pokazuję ostatnie dane",backOnlineMsg:"Znów online — synchronizacja...",loadingMsg:"Ładowanie...",errSave:"Nie udało się zapisać. Spróbuj ponownie.",errNet:"Brak połączenia. Sprawdź internet.",fieldRequired:"Uzupełnij to pole",invalidTime:"Format 08:00",invalidNumber:"Podaj poprawną liczbę",updateReady:"Dostępna nowa wersja — otwórz aplikację ponownie",serverHead:"Bezpieczny serwer (opcjonalnie)",serverHint:"Wklej linki Supabase Edge Function. Dzięki temu klucz AI zostaje na serwerze, nie w telefonie.",errHttps:"Link musi zaczynać się od https://",noDataTitle:"Połączono, ale brak danych",noDataMsg:"Aplikacja połączyła się z bazą, ale nic nie otrzymała — zwykle to reguły dostępu. Uruchom skrypt naprawczy w Supabase i odśwież.",noDataRooms:"Nie znaleziono pokoi",eventsToday:"Wydarzenia dziś",noEventsToday:"Dziś brak wydarzenia specjalnego",practiceHead:"Trening zespołu",practiceWindow:"12:30 – 13:15 (45 min)",makeupWindow:"45 min — indywidualnie",aiEndpointErr:"Link serwera niedostępny — sprawdź wdrożenie lub wyczyść pole",aiEndpointFallback:"Serwer niedostępny — używam klucza na tym urządzeniu",themeHead:"Motyw aplikacji",themeHint:"Każdy motyw ma wersję jasną i ciemną — przełącz słońcem/księżycem w menu.",themeCustom:"Własne kolory",themeLight:"Jasny",themeDark:"Ciemny",quizTab:"Quiz dnia",quizToday:"Pytanie dnia",quizAnswerPh:"Twoja odpowiedź...",quizSend:"Wyślij odpowiedź",quizDone:"Odpowiedziano — dziękujemy!",quizNone:"Dziś brak pytania. Wróć jutro!",quizMine:"Twoja odpowiedź",quizCenter:"Centrum quizu",quizNew:"Nowe pytanie",quizFor:"Dla",quizForGuest:"Goście",quizForStaff:"Animatorzy",quizQuestion:"Pytanie",quizHint:"Podpowiedź (opcjonalnie)",quizKey:"Poprawna odpowiedź (widzisz tylko Ty)",quizReplies:"Odpowiedzi",quizNoReplies:"Brak odpowiedzi",quizSaved:"Pytanie opublikowane",quizAlready:"Już dziś odpowiedziałeś",todayPlanExp:"Plan na dziś (dla dyrekcji)",navBack:"Wstecz",navForward:"Dalej",genderLbl:"Płeć",genderM:"Mężczyzna",genderF:"Kobieta",genderNone:"Nie podano",teamSummary:"Podsumowanie zespołu",totalEntertainers:"Łącznie animatorów",byGender:"Wg płci",byNationality:"Wg narodowości",teamOverview:"Przegląd zespołu",typeNationality:"Wpisz narodowość",natOtherHint:"Nie ma na liście? Wybierz Inne i wpisz.",editDuty:"Edytuj dzień wolny i wejście",dutyFor:"Dyżur na",selectDayOff:"Kto ma wolne",selectEntrance:"Dyżur przy wejściu",resetDefault:"Przywróć plan standardowy",customDay:"Zmienione",standardDay:"Plan standardowy",workingToday:"Pracuje",dayOffToday:"Wolne",totalTeam:"Cały zespół",dutySaved:"Dyżur zaktualizowany",noOneOff:"Nikt nie ma wolnego",monthAtt:"Obecność miesięczna",attP:"Obecny",attO:"Wolne",attA:"Nieobecny",attLegend:"P = obecny · O = wolne · A = nieobecny",attTapHint:"Dotknij dnia, aby zmienić. Szary pochodzi z planu.",attAuto:"Z planu",attTotalsP:"Dni pracy",attTotalsO:"Dni wolne",attTotalsA:"Nieobecności",attExport:"Miesięczna lista obecności",prevMonth:"Poprzedni miesiąc",nextMonth:"Następny miesiąc",attSaved:"Obecność zaktualizowana",workDays:"Dni pracy",monthTotals:"Podsumowanie miesiąca",teamWorkDays:"Dni pracy zespołu",avgPerPerson:"Średnio na osobę",hotelInfoTab:"Informacje o hotelu",hotelInfoHint:"Godziny otwarcia, WiFi i najczęstsze pytania gości",addInfo:"Dodaj informację",infoTitle:"Tytuł",infoValue:"Szczegóły",noInfo:"Brak informacji",galleryTab:"Zdjęcia",galleryHint:"Zdjęcia z naszych pokazów i zajęć",addPhoto:"Dodaj zdjęcie",noPhotos:"Brak zdjęć — zajrzyj po wieczornym pokazie!",photoCaption:"Podpis (opcjonalnie)",attentionHead:"Wymaga uwagi",allGood:"Wszystko w porządku",attEmptyAct:"zajęć dziś bez rezerwacji",attWaitReq:"próśb gości czeka",attLowRate:"niskich ocen w tym tygodniu",attStaffReq:"próśb zespołu czeka",attNoShow:"osób nieoznaczonych dziś",trendsHead:"Trendy",last7:"Ostatnie 7 dni",topActs:"Najpopularniejsze",lowActs:"Najmniej popularne",bookingTrend:"Rezerwacje dziennie",myAttendance:"Moja obecność",myFeedback:"Moje opinie",noMyFeedback:"Brak opinii",askManager:"Zapytaj menedżera",myRequestsTeam:"Moje prośby",newTeamReq:"Nowa prośba",reqDayOff:"Zmiana dnia wolnego",reqProblem:"Zgłoś problem",reqCannot:"Nie mogę poprowadzić zajęć",reqOther:"Coś innego",reqDetail:"Napisz do menedżera",reqDateOpt:"Który dzień (opcjonalnie)",teamRequests:"Prośby zespołu",noTeamReqs:"Brak próśb od zespołu",reqApprove:"Zatwierdź",reqDecline:"Odrzuć",reqReply:"Odpowiedź (opcjonalnie)",statusOk:"Zatwierdzone",statusNo:"Odrzucone",reqSent:"Wysłano do menedżera",thankYou:"Dziękujemy!",shareExp:"Chcesz podzielić się wrażeniami?",reviewLater:"Może później",howWasIt:"Jak było?",qrTab:"Kod QR",qrHint:"Wydrukuj i umieść przy basenie, barze i recepcji",qrDownload:"Otwórz stronę do druku",stayEnded:"Twój pobyt zakończony — dziękujemy za wizytę!",accountOff:"To konto jest nieaktywne. Zapytaj menedżera.",activeAcc:"Konto aktywne",inactiveAcc:"Nieaktywne",deactivate:"Dezaktywuj",activate:"Aktywuj",resetPass:"Zresetuj hasło",newPassIs:"Nowe hasło",passCopied:"Przekaż to tej osobie — zastępuje stare",tooManyTries:"Zbyt wiele prób. Poczekaj chwilę.",logoLbl:"Logo",logoHint:"Pokazywane na ekranie logowania",hotelNameLbl:"Nazwa hotelu",timezoneLbl:"Strefa czasowa hotelu",timezoneHint:"Godziny i alarmy według zegara hotelu, nie telefonu gościa",currencyLbl:"Waluta",contactLbl:"Kontakt",fontSizeLbl:"Wielkość tekstu",fsSmall:"Mały",fsNormal:"Normalny",fsLarge:"Duży",fsXl:"Bardzo duży",autoDarkLbl:"Tryb ciemny jak w telefonie",featuresLbl:"Funkcje",featQuiz:"Quiz dnia",featTickets:"Bilety",featGallery:"Zdjęcia",featBus:"Rozkład autobusu",featInfo:"Informacje o hotelu",previewTheme:"Podgląd",applyTheme:"Użyj tego motywu",previewOn:"Podgląd — jeszcze nie zapisano",secIdentity:"Dane hotelu",secLook:"Wygląd",secAccess:"Dostęp",upToToday:"do dziś",countedDays:"Policzone dni",workingEntToday:"Animatorzy pracujący dziś",weatherTab:"Pogoda",weatherToday:"Dziś",weatherWeek:"W tym tygodniu",weatherFail:"Pogoda niedostępna",feelsLike:"Odczuwalna",windLbl:"Wiatr",latLbl:"Szerokość",lonLbl:"Długość",weatherLoc:"Lokalizacja pogody",weatherLocHint:"Współrzędne hotelu (domyślnie Hurghada)",wSun:"Słonecznie",wPartly:"Częściowe zachmurzenie",wCloud:"Pochmurno",wFog:"Mgła",wDrizzle:"Mżawka",wRain:"Deszcz",wShower:"Przelotne opady",wSnow:"Śnieg",wStorm:"Burza",wWind:"Wietrznie",setBrand:"Marka i tożsamość",setBrandSub:"Logo, nazwa hotelu, kontakt",setTheme:"Motyw i kolory",setThemeSub:"Kolory, czcionki, wielkość tekstu, tryb ciemny",setMenus:"Menu i strony",setMenusSub:"Zmiana nazw, kolejność, własne strony",setNotif:"Powiadomienia",setNotifSub:"Dźwięk i alerty",setLinksT:"Linki i opinie",setLinksSub:"Social media i serwisy opinii",setFeatures:"Funkcje",setFeaturesSub:"Włącz lub wyłącz części aplikacji",setLocation:"Lokalizacja i czas",setLocationSub:"Strefa czasowa i lokalizacja pogody",setAdvanced:"Zaawansowane",setAdvancedSub:"Bezpieczny serwer, AI, kod QR",setData:"Dane",setDataSub:"Eksport wszystkiego do Excel lub PDF",addTime:"Dodaj kolejną godzinę",timesLbl:"Godziny otwarcia",guestCrm:"Profile gości",crmSearch:"Szukaj pokoju, imienia lub narodowości",guest360:"Profil gościa",stayLen:"Pobyt",nights:"nocy",attendedActs:"Odwiedzone zajęcia",favActs:"Ulubione zajęcia",msgCount:"Wiadomości",quizPart:"Odpowiedzi w quizie",appUsage:"Dni w aplikacji",noGuests:"Brak gości",openProfile:"Otwórz profil",taskPriority:"Priorytet",prLow:"Niski",prNormal:"Normalny",prHigh:"Wysoki",prUrgent:"Pilny",taskLoc:"Miejsce",taskDeadline:"Termin",stNew:"Nowe",stAccepted:"Przyjęte",stProgress:"W trakcie",stCompleted:"Ukończone",stVerified:"Zweryfikowane",overdue:"Po terminie",acceptTask:"Przyjmij",startTask:"Rozpocznij",completeTask:"Zakończ",verifyTask:"Zweryfikuj",taskProof:"Zdjęcie dowodowe",taskComments:"Komentarze",addComment:"Dodaj komentarz",taskHistory:"Historia",createdBy:"Utworzone przez",noTasks:"Brak zadań",employeeProfile:"Profil pracownika",employeeId:"ID pracownika",positionLbl2:"Stanowisko",phoneLbl2:"Telefon",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Data zatrudnienia",suspend:"Zawieś",assignedActs:"Przypisane zajęcia",performance:"Wyniki",guestRatings:"Oceny gości",pointsLbl:"Punkty",rankLbl:"Miejsce",tasksDone:"Ukończone zadania",onTime:"Na czas",viewProfile:"Zobacz profil",photosLbl:"Zdjęcia",addPhotos:"Dodaj zdjęcia",removePhoto:"Usuń zdjęcie",cropLogo:"Przytnij logo",cropHint:"Przeciągnij, suwak do powiększenia",useCrop:"Użyj tego",removeLogo:"Usuń logo",photoOf:"z",requestChange:"Poproś o zmianę",changeRequest:"Prośba o zmianę",whatToChange:"Co należy zmienić?",reqSentMgr:"Wysłano do menedżera",profileReadOnly:"Tylko menedżer może to zmienić",pageBuilder:"Kreator stron",pbHint:"Zbuduj stronę z bloków — bez kodu",pbNewPage:"Nowa strona",pbEditPage:"Edytuj stronę",pbBlocks:"Bloki",pbAddBlock:"Dodaj blok",blkHeading:"Nagłówek",blkText:"Tekst",blkImage:"Obraz",blkGallery:"Galeria",blkButton:"Przycisk",blkDivider:"Linia",blkSpacer:"Odstęp",blkCard:"Karta",blkList:"Lista",blkVideo:"Wideo",blkMap:"Mapa",pbContent:"Treść",pbStyle:"Styl",fontSizeB:"Wielkość czcionki",fontFamilyB:"Czcionka",alignLbl:"Wyrównanie",alignLeft:"Lewo",alignCenter:"Środek",alignRight:"Prawo",colorLbl:"Kolor",bgLbl:"Tło",btnShape:"Kształt przycisku",shapeRound:"Zaokrąglony",shapePill:"Pigułka",shapeSquare:"Kwadratowy",btnSize:"Wielkość przycisku",sizeS:"Mały",sizeM:"Średni",sizeL:"Duży",btnLink:"Link (opcjonalnie)",boldLbl:"Pogrubienie",moveBlockUp:"W górę",moveBlockDown:"W dół",dupBlock:"Duplikuj",delBlock:"Usuń blok",pbPreview:"Podgląd",pbEmpty:"Strona jest pusta — dodaj pierwszy blok",pbSaved:"Strona zapisana",listItems:"Jedna pozycja na wiersz",videoUrl:"Link do wideo (YouTube)",mapAddr:"Adres lub miejsce",pbWho:"Kto widzi",pbIcon:"Ikona",pbTitle:"Tytuł strony",persons:"Liczba osób",personsShort:"os.",attN:"Jeszcze nie zatrudniony",notHiredYet:"Przed datą zatrudnienia",mapTab:"Mapa na żywo",shareLoc:"Udostępnij moją lokalizację",shareLocHint:"Tylko gdy włączone. Wyłącz kiedy chcesz — lokalizacja zostanie usunięta.",locDenied:"Odmówiono dostępu do lokalizacji na tym telefonie",noOneSharing:"Nikt teraz nie udostępnia lokalizacji",lastSeen:"Zaktualizowano",mapHint:"Widoczne są tylko osoby, które włączyły udostępnianie",minsAgo:"min temu",justNow:"przed chwilą",locTeam:"Zespół",locGuests:"Goście",assignCenter:"Przydziały",asgActs:"Aktywności",asgWho:"Kto co potrafi",asgOpen:"Jeszcze nikt",asgNobody:"Jeszcze nikt",allAssigned:"Wszystko przydzielone",autoAssign:"Przydziel automatycznie",autoAssignHint:"Używa planu dnia, wolnych, nieobecności i umiejętności.",autoReviewHint:"Sprawdź propozycje, zmień kogo chcesz, potem zastosuj.",applyAssign:"Zastosuj",asgApplied:"przydzielono",asgSkip:"Zostaw puste",asgNoSkill:"Nikt dostępny tego nie potrafi",asgAllBusy:"Wszyscy zdolni są zajęci",nobodyWorking:"Tego dnia nikt nie pracuje",asgWhoHint:"Dotknij osobę, aby ustawić umiejętności",noSkillsSet:"Nic nie ustawiono — można przydzielić wszystko",skillEditHint:"Raz = potrafi. Drugi raz = nie potrafi. Trzeci = wyczyść.",skCan:"potrafi",skCant:"nie potrafi",skAny:"—",sk_sport:"Sport",sk_water:"Woda",sk_dance:"Taniec",sk_show:"Show",sk_kids:"Dzieci",sk_music:"Muzyka",sk_dj:"DJ",sk_games:"Gry",sk_fitness:"Fitness",sk_host:"Prowadzenie",sk_craft:"Rękodzieło",sk_beach:"Plaża",needsSkill:"Wymagana umiejętność",noActsYet:"Najpierw dodaj aktywności do programu — potem zaznaczysz, kto co potrafi.",canRunIt:"potrafi",editDayOff:"Zmień dzień wolny",noOneEntrance:"Nikt nie ustawiony",teamChatTab:"Wiadomości zespołu",guestChatTab:"Wiadomości gości",attV:"Urlop",attLeft:"Opuścił hotel",markLeft:"Opuścił hotel",markLeftHint:"Obecność zostaje zachowana. Numer zwalnia się.",leftDate:"Ostatni dzień pracy",undoLeft:"Wrócił",leftTag:"Odszedł",startPage:"Strona startowa",startPageHint:"Po otwarciu aplikacji trafisz tutaj.",todayWord:"Dziś",yesterdayWord:"Wczoraj",practiceDays:"Pn / Śr / Pt",arrangeSections:"Ułóż tę stronę",arrangeHint:"Przesuwaj części tej strony w górę lub w dół. Zapisane dla wszystkich.",dayInfoSec:"Informacje o dniu",wholeDay:"Cały dzień",morningPart:"Rano",afternoonPart:"Popołudnie",eveningPart:"Wieczór",itemsWord:"pozycji",editBooking:"Edytuj rezerwację",openGuest:"Otwórz profil gościa",bookedAt:"Zarezerwowano",booked:"Zarezerwowany",waitlist:"Lista oczekujących",status:"Status",standardsHead:"Standardy dnia",noGuestAccount:"Brak konta gościa dla tego pokoju",finishedChip:"Zakończone",setVacation:"Ustaw urlop",setVacationHint:"Wybierz osobę oraz pierwszy i ostatni dzień.",clearVacation:"Usuń urlop",person:"Osoba",fromDate:"Od",toDate:"Do",daysWord:"dni",checkDates:"Sprawdź daty",dayWord:"Dzień",nightsWord:"nocy",nightsLeft:"nocy zostało",stayDayOf:"Dzień {n} z {t}",stayWelcome:"Witamy — Twój urlop zaczyna się dziś",stayLastDay:"Ostatni dzień — mamy nadzieję, że było miło",plannedAhead:"Zaplanowane",addMember:"Dodaj członka",addAttOnly:"Tylko obecność",addAttOnlyHint:"Tylko imię i numer (11–50) do listy obecności. Bez logowania, bez aktywności, nie liczy się do zespołu.",attNumber:"Numer (11–50)",attNumRange:"Numer musi być od 11 do 50",numberTaken:"Ten numer jest już zajęty",nameNeeded:"Wpisz imię",attOnlyTag:"· tylko obecność",whichMonth:"Który miesiąc",whichDay:"Który dzień",selectMsgs:"Zaznacz wiadomości",clearChat:"Wyczyść czat",selectedWord:"zaznaczono",selectAll:"Zaznacz wszystkie",selectNone:"Odznacz wszystkie",deleteMsgsQ:"Usunąć {n} wiadomości?",clearChatQ:"Wyczyścić cały czat?",clearChatHint:"Wszystkie {n} wiadomości zostaną usunięte dla wszystkich.",cannotUndo:"Tego nie można cofnąć.",deleteReqQ:"Usunąć tę prośbę?",allDays:"Wszystkie dni",whichTime:"Która pora",allDayLong:"Cały dzień",filterNote:"Eksport tylko:",noFilterNote:"Eksport wszystkiego.",officialAtt:"{hotel} — Oficjalna miesięczna obecność",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"Pierwszy dzień",lastDayOpt:"Ostatni dzień (opcjonalnie)",attDatesHint:"Dni przed pierwszym i po ostatnim dniu nie są liczone.",delete:"Usuń",deleteQ:"Usunąć tę osobę?",attDeleteHint:"Jej obecność też zostanie usunięta. Zamiast tego ustaw ostatni dzień, aby ją zachować.",eventsCrewTag:"Wszystkie wydarzenia i show",eventsCrewHint:"Ta osoba jest na każdym wydarzeniu i pokazie — DJ dla muzyki, social media do filmowania. Nie jest w grafiku aktywności, więc nie ma tu nic do zaznaczenia.",wasBooked:"Byłeś zapisany",bookNowLive:"Trwa — dołącz",removeBooking:"Usuń rezerwację",removeBookingQ:"Usunąć tę rezerwację?",removeBookingHint:"Gość traci miejsce. Nie można cofnąć.",skillEditHint2:"Zaznacz aktywności z programu. Raz = potrafi. Drugi raz = nie potrafi. Trzeci = wyczyść.",autoAssign:"Automatyczny przydział zajęć",autoHint:"Po jednym zajęciu rano i po południu — sprawiedliwie. Wydarzenia robi cały zespół, Ty i DJ nie są przydzielani.",autoDay:"Ten dzień",autoWeek:"Cały tydzień",onlyEmptyLbl:"Tylko zajęcia bez przydziału",replaceAllLbl:"Zastąp wszystko",autoPreview:"Propozycja",autoApply:"Zastosuj plan",autoNothing:"Nie ma czego przydzielić — sprawdź dni wolne i program",autoDone:"Zajęcia przydzielone",morningSlot:"Rano",afternoonSlot:"Popołudnie",perPerson:"Na osobę",noOneAvailable:"Tego dnia nikogo nie ma",eventsAllTeam:"Wydarzenia — cały zespół",changeWho:"Zmień",noneAssigned:"— nikt —",balanceLbl:"Balans",evenSpread:"Równo podzielone",spreadOff:"Różnica",editHint:"Dotknij imienia, aby zmienić przed zastosowaniem",recalc:"Przelicz ponownie",fairest:"Najsprawiedliwiej",activityCount:"zajęć",zoomLbl:"Powiększenie",totalAllTeam:"Cały zespół (z menedżerem)",infoTime:"Godziny",infoPlace:"Miejsce",translateBtn:"Tłumacz",translating:"Tłumaczenie...",translateFail:"Nie udało się przetłumaczyć",showOriginal:"Pokaż oryginał",builderTab:"Kreator menu",builderHint:"Zmień nazwę, kolejność, ukryj lub dodaj pozycje — dla każdej roli, bez kodu",forRole:"Dla",roleGuest:"Goście",roleStaff:"Animatorzy",roleManager:"Menedżer",moveUp:"W górę",moveDown:"W dół",hideItem:"Ukryte",showItem:"Widoczne",renameItem:"Nazwa",addLink:"Dodaj własną stronę",linkTitle:"Tytuł",linkUrl:"Adres web",linkText:"Tekst do pokazania",linkKind:"Typ",kindLink:"Link",kindPage:"Strona tekstowa",resetMenu:"Przywróć domyślne",builderSaved:"Menu zaktualizowane",customPage:"Moja strona",openLink:"Otwórz",translatedTag:"Przetłumaczono",infoPhoto:"Zdjęcie",totalRow:"RAZEM",months:["Styczeń","Luty","Marzec","Kwiecień","Maj","Czerwiec","Lipiec","Sierpień","Wrzesień","Październik","Listopad","Grudzień"],statusLegend:"Status",almSoonG:"Start za 5 min",almStartG:"Zaczyna się teraz",almDoneG:"Zakończone",almSoonS:"Twoja aktywność za 5 min — bądź na miejscu",almStartS:"Twoja aktywność się zaczyna",almDoneS:"Zakończone — zbierz opinię z numerem pokoju",almSoonTeam:"Start za 5 min",almStartTeam:"Zaczyna się teraz",almDoneTeam:"Zakończone",secProgram:"Program",secBookings:"Moje rezerwacje",secConnect:"Social i zespół",secManage:"Zarządzanie",secTeamwork:"Moja praca",secGuests:"Goście",secSettings:"Ustawienia",uploadErr:"Przesyłanie nie powiodło się — sprawdź Storage",photo:"Zdjęcie",uploadPhoto:"Dotknij, aby przesłać zdjęcie",changePhoto:"Zmień zdjęcie"},EXTRA.pl),
cs:Object.assign({appSub:"Animační tým",guest:"Host",staff:"Tým",manager:"Manažer",room:"Číslo pokoje",name:"Vaše jméno",phone:"Mobilní telefon",user:"Uživatelské jméno",pass:"Heslo",signin:"Přihlásit se",welcome:"Vítejte",today:"Dnes",highlight:"Zážitek dne",todayProgram:"Dnešní program",week:"Týdenní program",myStay:"Můj pobyt",home:"Domů",program:"Program",bookings:"Rezervace",myBookings:"Moje rezervace",favorites:"Oblíbené",book:"Rezervovat",booked:"Rezervováno",full:"Obsazeno",waitlist:"Na čekací listinu",onWaitlist:"Na čekací listině",cancel:"Zrušit rezervaci",seatsLeft:"volných míst",adults:"Dospělí",children:"Děti",confirm:"Potvrdit rezervaci",close:"Zavřít",days:["Pondělí","Úterý","Středa","Čtvrtek","Pátek","Sobota","Neděle"],daysShort:["Po","Út","St","Čt","Pá","So","Ne"],cats:{morning:"Ráno",afternoon:"Odpoledne",evening:"Večer",kids:"Dětský klub",theme:"Tematický den",mKids:"Aktivity pro děti",mTeen:"Aktivity pro teenagery",mAdult:"Aktivity",mEvents:"Akce",eKidsStage:"Dětské pódium",eLive:"Živé pódium",eBefore:"Před show",eShow:"Show",eAfter:"Po show",eParty:"Párty"},guests:"hostů",noBookings:"Zatím žádné rezervace. Prohlédněte si dnešní program!",noFavs:"Zatím žádné oblíbené. Klepněte na srdíčko u aktivity.",schedule:"Rozvrh",team:"Tým",guestsBooked:"Přihlášení hosté",noneToday:"Dnes tu není nic naplánováno.",dashboard:"Přehled",manage:"Program",totalBookings:"Rezervace tento týden",activities:"Aktivity",occupancy:"Prům. obsazenost",waitlisted:"Na čekacích listinách",addActivity:"Přidat aktivitu",editActivity:"Upravit aktivitu",deleteActivity:"Smazat",actName:"Název aktivity",desc:"Popis",location:"Místo",time:"Čas",capacity:"Kapacita",entertainer:"Animátor(ři)",imageUrl:"Odkaz na fotku (volitelné)",category:"Kategorie",day:"Den",makeHighlight:"Zážitek dne",save:"Uložit",saved:"Uloženo",deleted:"Smazáno",bookingOk:"Rezervace potvrzena!",waitOk:"Přidáno na čekací listinu",cancelled:"Zrušeno",loginErr:"Zkontrolujte údaje a zkuste to znovu.",demoNote:"Režim náhledu s ukázkovými daty — připojte Supabase v souboru.",reviews:"Líbí se vám dovolená?",reviewsSub:"Podělte se o zkušenost — pro náš tým to hodně znamená.",followUs:"Sledujte náš tým",none:"—",arrival:"Den příjezdu",departure:"Den odjezdu",otherUsers:"Přístup pro tým",backToGuest:"← Přihlášení hosta",usersTab:"Účty",appTab:"App",appName:"Název aplikace",appSubtitle:"Podtitul",colorsHead:"Barvy",primaryC:"Hlavní barva",accentC:"Barva akcentu",linksHead:"Odkazy na recenze",socialHead:"Sociální sítě",addUser:"Přidat uživatele",displayName:"Zobrazované jméno",roleLabel:"Role",teamAccounts:"Účty týmu",guestStats:"Statistiky hostů",uniqueGuests:"Pokoje hostů",totalPeople:"Přihlášené osoby",language:"Jazyk",userExists:"Uživatelské jméno již existuje",tickets:"Vstupenky",buyTicket:"Koupit vstupenku",myTickets:"Moje vstupenky",price:"Cena",qty:"Počet",reserved:"Rezervováno",paid:"Zaplaceno",payNote:"Rezervujte v aplikaci a zaplaťte u animačního stánku nebo na recepci.",ticketOk:"Vstupenka rezervována!",nationality:"Národnost",natStats:"Národnosti",addTicket:"Přidat akci",editTicket:"Upravit akci",markPaid:"Označit jako zaplacené",markReserved:"Označit jako rezervaci",styleHead:"Styl písma",buttonHead:"Styl tlačítek",menuHead:"Názvy menu",bgC:"Pozadí",fontElegant:"Elegantní",fontRoyal:"Královský",fontModern:"Moderní",fontSoft:"Jemný",btnRounded:"Zaoblené",btnPill:"Pilulka",btnSquare:"Hranaté",ticketsNone:"Zatím žádné akce se vstupenkami.",orders:"Objednávky",soldOut:"Vyprodáno",opMorning:"Ranní program",opAfternoon:"Odpolední program",opEvening:"Večerní program",opDaytime:"Denní aktivity",opDayEvents:"Denní akce",opSpecial:"Speciální akce",startTime:"Začátek",endTime:"Konec",operation:"Program",chooseCat:"Vyberte kategorii",backToCats:"Všechny kategorie",myActs:"Moje aktivity",myActsSub:"Aktivity přiřazené vám",chatManager:"Napsat manažerovi",teamChat:"Týmový chat",editMsg:"Upravit zprávu",deleteMsg:"Smazat zprávu",noStaffMsg:"Zatím žádné zprávy. Pozdravte svého manažera!",shirtNumber:"Číslo dresu",myWorkDay:"Můj pracovní den",dayPlan:"Denní plán",dayOff:"Volný den",entranceDuty:"Služba u vchodu",dressCode:"Dress code",restaurantTheme:"Téma restaurace",dailyStandards:"Denní rozvrh",eveningShowLbl:"Večerní show",liveBandLbl:"Živá kapela",makeupPractice:"Náhradní trénink",practiceToday:"Týmový trénink dnes (45 min - Po/St/Pá)",youAreOff:"Dnes máš volno - užij si den!",youHaveEntrance:"Dnes máš službu u vchodu",teamPlanFull:"Celý týdenní plán",selectDay:"Vyber den",noNumber:"Číslo není nastaveno - zeptej se manažera",djSchedule:"Rozvrh DJ",std_breakfast:"Snídaně",std_mmeet:"Ranní porada",std_start:"Start — připraveni na pozicích",std_lunch:"Oběd",std_fmorning:"Konec ranního provozu",std_ameet:"Odpolední porada",std_fafternoon:"Konec odpoledního provozu",std_dinner:"Večeře",std_stage:"Pódium se otevírá",std_emeet:"Večerní porada",std_yoga:"Host jógy/západu odchází dříve",std_fevening:"Konec večerního provozu",n_sport:"Sportovní uniforma",n_mact:"Ranní aktivity 10:00–12:30",n_practice:"13:15 v Po / St / Pá (45min trénink)",n_aact:"Odpolední aktivity 15:00–17:00",n_yogahost:"17:15 pro hosta jógy/západu",n_eshow:"Večerní show a živá hudba od 20:00",n_special:"23:30 ve dnech speciálních akcí (např. Beach Party)",practiceInline:"13:15 dnes — 45min trénink",dj_wed:"Bez odpolední směny — příchod 16:30 na Sunset Instrument Party (17:00–19:00), do konce (23:00)",dj_thu:"Volný den — živá kapela hraje hudbu (jen 1 akce: Foam Party)",dj_other:"Odchod 16:30, návrat na 19:00 k otevření pódia",trainsToday:"dnes trénuje individuálně",busTimes:"Časy autobusu",busSchedule:"Jízdní řád autobusu pro personál",busToHotel:"Dům personálu → Hotel",busToHouse:"Hotel → Dům personálu",busEditHint:"Jeden čas odjezdu na řádek",noBusTimes:"Zatím žádné časy — přidejte je v nastavení aplikace.",busNextHint:"Příští odjezd",addBus:"Přidat autobus",editBus:"Upravit autobus",busDirection:"Směr",busTimeLbl:"Čas odjezdu",busNoteLbl:"Poznámka (volitelné)",busNoteHint:"např. jen v pátek",settingsHub:"Nastavení",appSettingsItem:"Vzhled a nastavení aplikace",aiItem:"AI asistent",exportItem:"Export dat (Excel/PDF)",busItem:"Jízdní řád autobusu",settingsSub:"Vše pro správu a přizpůsobení aplikace",st_todo:"Nezačato",st_live:"Probíhá",st_done:"Dokončeno",cancelBtn:"Zrušit",confirmTitle:"Opravdu?",cannotUndo:"Tuto akci nelze vrátit zpět.",delActivityQ:"Smazat tuto aktivitu?",delUserQ:"Smazat tento účet?",delReqQ:"Smazat toto přání?",delBusQ:"Smazat tento autobus?",delMsgQ:"Smazat tuto zprávu?",offlineMsg:"Offline — zobrazuji poslední data",backOnlineMsg:"Zpět online — synchronizuji...",loadingMsg:"Načítání...",errSave:"Nepodařilo se uložit. Zkuste to znovu.",errNet:"Bez připojení. Zkontrolujte internet.",fieldRequired:"Vyplňte prosím",invalidTime:"Formát 08:00",invalidNumber:"Zadejte platné číslo",updateReady:"Je dostupná nová verze — otevřete aplikaci znovu",serverHead:"Zabezpečený server (volitelné)",serverHint:"Vložte odkazy na Supabase Edge Function. Klíč AI pak zůstane na serveru, ne v telefonu.",errHttps:"Odkaz musí začínat https://",noDataTitle:"Připojeno, ale bez dat",noDataMsg:"Aplikace se spojila s databází, ale nic nedostala — obvykle pravidla přístupu. Spusťte opravný skript v Supabase a načtěte znovu.",noDataRooms:"Nenalezeny žádné pokoje",eventsToday:"Akce dnes",noEventsToday:"Dnes žádná speciální akce",practiceHead:"Týmový trénink",practiceWindow:"12:30 – 13:15 (45 min)",makeupWindow:"45 min — individuálně",aiEndpointErr:"Odkaz na server není dostupný — zkontrolujte nasazení nebo pole vymažte",aiEndpointFallback:"Server nedostupný — používám klíč v tomto zařízení",themeHead:"Motiv aplikace",themeHint:"Každý motiv má světlou a tmavou verzi — přepínejte sluncem/měsícem v menu.",themeCustom:"Vlastní barvy",themeLight:"Světlý",themeDark:"Tmavý",quizTab:"Kvíz dne",quizToday:"Otázka dne",quizAnswerPh:"Tvoje odpověď...",quizSend:"Odeslat odpověď",quizDone:"Odpovězeno — děkujeme!",quizNone:"Dnes žádná otázka. Přijď zítra!",quizMine:"Tvoje odpověď",quizCenter:"Centrum kvízu",quizNew:"Nová otázka",quizFor:"Pro",quizForGuest:"Hosté",quizForStaff:"Animátoři",quizQuestion:"Otázka",quizHint:"Nápověda (volitelné)",quizKey:"Správná odpověď (vidíte jen vy)",quizReplies:"Odpovědi",quizNoReplies:"Zatím žádné odpovědi",quizSaved:"Otázka zveřejněna",quizAlready:"Dnes jsi už odpověděl",todayPlanExp:"Dnešní plán (pro vedení)",navBack:"Zpět",navForward:"Vpřed",genderLbl:"Pohlaví",genderM:"Muž",genderF:"Žena",genderNone:"Neuvedeno",teamSummary:"Přehled týmu",totalEntertainers:"Celkem animátorů",byGender:"Podle pohlaví",byNationality:"Podle národnosti",teamOverview:"Přehled týmu",typeNationality:"Zadejte národnost",natOtherHint:"Není v seznamu? Zvolte Jiné a napište.",editDuty:"Upravit volno a vchod",dutyFor:"Služba na",selectDayOff:"Kdo má volno",selectEntrance:"Služba u vchodu",resetDefault:"Obnovit standardní plán",customDay:"Změněno",standardDay:"Standardní plán",workingToday:"V práci",dayOffToday:"Volno",totalTeam:"Tým celkem",dutySaved:"Služba aktualizována",noOneOff:"Nikdo nemá volno",monthAtt:"Měsíční docházka",attP:"Přítomen",attO:"Volno",attA:"Nepřítomen",attLegend:"P = přítomen · O = volno · A = nepřítomen",attTapHint:"Klepnutím na den jej změníte. Šedá je z plánu.",attAuto:"Z plánu",attTotalsP:"Pracovní dny",attTotalsO:"Volné dny",attTotalsA:"Absence",attExport:"Měsíční docházkový list",prevMonth:"Předchozí měsíc",nextMonth:"Další měsíc",attSaved:"Docházka aktualizována",workDays:"Pracovní dny",monthTotals:"Měsíční souhrn",teamWorkDays:"Pracovní dny týmu",avgPerPerson:"Průměr na osobu",hotelInfoTab:"Informace o hotelu",hotelInfoHint:"Otevírací doba, WiFi a nejčastější dotazy hostů",addInfo:"Přidat informaci",infoTitle:"Název",infoValue:"Podrobnosti",noInfo:"Zatím žádné informace",galleryTab:"Fotky",galleryHint:"Fotky z našich show a aktivit",addPhoto:"Přidat fotku",noPhotos:"Zatím žádné fotky — zastavte se po večerní show!",photoCaption:"Popisek (volitelné)",attentionHead:"Vyžaduje pozornost",allGood:"Vše v pořádku",attEmptyAct:"aktivit dnes bez rezervace",attWaitReq:"přání hostů čeká",attLowRate:"nízkých hodnocení tento týden",attStaffReq:"žádostí týmu čeká",attNoShow:"členů týmu dnes neoznačeno",trendsHead:"Trendy",last7:"Posledních 7 dní",topActs:"Nejoblíbenější",lowActs:"Nejméně oblíbené",bookingTrend:"Rezervace denně",myAttendance:"Moje docházka",myFeedback:"Moje hodnocení",noMyFeedback:"Zatím žádné hodnocení",askManager:"Zeptat se manažera",myRequestsTeam:"Moje žádosti",newTeamReq:"Nová žádost",reqDayOff:"Změna volna",reqProblem:"Nahlásit problém",reqCannot:"Nemohu vést aktivitu",reqOther:"Něco jiného",reqDetail:"Napiš manažerovi",reqDateOpt:"Který den (volitelné)",teamRequests:"Žádosti týmu",noTeamReqs:"Žádné žádosti od týmu",reqApprove:"Schválit",reqDecline:"Zamítnout",reqReply:"Odpověď (volitelné)",statusOk:"Schváleno",statusNo:"Zamítnuto",reqSent:"Odesláno manažerovi",thankYou:"Děkujeme!",shareExp:"Chcete se podělit o zážitek?",reviewLater:"Možná později",howWasIt:"Jaké to bylo?",qrTab:"QR kód",qrHint:"Vytiskněte a umístěte k bazénu, baru a recepci",qrDownload:"Otevřít stránku k tisku",stayEnded:"Váš pobyt skončil — děkujeme za návštěvu!",accountOff:"Tento účet není aktivní. Zeptejte se manažera.",activeAcc:"Účet aktivní",inactiveAcc:"Neaktivní",deactivate:"Deaktivovat",activate:"Aktivovat",resetPass:"Obnovit heslo",newPassIs:"Nové heslo",passCopied:"Předejte to dané osobě — nahrazuje staré",tooManyTries:"Příliš mnoho pokusů. Chvíli počkejte.",logoLbl:"Logo",logoHint:"Zobrazí se na přihlašovací obrazovce",hotelNameLbl:"Název hotelu",timezoneLbl:"Časové pásmo hotelu",timezoneHint:"Časy a upozornění podle hodin hotelu, ne telefonu hosta",currencyLbl:"Měna",contactLbl:"Kontakt",fontSizeLbl:"Velikost písma",fsSmall:"Malé",fsNormal:"Normální",fsLarge:"Velké",fsXl:"Velmi velké",autoDarkLbl:"Tmavý režim podle telefonu",featuresLbl:"Funkce",featQuiz:"Kvíz dne",featTickets:"Vstupenky",featGallery:"Fotky",featBus:"Jízdní řád",featInfo:"Informace o hotelu",previewTheme:"Náhled",applyTheme:"Použít tento motiv",previewOn:"Náhled — zatím neuloženo",secIdentity:"Identita hotelu",secLook:"Vzhled",secAccess:"Přístup",upToToday:"do dneška",countedDays:"Započtené dny",workingEntToday:"Animátoři dnes v práci",weatherTab:"Počasí",weatherToday:"Dnes",weatherWeek:"Tento týden",weatherFail:"Počasí není dostupné",feelsLike:"Pocitově",windLbl:"Vítr",latLbl:"Zeměpisná šířka",lonLbl:"Zeměpisná délka",weatherLoc:"Místo pro počasí",weatherLocHint:"Souřadnice hotelu (výchozí Hurghada)",wSun:"Slunečno",wPartly:"Polojasno",wCloud:"Zataženo",wFog:"Mlha",wDrizzle:"Mrholení",wRain:"Déšť",wShower:"Přeháňky",wSnow:"Sníh",wStorm:"Bouřka",wWind:"Větrno",setBrand:"Značka a identita",setBrandSub:"Logo, název hotelu, kontakt",setTheme:"Motiv a barvy",setThemeSub:"Barvy, písma, velikost textu, tmavý režim",setMenus:"Menu a stránky",setMenusSub:"Přejmenování, pořadí, vlastní stránky",setNotif:"Oznámení",setNotifSub:"Zvuk a upozornění",setLinksT:"Odkazy a recenze",setLinksSub:"Sociální sítě a recenzní weby",setFeatures:"Funkce",setFeaturesSub:"Zapnout nebo vypnout části aplikace",setLocation:"Místo a čas",setLocationSub:"Časové pásmo a místo pro počasí",setAdvanced:"Pokročilé",setAdvancedSub:"Zabezpečený server, AI, QR kód",setData:"Data",setDataSub:"Export všeho do Excelu nebo PDF",addTime:"Přidat další čas",timesLbl:"Otevírací doba",guestCrm:"Profily hostů",crmSearch:"Hledat pokoj, jméno nebo národnost",guest360:"Profil hosta",stayLen:"Pobyt",nights:"nocí",attendedActs:"Navštívené aktivity",favActs:"Oblíbené aktivity",msgCount:"Zprávy",quizPart:"Odpovědi v kvízu",appUsage:"Dní v aplikaci",noGuests:"Zatím žádní hosté",openProfile:"Otevřít profil",taskPriority:"Priorita",prLow:"Nízká",prNormal:"Normální",prHigh:"Vysoká",prUrgent:"Urgentní",taskLoc:"Místo",taskDeadline:"Termín",stNew:"Nový",stAccepted:"Přijato",stProgress:"Probíhá",stCompleted:"Hotovo",stVerified:"Ověřeno",overdue:"Po termínu",acceptTask:"Přijmout",startTask:"Začít",completeTask:"Dokončit",verifyTask:"Ověřit",taskProof:"Foto důkaz",taskComments:"Komentáře",addComment:"Přidat komentář",taskHistory:"Historie",createdBy:"Vytvořil",noTasks:"Žádné úkoly",employeeProfile:"Profil zaměstnance",employeeId:"ID zaměstnance",positionLbl2:"Pozice",phoneLbl2:"Telefon",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Datum nástupu",suspend:"Pozastavit",assignedActs:"Přiřazené aktivity",performance:"Výkon",guestRatings:"Hodnocení hostů",pointsLbl:"Body",rankLbl:"Pořadí",tasksDone:"Dokončené úkoly",onTime:"Včas",viewProfile:"Zobrazit profil",photosLbl:"Fotky",addPhotos:"Přidat fotky",removePhoto:"Odebrat fotku",cropLogo:"Oříznout logo",cropHint:"Táhnutím posuňte, posuvníkem přiblížíte",useCrop:"Použít",removeLogo:"Odebrat logo",photoOf:"z",requestChange:"Požádat o změnu",changeRequest:"Žádost o změnu",whatToChange:"Co se má změnit?",reqSentMgr:"Odesláno manažerovi",profileReadOnly:"Změnit může jen manažer",pageBuilder:"Návrhář stránek",pbHint:"Sestavte stránku z bloků — bez kódu",pbNewPage:"Nová stránka",pbEditPage:"Upravit stránku",pbBlocks:"Bloky",pbAddBlock:"Přidat blok",blkHeading:"Nadpis",blkText:"Text",blkImage:"Obrázek",blkGallery:"Galerie",blkButton:"Tlačítko",blkDivider:"Oddělovač",blkSpacer:"Mezera",blkCard:"Karta",blkList:"Seznam",blkVideo:"Video",blkMap:"Mapa",pbContent:"Obsah",pbStyle:"Styl",fontSizeB:"Velikost písma",fontFamilyB:"Písmo",alignLbl:"Zarovnání",alignLeft:"Vlevo",alignCenter:"Na střed",alignRight:"Vpravo",colorLbl:"Barva",bgLbl:"Pozadí",btnShape:"Tvar tlačítka",shapeRound:"Zaoblené",shapePill:"Pilulka",shapeSquare:"Hranaté",btnSize:"Velikost tlačítka",sizeS:"Malé",sizeM:"Střední",sizeL:"Velké",btnLink:"Odkaz (volitelné)",boldLbl:"Tučně",moveBlockUp:"Nahoru",moveBlockDown:"Dolů",dupBlock:"Duplikovat",delBlock:"Smazat blok",pbPreview:"Náhled",pbEmpty:"Stránka je prázdná — přidejte první blok",pbSaved:"Stránka uložena",listItems:"Jedna položka na řádek",videoUrl:"Odkaz na video (YouTube)",mapAddr:"Adresa nebo místo",pbWho:"Kdo to vidí",pbIcon:"Ikona",pbTitle:"Název stránky",persons:"Počet osob",personsShort:"os.",attN:"Ještě nenastoupil",notHiredYet:"Před datem nástupu",mapTab:"Živá mapa",shareLoc:"Sdílet moji polohu",shareLocHint:"Jen když je zapnuto. Kdykoli vypněte — poloha se smaže.",locDenied:"Přístup k poloze byl na tomto telefonu odmítnut",noOneSharing:"Nikdo právě nesdílí polohu",lastSeen:"Aktualizováno",mapHint:"Zobrazují se jen lidé, kteří sdílení zapnuli",minsAgo:"min zpět",justNow:"právě teď",locTeam:"Tým",locGuests:"Hosté",assignCenter:"Přiřazení",asgActs:"Aktivity",asgWho:"Kdo co umí",asgOpen:"Zatím nikdo",asgNobody:"Zatím nikdo",allAssigned:"Vše přiřazeno",autoAssign:"Přiřadit automaticky",autoAssignHint:"Používá denní plán, volna, absence a dovednosti.",autoReviewHint:"Zkontroluj návrhy, změň koho chceš, pak použij.",applyAssign:"Použít",asgApplied:"přiřazeno",asgSkip:"Nechat prázdné",asgNoSkill:"Nikdo dostupný to neumí",asgAllBusy:"Všichni schopní jsou zaneprázdněni",nobodyWorking:"Tento den nikdo nepracuje",asgWhoHint:"Klepni na osobu pro nastavení dovedností",noSkillsSet:"Nic nenastaveno — lze přiřadit cokoli",skillEditHint:"Jednou = umí. Podruhé = neumí. Potřetí = vymazat.",skCan:"umí",skCant:"neumí",skAny:"—",sk_sport:"Sport",sk_water:"Voda",sk_dance:"Tanec",sk_show:"Show",sk_kids:"Děti",sk_music:"Hudba",sk_dj:"DJ",sk_games:"Hry",sk_fitness:"Fitness",sk_host:"Moderování",sk_craft:"Tvoření",sk_beach:"Pláž",needsSkill:"Potřebná dovednost",noActsYet:"Nejprve přidej aktivity do programu — pak označíš, kdo co umí.",canRunIt:"to umí",editDayOff:"Upravit volno",noOneEntrance:"Nikdo nenastaven",teamChatTab:"Zprávy týmu",guestChatTab:"Zprávy hostů",attV:"Dovolená",attLeft:"Opustil hotel",markLeft:"Opustil hotel",markLeftHint:"Docházka zůstává. Číslo se uvolní.",leftDate:"Poslední pracovní den",undoLeft:"Vrátil se",leftTag:"Odešel",startPage:"Úvodní stránka",startPageHint:"Po otevření aplikace přistanete zde.",todayWord:"Dnes",yesterdayWord:"Včera",practiceDays:"Po / St / Pá",arrangeSections:"Uspořádat stránku",arrangeHint:"Posouvej části stránky nahoru nebo dolů. Uloženo pro všechny.",dayInfoSec:"Informace o dni",wholeDay:"Celý den",morningPart:"Ráno",afternoonPart:"Odpoledne",eveningPart:"Večer",itemsWord:"položek",editBooking:"Upravit rezervaci",openGuest:"Otevřít profil hosta",bookedAt:"Rezervováno",booked:"Rezervován",waitlist:"Čekací listina",status:"Stav",standardsHead:"Denní standardy",noGuestAccount:"Pro tento pokoj není účet hosta",finishedChip:"Skončilo",setVacation:"Nastavit dovolenou",setVacationHint:"Vyber osobu a první a poslední den.",clearVacation:"Zrušit dovolenou",person:"Osoba",fromDate:"Od",toDate:"Do",daysWord:"dní",checkDates:"Zkontroluj data",dayWord:"Den",nightsWord:"nocí",nightsLeft:"nocí zbývá",stayDayOf:"Den {n} z {t}",stayWelcome:"Vítejte — dovolená začíná dnes",stayLastDay:"Poslední den — doufáme, že bylo krásně",plannedAhead:"Naplánováno",addMember:"Přidat člena",addAttOnly:"Jen docházka",addAttOnlyHint:"Jen jméno a číslo (11–50) pro docházku. Bez přihlášení, bez aktivit, nepočítá se do týmu.",attNumber:"Číslo (11–50)",attNumRange:"Číslo musí být mezi 11 a 50",numberTaken:"Toto číslo je již obsazené",nameNeeded:"Zadej jméno",attOnlyTag:"· jen docházka",whichMonth:"Který měsíc",whichDay:"Který den",selectMsgs:"Vybrat zprávy",clearChat:"Vymazat chat",selectedWord:"vybráno",selectAll:"Vybrat vše",selectNone:"Zrušit výběr",deleteMsgsQ:"Smazat {n} zpráv?",clearChatQ:"Vymazat celý chat?",clearChatHint:"Všech {n} zpráv bude smazáno pro všechny.",cannotUndo:"Toto nelze vrátit.",deleteReqQ:"Smazat tuto žádost?",allDays:"Všechny dny",whichTime:"Která část dne",allDayLong:"Celý den",filterNote:"Exportuje se jen:",noFilterNote:"Exportuje se vše.",officialAtt:"{hotel} — Oficiální měsíční docházka",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"První den",lastDayOpt:"Poslední den (nepovinné)",attDatesHint:"Dny před prvním a po posledním dni se nepočítají.",delete:"Smazat",deleteQ:"Smazat tuto osobu?",attDeleteHint:"Smaže se i její docházka. Raději nastav poslední den, pokud ji chceš zachovat.",eventsCrewTag:"Všechny akce a show",eventsCrewHint:"Tato osoba je na každé akci a show — DJ kvůli hudbě, sociální sítě kvůli natáčení. Není v rozpisu aktivit, takže tu není co zaškrtávat.",wasBooked:"Byl jsi přihlášen",bookNowLive:"Probíhá — přidat se",removeBooking:"Odebrat rezervaci",removeBookingQ:"Odebrat tuto rezervaci?",removeBookingHint:"Host přijde o místo. Nelze vrátit.",skillEditHint2:"Označ aktivity z programu. Jednou = umí. Podruhé = neumí. Potřetí = vymazat.",autoAssign:"Automaticky přidělit aktivity",autoHint:"Jedna aktivita dopoledne a jedna odpoledne — spravedlivě. Akce dělá celý tým, ty a DJ nikdy nejste přiděleni.",autoDay:"Tento den",autoWeek:"Celý týden",onlyEmptyLbl:"Jen aktivity bez přidělení",replaceAllLbl:"Nahradit vše",autoPreview:"Návrh",autoApply:"Použít plán",autoNothing:"Není co přidělit — zkontroluj volna a program",autoDone:"Aktivity přiděleny",morningSlot:"Dopoledne",afternoonSlot:"Odpoledne",perPerson:"Na osobu",noOneAvailable:"Tento den nikdo není k dispozici",eventsAllTeam:"Akce — celý tým",changeWho:"Změnit",noneAssigned:"— nikdo —",balanceLbl:"Rovnováha",evenSpread:"Rovnoměrně",spreadOff:"Rozdíl",editHint:"Klepnutím na jméno jej změníte před použitím",recalc:"Přepočítat",fairest:"Nejspravedlivější",activityCount:"aktivit",zoomLbl:"Přiblížení",totalAllTeam:"Tým celkem (včetně manažera)",infoTime:"Otevírací doba",infoPlace:"Místo",translateBtn:"Přeložit",translating:"Překládám...",translateFail:"Nelze přeložit",showOriginal:"Zobrazit originál",builderTab:"Tvůrce menu",builderHint:"Přejmenujte, seřaďte, skryjte nebo přidejte položky — pro každou roli, bez kódu",forRole:"Pro",roleGuest:"Hosté",roleStaff:"Animátoři",roleManager:"Manažer",moveUp:"Nahoru",moveDown:"Dolů",hideItem:"Skryté",showItem:"Zobrazené",renameItem:"Název",addLink:"Přidat vlastní stránku",linkTitle:"Titulek",linkUrl:"Webová adresa",linkText:"Text k zobrazení",linkKind:"Typ",kindLink:"Odkaz",kindPage:"Textová stránka",resetMenu:"Obnovit výchozí",builderSaved:"Menu aktualizováno",customPage:"Moje stránka",openLink:"Otevřít",translatedTag:"Přeloženo",infoPhoto:"Fotka",totalRow:"CELKEM",months:["Leden","Únor","Březen","Duben","Květen","Červen","Červenec","Srpen","Září","Říjen","Listopad","Prosinec"],statusLegend:"Stav",almSoonG:"Začíná za 5 min",almStartG:"Začíná nyní",almDoneG:"Dokončeno",almSoonS:"Tvoje aktivita začíná za 5 min — buď na místě",almStartS:"Tvoje aktivita začíná",almDoneS:"Dokončeno — vyžádej si zpětnou vazbu s číslem pokoje",almSoonTeam:"Začíná za 5 min",almStartTeam:"Začíná nyní",almDoneTeam:"Dokončeno",secProgram:"Program",secBookings:"Moje rezervace",secConnect:"Sociální sítě a tým",secManage:"Správa",secTeamwork:"Moje práce",secGuests:"Hosté",secSettings:"Nastavení",uploadErr:"Nahrání selhalo — zkontrolujte Storage",photo:"Fotka",uploadPhoto:"Klepnutím nahrajete fotku",changePhoto:"Změnit fotku"},EXTRA.cs),
nl:Object.assign({appSub:"Animatieteam",guest:"Gast",staff:"Team",manager:"Manager",room:"Kamernummer",name:"Je naam",phone:"Mobiel nummer",user:"Gebruikersnaam",pass:"Wachtwoord",signin:"Inloggen",welcome:"Welkom",today:"Vandaag",highlight:"Hoogtepunt van de dag",todayProgram:"Programma van vandaag",week:"Weekprogramma",myStay:"Mijn verblijf",home:"Home",program:"Programma",bookings:"Boekingen",myBookings:"Mijn boekingen",favorites:"Favorieten",book:"Boeken",booked:"Geboekt",full:"Vol",waitlist:"Op wachtlijst",onWaitlist:"Op de wachtlijst",cancel:"Boeking annuleren",seatsLeft:"plaatsen vrij",adults:"Volwassenen",children:"Kinderen",confirm:"Boeking bevestigen",close:"Sluiten",days:["Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag","Zondag"],daysShort:["Ma","Di","Wo","Do","Vr","Za","Zo"],cats:{morning:"Ochtend",afternoon:"Middag",evening:"Avond",kids:"Kidsclub",theme:"Themadag",mKids:"Kinderactiviteiten",mTeen:"Tieneractiviteiten",mAdult:"Activiteiten",mEvents:"Evenementen",eKidsStage:"Kinderpodium",eLive:"Live-podium",eBefore:"Voor de show",eShow:"Showtime",eAfter:"Na de show",eParty:"Feest"},guests:"gasten",noBookings:"Nog geen boekingen. Bekijk het programma van vandaag!",noFavs:"Nog geen favorieten. Tik op het hartje bij een activiteit.",schedule:"Rooster",team:"Team",guestsBooked:"Geboekte gasten",noneToday:"Vandaag is hier niets gepland.",dashboard:"Overzicht",manage:"Programma",totalBookings:"Boekingen deze week",activities:"Activiteiten",occupancy:"Gem. bezetting",waitlisted:"Op wachtlijsten",addActivity:"Activiteit toevoegen",editActivity:"Activiteit bewerken",deleteActivity:"Verwijderen",actName:"Naam activiteit",desc:"Beschrijving",location:"Locatie",time:"Tijd",capacity:"Capaciteit",entertainer:"Entertainer(s)",imageUrl:"Foto-URL (optioneel)",category:"Categorie",day:"Dag",makeHighlight:"Hoogtepunt van de dag",save:"Opslaan",saved:"Opgeslagen",deleted:"Verwijderd",bookingOk:"Boeking bevestigd!",waitOk:"Toegevoegd aan wachtlijst",cancelled:"Geannuleerd",loginErr:"Controleer je gegevens en probeer opnieuw.",demoNote:"Voorbeeldmodus — verbind Supabase in het bestand om live te gaan.",reviews:"Geniet je van je vakantie?",reviewsSub:"Deel je ervaring — het betekent veel voor ons team.",followUs:"Volg het team",none:"—",arrival:"Aankomstdag",departure:"Vertrekdag",otherUsers:"Teamtoegang",backToGuest:"← Gast-login",usersTab:"Accounts",appTab:"App",appName:"App-naam",appSubtitle:"Ondertitel",colorsHead:"Kleuren",primaryC:"Hoofdkleur",accentC:"Accentkleur",linksHead:"Reviewlinks",socialHead:"Social media",addUser:"Gebruiker toevoegen",displayName:"Weergavenaam",roleLabel:"Rol",teamAccounts:"Teamaccounts",guestStats:"Gastenstatistiek",uniqueGuests:"Gastenkamers",totalPeople:"Geboekte personen",language:"Taal",userExists:"Gebruikersnaam bestaat al",tickets:"Tickets",buyTicket:"Ticket kopen",myTickets:"Mijn tickets",price:"Prijs",qty:"Aantal",reserved:"Gereserveerd",paid:"Betaald",payNote:"Reserveer in de app en betaal bij de animatiebalie of receptie.",ticketOk:"Ticket gereserveerd!",nationality:"Nationaliteit",natStats:"Nationaliteiten",addTicket:"Ticketevent toevoegen",editTicket:"Ticketevent bewerken",markPaid:"Markeer als betaald",markReserved:"Markeer als gereserveerd",styleHead:"Tekststijl",buttonHead:"Knopstijl",menuHead:"Menutitels",bgC:"Achtergrond",fontElegant:"Elegant",fontRoyal:"Koninklijk",fontModern:"Modern",fontSoft:"Zacht",btnRounded:"Afgerond",btnPill:"Pil",btnSquare:"Vierkant",ticketsNone:"Nog geen ticketevents.",orders:"Bestellingen",soldOut:"Uitverkocht",opMorning:"Ochtendprogramma",opAfternoon:"Middagprogramma",opEvening:"Avondprogramma",opDaytime:"Dagactiviteiten",opDayEvents:"Dagevenementen",opSpecial:"Speciale evenementen",startTime:"Starttijd",endTime:"Eindtijd",operation:"Programma",chooseCat:"Kies een categorie",backToCats:"Alle categorieën",myActs:"Mijn activiteiten",myActsSub:"Aan jou toegewezen activiteiten",chatManager:"Bericht de manager",teamChat:"Teamchat",editMsg:"Bericht bewerken",deleteMsg:"Bericht verwijderen",noStaffMsg:"Nog geen berichten. Zeg hallo tegen je manager!",shirtNumber:"Rugnummer",myWorkDay:"Mijn werkdag",dayPlan:"Dagplan",dayOff:"Vrije dag",entranceDuty:"Ingangsdienst",dressCode:"Dresscode",restaurantTheme:"Restaurantthema",dailyStandards:"Dagindeling",eveningShowLbl:"Avondshow",liveBandLbl:"Liveband",makeupPractice:"Inhaaltraining",practiceToday:"Teamtraining vandaag (45 min - ma/wo/vr)",youAreOff:"Je bent vandaag VRIJ - geniet ervan!",youHaveEntrance:"Je hebt vandaag ingangsdienst",teamPlanFull:"Volledig weekplan",selectDay:"Kies dag",noNumber:"Geen rugnummer - vraag je manager",djSchedule:"DJ-schema",std_breakfast:"Ontbijt",std_mmeet:"Ochtendmeeting",std_start:"Starttijd — klaar op posities",std_lunch:"Lunch",std_fmorning:"Einde ochtenddienst",std_ameet:"Middagmeeting",std_fafternoon:"Einde middagdienst",std_dinner:"Diner",std_stage:"Podium opent",std_emeet:"Avondmeeting",std_yoga:"Yoga-/sunset-host gaat eerder naar huis",std_fevening:"Einde avonddienst",n_sport:"Sportuniform",n_mact:"Ochtendactiviteiten 10:00–12:30",n_practice:"13:15 op ma / wo / vr (training 45 min)",n_aact:"Middagactiviteiten 15:00–17:00",n_yogahost:"17:15 voor de yoga-/sunset-host",n_eshow:"Avondshow & livemuziek vanaf 20:00",n_special:"23:30 op speciale avonden (bijv. Beach Party)",practiceInline:"13:15 vandaag — training 45 min",dj_wed:"Geen middagdienst — kom 16:30 voor de Sunset Instrument Party (17:00–19:00), blijf tot sluiting (23:00)",dj_thu:"Vrije dag — liveband verzorgt de muziek (slechts 1 evenement: Foam Party)",dj_other:"Vertrek 16:30, terug om 19:00 om het podium te openen",trainsToday:"traint vandaag individueel",busTimes:"Bustijden",busSchedule:"Busrooster personeel",busToHotel:"Personeelshuis → Hotel",busToHouse:"Hotel → Personeelshuis",busEditHint:"Eén vertrektijd per regel",noBusTimes:"Nog geen bustijden — voeg ze toe in App-instellingen.",busNextHint:"Volgende vertrek",addBus:"Bus toevoegen",editBus:"Bus bewerken",busDirection:"Richting",busTimeLbl:"Vertrektijd",busNoteLbl:"Notitie (optioneel)",busNoteHint:"bijv. alleen vrijdag",settingsHub:"Instellingen",appSettingsItem:"App-ontwerp & instellingen",aiItem:"AI-assistent",exportItem:"Gegevens exporteren (Excel/PDF)",busItem:"Busrooster",settingsSub:"Alles om je app te beheren en aan te passen",st_todo:"Niet gestart",st_live:"Bezig",st_done:"Afgelopen",cancelBtn:"Annuleren",confirmTitle:"Weet je het zeker?",cannotUndo:"Deze actie kan niet ongedaan worden gemaakt.",delActivityQ:"Deze activiteit verwijderen?",delUserQ:"Dit account verwijderen?",delReqQ:"Dit verzoek verwijderen?",delBusQ:"Deze bus verwijderen?",delMsgQ:"Dit bericht verwijderen?",offlineMsg:"Offline — laatst opgeslagen gegevens",backOnlineMsg:"Weer online — synchroniseren...",loadingMsg:"Laden...",errSave:"Opslaan mislukt. Probeer opnieuw.",errNet:"Geen verbinding. Controleer je internet.",fieldRequired:"Vul dit in",invalidTime:"Formaat 08:00",invalidNumber:"Voer een geldig getal in",updateReady:"Nieuwe versie beschikbaar — heropen de app",serverHead:"Beveiligde server (optioneel)",serverHint:"Plak hier je Supabase Edge Function-links. Zo blijft de AI-sleutel op de server in plaats van op de telefoon.",errHttps:"Link moet met https:// beginnen",noDataTitle:"Verbonden, maar geen gegevens",noDataMsg:"De app bereikte de database maar kreeg niets terug — meestal de toegangsregels. Voer het herstelscript uit in Supabase en herlaad.",noDataRooms:"Geen kamers gevonden",eventsToday:"Evenementen vandaag",noEventsToday:"Vandaag geen speciaal evenement",practiceHead:"Teamtraining",practiceWindow:"12:30 – 13:15 (45 min)",makeupWindow:"45 min — individueel",aiEndpointErr:"Serverlink niet bereikbaar — controleer de deploy of maak het veld leeg",aiEndpointFallback:"Server niet bereikbaar — sleutel op dit apparaat wordt gebruikt",themeHead:"App-thema",themeHint:"Elk thema heeft een lichte en donkere versie — wissel met zon/maan in het menu.",themeCustom:"Eigen kleuren",themeLight:"Licht",themeDark:"Donker",quizTab:"Dagelijkse quiz",quizToday:"Vraag van de dag",quizAnswerPh:"Jouw antwoord...",quizSend:"Antwoord versturen",quizDone:"Beantwoord — bedankt!",quizNone:"Vandaag geen vraag. Kom morgen terug!",quizMine:"Jouw antwoord",quizCenter:"Quizcentrum",quizNew:"Nieuwe vraag",quizFor:"Voor",quizForGuest:"Gasten",quizForStaff:"Entertainers",quizQuestion:"Vraag",quizHint:"Hint (optioneel)",quizKey:"Juiste antwoord (alleen jij ziet dit)",quizReplies:"Antwoorden",quizNoReplies:"Nog geen antwoorden",quizSaved:"Vraag gepubliceerd",quizAlready:"Je hebt vandaag al geantwoord",todayPlanExp:"Plan van vandaag (voor directie)",navBack:"Terug",navForward:"Vooruit",genderLbl:"Geslacht",genderM:"Man",genderF:"Vrouw",genderNone:"Niet ingesteld",teamSummary:"Teamoverzicht",totalEntertainers:"Totaal entertainers",byGender:"Naar geslacht",byNationality:"Naar nationaliteit",teamOverview:"Teamoverzicht",typeNationality:"Typ de nationaliteit",natOtherHint:"Niet in de lijst? Kies Anders en typ het.",editDuty:"Vrije dag & ingang bewerken",dutyFor:"Dienst voor",selectDayOff:"Wie is vrij",selectEntrance:"Ingangsdienst",resetDefault:"Terug naar standaardplan",customDay:"Gewijzigd",standardDay:"Standaardplan",workingToday:"Aan het werk",dayOffToday:"Vrij",totalTeam:"Team totaal",dutySaved:"Dienst bijgewerkt",noOneOff:"Niemand vrij",monthAtt:"Maandelijkse aanwezigheid",attP:"Aanwezig",attO:"Vrij",attA:"Afwezig",attLegend:"P = aanwezig · O = vrij · A = afwezig",attTapHint:"Tik op een dag om te wijzigen. Grijs komt uit het plan.",attAuto:"Uit het plan",attTotalsP:"Werkdagen",attTotalsO:"Vrije dagen",attTotalsA:"Afwezig",attExport:"Maandelijkse aanwezigheidslijst",prevMonth:"Vorige maand",nextMonth:"Volgende maand",attSaved:"Aanwezigheid bijgewerkt",workDays:"Werkdagen",monthTotals:"Maandtotalen",teamWorkDays:"Werkdagen team",avgPerPerson:"Gemiddeld per persoon",hotelInfoTab:"Hotelinfo",hotelInfoHint:"Openingstijden, wifi en de meestgestelde gastvragen",addInfo:"Informatie toevoegen",infoTitle:"Titel",infoValue:"Details",noInfo:"Nog geen informatie",galleryTab:"Foto's",galleryHint:"Foto's van onze shows en activiteiten",addPhoto:"Foto toevoegen",noPhotos:"Nog geen foto's — kom terug na de show van vanavond!",photoCaption:"Bijschrift (optioneel)",attentionHead:"Vraagt je aandacht",allGood:"Alles goed",attEmptyAct:"activiteiten vandaag zonder boeking",attWaitReq:"gastverzoeken wachten",attLowRate:"lage beoordelingen deze week",attStaffReq:"teamverzoeken wachten",attNoShow:"teamleden vandaag niet gemarkeerd",trendsHead:"Trends",last7:"Laatste 7 dagen",topActs:"Populairst",lowActs:"Minst populair",bookingTrend:"Boekingen per dag",myAttendance:"Mijn aanwezigheid",myFeedback:"Mijn feedback",noMyFeedback:"Nog geen feedback",askManager:"Vraag de manager",myRequestsTeam:"Mijn verzoeken",newTeamReq:"Nieuw verzoek",reqDayOff:"Vrije dag wijzigen",reqProblem:"Probleem melden",reqCannot:"Ik kan een activiteit niet doen",reqOther:"Iets anders",reqDetail:"Schrijf je manager",reqDateOpt:"Welke dag (optioneel)",teamRequests:"Teamverzoeken",noTeamReqs:"Geen verzoeken van het team",reqApprove:"Goedkeuren",reqDecline:"Afwijzen",reqReply:"Antwoord (optioneel)",statusOk:"Goedgekeurd",statusNo:"Afgewezen",reqSent:"Naar je manager gestuurd",thankYou:"Bedankt!",shareExp:"Wil je je ervaring delen?",reviewLater:"Misschien later",howWasIt:"Hoe was het?",qrTab:"QR-code",qrHint:"Print dit en zet het bij het zwembad, de bar en de receptie",qrDownload:"Printpagina openen",stayEnded:"Je verblijf is voorbij — bedankt voor je bezoek!",accountOff:"Dit account is niet actief. Vraag je manager.",activeAcc:"Account actief",inactiveAcc:"Inactief",deactivate:"Deactiveren",activate:"Activeren",resetPass:"Wachtwoord resetten",newPassIs:"Nieuw wachtwoord",passCopied:"Geef dit aan de persoon — het vervangt het oude",tooManyTries:"Te veel pogingen. Wacht even.",logoLbl:"Logo",logoHint:"Getoond op het inlogscherm",hotelNameLbl:"Hotelnaam",timezoneLbl:"Tijdzone hotel",timezoneHint:"Tijden en meldingen volgen de hotelklok, niet de telefoon van de gast",currencyLbl:"Valuta",contactLbl:"Contact",fontSizeLbl:"Tekstgrootte",fsSmall:"Klein",fsNormal:"Normaal",fsLarge:"Groot",fsXl:"Extra groot",autoDarkLbl:"Donkere modus van telefoon volgen",featuresLbl:"Functies",featQuiz:"Dagelijkse quiz",featTickets:"Tickets",featGallery:"Foto's",featBus:"Busrooster",featInfo:"Hotelinfo",previewTheme:"Voorbeeld",applyTheme:"Dit thema gebruiken",previewOn:"Voorbeeld — nog niet opgeslagen",secIdentity:"Hotelgegevens",secLook:"Uiterlijk",secAccess:"Toegang",upToToday:"tot vandaag",countedDays:"Getelde dagen",workingEntToday:"Entertainers vandaag aan het werk",weatherTab:"Weer",weatherToday:"Vandaag",weatherWeek:"Deze week",weatherFail:"Weer nu niet beschikbaar",feelsLike:"Voelt als",windLbl:"Wind",latLbl:"Breedtegraad",lonLbl:"Lengtegraad",weatherLoc:"Weerlocatie",weatherLocHint:"Coördinaten van het hotel (standaard Hurghada)",wSun:"Zonnig",wPartly:"Half bewolkt",wCloud:"Bewolkt",wFog:"Mist",wDrizzle:"Motregen",wRain:"Regen",wShower:"Buien",wSnow:"Sneeuw",wStorm:"Onweer",wWind:"Winderig",setBrand:"Merk & identiteit",setBrandSub:"Logo, hotelnaam, contact",setTheme:"Thema & kleuren",setThemeSub:"Kleuren, lettertypen, tekstgrootte, donkere modus",setMenus:"Menu's & pagina's",setMenusSub:"Hernoemen, sorteren, eigen pagina's",setNotif:"Meldingen",setNotifSub:"Geluid en waarschuwingen",setLinksT:"Links & reviews",setLinksSub:"Social media en reviewsites",setFeatures:"Functies",setFeaturesSub:"Onderdelen aan- of uitzetten",setLocation:"Locatie & tijd",setLocationSub:"Tijdzone en weerlocatie",setAdvanced:"Geavanceerd",setAdvancedSub:"Beveiligde server, AI, QR-code",setData:"Gegevens",setDataSub:"Alles exporteren naar Excel of PDF",addTime:"Nog een tijd toevoegen",timesLbl:"Openingstijden",guestCrm:"Gastprofielen",crmSearch:"Zoek kamer, naam of nationaliteit",guest360:"Gastprofiel",stayLen:"Verblijf",nights:"nachten",attendedActs:"Bezochte activiteiten",favActs:"Favoriete activiteiten",msgCount:"Berichten",quizPart:"Quizantwoorden",appUsage:"Dagen in de app",noGuests:"Nog geen gasten",openProfile:"Profiel openen",taskPriority:"Prioriteit",prLow:"Laag",prNormal:"Normaal",prHigh:"Hoog",prUrgent:"Urgent",taskLoc:"Locatie",taskDeadline:"Deadline",stNew:"Nieuw",stAccepted:"Geaccepteerd",stProgress:"Bezig",stCompleted:"Afgerond",stVerified:"Geverifieerd",overdue:"Te laat",acceptTask:"Accepteren",startTask:"Starten",completeTask:"Afronden",verifyTask:"Verifiëren",taskProof:"Bewijsfoto",taskComments:"Opmerkingen",addComment:"Opmerking toevoegen",taskHistory:"Geschiedenis",createdBy:"Gemaakt door",noTasks:"Geen taken",employeeProfile:"Medewerkersprofiel",employeeId:"Medewerker-ID",positionLbl2:"Functie",phoneLbl2:"Telefoon",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Datum in dienst",suspend:"Schorsen",assignedActs:"Toegewezen activiteiten",performance:"Prestaties",guestRatings:"Gastbeoordelingen",pointsLbl:"Punten",rankLbl:"Rang",tasksDone:"Afgeronde taken",onTime:"Op tijd",viewProfile:"Profiel bekijken",photosLbl:"Foto's",addPhotos:"Foto's toevoegen",removePhoto:"Foto verwijderen",cropLogo:"Logo bijsnijden",cropHint:"Sleep om te bewegen, schuif om te zoomen",useCrop:"Gebruik deze",removeLogo:"Logo verwijderen",photoOf:"van",requestChange:"Wijziging aanvragen",changeRequest:"Wijzigingsverzoek",whatToChange:"Wat moet er veranderen?",reqSentMgr:"Naar de manager gestuurd",profileReadOnly:"Alleen de manager kan dit wijzigen",pageBuilder:"Paginaontwerper",pbHint:"Bouw een pagina uit blokken — zonder code",pbNewPage:"Nieuwe pagina",pbEditPage:"Pagina bewerken",pbBlocks:"Blokken",pbAddBlock:"Blok toevoegen",blkHeading:"Kop",blkText:"Tekst",blkImage:"Afbeelding",blkGallery:"Galerij",blkButton:"Knop",blkDivider:"Scheidingslijn",blkSpacer:"Ruimte",blkCard:"Kaart",blkList:"Lijst",blkVideo:"Video",blkMap:"Kaart",pbContent:"Inhoud",pbStyle:"Stijl",fontSizeB:"Tekstgrootte",fontFamilyB:"Lettertype",alignLbl:"Uitlijning",alignLeft:"Links",alignCenter:"Midden",alignRight:"Rechts",colorLbl:"Kleur",bgLbl:"Achtergrond",btnShape:"Knopvorm",shapeRound:"Afgerond",shapePill:"Pil",shapeSquare:"Vierkant",btnSize:"Knopgrootte",sizeS:"Klein",sizeM:"Middel",sizeL:"Groot",btnLink:"Link (optioneel)",boldLbl:"Vet",moveBlockUp:"Omhoog",moveBlockDown:"Omlaag",dupBlock:"Dupliceren",delBlock:"Blok verwijderen",pbPreview:"Voorbeeld",pbEmpty:"Deze pagina is leeg — voeg je eerste blok toe",pbSaved:"Pagina opgeslagen",listItems:"Eén item per regel",videoUrl:"Videolink (YouTube)",mapAddr:"Adres of plaats",pbWho:"Wie ziet het",pbIcon:"Pictogram",pbTitle:"Paginatitel",persons:"Aantal personen",personsShort:"pers.",attN:"Nog niet in dienst",notHiredYet:"Voor datum in dienst",mapTab:"Live kaart",shareLoc:"Mijn locatie delen",shareLocHint:"Alleen zolang dit aan staat. Zet het uit en je locatie wordt verwijderd.",locDenied:"Locatietoegang is op deze telefoon geweigerd",noOneSharing:"Niemand deelt nu zijn locatie",lastSeen:"Bijgewerkt",mapHint:"Alleen mensen die delen hebben aangezet verschijnen hier",minsAgo:"min geleden",justNow:"zojuist",locTeam:"Team",locGuests:"Gasten",assignCenter:"Toewijzingen",asgActs:"Activiteiten",asgWho:"Wie kan wat",asgOpen:"Nog niemand",asgNobody:"Nog niemand",allAssigned:"Alles toegewezen",autoAssign:"Automatisch toewijzen",autoAssignHint:"Gebruikt dagplan, vrije dagen, afwezigheid en vaardigheden.",autoReviewHint:"Controleer de voorstellen, wijzig wie je wilt, pas dan toe.",applyAssign:"Toepassen",asgApplied:"toegewezen",asgSkip:"Leeg laten",asgNoSkill:"Niemand beschikbaar kan dit",asgAllBusy:"Iedereen die het kan is al bezig",nobodyWorking:"Deze dag werkt niemand",asgWhoHint:"Tik op iemand om vaardigheden in te stellen",noSkillsSet:"Niets ingesteld — overal inzetbaar",skillEditHint:"Eén tik = kan. Nog een tik = kan niet. Derde tik = wissen.",skCan:"kan",skCant:"kan niet",skAny:"—",sk_sport:"Sport",sk_water:"Water",sk_dance:"Dans",sk_show:"Show",sk_kids:"Kinderen",sk_music:"Muziek",sk_dj:"DJ",sk_games:"Spellen",sk_fitness:"Fitness",sk_host:"Presenteren",sk_craft:"Knutselen",sk_beach:"Strand",needsSkill:"Benodigde vaardigheid",noActsYet:"Voeg eerst activiteiten toe aan je programma — daarna kun je aanvinken wie wat kan.",canRunIt:"kunnen het",editDayOff:"Vrije dag wijzigen",noOneEntrance:"Niemand ingesteld",teamChatTab:"Teamberichten",guestChatTab:"Gastberichten",attV:"Vakantie",attLeft:"Hotel verlaten",markLeft:"Hotel verlaten",markLeftHint:"De aanwezigheid blijft bewaard. Het nummer komt vrij.",leftDate:"Laatste werkdag",undoLeft:"Weer terug",leftTag:"Weg",startPage:"Startpagina van de app",startPageHint:"Bij openen kom je hier terecht.",todayWord:"Vandaag",yesterdayWord:"Gisteren",practiceDays:"Ma / Wo / Vr",arrangeSections:"Deze pagina ordenen",arrangeHint:"Verplaats de delen van deze pagina omhoog of omlaag. Voor iedereen opgeslagen.",dayInfoSec:"Daginformatie",wholeDay:"De hele dag",morningPart:"Ochtend",afternoonPart:"Middag",eveningPart:"Avond",itemsWord:"items",editBooking:"Boeking bewerken",openGuest:"Gastprofiel openen",bookedAt:"Geboekt",booked:"Geboekt",waitlist:"Wachtlijst",status:"Status",standardsHead:"Dagstandaarden",noGuestAccount:"Geen gastaccount voor deze kamer",finishedChip:"Afgelopen",setVacation:"Vakantie instellen",setVacationHint:"Kies de persoon en de eerste en laatste dag.",clearVacation:"Vakantie verwijderen",person:"Persoon",fromDate:"Van",toDate:"Tot",daysWord:"dagen",checkDates:"Controleer de datums",dayWord:"Dag",nightsWord:"nachten",nightsLeft:"nachten over",stayDayOf:"Dag {n} van {t}",stayWelcome:"Welkom — je vakantie begint vandaag",stayLastDay:"Laatste dag — we hopen dat het fijn was",plannedAhead:"Vooruit gepland",addMember:"Lid toevoegen",addAttOnly:"Alleen aanwezigheid",addAttOnlyHint:"Alleen een naam en een nummer (11–50) voor de presentielijst. Geen login, geen activiteiten, telt niet mee in het team.",attNumber:"Nummer (11–50)",attNumRange:"Het nummer moet tussen 11 en 50 liggen",numberTaken:"Dat nummer is al in gebruik",nameNeeded:"Vul een naam in",attOnlyTag:"· alleen aanwezigheid",whichMonth:"Welke maand",whichDay:"Welke dag",selectMsgs:"Berichten selecteren",clearChat:"Chat wissen",selectedWord:"geselecteerd",selectAll:"Alles selecteren",selectNone:"Niets selecteren",deleteMsgsQ:"{n} berichten verwijderen?",clearChatQ:"De hele chat wissen?",clearChatHint:"Alle {n} berichten worden voor iedereen verwijderd.",cannotUndo:"Dit kan niet ongedaan worden gemaakt.",deleteReqQ:"Dit verzoek verwijderen?",allDays:"Alle dagen",whichTime:"Welk moment",allDayLong:"Hele dag",filterNote:"Alleen exporteren:",noFilterNote:"Alles wordt geëxporteerd.",officialAtt:"{hotel} — Officiële maandelijkse aanwezigheid",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"Eerste dag",lastDayOpt:"Laatste dag (optioneel)",attDatesHint:"Dagen voor de eerste en na de laatste dag tellen niet mee.",delete:"Verwijderen",deleteQ:"Deze persoon verwijderen?",attDeleteHint:"De aanwezigheid wordt ook verwijderd. Stel liever de laatste dag in als je die wilt bewaren.",eventsCrewTag:"Alle events & shows",eventsCrewHint:"Deze persoon is bij elk event en elke show — de DJ voor de muziek, social media om te filmen. Zij staan niet op het activiteitenrooster, dus hier valt niets aan te vinken.",wasBooked:"Je was geboekt",bookNowLive:"Bezig — meedoen",removeBooking:"Boeking verwijderen",removeBookingQ:"Deze boeking verwijderen?",removeBookingHint:"De gast verliest zijn plek. Niet terug te draaien.",skillEditHint2:"Vink activiteiten uit je programma aan. Eén tik = kan. Nog een tik = kan niet. Derde tik = wissen.",autoAssign:"Activiteiten automatisch verdelen",autoHint:"Eén activiteit 's ochtends en één 's middags — eerlijk verdeeld. Evenementen doet het hele team, jij en de DJ worden nooit ingedeeld.",autoDay:"Deze dag",autoWeek:"Hele week",onlyEmptyLbl:"Alleen activiteiten zonder toewijzing",replaceAllLbl:"Alles vervangen",autoPreview:"Voorstel",autoApply:"Plan toepassen",autoNothing:"Niets te verdelen — controleer vrije dagen en programma",autoDone:"Activiteiten verdeeld",morningSlot:"Ochtend",afternoonSlot:"Middag",perPerson:"Per persoon",noOneAvailable:"Niemand beschikbaar op deze dag",eventsAllTeam:"Evenementen — hele team",changeWho:"Wijzigen",noneAssigned:"— niemand —",balanceLbl:"Balans",evenSpread:"Gelijk verdeeld",spreadOff:"Verschil van",editHint:"Tik op een naam om te wijzigen voor toepassen",recalc:"Opnieuw verdelen",fairest:"Eerlijkst",activityCount:"activiteiten",zoomLbl:"Zoom",totalAllTeam:"Team totaal (incl. manager)",infoTime:"Openingstijd",infoPlace:"Locatie",translateBtn:"Vertalen",translating:"Vertalen...",translateFail:"Vertalen mislukt",showOriginal:"Origineel tonen",builderTab:"Menubouwer",builderHint:"Hernoem, sorteer, verberg of voeg items toe — per rol, zonder code",forRole:"Voor",roleGuest:"Gasten",roleStaff:"Entertainers",roleManager:"Manager",moveUp:"Omhoog",moveDown:"Omlaag",hideItem:"Verborgen",showItem:"Zichtbaar",renameItem:"Naam",addLink:"Eigen pagina toevoegen",linkTitle:"Titel",linkUrl:"Webadres",linkText:"Te tonen tekst",linkKind:"Type",kindLink:"Weblink",kindPage:"Tekstpagina",resetMenu:"Terug naar standaard",builderSaved:"Menu bijgewerkt",customPage:"Mijn pagina",openLink:"Openen",translatedTag:"Vertaald",infoPhoto:"Foto",totalRow:"TOTAAL",months:["Januari","Februari","Maart","April","Mei","Juni","Juli","Augustus","September","Oktober","November","December"],statusLegend:"Status",almSoonG:"Begint over 5 min",almStartG:"Begint nu",almDoneG:"Afgelopen",almSoonS:"Je activiteit begint over 5 min — wees er nu",almStartS:"Je activiteit begint nu",almDoneS:"Afgelopen — verzamel feedback met kamernummer",almSoonTeam:"Begint over 5 min",almStartTeam:"Begint nu",almDoneTeam:"Afgelopen",secProgram:"Programma",secBookings:"Mijn boekingen",secConnect:"Social & team",secManage:"Beheer",secTeamwork:"Mijn werk",secGuests:"Gasten",secSettings:"Instellingen",uploadErr:"Uploaden mislukt — controleer Storage",photo:"Foto",uploadPhoto:"Tik om foto te uploaden",changePhoto:"Foto wijzigen"},EXTRA.nl),
fr:Object.assign({appSub:"Équipe d'animation",guest:"Invité",staff:"Équipe",manager:"Manager",room:"Numéro de chambre",name:"Votre nom",phone:"Téléphone portable",user:"Nom d'utilisateur",pass:"Mot de passe",signin:"Se connecter",welcome:"Bienvenue",today:"Aujourd'hui",highlight:"Moment fort du jour",todayProgram:"Programme du jour",week:"Programme de la semaine",myStay:"Mon séjour",home:"Accueil",program:"Programme",bookings:"Réservations",myBookings:"Mes réservations",favorites:"Favoris",book:"Réserver",booked:"Réservé",full:"Complet",waitlist:"Liste d'attente",onWaitlist:"Sur liste d'attente",cancel:"Annuler la réservation",seatsLeft:"places restantes",adults:"Adultes",children:"Enfants",confirm:"Confirmer la réservation",close:"Fermer",days:["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"],daysShort:["Lun","Mar","Mer","Jeu","Ven","Sam","Dim"],cats:{morning:"Matin",afternoon:"Après-midi",evening:"Soir",kids:"Club enfants",theme:"Journée à thème",mKids:"Activités enfants",mTeen:"Activités ados",mAdult:"Activités",mEvents:"Événements",eKidsStage:"Scène enfants",eLive:"Scène live",eBefore:"Avant le spectacle",eShow:"Spectacle",eAfter:"Après le spectacle",eParty:"Fête"},guests:"invités",noBookings:"Aucune réservation. Découvrez le programme du jour !",noFavs:"Aucun favori. Touchez le cœur d'une activité.",schedule:"Planning",team:"Équipe",guestsBooked:"Invités inscrits",noneToday:"Rien de prévu ici aujourd'hui.",dashboard:"Aperçu",manage:"Programme",totalBookings:"Réservations cette semaine",activities:"Activités",occupancy:"Occupation moy.",waitlisted:"Sur listes d'attente",addActivity:"Ajouter une activité",editActivity:"Modifier l'activité",deleteActivity:"Supprimer",actName:"Nom de l'activité",desc:"Description",location:"Lieu",time:"Heure",capacity:"Capacité",entertainer:"Animateur(s)",imageUrl:"URL de la photo (optionnel)",category:"Catégorie",day:"Jour",makeHighlight:"Moment fort du jour",save:"Enregistrer",saved:"Enregistré",deleted:"Supprimé",bookingOk:"Réservation confirmée !",waitOk:"Ajouté à la liste d'attente",cancelled:"Annulé",loginErr:"Vérifiez vos informations et réessayez.",demoNote:"Mode aperçu avec données d'exemple — connectez Supabase dans le fichier.",reviews:"Vous passez de bonnes vacances ?",reviewsSub:"Partagez votre expérience — cela compte beaucoup pour notre équipe.",followUs:"Suivez l'équipe",none:"—",arrival:"Jour d'arrivée",departure:"Jour de départ",otherUsers:"Accès équipe",backToGuest:"← Connexion invité",usersTab:"Comptes",appTab:"App",appName:"Nom de l'app",appSubtitle:"Sous-titre",colorsHead:"Couleurs",primaryC:"Couleur principale",accentC:"Couleur d'accent",linksHead:"Liens d'avis",socialHead:"Réseaux sociaux",addUser:"Ajouter un compte",displayName:"Nom affiché",roleLabel:"Rôle",teamAccounts:"Comptes de l'équipe",guestStats:"Statistiques invités",uniqueGuests:"Chambres",totalPeople:"Personnes inscrites",language:"Langue",userExists:"Ce nom d'utilisateur existe déjà",tickets:"Billets",buyTicket:"Acheter un billet",myTickets:"Mes billets",price:"Prix",qty:"Quantité",reserved:"Réservé",paid:"Payé",payNote:"Réservez dans l'app et payez au stand animation ou à la réception.",ticketOk:"Billet réservé !",nationality:"Nationalité",natStats:"Nationalités",addTicket:"Ajouter un événement",editTicket:"Modifier l'événement",markPaid:"Marquer payé",markReserved:"Marquer réservé",styleHead:"Style du texte",buttonHead:"Style des boutons",menuHead:"Titres du menu",bgC:"Arrière-plan",fontElegant:"Élégant",fontRoyal:"Royal",fontModern:"Moderne",fontSoft:"Doux",btnRounded:"Arrondis",btnPill:"Pilule",btnSquare:"Carrés",ticketsNone:"Aucun événement pour l'instant.",orders:"Commandes",soldOut:"Complet",opMorning:"Programme du matin",opAfternoon:"Programme de l'après-midi",opEvening:"Programme du soir",opDaytime:"Activités de jour",opDayEvents:"Événements de jour",opSpecial:"Événements spéciaux",startTime:"Heure de début",endTime:"Heure de fin",operation:"Programme",chooseCat:"Choisir une catégorie",backToCats:"Toutes les catégories",myActs:"Mes activités",myActsSub:"Activités qui vous sont attribuées",chatManager:"Écrire au manager",teamChat:"Chat de l'équipe",editMsg:"Modifier le message",deleteMsg:"Supprimer le message",noStaffMsg:"Aucun message. Dites bonjour à votre manager !",shirtNumber:"Numéro de maillot",myWorkDay:"Ma journée de travail",dayPlan:"Plan du jour",dayOff:"Jour de repos",entranceDuty:"Service d'entrée",dressCode:"Code vestimentaire",restaurantTheme:"Thème du restaurant",dailyStandards:"Déroulé de la journée",eveningShowLbl:"Spectacle du soir",liveBandLbl:"Groupe live",makeupPractice:"Répétition de rattrapage",practiceToday:"Répétition aujourd'hui (45 min - lun/mer/ven)",youAreOff:"Vous êtes en repos aujourd'hui !",youHaveEntrance:"Vous avez le service d'entrée aujourd'hui",teamPlanFull:"Plan complet de la semaine",selectDay:"Choisir le jour",noNumber:"Aucun numéro - demandez à votre manager",djSchedule:"Planning DJ",std_breakfast:"Petit-déjeuner",std_mmeet:"Réunion du matin",std_start:"Heure de début — prêts aux positions",std_lunch:"Déjeuner",std_fmorning:"Fin du service du matin",std_ameet:"Réunion de l'après-midi",std_fafternoon:"Fin du service de l'après-midi",std_dinner:"Dîner",std_stage:"Ouverture de la scène",std_emeet:"Réunion du soir",std_yoga:"L'animateur yoga/coucher part plus tôt",std_fevening:"Fin du service du soir",n_sport:"Tenue de sport",n_mact:"Activités du matin 10:00–12:30",n_practice:"13:15 les lun / mer / ven (répétition 45 min)",n_aact:"Activités de l'après-midi 15:00–17:00",n_yogahost:"17:15 pour l'animateur yoga/coucher",n_eshow:"Spectacle du soir et musique live dès 20:00",n_special:"23:30 les soirs d'événement (ex. Beach Party)",practiceInline:"13:15 aujourd'hui — répétition 45 min",dj_wed:"Pas de service l'après-midi — arriver à 16:30 pour la Sunset Instrument Party (17:00–19:00), rester jusqu'à la fermeture (23:00)",dj_thu:"Jour de repos — le groupe live assure la musique (1 seul événement : Foam Party)",dj_other:"Partir à 16:30, revenir à 19:00 pour ouvrir la scène",trainsToday:"s'entraîne individuellement aujourd'hui",busTimes:"Horaires du bus",busSchedule:"Horaires du bus du personnel",busToHotel:"Maison du personnel → Hôtel",busToHouse:"Hôtel → Maison du personnel",busEditHint:"Un horaire de départ par ligne",noBusTimes:"Aucun horaire — ajoutez-les dans les paramètres.",busNextHint:"Prochain départ",addBus:"Ajouter un bus",editBus:"Modifier le bus",busDirection:"Direction",busTimeLbl:"Heure de départ",busNoteLbl:"Note (optionnel)",busNoteHint:"ex. vendredis uniquement",settingsHub:"Paramètres",appSettingsItem:"Design et paramètres de l'app",aiItem:"Assistant IA",exportItem:"Exporter les données (Excel/PDF)",busItem:"Horaires du bus",settingsSub:"Tout pour gérer et personnaliser votre app",st_todo:"Pas commencé",st_live:"En cours",st_done:"Terminé",cancelBtn:"Annuler",confirmTitle:"Êtes-vous sûr ?",cannotUndo:"Cette action est irréversible.",delActivityQ:"Supprimer cette activité ?",delUserQ:"Supprimer ce compte ?",delReqQ:"Supprimer cette demande ?",delBusQ:"Supprimer ce bus ?",delMsgQ:"Supprimer ce message ?",offlineMsg:"Hors ligne — dernières données enregistrées",backOnlineMsg:"De nouveau en ligne — synchronisation...",loadingMsg:"Chargement...",errSave:"Échec de l'enregistrement. Réessayez.",errNet:"Pas de connexion. Vérifiez votre internet.",fieldRequired:"Veuillez remplir ce champ",invalidTime:"Format 08:00",invalidNumber:"Entrez un nombre valide",updateReady:"Nouvelle version disponible — rouvrez l'application",serverHead:"Serveur sécurisé (optionnel)",serverHint:"Collez vos liens Supabase Edge Function. La clé IA reste alors sur le serveur, pas sur le téléphone.",errHttps:"Le lien doit commencer par https://",noDataTitle:"Connecté, mais aucune donnée",noDataMsg:"L'application a joint la base mais n'a rien reçu — souvent les règles d'accès. Lancez le script de réparation dans Supabase puis rechargez.",noDataRooms:"Aucune chambre trouvée",eventsToday:"Événements aujourd'hui",noEventsToday:"Aucun événement spécial aujourd'hui",practiceHead:"Répétition d'équipe",practiceWindow:"12:30 – 13:15 (45 min)",makeupWindow:"45 min — individuel",aiEndpointErr:"Lien serveur injoignable — vérifiez le déploiement ou videz le champ",aiEndpointFallback:"Serveur injoignable — utilisation de la clé de cet appareil",themeHead:"Thème de l'app",themeHint:"Chaque thème a une version claire et sombre — basculez avec le soleil/la lune dans le menu.",themeCustom:"Couleurs personnalisées",themeLight:"Clair",themeDark:"Sombre",quizTab:"Quiz du jour",quizToday:"Question du jour",quizAnswerPh:"Votre réponse...",quizSend:"Envoyer la réponse",quizDone:"Répondu — merci !",quizNone:"Pas de question aujourd'hui. Revenez demain !",quizMine:"Votre réponse",quizCenter:"Centre de quiz",quizNew:"Nouvelle question",quizFor:"Pour",quizForGuest:"Clients",quizForStaff:"Animateurs",quizQuestion:"Question",quizHint:"Indice (optionnel)",quizKey:"Bonne réponse (vous seul la voyez)",quizReplies:"Réponses",quizNoReplies:"Aucune réponse",quizSaved:"Question publiée",quizAlready:"Vous avez déjà répondu aujourd'hui",todayPlanExp:"Plan du jour (pour la direction)",navBack:"Retour",navForward:"Suivant",genderLbl:"Sexe",genderM:"Homme",genderF:"Femme",genderNone:"Non renseigné",teamSummary:"Résumé de l'équipe",totalEntertainers:"Total animateurs",byGender:"Par sexe",byNationality:"Par nationalité",teamOverview:"Aperçu de l'équipe",typeNationality:"Saisissez la nationalité",natOtherHint:"Absent de la liste ? Choisissez Autre et saisissez-la.",editDuty:"Modifier repos et entrée",dutyFor:"Service pour",selectDayOff:"Qui est en repos",selectEntrance:"Service d'entrée",resetDefault:"Revenir au plan standard",customDay:"Modifié",standardDay:"Plan standard",workingToday:"En service",dayOffToday:"En repos",totalTeam:"Équipe totale",dutySaved:"Service mis à jour",noOneOff:"Personne en repos",monthAtt:"Présence mensuelle",attP:"Présent",attO:"Repos",attA:"Absent",attLegend:"P = présent · O = repos · A = absent",attTapHint:"Touchez un jour pour le changer. Le gris vient du plan.",attAuto:"Du plan",attTotalsP:"Jours travaillés",attTotalsO:"Jours de repos",attTotalsA:"Absences",attExport:"Feuille de présence mensuelle",prevMonth:"Mois précédent",nextMonth:"Mois suivant",attSaved:"Présence mise à jour",workDays:"Jours travaillés",monthTotals:"Totaux du mois",teamWorkDays:"Jours travaillés équipe",avgPerPerson:"Moyenne par personne",hotelInfoTab:"Infos hôtel",hotelInfoHint:"Horaires, WiFi et les questions les plus fréquentes",addInfo:"Ajouter une information",infoTitle:"Titre",infoValue:"Détails",noInfo:"Aucune information",galleryTab:"Photos",galleryHint:"Photos de nos spectacles et activités",addPhoto:"Ajouter une photo",noPhotos:"Pas encore de photos — revenez après le spectacle de ce soir !",photoCaption:"Légende (optionnel)",attentionHead:"Demande votre attention",allGood:"Tout va bien",attEmptyAct:"activités aujourd'hui sans réservation",attWaitReq:"demandes clients en attente",attLowRate:"notes basses cette semaine",attStaffReq:"demandes de l'équipe en attente",attNoShow:"membres non pointés aujourd'hui",trendsHead:"Tendances",last7:"7 derniers jours",topActs:"Les plus populaires",lowActs:"Les moins populaires",bookingTrend:"Réservations par jour",myAttendance:"Ma présence",myFeedback:"Mes avis",noMyFeedback:"Aucun avis",askManager:"Demander au manager",myRequestsTeam:"Mes demandes",newTeamReq:"Nouvelle demande",reqDayOff:"Changer le jour de repos",reqProblem:"Signaler un problème",reqCannot:"Je ne peux pas animer",reqOther:"Autre chose",reqDetail:"Écrivez à votre manager",reqDateOpt:"Quel jour (optionnel)",teamRequests:"Demandes de l'équipe",noTeamReqs:"Aucune demande de l'équipe",reqApprove:"Approuver",reqDecline:"Refuser",reqReply:"Réponse (optionnel)",statusOk:"Approuvée",statusNo:"Refusée",reqSent:"Envoyé à votre manager",thankYou:"Merci !",shareExp:"Voulez-vous partager votre expérience ?",reviewLater:"Plus tard",howWasIt:"C'était comment ?",qrTab:"Code QR",qrHint:"Imprimez et placez à la piscine, au bar et à la réception",qrDownload:"Ouvrir la page à imprimer",stayEnded:"Votre séjour est terminé — merci de votre visite !",accountOff:"Ce compte n'est pas actif. Demandez à votre manager.",activeAcc:"Compte actif",inactiveAcc:"Inactif",deactivate:"Désactiver",activate:"Activer",resetPass:"Réinitialiser le mot de passe",newPassIs:"Nouveau mot de passe",passCopied:"Donnez-le à la personne — il remplace l'ancien",tooManyTries:"Trop de tentatives. Patientez un instant.",logoLbl:"Logo",logoHint:"Affiché sur l'écran de connexion",hotelNameLbl:"Nom de l'hôtel",timezoneLbl:"Fuseau horaire de l'hôtel",timezoneHint:"Les horaires et alertes suivent l'heure de l'hôtel, pas le téléphone",currencyLbl:"Devise",contactLbl:"Contact",fontSizeLbl:"Taille du texte",fsSmall:"Petit",fsNormal:"Normal",fsLarge:"Grand",fsXl:"Très grand",autoDarkLbl:"Suivre le mode sombre du téléphone",featuresLbl:"Fonctions",featQuiz:"Quiz du jour",featTickets:"Billets",featGallery:"Photos",featBus:"Horaires du bus",featInfo:"Infos hôtel",previewTheme:"Aperçu",applyTheme:"Utiliser ce thème",previewOn:"Aperçu — pas encore enregistré",secIdentity:"Identité de l'hôtel",secLook:"Apparence",secAccess:"Accès",upToToday:"jusqu'à aujourd'hui",countedDays:"Jours comptés",workingEntToday:"Animateurs en service aujourd'hui",weatherTab:"Météo",weatherToday:"Aujourd'hui",weatherWeek:"Cette semaine",weatherFail:"Météo indisponible",feelsLike:"Ressenti",windLbl:"Vent",latLbl:"Latitude",lonLbl:"Longitude",weatherLoc:"Lieu de la météo",weatherLocHint:"Coordonnées de l'hôtel (Hurghada par défaut)",wSun:"Ensoleillé",wPartly:"Partiellement nuageux",wCloud:"Nuageux",wFog:"Brouillard",wDrizzle:"Bruine",wRain:"Pluie",wShower:"Averses",wSnow:"Neige",wStorm:"Orage",wWind:"Venteux",setBrand:"Marque et identité",setBrandSub:"Logo, nom de l'hôtel, contact",setTheme:"Thème et couleurs",setThemeSub:"Couleurs, polices, taille du texte, mode sombre",setMenus:"Menus et pages",setMenusSub:"Renommer, réorganiser, vos propres pages",setNotif:"Notifications",setNotifSub:"Son et alertes",setLinksT:"Liens et avis",setLinksSub:"Réseaux sociaux et sites d'avis",setFeatures:"Fonctions",setFeaturesSub:"Activer ou désactiver des parties de l'app",setLocation:"Lieu et heure",setLocationSub:"Fuseau horaire et lieu de la météo",setAdvanced:"Avancé",setAdvancedSub:"Serveur sécurisé, IA, code QR",setData:"Données",setDataSub:"Tout exporter en Excel ou PDF",addTime:"Ajouter un autre horaire",timesLbl:"Horaires d'ouverture",guestCrm:"Profils clients",crmSearch:"Chercher chambre, nom ou nationalité",guest360:"Profil client",stayLen:"Séjour",nights:"nuits",attendedActs:"Activités suivies",favActs:"Activités favorites",msgCount:"Messages",quizPart:"Réponses au quiz",appUsage:"Jours dans l'app",noGuests:"Aucun client",openProfile:"Ouvrir le profil",taskPriority:"Priorité",prLow:"Basse",prNormal:"Normale",prHigh:"Haute",prUrgent:"Urgente",taskLoc:"Lieu",taskDeadline:"Échéance",stNew:"Nouvelle",stAccepted:"Acceptée",stProgress:"En cours",stCompleted:"Terminée",stVerified:"Vérifiée",overdue:"En retard",acceptTask:"Accepter",startTask:"Démarrer",completeTask:"Terminer",verifyTask:"Vérifier",taskProof:"Photo justificative",taskComments:"Commentaires",addComment:"Ajouter un commentaire",taskHistory:"Historique",createdBy:"Créée par",noTasks:"Aucune tâche",employeeProfile:"Profil employé",employeeId:"ID employé",positionLbl2:"Poste",phoneLbl2:"Téléphone",whatsappLbl2:"WhatsApp",instagramLbl2:"Instagram",hireDate:"Date d'embauche",suspend:"Suspendre",assignedActs:"Activités assignées",performance:"Performance",guestRatings:"Notes des clients",pointsLbl:"Points",rankLbl:"Rang",tasksDone:"Tâches terminées",onTime:"À l'heure",viewProfile:"Voir le profil",photosLbl:"Photos",addPhotos:"Ajouter des photos",removePhoto:"Retirer la photo",cropLogo:"Recadrer le logo",cropHint:"Glissez pour déplacer, curseur pour zoomer",useCrop:"Utiliser",removeLogo:"Retirer le logo",photoOf:"sur",requestChange:"Demander un changement",changeRequest:"Demande de modification",whatToChange:"Que faut-il changer ?",reqSentMgr:"Envoyé au manager",profileReadOnly:"Seul le manager peut le modifier",pageBuilder:"Concepteur de page",pbHint:"Construisez une page avec des blocs — sans code",pbNewPage:"Nouvelle page",pbEditPage:"Modifier la page",pbBlocks:"Blocs",pbAddBlock:"Ajouter un bloc",blkHeading:"Titre",blkText:"Texte",blkImage:"Image",blkGallery:"Galerie",blkButton:"Bouton",blkDivider:"Séparateur",blkSpacer:"Espace",blkCard:"Carte",blkList:"Liste",blkVideo:"Vidéo",blkMap:"Carte",pbContent:"Contenu",pbStyle:"Style",fontSizeB:"Taille du texte",fontFamilyB:"Police",alignLbl:"Alignement",alignLeft:"Gauche",alignCenter:"Centre",alignRight:"Droite",colorLbl:"Couleur",bgLbl:"Fond",btnShape:"Forme du bouton",shapeRound:"Arrondi",shapePill:"Pilule",shapeSquare:"Carré",btnSize:"Taille du bouton",sizeS:"Petit",sizeM:"Moyen",sizeL:"Grand",btnLink:"Lien (optionnel)",boldLbl:"Gras",moveBlockUp:"Monter",moveBlockDown:"Descendre",dupBlock:"Dupliquer",delBlock:"Supprimer le bloc",pbPreview:"Aperçu",pbEmpty:"Cette page est vide — ajoutez votre premier bloc",pbSaved:"Page enregistrée",listItems:"Un élément par ligne",videoUrl:"Lien vidéo (YouTube)",mapAddr:"Adresse ou lieu",pbWho:"Qui le voit",pbIcon:"Icône",pbTitle:"Titre de la page",persons:"Nombre de personnes",personsShort:"pers.",attN:"Pas encore employé",notHiredYet:"Avant la date d'embauche",mapTab:"Carte en direct",shareLoc:"Partager ma position",shareLocHint:"Uniquement quand c'est activé. Désactivez à tout moment et votre position est supprimée.",locDenied:"L'accès à la position a été refusé sur ce téléphone",noOneSharing:"Personne ne partage sa position actuellement",lastSeen:"Mis à jour",mapHint:"Seules les personnes ayant activé le partage apparaissent ici",minsAgo:"min",justNow:"à l'instant",locTeam:"Équipe",locGuests:"Clients",assignCenter:"Affectations",asgActs:"Activités",asgWho:"Qui peut faire quoi",asgOpen:"Personne encore",asgNobody:"Personne encore",allAssigned:"Tout est affecté",autoAssign:"Affecter automatiquement",autoAssignHint:"Utilise le plan du jour, les repos, les absences et les compétences.",autoReviewHint:"Vérifiez les propositions, changez qui vous voulez, puis appliquez.",applyAssign:"Appliquer",asgApplied:"affectés",asgSkip:"Laisser vide",asgNoSkill:"Personne de disponible ne peut le faire",asgAllBusy:"Tous ceux qui peuvent sont occupés",nobodyWorking:"Personne ne travaille ce jour",asgWhoHint:"Touchez une personne pour définir ses compétences",noSkillsSet:"Rien de défini — peut tout faire",skillEditHint:"Un appui = sait faire. Deuxième = ne sait pas. Troisième = effacer.",skCan:"sait",skCant:"ne sait pas",skAny:"—",sk_sport:"Sport",sk_water:"Eau",sk_dance:"Danse",sk_show:"Spectacle",sk_kids:"Enfants",sk_music:"Musique",sk_dj:"DJ",sk_games:"Jeux",sk_fitness:"Fitness",sk_host:"Animation",sk_craft:"Loisirs créatifs",sk_beach:"Plage",needsSkill:"Compétence requise",noActsYet:"Ajoutez d'abord des activités au programme — vous pourrez ensuite cocher qui peut faire quoi.",canRunIt:"peuvent l'animer",editDayOff:"Modifier le repos",noOneEntrance:"Personne défini",teamChatTab:"Messages équipe",guestChatTab:"Messages clients",attV:"Congés",attLeft:"A quitté l'hôtel",markLeft:"A quitté l'hôtel",markLeftHint:"Sa présence est conservée. Son numéro est libéré.",leftDate:"Dernier jour travaillé",undoLeft:"Il est revenu",leftTag:"Parti",startPage:"Page d'ouverture",startPageHint:"À l'ouverture de l'app vous arrivez ici.",todayWord:"Aujourd'hui",yesterdayWord:"Hier",practiceDays:"Lun / Mer / Ven",arrangeSections:"Organiser cette page",arrangeHint:"Déplacez les parties de cette page vers le haut ou le bas. Enregistré pour tous.",dayInfoSec:"Informations du jour",wholeDay:"Toute la journée",morningPart:"Matin",afternoonPart:"Après-midi",eveningPart:"Soir",itemsWord:"éléments",editBooking:"Modifier la réservation",openGuest:"Ouvrir la fiche client",bookedAt:"Réservé",booked:"Réservé",waitlist:"Liste d'attente",status:"Statut",standardsHead:"Standards du jour",noGuestAccount:"Aucun compte client pour cette chambre",finishedChip:"Terminé",setVacation:"Définir les congés",setVacationHint:"Choisissez la personne et le premier et dernier jour.",clearVacation:"Retirer les congés",person:"Personne",fromDate:"Du",toDate:"Au",daysWord:"jours",checkDates:"Vérifiez les dates",dayWord:"Jour",nightsWord:"nuits",nightsLeft:"nuits restantes",stayDayOf:"Jour {n} sur {t}",stayWelcome:"Bienvenue — vos vacances commencent aujourd'hui",stayLastDay:"Dernier jour — nous espérons que c'était agréable",plannedAhead:"Planifié à l'avance",addMember:"Ajouter un membre",addAttOnly:"Présence uniquement",addAttOnlyHint:"Juste un nom et un numéro (11–50) pour la feuille de présence. Pas de connexion, pas d'activités, non compté dans l'équipe.",attNumber:"Numéro (11–50)",attNumRange:"Le numéro doit être entre 11 et 50",numberTaken:"Ce numéro est déjà pris",nameNeeded:"Merci d'indiquer un nom",attOnlyTag:"· présence uniquement",whichMonth:"Quel mois",whichDay:"Quel jour",selectMsgs:"Sélectionner des messages",clearChat:"Vider la conversation",selectedWord:"sélectionné(s)",selectAll:"Tout sélectionner",selectNone:"Tout désélectionner",deleteMsgsQ:"Supprimer {n} messages ?",clearChatQ:"Vider toute la conversation ?",clearChatHint:"Les {n} messages seront supprimés pour tout le monde.",cannotUndo:"Cette action est irréversible.",deleteReqQ:"Supprimer cette demande ?",allDays:"Tous les jours",whichTime:"Quel moment",allDayLong:"Toute la journée",filterNote:"Export limité à :",noFilterNote:"Tout sera exporté.",officialAtt:"{hotel} — Présence mensuelle officielle",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"Premier jour",lastDayOpt:"Dernier jour (facultatif)",attDatesHint:"Les jours avant le premier et après le dernier ne sont pas comptés.",delete:"Supprimer",deleteQ:"Supprimer cette personne ?",attDeleteHint:"Sa présence sera supprimée aussi. Indiquez plutôt le dernier jour pour la conserver.",eventsCrewTag:"Tous les événements et spectacles",eventsCrewHint:"Cette personne est présente à chaque événement et spectacle — le DJ pour la musique, les réseaux sociaux pour filmer. Elle n'est pas dans le planning des activités, il n'y a donc rien à cocher ici.",wasBooked:"Vous étiez inscrit",bookNowLive:"En cours — rejoindre",removeBooking:"Retirer la réservation",removeBookingQ:"Retirer cette réservation ?",removeBookingHint:"Le client perd sa place. Irréversible.",skillEditHint2:"Cochez les activités de votre programme. Un appui = sait faire. Deuxième = ne sait pas. Troisième = effacer.",autoAssign:"Attribuer les activités",autoHint:"Une activité le matin et une l'après-midi — réparti équitablement. Les événements sont pour toute l'équipe, vous et le DJ n'êtes jamais attribués.",autoDay:"Ce jour",autoWeek:"Semaine entière",onlyEmptyLbl:"Seulement les activités sans personne",replaceAllLbl:"Tout remplacer",autoPreview:"Proposition",autoApply:"Appliquer ce plan",autoNothing:"Rien à attribuer — vérifiez les repos et le programme",autoDone:"Activités attribuées",morningSlot:"Matin",afternoonSlot:"Après-midi",perPerson:"Par personne",noOneAvailable:"Personne disponible ce jour",eventsAllTeam:"Événements — toute l'équipe",changeWho:"Modifier",noneAssigned:"— personne —",balanceLbl:"Équilibre",evenSpread:"Réparti équitablement",spreadOff:"Écart de",editHint:"Touchez un nom pour le changer avant d'appliquer",recalc:"Recalculer",fairest:"Le plus équitable",activityCount:"activités",zoomLbl:"Zoom",totalAllTeam:"Équipe totale (manager inclus)",infoTime:"Horaires",infoPlace:"Lieu",translateBtn:"Traduire",translating:"Traduction...",translateFail:"Traduction impossible",showOriginal:"Voir l'original",builderTab:"Constructeur de menu",builderHint:"Renommez, réorganisez, masquez ou ajoutez — par rôle, sans code",forRole:"Pour",roleGuest:"Clients",roleStaff:"Animateurs",roleManager:"Manager",moveUp:"Monter",moveDown:"Descendre",hideItem:"Masqué",showItem:"Affiché",renameItem:"Nom",addLink:"Ajouter votre page",linkTitle:"Titre",linkUrl:"Adresse web",linkText:"Texte à afficher",linkKind:"Type",kindLink:"Lien web",kindPage:"Page de texte",resetMenu:"Réinitialiser",builderSaved:"Menu mis à jour",customPage:"Ma page",openLink:"Ouvrir",translatedTag:"Traduit",infoPhoto:"Photo",totalRow:"TOTAL",months:["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],statusLegend:"Statut",almSoonG:"Commence dans 5 min",almStartG:"Commence maintenant",almDoneG:"Terminé",almSoonS:"Votre activité commence dans 5 min — soyez présent",almStartS:"Votre activité commence maintenant",almDoneS:"Terminé — recueillez les avis avec le numéro de chambre",almSoonTeam:"Commence dans 5 min",almStartTeam:"Commence maintenant",almDoneTeam:"Terminé",secProgram:"Programme",secBookings:"Mes réservations",secConnect:"Social et équipe",secManage:"Gestion",secTeamwork:"Mon travail",secGuests:"Invités",secSettings:"Paramètres",uploadErr:"Échec du téléversement — vérifiez le Storage",photo:"Photo",uploadPhoto:"Toucher pour téléverser une photo",changePhoto:"Changer la photo"},EXTRA.fr),
ar:Object.assign({appSub:"فريق الترفيه",guest:"ضيف",staff:"الفريق",manager:"المدير",room:"رقم الغرفة",name:"اسمك",phone:"رقم الهاتف",user:"اسم المستخدم",pass:"كلمة المرور",signin:"تسجيل الدخول",welcome:"أهلاً وسهلاً",today:"اليوم",highlight:"نشاط اليوم المميز",todayProgram:"برنامج اليوم",week:"البرنامج الأسبوعي",myStay:"إقامتي",home:"الرئيسية",program:"البرنامج",bookings:"الحجوزات",myBookings:"حجوزاتي",favorites:"المفضلة",book:"احجز",booked:"محجوز",full:"مكتمل",waitlist:"انضم لقائمة الانتظار",onWaitlist:"في قائمة الانتظار",cancel:"إلغاء الحجز",seatsLeft:"مقاعد متبقية",adults:"بالغون",children:"أطفال",confirm:"تأكيد الحجز",close:"إغلاق",days:["الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت","الأحد"],daysShort:["اثن","ثلا","أرب","خمي","جمع","سبت","أحد"],cats:{morning:"الصباح",afternoon:"بعد الظهر",evening:"المساء",kids:"نادي الأطفال",theme:"يوم خاص",mKids:"أنشطة الأطفال",mTeen:"أنشطة المراهقين",mAdult:"أنشطة",mEvents:"فعاليات",eKidsStage:"مسرح الأطفال",eLive:"المسرح المباشر",eBefore:"قبل العرض",eShow:"وقت العرض",eAfter:"بعد العرض",eParty:"حفلة"},guests:"ضيوف",noBookings:"لا توجد حجوزات بعد. تصفح برنامج اليوم!",noFavs:"لا توجد مفضلات بعد. اضغط على القلب في أي نشاط.",schedule:"الجدول",team:"الفريق",guestsBooked:"الضيوف المحجوزون",noneToday:"لا يوجد شيء مجدول هنا اليوم.",dashboard:"لوحة التحكم",manage:"البرنامج",totalBookings:"حجوزات هذا الأسبوع",activities:"الأنشطة",occupancy:"متوسط الإشغال",waitlisted:"في قوائم الانتظار",addActivity:"إضافة نشاط",editActivity:"تعديل النشاط",deleteActivity:"حذف",actName:"اسم النشاط",desc:"الوصف",location:"المكان",time:"الوقت",capacity:"السعة",entertainer:"المنشط(ون)",imageUrl:"رابط الصورة (اختياري)",category:"الفئة",day:"اليوم",makeHighlight:"نشاط اليوم المميز",save:"حفظ",saved:"تم الحفظ",deleted:"تم الحذف",bookingOk:"تم تأكيد الحجز!",waitOk:"تمت الإضافة لقائمة الانتظار",cancelled:"تم الإلغاء",loginErr:"يرجى التحقق من بياناتك والمحاولة مرة أخرى.",demoNote:"وضع المعاينة ببيانات تجريبية — اربط Supabase في الملف.",reviews:"هل تستمتع بعطلتك؟",reviewsSub:"شارك تجربتك — هذا يعني الكثير لفريقنا.",followUs:"تابع الفريق",none:"—",arrival:"يوم الوصول",departure:"يوم المغادرة",otherUsers:"دخول الفريق",backToGuest:"دخول الضيف",usersTab:"الحسابات",appTab:"التطبيق",appName:"اسم التطبيق",appSubtitle:"العنوان الفرعي",colorsHead:"الألوان",primaryC:"اللون الرئيسي",accentC:"لون مميز",linksHead:"روابط التقييم",socialHead:"وسائل التواصل",addUser:"إضافة مستخدم",displayName:"الاسم المعروض",roleLabel:"الدور",teamAccounts:"حسابات الفريق",guestStats:"إحصائيات الضيوف",uniqueGuests:"غرف الضيوف",totalPeople:"أشخاص محجوزون",language:"اللغة",userExists:"اسم المستخدم موجود بالفعل",tickets:"التذاكر",buyTicket:"شراء تذكرة",myTickets:"تذاكري",price:"السعر",qty:"العدد",reserved:"محجوز",paid:"مدفوع",payNote:"احجز في التطبيق وادفع عند مكتب الترفيه أو الاستقبال.",ticketOk:"تم حجز التذكرة!",nationality:"الجنسية",natStats:"الجنسيات",addTicket:"إضافة فعالية",editTicket:"تعديل الفعالية",markPaid:"وضع كمدفوع",markReserved:"وضع كمحجوز",styleHead:"نمط الخط",buttonHead:"نمط الأزرار",menuHead:"عناوين القائمة",bgC:"الخلفية",fontElegant:"أنيق",fontRoyal:"ملكي",fontModern:"عصري",fontSoft:"ناعم",btnRounded:"مستدير",btnPill:"كبسولة",btnSquare:"مربع",ticketsNone:"لا توجد فعاليات بعد.",orders:"الطلبات",soldOut:"نفدت التذاكر",opMorning:"برنامج الصباح",opAfternoon:"برنامج بعد الظهر",opEvening:"برنامج المساء",opDaytime:"أنشطة نهارية",opDayEvents:"فعاليات نهارية",opSpecial:"فعاليات خاصة",startTime:"وقت البدء",endTime:"وقت الانتهاء",operation:"البرنامج",chooseCat:"اختر فئة",backToCats:"كل الفئات",myActs:"أنشطتي",myActsSub:"الأنشطة المسندة إليك",chatManager:"مراسلة المدير",teamChat:"دردشة الفريق",editMsg:"تعديل الرسالة",deleteMsg:"حذف الرسالة",noStaffMsg:"لا توجد رسائل بعد. سلّم على مديرك!",shirtNumber:"رقم القميص",myWorkDay:"يوم عملي",dayPlan:"خطة اليوم",dayOff:"يوم إجازة",entranceDuty:"مناوبة المدخل",dressCode:"قواعد اللباس",restaurantTheme:"ثيم المطعم",dailyStandards:"الجدول اليومي",eveningShowLbl:"عرض المساء",liveBandLbl:"الفرقة الحية",makeupPractice:"تدريب تعويضي",practiceToday:"تدريب الفريق اليوم (45 د)",youAreOff:"أنت في إجازة اليوم - استمتع!",youHaveEntrance:"لديك مناوبة المدخل اليوم",teamPlanFull:"خطة الأسبوع كاملة",selectDay:"اختر اليوم",noNumber:"لا يوجد رقم - اسأل مديرك",djSchedule:"جدول الدي جي",std_breakfast:"الفطور",std_mmeet:"اجتماع الصباح",std_start:"وقت البدء — الاستعداد في المواقع",std_lunch:"الغداء",std_fmorning:"نهاية دوام الصباح",std_ameet:"اجتماع بعد الظهر",std_fafternoon:"نهاية دوام بعد الظهر",std_dinner:"العشاء",std_stage:"افتتاح المسرح",std_emeet:"اجتماع المساء",std_yoga:"مقدّم اليوغا/الغروب يغادر مبكراً",std_fevening:"نهاية دوام المساء",n_sport:"زي رياضي",n_mact:"أنشطة الصباح 10:00–12:30",n_practice:"13:15 يوم الاثنين/الأربعاء/الجمعة (تدريب 45 د)",n_aact:"أنشطة بعد الظهر 15:00–17:00",n_yogahost:"17:15 لمقدّم اليوغا/الغروب",n_eshow:"عرض المساء والموسيقى الحية من 20:00",n_special:"23:30 في ليالي الفعاليات الخاصة (مثل Beach Party)",practiceInline:"13:15 اليوم — تدريب 45 د",dj_wed:"لا توجد فترة بعد الظهر — الحضور 16:30 لتشغيل Sunset Instrument Party (17:00–19:00) والبقاء حتى الإغلاق (23:00)",dj_thu:"يوم إجازة — الفرقة الحية تتولى الموسيقى (فعالية واحدة فقط: Foam Party)",dj_other:"المغادرة 16:30 والعودة 19:00 لفتح المسرح",trainsToday:"يتدرب بشكل فردي اليوم",busTimes:"مواعيد الحافلة",busSchedule:"جدول حافلة الفريق",busToHotel:"سكن الفريق ← الفندق",busToHouse:"الفندق ← سكن الفريق",busEditHint:"وقت مغادرة واحد لكل سطر",noBusTimes:"لا توجد مواعيد بعد — أضِفها في إعدادات التطبيق.",busNextHint:"المغادرة القادمة",addBus:"إضافة حافلة",editBus:"تعديل الحافلة",busDirection:"الاتجاه",busTimeLbl:"وقت المغادرة",busNoteLbl:"ملاحظة (اختياري)",busNoteHint:"مثال: الجمعة فقط",settingsHub:"الإعدادات",appSettingsItem:"تصميم وإعدادات التطبيق",aiItem:"مساعد الذكاء",exportItem:"تصدير البيانات (Excel/PDF)",busItem:"جدول الحافلة",settingsSub:"كل ما تحتاجه لإدارة وتخصيص تطبيقك",st_todo:"لم يبدأ",st_live:"جارٍ",st_done:"انتهى",cancelBtn:"إلغاء",confirmTitle:"هل أنت متأكد؟",cannotUndo:"لا يمكن التراجع عن هذا الإجراء.",delActivityQ:"حذف هذا النشاط؟",delUserQ:"حذف هذا الحساب؟",delReqQ:"حذف هذا الطلب؟",delBusQ:"حذف هذه الحافلة؟",delMsgQ:"حذف هذه الرسالة؟",offlineMsg:"غير متصل — عرض آخر البيانات المحفوظة",backOnlineMsg:"عاد الاتصال — جارٍ المزامنة...",loadingMsg:"جارٍ التحميل...",errSave:"تعذّر الحفظ. حاول مرة أخرى.",errNet:"لا يوجد اتصال. تحقق من الإنترنت.",fieldRequired:"يرجى ملء هذا الحقل",invalidTime:"الصيغة 08:00",invalidNumber:"أدخل رقماً صحيحاً",updateReady:"يتوفر إصدار جديد — أعد فتح التطبيق للتحديث",serverHead:"خادم آمن (اختياري)",serverHint:"الصق روابط Supabase Edge Function هنا. عندها يبقى مفتاح الذكاء على الخادم بدل الهاتف.",errHttps:"يجب أن يبدأ الرابط بـ https://",noDataTitle:"متصل، لكن لا توجد بيانات",noDataMsg:"وصل التطبيق إلى قاعدة البيانات لكنه لم يستلم شيئاً — غالباً قواعد الوصول. شغّل سكربت الإصلاح في Supabase ثم أعد التحميل.",noDataRooms:"لم يتم العثور على غرف",eventsToday:"فعاليات اليوم",noEventsToday:"لا توجد فعالية خاصة اليوم",practiceHead:"تدريب الفريق",practiceWindow:"12:30 – 13:15 (45 د)",makeupWindow:"45 د — فردي",aiEndpointErr:"رابط الخادم غير متاح — تحقق من النشر أو أفرغ الحقل",aiEndpointFallback:"الخادم غير متاح — يتم استخدام المفتاح على هذا الجهاز",themeHead:"مظهر التطبيق",themeHint:"لكل مظهر نسخة فاتحة وداكنة — بدّل بالشمس/القمر في القائمة.",themeCustom:"ألوان مخصصة",themeLight:"فاتح",themeDark:"داكن",quizTab:"مسابقة اليوم",quizToday:"سؤال اليوم",quizAnswerPh:"إجابتك...",quizSend:"إرسال الإجابة",quizDone:"تم الإرسال — شكراً!",quizNone:"لا يوجد سؤال اليوم. عد غداً!",quizMine:"إجابتك",quizCenter:"مركز المسابقة",quizNew:"سؤال جديد",quizFor:"لـ",quizForGuest:"الضيوف",quizForStaff:"المنشطون",quizQuestion:"السؤال",quizHint:"تلميح (اختياري)",quizKey:"الإجابة الصحيحة (تراها أنت فقط)",quizReplies:"الإجابات",quizNoReplies:"لا توجد إجابات بعد",quizSaved:"تم نشر السؤال",quizAlready:"لقد أجبت اليوم بالفعل",todayPlanExp:"خطة اليوم (للإدارة)",navBack:"رجوع",navForward:"تقدم",genderLbl:"الجنس",genderM:"ذكر",genderF:"أنثى",genderNone:"غير محدد",teamSummary:"ملخص الفريق",totalEntertainers:"إجمالي المنشطين",byGender:"حسب الجنس",byNationality:"حسب الجنسية",teamOverview:"نظرة عامة على الفريق",typeNationality:"اكتب الجنسية",natOtherHint:"غير موجودة في القائمة؟ اختر أخرى واكتبها.",editDuty:"تعديل الإجازة والمدخل",dutyFor:"المناوبة ليوم",selectDayOff:"من في إجازة",selectEntrance:"مناوبة المدخل",resetDefault:"العودة للخطة القياسية",customDay:"معدّل",standardDay:"الخطة القياسية",workingToday:"يعملون",dayOffToday:"في إجازة",totalTeam:"إجمالي الفريق",dutySaved:"تم تحديث المناوبة",noOneOff:"لا أحد في إجازة",monthAtt:"الحضور الشهري",attP:"حاضر",attO:"إجازة",attA:"غائب",attLegend:"P = حاضر · O = إجازة · A = غائب",attTapHint:"اضغط على اليوم لتغييره. الرمادي من الخطة.",attAuto:"من الخطة",attTotalsP:"أيام العمل",attTotalsO:"أيام الإجازة",attTotalsA:"أيام الغياب",attExport:"كشف الحضور الشهري",prevMonth:"الشهر السابق",nextMonth:"الشهر التالي",attSaved:"تم تحديث الحضور",workDays:"أيام العمل",monthTotals:"إجماليات الشهر",teamWorkDays:"أيام عمل الفريق",avgPerPerson:"المتوسط لكل شخص",hotelInfoTab:"معلومات الفندق",hotelInfoHint:"أوقات العمل والواي فاي وأكثر أسئلة الضيوف",addInfo:"إضافة معلومة",infoTitle:"العنوان",infoValue:"التفاصيل",noInfo:"لا توجد معلومات بعد",galleryTab:"الصور",galleryHint:"صور من عروضنا وأنشطتنا",addPhoto:"إضافة صورة",noPhotos:"لا توجد صور بعد — عد بعد عرض الليلة!",photoCaption:"تعليق (اختياري)",attentionHead:"يحتاج انتباهك",allGood:"كل شيء على ما يرام",attEmptyAct:"أنشطة اليوم بدون حجز",attWaitReq:"طلبات ضيوف تنتظر",attLowRate:"تقييمات منخفضة هذا الأسبوع",attStaffReq:"طلبات فريق تنتظر",attNoShow:"أعضاء لم يُسجَّلوا اليوم",trendsHead:"الاتجاهات",last7:"آخر 7 أيام",topActs:"الأكثر شعبية",lowActs:"الأقل شعبية",bookingTrend:"الحجوزات يومياً",myAttendance:"حضوري",myFeedback:"تقييماتي",noMyFeedback:"لا توجد تقييمات بعد",askManager:"اسأل المدير",myRequestsTeam:"طلباتي",newTeamReq:"طلب جديد",reqDayOff:"تغيير يوم الإجازة",reqProblem:"الإبلاغ عن مشكلة",reqCannot:"لا أستطيع تقديم نشاط",reqOther:"شيء آخر",reqDetail:"اكتب لمديرك",reqDateOpt:"أي يوم (اختياري)",teamRequests:"طلبات الفريق",noTeamReqs:"لا توجد طلبات من الفريق",reqApprove:"موافقة",reqDecline:"رفض",reqReply:"رد (اختياري)",statusOk:"تمت الموافقة",statusNo:"مرفوض",reqSent:"أُرسل إلى مديرك",thankYou:"شكراً!",shareExp:"هل تود مشاركة تجربتك؟",reviewLater:"ربما لاحقاً",howWasIt:"كيف كانت؟",qrTab:"رمز QR",qrHint:"اطبعه وضعه عند المسبح والبار والاستقبال",qrDownload:"فتح صفحة الطباعة",stayEnded:"انتهت إقامتك — شكراً لزيارتك!",accountOff:"هذا الحساب غير مفعّل. يرجى سؤال مديرك.",activeAcc:"الحساب مفعّل",inactiveAcc:"غير مفعّل",deactivate:"إلغاء التفعيل",activate:"تفعيل",resetPass:"إعادة تعيين كلمة المرور",newPassIs:"كلمة المرور الجديدة",passCopied:"سلّمها للشخص — تحل محل القديمة",tooManyTries:"محاولات كثيرة. انتظر لحظة.",logoLbl:"الشعار",logoHint:"يظهر في شاشة الدخول",hotelNameLbl:"اسم الفندق",timezoneLbl:"المنطقة الزمنية للفندق",timezoneHint:"الأوقات والتنبيهات تتبع ساعة الفندق وليس هاتف الضيف",currencyLbl:"العملة",contactLbl:"جهة الاتصال",fontSizeLbl:"حجم النص",fsSmall:"صغير",fsNormal:"عادي",fsLarge:"كبير",fsXl:"كبير جداً",autoDarkLbl:"اتباع الوضع الداكن للهاتف",featuresLbl:"الميزات",featQuiz:"مسابقة اليوم",featTickets:"التذاكر",featGallery:"الصور",featBus:"جدول الحافلة",featInfo:"معلومات الفندق",previewTheme:"معاينة",applyTheme:"استخدام هذا المظهر",previewOn:"معاينة — لم تُحفظ بعد",secIdentity:"هوية الفندق",secLook:"المظهر",secAccess:"الوصول",upToToday:"حتى اليوم",countedDays:"الأيام المحتسبة",workingEntToday:"المنشطون العاملون اليوم",weatherTab:"الطقس",weatherToday:"اليوم",weatherWeek:"هذا الأسبوع",weatherFail:"الطقس غير متاح الآن",feelsLike:"يشعر كأنه",windLbl:"الرياح",latLbl:"خط العرض",lonLbl:"خط الطول",weatherLoc:"موقع الطقس",weatherLocHint:"إحداثيات الفندق (الغردقة افتراضياً)",wSun:"مشمس",wPartly:"غائم جزئياً",wCloud:"غائم",wFog:"ضباب",wDrizzle:"رذاذ",wRain:"مطر",wShower:"زخات",wSnow:"ثلج",wStorm:"عاصفة رعدية",wWind:"عاصف",setBrand:"العلامة والهوية",setBrandSub:"الشعار واسم الفندق وجهة الاتصال",setTheme:"المظهر والألوان",setThemeSub:"الألوان والخطوط وحجم النص والوضع الداكن",setMenus:"القوائم والصفحات",setMenusSub:"إعادة التسمية والترتيب وصفحاتك",setNotif:"الإشعارات",setNotifSub:"الصوت والتنبيهات",setLinksT:"الروابط والتقييمات",setLinksSub:"التواصل الاجتماعي ومواقع التقييم",setFeatures:"الميزات",setFeaturesSub:"تشغيل أو إيقاف أجزاء من التطبيق",setLocation:"الموقع والوقت",setLocationSub:"المنطقة الزمنية وموقع الطقس",setAdvanced:"متقدم",setAdvancedSub:"الخادم الآمن والذكاء ورمز QR",setData:"البيانات",setDataSub:"تصدير كل شيء إلى Excel أو PDF",addTime:"إضافة وقت آخر",timesLbl:"أوقات العمل",guestCrm:"ملفات الضيوف",crmSearch:"ابحث بالغرفة أو الاسم أو الجنسية",guest360:"ملف الضيف",stayLen:"الإقامة",nights:"ليالٍ",attendedActs:"الأنشطة المحضورة",favActs:"الأنشطة المفضلة",msgCount:"الرسائل",quizPart:"إجابات المسابقة",appUsage:"أيام استخدام التطبيق",noGuests:"لا يوجد ضيوف بعد",openProfile:"فتح الملف",taskPriority:"الأولوية",prLow:"منخفضة",prNormal:"عادية",prHigh:"عالية",prUrgent:"عاجلة",taskLoc:"المكان",taskDeadline:"الموعد النهائي",stNew:"جديدة",stAccepted:"مقبولة",stProgress:"قيد التنفيذ",stCompleted:"مكتملة",stVerified:"تم التحقق",overdue:"متأخرة",acceptTask:"قبول",startTask:"بدء",completeTask:"إكمال",verifyTask:"تحقق",taskProof:"صورة إثبات",taskComments:"التعليقات",addComment:"إضافة تعليق",taskHistory:"السجل",createdBy:"أنشأها",noTasks:"لا توجد مهام",employeeProfile:"ملف الموظف",employeeId:"رقم الموظف",positionLbl2:"المنصب",phoneLbl2:"الهاتف",whatsappLbl2:"واتساب",instagramLbl2:"إنستغرام",hireDate:"تاريخ التعيين",suspend:"إيقاف",assignedActs:"الأنشطة المسندة",performance:"الأداء",guestRatings:"تقييمات الضيوف",pointsLbl:"النقاط",rankLbl:"الترتيب",tasksDone:"المهام المكتملة",onTime:"في الوقت",viewProfile:"عرض الملف",photosLbl:"الصور",addPhotos:"إضافة صور",removePhoto:"إزالة الصورة",cropLogo:"قص الشعار",cropHint:"اسحب للتحريك، المؤشر للتكبير",useCrop:"استخدام",removeLogo:"إزالة الشعار",photoOf:"من",requestChange:"طلب تعديل",changeRequest:"طلب تعديل",whatToChange:"ما الذي يجب تغييره؟",reqSentMgr:"أُرسل إلى المدير",profileReadOnly:"المدير فقط يمكنه التغيير",pageBuilder:"مصمم الصفحات",pbHint:"ابنِ صفحة من كتل — بدون كود",pbNewPage:"صفحة جديدة",pbEditPage:"تعديل الصفحة",pbBlocks:"الكتل",pbAddBlock:"إضافة كتلة",blkHeading:"عنوان",blkText:"نص",blkImage:"صورة",blkGallery:"معرض",blkButton:"زر",blkDivider:"فاصل",blkSpacer:"مسافة",blkCard:"بطاقة",blkList:"قائمة",blkVideo:"فيديو",blkMap:"خريطة",pbContent:"المحتوى",pbStyle:"النمط",fontSizeB:"حجم الخط",fontFamilyB:"نوع الخط",alignLbl:"المحاذاة",alignLeft:"يسار",alignCenter:"وسط",alignRight:"يمين",colorLbl:"اللون",bgLbl:"الخلفية",btnShape:"شكل الزر",shapeRound:"دائري",shapePill:"بيضاوي",shapeSquare:"مربع",btnSize:"حجم الزر",sizeS:"صغير",sizeM:"متوسط",sizeL:"كبير",btnLink:"رابط (اختياري)",boldLbl:"عريض",moveBlockUp:"لأعلى",moveBlockDown:"لأسفل",dupBlock:"نسخ",delBlock:"حذف الكتلة",pbPreview:"معاينة",pbEmpty:"هذه الصفحة فارغة — أضف أول كتلة",pbSaved:"تم حفظ الصفحة",listItems:"عنصر واحد لكل سطر",videoUrl:"رابط فيديو (يوتيوب)",mapAddr:"العنوان أو المكان",pbWho:"من يراها",pbIcon:"أيقونة",pbTitle:"عنوان الصفحة",persons:"عدد الأشخاص",personsShort:"شخص",attN:"لم يُعيَّن بعد",notHiredYet:"قبل تاريخ التعيين",mapTab:"الخريطة المباشرة",shareLoc:"مشاركة موقعي",shareLocHint:"فقط أثناء التشغيل. أوقفه في أي وقت وسيُحذف موقعك.",locDenied:"تم رفض إذن الموقع على هذا الهاتف",noOneSharing:"لا أحد يشارك موقعه الآن",lastSeen:"آخر تحديث",mapHint:"يظهر هنا فقط من فعّل المشاركة",minsAgo:"د مضت",justNow:"الآن",locTeam:"الفريق",locGuests:"الضيوف",assignCenter:"الإسنادات",asgActs:"الأنشطة",asgWho:"من يستطيع ماذا",asgOpen:"لا أحد بعد",asgNobody:"لا أحد بعد",allAssigned:"تم إسناد كل شيء",autoAssign:"إسناد تلقائي",autoAssignHint:"يعتمد على خطة اليوم والإجازات والغياب والمهارات.",autoReviewHint:"راجع الاقتراحات وغيّر من تشاء ثم طبّق.",applyAssign:"تطبيق",asgApplied:"تم إسنادها",asgSkip:"اتركه فارغاً",asgNoSkill:"لا أحد متاح يستطيع ذلك",asgAllBusy:"كل القادرين مشغولون",nobodyWorking:"لا أحد يعمل في هذا اليوم",asgWhoHint:"اضغط على شخص لتحديد مهاراته",noSkillsSet:"لم يُحدَّد شيء — يمكن إسناد أي شيء",skillEditHint:"ضغطة = يستطيع. ضغطتان = لا يستطيع. ثلاث = مسح.",skCan:"يستطيع",skCant:"لا يستطيع",skAny:"—",sk_sport:"رياضة",sk_water:"مائية",sk_dance:"رقص",sk_show:"عرض",sk_kids:"أطفال",sk_music:"موسيقى",sk_dj:"دي جي",sk_games:"ألعاب",sk_fitness:"لياقة",sk_host:"تقديم",sk_craft:"أشغال يدوية",sk_beach:"شاطئ",needsSkill:"المهارة المطلوبة",noActsYet:"أضف الأنشطة إلى البرنامج أولاً — ثم يمكنك تحديد من يستطيع ماذا.",canRunIt:"يستطيعون",editDayOff:"تعديل يوم الإجازة",noOneEntrance:"لم يُحدَّد أحد",teamChatTab:"رسائل الفريق",guestChatTab:"رسائل الضيوف",attV:"إجازة",attLeft:"غادر الفندق",markLeft:"غادر الفندق",markLeftHint:"يُحتفظ بحضوره ويُحرَّر رقمه لشخص جديد.",leftDate:"آخر يوم عمل",undoLeft:"عاد للعمل",leftTag:"غادر",startPage:"صفحة بدء التطبيق",startPageHint:"عند فتح التطبيق ستصل إلى هنا.",todayWord:"اليوم",yesterdayWord:"أمس",practiceDays:"الإثنين / الأربعاء / الجمعة",arrangeSections:"ترتيب هذه الصفحة",arrangeHint:"حرّك أجزاء الصفحة لأعلى أو لأسفل. يُحفظ للجميع.",dayInfoSec:"معلومات اليوم",wholeDay:"اليوم كامل",morningPart:"الصباح",afternoonPart:"بعد الظهر",eveningPart:"المساء",itemsWord:"عنصر",editBooking:"تعديل الحجز",openGuest:"فتح ملف الضيف",bookedAt:"تم الحجز",booked:"محجوز",waitlist:"قائمة الانتظار",status:"الحالة",standardsHead:"المعايير اليومية",noGuestAccount:"لا يوجد حساب ضيف لهذه الغرفة",finishedChip:"انتهى",setVacation:"تحديد إجازة",setVacationHint:"اختر الشخص وأول وآخر يوم.",clearVacation:"إلغاء الإجازة",person:"الشخص",fromDate:"من",toDate:"إلى",daysWord:"أيام",checkDates:"تحقق من التواريخ",dayWord:"اليوم",nightsWord:"ليالٍ",nightsLeft:"ليالٍ متبقية",stayDayOf:"اليوم {n} من {t}",stayWelcome:"أهلاً بك — إجازتك تبدأ اليوم",stayLastDay:"آخر يوم — نتمنى أن تكون قد استمتعت",plannedAhead:"مخطط مسبقاً",addMember:"إضافة عضو",addAttOnly:"الحضور فقط",addAttOnlyHint:"اسم ورقم فقط (11–50) لكشف الحضور. بدون تسجيل دخول، بدون أنشطة، ولا يُحتسب ضمن الفريق.",attNumber:"الرقم (11–50)",attNumRange:"يجب أن يكون الرقم بين 11 و50",numberTaken:"هذا الرقم مستخدم بالفعل",nameNeeded:"يرجى كتابة الاسم",attOnlyTag:"· حضور فقط",whichMonth:"أي شهر",whichDay:"أي يوم",selectMsgs:"تحديد الرسائل",clearChat:"مسح المحادثة",selectedWord:"محدد",selectAll:"تحديد الكل",selectNone:"إلغاء التحديد",deleteMsgsQ:"حذف {n} رسالة؟",clearChatQ:"مسح المحادثة بالكامل؟",clearChatHint:"سيتم حذف كل الرسائل ({n}) لدى الجميع.",cannotUndo:"لا يمكن التراجع عن هذا.",deleteReqQ:"حذف هذا الطلب؟",allDays:"كل الأيام",whichTime:"أي وقت",allDayLong:"اليوم كامل",filterNote:"سيتم تصدير:",noFilterNote:"سيتم تصدير كل شيء.",officialAtt:"{hotel} — كشف الحضور الشهري الرسمي",sigEntertainment:"Entertainment Manager",sigSecurity:"Security Manager",sigFB:"Food and Beverage Manager",sigGM:"General Manager",startedOn:"أول يوم",lastDayOpt:"آخر يوم (اختياري)",attDatesHint:"الأيام قبل أول يوم وبعد آخر يوم لا تُحتسب.",delete:"حذف",deleteQ:"حذف هذا الشخص؟",attDeleteHint:"سيُحذف سجل حضوره أيضاً. اضبط آخر يوم بدلاً من ذلك إذا أردت الاحتفاظ به.",eventsCrewTag:"كل الفعاليات والعروض",eventsCrewHint:"هذا الشخص حاضر في كل فعالية وعرض — الدي جي للموسيقى والسوشيال ميديا للتصوير. ليس ضمن جدول الأنشطة، لذا لا يوجد ما يُحدَّد هنا.",wasBooked:"كنت محجوزاً",bookNowLive:"جارٍ الآن — انضم",removeBooking:"حذف الحجز",removeBookingQ:"حذف هذا الحجز؟",removeBookingHint:"سيفقد الضيف مكانه. لا يمكن التراجع.",skillEditHint2:"حدّد الأنشطة من برنامجك. ضغطة = يستطيع. ضغطتان = لا يستطيع. ثلاث = مسح.",autoAssign:"توزيع الأنشطة تلقائياً",autoHint:"نشاط واحد صباحاً وواحد بعد الظهر — بتوزيع عادل. الفعاليات يشارك بها الفريق كله، وأنت والدي جي لا تُسنَد لكما أنشطة.",autoDay:"هذا اليوم",autoWeek:"الأسبوع كامل",onlyEmptyLbl:"فقط الأنشطة بدون إسناد",replaceAllLbl:"استبدال الكل",autoPreview:"الاقتراح",autoApply:"تطبيق الخطة",autoNothing:"لا يوجد ما يُسنَد — تحقق من الإجازات والبرنامج",autoDone:"تم توزيع الأنشطة",morningSlot:"الصباح",afternoonSlot:"بعد الظهر",perPerson:"لكل شخص",noOneAvailable:"لا يوجد أحد متاح في هذا اليوم",eventsAllTeam:"الفعاليات — الفريق كله",changeWho:"تغيير",noneAssigned:"— لا أحد —",balanceLbl:"التوازن",evenSpread:"موزّع بالتساوي",spreadOff:"فرق قدره",editHint:"اضغط على أي اسم لتغييره قبل التطبيق",recalc:"إعادة التوزيع",fairest:"الأكثر عدلاً",activityCount:"أنشطة",zoomLbl:"تكبير",totalAllTeam:"إجمالي الفريق (مع المدير)",infoTime:"وقت العمل",infoPlace:"الموقع",translateBtn:"ترجمة",translating:"جارٍ الترجمة...",translateFail:"تعذّرت الترجمة",showOriginal:"إظهار الأصل",builderTab:"منشئ القائمة",builderHint:"غيّر الاسم أو الترتيب أو أخفِ أو أضف عناصر — لكل دور، بدون كود",forRole:"لـ",roleGuest:"الضيوف",roleStaff:"المنشطون",roleManager:"المدير",moveUp:"لأعلى",moveDown:"لأسفل",hideItem:"مخفي",showItem:"ظاهر",renameItem:"الاسم",addLink:"إضافة صفحتك",linkTitle:"العنوان",linkUrl:"عنوان الويب",linkText:"النص المعروض",linkKind:"النوع",kindLink:"رابط ويب",kindPage:"صفحة نصية",resetMenu:"إعادة الضبط",builderSaved:"تم تحديث القائمة",customPage:"صفحتي",openLink:"فتح",translatedTag:"مترجم",infoPhoto:"صورة",totalRow:"الإجمالي",months:["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"],statusLegend:"الحالة",almSoonG:"يبدأ خلال 5 دقائق",almStartG:"يبدأ الآن",almDoneG:"انتهى",almSoonS:"نشاطك يبدأ خلال 5 دقائق — كن هناك الآن",almStartS:"نشاطك يبدأ الآن",almDoneS:"انتهى — يرجى جمع التقييم مع رقم الغرفة",almSoonTeam:"يبدأ خلال 5 دقائق",almStartTeam:"يبدأ الآن",almDoneTeam:"انتهى",secProgram:"البرنامج",secBookings:"حجوزاتي",secConnect:"التواصل والفريق",secManage:"الإدارة",secTeamwork:"عملي",secGuests:"الضيوف",secSettings:"الإعدادات",uploadErr:"فشل الرفع — تحقق من إعداد التخزين",photo:"صورة",uploadPhoto:"اضغط لرفع صورة",changePhoto:"تغيير الصورة"},EXTRA.ar)
};

/* ---------------- state ---------------- */
const S = {
  lang:"en", theme:"light", session:null, tab:"home",
  day:(new Date().getDay()+6)%7, favorites:[],   // initial only; todayIndex() takes over after load
  sub:{program:"acts", guests:"bookings", team:"accounts", dash:"overview"}, op:null, cat:null,
  chatRoom:null, seenNote:0,
  activities:[], bookings:[], users:[], tickets:[], orders:[],
  rooms:[], accounts:[], messages:[], requests:[], tasks:[], notes:[], attendance:[], feedback:[], aiChat:[], profiles:[],
  buses:[], quizzes:[], quizReplies:[], staffAtt:[], attMonth:null, photos:[], staffReqs:[], weather:null, weatherBusy:false, crmQuery:"", drawerOpen:null, pb:null, assignDay:null, openDay:{}, chatSel:null, exportMonth:null, exportDay:"", exportSlot:"", settings:{...DEFAULT_SETTINGS}, loadError:false
};
Object.assign(DICT.en, {
  arrangeAnyHint:"Move the parts of this page up or down, or hide the ones you never use. Saved for everyone.",
  secTitles:"Section titles",
  secTitlesHint:"The grey headings above each group of menu items.",
  renameGroup:"Rename section",
  fbNew:"New feedback",
  fbEdit:"Edit feedback",
  fbGuestName:"Guest name",
  fbOverall:"Overall",
  fbDepartments:"Departments rated",
  fbAnalytics:"Feedback analytics",
  fbByDept:"Rating by department",
  fbNotRated:"Not rated",
  fbDetails:"Feedback details",
  fbResponses:"ratings",
  fbExport:"Export feedback",
  fbTapHint:"Tap a department or a feedback to open the details.",
  fbTapOne:"Tap a feedback to open the details.",
  fbCollectedBy:"Collected by",
  allMonths:"All months",
  fbFilterHead:"What to export",
  fbRoomHint:"Type the room number — if the guest has an account their name and nationality fill in by themselves.",
  fbFoundGuest:"Guest found",
  fbExactDate:"One exact date (optional)",
  fbExactHint:"Leave this empty to take the whole month.",
  fbReport:"Guest Feedback Report",
  fbPrepared:"Prepared",
  fbCollected:"Feedback collected",
  fbHighest:"Highest rated",
  fbLowest:"Needs attention",
  fbWholeStay:"All feedback",
  fbNothing:"No feedback matches this selection.",
  rename:"Rename",
  fbDeptsEdit:"Departments",
  fbDeptsHint:"These are the things guests rate. Rename them, move them, add your own or remove the ones you never use.",
  fbAddDept:"Add a department",
  fbDeptName:"Department name",
  fbDeptGone:"Removed. Ratings already collected for it stay in the database, they are just no longer shown.",
  fbLastDept:"Keep at least one department.",
  fbResetDepts:"Back to the standard 15",
  fbStrong:"All departments strong",
  fbWholeHotel:"Whole hotel",
  fbAllEqual:"Every department scored the same",
  fbPerfect:"Perfect across the board",
  fbTied:"{n} departments tied at the top",
  fbNoneWeak:"Nothing scored under five",
  fbFiveShare:"Five-star feedback",
  fbDeptsRated:"Departments rated",
  fbLowestRated:"Lowest rated",
  fbHotelGeneral:"The hotel in general \u2014 rated good all round",
  fbAllFiveN:"All five stars",
  fbToReview:"To review",
  fbAllFiveSub:"Nothing to follow up",
  fbToReviewSub:"Something to improve",
  fbStatusNone:"No attention",
  fbStatusAttn:"Attention",
  fbStatusPriority:"Priority attention",
  fbReviewHead:"Guests with feedback to review",
  fbReviewSub:"Worst first. Every point a guest raised, even from guests who were otherwise delighted.",
  fbPerfectHead:"All five stars",
  fbPerfectSub:"Nothing to follow up with these guests.",
  fbNoReview:"No guest raised anything. Every rating was a full five.",
  fbLegend2:"Green: nothing to follow up \u00b7 Orange: something to improve \u00b7 Red: needs attention first. A high overall score does not mean there is nothing to fix.",
  liveOps:"Live operations",
  startActivity:"Start activity",
  yourDay:"Your day",
  nowLbl:"Now",
  tonightLbl:"Tonight",
  readyTeam:"Team",
  readySetup:"Setup",
  readyNothing:"No requirement sheet yet",
  readyMake:"Make a requirement sheet",
  registered:"registered",
  nothingTonight:"Nothing on tonight.",
  liveNow:"Live",
  liveSoon:"Starts in {n} min",
  liveNoStaff:"No staff",
  liveAssigned:"Assigned",
  liveDone:"Done",
  liveNothing:"Nothing running right now.",
  opsToday:"Activities today",
  opsPeople:"Participants",
  reqKind:"Kind",
  reqFromProgram:"Pick it from the programme",
  reqFromProgramOwn:"Type it myself",
  reqFromProgramHint:"Choosing one fills in the name, the day, the time and the place. Anything you add to the programme shows up here.",
  reqNoProgram:"Nothing of this kind in the programme yet.",
  reqDate:"Date",
  reqResetLists:"Back to the standard lists",
  reqTab:"Requirements",
  reqHead:"Requirement sheets",
  reqSub:"What we need, how much, and which department provides it. Send it the day before.",
  reqEvent:"Event requirements",
  reqActivity:"Activity requirements",
  reqParty:"Party requirements",
  reqKindEvent:"Event",
  reqKindActivity:"Activity",
  reqKindParty:"Party",
  reqNew:"New requirement sheet",
  reqEdit:"Edit requirement sheet",
  reqName:"Name",
  reqLocation:"Location",
  reqResponsible:"Responsible",
  reqNote:"Special request / note",
  reqNeed:"Need",
  reqQty:"Qty",
  reqDept:"Department",
  reqStatus:"Status",
  reqAddLine:"Add a line",
  reqStandard:"Load the standard list",
  reqDepts:"Departments",
  reqDeptsHint:"The departments that can be asked to provide something.",
  reqTemplates:"Standard lists",
  reqTemplatesHint:"What gets loaded into a new sheet. One list per kind.",
  reqAddDept:"Add a department",
  reqLastDept:"Keep at least one department.",
  reqNone:"No requirement sheet yet.",
  reqNoLines:"No lines yet. Add one, or load the standard list.",
  reqExportOne:"Export this sheet",
  reqExportDay:"Export the day pack",
  reqBlank:"Print a blank form",
  reqDayPack:"Requirement sheets",
  reqPickDate:"Which date",
  reqAllDates:"All dates",
  reqNothingOn:"Nothing planned for that date.",
  reqLines:"lines",
  reqDelete:"Delete this sheet",
  reqSignature:"Signature",
  reqReceived:"Received by",
  fbHighRooms:"Happy rooms",
  fbLowRooms:"Unhappy rooms",
  fbHighSub:"4.5 stars and above",
  fbLowSub:"Below 4.5 stars",
  fbGuestList:"Room by room",
  fbGuestHead:"Green means happy, red means unhappy. Only the things a guest marked down are listed.",
  fbAllFive:"Everything five stars",
  fbMarkedDown:"Marked down",
  fbBelowFive:"Departments below five stars",
  fbBelowNone:"Every department scored a full five.",
  fbBelowHead:"Everything a guest scored under five, weakest first.",
  fbLegend:"Green bar: the room was happy, 4.5 stars or better. Red bar: below 4.5. Only what a guest marked down is listed under their line.",
  fbRatings:"ratings",
  fbShortOf:"short of five",
  fbMyFeedback:"Guest feedback",
  fbMySub:"Collect a rating while you are with the guest.",
  fbSeeAll:"See all my feedback",
  fbFormHint:"Tap the stars for each department. Leave a department empty if the guest did not rate it.",
  fbNoDept:"No department was rated yet.",
  fbNeedRoom:"Please write the room number",
  fbDeptSheet:"Feedback by department",
  fbOldDb:"Saved. Your database does not have the new columns yet, so the department ratings were written into the comment. Run the SQL below in Supabase once and everything moves into its own columns.",
  fbSqlNote:"Run this once in Supabase (SQL editor):",
  hideSection:"Hidden",
  showSection:"Shown",
  d_ent_general:"Entertainment in general",
  d_music_day:"Music daytime",
  d_music_night:"Music at night",
  d_day_acts:"Daytime activities",
  d_day_events:"Daytime events",
  d_equipment:"Activities materials & equipment",
  d_ent_team:"Entertainment team members",
  d_food:"Food",
  d_drinks:"Drinks",
  d_room:"Room",
  d_housekeeping:"Housekeeping",
  d_pool_beach:"Pool & Beach",
  d_alacarte:"A la carte restaurant",
  d_behaviour:"Team behaviour",
  d_reception:"Reception"
});
/* ===== GUEST FEEDBACK BY DEPARTMENT =====
   One feedback holds up to 15 department scores (1-5). They live in the
   `depts` column as JSON. If that column is missing (older database) they are
   packed into the comment instead, so nothing is ever lost. */
const FB_DEPT_KEYS=["ent_general","music_day","music_night","day_acts","day_events",
  "equipment","ent_team","food","drinks","room","housekeeping","pool_beach",
  "alacarte","behaviour","reception"];
/* The manager can rename, reorder, add and remove departments. Her list lives in
   S.settings.fbDepts as [{key,name}]; without one we use the standard fifteen.
   Keys never change once created, so ratings already collected stay attached. */
function fbDeptConf(){
  const c=S.settings && S.settings.fbDepts;
  return (Array.isArray(c) && c.length) ? c.filter(d=>d && d.key) : null;
}
function fbDeptKeys(){
  const c=fbDeptConf();
  return c ? c.map(d=>String(d.key)) : FB_DEPT_KEYS.slice();
}
function fbDeptRows(){
  const c=fbDeptConf();
  return c ? c.map(d=>({key:String(d.key), name:d.name||""}))
           : FB_DEPT_KEYS.map(k=>({key:k, name:""}));
}
const FB_SQL="alter table feedback add column if not exists depts text;\n"
  +"alter table feedback add column if not exists guest_name text;";
const FB_MARK="\n#ratings ";
function fbDeptLabel(k){
  const c=fbDeptConf(), f=c && c.find(d=>String(d.key)===String(k));
  if(f && f.name) return f.name;
  const std=t("d_"+k);
  return std==="d_"+k ? String(k) : std;
}
/* Feedback stores the login name (a shirt number). Everywhere it is SHOWN we
   want the person's real display name instead. */
function teamName(username){
  const un=String(username||"").trim();
  if(!un) return "";
  const u=(S.users||[]).find(x=>String(x.username)===un)
       || (S.profiles||[]).find(x=>String(x.username)===un);
  return (u && (u.display_name||u.name)) || un;
}
/* 1-3 red, 4 orange, 5 gold — the same scale in the app and in the export. */
function fbTone(n){ n=+n||0; return n<=0?"none":n<3.5?"low":n<4.5?"mid":"top"; }
function fbDepts(f){
  if(!f) return {};
  let d=f.depts;
  if(typeof d==="string" && d.trim()){ try{ d=JSON.parse(d); }catch(e){ d=null; } }
  if(d && typeof d==="object") return d;
  const c=String(f.comment||""); const i=c.indexOf(FB_MARK);
  if(i<0) return {};
  const out={};
  c.slice(i+FB_MARK.length).split(";").forEach(part=>{
    const bits=part.split(":"); const v=+bits[1];
    if(bits[0] && v>0) out[bits[0].trim()]=v;
  });
  return out;
}
function fbComment(f){ return String((f&&f.comment)||"").split(FB_MARK)[0].trim(); }
function fbPackComment(f){
  const d=fbDepts(f);
  const line=Object.keys(d).filter(k=>+d[k]>0).map(k=>k+":"+d[k]).join(";");
  const base=fbComment(f);
  return line ? (base+FB_MARK+line) : base;
}
function fbOverall(f){
  const v=Object.values(fbDepts(f)).map(Number).filter(n=>n>0);
  if(v.length) return Math.round(v.reduce((a,b)=>a+b,0)/v.length*10)/10;
  return +((f&&f.rate)||0);
}
function fbStars(n){
  n=+n||0;
  return `<span class="fb-stars ${fbTone(n)}">${[1,2,3,4,5].map(i=>
    `<span class="fb-st ${i<=n?"on":""}">${i<=n?"\u2605":"\u2606"}</span>`).join("")}</span>`;
}
/* Compact coloured stars for a list row. */
function fbStarLine(n){
  const r=Math.round(+n||0);
  return `<span class="fb-sline ${fbTone(r)}">${"\u2605".repeat(r)}<span class="fb-sg">${"\u2606".repeat(Math.max(0,5-r))}</span></span>`;
}
function fbDeptStats(list){
  const acc={};
  (list||[]).forEach(f=>{
    const d=fbDepts(f);
    fbDeptKeys().forEach(k=>{ const v=+d[k]; if(v>0){ acc[k]=acc[k]||{n:0,s:0}; acc[k].n++; acc[k].s+=v; } });
  });
  return fbDeptKeys().filter(k=>acc[k]).map(k=>({k,n:acc[k].n,avg:acc[k].s/acc[k].n}));
}
function fbAvgAll(list){
  const v=(list||[]).map(fbOverall).filter(n=>n>0);
  return v.length ? v.reduce((a,b)=>a+b,0)/v.length : 0;
}
/* A guest's overall score can be 4.9 and still hide something worth fixing, so
   status is decided by what they marked down, not by the average alone.
     none     - every department they rated got five
     attn     - anything under five
     priority - a really low mark (2 or less), two or more threes,
                or an overall that has genuinely dropped below 4.5 */
function fbStatus(f){
  const d=fbDepts(f);
  const vals=fbDeptKeys().map(k=>+d[k]).filter(n=>n>0);
  if(!vals.length) return fbComment(f) ? "attn" : "none";
  const under=vals.filter(n=>n<5);
  if(!under.length) return "none";
  const veryLow=vals.filter(n=>n<=2).length;
  const low=vals.filter(n=>n<=3).length;
  // a really low mark, several threes, or a three on an already sagging stay
  if(veryLow>0 || low>=2 || (low>0 && fbOverall(f)<4.5)) return "priority";
  return "attn";
}
function fbStatusLabel(st){
  return st==="priority" ? t("fbStatusPriority") : st==="attn" ? t("fbStatusAttn") : t("fbStatusNone");
}
/* One place decides what the numbers mean, so the app and the printed report
   never disagree. A department is only "needs attention" if it is genuinely
   weak — below 4.5 AND below the best one. Five out of five is never a problem. */
function fbSummary(list){
  list=list||[];
  const stat=fbDeptStats(list).sort((a,b)=>(b.avg-a.avg)||String(a.k).localeCompare(String(b.k)));
  const overall=fbAvgAll(list);
  const scores=list.map(fbOverall).filter(n=>n>0);
  const five=scores.filter(n=>n>=4.75).length;
  // Calling a 4.9 guest "unhappy" was misleading. What management needs to know
  // is who left something to follow up, not who was cross.
  const status=list.map(fbStatus);
  const allFive=status.filter(x=>x==="none").length;
  const toReview=status.filter(x=>x!=="none").length;
  const priority=status.filter(x=>x==="priority").length;
  const high=scores.filter(n=>n>=4.5).length;
  const low=scores.filter(n=>n<4.5).length;
  const top=stat[0]||null;
  const tail=stat[stat.length-1]||null;
  // naming one winner is only honest when it actually won
  const tiedTop=top ? stat.filter(d=>Math.abs(d.avg-top.avg)<0.005) : [];
  const allSame=stat.length>1 && tiedTop.length===stat.length;
  const best=(top && !allSame && tiedTop.length===1) ? top : null;
  // Anything a guest scored under five is worth naming, not only the bad ones.
  const below=stat.filter(d=>d.avg<4.995).sort((a,b)=>(a.avg-b.avg)||String(a.k).localeCompare(String(b.k)));
  const weak=below[0]||null;
  return {
    stat, overall, best, weak, below, top, tiedTop, allSame, high, low,
    allFive, toReview, priority,
    topAvg: top ? top.avg : 0,
    perfect: !!(top && stat.length && Math.abs(top.avg-5)<0.005 && (!tail || Math.abs(tail.avg-5)<0.005)),
    lowest: (tail && top && tail.k!==top.k && tail.avg<top.avg) ? tail : null,
    count: list.length,
    rated: stat.length,
    five,
    fivePct: scores.length ? Math.round(five/scores.length*100) : 0
  };
}
function fbDeptListCard(list){
  const st=fbDeptStats(list).sort((a,b)=>b.avg-a.avg);
  if(!st.length) return `<div class="empty"><div class="big">${ic("star",30)}</div>${t("fbNoDept")}</div>`;
  return `<div class="card">${st.map(d=>`<button class="fb-dept ${fbTone(d.avg)}" data-fbdept="${esc(d.k)}">
    <span class="fb-nm">${esc(fbDeptLabel(d.k))}<br><span class="mini">${d.n} ${t("fbResponses")}</span></span>
    <span class="fb-bar"><i style="width:${Math.round(d.avg/5*100)}%"></i></span>
    <span class="fb-val">${d.avg.toFixed(1)}</span></button>`).join("")}</div>`;
}
function fbCanEdit(f){
  if(!S.session) return false;
  return S.session.role==="manager" || String(f.by_user||"")===String(S.session.username||"");
}
function fbRowHtml(f){
  const d=fbDepts(f), n=fbDeptKeys().filter(k=>+d[k]>0).length;
  const who=[f.guest_name?esc(f.guest_name):"", f.nationality?esc(f.nationality):""].filter(Boolean).join(" \u00b7 ");
  return `<div class="fb-line" data-fbopen="${esc(String(f.id))}">
    <span style="min-width:0"><b>${t("room")} ${esc(f.room)}</b>${who?` \u00b7 ${who}`:""}
      <br><span class="mini">${fbStarLine(fbOverall(f))}${fbOverall(f)?` ${fbOverall(f).toFixed(1)}`:""}${n?` \u00b7 ${n} ${t("fbDepartments").toLowerCase()}`:""}</span>
      ${fbComment(f)?`<br><span class="mini">${esc(fbComment(f))}</span>`:""}
      <br><span class="mini">${mi("user")}${esc(teamName(f.by_user))} \u00b7 ${fmtTime(f.created_at)}</span></span>
    <span class="fb-chev">${ic("back",16)}</span>
  </div>`;
}
const t = k => (DICT[S.lang] && DICT[S.lang][k]) ?? DICT.en[k] ?? k;
const NATIONS=["Afghan","Albanian","Algerian","American","Andorran","Angolan","Argentine","Armenian","Australian","Austrian","Azerbaijani","Bahraini","Bangladeshi","Barbadian","Belarusian","Belgian","Belizean","Beninese","Bhutanese","Bolivian","Bosnian","Botswanan","Brazilian","British","Bruneian","Bulgarian","Burkinabe","Burmese","Burundian","Cambodian","Cameroonian","Canadian","Cape Verdean","Central African","Chadian","Chilean","Chinese","Colombian","Comoran","Congolese","Costa Rican","Croatian","Cuban","Cypriot","Czech","Danish","Djiboutian","Dominican","Dutch","East Timorese","Ecuadorean","Egyptian","Emirati","Equatorial Guinean","Eritrean","Estonian","Ethiopian","Fijian","Filipino","Finnish","French","Gabonese","Gambian","Georgian","German","Ghanaian","Greek","Grenadian","Guatemalan","Guinean","Guyanese","Haitian","Honduran","Hungarian","Icelandic","Indian","Indonesian","Iranian","Iraqi","Irish","Israeli","Italian","Ivorian","Jamaican","Japanese","Jordanian","Kazakh","Kenyan","Kosovar","Kuwaiti","Kyrgyz","Laotian","Latvian","Lebanese","Liberian","Libyan","Liechtensteiner","Lithuanian","Luxembourgish","Macedonian","Malagasy","Malawian","Malaysian","Maldivian","Malian","Maltese","Mauritanian","Mauritian","Mexican","Moldovan","Monacan","Mongolian","Montenegrin","Moroccan","Mozambican","Namibian","Nepalese","New Zealander","Nicaraguan","Nigerian","Nigerien","North Korean","Norwegian","Omani","Pakistani","Palestinian","Panamanian","Papua New Guinean","Paraguayan","Peruvian","Polish","Portuguese","Qatari","Romanian","Russian","Rwandan","Salvadoran","Samoan","Saudi","Senegalese","Serbian","Seychellois","Sierra Leonean","Singaporean","Slovak","Slovenian","Somali","South African","South Korean","South Sudanese","Spanish","Sri Lankan","Sudanese","Surinamese","Swazi","Swedish","Swiss","Syrian","Taiwanese","Tajik","Tanzanian","Thai","Togolese","Trinidadian","Tunisian","Turkish","Turkmen","Ugandan","Ukrainian","Uruguayan","Uzbek","Venezuelan","Vietnamese","Yemeni","Zambian","Zimbabwean","Other"];

/* ============ TEAM PLAN (from the internal 8-page plan) ============ */
/* Daily standards — identical every day. Some entries vary by day (notes). */
const DAILY_STANDARDS=[
  {time:"09:00",k:"std_breakfast"},
  {time:"09:30",k:"std_mmeet",nk:"n_sport"},
  {time:"09:55",k:"std_start",nk:"n_mact"},
  {time:"12:30",k:"std_lunch"},
  {time:"12:30",k:"std_fmorning",nk:"n_practice",morning:true},
  {time:"14:45",k:"std_ameet"},
  {time:"14:55",k:"std_start",nk:"n_aact"},
  {time:"17:00",k:"std_fafternoon",nk:"n_yogahost"},
  {time:"19:00",k:"std_dinner"},
  {time:"19:00",k:"std_stage"},
  {time:"19:45",k:"std_emeet"},
  {time:"19:55",k:"std_start",nk:"n_eshow"},
  {time:"22:45",k:"std_yoga"},
  {time:"23:00",k:"std_fevening",nk:"n_special"}
];
/* Per-day: theme, dress code, entrance-duty number, day-off numbers, make-up practice, practice flag */
const DAY_PLAN=[
  {day:0,name:"Monday",theme:"Seafood",dress:"Tropical",entrance:7,off:[4],practice:true,
    makeup:null, eveningShow:"Beach Party / Pool Party", showTime:"20:00 – 23:00", showLoc:"Beach · Pool", liveBand:""},
  {day:1,name:"Tuesday",theme:"Oriental",dress:"Oriental Costume",entrance:8,off:[1,2],practice:false,
    makeup:{num:4,offDay:0}, eveningShow:"Oriental / Folklore", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:"20:15–21:00 · 21:30–22:15"},
  {day:2,name:"Wednesday",theme:"For East",dress:"Classic White (Shirt & Trouser)",entrance:9,off:[5],practice:true,
    makeup:null, eveningShow:"Entertainment Team Mic", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:"Sunset Instrument Party 17:00–19:00"},
  {day:3,name:"Thursday",theme:"France",dress:"Classic White & Black (Shirt & Trouser)",entrance:10,off:[3,6],practice:false,
    makeup:{num:5,offDay:2}, eveningShow:"International / Colombian", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:"20:15–21:00 · 21:30–22:15"},
  {day:4,name:"Friday",theme:"Italy",dress:"Classic All Black (Shirt & Trouser)",entrance:6,off:[7],practice:true,
    makeup:null, eveningShow:"Dance Technology", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:""},
  {day:5,name:"Saturday",theme:"International",dress:"Classic Brown & White (Shirt & Trouser)",entrance:4,off:[8],practice:false,
    makeup:{num:7,offDay:4}, eveningShow:"Acrobat", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:"20:15–21:00 · 21:30–22:15"},
  {day:6,name:"Sunday",theme:"German",dress:"Classic Brown & Black (Shirt & Trouser)",entrance:5,off:[9,10],practice:false,
    makeup:null, eveningShow:"International / Brazilian", showTime:"21:00 – 21:30", showLoc:"Stage", liveBand:"20:15–21:00 · 21:30–22:15"}
];
const TEAM_ROLES={1:"Manager",2:"Entertainer · Social Media",3:"DJ"};
function roleForNumber(n){ return TEAM_ROLES[n]||"Entertainer"; }
/* Counts the whole team once — used by the team page and the management export */
function teamStats(){
  const team=(S.users||[]).filter(u=>u.role==="staff"||u.role==="manager");
  const entertainers=team.filter(u=>u.role==="staff");
  const byGender={male:0,female:0,none:0};
  const byNat={};
  team.forEach(u=>{
    const g=u.gender==="male"?"male":u.gender==="female"?"female":"none";
    byGender[g]++;
    const n=(u.nationality||"").trim();
    if(n) byNat[n]=(byNat[n]||0)+1;
  });
  const natList=Object.keys(byNat).sort((a,b)=>byNat[b]-byNat[a]||a.localeCompare(b))
    .map(n=>({name:n,count:byNat[n]}));
  return {total:team.length, entertainers:entertainers.length, byGender, natList,
          noNat:team.filter(u=>!(u.nationality||"").trim()).length};
}
function genderLabel(g){ return g==="male"?t("genderM"):g==="female"?t("genderF"):t("genderNone"); }
function genderOptions(cur){
  return `<option value="" ${!cur?"selected":""}>${t("genderNone")}</option>
    <option value="male" ${cur==="male"?"selected":""}>${t("genderM")}</option>
    <option value="female" ${cur==="female"?"selected":""}>${t("genderF")}</option>`;
}
function nationOptions(cur){
  // a saved value that is not in the list means it was typed by hand -> keep it selected
  const custom = cur && !NATIONS.includes(cur);
  return `<option value="" ${!cur?"selected":""}>—</option>` +
    NATIONS.map(n=>`<option value="${esc(n)}" ${(!custom&&cur===n)||(custom&&n==="Other")?"selected":""}>${esc(n)}</option>`).join("");
}
/* Renders a nationality dropdown plus a hidden "type it yourself" box that
   appears when Other is chosen. Returns the markup; wire it with wireNatPicker. */
function nationField(idSel, idText, cur){
  const custom = cur && !NATIONS.includes(cur);
  return `<select id="${idSel}">${nationOptions(cur)}</select>
    <input id="${idText}" placeholder="${esc(t("typeNationality"))}" value="${custom?esc(cur):""}"
      style="margin-top:8px;${custom?"":"display:none"}">`;
}
function wireNatPicker(wrap, idSel, idText){
  const sel=wrap.querySelector("#"+idSel), txt=wrap.querySelector("#"+idText);
  if(!sel||!txt) return;
  const sync=()=>{
    const other = sel.value==="Other";
    txt.style.display = other ? "" : "none";
    if(!other) txt.value="";
  };
  sel.onchange=sync;
}
/* The value to save: the typed text when Other is chosen, otherwise the picked one */
function readNatField(wrap, idSel, idText){
  const sel=wrap.querySelector("#"+idSel), txt=wrap.querySelector("#"+idText);
  if(!sel) return "";
  if(sel.value==="Other"){ const v=(txt&&txt.value||"").trim(); return v||"Other"; }
  return sel.value;
}
/* Name for a shirt number, from the real team accounts. Manager = #1. */
function nameForNumber(n){
  let u=(S.users||[]).find(x=>x.number===n);
  if(!u && n===1) u=(S.users||[]).find(x=>x.role==="manager");
  const nm=u?(u.display_name||u.username):"";
  return nm||"";
}
/* "Mr Solo #3" when we know the name, otherwise just "#3" */
function personTag(n){
  const nm=nameForNumber(n);
  return nm ? (esc(nm)+" #"+n) : ("#"+n);
}
function personTags(list){ return (list||[]).map(personTag).join(" · "); }
function dayPlanFor(day){
  const base=DAY_PLAN.find(d=>d.day===day)||DAY_PLAN[0];
  const ov=(S.settings&&S.settings.dayOverrides)?S.settings.dayOverrides[String(day)]:null;
  if(!ov) return base;
  return {...base,
    off: Array.isArray(ov.off) ? ov.off.slice() : base.off,
    entrance: (typeof ov.entrance==="number") ? ov.entrance : base.entrance,
    custom: true};
}
function dayIsCustom(day){
  const ov=(S.settings&&S.settings.dayOverrides)?S.settings.dayOverrides[String(day)]:null;
  return !!ov;
}
/* Who is working and who is off on a given day, using the real team accounts */
function dayDutyDate(day){
  const now=hotelNow(), today=(now.getDay()+6)%7;
  const d=new Date(now); d.setHours(12,0,0,0); d.setDate(d.getDate()-today+day);
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}
function dayDutyStats(day){
  const dp=dayPlanFor(day), ds=dayDutyDate(day), mk=ds.slice(0,7), dd=+ds.slice(8,10);
  const team=(S.users||[]).filter(u=>(u.role==="staff"||u.role==="manager") && u.active!==false && !hasLeft(u));
  const off=[], absent=[], vacation=[], working=[];
  team.forEach(u=>{
    let num=u.number; if(!num && u.role==="manager") num=1;
    const st=attStatus(u,mk,dd);
    if(st==="V") vacation.push(u);
    else if(st==="A") absent.push(u);
    else if(st==="N"){} // not employed on that exact date
    else if(st==="O" || (num && dp.off.includes(num))) off.push(u);
    else working.push(u);
  });
  const employed=working.length+off.length+absent.length+vacation.length;
  return {date:ds,total:employed,off,absent,vacation,working,offCount:off.length,
          absentCount:absent.length,vacationCount:vacation.length,workingCount:working.length,entrance:dp.entrance};
}
/* Build a translated make-up-practice sentence: "#4 · off Monday — trains individually today" */
function makeupText(mk){
  if(!mk) return "";
  const dayName=(t("days")[mk.offDay]||"");
  return "#"+mk.num+" · "+t("dayOff")+" "+dayName+" — "+t("trainsToday");
}
/* What is this person's status today, by shirt number? */
function personDayInfo(num,day){
  const dp=dayPlanFor(day);
  const u=(S.users||[]).find(x=>+x.number===+num) || (num===1?(S.users||[]).find(x=>x.role==="manager"):null);
  const ds=typeof dayDutyDate==="function"?dayDutyDate(day):assignDateStr(day);
  const mk=String(ds||"").slice(0,7), dd=+String(ds||"").slice(8,10);
  const att=(u&&mk&&dd)?attStatus(u,mk,dd):"";
  const isVacation=att==="V", isAbsent=att==="A";
  const isOff=!isVacation&&!isAbsent&&(att==="O"||dp.off.includes(num));
  const isEntrance=!isVacation&&!isAbsent&&!isOff&&dp.entrance===num;
  const isDJ=num===3;
  const isSocial=num===2;
  // DJ special schedule
  let djNote="";
  if(isDJ){
    if(isOff) djNote=t("dj_thu");                    // off -> live band covers the music
    else if(day===2) djNote=t("dj_wed");
    else djNote=t("dj_other");
  }
  return {dp,u,date:ds,att,isOff,isVacation,isAbsent,isEntrance,isDJ,isSocial,djNote,
    entranceWindow:isEntrance?"Leaves 16:00 · returns 18:30":"",
    makeupForMe:(dp.makeup&&dp.makeup.num===num)?dp.makeup:null};
}

/* ===== ACCESS CONTROL =====
   A guest keeps access only until the day after departure. The next guest in
   that room must not inherit the previous guest's session. */
/* A gentle brake on password guessing (per device) */
/* A readable password the manager can hand over verbally */
function makePassword(){
  const a="abcdefghjkmnpqrstuvwxyz", n="23456789";
  let out="";
  for(let i=0;i<4;i++) out+=a[Math.floor(Math.random()*a.length)];
  for(let i=0;i<3;i++) out+=n[Math.floor(Math.random()*n.length)];
  return out;
}
function showNewPassword(pw){
  const wrap=baseModal(`
    <h3>${ic("check",20)} ${t("newPassIs")}</h3>
    <div class="newpass">${esc(pw)}</div>
    <p class="mini">${t("passCopied")}</p>
    <button class="btn" id="np-x">${t("close")}</button>`);
  wrap.querySelector("#np-x").onclick=()=>wrap.remove();
}
function tooManyAttempts(){
  try{
    const raw=JSON.parse(localStorage.getItem("ent_tries")||"{}");
    if(!raw.until) return false;
    if(Date.now()>raw.until){ localStorage.removeItem("ent_tries"); return false; }
    return (raw.n||0)>=5;
  }catch(e){ return false; }
}
function noteFailedAttempt(){
  try{
    const raw=JSON.parse(localStorage.getItem("ent_tries")||"{}");
    const n=(raw.n||0)+1;
    localStorage.setItem("ent_tries", JSON.stringify({n, until:Date.now()+60000}));
  }catch(e){}
}
function clearAttempts(){ try{ localStorage.removeItem("ent_tries"); }catch(e){} }
function stayExpired(acc){
  if(!acc || !acc.departure) return false;
  const dep=String(acc.departure).slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(dep)) return false;
  return hotelDateStr() > dep;              // the day AFTER departure
}
function accountActive(u){ return !u || u.active!==false; }
/* Called on every load and every poll: drops a session that should no longer exist. */
function enforceAccess(){
  if(!S.session) return false;
  if(S.session.role==="guest"){
    const acc=(S.accounts||[]).find(a=>a.id===S.session.accountId)
      || (S.accounts||[]).find(a=>String(a.room)===String(S.session.room));
    if(acc && (stayExpired(acc) || acc.active===false)){
      S.session=null; persist();
      toastWarn(t(acc.active===false?"accountOff":"stayEnded"));
      return true;
    }
  } else if(S.session.role==="staff" || S.session.role==="manager"){
    const su=String(S.session.username||"").trim().toLowerCase();
    const u=(S.users||[]).find(x=>String(x.username||"").trim().toLowerCase()===su);
    // Recovery manager sessions are intentionally allowed even if the remote manager row is temporarily missing.
    if(u && u.active===false){
      S.session=null; persist();
      toastWarn(t("accountOff"));
      return true;
    }
  }
  return false;
}
function persist(){
  try{ localStorage.setItem(LS_KEY, JSON.stringify({
    lang:S.lang, theme:S.theme, favorites:S.favorites, seenNote:S.seenNote,
    remember:S.remember!==false, session:(S.remember===false?null:S.session)
  })); }catch(e){}
}
function restore(){
  try{
    const savedLang=localStorage.getItem("entapp_lang");
    if(savedLang) S.lang=savedLang;
    const d=JSON.parse(localStorage.getItem(LS_KEY)||"null");
    if(!d) return;
    if(d.lang) S.lang=d.lang;
    if(d.theme) S.theme=d.theme;
    if(Array.isArray(d.favorites)) S.favorites=d.favorites;
    if(typeof d.remember!=="undefined") S.remember=d.remember!==false;
    if(d.session) S.session=d.session;
    if(d.seenNote) S.seenNote=d.seenNote;
  }catch(e){}
}

/* ---------------- sample data (preview only) ---------------- */
const IMG = {
  aqua:"https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?w=800&q=60",
  yoga:"https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&q=60",
  volley:"https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=800&q=60",
  kids:"https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=800&q=60",
  darts:"https://images.unsplash.com/photo-1642056446459-59a5e696d97c?w=800&q=60",
  show:"https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=60",
  foam:"https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&q=60",
  dance:"https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&q=60",
  boccia:"https://images.unsplash.com/photo-1595429035839-c99c298ffdde?w=800&q=60",
  neon:"https://images.unsplash.com/photo-1563089145-599997674d42?w=800&q=60"
};
function demoActivities(){
  const A=[]; let id=1;
  for(let d=0;d<7;d++){
    A.push({id:id++,day:d,category:"morning",name:"Aqua Gym",desc:"Wake up the body in the pool — music, energy and good vibes.",location:"Main Pool",time:"10:00",capacity:20,entertainer:"Team",image:IMG.aqua,highlight:false});
    A.push({id:id++,day:d,category:"morning",name:"Morning Yoga",desc:"Gentle stretching with sea view. All levels welcome.",location:"Beach Deck",time:"09:00",capacity:15,entertainer:"Team",image:IMG.yoga,highlight:false});
    A.push({id:id++,day:d,category:"kids",name:"Kids Club",desc:"Games, crafts and mini disco for our little guests (4–12).",location:"Kids Club",time:"10:30",capacity:25,entertainer:"Kids Team",image:IMG.kids,highlight:false});
    A.push({id:id++,day:d,category:"afternoon",name:"Beach Volleyball",desc:"Friendly tournament on the beach court. Join a team!",location:"Beach Court",time:"15:00",capacity:16,entertainer:"Team",image:IMG.volley,highlight:false});
    A.push({id:id++,day:d,category:"evening",name:d%2?"Live Show Night":"Dance Show",desc:"An evening full of lights, music and surprises on the big stage.",location:"Amphitheatre",time:"21:00",capacity:150,entertainer:"Show Team",image:d%2?IMG.show:IMG.dance,highlight:d===0});
  }
  A.push({id:id++,day:2,category:"theme",name:"Foam Party",desc:"The legendary foam party at the main pool — don't miss it!",location:"Main Pool",time:"14:30",capacity:80,entertainer:"All Team",image:IMG.foam,highlight:true});
  A.push({id:id++,day:5,category:"theme",name:"Neon Party",desc:"Glow sticks, UV lights and the best beats of the week.",location:"Amphitheatre",time:"21:30",capacity:120,entertainer:"All Team",image:IMG.neon,highlight:true});
  A.push({id:id++,day:3,category:"afternoon",name:"Boccia on the Beach",desc:"Relaxed boccia tournament by the sea.",location:"Beach",time:"17:00",capacity:12,entertainer:"Team",image:IMG.boccia,highlight:false});
  return A;
}
function demoTickets(){
  return [
    {id:1,day:6,name:"Tombola",desc:"Our big Sunday raffle with amazing prizes — every ticket can win!",location:"Amphitheatre",time:"20:00",price:"5 €",capacity:0,image:IMG.show},
    {id:2,day:2,name:"Bingo Night",desc:"Classic bingo with the team, prizes and lots of laughs.",location:"Pool Bar",time:"18:00",price:"3 €",capacity:60,image:IMG.darts},
    {id:3,day:4,name:"Disco Night",desc:"Dance until late — DJ, lights and the best party of the week.",location:"Disco",time:"22:30",price:"8 €",capacity:0,image:IMG.neon}
  ];
}
function demoBookings(){
  return [
    {id:1,activity_id:1,room:"4215",guest_name:"Familie Weber",phone:"",nationality:"German",adults:2,children:0,status:"booked"},
    {id:2,activity_id:1,room:"4308",guest_name:"Smith",phone:"",nationality:"British",adults:1,children:1,status:"booked"},
    {id:3,activity_id:3,room:"4510",guest_name:"Ivanova",phone:"",nationality:"Russian",adults:1,children:2,status:"booked"}
  ];
}
function demoOrders(){
  return [{id:1,ticket_id:1,room:"4215",guest_name:"Familie Weber",nationality:"German",qty:2,status:"reserved"}];
}
const DEMO_USERS=[];
function demoRooms(){ return ["4215","4308","4510","4102","4103"].map((r,i)=>({id:i+1,room:r,active:true})); }
function demoAccounts(){
  const today=new Date(), plus=d=>{const x=new Date(today);x.setDate(x.getDate()+d);return x.toISOString().slice(0,10);};
  return [{id:1,room:"4215",name:"Familie Weber",phone:"",nationality:"German",arrival:plus(-4),departure:plus(3)}];
}
function demoMessages(){
  const now=Date.now();
  return [
    {id:1,room:"4215",sender:"guest",sender_name:"Familie Weber",text:"Hello! Is the foam party for kids too?",created_at:new Date(now-3600e3).toISOString(),read_by_team:true,read_by_guest:true},
    {id:2,room:"4215",sender:"team",sender_name:"Entertainment Manager",text:"Hello! Yes, absolutely — kids love it. See you there!",created_at:new Date(now-3000e3).toISOString(),read_by_team:true,read_by_guest:false}
  ];
}
function demoRequests(){
  return [{id:1,room:"4215",guest_name:"Familie Weber",type:"song",detail:"Bailando – Enrique Iglesias",date:"",note:"For the pool party please!",status:"new",created_at:new Date().toISOString()}];
}
function demoTasks(){
  return [{id:1,type:"collect",title:"Collect guests for Boccia",desc:"",location:"Beach Area",assigned_to:"team",due:"",status:"open",was_still:false,created_at:new Date().toISOString()}];
}
function demoProfiles(){
  return [{id:1,name:"Jacky",position:"Entertainment Manager",photo:"",nationality:"German",languages:"DE · EN · AR",skills:"Shows · Dance · Kids",instagram:"",created_at:new Date().toISOString()}];
}
function demoFeedback(){
  return [{id:1,room:"4215",nationality:"German",rate:5,comment:"Amazing foam party!",by_user:"team",created_at:new Date().toISOString()}];
}
function demoNotes(){
  return [{id:1,title:"Foam Party today!",body:"14:30 at the Main Pool — bring your swimsuit and good mood!",audience:"all",created_at:new Date().toISOString()}];
}

/* ---------------- data layer ---------------- */
async function sb(path, opts={}){
  const res = await fetch(CONFIG.SUPABASE_URL + "/rest/v1/" + path, {
    ...opts,
    headers:{
      "apikey":CONFIG.SUPABASE_ANON_KEY,
      "Authorization":"Bearer "+CONFIG.SUPABASE_ANON_KEY,
      "Content-Type":"application/json",
      "Prefer": opts.method==="POST"||opts.method==="PATCH" ? "return=representation" : "",
      ...(opts.headers||{})
    }
  });
  if(!res.ok) throw new Error("Supabase "+res.status+" on "+path);
  const txt = await res.text();
  return __sbParse(txt);
}
/* Supabase normally returns the created row. If it ever returns nothing
   (blocked header, odd proxy, empty body), fall back to the row we sent so
   we never push `undefined` into the app data. */
function __row(res, sent){
  if(res && res[0] && typeof res[0]==="object") return res[0];
  return {...sent, id:(sent && sent.id) || Date.now()+Math.random()};
}
function __sbParse(txt){
  return txt ? JSON.parse(txt) : null;
}
/* Upload an image file to Supabase Storage bucket "avatars"; returns the public URL. */
async function uploadAvatar(file){
  if(!REMOTE) throw new Error("offline");
  const ext=(file.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"")||"jpg";
  const path="avatars/"+Date.now()+"-"+Math.random().toString(36).slice(2,8)+"."+ext;
  const res=await fetch(CONFIG.SUPABASE_URL+"/storage/v1/object/"+path,{
    method:"POST",
    headers:{ "apikey":CONFIG.SUPABASE_ANON_KEY, "Authorization":"Bearer "+CONFIG.SUPABASE_ANON_KEY,
      "Content-Type":file.type||"image/jpeg", "x-upsert":"true" },
    body:file
  });
  if(!res.ok){ throw new Error("upload "+res.status); }
  return CONFIG.SUPABASE_URL+"/storage/v1/object/public/"+path;
}
/* Wire a photo picker: an avatar preview + hidden file input + upload-on-change. */
/* ================= PHOTO VIEWER (lightbox) =================
   Tap any picture anywhere to open it big, swipe or arrow between them. */
/* Any picture, anywhere: tapping it opens the big view and NEVER triggers the
   card or row underneath. Runs in the capture phase so it fires before anything else. */
function initPhotoTaps(){
  if(window.__photoTaps) return;
  window.__photoTaps=true;
  document.addEventListener("click", ev=>{
    const target=ev.target;
    if(!target || !target.closest) return;
    // never inside the viewer itself, an upload box, the crop tool or an editor thumbnail
    if(target.closest(".pv-bg,.photo-pick,.photo-box,.pedit,.crop-stage,.brandmark")) return;
    const holder=target.closest("[data-pv],[data-pvsingle]");
    let urls=[], start=0;
    if(holder && holder.hasAttribute("data-pvsingle")){
      urls=[holder.getAttribute("data-pvsingle")];
    } else if(holder && holder.hasAttribute("data-pv")){
      const parts=String(holder.getAttribute("data-pv")).split("|");
      start=+parts[1]||0;
      let strip=null;
      try{ strip=document.querySelector('[data-strip="'+String(parts[0]).replace(/["\\]/g,"")+'"]'); }catch(e){}
      if(strip) urls=[...strip.querySelectorAll("img")].map(i=>i.getAttribute("src"));
      else { const im=holder.tagName==="IMG"?holder:holder.querySelector("img"); if(im) urls=[im.getAttribute("src")]; }
    } else {
      // a plain photo with no marker (gallery grid, avatars, proof shots…)
      if(target.tagName!=="IMG") return;
      const src=target.getAttribute("src");
      if(!src || /^data:/.test(src)) return;
      urls=[src];
    }
    urls=(urls||[]).filter(Boolean);
    if(!urls.length) return;
    ev.preventDefault();
    ev.stopPropagation();
    if(ev.stopImmediatePropagation) ev.stopImmediatePropagation();
    openPhotoViewer(urls, start);
  }, true);
}
function openPhotoViewer(urls, start){
  const list=(Array.isArray(urls)?urls:[urls]).filter(Boolean);
  if(!list.length) return;
  let i=Math.max(0, Math.min(list.length-1, start||0));
  const wrap=document.createElement("div");
  wrap.className="pv-bg";
  const draw=()=>{
    wrap.innerHTML=`
      <button class="pv-x" aria-label="${t("close")}">${ic("close",20)}</button>
      ${list.length>1?`<button class="pv-nav prev" aria-label="prev">${ic("back",22)}</button>`:""}
      <img class="pv-img" src="${esc(list[i])}" alt="">
      ${list.length>1?`<button class="pv-nav next" aria-label="next">${ic("back",22)}</button>`:""}
      ${list.length>1?`<span class="pv-count">${i+1} ${t("photoOf")} ${list.length}</span>`:""}`;
    const x=wrap.querySelector(".pv-x"); if(x) x.onclick=close;
    const pv=wrap.querySelector(".prev"); if(pv) pv.onclick=e=>{ e.stopPropagation(); i=(i-1+list.length)%list.length; draw(); };
    const nx=wrap.querySelector(".next"); if(nx) nx.onclick=e=>{ e.stopPropagation(); i=(i+1)%list.length; draw(); };
  };
  function onKey(e){
    if(e.key==="Escape") close();
    if(e.key==="ArrowLeft"){ i=(i-1+list.length)%list.length; draw(); }
    if(e.key==="ArrowRight"){ i=(i+1)%list.length; draw(); }
  }
  function close(){ wrap.remove(); document.removeEventListener("keydown",onKey); }
  wrap.onclick=e=>{ if(e.target===wrap) close(); };
  // swipe on touch
  let sx=0;
  wrap.addEventListener("touchstart",e=>{ sx=e.touches[0].clientX; },{passive:true});
  wrap.addEventListener("touchend",e=>{
    const dx=e.changedTouches[0].clientX-sx;
    if(Math.abs(dx)>50 && list.length>1){ i=(dx>0?(i-1+list.length):(i+1))%list.length; draw(); }
  },{passive:true});
  document.addEventListener("keydown",onKey);
  draw();
  document.body.appendChild(wrap);
}
/* A horizontal strip of photos that opens the viewer on tap */
function photoStrip(urls, key){
  const list=(urls||[]).filter(Boolean);
  if(!list.length) return "";
  return `<div class="pstrip" data-strip="${esc(key||"")}">
    ${list.map((u,ix)=>`<img src="${esc(u)}" alt="" loading="lazy" data-pv="${esc(key||"")}|${ix}">`).join("")}
  </div>`;
}
/* Editable list of photos (add / remove) used in the editors */
function photoListEditor(idBase, urls){
  return `<label>${t("photosLbl")}</label>
    <div class="pedit" id="${idBase}-list">
      ${(urls||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
        <button class="pedit-rm" type="button" data-prm="${ix}" aria-label="${t("removePhoto")}">${ic("close",13)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" id="${idBase}-add" type="button">${ic("plus",14)} ${t("addPhotos")}</button>
    <input type="file" accept="image/*" multiple id="${idBase}-file" hidden>`;
}
/* Wires the editor: uploads new files, removes existing ones. */
function wirePhotoList(wrap, idBase, getList, setList){
  const box=wrap.querySelector("#"+idBase+"-list");
  const btn=wrap.querySelector("#"+idBase+"-add");
  const file=wrap.querySelector("#"+idBase+"-file");
  const redraw=()=>{
    if(!box) return;
    box.innerHTML=(getList()||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
      <button class="pedit-rm" type="button" data-prm="${ix}">${ic("close",13)}</button></div>`).join("");
    box.querySelectorAll("[data-prm]").forEach(b=>b.onclick=()=>{
      const l=(getList()||[]).slice(); l.splice(+b.dataset.prm,1); setList(l); redraw();
    });
  };
  redraw();
  if(btn && file) btn.onclick=()=>file.click();
  if(file) file.onchange=async ()=>{
    const files=[...(file.files||[])];
    if(!files.length) return;
    if(btn) btn.disabled=true;
    for(const f of files){
      try{ const url=await uploadAvatar(f); setList((getList()||[]).concat([url])); redraw(); }
      catch(e){ toastErr(t("uploadErr")); }
    }
    if(btn) btn.disabled=false;
    file.value="";
  };
}
/* ================= CIRCLE CROP (logo) ================= */
function openCropModal(file, onDone){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("cropLogo")}</h3>
    <p class="mini">${t("cropHint")}</p>
    <div class="crop-stage" id="cr-stage">
      <canvas id="cr-canvas" width="280" height="280"></canvas>
      <div class="crop-ring"></div>
    </div>
    <label>${t("zoomLbl")}</label>
    <input id="cr-zoom" type="range" min="100" max="300" value="100">
    <button class="btn" id="cr-ok">${t("useCrop")}</button>
    <button class="btn ghost" id="cr-x">${t("close")}</button>`);
  const canvas=wrap.querySelector("#cr-canvas");
  const ctx=canvas.getContext&&canvas.getContext("2d");
  const img=new Image();
  let zoom=1, ox=0, oy=0, drag=false, lx=0, ly=0;
  const paint=()=>{
    if(!ctx||!img.width) return;
    const S2=canvas.width;
    ctx.clearRect(0,0,S2,S2);
    ctx.fillStyle="#00000010"; ctx.fillRect(0,0,S2,S2);
    const base=Math.max(S2/img.width, S2/img.height);
    const sc=base*zoom;
    const w=img.width*sc, h=img.height*sc;
    ctx.drawImage(img, (S2-w)/2+ox, (S2-h)/2+oy, w, h);
  };
  img.onload=paint;
  try{ img.src=URL.createObjectURL(file); }catch(e){}
  const stage=wrap.querySelector("#cr-stage");
  const start=(x,y)=>{ drag=true; lx=x; ly=y; };
  const move=(x,y)=>{ if(!drag) return; ox+=x-lx; oy+=y-ly; lx=x; ly=y; paint(); };
  const stop=()=>{ drag=false; };
  if(stage){
    stage.addEventListener("mousedown",e=>start(e.clientX,e.clientY));
    stage.addEventListener("mousemove",e=>move(e.clientX,e.clientY));
    stage.addEventListener("mouseup",stop); stage.addEventListener("mouseleave",stop);
    stage.addEventListener("touchstart",e=>start(e.touches[0].clientX,e.touches[0].clientY),{passive:true});
    stage.addEventListener("touchmove",e=>move(e.touches[0].clientX,e.touches[0].clientY),{passive:true});
    stage.addEventListener("touchend",stop,{passive:true});
  }
  const zi=wrap.querySelector("#cr-zoom");
  if(zi) zi.oninput=()=>{ zoom=(+zi.value)/100; paint(); };
  wrap.querySelector("#cr-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cr-ok").onclick=()=>{
    if(!ctx){ wrap.remove(); return; }
    // cut a circle out of the canvas
    const out=document.createElement("canvas");
    out.width=out.height=canvas.width;
    const octx=out.getContext("2d");
    octx.beginPath();
    octx.arc(canvas.width/2, canvas.width/2, canvas.width/2, 0, Math.PI*2);
    octx.closePath(); octx.clip();
    octx.drawImage(canvas,0,0);
    out.toBlob(async b=>{
      if(!b){ wrap.remove(); return; }
      try{
        const f2=new File([b], "logo.png", {type:"image/png"});
        const url=await uploadAvatar(f2);
        wrap.remove(); onDone(url);
      }catch(e){ toastErr(t("uploadErr")); wrap.remove(); }
    }, "image/png");
  };
}
/* Opens the phone's picker, uploads, then hands back the link. */
function pickOneImage(done, multi){
  const inp=document.createElement("input");
  inp.type="file"; inp.accept="image/*"; if(multi) inp.multiple=true;
  inp.onchange=async ()=>{
    const files=[...(inp.files||[])];
    for(const f of files){
      try{ const url=await uploadAvatar(f); done(url); }
      catch(e){ toastErr(t("uploadErr")); }
    }
  };
  inp.click();
}
function wirePhotoPicker(wrap, getUrl, setUrl){
  const box=wrap.querySelector("[data-photobox]"); if(!box) return;
  const input=wrap.querySelector("[data-photoinput]");
  const render=()=>{ const u=getUrl();
    box.innerHTML = u ? `<img src="${esc(u)}" alt="">` : `<span>${ic("user",26)}</span>`; };
  render();
  box.onclick=()=>input&&input.click();
  if(input) input.onchange=async ()=>{
    const f=input.files&&input.files[0]; if(!f) return;
    box.classList.add("uploading");
    try{ const url=await uploadAvatar(f); setUrl(url); render(); toast(t("saved")); }
    catch(e){ toastErr(t("uploadErr")); }
    box.classList.remove("uploading");
  };
}
const SETTINGS_BACKUP_KEY_V626="entapp_settings_v626";
function readSettingsBackupV626(){
  try{
    const x=JSON.parse(localStorage.getItem(SETTINGS_BACKUP_KEY_V626)||"null");
    return x&&typeof x==="object"?x:null;
  }catch(e){ return null; }
}
function writeSettingsBackupV626(st){
  try{ localStorage.setItem(SETTINGS_BACKUP_KEY_V626,JSON.stringify(st||{})); }catch(e){}
}
function settingsRevisionV626(st){ return +(st&&st._settingsUpdatedAtV626||0)||0; }
function reconcileSettingsV626(remoteSettings){
  const remote={...DEFAULT_SETTINGS,...(remoteSettings||{})};
  const local=readSettingsBackupV626();
  if(local && settingsRevisionV626(local)>settingsRevisionV626(remote)){
    const merged={...DEFAULT_SETTINGS,...local};
    writeSettingsBackupV626(merged);
    return {settings:merged,localNewer:true};
  }
  writeSettingsBackupV626(remote);
  return {settings:remote,localNewer:false};
}
async function cloudUpsertSettingsV626(st){
  if(!REMOTE)return null;
  /* First try the normal PATCH. If the settings row does not exist, use a safe upsert. */
  try{
    const r=await sb("app_settings?id=eq.1",{method:"PATCH",body:JSON.stringify({data:st})});
    if(r&&r.length)return r;
  }catch(e){}
  return await sb("app_settings?on_conflict=id",{
    method:"POST",
    headers:{"Prefer":"resolution=merge-duplicates,return=representation"},
    body:JSON.stringify({id:1,data:st})
  });
}

const DB = {
  async load(){
    if(REMOTE){
      const [a,b,u,s,tk,o,rm,ac,ms,rq,ts,nt,at,fb,tp,bs,qz,qr,sa,ph,sr] = await Promise.all([
        sb("activities?select=*&order=time"), sb("bookings?select=*"),
        sb("app_users?select=*"), sb("app_settings?select=*&id=eq.1"),
        sb("tickets?select=*&order=time"), sb("ticket_orders?select=*"),
        sb("rooms?select=*&order=room"), sb("guest_accounts?select=*"),
        sb("messages?select=*&order=created_at"), sb("requests?select=*&order=created_at.desc"),
        sb("tasks?select=*&order=created_at.desc"), sb("announcements?select=*&order=created_at.desc"),
        sb("attendance?select=*"), sb("feedback?select=*&order=created_at.desc"),
        sb("team_profiles?select=*&order=id"), sb("buses?select=*&order=sort"),
        sb("quizzes?select=*&order=quiz_date.desc"), sb("quiz_replies?select=*&order=created_at.desc"),
        sb("staff_attendance?select=*"),
        sb("photos?select=*&order=created_at.desc"), sb("staff_requests?select=*&order=created_at.desc"),
      ]);
      S.activities=a||[]; S.bookings=b||[]; S.users=u||[]; S.tickets=tk||[]; S.orders=o||[];
      S.rooms=rm||[]; S.accounts=ac||[]; S.messages=ms||[]; S.requests=rq||[];
      S.tasks=ts||[]; S.notes=nt||[]; S.attendance=at||[]; S.feedback=fb||[]; S.profiles=tp||[]; S.buses=bs||[];
      S.quizzes=qz||[]; S.quizReplies=qr||[]; S.staffAtt=sa||[]; S.photos=ph||[]; S.staffReqs=sr||[];
      {
        const rr=reconcileSettingsV626((s&&s[0]&&s[0].data)?s[0].data:DEFAULT_SETTINGS);
        S.settings=rr.settings;
        if(rr.localNewer){
          try{ await cloudUpsertSettingsV626(S.settings); }catch(e){ console.warn("settings cloud reconcile pending",e); }
        }
      }
    } else {
      S.activities=demoActivities(); S.bookings=demoBookings();
      S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
      S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
      S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
      S.quizzes=[]; S.quizReplies=[]; S.staffAtt=[]; S.photos=[]; S.staffReqs=[];
      S.buses=[{id:1,direction:"toHotel",time:"08:00",note:"",sort:0},{id:2,direction:"toHotel",time:"15:00",note:"",sort:1},{id:3,direction:"toHouse",time:"00:30",note:"",sort:2},{id:4,direction:"toHouse",time:"13:15",note:"",sort:3}];
      S.settings=reconcileSettingsV626(DEFAULT_SETTINGS).settings;
    }
  },
  async poll(){
    if(!REMOTE) return false;
    const [ms,rq,nt,b,o,ts]=await Promise.all([
      sb("messages?select=*&order=created_at"), sb("requests?select=*&order=created_at.desc"),
      sb("announcements?select=*&order=created_at.desc"), sb("bookings?select=*"),
      sb("ticket_orders?select=*"), sb("tasks?select=*&order=created_at.desc")
    ]);
    const changed = JSON.stringify(ms)!==JSON.stringify(S.messages)
      || JSON.stringify(rq)!==JSON.stringify(S.requests)
      || JSON.stringify(nt)!==JSON.stringify(S.notes)
      || JSON.stringify(b)!==JSON.stringify(S.bookings)
      || JSON.stringify(o)!==JSON.stringify(S.orders)
      || JSON.stringify(ts)!==JSON.stringify(S.tasks);
    S.messages=ms||[]; S.requests=rq||[]; S.notes=nt||[]; S.bookings=b||[]; S.orders=o||[]; S.tasks=ts||[];
    return changed;
  },
  async addBooking(bk){
    if(REMOTE){ const r=await sb("bookings",{method:"POST",body:JSON.stringify(bk)}); S.bookings.push(__row(r,bk)); }
    else { bk.id=Date.now(); S.bookings.push(bk); }
  },
  async removeBooking(id){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"DELETE"});
    S.bookings=S.bookings.filter(b=>b.id!==id);
  },
  async saveActivity(act){
    if(act.id){
      if(REMOTE){ const {id,...rest}=act; await sb("activities?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.activities=S.activities.map(a=>a.id===act.id?act:a);
    } else {
      if(REMOTE){ const r=await sb("activities",{method:"POST",body:JSON.stringify(act)}); S.activities.push(__row(r,act)); }
      else { act.id=Date.now(); S.activities.push(act); }
    }
  },
  async deleteActivity(id){
    if(REMOTE) await sb("activities?id=eq."+id,{method:"DELETE"});
    S.activities=S.activities.filter(a=>a.id!==id);
    S.bookings=S.bookings.filter(b=>b.activity_id!==id);
  },
  async updateBooking(id, patch){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.bookings=S.bookings.map(b=>b.id===id?{...b,...patch}:b);
  },
  async deleteBooking(id){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"DELETE"});
    S.bookings=S.bookings.filter(b=>b.id!==id);
  },
  async addPhoto(ph){
    if(REMOTE){ const r=await sb("photos",{method:"POST",body:JSON.stringify(ph)}); S.photos.unshift(__row(r,ph)); }
    else { ph.id=Date.now(); ph.created_at=new Date().toISOString(); S.photos.unshift(ph); }
  },
  async deletePhoto(id){
    if(REMOTE) await sb("photos?id=eq."+id,{method:"DELETE"});
    S.photos=S.photos.filter(x=>x.id!==id);
  },
  async addStaffReq(rq){
    if(REMOTE){ const r=await sb("staff_requests",{method:"POST",body:JSON.stringify(rq)}); S.staffReqs.unshift(__row(r,rq)); }
    else { rq.id=Date.now(); rq.created_at=new Date().toISOString(); S.staffReqs.unshift(rq); }
  },
  async updateStaffReq(id, patch){
    if(REMOTE) await sb("staff_requests?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.staffReqs=S.staffReqs.map(x=>x.id===id?{...x,...patch}:x);
  },
  async deleteStaffReq(id){
    if(REMOTE) await sb("staff_requests?id=eq."+id,{method:"DELETE"});
    S.staffReqs=S.staffReqs.filter(x=>x.id!==id);
  },
  async setStaffAtt(username, date, status){
    const found=S.staffAtt.find(x=>x.username===username && String(x.date).slice(0,10)===date);
    if(status===null){                       // back to the automatic value
      if(found){
        if(REMOTE) await sb("staff_attendance?id=eq."+found.id,{method:"DELETE"});
        S.staffAtt=S.staffAtt.filter(x=>x.id!==found.id);
      }
      return;
    }
    if(found){
      if(REMOTE) await sb("staff_attendance?id=eq."+found.id,{method:"PATCH",body:JSON.stringify({status})});
      S.staffAtt=S.staffAtt.map(x=>x.id===found.id?{...x,status}:x);
    } else {
      const row={username,date,status};
      if(REMOTE){ const r=await sb("staff_attendance",{method:"POST",body:JSON.stringify(row)}); S.staffAtt.push(__row(r,row)); }
      else { row.id=Date.now()+Math.random(); S.staffAtt.push(row); }
    }
  },
  async saveQuiz(q){
    if(q.id){
      if(REMOTE){ const {id,...rest}=q; await sb("quizzes?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.quizzes=S.quizzes.map(x=>x.id===q.id?{...x,...q}:x);
    } else {
      if(REMOTE){ const r=await sb("quizzes",{method:"POST",body:JSON.stringify(q)}); S.quizzes.unshift(__row(r,q)); }
      else { q.id=Date.now(); q.created_at=new Date().toISOString(); S.quizzes.unshift(q); }
    }
  },
  async deleteQuiz(id){
    if(REMOTE) await sb("quizzes?id=eq."+id,{method:"DELETE"});
    S.quizzes=S.quizzes.filter(q=>q.id!==id);
    S.quizReplies=S.quizReplies.filter(r=>r.quiz_id!==id);
  },
  async addQuizReply(r){
    if(REMOTE){ const res=await sb("quiz_replies",{method:"POST",body:JSON.stringify(r)}); S.quizReplies.unshift(__row(res,r)); }
    else { r.id=Date.now(); r.created_at=new Date().toISOString(); S.quizReplies.unshift(r); }
  },
  async saveBus(bus){
    if(bus.id){
      if(REMOTE){ const {id,...rest}=bus; await sb("buses?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.buses=S.buses.map(b=>b.id===bus.id?bus:b);
    } else {
      if(REMOTE){ const r=await sb("buses",{method:"POST",body:JSON.stringify(bus)}); S.buses.push(__row(r,bus)); }
      else { bus.id=Date.now(); S.buses.push(bus); }
    }
  },
  async deleteBus(id){
    if(REMOTE) await sb("buses?id=eq."+id,{method:"DELETE"});
    S.buses=S.buses.filter(b=>b.id!==id);
  },
  async saveTicket(tk){
    if(tk.id){
      if(REMOTE){ const {id,...rest}=tk; await sb("tickets?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.tickets=S.tickets.map(x=>x.id===tk.id?tk:x);
    } else {
      if(REMOTE){ const r=await sb("tickets",{method:"POST",body:JSON.stringify(tk)}); S.tickets.push(__row(r,tk)); }
      else { tk.id=Date.now(); S.tickets.push(tk); }
    }
  },
  async deleteTicket(id){
    if(REMOTE) await sb("tickets?id=eq."+id,{method:"DELETE"});
    S.tickets=S.tickets.filter(x=>x.id!==id);
    S.orders=S.orders.filter(o=>o.ticket_id!==id);
  },
  async addOrder(o){
    if(REMOTE){ const r=await sb("ticket_orders",{method:"POST",body:JSON.stringify(o)}); S.orders.push(__row(r,o)); }
    else { o.id=Date.now(); S.orders.push(o); }
  },
  async deleteOrder(id){
    if(REMOTE) await sb("ticket_orders?id=eq."+id,{method:"DELETE"});
    S.orders=S.orders.filter(o=>o.id!==id);
  },
  async setOrderStatus(id,status){
    if(REMOTE) await sb("ticket_orders?id=eq."+id,{method:"PATCH",body:JSON.stringify({status})});
    S.orders=S.orders.map(o=>o.id===id?{...o,status}:o);
  },
  async addUser(u){
    if(REMOTE){ const r=await sb("app_users",{method:"POST",body:JSON.stringify(u)}); S.users.push(__row(r,u)); }
    else { u.id=Date.now(); S.users.push(u); }
  },
  async deleteUser(id){
    if(REMOTE) await sb("app_users?id=eq."+id,{method:"DELETE"});
    S.users=S.users.filter(x=>x.id!==id);
  },
  async addRooms(list){
    const fresh=list.filter(r=>!S.rooms.some(x=>x.room===r)).map(r=>({room:r,active:true}));
    if(!fresh.length) return;
    if(REMOTE){ const r=await sb("rooms",{method:"POST",body:JSON.stringify(fresh)}); S.rooms.push(...r); }
    else { fresh.forEach(f=>{f.id=Date.now()+Math.random(); S.rooms.push(f);}); }
    S.rooms.sort((a,b)=>String(a.room).localeCompare(String(b.room),undefined,{numeric:true}));
  },
  async setRoomActive(id,active){
    if(REMOTE) await sb("rooms?id=eq."+id,{method:"PATCH",body:JSON.stringify({active})});
    S.rooms=S.rooms.map(r=>r.id===id?{...r,active}:r);
  },
  async deleteRoom(id){
    const rm=S.rooms.find(r=>r.id===id); if(!rm) return;
    if(REMOTE){
      await sb("rooms?id=eq."+id,{method:"DELETE"});
      await sb("guest_accounts?room=eq."+encodeURIComponent(rm.room),{method:"DELETE"});
    }
    S.rooms=S.rooms.filter(r=>r.id!==id);
    S.accounts=S.accounts.filter(a=>a.room!==rm.room);
  },
  async addAccount(acc){
    if(REMOTE){ const r=await sb("guest_accounts",{method:"POST",body:JSON.stringify(acc)}); const created=__row(r,acc); S.accounts.push(created); return created; }
    acc.id=Date.now(); S.accounts.push(acc); return acc;
  },
  async updateAccount(id,patch){
    if(REMOTE) await sb("guest_accounts?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.accounts=S.accounts.map(a=>a.id===id?{...a,...patch}:a);
  },
  async updateUser(id,patch){
    if(REMOTE) await sb("app_users?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.users=S.users.map(u=>u.id===id?{...u,...patch}:u);
  },
  async addMessage(m){
    if(REMOTE){ const r=await sb("messages",{method:"POST",body:JSON.stringify(m)}); S.messages.push(__row(r,m)); }
    else { m.id=Date.now(); m.created_at=new Date().toISOString(); S.messages.push(m); }
  },
  async updateMessage(id,text){
    if(REMOTE) await sb("messages?id=eq."+id,{method:"PATCH",body:JSON.stringify({text})});
    S.messages=S.messages.map(m=>m.id===id?{...m,text}:m);
  },
  async deleteMessage(id){
    if(REMOTE) await sb("messages?id=eq."+id,{method:"DELETE"});
    S.messages=S.messages.filter(m=>m.id!==id);
  },
  async markRead(room,side){
    const flag = side==="team" ? "read_by_team" : "read_by_guest";
    const sender = side==="team" ? "guest" : "team";
    const unread=S.messages.filter(m=>m.room===room&&m.sender===sender&&!m[flag]);
    if(!unread.length) return;
    if(REMOTE) await sb("messages?room=eq."+encodeURIComponent(room)+"&sender=eq."+sender,{method:"PATCH",body:JSON.stringify({[flag]:true})});
    S.messages=S.messages.map(m=>m.room===room&&m.sender===sender?{...m,[flag]:true}:m);
  },
  async addRequest(r){
    if(REMOTE){ const x=await sb("requests",{method:"POST",body:JSON.stringify(r)}); S.requests.unshift(x[0]); }
    else { r.id=Date.now(); r.created_at=new Date().toISOString(); S.requests.unshift(r); }
  },
  async setRequestStatus(id,status){
    if(REMOTE) await sb("requests?id=eq."+id,{method:"PATCH",body:JSON.stringify({status})});
    S.requests=S.requests.map(r=>r.id===id?{...r,status}:r);
  },
  async deleteRequest(id){
    if(REMOTE) await sb("requests?id=eq."+id,{method:"DELETE"});
    S.requests=S.requests.filter(r=>r.id!==id);
  },
  async addTask(tk){
    if(REMOTE){ const r=await sb("tasks",{method:"POST",body:JSON.stringify(tk)}); S.tasks.unshift(__row(r,tk)); }
    else { tk.id=Date.now(); tk.created_at=new Date().toISOString(); S.tasks.unshift(tk); }
  },
  async updateTask(id,patch){
    if(REMOTE) await sb("tasks?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.tasks=S.tasks.map(x=>x.id===id?{...x,...patch}:x);
  },
  async addFeedback(f){
    if(REMOTE){
      try{
        const r=await sb("feedback",{method:"POST",body:JSON.stringify(f)});
        S.feedback.unshift(__row(r,f));
      }catch(e){
        // older database without the depts / guest_name columns: keep the ratings in the comment
        const base={room:f.room,nationality:f.nationality||"",rate:f.rate,by_user:f.by_user||"",comment:fbPackComment(f)};
        const r=await sb("feedback",{method:"POST",body:JSON.stringify(base)});
        S.feedback.unshift(__row(r,base));
        S.fbOldDb=true;
      }
    }
    else { f.id=Date.now(); f.created_at=new Date().toISOString(); S.feedback.unshift(f); }
  },
  async updateFeedback(id,patch){
    const cur=(S.feedback||[]).find(x=>String(x.id)===String(id))||{};
    if(REMOTE){
      try{ await sb("feedback?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)}); }
      catch(e){
        const merged={...cur,...patch};
        const base={room:merged.room,nationality:merged.nationality||"",rate:merged.rate,comment:fbPackComment(merged)};
        await sb("feedback?id=eq."+id,{method:"PATCH",body:JSON.stringify(base)});
        patch=base; S.fbOldDb=true;
      }
    }
    S.feedback=S.feedback.map(x=>String(x.id)===String(id)?{...x,...patch}:x);
  },
  async deleteFeedback(id){
    if(REMOTE) await sb("feedback?id=eq."+id,{method:"DELETE"});
    S.feedback=S.feedback.filter(x=>String(x.id)!==String(id));
  },
  async saveProfile(pr){
    if(REMOTE){
      if(pr.id){ const {id,...rest}=pr; await sb("team_profiles?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)});
        S.profiles=S.profiles.map(x=>x.id===id?pr:x); }
      else { const r=await sb("team_profiles",{method:"POST",body:JSON.stringify(pr)}); S.profiles.push(__row(r,pr)); }
    } else {
      if(pr.id) S.profiles=S.profiles.map(x=>x.id===pr.id?pr:x);
      else { pr.id=Date.now(); S.profiles.push(pr); }
    }
  },
  async deleteProfile(id){
    if(REMOTE) await sb("team_profiles?id=eq."+id,{method:"DELETE"});
    S.profiles=S.profiles.filter(x=>x.id!==id);
  },
  async deleteTask(id){
    if(REMOTE) await sb("tasks?id=eq."+id,{method:"DELETE"});
    S.tasks=S.tasks.filter(x=>x.id!==id);
  },
  async addNote(n){
    if(REMOTE){ const r=await sb("announcements",{method:"POST",body:JSON.stringify(n)}); S.notes.unshift(__row(r,n)); }
    else { n.id=Date.now(); n.created_at=new Date().toISOString(); S.notes.unshift(n); }
  },
  async deleteNote(id){
    if(REMOTE) await sb("announcements?id=eq."+id,{method:"DELETE"});
    S.notes=S.notes.filter(n=>n.id!==id);
  },
  async setAttendance(bookingId,date,present){
    if(present){
      const row={booking_id:bookingId,date};
      if(REMOTE){ const r=await sb("attendance",{method:"POST",body:JSON.stringify(row)}); S.attendance.push(__row(r,row)); }
      else { row.id=Date.now(); S.attendance.push(row); }
    } else {
      if(REMOTE) await sb("attendance?booking_id=eq."+bookingId+"&date=eq."+date,{method:"DELETE"});
      S.attendance=S.attendance.filter(x=>!(x.booking_id===bookingId&&x.date===date));
    }
  },
  async saveSettings(st){
    const next={...DEFAULT_SETTINGS,...st,_settingsUpdatedAtV626:Date.now()};
    S.settings=next;
    writeSettingsBackupV626(next);              // survives app/browser closing immediately
    if(REMOTE) await cloudUpsertSettingsV626(next); // shared source for every device
    return next;
  }
};

/* ---------------- helpers ---------------- */
const $ = sel => document.querySelector(sel);
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function shade(hex,p){
  const n=parseInt(hex.slice(1),16); let r=n>>16,g=(n>>8)&255,b=n&255;
  r=Math.min(255,Math.round(r+(255-r)*p)); g=Math.min(255,Math.round(g+(255-g)*p)); b=Math.min(255,Math.round(b+(255-b)*p));
  return "#"+((r<<16)|(g<<8)|b).toString(16).padStart(6,"0");
}

/* ============ COLOUR PALETTES (each works in light AND dark) ============ */
const PALETTES = {
  /* Midnight navy, champagne gold, warm ivory. A palette carries an optional
     font and button shape so one tap sets the whole look. */
  aurea: { label:"Aurea Resort", font:"aurea", btn:"pill",
    light:{ primary:"#101820", accent:"#C9A96E", bg:"#F7F3EC", text:"#101820", card:"#FFFFFF", sand:"#EFE8DC", line:"#E2D8C8" },
    dark: { primary:"#C9A96E", accent:"#C9A96E", bg:"#0B1016", text:"#F1EBE1", card:"#151C24", sand:"#1D2731", line:"#2A3540" } },
  brownWhite: { label:"Brown & White",
    light:{ primary:"#3E2A1E", accent:"#B98A5C", bg:"#F7F2EA", text:"#2B1F16", card:"#FFFFFF", sand:"#EFE6D8", line:"#E2D6C4" },
    dark: { primary:"#D9B47F", accent:"#C9A26B", bg:"#17110C", text:"#F2E7D8", card:"#221913", sand:"#2C211A", line:"#3A2C22" } }
};
function paletteList(){ return Object.keys(PALETTES); }
function applyPalette(){
  if(S.settings && S.settings.palette && S.settings.palette!=="custom" && !PALETTES[S.settings.palette]){
    S.settings.palette="brownWhite";                 // an old theme that no longer exists
  }
  const key=S.settings.palette;
  const pal=PALETTES[key]; if(!pal) return false;      // custom colours -> skip
  const mode=(S.theme==="dark")?"dark":"light";
  const c=pal[mode], root=document.documentElement.style;
  root.setProperty("--espresso",c.primary);
  root.setProperty("--cacao",shade(c.primary,.18));
  root.setProperty("--bronze",c.accent);
  root.setProperty("--bg-light",pal.light.bg);
  root.setProperty("--ink-light",pal.light.text);
  root.setProperty("--bg-dark",pal.dark.bg);
  root.setProperty("--ink-dark",pal.dark.text);
  root.setProperty("--bg",c.bg);
  root.setProperty("--ink",c.text);
  root.setProperty("--card",c.card);
  root.setProperty("--sand",c.sand);
  root.setProperty("--line",c.line);
  root.setProperty("--muted",shade(c.text,mode==="dark"?-0.35:0.42));
  root.setProperty("--nav-bg",c.card);
  root.setProperty("--nav-on",c.primary);
  return true;
}
function applySettings(){
  const st=S.settings, root=document.documentElement.style;
  applyAutoDark();
  if(applyPalette()){
    const pack=PALETTES[st.palette]||{};
    const f0=FONTS[st.fontStyle]||FONTS[pack.font]||FONTS.elegant;
    root.setProperty("--font-display",f0[0]); root.setProperty("--font-body",f0[1]);
    const br0=BTN_R[st.buttonStyle]||BTN_R[pack.btn]||BTN_R.rounded;
    root.setProperty("--btn-radius",br0[0]); root.setProperty("--btn-radius-sm",br0[1]);
    document.title=st.name||"Entertainment";
    return;
  }
  root.setProperty("--espresso",st.primary);
  root.setProperty("--cacao",shade(st.primary,.22));
  root.setProperty("--bronze",st.accent);
  root.setProperty("--bg-light",st.bg||"#F7F2EA");
  root.setProperty("--ink-light",st.textColor||"#2B1F16");
  if(S.theme==="light"){
    root.setProperty("--nav-bg",st.navBg||"#FFFFFF");
    root.setProperty("--nav-on",st.navActive||shade(st.primary,.22));
  } else { root.removeProperty("--nav-bg"); root.removeProperty("--nav-on"); }
  const f=FONTS[st.fontStyle]||FONTS.elegant;
  root.setProperty("--font-display",f[0]); root.setProperty("--font-body",f[1]);
  const br=BTN_R[st.buttonStyle]||BTN_R.rounded;
  root.setProperty("--btn-radius",br[0]); root.setProperty("--btn-radius-sm",br[1]);
  applyFontScale();
  document.title=st.name||"Entertainment";
}
const FONT_SCALES={small:.92,normal:1,large:1.12,xl:1.25};
/* Try a theme before committing to it. Cancel puts everything back. */
function openThemePreview(key){
  const before=S.settings.palette, beforeFont=S.settings.fontStyle, beforeBtn=S.settings.buttonStyle;
  const trying=(key==="custom")?"":key;
  S.settings.palette=trying;
  const pack=PALETTES[trying];
  if(pack && pack.font){ S.settings.fontStyle=pack.font; S.settings.buttonStyle=pack.btn||S.settings.buttonStyle; }
  applySettings();
  const name=PALETTES[trying]?PALETTES[trying].label:t("themeCustom");
  const wrap=baseModal(`
    <h3>${ic("palette",20)} ${esc(name)}</h3>
    <p class="mini">${t("previewOn")}</p>
    <div class="tp-demo">
      <div class="tp-card"><b>${esc(S.settings.name||"Entertainment")}</b>
        <span class="mini">${esc(t("appSub"))}</span>
        <span class="tp-btn">${t("book")}</span></div>
    </div>
    <button class="btn" id="tp-use">${t("applyTheme")}</button>
    <button class="btn ghost" id="tp-x">${t("cancelBtn")}</button>`);
  const revert=()=>{
    S.settings.palette=before; S.settings.fontStyle=beforeFont; S.settings.buttonStyle=beforeBtn;
    applySettings();
  };
  wrap.querySelector("#tp-x").onclick=()=>{ revert(); wrap.remove(); render(); };
  wrap.onclick=e=>{ if(e.target===wrap){ revert(); wrap.remove(); render(); } };
  wrap.querySelector("#tp-use").onclick=async ()=>{
    try{
      await DB.saveSettings({...S.settings, palette:trying});
      applySettings(); wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ revert(); toastErr(t("errSave")); }
  };
}
function applyFontScale(){
  const k=(S.settings&&S.settings.fontScale)||"normal";
  const v=FONT_SCALES[k]||1;
  document.documentElement.style.setProperty("--fscale", String(v));
}
/* follow the phone's dark mode when the manager switched it on */
function applyAutoDark(){
  if(!S.settings || !S.settings.autoDark) return;
  try{
    const m=window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)");
    if(!m) return;
    const want=m.matches?"dark":"light";
    if(S.theme!==want){ S.theme=want; document.documentElement.setAttribute("data-theme",want); }
    if(!window.__autoDarkHooked && m.addEventListener){
      window.__autoDarkHooked=true;
      m.addEventListener("change",()=>{ if(S.settings.autoDark){ applyAutoDark(); applySettings(); render(); } });
    }
  }catch(e){}
}
/* is a feature switched on? (missing = on, so nothing breaks) */
function featureOn(k){
  const f=(S.settings&&S.settings.features)||{};
  return f[k]!==false;
}
function menuLabel(key,fallback){ const v=(S.settings[key]||"").trim(); return v||fallback; }
function fmtTime(ts){ return whenLabel(ts); }
function bookingsFor(actId){ return S.bookings.filter(b=>b.activity_id===actId); }
function seatsTaken(actId){ return bookingsFor(actId).filter(b=>b.status==="booked").reduce((n,b)=>n+(+b.adults||0)+(+b.children||0),0); }
function myBooking(actId){ const g=S.session; if(!g||g.role!=="guest") return null;
  return S.bookings.find(b=>b.activity_id===actId && b.room===g.room); }
function ordersFor(tkId){ return S.orders.filter(o=>o.ticket_id===tkId); }
function ticketsSold(tkId){ return ordersFor(tkId).reduce((n,o)=>n+(+o.qty||0),0); }
function myOrders(){ const g=S.session; if(!g||g.role!=="guest") return [];
  return S.orders.filter(o=>o.room===g.room); }
function myRequestsList(){ const g=S.session; if(!g||g.role!=="guest") return [];
  return S.requests.filter(r=>r.room===g.room); }
function accountName(room){ const a=S.accounts.find(x=>x.room===room); return a?a.name:room; }
/* The registered guest behind a room number, matched loosely so 0102 finds 102. */
function guestForRoom(room){
  const r=String(room||"").trim();
  if(!r) return null;
  const list=S.accounts||[];
  return list.find(a=>String(a.room||"")===r)
      || list.find(a=>String(a.username||"")===r)
      || list.find(a=>String(a.room||"").replace(/^0+/,"")===r.replace(/^0+/,"") && r.replace(/^0+/,""))
      || null;
}
/* Every room the app knows about — the registered guests first, then any
   empty room from the room list, so she can pick instead of typing. */
function knownRooms(){
  const out=[];
  (S.accounts||[]).forEach(a=>{ const r=String(a.room||"").trim(); if(r&&!out.includes(r)) out.push(r); });
  (S.rooms||[]).forEach(x=>{ const r=String(x.room||"").trim(); if(r&&!out.includes(r)) out.push(r); });
  return out.sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));
}
function unreadFor(role){
  if(role==="guest"){ const g=S.session; return S.messages.filter(m=>m.room===g.room&&m.sender==="team"&&!m.read_by_guest).length; }
  return unreadGuests()+unreadTeam();
}
/* kept apart so a guest message never lights up Team, and the other way round */
function unreadGuests(){
  return S.messages.filter(m=>!isStaffRoom(m.room)&&m.sender==="guest"&&!m.read_by_team).length;
}
function unreadTeam(){
  return S.messages.filter(m=>isStaffRoom(m.room)&&m.sender==="guest"&&!m.read_by_team).length;
}
function teamReqCount(){
  return (S.staffReqs||[]).filter(r=>String(r.status||"new")==="new").length;
}
function visibleNotes(role){
  return S.notes.filter(n=>n.audience==="all" || (role==="guest"?n.audience==="guests":n.audience==="team"));
}
function unseenNotes(role){ return visibleNotes(role).some(n=>n.id>S.seenNote); }
function reviewDue(g){
  if(!g || !g.arrival || !g.departure) return false;
  const a=Date.parse(g.arrival), d=Date.parse(g.departure);
  if(isNaN(a)||isNaN(d)||d<a) return false;
  return Date.now() >= a+(d-a)/2;
}
/* ===== Universal toast: type = "success" | "error" | "warn" | "info" ===== */
function toast(msg, type){
  type = type || "success";
  const marks={success:"check",error:"close",warn:"bell",info:"sparkle"};
  const el=document.createElement("div");
  el.className="toast t-"+type;
  el.setAttribute("role", type==="error"?"alert":"status");
  el.innerHTML='<span class="t-ic">'+ic(marks[type]||"check",16)+'</span><span>'+esc(msg)+'</span>';
  document.body.appendChild(el);
  setTimeout(()=>{ el.classList.add("out"); setTimeout(()=>el.remove(),260); }, type==="error"?3600:2400);
}
function toastOk(m){ toast(m,"success"); }
function toastErr(m){ toast(m,"error"); }
function toastWarn(m){ toast(m,"warn"); }
/* ===== Premium confirmation dialog for dangerous actions =====
   confirmAction({question, detail, confirmLabel, danger}) -> Promise<boolean> */
function confirmAction(opts){
  const o=opts||{};
  return new Promise(resolve=>{
    const wrap=document.createElement("div");
    wrap.className="modal-bg confirm-bg";
    wrap.innerHTML=`<div class="modal confirm-modal" role="dialog" aria-modal="true">
      <div class="cf-ic ${o.danger?"danger":""}">${ic(o.danger?"trash":"bell",22)}</div>
      <h3>${esc(o.question||t("confirmTitle"))}</h3>
      <p class="mini cf-sub">${esc(o.detail||t("cannotUndo"))}</p>
      <div class="cf-row">
        <button class="btn ghost" data-cf="no">${t("cancelBtn")}</button>
        <button class="btn ${o.danger?"warn":""}" data-cf="yes">${esc(o.confirmLabel||t("deleteActivity"))}</button>
      </div>
    </div>`;
    const done=v=>{ wrap.remove(); document.removeEventListener("keydown",onKey); resolve(v); };
    function onKey(e){ if(e.key==="Escape") done(false); }
    wrap.querySelector('[data-cf="no"]').onclick=()=>done(false);
    wrap.querySelector('[data-cf="yes"]').onclick=()=>done(true);
    wrap.onclick=e=>{ if(e.target===wrap) done(false); };
    document.addEventListener("keydown",onKey);
    document.body.appendChild(wrap);
    setTimeout(()=>{ const b=wrap.querySelector('[data-cf="yes"]'); if(b) b.focus(); },40);
  });
}
/* ===== Connection banner: offline / back online ===== */
let __wasOffline=false;
function connBanner(show, msg, kind){
  let el=document.getElementById("conn-banner");
  if(!show){ if(el) el.remove(); return; }
  if(!el){ el=document.createElement("div"); el.id="conn-banner"; document.body.appendChild(el); }
  el.className="conn-banner "+(kind||"off");
  el.textContent=msg;
}
function initConnectionWatch(){
  function goOffline(){ __wasOffline=true; connBanner(true, t("offlineMsg"), "off"); }
  function goOnline(){
    if(!__wasOffline){ connBanner(false); return; }
    __wasOffline=false;
    connBanner(true, t("backOnlineMsg"), "on");
    if(typeof runPoll==="function") runPoll();
    setTimeout(()=>connBanner(false), 2600);
  }
  window.addEventListener("offline", goOffline);
  window.addEventListener("online", goOnline);
  if(navigator.onLine===false) goOffline();
}
/* ===== Global error safety net: never leave a broken screen silently ===== */
function initErrorGuard(){
  window.addEventListener("error", e=>{ console.error("app error:", e && e.message); });
  window.addEventListener("unhandledrejection", e=>{
    const r=e && e.reason;
    console.error("unhandled:", r);
    const txt=String((r && r.message)||r||"");
    if(/fetch|network|Failed to fetch|NetworkError/i.test(txt)) toastErr(t("errNet"));
  });
}
function setLang(l){ S.lang=l; document.documentElement.lang=l; document.documentElement.dir=(l==="ar"?"rtl":"ltr"); try{ localStorage.setItem("entapp_lang",l); }catch(e){} persist(); render(); }
function setTheme(th){ S.theme=th; document.documentElement.setAttribute("data-theme",th); applySettings(); persist(); render(); }
function catLabel(c){ return t("cats")[c]||c; }
/* Four clean operations (Kids removed). Sub-category ids kept for data mapping. */
const OPS=[
  {id:"daytime", cats:["mAdult"]},
  {id:"dayevents", cats:["mEvents"]},
  {id:"evening", cats:["eBefore","eLive","eShow","eAfter"]},
  {id:"special", cats:["eParty"]}
];
function opLabel(op){ return {daytime:t("opDaytime"),dayevents:t("opDayEvents"),evening:t("opEvening"),special:t("opSpecial")}[op]||op; }
function opOf(cat){ const o=OPS.find(o=>o.cats.includes(cat)); return o?o.id:"daytime"; }
function allCats(){ return [...new Set(OPS.flatMap(o=>o.cats))]; }
/* map ANY old/new category to one of the four operations' sub-categories */
function normCat(a){
  const c=a.category||"";
  if(allCats().includes(c)) return c;
  const legacy={
    // old morning/afternoon regular -> daytime activities
    morning:"mAdult", afternoon:"mAdult", mAdult:"mAdult", mKids:"mAdult", mTeen:"mAdult",
    // events -> day events
    mEvents:"mEvents", theme:"mEvents", kids:"mAdult",
    // evening buckets
    eLive:"eLive", eBefore:"eBefore", eShow:"eShow", eAfter:"eAfter", eKidsStage:"eShow",
    eParty:"eParty",
    evening: a.highlight?"eShow":"eLive"
  };
  return legacy[c]|| (a.highlight?"eShow":"mAdult");
}
function actOp(a){ return opOf(normCat(a)); }
const CAT_ORDER=["mAdult","mEvents","eBefore","eLive","eShow","eAfter","eParty"];
function catImage(cat){
  return {mAdult:IMG.yoga,mEvents:IMG.foam,eBefore:IMG.neon,eLive:IMG.show,eShow:IMG.dance,eAfter:IMG.neon,eParty:IMG.foam}[cat]||IMG.show;
}
/* operation cover images */
function opImage(op){
  return {daytime:IMG.yoga,dayevents:IMG.foam,evening:IMG.show,special:IMG.neon}[op]||IMG.show;
}
const TASK_TYPES=["come","leave","activity","feedback","collect"];
const TASK_ICON={come:"pin",leave:"exit",activity:"flag",feedback:"star",collect:"users"};
const ICONS={
menu:'<path d="M4 7h16M4 12h16M4 17h10"/>',
home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v11h14V10"/><path d="M10 21v-6h4v6"/>',
calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
ticket:'<path d="M4 8a2 2 0 012-2h12a2 2 0 012 2v1.5a2.5 2.5 0 000 5V16a2 2 0 01-2 2H6a2 2 0 01-2-2v-1.5a2.5 2.5 0 000-5z"/><path d="M14 6v12" stroke-dasharray="2.5 2.5"/>',
chat:'<path d="M21 11.5a8 8 0 01-8 8H5.5L3 22V11.5a8 8 0 018-8h2a8 8 0 018 8z"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4.5 21c1.4-3.8 4.6-5.5 7.5-5.5s6.1 1.7 7.5 5.5"/>',
users:'<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20c1-3.4 3.9-5 6.5-5s5.5 1.6 6.5 5"/><path d="M16 5.6a3.5 3.5 0 010 5.8M18.5 15.4c1.6.8 2.8 2.3 3.2 4.6"/>',
bell:'<path d="M6 9.5a6 6 0 0112 0c0 4.6 2 5.8 2 5.8H4s2-1.2 2-5.8z"/><path d="M10 19.5a2.2 2.2 0 004 0"/>',
belloff:'<path d="M6 9.5a6 6 0 0112 0c0 4.6 2 5.8 2 5.8H4s2-1.2 2-5.8z"/><path d="M10 19.5a2.2 2.2 0 004 0"/><path d="M3 3l18 18" stroke-width="2"/>',
moon:'<path d="M20.5 13.5A8.5 8.5 0 1110.5 3.5a7 7 0 0010 10z"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8"/>',
cloud:'<path d="M7 18h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 18z"/>',
rain:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M9 18l-1 3M13 18l-1 3M17 18l-1 3"/>',
snow:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M9 19h.01M13 19h.01M11 21h.01M15 21h.01"/>',
storm:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M12 17l-2 3.5h3L11 24"/>',
globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.6 3 14.4 0 18M12 3c-3 3.6-3 14.4 0 18"/>',
power:'<path d="M12 3v8"/><path d="M6.3 6.6a8 8 0 1011.4 0"/>',
back:'<path d="M15 5l-7 7 7 7"/>',
send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
check:'<path d="M5 13l4 4L19 7"/>',
bus:'<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M3 11h18"/><circle cx="7.5" cy="17" r="1.6"/><circle cx="16.5" cy="17" r="1.6"/><path d="M6 17H5m14 0h-1"/>',
clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
pin:'<path d="M12 21.5s7-6.4 7-11.3a7 7 0 10-14 0c0 4.9 7 11.3 7 11.3z"/><circle cx="12" cy="10" r="2.5"/>',
star:'<path d="M12 3l2.7 5.7 6.3.8-4.6 4.3 1.2 6.2L12 17l-5.6 3 1.2-6.2L3 9.5l6.3-.8z"/>',
heart:'<path d="M12 20.5S3.8 15.5 2.5 10.7A5 5 0 0112 7a5 5 0 019.5 3.7C20.2 15.5 12 20.5 12 20.5z"/>',
pen:'<path d="M4 20l4.5-1L19.5 8a2.1 2.1 0 00-3-3L5.5 16 4 20z"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
trash:'<path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13"/>',
close:'<path d="M6 6l12 12M18 6L6 18"/>',
download:'<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
sparkle:'<path d="M12 2.5l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/><path d="M19 15.5l.9 2.6 2.6.9-2.6.9-.9 2.6-.9-2.6-2.6-.9 2.6-.9z"/>',
palette:'<path d="M12 21a9 9 0 110-18 9 9 0 019 8.6c0 2-1.4 2.6-2.9 2.6h-2A2.6 2.6 0 0013.5 17c0 1.4.6 4-1.5 4z"/><circle cx="8" cy="9" r="1.1"/><circle cx="12.5" cy="6.8" r="1.1"/><circle cx="16.5" cy="9.5" r="1.1"/>',
grid:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
clipboard:'<rect x="6" y="4.5" width="12" height="17" rx="2"/><path d="M9 4.5a3 3 0 016 0M9 11h6M9 15h6"/>',
flag:'<path d="M5.5 21V4"/><path d="M5.5 4.5h11.5l-2.5 4 2.5 4H5.5"/>',
exit:'<path d="M13.5 4.5H19v15h-5.5"/><path d="M10 8.5L6.5 12l3.5 3.5M6.5 12H15"/>',
gift:'<path d="M20 12.5V21H4v-8.5M2.5 7.5h19v5h-19zM12 7.5V21"/><path d="M12 7.5c-3 0-4.7-2.7-3-4.3C10.6 1.7 12 4.5 12 7.5c0-3 1.4-5.8 3-4.3 1.7 1.6 0 4.3-3 4.3z"/>',
music:'<path d="M9 18.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0zM20 16.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/><path d="M9 18.5V5.5l11-2v13"/>',
lock:'<rect x="5" y="11" width="14" height="9.5" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z"/><path d="M7 6H4.2A2.8 2.8 0 007 9.8M17 6h2.8A2.8 2.8 0 0117 9.8"/>',
door:'<rect x="5" y="3" width="14" height="18" rx="1.5"/><circle cx="15" cy="12" r="1" fill="currentColor" stroke="none"/>',
key:'<circle cx="8" cy="14.5" r="4"/><path d="M11 11.5L20 3M16 7l2.5 2.5M13.5 9.5L16 12"/>'
};
const BRAND={
Instagram:'<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17.2" cy="6.8" r="1.2" fill="currentColor"/>',
TikTok:'<path fill="currentColor" d="M16.5 3c.4 2.3 1.8 3.8 4 4.1v3c-1.6 0-3-.5-4-1.3v6.7a5.75 5.75 0 11-5.75-5.75c.26 0 .5.02.75.06v3.1a2.7 2.7 0 102 2.6V3h3z"/>',
Facebook:'<path fill="currentColor" d="M14 8.5h3.2V5H14a4.2 4.2 0 00-4.2 4.2v2.3H7v3.5h2.8V22h3.6v-7h3l.6-3.5h-3.6V9.4c0-.5.3-.9.6-.9z"/>',
YouTube:'<rect x="2.5" y="6" width="19" height="12.5" rx="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path fill="currentColor" d="M10.3 9.4l5 2.85-5 2.85z"/>',
WhatsApp:'<path fill="currentColor" d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.2zm4.6-6.1c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.7.8-.8 1-.1.2-.3.2-.5.1a6.7 6.7 0 01-3.3-2.9c-.2-.4 0-.5.1-.7l.4-.5c.1-.2.1-.3.2-.5s0-.4 0-.5c-.1-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.6 1.1 2.8c.1.2 1.9 3 4.7 4.1.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.6-.3z"/>'
};
function ic(name,size=20){ return `<svg class="ic-s" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]||ICONS.star}</svg>`; }
function mi(name){ return `<span class="mi">${ic(name,13)}</span>`; }
function brandIc(name){ return `<svg class="ic-s" width="17" height="17" viewBox="0 0 24 24" aria-hidden="true">${BRAND[name]||""}</svg>`; }
function rankBadge(i){ return `<span class="rankb r${i<3?i:"x"}">${i+1}</span>`; }
function taskTypeLabel(ty){return {come:t("ttCome"),leave:t("ttLeave"),activity:t("ttActivity"),feedback:t("ttFeedback"),collect:t("ttCollect")}[ty]||ty;}
function canSeeGuests(a){
  if(!S.session) return false;
  if(S.session.role==="manager") return true;
  if(S.session.role!=="staff") return false;
  const e=(a.entertainer||"").toLowerCase().trim();
  if(!e) return false;
  if(e==="team"||e==="all team") return true;
  const u=(S.session.username||"").toLowerCase(), d=(S.session.name||"").toLowerCase();
  return (u&&e.includes(u))||(d&&e.includes(d));
}
function guestDaysHere(acc){
  if(!acc || !acc.created_at) return null;
  const d=Math.floor((Date.now()-Date.parse(acc.created_at))/864e5);
  return isNaN(d)?null:Math.max(0,d);
}
function guestActivities(room){
  return S.bookings.filter(b=>String(b.room)===String(room))
    .map(b=>{ const a=S.activities.find(x=>x.id===b.activity_id); return a?a.name:null; })
    .filter(Boolean);
}
function guestFullInfo(room){
  const acc=S.accounts.find(a=>String(a.room)===String(room) || String(a.username||"")===String(room));
  if(!acc) return null;
  return {room:acc.room,name:acc.name,username:acc.username||acc.room,phone:acc.phone||"",
    nationality:acc.nationality||"",arrival:acc.arrival||"",departure:acc.departure||"",
    days:guestDaysHere(acc),activities:guestActivities(acc.room),
    tickets:S.orders.filter(o=>String(o.room)===String(acc.room)).reduce((n,o)=>n+(+o.qty||0),0),
    requests:S.requests.filter(r=>String(r.room)===String(acc.room)).length};
}
function teamMemberList(){
  const out=[], seen=new Set();
  S.profiles.forEach(p=>{
    const nm=String(p.name||"").trim();
    if(nm && !seen.has(nm.toLowerCase())){ seen.add(nm.toLowerCase()); out.push({name:nm,photo:p.photo||""}); }
  });
  S.users.filter(u=>u.role==="staff").forEach(u=>{
    const nm=String(u.display_name||u.username||"").trim();
    if(nm && !seen.has(nm.toLowerCase())){ seen.add(nm.toLowerCase()); out.push({name:nm,photo:""}); }
  });
  return out;
}
function staffStats(username){
  const mine=S.tasks.filter(x=>x.assigned_to===username);
  const done=mine.filter(x=>x.status==="done"&&!x.was_still).length;
  const late=mine.filter(x=>x.status==="done"&&x.was_still).length;
  const cant=mine.filter(x=>x.status==="cant").length;
  const open=mine.filter(x=>["open","accepted","still"].includes(x.status)).length;
  return {done,late,cant,open,points:done*10+late*6};
}
function rankingRows(){
  return S.users.filter(u=>u.role==="staff")
    .map(u=>({u,...staffStats(u.username)}))
    .sort((a,b)=>b.points-a.points);
}
/* ================= RENDER ================= */
/* ================= SCREEN HISTORY (back / forward) =================
   Records every screen change automatically, so Back and Forward work
   everywhere without having to touch each button. */
let NAV_HIST=[], NAV_IDX=-1, NAV_LOCK=false;
function navSnapshot(){
  return JSON.stringify({tab:S.tab, sub:S.sub, op:S.op, cat:S.cat,
    chatRoom:S.chatRoom, planDay:S.planDay, day:S.day});
}
function navRecord(){
  if(NAV_LOCK) return;
  const snap=navSnapshot();
  if(NAV_IDX>=0 && NAV_HIST[NAV_IDX]===snap) return;   // nothing changed
  NAV_HIST=NAV_HIST.slice(0, NAV_IDX+1);               // drop any forward branch
  NAV_HIST.push(snap);
  if(NAV_HIST.length>60) NAV_HIST.shift();             // keep memory small
  NAV_IDX=NAV_HIST.length-1;
}
function navApply(snap){
  let o; try{ o=JSON.parse(snap); }catch(e){ return; }
  S.tab=o.tab; S.op=o.op; S.cat=o.cat; S.chatRoom=o.chatRoom;
  if(o.sub) S.sub=o.sub;
  S.planDay=o.planDay;
  if(typeof o.day==="number") S.day=o.day;
}
function canNavBack(){ return NAV_IDX>0; }
function canNavForward(){ return NAV_IDX < NAV_HIST.length-1; }
function navBack(){
  if(!canNavBack()) return;
  NAV_IDX--; NAV_LOCK=true; navApply(NAV_HIST[NAV_IDX]); render(); NAV_LOCK=false;
}
function navForward(){
  if(!canNavForward()) return;
  NAV_IDX++; NAV_LOCK=true; navApply(NAV_HIST[NAV_IDX]); render(); NAV_LOCK=false;
}
function navReset(){ NAV_HIST=[]; NAV_IDX=-1; }
function render(){
  const app=$("#app");
  document.documentElement.setAttribute("data-approle", S.session?S.session.role:"none");
  if(S.loadError){ app.innerHTML=errorView(); const r=$("#btn-retry"); if(r) r.onclick=()=>location.reload(); return; }
  if(!S.session){
    const __publicFirst639 = window.__PUBLIC_EXPLORE_EXITED_V639!==true;
    if((window.__PUBLIC_EXPLORE_V637 || __publicFirst639) && typeof window.visitorExploreView637==="function"){
      window.__PUBLIC_EXPLORE_V637=true;
      document.documentElement.setAttribute("data-approle","visitor");
      app.innerHTML=window.visitorExploreView637();
      if(typeof window.wireVisitorExplore637==="function") window.wireVisitorExplore637();
      return;
    }
    app.innerHTML=loginView(); wireLogin();
    // Connected but the database sent back nothing -> tell the user plainly
    if(REMOTE && !S.loadError && S.rooms.length===0 && S.users.length===0 && !window.__noDataWarned){
      window.__noDataWarned=true;
      setTimeout(()=>{ try{ toastErr(t("noDataTitle")); }catch(e){} }, 400);
      console.warn("Database reachable but returned no rooms and no users — check the access policies (run repair-access.sql).");
    }
    return;
  }
  const r=S.session.role;
  // V5.3: migrate Manager sessions that were accidentally saved on Program by the auth repair.
  if(r==="manager" && (!S.tab || S.tab==="home")){ S.tab="dash"; S.sub.dash="overview"; }
  let html="";
  try{
    html=(r==="guest" ? guestView() : r==="staff" ? staffView() : managerView());
  }catch(e){
    console.error("view render failed",e);
    // A broken landing widget must never make a valid login look like an authentication failure.
    try{
      if(r==="manager"){ S.tab="dash"; S.sub.dash="overview"; html=managerView(); }
      else if(r==="staff"){ S.tab="today"; html=staffView(); }
      else html=guestView();
    }catch(e2){
      console.error("fallback view failed",e2);
      html=`<div class="screen fadein"><div class="empty"><div class="big">!</div><b>Signed in, but this screen could not open.</b><br><span class="mini">A screen component failed to load. Please retry or open safe home.</span><button class="btn" id="safe-home" style="margin-top:18px">Open safe home</button></div></div>`;
    }
  }
  app.innerHTML=html;
  const sh=$("#safe-home"); if(sh) sh.onclick=()=>{ S.tab=r==="manager"?"dash":r==="staff"?"today":"home"; render(); };
  navRecord();
  wireCommon();
}
function errorView(){
  return `<div class="screen fadein" style="display:flex;flex-direction:column;justify-content:center">
    <div class="empty"><div class="big">${ic("globe",30)}</div>
      Could not reach the database.<br>Please check your internet connection.
      <button class="btn" id="btn-retry" style="margin-top:18px">${ic("back",16)}</button>
    </div></div>`;
}

/* ---------------- login ---------------- */
let loginMode="guest";
let guestMode="new";
let rememberMe=true;
let wiz={step:0,room:"",nat:"",name:"",phone:"",arr:"",dep:"",username:"",password:""};
function resetWiz(){ wiz={step:0,room:"",nat:"",name:"",phone:"",arr:"",dep:"",username:"",password:""}; }
let loginRole="staff";
function loginView(){
  const st=S.settings;
  const brand=`
    <div class="brandmark">
      <div class="mono serif${st.logo?" haslogo":""}">${st.logo
        ?`<img src="${esc(st.logo)}" alt="${esc(st.name||"")}">`
        :esc((st.name||"E").trim().charAt(0).toUpperCase())}</div>
      <h1>${esc(st.name)}</h1>
      <p>${esc(st.subtitle||t("appSub"))}</p>
    </div>
    <div class="lang-row">
      ${LANGS.map(([l,label])=>`<button data-lang="${l}" class="${S.lang===l?"on":""}">${label}</button>`).join("")}
    </div>`;
  if(loginMode==="guest"){
    const remRow=`<label class="remrow"><input type="checkbox" id="cb-rem" ${rememberMe?"checked":""}> ${t("rememberMe")}</label>`;
    const dots=`<div class="wz-dots">${[0,1,2,3,4,5,6].map(i=>`<span class="wz-dot ${wiz.step===i?"on":wiz.step>i?"done":""}"></span>`).join("")}</div>`;
    const backLink=wiz.step>0?`<button class="wz-back" id="wz-back">${ic("back",14)} ${t("backStep")}</button>`:"";
    let stepHtml="";
    if(wiz.step===0) stepHtml=`<label>${t("room")}</label>
        <button class="pickfield" id="wz-pick">${wiz.room?`<b>${esc(wiz.room)}</b>`:t("chooseRoom")}<span class="pf-ch">${ic("back",16)}</span></button>`;
    else if(wiz.step===1) stepHtml=`<label>${t("nationality")}</label>
        <button class="pickfield" id="wz-pick">${wiz.nat?`<b>${esc(wiz.nat)}</b>`:t("chooseNat")}<span class="pf-ch">${ic("back",16)}</span></button>`;
    else if(wiz.step===2) stepHtml=`<label>${t("name")}</label><input id="wz-in" value="${esc(wiz.name)}" placeholder="${t("name")}">`;
    else if(wiz.step===3) stepHtml=`<label>${t("phone")}</label><input id="wz-in" inputmode="tel" value="${esc(wiz.phone)}" placeholder="+49 ...">`;
    else if(wiz.step===4) stepHtml=`<label>${t("arrival")}</label><input id="wz-in" type="date" value="${esc(wiz.arr)}">`;
    else if(wiz.step===5) stepHtml=`<label>${t("departure")}</label><input id="wz-in" type="date" value="${esc(wiz.dep)}" min="${esc(wiz.arr)}">`;
    else stepHtml=`<label>${t("user")}</label><input id="wz-user" autocapitalize="none" value="${esc(wiz.username||wiz.room)}">
        <label>${t("pass")}</label><input id="wz-pass" autocapitalize="none" value="${esc(wiz.password)}" placeholder="••••••">
        ${remRow}`;
    const wizard=`
        ${dots}
        ${stepHtml}
        ${wiz.step<6
          ? `<button class="btn" id="wz-next">${t("nextStep")}</button>`
          : `<button class="btn" id="wz-create">${t("createAccount")}</button>`}
        ${backLink}`;
    const fields = guestMode==="new" ? wizard : `
        <label>${t("user")} · ${t("room")}</label><input id="f-room" inputmode="numeric" value="${esc(wiz.room)}" placeholder="4215">
        <label>${t("pass")}</label><input id="f-gpass" type="password" placeholder="••••••">
        ${remRow}`;
    return `<div class="login-wrap fadein">
      ${brand}
      <div class="role-tabs">
        <button data-gmode="signin" class="${guestMode==="signin"?"on":""}">${t("signin")}</button>
        <button data-gmode="new" class="${guestMode==="new"?"on":""}">${t("firstVisit")}</button>
      </div>
      <div class="login-card">
        ${fields}
        ${guestMode==="signin"?`<button class="btn" id="btn-login">${t("signin")}</button>`:""}
        <div class="err" id="login-err"></div>
        ${!REMOTE?`<p class="hint">${t("demoNote")}</p>`:""}
      </div>
      <button class="visitor-explore-btn" id="btn-public-explore">${ic("sparkle",16)} <span>Explore the entertainment</span><small>No account needed</small></button>
      <button class="staff-link" id="btn-teamlink">${ic("sparkle",15)} <span>${t("otherUsers")}</span></button>
    </div>`;
  }
  return `<div class="login-wrap fadein">
    ${brand}
    <div class="role-tabs">
      ${["staff","manager"].map(r=>`<button data-role="${r}" class="${loginRole===r?"on":""}">${t(r)}</button>`).join("")}
    </div>
    <div class="login-card">
      <label>${t("user")}</label><input id="f-user" autocapitalize="none" placeholder="${loginRole}">
      <label>${t("pass")}</label><input id="f-pass" type="password" placeholder="••••">
      <button class="btn" id="btn-login">${t("signin")}</button>
      <div class="err" id="login-err"></div>
    </div>
    <button class="visitor-explore-btn" id="btn-public-explore">${ic("sparkle",16)} <span>Explore the entertainment</span><small>No account needed</small></button>
    <button class="staff-link" id="btn-guestlink"><span>${t("backToGuest")}</span></button>
  </div>`;
}
function wireLogin(){
  document.querySelectorAll("[data-lang]").forEach(b=>b.onclick=()=>setLang(b.dataset.lang));
  document.querySelectorAll("#app [data-role]").forEach(b=>b.onclick=()=>{loginRole=b.dataset.role;render();});
  document.querySelectorAll("[data-gmode]").forEach(b=>b.onclick=()=>{guestMode=b.dataset.gmode;render();});
  const tl=$("#btn-teamlink"); if(tl) tl.onclick=()=>{loginMode="team";render();};
  const gl=$("#btn-guestlink"); if(gl) gl.onclick=()=>{loginMode="guest";render();};
  const px=$("#btn-public-explore"); if(px) px.onclick=()=>{ window.__PUBLIC_EXPLORE_V637=true; window.__PUBLIC_EXPLORE_DAY_V637=todayIndex(); render(); };
  const wireWizard=()=>{
    const err=$("#login-err");
    const pick=$("#wz-pick");
    if(pick) pick.onclick=()=>{ wiz.step===0?openRoomPicker():openNatPicker(); };
    const back=$("#wz-back");
    if(back) back.onclick=()=>{ wiz.step=Math.max(0,wiz.step-1); render(); };
    const next=$("#wz-next");
    if(next) next.onclick=()=>{
      if(wiz.step===0){
        if(!wiz.room){ err.textContent=t("loginErr"); return; }
        const existing=S.accounts.find(a=>String(a.room)===String(wiz.room));
        if(existing && existing.active!==false && !stayExpired(existing)){ err.textContent=t("accountExists"); guestMode="signin"; setTimeout(render,1500); return; }
      }
      if(wiz.step===1 && !wiz.nat){ err.textContent=t("loginErr"); return; }
      if(wiz.step===2){ wiz.name=$("#wz-in").value.trim(); if(!wiz.name){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===3){ wiz.phone=$("#wz-in").value.trim(); if(!wiz.phone){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===4){ wiz.arr=$("#wz-in").value; if(!wiz.arr){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===5){
        wiz.dep=$("#wz-in").value;
        if(!wiz.dep || Date.parse(wiz.dep)<Date.parse(wiz.arr)){ err.textContent=t("loginErr"); return; }
      }
      wiz.step++; render();
    };
    const create=$("#wz-create");
    if(create) create.onclick=async ()=>{
      wiz.username=$("#wz-user").value.trim();
      wiz.password=$("#wz-pass").value.trim();
      const cb=$("#cb-rem"); rememberMe=cb?cb.checked:true;
      if(wiz.username.length<3 || wiz.password.length<4){ err.textContent=t("loginErr"); return; }
      const recyclable=S.accounts.find(a=>String(a.room)===String(wiz.room) && (a.active===false || stayExpired(a)));
      const taken=S.accounts.some(a=>a!==recyclable && String(a.username||"").toLowerCase()===wiz.username.toLowerCase())
        || (S.rooms.some(r=>String(r.room)===wiz.username) && wiz.username!==String(wiz.room));
      if(taken){ err.textContent=t("userExists"); return; }
      const rm=S.rooms.find(x=>String(x.room)===String(wiz.room));
      if(!rm || !rm.active){ err.textContent=t("roomNotFound"); return; }
      if(S.accounts.some(a=>String(a.room)===String(wiz.room) && a.active!==false && !stayExpired(a))){ err.textContent=t("accountExists"); guestMode="signin"; setTimeout(render,1500); return; }
      let acc;
      try{ acc=await DB.addAccount({room:wiz.room,name:wiz.name,phone:wiz.phone,nationality:wiz.nat,
        arrival:wiz.arr,departure:wiz.dep,username:wiz.username,password:wiz.password}); }
      catch(e){ err.textContent=t("loginErr"); return; }
      S.remember=rememberMe;
      resetWiz();
      startGuestSession(acc);
    };
  };
  if(loginMode==="guest" && guestMode==="new") wireWizard();
  const bl=$("#btn-login");
  if(bl) bl.onclick=async ()=>{
    const err=$("#login-err");
    if(loginMode==="guest"){
      const room=$("#f-room").value.trim();
      if(!room){ err.textContent=t("loginErr"); return; }
      const existing=S.accounts.find(a=>String(a.room)===room || String(a.username||"")===room);
      if(!existing){ err.textContent=t("roomNotFound"); return; }
      const rm=S.rooms.find(x=>String(x.room)===String(existing.room));
      if(!rm || !rm.active){ err.textContent=t("roomNotFound"); return; }
      const p=$("#f-gpass").value;
      if(existing.password && existing.password!==p){ err.textContent=t("loginErr"); return; }
      const cb=$("#cb-rem"); S.remember=rememberMe=(cb?cb.checked:true);
      startGuestSession(existing);
    } else {
      const uRaw=String($("#f-user").value||"").trim();
      const pRaw=String($("#f-pass").value||"");
      const u=uRaw.toLowerCase();
      const p=pRaw.trim();
      if(!u || !p){ err.textContent=t("loginErr"); return; }

      // One predictable authentication path for both Team and Manager.
      // Usernames are case-insensitive; passwords tolerate accidental leading/trailing spaces.
      let found=(S.users||[]).find(x=>
        String(x.username||"").trim().toLowerCase()===u &&
        !isAttOnly(x) &&
        (loginRole==="manager" ? x.role==="manager" : x.role==="staff")
      );

      // Authenticate only against a real Manager/Team account in the loaded user directory.
      // No hard-coded recovery password is exposed or accepted in production.
      if(!found || String(found.password==null?"":found.password).trim()!==p){
        err.textContent=t("loginErr"); return;
      }

      if(!accountActive(found)){ err.textContent=t("accountOff"); return; }
      clearAttempts();
      const role=loginRole==="manager"?"manager":"staff";
      S.remember=true;
      S.session={role,name:found.display_name||found.username,username:found.username||u,userId:found.id,number:found.number||null,photo:found.photo||''};
      S.tab=defaultTabFor(role); navReset(); persist();
      try{ render(); }catch(e){
        console.error("login render failed",e);
        // Keep the session and retry on a simple, low-dependency screen.
        S.tab=role==="manager"?"dash":"today"; if(role==="manager") S.sub.dash="overview"; persist(); render();
      }
      askNotifPermission();
    }
  };
}

function openRoomPicker(){
  const rooms=S.rooms.filter(r=>r.active).map(r=>String(r.room))
    .sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  const wrap=baseModal(`
    <h3>${ic("door",20)} ${t("chooseRoom")}</h3>
    <input id="pk-q" placeholder="..." inputmode="numeric" style="margin-top:8px">
    <div class="picklist">${rooms.length?rooms.map(r=>`<button class="pick-it" data-pick="${esc(r)}">${esc(r)}</button>`).join(""):`<p class="mini" style="padding:14px 6px;text-align:center">${t("noDataRooms")}</p>`}</div>
    <button class="btn ghost" id="pk-x">${t("close")}</button>`);
  wrap.querySelector("#pk-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{ wiz.room=b.dataset.pick; wrap.remove(); render(); });
  wrap.querySelector("#pk-q").oninput=e=>{
    const q=e.target.value.trim().toLowerCase();
    wrap.querySelectorAll(".pick-it").forEach(el=>{ el.style.display=!q||el.dataset.pick.toLowerCase().includes(q)?"":"none"; });
  };
}
function openNatPicker(){
  const wrap=baseModal(`
    <h3>${ic("flag",20)} ${t("chooseNat")}</h3>
    <input id="pk-q" placeholder="..." style="margin-top:8px">
    <div class="picklist one">${NATIONS.map(n=>`<button class="pick-it" data-pick="${esc(n)}">${esc(n)}</button>`).join("")}</div>
    <button class="btn ghost" id="pk-x">${t("close")}</button>`);
  wrap.querySelector("#pk-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{
    const picked=b.dataset.pick;
    if(picked==="Other"){ wrap.remove(); openNatTypeModal(); return; }
    wiz.nat=picked; wrap.remove(); render();
  });
  wrap.querySelector("#pk-q").oninput=e=>{
    const q=e.target.value.trim().toLowerCase();
    wrap.querySelectorAll(".pick-it").forEach(el=>{ el.style.display=!q||el.dataset.pick.toLowerCase().includes(q)?"":"none"; });
  };
}
/* Lets the guest type a nationality that is not in the list */
function openNatTypeModal(){
  const wrap=baseModal(`
    <h3>${ic("flag",20)} ${t("typeNationality")}</h3>
    <input id="nt-v" placeholder="${esc(t("typeNationality"))}" autocapitalize="words" style="margin-top:8px">
    <button class="btn" id="nt-ok">${t("save")}</button>
    <button class="btn ghost" id="nt-back">${t("close")}</button>`);
  wrap.querySelector("#nt-back").onclick=()=>{ wrap.remove(); openNatPicker(); };
  wrap.querySelector("#nt-ok").onclick=()=>{
    const v=wrap.querySelector("#nt-v").value.trim();
    if(!v){ toastWarn(t("fieldRequired")); return; }
    wiz.nat=v; wrap.remove(); render();
  };
  setTimeout(()=>{ const i=wrap.querySelector("#nt-v"); if(i) i.focus(); },60);
}
function startGuestSession(acc){
  // a finished stay or a switched-off account can never start a session
  if(stayExpired(acc)){ toastWarn(t("stayEnded")); return; }
  if(acc.active===false){ toastWarn(t("accountOff")); return; }
  S.session={role:"guest",room:acc.room,name:acc.name,phone:acc.phone||"",
    nationality:acc.nationality||"",arrival:acc.arrival,departure:acc.departure,
    accountId:acc.id,username:acc.username||acc.room};
  S.tab="home"; persist(); render();
  askNotifPermission();
}
/* ---------------- shared pieces ---------------- */
function socialTopIcons(){
  const st=S.settings;
  const links=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube],["WhatsApp",waLink()]].filter(x=>x[1]);
  return links.map(([n,u])=>`<a class="iconbtn socialtop" href="${esc(u)}" target="_blank" rel="noopener" aria-label="${n}">${brandIc(n)}</a>`).join("");
}
function waLink(){
  const num=String(S.settings.whatsapp||"").replace(/[^0-9]/g,"");
  return num?("https://wa.me/"+num):"";
}
function navGroupsBase(role){
  if(role==="guest"){
    const un=unreadFor("guest");
    return [
      {key:"secProgram", head:t("secProgram"), items:[
        ["home","home",menuLabel("menuHome",t("home")),0],
        ["program","calendar",menuLabel("menuProgram",t("program")),0],
        ["chat","chat",menuLabel("menuChat",t("chat")),un],
        ["teaminfo","users",t("teamPage"),0],
        ["stay","user",t("myActs"),0],
        ...(featureOn("tickets")?[["tickets","ticket",t("myTickets"),0]]:[])]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["social","star",t("socialPage"),0]]}
    ];
  }
  if(role==="staff"){
    const myRoom="staff:"+S.session.username;
    const un=S.messages.filter(m=>m.room===myRoom&&m.sender==="team"&&!m.read_by_guest).length;
    const taskN=S.tasks.filter(x=>["open","accepted","still"].includes(x.status)&&(!x.assigned_to||x.assigned_to===S.session.username)).length;
    return [
      {key:"secTeamwork", head:t("secTeamwork"), items:[
        ["workday","clipboard",t("myWorkDay"),0],
        ["mypage","user",t("myAttendance"),0],
        ...(featureOn("quiz")?[["quiz","sparkle",t("quizTab"),quizForToday("staff")&&!myQuizReply(quizForToday("staff").id)?1:0]]:[]),
        ...(featureOn("bus")?[["bus","bus",t("busTimes"),0]]:[]),
        ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[])]},
      {key:"secProgram", head:t("secProgram"), items:[
        ["today","calendar",t("todayProgram"),0],
        ["week","calendar",t("program"),0],
        ["bookings","ticket",t("bookings"),0]]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["chat","chat",t("chatManager"),un],
        ...(featureOn("gallery")?[["gallery","sparkle",t("galleryTab"),0]]:[]),
        ["teaminfo","users",t("teamPage"),0]]}
    ];
  }
  const un=unreadFor("manager");
  const newReq=S.requests.filter(r=>r.status==="new").length;
  return [
    {key:"secManage", head:t("secManage"), items:[
      ["dash","grid",t("dashboard"),0],
      ["program","calendar",t("manage"),0],
      ["dayplan","clipboard",t("dayPlan"),0],
      ["req","clipboard",t("reqTab"),0],
      ["assign","check",t("assignCenter"),0],
      ["quiz","sparkle",t("quizCenter"),0],
      ["gallery","sparkle",t("galleryTab"),0],
      ["hotelinfo","pin",t("hotelInfoTab"),0],
      ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[]),
      ["qr","sparkle",t("qrTab"),0]]},
    {key:"secGuests", head:t("secGuests"), items:[
      ["guests","chat",t("guestsTab"),unreadGuests()+newReq],
      ["team","users",t("teamTab"),unreadTeam()+teamReqCount()]]},
    {key:"secSettings", head:t("secSettings"), items:[
      ["settings","palette",t("settingsHub"),0]]}
  ];
}
/* ===== MENU BUILDER =====
   The manager can rename, reorder, hide and add items per role. Stored in
   settings.menu so it syncs to every device. */
function menuConf(role){
  const m=(S.settings && S.settings.menu) || {};
  return m[role] || {order:[], hidden:[], names:{}, custom:[]};
}
function customPages(role){ return (menuConf(role).custom||[]); }
function applyMenuConf(role, groups){
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{}, order=conf.order||[];
  // rename + hide
  const gnames=conf.gnames||{};
  let out=groups.map(g=>({key:g.key, head:(g.key&&gnames[g.key])||g.head, items:g.items
    .filter(it=>!hidden.includes(it[0]))
    .map(it=>[it[0], it[1], names[it[0]]||it[2], it[3]])}));
  // the manager's own pages go into the first section
  const extra=customPages(role).map(p=>[ "cp:"+p.id, p.icon||"pin", p.title, 0 ]);
  if(extra.length && out.length) out[0]={...out[0], items:out[0].items.concat(extra)};
  // a section whose title she blanked out simply loses its heading
  // custom order inside each section
  if(order.length){
    out=out.map(g=>({...g, items:g.items.slice().sort((a,b)=>{
      const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
      if(ia<0&&ib<0) return 0;
      if(ia<0) return 1;
      if(ib<0) return -1;
      return ia-ib;
    })}));
  }
  return out.filter(g=>g.items.length);
}
function navGroups(role){
  const groups=applyMenuConf(role, navGroupsBase(role));
  if(role!=="guest") return groups;
  const wanted=["home","program","chat","teaminfo","stay","tickets","social"];
  const all=groups.flatMap(g=>g.items), byId=new Map(all.map(it=>[it[0],it]));
  // Re-add required guest destinations if an old Menu Builder configuration hid them.
  const base=navGroupsBase("guest").flatMap(g=>g.items);
  base.forEach(it=>{ if(!byId.has(it[0])) byId.set(it[0],it); });
  const primary=wanted.slice(0,6).map(id=>byId.get(id)).filter(Boolean);
  const social=byId.get("social");
  return [{key:"secProgram",head:t("secProgram"),items:primary}, ...(social?[{key:"secConnect",head:t("secConnect"),items:[social]}]:[])];
}
function navItems(role){ return navGroups(role).flatMap(g=>g.items); }
function topBar(title,sub){
  const role=S.session?S.session.role:"guest";
  const anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow">
      <button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button>
    </div>
  </div>
  <div class="who whobar"><h2>${esc(title)}</h2><p>${esc(sub||"")}</p></div>`;
}
function hubBack(){
  // shown on Settings sub-pages so the manager can go back to the hub
  if(S.session && S.session.role==="manager")
    return `<button class="crumb" id="crumb-hub">${ic("back",15)} ${t("settingsHub")}</button>`;
  return "";
}
/* Which menu sections are expanded — defaults to the one you are currently in. */
function drawerOpenSection(i, hasCurrent){
  if(!S.drawerOpen) S.drawerOpen={};
  if(S.drawerOpen[i]===undefined) return hasCurrent;
  return !!S.drawerOpen[i];
}
function openMenuDrawer(){
  askNotifPermission();
  const role=S.session?S.session.role:"guest";
  const wrap=document.createElement("div"); wrap.className="drawer-bg";
  wrap.innerHTML=`<div class="drawer">
    <div class="dr-head">
      <div class="mono serif sm">${esc((S.settings.name||"E").trim().charAt(0).toUpperCase())}</div>
      <div><h3>${esc(S.settings.name)}</h3><div class="dr-person"><p>${esc(S.session?S.session.name:"")}</p>${role==="guest"?guestWeatherChip():""}</div></div>
    </div>
    <div class="dr-items">
      ${navGroups(role).map((g,gi)=>{
        const hasCurrent=g.items.some(it=>it[0]===S.tab);
        const dots=g.items.reduce((n,it)=>n+(it[3]||0),0);
        const open=drawerOpenSection(gi, hasCurrent);
        return `
        <button class="dr-sec dr-sech ${open?"open":""}" data-drsec="${gi}">
          <span>${esc(g.head)}</span>
          ${dots?`<span class="badge">${dots}</span>`:""}
          <span class="dr-caret">${ic("back",14)}</span>
        </button>
        <div class="dr-group ${open?"open":""}">
          ${g.items.map(([id,icn,lb,dot])=>`<button class="dr-it ${S.tab===id?"on":""}" data-drtab="${id}">
            <span class="dr-ic">${ic(icn,19)}</span><span class="dr-lb">${lb}</span>${dot?`<span class="badge">${dot}</span>`:""}
          </button>`).join("")}
        </div>`;
      }).join("")}
    </div>
    <div class="dr-foot">
      <button class="iconbtn" id="dr-lang" aria-label="${t("language")}">${ic("globe",19)}</button>
      <button class="iconbtn" id="dr-theme" aria-label="theme">${ic(S.theme==="light"?"moon":"sun",19)}</button>
      <button class="iconbtn ${notifSoundOn()?"on-notif":""}" id="dr-notif" aria-label="${t("notifSound")}">${ic(notifSoundOn()?"bell":"belloff",19)}</button>
      <button class="dr-out" id="dr-out">${ic("power",16)} ${t("logout")}</button>
    </div>
    <div class="dr-build">${esc(APP_BUILD)}</div>
  </div>`;
  document.body.appendChild(wrap);
  requestAnimationFrame(()=>wrap.classList.add("open"));
  const close=(cb)=>{ wrap.classList.remove("open"); setTimeout(()=>{ wrap.remove(); if(cb) cb(); },240); };
  wrap.onclick=e=>{ if(e.target===wrap) close(); };
  wrap.querySelectorAll("[data-drsec]").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.drsec;
    if(!S.drawerOpen) S.drawerOpen={};
    const groups=navGroups(S.session?S.session.role:"guest");
    const hasCur=(groups[i]&&groups[i].items||[]).some(it=>it[0]===S.tab);
    S.drawerOpen[i]=!drawerOpenSection(i,hasCur);
    wrap.remove(); openMenuDrawer();
  });
  wrap.querySelectorAll("[data-drtab]").forEach(b=>b.onclick=()=>{
    close(()=>{ S.tab=b.dataset.drtab; S.chatRoom=null; render(); });
  });
  wrap.querySelector("#dr-lang").onclick=()=>close(openLangModal);
  wrap.querySelector("#dr-theme").onclick=()=>close(()=>setTheme(S.theme==="light"?"dark":"light"));
  wrap.querySelector("#dr-notif").onclick=()=>{
    const turningOn = !notifSoundOn();
    localStorage.setItem("ent_notif", turningOn ? "on" : "off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    close(()=>render());
  };
  wrap.querySelector("#dr-out").onclick=()=>close(()=>{S.session=null;S.chatRoom=null;loginMode="guest";guestMode="new";resetWiz();persist();render();});
}
function heroCard(a){
  if(!a) return "";
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken);
  return `<div class="hero" data-open="${a.id}">
    <img src="${esc(a.image||IMG.show)}" alt="">
    <div class="veil"></div>
    <div class="tag">${ic("sparkle",13)} ${t("highlight")}</div>
    <div class="body">
      <h3>${esc(a.name)}</h3>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span>${a.capacity?`<span>${mi("users")}${left} ${t("seatsLeft")}</span>`:""}</div>
      <div class="desc">${esc(a.desc)}</div>
    </div>
  </div>`;
}
/* Today's highlights, swiped sideways. One card behaves exactly as before, so
   a day with a single highlight looks the way it always did. */
function heroCarousel(list){
  list=(list||[]).filter(Boolean).slice(0,5);
  if(!list.length) return "";
  if(list.length===1) return heroCard(list[0]);
  return `<div class="hero-wrap">
    <div class="hero-rail" id="hero-rail">${list.map(a=>heroCard(a)).join("")}</div>
    <div class="hero-dots" id="hero-dots">${list.map((a,i)=>
      `<i class="${i===0?"on":""}" data-herodot="${i}"></i>`).join("")}</div>
  </div>`;
}
function activityCard(a,{showBook=true,showFav=true,manager=false,staff=false}={}){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id);
  const fav=S.favorites.includes(a.id);
  let side="";
  if(manager){
    side=`<button class="btn sm ghost" data-edit="${a.id}">${ic("pen",15)}</button><span class="seats">${taken}/${a.capacity}</span>`;
  } else if(staff){
    side=`${canSeeGuests(a)?`<button class="btn sm ghost" data-att="${a.id}">${ic("check",15)}</button>`:""}<span class="pill">${bookingsFor(a.id).length} ${t("guests")}</span>`;
  } else if(showBook){
    /* Once today's activity has finished (or the day has passed) it can no longer
       be booked — the guest sees that straight away instead of after tapping. */
    const over = isToday(a.day) && activityStatus(a)==="done";
    const running = isToday(a.day) && activityStatus(a)==="live";
    if(over){
      side = mine
        ? `<span class="chip done">${t("wasBooked")}</span>`
        : `<span class="chip done">${t("finishedChip")}</span>`;
    } else {
      side = mine
        ? `<span class="chip ${mine.status==="booked"?"ok":""}">${mine.status==="booked"?t("booked"):t("onWaitlist")}</span>`
        : full ? `<span class="chip full">${t("full")}</span>`
        : `<button class="btn sm" data-book="${a.id}">${running?t("bookNowLive"):t("book")}</button>`;
      side += `<span class="seats">${unlimited||full?"":left+" "+t("seatsLeft")}</span>`;
    }
  }
  // the coloured ring is drawn around the guest's own booked activity
  const ringCls = (mine && isToday(a.day)) ? (" "+statusRing(a)) : "";
  const overNow = isToday(a.day) && activityStatus(a)==="done";
  const guestCard=!manager&&!staff;
  return `<div class="card act${guestCard?" guest-act":""}${ringCls}${overNow?" is-over":""}" ${manager||staff||overNow?"":`data-open="${a.id}"`}>
    <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" loading="lazy" ${guestCard?"":`data-pvsingle="${esc(a.image||IMG.show)}"` }>
    <div class="mid">
      <span class="catbadge">${catLabel(a.category)}</span>
      <h4>${statusDot(a)}${esc(a.name)}</h4>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div>
      ${guestCard&&a.desc?`<p class="guest-act-desc">${esc(a.desc)}</p>`:""}
      ${mine&&isToday(a.day)?`<div class="guest-status-line">${statusPill(a)}</div>`:""}
    </div>
    <div class="side">
      ${showFav&&!manager&&!staff?`<button class="fav" data-fav="${a.id}">${fav?`<span class="hf">${ic("heart",19)}</span>`:ic("heart",19)}</button>`:""}
      ${side}
      ${guestCard&&!overNow?`<span class="guest-detail-arrow">${ic("back",15)}</span>`:""}
    </div>
  </div>`;
}
function dayTabs(){
  return `<div class="daytabs">${t("daysShort").map((d,i)=>
    `<button data-day="${i}" class="${S.day===i?"on":""}">${d}</button>`).join("")}</div>`;
}
function subTabs(group,items){
  if(PAGE_SECTIONS[group]){
    const ord=pageOrder(group);
    items=items.filter(it=>ord.includes(it[0]))
               .sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
    if(!items.some(it=>it[0]===S.sub[group]) && items.length) S.sub[group]=items[0][0];
  }
  return `<div class="pills">${items.map(([id,lb])=>
    `<button data-sub="${group}:${id}" class="${S.sub[group]===id?"on":""}">${lb}</button>`).join("")}</div>`;
}
function listByCat(acts,opts){
  if(!acts.length) return `<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return CAT_ORDER.filter(c=>acts.some(a=>a.category===c)).map(c=>`
    <div class="sec"><h3>${catLabel(c)}</h3>
      ${acts.filter(a=>a.category===c).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a,opts)).join("")}
    </div>`).join("");
}
function operationCard(op){
  const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id);
  const img=opImage(op.id);
  return `<button class="opcard" data-op="${op.id}">
    <img src="${esc(img)}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h3>${esc(opLabel(op.id))}</h3><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",18)}</span>
  </button>`;
}
function categoryCard(cat){
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===cat);
  return `<button class="catcard ${acts.length?"":"empty-cat"}" data-cat="${cat}">
    <img src="${esc(catImage(cat))}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h4>${esc(catLabel(cat))}</h4><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",16)}</span>
  </button>`;
}
function browseView(title){
  // level 1: operations
  if(!S.op){
    let mineBanner="";
    if(S.session && S.session.role==="staff"){
      const mine=S.activities.filter(a=>a.day===S.day && canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
      if(mine.length) mineBanner=`<div class="sec"><h3>${ic("clipboard",18)} ${t("myActs")}</h3>
        <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
        ${mine.map(a=>activityCard(a,{staff:true,showBook:false,showFav:false})).join("")}</div>`;
    }
    const dp=dayPlanFor(S.day);
    const themeBanner=dp&&dp.theme?`<div class="theme-banner"><span class="tb-l">${t("restaurantTheme")}</span><b class="serif">${esc(dp.theme)}</b></div>`:"";
    return `<div class="screen fadein">${topBar(title,t("days")[S.day])}${dayTabs()}
      ${themeBanner}
      ${mineBanner}
      <div class="opgrid">${OPS.map(operationCard).join("")}</div></div>`;
  }
  const op=OPS.find(o=>o.id===S.op)||OPS[0];
  // Single-category operation -> show its activities directly (no middle level)
  if(op.cats.length===1){
    const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      ${acts.length?statusLegend():""}
      ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
    </div>`;
  }
  // level 2: categories inside a multi-category operation
  if(!S.cat){
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      <div class="catgrid">${op.cats.map(categoryCard).join("")}</div></div>`;
  }
  // level 3: the activities of the chosen category
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===S.cat).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  return `<div class="screen fadein">${topBar(catLabel(S.cat),opLabel(op.id))}
    <button class="crumb" id="crumb-cats">${ic("back",15)} ${esc(opLabel(op.id))}</button>
    ${dayTabs()}
    ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
  </div>`;
}
/* ================= CHAT TRANSLATION =================
   Guests write in their language, the team reads in theirs. Uses a free
   public translation service (no key needed, so it works for guests too).
   Results are remembered for the session so nothing is fetched twice. */
const TRANS_CACHE={};
const TRANS_SHOWN={};
function transKey(id,lang){ return id+"|"+lang; }
async function translateText(text, to){
  const from="auto";
  const url="https://api.mymemory.translated.net/get?q="+encodeURIComponent(text)+
    "&langpair="+encodeURIComponent(from+"|"+to);
  const res=await fetch(url);
  if(!res.ok) throw new Error("translate "+res.status);
  const data=await res.json();
  const out=data && data.responseData && data.responseData.translatedText;
  if(!out || /^please select|invalid/i.test(out)) throw new Error("no translation");
  return String(out);
}
async function translateMessage(id){
  const m=S.messages.find(x=>String(x.id)===String(id));
  if(!m) return;
  const to=S.lang||"en";
  const k=transKey(id,to);
  if(TRANS_CACHE[k]){ TRANS_SHOWN[k]=!TRANS_SHOWN[k]; render(); return; }
  TRANS_SHOWN[k]=true; TRANS_CACHE[k]="__loading__"; render();
  try{
    TRANS_CACHE[k]=await translateText(m.text, to);
  }catch(e){
    delete TRANS_CACHE[k]; delete TRANS_SHOWN[k];
    toastErr(t("translateFail"));
  }
  render();
}
function bubbleTranslation(m){
  const to=S.lang||"en";
  const k=transKey(m.id,to);
  const val=TRANS_CACHE[k];
  if(!val || !TRANS_SHOWN[k]) return "";
  if(val==="__loading__") return `<span class="tr-line loading">${t("translating")}</span>`;
  return `<span class="tr-line"><i>${t("translatedTag")}</i>${esc(val)}</span>`;
}
function threadView(room,meSide){
  const msgs=S.messages.filter(m=>m.room===room);
  const isManager=S.session && S.session.role==="manager";
  const emptyTxt = String(room).startsWith("staff:") ? t("noStaffMsg") : t("noMessages");
  return `<div class="thread">
    ${msgs.length?msgs.map(m=>{
      const mine = m.sender===meSide;
      const picking=chatSelOn(), picked=chatSelHas(m.id);
      return `<div class="bubwrap ${mine?"me":"them"}${picking?" picking":""}${picked?" picked":""}"
        ${picking?`data-msgpick="${m.id}"`:""}>
        ${picking?`<span class="pick-dot">${picked?ic("check",13):""}</span>`:""}
        <div class="bub ${mine?"me":"them"}">${esc(m.text)}${bubbleTranslation(m)}<span class="tm">${mine?"":esc(m.sender_name)+" · "}${fmtTime(m.created_at)}</span></div>
        ${mine?"":`<button class="tr-btn" data-translate="${m.id}">${ic("sparkle",12)} ${TRANS_SHOWN[transKey(m.id,S.lang||"en")]?t("showOriginal"):t("translateBtn")}</button>`}
        ${isManager&&!chatSelOn()?`<div class="bub-tools">
          <button class="bubtool" data-msgedit="${m.id}" aria-label="${t("editMsg")}">${ic("pen",14)}</button>
          <button class="bubtool" data-msgdel="${m.id}" aria-label="${t("deleteMsg")}">${ic("exit",14)}</button>
        </div>`:""}
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("chat",30)}</div>${emptyTxt}</div>`}
  </div>
  <div class="chatbar">
    <input id="chat-in" placeholder="${t("typeMessage")}" autocomplete="off">
    <button id="chat-send" aria-label="${t("send")}">${ic("send",17)}</button>
  </div>`;
}
/* ---------------- guest ---------------- */
function guestWeatherChip(){
  if(!featureOn("weather")) return "";
  const w=S.weather;
  if(w && !w.error && w.cur){
    const c=w.cur;
    return `<button class="guest-weather" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
      <span class="gw-icon">${ic(wmoIcon(c.weather_code),18)}</span>
      <span class="gw-temp">${Math.round(c.temperature_2m)}°</span>
      <span class="gw-label">${esc(wmoLabel(c.weather_code))}</span>
    </button>`;
  }
  return `<button class="guest-weather loading" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
    <span class="gw-icon">${ic("sun",18)}</span><span class="gw-label">${esc(t("weatherTab"))}</span>
  </button>`;
}
function guestHomeTopBar(g,todayIdx){
  const role="guest", anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top guest-top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow"><button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button></div>
  </div>
  <div class="guest-welcome-head">
    <div><h1>${esc(t("welcome"))}, ${esc(g.name)}</h1><p>${esc(t("room"))} ${esc(g.room)} · ${esc(t("days")[todayIdx])}</p></div>
    ${guestWeatherChip()}
  </div>`;
}
function guestQuickActions(){
  const items=[];
  if(featureOn("hotelinfo")) items.push(["hotelinfo","pin",t("hotelInfoTab")]);
  if(featureOn("gallery")) items.push(["gallery","sparkle",t("galleryTab")]);
  if(featureOn("quiz")) items.push(["quiz","sparkle",t("quizTab")]);
  if(!items.length) return "";
  return `<div class="guest-quick-actions">${items.map(([tab,icon,label])=>
    `<button data-tab="${tab}" class="gqa"><span class="gqa-ic">${ic(icon,22)}</span><span>${esc(label)}</span><i>${ic("back",14)}</i></button>`
  ).join("")}</div>`;
}
function openGuestActivityDetail(a){
  if(!a) return;
  const unlimited=!(+a.capacity), taken=seatsTaken(a.id), left=Math.max(0,(+a.capacity||0)-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id), status=isToday(a.day)?activityStatus(a):"";
  const wrap=baseModal(`<div class="guest-detail">
    <div class="gd-photo"><img src="${esc(a.image||IMG.show)}" alt=""><span class="gd-cat">${esc(catLabel(normCat(a)))}</span></div>
    <div class="gd-copy">
      <h3>${esc(a.name)}</h3>
      <div class="gd-meta"><span>${mi("clock")}${esc(a.time)}${a.end_time?" – "+esc(a.end_time):""}</span><span>${mi("pin")}${esc(a.location||"")}</span></div>
      ${a.desc?`<p class="gd-desc">${esc(a.desc)}</p>`:""}
      <div class="gd-facts">
        ${!unlimited?`<span>${ic("users",16)} <b>${full?t("full"):left+" "+t("seatsLeft")}</b></span>`:""}
        ${status?`<span>${statusDot(a)} <b>${status==="live"?t("st_live"):status==="done"?t("st_done"):t("st_todo")}</b></span>`:""}
      </div>
    </div>
    ${mine?`<div class="gd-booked">${ic("check",17)} ${mine.status==="booked"?t("booked"):t("onWaitlist")}</div>`:
      `<button class="btn guest-book-now" id="gd-book">${full?t("waitlist"):t("book")}</button>`}
    <button class="btn ghost" id="gd-close">${t("close")}</button>
  </div>`);
  wrap.querySelector("#gd-close").onclick=()=>wrap.remove();
  const book=wrap.querySelector("#gd-book");
  if(book) book.onclick=()=>{wrap.remove();openBookModal(a);};
}
function guestView(){
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  const g=S.session;
  const todayIdx=todayIndex();
  if(S.tab==="home"){
    const todays=S.activities.filter(a=>a.day===todayIdx);
    const hl=todays.find(a=>a.highlight)||todays[0];
    const wm=(S.settings.welcomeMsg||"").trim();
    return `<div class="screen fadein">
      ${guestHomeTopBar(g,todayIdx)}
      ${stayCard((S.accounts||[]).find(a=>a.id===g.accountId)||(S.accounts||[]).find(a=>String(a.room)===String(g.room)))}
      ${wm?`<div class="card guest-welcome-msg">${esc(wm)}</div>`:""}
      ${guestQuickActions()}
      ${heroCarousel([hl].concat(todays.filter(a=>a!==hl && a.highlight)))}
      <div class="quickrow">
        <button id="btn-req-song"><span>${ic("music",22)}</span>${t("songRequest")}</button>
        <button id="btn-req-bday"><span>${ic("gift",22)}</span>${t("birthdayRequest")}</button>
      </div>
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${todays.filter(a=>a!==hl).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a)).join("")||`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
      </div>
      ${reviewDue(g)?reviewBlock():""}
      ${socialBlock()}
    </div>`;
  }
  if(S.tab==="program") return browseView(menuLabel("menuProgram",t("program")));
  if(S.tab==="social") return socialPageView();
  if(S.tab==="teaminfo") return teamInfoView();
  if(S.tab==="tickets") return guestTicketsView();
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chat"),accountName(g.room))}
      ${threadView(g.room,"guest")}
    </div>`;
  }
  const mine=S.bookings.filter(b=>b.room===g.room);
  const orders=myOrders();
  const reqs=myRequestsList();
  const favActs=S.activities.filter(a=>S.favorites.includes(a.id));
  return `<div class="screen fadein">
    ${topBar(t("myStay"),g.name)}
    <div class="card profcard">
      <div class="pf-ava">${ic("user",26)}</div>
      <div style="min-width:0">
        <h4>${esc(g.name)}</h4>
        <p class="mini">${t("room")} ${esc(g.room)}${g.nationality?` · ${esc(g.nationality)}`:""}</p>
        <p class="mini">${esc(g.arrival||"")} → ${esc(g.departure||"")}</p>
      </div>
      <button class="btn sm ghost" id="btn-chpass" style="flex:none">${ic("key",15)} ${t("changePass")}</button>
    </div>
    <div class="sec"><h3>${t("myBookings")} <span class="count">${mine.length}</span></h3>
      ${mine.length?mine.map(b=>{
        const a=S.activities.find(x=>x.id===b.activity_id); if(!a) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" data-pvsingle="${esc(a.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[a.day]}</span><h4>${esc(a.name)}</h4>
            <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div></div>
          <div class="side">
            <span class="chip ${b.status==="booked"?"ok":""}">${b.status==="booked"?t("booked"):t("onWaitlist")}</span>
            <button class="btn sm warn" data-cancel="${b.id}">${ic("close",14)}</button>
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("noBookings")}</div>`}
    </div>
    <div class="sec"><h3>${t("myTickets")} <span class="count">${orders.length}</span></h3>
      ${orders.length?orders.map(o=>{
        const tk=S.tickets.find(x=>x.id===o.ticket_id); if(!tk) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span><h4>${esc(tk.name)}</h4>
            <div class="meta"><span>${mi("ticket")}×${o.qty}</span><span>${esc(tk.price||"")}</span>${o.collect_from?`<span>${mi("user")}${esc(o.collect_from)}</span>`:""}</div></div>
          <div class="side">
            <span class="chip ${o.status==="paid"?"ok":"res"}">${o.status==="paid"?t("paid"):t("reserved")}</span>
            ${o.status==="paid"?"":`<button class="btn sm warn" data-cancelorder="${o.id}">${ic("close",14)}</button>`}
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
    </div>
    ${reqs.length?`<div class="sec"><h3>${t("myRequests")} <span class="count">${reqs.length}</span></h3>
      <div class="card">${reqs.map(r=>`<div class="booking-line">
        <span>${ic(r.type==="song"?"music":"gift",15)} ${esc(r.detail)}${r.date?` · ${esc(r.date)}`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <span class="chip ${r.status==="done"?"ok":"res"}">${r.status==="done"?t("done"):t("statusNew")}</span>
          ${r.status==="done"?"":`<button class="btn sm warn" data-delreq="${r.id}">${ic("close",14)}</button>`}
        </span></div>`).join("")}</div>
    </div>`:""}
    <div class="sec"><h3>${t("favorites")} <span class="count">${favActs.length}</span></h3>
      ${favActs.length?favActs.map(a=>activityCard(a)).join(""):`<div class="empty"><div class="big">${ic("heart",30)}</div>${t("noFavs")}</div>`}
    </div>
    ${reviewDue(g)?reviewBlock():""}
  </div>`;
}
function socialPageView(){
  const st=S.settings;
  const socials=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube]].filter(x=>x[1]);
  const reviews=[["Google",st.google],["Facebook",st.facebook],["Tripadvisor",st.tripadvisor],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  const wa=waLink();
  return `<div class="screen fadein">
    ${topBar(t("socialPage"),S.settings.name)}
    ${S.session.role==="guest"?`<div class="card ratecard">
      <b>${t("howWasIt")}</b>
      <div class="rate-stars">${[1,2,3,4,5].map(r=>`<button class="rs" data-guestrate="${r}" aria-label="${r}">${ic("star",26)}</button>`).join("")}</div>
    </div>`:""}
    ${wa?`<a class="wa-cta" href="${esc(wa)}" target="_blank" rel="noopener">${brandIc("WhatsApp")} ${t("contactWa")}</a>`:""}
    ${socials.length?`<div class="sec"><h3>${t("followUs")}</h3>
      ${socials.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic">${brandIc(n)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
    ${reviews.length?`<div class="sec"><h3>${t("leaveReview")}</h3>
      ${reviews.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic star">${ic("star",17)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
  </div>`;
}
function teamInfoView(){
  /* one single team list — the real accounts the manager edits, so what she
     changes on a person is exactly what guests see. */
  const list=(S.users||[])
    .filter(u=>(u.role==="staff"||u.role==="manager") && u.active!==false)
    .map(u=>({...u, name:u.display_name||u.username}))
    .sort((a,b)=>{
      const am=/manager/i.test(a.position||"")?0:1, bm=/manager/i.test(b.position||"")?0:1;
      return am-bm || (a.number||99)-(b.number||99) || a.id-b.id;
    });
  const entCount=list.filter(p=>!/manager/i.test(p.position||"")).length;
  return `<div class="screen fadein">
    ${topBar(t("teamPage"),S.settings.name)}
    <div class="teamcount card"><b class="serif">${entCount}</b><span>${t("ourTeam")} · ${entCount} ${t("entertainersWord")}</span></div>
    ${list.length?list.map(p=>teamCard(p)).join(""):`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
  </div>`;
}
/* match a Meet-the-Team card to a real team account so it can open the profile */
function userForProfileName(name){
  const nm=String(name||"").trim().toLowerCase();
  if(!nm) return null;
  return (S.users||[]).find(u=>String(u.display_name||u.username||"").trim().toLowerCase()===nm)||null;
}
function teamCard(p){
  const chips=x=>String(x||"").split(/[·,;\/|]+/).map(v=>v.trim()).filter(Boolean)
    .map(v=>`<span class="tchip">${esc(v)}</span>`).join("");
  const linked=userForProfileName(p.name);
  return `<div class="card team-card${linked?" tappable":""}" ${linked?`data-uview="${esc(linked.username)}"`:""}>
    <div class="tc-photo">${p.photo?`<img src="${esc(p.photo)}" alt="" loading="lazy">`:`<div class="tc-mono serif">${esc((p.name||"?").trim().charAt(0).toUpperCase())}</div>`}</div>
    <div class="tc-body">
      <h4 class="serif">${esc(p.name)}</h4>
      <p class="tc-pos">${esc(p.position||"")}</p>
      <p class="mini">${esc(p.nationality||"")}${p.nationality&&p.languages?" · ":""}${esc(p.languages||"")}</p>
      ${p.skills?`<div class="tc-chips">${chips(p.skills)}</div>`:""}
      ${p.instagram?`<a class="btn sm ghost social-a" href="${esc(p.instagram)}" target="_blank" rel="noopener">${brandIc("Instagram")} Instagram</a>`:""}
    </div>
  </div>`;
}
function guestTicketsView(){
  return `<div class="screen fadein">
    ${topBar(t("tickets"),"")}
    <p class="mini" style="margin:-6px 0 16px">${t("payNote")}</p>
    ${S.tickets.length?S.tickets.map(tk=>{
      const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
      const soldOut=left!==null&&left<=0;
      return `<div class="tk">
        <img src="${esc(tk.image||IMG.show)}" alt="" loading="lazy">
        <div class="bd">
          <h4>${esc(tk.name)}</h4>
          <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}${left!==null?` · ${left} ${t("seatsLeft")}`:""}</p>
          <p class="desc">${esc(tk.desc)}</p>
          <div class="rowend">
            <span class="price">${esc(tk.price||"")}</span>
            ${soldOut?`<span class="chip full">${t("soldOut")}</span>`:`<button class="btn sm" data-buy="${tk.id}">${t("buyTicket")}</button>`}
          </div>
        </div>
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
  </div>`;
}
function reviewBlock(){
  const st=S.settings;
  const links=[["Tripadvisor",st.tripadvisor],["Google",st.google],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("reviews")}</h3>
    <p class="mini" style="margin:4px 0 12px">${t("reviewsSub")}</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${links.map(([n,u])=>`<a class="btn sm ghost" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${ic("star",14)} ${n}</a>`).join("")}
    </div></div>`;
}
function socialBlock(){
  const st=S.settings;
  const links=[["Instagram",st.instagram],["TikTok",st.tiktok],["Facebook",st.facebook],["YouTube",st.youtube]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("followUs")}</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      ${links.map(([n,u])=>`<a class="btn sm ghost social-a" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${brandIc(n)} ${n}</a>`).join("")}
    </div></div>`;
}

/* ---------------- staff ---------------- */
function staffView(){
  const todayIdx=todayIndex();
  // My Work Day is the entertainer's home screen
  const STAFF_TABS=["workday","mypage","quiz","gallery","weather","bus","today","week","bookings","tasks","chat","feedback","teaminfo"];
  if(!S.tab || (!STAFF_TABS.includes(S.tab) && !String(S.tab).startsWith("cp:") && !String(S.tab).startsWith("emp:"))) S.tab="workday";
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="workday") return myWorkDayView();
  if(S.tab==="mypage") return myPageView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="bus") return busView();
  if(S.tab==="today"){
    const acts=S.activities.filter(a=>a.day===todayIdx);
    const hl=acts.find(a=>a.highlight);
    const mine=acts.filter(a=>canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">
      ${topBar(t("schedule"),t("days")[todayIdx]+" · "+S.session.name)}
      ${heroCard(hl)}
      ${statusLegend()}
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${listByCat(acts.filter(a=>a!==hl),{staff:true,showBook:false,showFav:false})}</div>
    </div>`;
  }
  if(S.tab==="week") return browseView(t("program"));
  if(S.tab==="tasks"){
    const me=S.session.username;
    const mine=S.tasks.filter(x=>!x.assigned_to || x.assigned_to===me);
    const rk=rankingRows();
    return `<div class="screen fadein">
      ${topBar(t("myTasks"),S.session.name)}
      ${rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("rank")}</h3><div class="card">
        ${rk.map((r,i)=>`<div class="booking-line"><span>${rankBadge(i)} ${esc(r.u.display_name||r.u.username)}${r.u.username===me?" ✦":""}</span><span class="pill">${r.points} ${t("points")}</span></div>`).join("")}
      </div></div>`:""}
      ${mine.length?`<div class="card">${mine.map(x=>taskLine(x,false)).join("")}</div>`:`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`}
      ${myActsCard()}
    </div>`;
  }
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chatManager"),S.session.name)}
      ${threadView("staff:"+S.session.username,"guest")}
    </div>`;
  }
  if(S.tab==="feedback") return staffFeedbackView();
  if(S.tab==="teaminfo") return teamInfoView();
  return bookingsView(t("guestsBooked"));
}
function taskStatusChip(x,clickAttr){
  const map={open:[t("statusNew"),"res"],accepted:[t("accepted"),"res"],still:[t("still"),"res"],done:[x.was_still?t("done")+" · "+t("late"):t("done"),"ok"],cant:[t("cantDo"),"full"]};
  const [lb,cls]=map[x.status]||map.open;
  return `<${clickAttr?"button":"span"} class="chip ${cls}" ${clickAttr?clickAttr+'="'+x.id+'"':""}>${lb}</${clickAttr?"button":"span"}>`;
}
/* ================= TASK MANAGEMENT =================
   Flow: New → Accepted → In progress → Completed → Verified.
   Old statuses (open/accepted/still/done) still work. */
const TASK_FLOW=["new","accepted","progress","completed","verified"];
const PRIORITIES=[["low","prLow"],["normal","prNormal"],["high","prHigh"],["urgent","prUrgent"]];
function taskStatus(x){
  const st=String(x.status||"new");
  if(st==="open") return "new";
  if(st==="still") return "progress";
  if(st==="done") return "completed";
  return TASK_FLOW.includes(st)?st:"new";
}
function taskStatusLabel(st){
  return {new:t("stNew"),accepted:t("stAccepted"),progress:t("stProgress"),
    completed:t("stCompleted"),verified:t("stVerified")}[st]||st;
}
function taskPriorityLabel(p){ const f=PRIORITIES.find(x=>x[0]===p); return f?t(f[1]):t("prNormal"); }
function taskIsOverdue(x){
  const st=taskStatus(x);
  if(st==="completed"||st==="verified") return false;
  if(!x.due) return false;
  const d=new Date(String(x.due).replace(" ","T"));
  return !isNaN(d.getTime()) && d.getTime() < Date.now();
}
function taskNextStatus(st){
  const i=TASK_FLOW.indexOf(st);
  return (i<0||i>=TASK_FLOW.length-1)?null:TASK_FLOW[i+1];
}
function taskActionLabel(st){
  return {new:t("acceptTask"),accepted:t("startTask"),progress:t("completeTask"),
    completed:t("verifyTask")}[st]||"";
}
function taskHistory(x){ try{ return Array.isArray(x.history)?x.history:JSON.parse(x.history||"[]"); }catch(e){ return []; } }
function taskComments(x){ try{ return Array.isArray(x.comments)?x.comments:JSON.parse(x.comments||"[]"); }catch(e){ return []; } }
async function advanceTask(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const cur=taskStatus(x), next=taskNextStatus(cur);
  if(!next) return;
  const stamp=new Date().toISOString();
  const patch={status:next};
  if(next==="accepted")  patch.accepted_at=stamp;
  if(next==="progress")  patch.started_at=stamp;
  if(next==="completed") patch.completed_at=stamp;
  if(next==="verified")  patch.verified_at=stamp;
  patch.history=taskHistory(x).concat([{at:stamp, by:S.session.name||S.session.username||"", to:next}]);
  try{ await DB.updateTask(id,patch); toastOk(t("saved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
async function addTaskComment(id, text){
  const x=S.tasks.find(y=>y.id==id); if(!x||!text) return;
  const c={at:new Date().toISOString(), by:S.session.name||S.session.username||"", text};
  try{ await DB.updateTask(id,{comments:taskComments(x).concat([c])}); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* Full task detail — everything about one task in one place */
function openTaskModal(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const st=taskStatus(x), over=taskIsOverdue(x);
  const u=S.users.find(u=>u.username===x.assigned_to);
  const hist=taskHistory(x), cmts=taskComments(x);
  const isMgr=S.session.role==="manager";
  const canAdvance = isMgr || (x.assigned_to===S.session.username) || !x.assigned_to;
  const next=taskNextStatus(st);
  const wrap=baseModal(`
    <h3>${ic(TASK_ICON[x.type]||"check",20)} ${esc(x.title)}</h3>
    <div class="tk-badges">
      <span class="tk-st s-${st}">${taskStatusLabel(st)}</span>
      <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
      ${over?`<span class="tk-over">${t("overdue")}</span>`:""}
    </div>
    ${x.desc?`<p class="mini" style="margin-top:8px">${esc(x.desc)}</p>`:""}
    <div class="tk-meta">
      ${x.assigned_to?`<span>${mi("user")}${esc((u&&u.display_name)||x.assigned_to)}</span>`:`<span>${mi("users")}${t("allTeam")}</span>`}
      ${x.location?`<span>${mi("pin")}${esc(x.location)}</span>`:""}
      ${x.due?`<span>${mi("clock")}${esc(String(x.due).replace("T"," "))}</span>`:""}
      ${x.created_by?`<span>${mi("pen")}${t("createdBy")}: ${esc(x.created_by)}</span>`:""}
    </div>
    ${x.proof_url?`<img class="tk-proof" src="${esc(x.proof_url)}" alt="">`:""}
    ${(st==="progress"||st==="completed")&&canAdvance?`
      <div class="photo-pick" style="margin-top:12px"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("taskProof")}</b><span class="mini">${t("uploadPhoto")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>`:""}
    ${next&&canAdvance?`<button class="btn" id="tk-next">${taskActionLabel(st)}</button>`:""}
    <label style="margin-top:12px">${t("taskComments")}</label>
    ${cmts.length?`<div class="card tk-cmts">${cmts.map(cm=>`<div class="tk-cm">
      <b>${esc(cm.by)}</b><span>${esc(cm.text)}</span><span class="mini">${fmtDate(cm.at)}</span></div>`).join("")}</div>`:""}
    <div class="time-row"><input id="tk-cm" placeholder="${esc(t("addComment"))}">
      <button class="btn sm" id="tk-cmadd" type="button">${ic("send",14)}</button></div>
    ${hist.length?`<label style="margin-top:12px">${t("taskHistory")}</label>
      <div class="card tk-hist">${hist.map(h=>`<div class="tk-h">
        <span>${taskStatusLabel(h.to)}</span><span class="mini">${esc(h.by)} · ${fmtDate(h.at)}</span></div>`).join("")}</div>`:""}
    <button class="btn ghost" id="tk-x" style="margin-top:12px">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  let proof=x.proof_url||"";
  wirePhotoPicker(wrap, ()=>proof, async v=>{
    proof=v; try{ await DB.updateTask(x.id,{proof_url:v}); }catch(e){}
  });
  const nx=wrap.querySelector("#tk-next");
  if(nx) nx.onclick=async ()=>{ wrap.remove(); await advanceTask(x.id); };
  const ca=wrap.querySelector("#tk-cmadd");
  if(ca) ca.onclick=async ()=>{
    const el=wrap.querySelector("#tk-cm"); const v=el?el.value.trim():"";
    if(!v) return; wrap.remove(); await addTaskComment(x.id, v);
  };
}
function taskLine(x,managerMode){
  const u=S.users.find(u=>u.username===x.assigned_to);
  const assignee = x.assigned_to ? ((u&&u.display_name)||x.assigned_to) : t("allTeam");
  const due=x.due?String(x.due).replace("T"," "):"";
  const info=`<span style="min-width:0">${ic(TASK_ICON[x.type]||"check",15)} <b>${esc(x.title)}</b>
    <br><span class="mini">${taskTypeLabel(x.type)}${x.location?` · ${mi("pin")}${esc(x.location)}`:""}</span>
    ${x.desc?`<br><span class="mini">${esc(x.desc)}</span>`:""}
    ${due?`<br><span class="mini">${mi("clock")}${esc(due)}</span>`:""}
    ${managerMode?`<br><span class="mini">${mi("user")}${esc(assignee)}</span>`:""}</span>`;
  const st2=taskStatus(x), over2=taskIsOverdue(x);
  const badges=`<br><span class="tk-inline">
    <span class="tk-st s-${st2}">${taskStatusLabel(st2)}</span>
    <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
    ${over2?`<span class="tk-over">${t("overdue")}</span>`:""}</span>`;
  if(managerMode){
    return `<div class="booking-line ${over2?"row-over":""}">${info.replace("</span>", badges+"</span>")}
      <span style="display:flex;gap:6px;align-items:center;flex:none">
        <button class="btn sm ghost" data-taskopen="${x.id}">${ic("pen",14)}</button>
        ${taskStatusChip(x,"data-taskdone")}
        <button class="btn sm warn" data-taskdel="${x.id}">${ic("close",14)}</button>
      </span></div>`;
  }
  let actions="";
  if(x.status==="open") actions=`<button class="btn sm" data-taccept="${x.id}">${t("accept")}</button>`;
  else if(x.status==="accepted"||x.status==="still"){
    actions=`<button class="btn sm" data-tsdone="${x.id}">${t("done")}</button>
      ${x.status==="accepted"?`<button class="btn sm ghost" data-tstill="${x.id}">${t("still")}</button>`:""}
      <button class="btn sm warn" data-tcant="${x.id}">${t("cantDo")}</button>`;
  } else actions=taskStatusChip(x,null);
  return `<div class="booking-line">${info}
    <span style="display:flex;gap:6px;align-items:center;flex:none;flex-wrap:wrap;justify-content:flex-end;max-width:46%">${actions}</span></div>`;
}
function myActsCard(){
  const mine=S.activities.filter(a=>canSeeGuests(a));
  if(!mine.length) return "";
  const byDay={};
  mine.forEach(a=>{ (byDay[a.day]=byDay[a.day]||[]).push(a); });
  const order=Object.keys(byDay).map(Number).sort((a,b)=>a-b);
  return `<div class="sec"><h3>${ic("calendar",18)} ${t("myActs")}</h3>
    <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
    <div class="card">${order.map(d=>`
      <div class="booking-line"><span style="min-width:0"><b>${t("daysShort")[d]}</b>
        ${byDay[d].sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>`<br><span class="mini">${mi("clock")}${esc(a.time)} · ${esc(a.name)}</span>`).join("")}
      </span></div>`).join("")}</div>
  </div>`;
}
function busMinutes(tm){
  const m=String(tm||"").match(/(\d{1,2})[:.\s](\d{2})/);
  return m?(+m[1])*60+(+m[2]):-1;
}
/* next upcoming bus (today) among a list of bus rows */
function nextBusId(list){
  const now=new Date(); const cur=now.getHours()*60+now.getMinutes();
  let best=null, bestMin=Infinity;
  list.forEach(b=>{ const mins=busMinutes(b.time); if(mins>=cur && mins<bestMin){ bestMin=mins; best=b.id; } });
  return best;
}
function busColumn(dir, iconRot){
  const list=(S.buses||[]).filter(b=>b.direction===dir)
    .sort((a,b)=>busMinutes(a.time)-busMinutes(b.time));
  const nxt=nextBusId(list);
  const isManager=S.session.role==="manager";
  return `<div class="bus-col">
    <div class="bus-col-head"><span class="bus-ic" style="transform:scaleX(${iconRot})">${ic("bus",20)}</span>
      <b>${t(dir==="toHotel"?"busToHotel":"busToHouse")}</b></div>
    ${list.length?`<div class="bus-rows">${list.map(b=>{
      const isNext=b.id===nxt;
      return `<div class="bus-row ${isNext?"next":""}" ${isManager?`data-busedit="${b.id}"`:""}>
        <span class="bus-time">${esc(b.time)}</span>
        <span class="bus-mid">${b.note?`<span class="bus-note">${esc(b.note)}</span>`:""}${isNext?`<span class="bus-next">${t("busNextHint")}</span>`:""}</span>
        ${isManager?`<span class="bus-go">${ic("pen",15)}</span>`:""}
      </div>`;
    }).join("")}</div>`:`<p class="mini bus-empty">—</p>`}
    ${isManager?`<button class="btn sm ghost bus-add" data-busadd="${dir}">${ic("plus",15)} ${t("addBus")}</button>`:""}
  </div>`;
}
/* ================= EMPLOYEE PROFILE ================= */
/* profile pictures: the main photo first, then any extra ones */
function empPics(u){
  let extra=[];
  try{ extra=Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]"); }catch(e){ extra=[]; }
  return [u.photo].concat(extra).filter(Boolean);
}
function employeeRecord(u){
  const mk=currentAttMonth();
  const att=attTotals(u,mk);
  const myTasks=(S.tasks||[]).filter(x=>x.assigned_to===u.username);
  const doneT=myTasks.filter(x=>["completed","verified","done"].includes(String(x.status))).length;
  const lateT=myTasks.filter(x=>taskIsOverdue(x)).length;
  const acts=(S.activities||[]).filter(a=>String(a.entertainer||"").toLowerCase()===String(u.username||"").toLowerCase());
  const fb=(S.feedback||[]).filter(f=>String(f.by_user||"")===u.username);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  const points=doneT*10 - lateT*5 + Math.round(avg*4);
  return {u, att, myTasks, doneT, lateT, acts, fb, avg, points,
    onTime: myTasks.length?Math.round((myTasks.length-lateT)/myTasks.length*100):100};
}
function employeeRank(u){
  const rows=(S.users||[]).filter(x=>x.role==="staff").map(x=>employeeRecord(x))
    .sort((a,b)=>b.points-a.points);
  const i=rows.findIndex(r=>r.u.username===u.username);
  return {pos:i+1, total:rows.length};
}
function employeeView(username){
  const u=(S.users||[]).find(x=>x.username===username);
  if(!u) return `<div class="screen fadein">${topBar(t("employeeProfile"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=employeeRecord(u), rank=employeeRank(u);
  const isMgr=S.session.role==="manager";
  const isSelf=S.session.role==="staff" && S.session.username===u.username;
  const full=isMgr||isSelf;                 // guests see the public part only
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  const line=(lb,v)=>v?`<div class="ep-row"><span class="mini">${lb}</span><b>${esc(v)}</b></div>`:"";
  return `<div class="screen fadein">
    ${topBar(esc(u.display_name||u.username), u.number?("#"+u.number):"")}
    <button class="crumb" id="crumb-team">${ic("back",15)} ${isMgr?t("teamAccounts"):t("teamPage")}</button>
    <div class="card g3-head">
      <div class="g3-av${u.photo?" haspic":""}" ${u.photo?`data-pv="emp|0"`:""}>${u.photo?`<img src="${esc(u.photo)}" alt="">`:esc(String(u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${esc(u.position||roleForNumber(u.number||0))}${u.number?" · #"+u.number:""}</span>
        <span class="mini">${u.active===false?t("inactiveAcc"):t("activeAcc")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span>
      </div>
    </div>
    ${full?`<div class="g3-stats">
      ${stat(r.att.P, t("workDays"))}
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.doneT, t("tasksDone"))}
      ${stat(r.onTime+"%", t("onTime"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
      ${stat(r.points, t("pointsLbl"))}
      ${stat(rank.pos?("#"+rank.pos):"—", t("rankLbl"))}
      ${stat(r.att.A, t("attTotalsA"))}
    </div>`:`<div class="g3-stats">
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
    </div>`}
    ${empPics(u).length?`<div class="sec">${photoStrip(empPics(u),"emp")}</div>`:""}
    <div class="sec"><h3>${ic("user",17)} ${t("employeeProfile")}</h3>
      <div class="card ep-card">
        ${full?line(t("employeeId"), u.employee_id):""}
        ${line(t("positionLbl2"), u.position)}
        ${full?line(t("user"), u.username):""}
        ${full?line(t("phoneLbl2"), u.phone):""}
        ${full?line(t("whatsappLbl2"), u.whatsapp):""}
        ${line(t("instagramLbl2"), u.instagram)}
        ${line(t("languagesLbl"), u.languages)}
        ${line(t("skills"), u.skills)}
        ${full?line(t("hireDate"), u.hire_date):""}
        ${line(t("nationality"), u.nationality)}
      </div>
    </div>
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("assignedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}${a.location?" · "+esc(a.location):""}</span></div>`).join("")}</div></div>`:""}
    ${full&&r.myTasks.length?`<div class="sec"><h3>${ic("check",17)} ${t("tasks")}</h3>
      <div class="card">${r.myTasks.slice(0,8).map(x=>`<div class="g3-row" data-taskopen="${x.id}">
        <b>${esc(x.title)}</b><span class="mini">${taskStatusLabel(taskStatus(x))}${taskIsOverdue(x)?" · "+t("overdue"):""}</span></div>`).join("")}</div></div>`:""}
    ${isMgr?`<div class="sec">
      <button class="btn" data-uedit="${u.id}">${ic("pen",16)} ${t("editUser")}</button>
      <button class="btn ghost" data-ususpend="${u.id}">${ic(u.active===false?"bell":"belloff",16)} ${u.active===false?t("activate"):t("suspend")}</button>
    </div>`
    :`<div class="sec">
      <p class="mini" style="margin-bottom:8px">${t("profileReadOnly")}</p>
      ${S.session.role==="staff"&&S.session.username===u.username
        ? `<button class="btn ghost" id="prof-req">${ic("chat",15)} ${t("requestChange")}</button>` : ""}
    </div>`}
  </div>`;
}
/* ================= GUEST CRM (360° profile) ================= */
/* How the guest's holiday is going: which day they are on and what is left. */
function stayProgress(acc){
  if(!acc || !acc.arrival || !acc.departure) return null;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  if(isNaN(a)||isNaN(d)) return null;
  const now=hotelNow(); now.setHours(0,0,0,0);
  const total=Math.max(1, Math.round((d-a)/864e5));
  const done=Math.max(0, Math.min(total, Math.round((now-a)/864e5)));
  const left=Math.max(0, total-done);
  const dayNo=Math.max(1, Math.min(total+1, done+1));
  return {total, done, left, dayNo, arrival:acc.arrival, departure:acc.departure,
          pct: Math.round((done/total)*100), lastDay:left===0, firstDay:done===0};
}
function stayCard(acc){
  const p=stayProgress(acc);
  if(!p) return "";
  const fmt=x=>{ const d=new Date(x+"T12:00:00");
    return isNaN(d)?x:d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"}); };
  const headline = p.lastDay ? t("stayLastDay")
    : p.firstDay ? t("stayWelcome")
    : t("stayDayOf").replace("{n}", p.dayNo).replace("{t}", p.total);
  return `<div class="card staycard">
    <div class="sc-top">
      <span class="sc-day"><b>${p.dayNo}</b><span class="mini">${t("dayWord")}</span></span>
      <span class="sc-mid"><b>${esc(headline)}</b>
        <span class="mini">${fmt(p.arrival)} → ${fmt(p.departure)} · ${p.total} ${t("nightsWord")}</span></span>
    </div>
    <div class="sc-bar"><span style="width:${Math.max(3,Math.min(100,p.pct))}%"></span></div>
    <div class="sc-foot">
      <span>${p.left} ${t("nightsLeft")}</span>
      <span>${p.done}/${p.total}</span>
    </div>
  </div>`;
}
function guestStayNights(acc){
  if(!acc||!acc.arrival||!acc.departure) return 0;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  const n=Math.round((d-a)/864e5);
  return isNaN(n)?0:Math.max(0,n);
}
function guestDaysInApp(acc){
  if(!acc||!acc.created_at) return 0;
  return Math.max(1, Math.round((Date.now()-new Date(acc.created_at).getTime())/864e5));
}
function guestRecord(acc){
  const room=String(acc.room);
  const bookings=(S.bookings||[]).filter(b=>String(b.room)===room);
  const actIds=bookings.map(b=>b.activity_id);
  const acts=(S.activities||[]).filter(a=>actIds.includes(a.id));
  const orders=(S.orders||[]).filter(o=>String(o.room)===room);
  const reqs=(S.requests||[]).filter(r=>String(r.room)===room);
  const fb=(S.feedback||[]).filter(f=>String(f.room)===room);
  const msgs=(S.messages||[]).filter(m=>String(m.room)===room);
  const quiz=(S.quizReplies||[]).filter(q=>String(q.who)===room);
  // favourites = the categories they book most
  const byCat={};
  acts.forEach(a=>{ const k=catLabel(normCat(a)); byCat[k]=(byCat[k]||0)+1; });
  const favs=Object.keys(byCat).sort((x,y)=>byCat[y]-byCat[x]).slice(0,3);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  return {acc, bookings, acts, orders, reqs, fb, msgs, quiz, favs, avg,
    nights:guestStayNights(acc), daysApp:guestDaysInApp(acc)};
}
function guestCrmInner(){
  let list=(S.accounts||[]).filter(a=>a.active!==false && !stayExpired(a));
  list.sort((a,b)=>String(a.room).localeCompare(String(b.room),undefined,{numeric:true}));
  return `<input id="crm-q" enterkeyhint="done" autocomplete="off" autocorrect="off" placeholder="${esc(t("crmSearch"))}" value="${esc(S.crmQuery||"")}" style="margin-bottom:12px">
    ${list.length?`<div class="card" id="crm-results">${list.map(a=>{
      const r=guestRecord(a);
      const searchText=[a.room,a.name,a.nationality].map(v=>String(v||"").toLowerCase()).join(" ");
      return `<div class="crm-row" data-crm="${a.id}" data-crm-search="${esc(searchText)}">
        <div class="crm-av">${esc(String(a.name||"?").trim().charAt(0).toUpperCase())}</div>
        <div class="crm-mid"><b>${esc(a.name||"")}</b>
          <span class="mini">${t("room")} ${esc(a.room)}${a.nationality?" · "+esc(a.nationality):""}</span>
          <span class="mini">${r.bookings.length} ${t("bookings").toLowerCase()} · ${r.reqs.length} ${t("requests").toLowerCase()}${r.fb.length?" · ★ "+r.avg:""}</span>
        </div>
        <span class="crm-go">${ic("back",15)}</span>
      </div>`;
    }).join("")}</div><div class="empty" id="crm-search-empty" style="display:none"><div class="big">${ic("users",30)}</div>No matching guests</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("noGuests")}</div>`}`;
}
function guest360View(id){
  const acc=(S.accounts||[]).find(a=>a.id==id);
  if(!acc) return `<div class="screen fadein">${topBar(t("guest360"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=guestRecord(acc);
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  return `<div class="screen fadein">
    ${topBar(esc(acc.name||""), t("room")+" "+esc(acc.room))}
    <button class="crumb" id="crumb-crm">${ic("back",15)} ${t("guestCrm")}</button>
    <div class="card g3-head">
      <div class="g3-av">${esc(String(acc.name||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(acc.name||"")}</b>
        <span class="mini">${esc(acc.nationality||"")}${acc.phone?" · "+esc(acc.phone):""}</span>
        <span class="mini">${esc(acc.arrival||"")} → ${esc(acc.departure||"")} · ${r.nights} ${t("nights")}</span>
      </div>
    </div>
    <div class="g3-stats">
      ${stat(r.bookings.length, t("bookings"))}
      ${stat(r.acts.length, t("attendedActs"))}
      ${stat(r.orders.length, t("tickets"))}
      ${stat(r.reqs.length, t("requests"))}
      ${stat(r.msgs.length, t("msgCount"))}
      ${stat(r.quiz.length, t("quizPart"))}
      ${stat(r.daysApp, t("appUsage"))}
      ${stat(r.fb.length?r.avg:"—", t("feedback"))}
    </div>
    ${r.favs.length?`<div class="sec"><h3>${ic("star",17)} ${t("favActs")}</h3>
      <div class="card"><div class="g3-tags">${r.favs.map(f=>`<span class="ts-chip">${esc(f)}</span>`).join("")}</div></div></div>`:""}
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("attendedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.reqs.length?`<div class="sec"><h3>${ic("chat",17)} ${t("requests")}</h3>
      <div class="card">${r.reqs.map(x=>`<div class="g3-row"><b>${esc(x.type||"")}</b>
        <span class="mini">${esc(x.detail||"")} · ${esc(x.status||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.fb.length?`<div class="sec"><h3>${ic("star",17)} ${t("feedback")}</h3>
      <div class="card">${r.fb.map(f=>`<div class="g3-row"><b>${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</b>
        <span class="mini">${esc(f.comment||"")} · ${fmtDate(f.created_at)}</span></div>`).join("")}</div></div>`:""}
  </div>`;
}
/* ================= AUTOMATIC ACTIVITY ROSTER =================
   Rules (agreed with the manager):
   - every entertainer gets ONE morning and ONE afternoon activity
   - EVENTS are joined by the whole team, so they are never assigned to one person
   - the MANAGER (#1) and the DJ (#3) never get activities
   - anyone on their day off is skipped
   - it is FAIR: whoever has done the least so far goes first, and the
     starting point rotates each day so it is never the same person. */
/* #2 social media (films) and #3 the DJ (music) — events and shows only, never
   the normal activity rota. #1 is the manager. */
/* Attendance-only people: numbers 11–50. They exist so their days can be
   recorded and nothing else — no login, no activities, not on the day plan,
   not counted in the team. */
const ATT_ONLY_MIN=11, ATT_ONLY_MAX=50;
function isAttOnly(u){ return !!u && u.role==="attendance"; }
function nextAttNumber(){
  const taken=new Set((S.users||[]).map(u=>+u.number).filter(Boolean));
  for(let n=ATT_ONLY_MIN;n<=ATT_ONLY_MAX;n++) if(!taken.has(n)) return n;
  return null;
}
const DJ_NUMBER=3;
const EVENTS_ONLY_NUMBERS=[DJ_NUMBER];
const NO_ACTIVITY_NUMBERS=[1,2,3];          // manager, social media and DJ never enter the normal activity rota
/* Shows, parties and events belong to the DJ. Entertainers only receive normal activities. */
function eventsCrew(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && +u.number===DJ_NUMBER && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
function isEventsOnly(u){ return !!u && +u.number===DJ_NUMBER; }
function assignableStaff(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && u.number && !NO_ACTIVITY_NUMBERS.includes(+u.number)
      && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
/* Hotel operation windows — one source of truth across rota, Whole Day and exports.
   Morning 10:00–12:30 · Afternoon 15:00–17:30 · Evening 19:30–23:00. */
function operationSlotFromMinutes(m){
  if(m==null || !Number.isFinite(+m)) return "other";
  m=+m;
  if(m>=10*60 && m<12*60+30) return "morning";
  if(m>=15*60 && m<17*60+30) return "afternoon";
  if(m>=19*60+30 && m<=23*60) return "evening";
  return "other";
}
/* Only mAdult enters the entertainer activity rota. Other programme categories remain event/show/party operations. */
function activitySlot(a){
  const c=normCat(a);
  if(c!=="mAdult") return "event";
  const w=actWindow(a);
  if(!w) return "other";
  return operationSlotFromMinutes(w.s0);
}
/* What each person ALREADY has that we are not going to touch.
   When she replaces everything, nothing is kept, so everyone starts at zero. */
function baseLoad(opts){
  const o=opts||{};
  const load={c:{}, last:{}, tick:0};
  (S.activities||[]).forEach(a=>{
    const slot=activitySlot(a);
    if(slot!=="morning" && slot!=="afternoon") return;
    const who=String(a.entertainer||"").trim().toLowerCase();
    if(!who) return;
    if(o.onlyEmpty) load.c[who]=(load.c[who]||0)+1;   // this one stays, so it counts
  });
  return load;
}
function baseCounts(opts){ return baseLoad(opts).c; }
function loadKey(u){ return String(u.username).toLowerCase(); }
function loadOf(load,u){ return (load.c&&load.c[loadKey(u)])||0; }
function bumpLoad(load,u,act,day){
  const k=loadKey(u);
  load.c[k]=(load.c[k]||0)+1;
  load.last[k]=++load.tick;                    // remember when they last got one
  if(act && act.name){                         // and which activity, so it is not repeated
    load.acts=load.acts||{};
    const ak=k+"|"+actKey(act.name);
    load.acts[ak]=(load.acts[ak]||0)+1;
    load.days=load.days||{};
    load.days[ak]=load.days[ak]||[];
    if(typeof day==="number") load.days[ak].push(day);
  }
}
/* Picks whoever has the FEWEST activities; if several are equal, the one who
   has waited longest. That keeps everybody within one of each other. */
/* Who already has this same activity on the other days of the week?
   Yesterday counts hardest, then anywhere else in the week. */
/* how far apart two weekdays are, going the short way round the week */
function dayGap(a,b){ const d=Math.abs(a-b)%7; return Math.min(d, 7-d); }
function repeatPenalty(u, act, day, load){
  if(!act || !act.name) return 0;
  /* what this run has already given them counts as much as what is saved */
  let planned=0, plannedYesterday=false;
  if(load && load.acts){
    const ak=loadKey(u)+"|"+actKey(act.name);
    planned=load.acts[ak]||0;
    plannedYesterday=((load.days&&load.days[ak])||[]).some(d=>dayGap(d,day)<=1);
  }
  const key=actKey(act.name), me=String(u.username||"").toLowerCase();
  const mine=a=>String(a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
      .map(x=>x.trim()).some(x=>{
        if(!x) return false;
        if(x===me) return true;
        const disp=String(u.display_name||"").toLowerCase();
        return disp && x===disp;
      });
  const sameAct=(S.activities||[]).filter(a=>actKey(a.name)===key && a.day!==day && mine(a));
  const didYesterday=sameAct.some(a=>dayGap(a.day,day)<=1)
    || plannedYesterday
    || (((load&&load.days&&load.days[loadKey(u)+"|"+actKey(act.name)])||[]).some(d=>dayGap(d,day)<=1));
  const times=sameAct.length + planned;
  if(!times && !didYesterday) return 0;
  return (didYesterday?4:0) + times;               // repeated yesterday hurts most
}
function pickFairest(pool, load, usedThisSlot, act, day){
  /* fairness first: never the same activity twice for one person if it can be
     avoided, then an even share of the work, then whoever went longest ago */
  const score=u=>repeatPenalty(u,act,day,load)*1e9 + loadOf(load,u)*1e6 + (load.last[loadKey(u)]||0);
  /* only people who are allowed to run this activity */
  const allowed=act ? pool.filter(u=>canRunActivity(u,act) && !entranceConflict(u,day,act)) : pool;
  if(!allowed.length) return null;             // nobody may do it — leave it empty
  let best=null, bestScore=Infinity;
  allowed.forEach(u=>{
    if(usedThisSlot.has(u.username)) return;
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  if(best) return best;
  allowed.forEach(u=>{                         // more activities than people
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  return best;
}
/* One day. Pass a shared `load` so a whole week stays balanced across days. */
function autoAssignDay(day, opts, sharedLoad){
  const o=opts||{};
  const dateStr_=assignDateStr(day);
  const out=[];
  const load=sharedLoad || baseLoad(o);

  /* Every event/show/party is assigned to the DJ only, provided the DJ is actually working. */
  const crew=eventsCrew(day,dateStr_);
  const dj=crew[0]||null;
  (S.activities||[])
    .filter(a=>a.day===day && activitySlot(a)==="event")
    .filter(a=>o.onlyEmpty ? !String(a.entertainer||"").trim() : true)
    .forEach(a=>{
      if(!dj) return;
      out.push({activity:a, slot:"event", username:dj.username,
        name:dj.display_name||dj.username, day});
    });

  const pool=assignableStaff(day,dateStr_);
  if(!pool.length) return out;

  ["morning","afternoon"].forEach(slot=>{
    const acts=(S.activities||[])
      .filter(a=>a.day===day && activitySlot(a)===slot)
      .filter(a=>o.onlyEmpty ? !String(a.entertainer||"").trim() : true)
      .sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    if(!acts.length) return;
    const usedThisSlot=new Set();
    acts.forEach(a=>{
      const pick=pickFairest(pool, load, usedThisSlot, a, day);
      if(!pick) return;
      usedThisSlot.add(pick.username);
      bumpLoad(load,pick,a,day);
      out.push({activity:a, username:pick.username, name:pick.display_name||pick.username, slot, day});
    });
  });
  return out;
}
/* The whole week, sharing ONE running count so everybody ends up even. */
function autoAssignWeek(opts){
  const load=baseLoad(opts||{});
  let all=[];
  for(let d=0; d<7; d++) all=all.concat(autoAssignDay(d, opts, load));
  return fixRepeats(balancePlan(all, opts||{}));
}
/* Last tidy-up: if anyone still ends up with the same activity on two days next
   to each other, swap it with another activity on that same day. */
function fixRepeats(plan){
  const clash=(p, list)=>list.some(x=>x!==p
    && String(x.username).toLowerCase()===String(p.username).toLowerCase()
    && actKey(x.activity.name)===actKey(p.activity.name)
    && dayGap(x.activity.day, p.activity.day)<=1);
  for(let round=0; round<40; round++){
    const bad=plan.find(p=>p.slot!=="event" && clash(p, plan));
    if(!bad) break;
    const sameDay=plan.filter(x=>x!==bad && x.slot!=="event" && x.activity.day===bad.activity.day);
    let fixed=false;
    for(const other of sameDay){
      const u1=(S.users||[]).find(u=>u.username===bad.username);
      const u2=(S.users||[]).find(u=>u.username===other.username);
      if(!u1||!u2) continue;
      if(!canRunActivity(u1, other.activity) || !canRunActivity(u2, bad.activity)) continue;
      /* pretend the swap happened and check nobody is worse off */
      const trial=plan.map(x=> x===bad ? {...x, username:other.username, name:other.name}
                            : x===other ? {...x, username:bad.username, name:bad.name} : x);
      const a2=trial.find(x=>x.activity===bad.activity), b2=trial.find(x=>x.activity===other.activity);
      if(clash(a2,trial) || clash(b2,trial)) continue;
      plan=trial; fixed=true; break;
    }
    if(!fixed) break;                                  // cannot do better honestly
  }
  return plan;
}
/* Final tidy-up: if anyone is still more than one ahead, hand one of their
   activities to somebody who has fewer — but only if that person is actually
   working that day and does not already have that half of the day. */
function balancePlan(plan, opts){
  for(let guard=0; guard<300; guard++){
    const bal=planBalance(plan, opts);
    if(bal.spread<=1) break;
    const hi=Object.keys(bal.per).filter(k=>bal.per[k]===bal.max);
    const lo=Object.keys(bal.per).filter(k=>bal.per[k]===bal.min);
    let moved=false;
    for(const h of hi){
      for(const l of lo){
        for(let i=0;i<plan.length && !moved;i++){
          const it=plan[i];
          if(String(it.username).toLowerCase()!==h) continue;
          const day=it.activity.day;
          const cand=assignableStaff(day,assignDateStr(day)).find(u=>String(u.username).toLowerCase()===l);
          if(!cand) continue;                                   // not working that day
          if(!canRunActivity(cand, it.activity)) continue;       // they are not allowed to run it
          const clash=plan.some(x=>x!==it && x.activity.day===day && x.slot===it.slot
            && String(x.username).toLowerCase()===l);
          if(clash) continue;                                   // already has that half-day
          /* and never hand them the same activity on the day before or after */
          const nextTo=plan.some(x=>x!==it && String(x.username).toLowerCase()===l
            && actKey(x.activity.name)===actKey(it.activity.name)
            && dayGap(x.activity.day, day)<=1);      // same activity on a neighbouring day
          if(nextTo) continue;
          plan[i]={...it, username:cand.username, name:cand.display_name||cand.username};
          moved=true;
        }
        if(moved) break;
      }
      if(moved) break;
    }
    if(!moved) break;                                           // cannot improve further
  }
  return plan;
}
/* How even the result is — she sees this before applying. */
function planBalance(list, opts){
  const per={};
  const everyone=new Set();
  for(let d=0; d<7; d++) assignableStaff(d,assignDateStr(d)).forEach(u=>everyone.add(u.username));
  if((opts||{}).onlyEmpty){
    const b=baseCounts(opts);
    Object.keys(b).forEach(k=>{ per[k]=b[k]; });
  }
  everyone.forEach(u=>{ if(per[String(u).toLowerCase()]===undefined) per[String(u).toLowerCase()]=0; });
  list.forEach(x=>{ const k=String(x.username).toLowerCase(); per[k]=(per[k]||0)+1; });
  const vals=Object.values(per);
  return {per, min:vals.length?Math.min(...vals):0, max:vals.length?Math.max(...vals):0,
          spread:vals.length?Math.max(...vals)-Math.min(...vals):0};
}
async function applyAssignments(list){
  for(const it of list){
    try{ await DB.saveActivity({...it.activity, entertainer:it.username}); }
    catch(e){ toastErr(t("errSave")); return false; }
  }
  return true;
}
/* She sees the proposal, can change ANY name, and only then applies it. */
function openAutoAssignModal(day){
  let scope="day", onlyEmpty=true;
  let plan=[];
  const wrap=baseModal("");
  const rebuild=()=>{ plan=(scope==="day")?autoAssignDay(day,{onlyEmpty}):autoAssignWeek({onlyEmpty}); };
  rebuild();
  const draw=()=>{
    const bal=planBalance(plan,{onlyEmpty});
    const byDay={};
    plan.forEach(x=>{ (byDay[x.activity.day]=byDay[x.activity.day]||[]).push(x); });
    const nameOf=un=>{ const u=(S.users||[]).find(y=>y.username===un); return u?(u.display_name||u.username):un; };
    wrap.innerHTML=`<div class="modal">
      <h3>${ic("users",20)} ${t("autoAssign")}</h3>
      <p class="mini">${t("autoHint")}</p>
      <div class="bd-roles" style="margin-top:12px">
        <button class="bd-role ${scope==="day"?"on":""}" data-ascope="day">${t("autoDay")}</button>
        <button class="bd-role ${scope==="week"?"on":""}" data-ascope="week">${t("autoWeek")}</button>
      </div>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:14.5px;color:var(--ink);margin:10px 0">
        <input type="checkbox" id="a-empty" style="width:auto" ${onlyEmpty?"checked":""}> ${t("onlyEmptyLbl")}</label>
      ${plan.length?`
        <div class="aa-bal ${bal.spread<=1?"good":"warn"}">
          <b>${t("balanceLbl")}</b>
          <span>${bal.spread<=1?t("evenSpread"):(t("spreadOff")+" "+bal.spread)} · ${bal.min}–${bal.max} ${t("activityCount")}</span>
        </div>
        <p class="mini" style="margin:8px 0">${ic("pen",12)} ${t("editHint")}</p>
        <div class="card aa-list">
          ${Object.keys(byDay).sort((a,b)=>a-b).map(d=>{
            const pool=assignableStaff(+d,assignDateStr(+d));
            return `<div class="aa-day"><b>${esc(t("days")[+d]||"")}</b></div>
            ${byDay[d].map(x=>{
              const i=plan.indexOf(x);
              return `<div class="aa-row">
                <span class="aa-slot ${x.slot}">${x.slot==="morning"?t("morningSlot"):t("afternoonSlot")}</span>
                <span class="aa-mid"><b>${esc(x.activity.name)}</b><span class="mini">${esc(x.activity.time||"")}</span></span>
                <select class="aa-sel" data-aarow="${i}">
                  <option value="">${t("noneAssigned")}</option>
                  ${pool.map(u=>`<option value="${esc(u.username)}" ${u.username===x.username?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("")}
                </select>
              </div>`;
            }).join("")}`;
          }).join("")}
        </div>
        <label style="margin-top:10px">${t("perPerson")}</label>
        <div class="aa-per">${Object.keys(bal.per).sort((a,b)=>bal.per[b]-bal.per[a]).map(k=>
          `<span class="ts-chip ${bal.per[k]===bal.max&&bal.spread>1?"hot":""}">${esc(nameOf(k))} · ${bal.per[k]}</span>`).join("")}</div>
        <p class="mini" style="margin-top:10px">${ic("sparkle",13)} ${t("eventsAllTeam")}</p>
        <button class="btn ghost" id="a-recalc">${ic("back",15)} ${t("recalc")}</button>
        <button class="btn" id="a-go">${ic("check",16)} ${t("autoApply")}</button>`
      :`<div class="empty" style="margin-top:12px"><div class="big">${ic("users",28)}</div>${t("autoNothing")}</div>`}
      <button class="btn ghost" id="a-x">${t("close")}</button>
    </div>`;
    wrap.querySelectorAll("[data-ascope]").forEach(b=>b.onclick=()=>{ scope=b.dataset.ascope; rebuild(); draw(); });
    const ce=wrap.querySelector("#a-empty"); if(ce) ce.onchange=()=>{ onlyEmpty=ce.checked; rebuild(); draw(); };
    // change any single assignment by hand
    wrap.querySelectorAll("[data-aarow]").forEach(sel=>sel.onchange=()=>{
      const i=+sel.dataset.aarow;
      if(!plan[i]) return;
      if(!sel.value){ plan.splice(i,1); }
      else { plan[i]={...plan[i], username:sel.value,
        name:((S.users||[]).find(u=>u.username===sel.value)||{}).display_name||sel.value}; }
      draw();
    });
    const rc=wrap.querySelector("#a-recalc"); if(rc) rc.onclick=()=>{ rebuild(); draw(); };
    wrap.querySelector("#a-x").onclick=()=>wrap.remove();
    const go=wrap.querySelector("#a-go");
    if(go) go.onclick=async ()=>{
      go.disabled=true;
      const ok=await applyAssignments(plan);
      wrap.remove();
      if(ok){ toastOk(t("autoDone")); render(); }
    };
  };
  draw();
}
/* Manager sets what a person can and cannot do — this drives automatic assignment. */
/* When an entertainer leaves: keep every day they worked, take them out of
   today's plans, and free their number for whoever replaces them. */
/* Open one booking: change how many people, move to waiting list, or remove it. */
function accountForRoom(room){
  const r=String(room||"").trim();
  return (S.accounts||[]).find(a=>String(a.room).trim()===r) || null;
}
function openBookingEditor(id){
  const b=(S.bookings||[]).find(x=>x.id===id); if(!b) return;
  const act=(S.activities||[]).find(a=>a.id===b.activity_id)||{};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editBooking")}</h3>
    <p class="mini">${esc(act.name||"")}${act.time?" · "+esc(act.time):""}</p>
    <div class="card" style="margin:10px 0">
      <div class="bk-line"><span class="mini">${t("room")}</span><b>${esc(b.room)}</b></div>
      <div class="bk-line"><span class="mini">${t("name")}</span><b>${esc(b.guest_name||"")}</b></div>
      ${b.phone?`<div class="bk-line"><span class="mini">${t("phone")}</span><b>${esc(b.phone)}</b></div>`:""}
      ${b.nationality?`<div class="bk-line"><span class="mini">${t("nationality")}</span><b>${esc(b.nationality)}</b></div>`:""}
      ${b.created_at?`<div class="bk-line"><span class="mini">${t("bookedAt")}</span><b>${esc(whenLabel(b.created_at))}</b></div>`:""}
    </div>
    <label>${t("persons")}</label>
    <input id="bk-n" type="number" min="1" max="20" value="${(+b.adults||1)+(+b.children||0)}" inputmode="numeric">
    <label style="margin-top:10px">${t("status")}</label>
    <select id="bk-st">
      <option value="booked" ${b.status!=="waitlist"?"selected":""}>${t("booked")}</option>
      <option value="waitlist" ${b.status==="waitlist"?"selected":""}>${t("waitlist")}</option>
    </select>
    <button class="btn" id="bk-save">${t("save")}</button>
    <button class="btn ghost" id="bk-open">${ic("user",15)} ${t("openGuest")}</button>
    <button class="btn warn" id="bk-del">${ic("trash",15)} ${t("removeBooking")}</button>
    <button class="btn ghost" id="bk-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#bk-x").onclick=()=>wrap.remove();
  const acc=accountForRoom(b.room);
  const openBtn=wrap.querySelector("#bk-open");
  if(openBtn){
    if(acc) openBtn.onclick=()=>{ wrap.remove(); S.tab="g360:"+acc.id; render(); };
    else { openBtn.disabled=true; openBtn.textContent=t("noGuestAccount"); }
  }
  wrap.querySelector("#bk-save").onclick=async ()=>{
    const n=Math.max(1,+wrap.querySelector("#bk-n").value||1);
    const st=wrap.querySelector("#bk-st").value;
    await DB.updateBooking(b.id,{adults:n, children:0, status:st});
    wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#bk-del").onclick=async ()=>{
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(b.id); wrap.remove(); toastOk(t("saved")); render();
  };
}
/* Set someone on holiday from one date to another, instead of tapping day by day. */
/* A person who is only on the attendance sheet — a name and a number, nothing else. */
function openAttPersonModal(userId){
  const u=userId ? (S.users||[]).find(x=>x.id===userId && isAttOnly(x)) : null;
  const suggested=u ? u.number : nextAttNumber();
  const wrap=baseModal(`
    <h3>${ic(u?"pen":"plus",20)} ${u?esc(u.display_name||""):t("addAttOnly")}</h3>
    <p class="mini">${t("addAttOnlyHint")}</p>
    <label>${t("name")}</label>
    <input id="ao-name" type="text" autocomplete="off" value="${u?esc(u.display_name||""):""}">
    <label style="margin-top:10px">${t("attNumber")}</label>
    <input id="ao-num" type="number" min="${ATT_ONLY_MIN}" max="${ATT_ONLY_MAX}" value="${suggested||ATT_ONLY_MIN}" inputmode="numeric">
    <div class="row2" style="margin-top:10px">
      <div><label>${t("startedOn")}</label>
        <input id="ao-from" type="date" value="${u&&u.hire_date?esc(String(u.hire_date).slice(0,10)):hotelDateStr()}"></div>
      <div><label>${t("lastDayOpt")}</label>
        <input id="ao-to" type="date" value="${u&&u.left_date?esc(String(u.left_date).slice(0,10)):""}"></div>
    </div>
    <p class="mini">${t("attDatesHint")}</p>
    <p class="mini" id="ao-err" style="color:#BE3C3C;min-height:16px"></p>
    <button class="btn" id="ao-go">${t("save")}</button>
    ${u?`<button class="btn warn" id="ao-del">${ic("trash",15)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="ao-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#ao-x").onclick=()=>wrap.remove();
  const del=wrap.querySelector("#ao-del");
  if(del) del.onclick=async ()=>{
    if(!(await confirmAction({title:t("deleteQ"), body:t("attDeleteHint"), danger:true}))) return;
    await DB.deleteUser(u.id); wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#ao-go").onclick=async ()=>{
    const err=wrap.querySelector("#ao-err");
    const name=wrap.querySelector("#ao-name").value.trim();
    const num=+wrap.querySelector("#ao-num").value;
    const from=wrap.querySelector("#ao-from").value;
    const to=wrap.querySelector("#ao-to").value;
    if(!name){ err.textContent=t("nameNeeded"); return; }
    if(!(num>=ATT_ONLY_MIN && num<=ATT_ONLY_MAX)){ err.textContent=t("attNumRange"); return; }
    if((S.users||[]).some(x=>+x.number===num && (!u || x.id!==u.id))){ err.textContent=t("numberTaken"); return; }
    if(to && from && to<from){ err.textContent=t("checkDates"); return; }
    const patch={ display_name:name, number:num,
      hire_date:from||"", left_date:to||"", archived:!!to, active:!to };
    if(u){ await DB.updateUser(u.id, patch); }
    else {
      await DB.addUser({ username:"att"+num+"_"+Date.now().toString(36),
        password:"", role:"attendance", ...patch });
    }
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openVacationModal(username){
  const team=(S.users||[]).filter(u=>(u.role==="staff"||u.role==="manager"||isAttOnly(u)) && !hasLeft(u));
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("sun",20)} ${t("setVacation")}</h3>
    <p class="mini">${t("setVacationHint")}</p>
    <label>${t("person")}</label>
    <select id="vc-who">
      ${team.map(u=>`<option value="${esc(u.username)}" ${u.username===username?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("")}
    </select>
    <div class="row2" style="margin-top:10px">
      <div><label>${t("fromDate")}</label><input id="vc-from" type="date" value="${today}"></div>
      <div><label>${t("toDate")}</label><input id="vc-to" type="date" value="${today}"></div>
    </div>
    <p class="mini" id="vc-count" style="margin-top:8px"></p>
    <button class="btn" id="vc-go">${t("setVacation")}</button>
    <button class="btn ghost" id="vc-clear">${t("clearVacation")}</button>
    <button class="btn ghost" id="vc-x">${t("cancelBtn")}</button>`);
  const from=wrap.querySelector("#vc-from"), to=wrap.querySelector("#vc-to");
  const note=wrap.querySelector("#vc-count");
  const daysBetween=()=>{
    const a=from.value, b=to.value;
    if(!a||!b||b<a) return [];
    const out=[]; const d=new Date(a+"T12:00:00"), end=new Date(b+"T12:00:00");
    while(d<=end && out.length<200){ out.push(d.toISOString().slice(0,10)); d.setDate(d.getDate()+1); }
    return out;
  };
  const refresh=()=>{
    const n=daysBetween().length;
    note.textContent = n ? (n+" "+t("daysWord")) : t("checkDates");
  };
  from.onchange=()=>{ if(to.value<from.value) to.value=from.value; refresh(); };
  to.onchange=refresh; refresh();
  wrap.querySelector("#vc-x").onclick=()=>wrap.remove();
  const apply=async status=>{
    const who=wrap.querySelector("#vc-who").value;
    const days=daysBetween();
    if(!days.length){ toastErr(t("checkDates")); return; }
    for(const d of days){ await DB.setStaffAtt(who, d, status); }
    wrap.remove(); toastOk(days.length+" "+t("daysWord")); render();
  };
  wrap.querySelector("#vc-go").onclick=()=>apply("V");
  wrap.querySelector("#vc-clear").onclick=()=>apply(null);
}
function openLeaveModal(userId){
  const u=(S.users||[]).find(x=>x.id===userId); if(!u) return;
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("exit",20)} ${t("markLeft")}</h3>
    <p class="mini">${esc(u.display_name||u.username)} · ${t("markLeftHint")}</p>
    <label style="margin-top:10px">${t("leftDate")}</label>
    <input id="lv-date" type="date" value="${esc(u.left_date||today)}">
    <button class="btn" id="lv-go">${t("markLeft")}</button>
    ${hasLeft(u)?`<button class="btn ghost" id="lv-undo">${t("undoLeft")}</button>`:""}
    <button class="btn ghost" id="lv-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#lv-x").onclick=()=>wrap.remove();
  wrap.querySelector("#lv-go").onclick=async ()=>{
    const d=wrap.querySelector("#lv-date").value || today;
    await DB.updateUser(u.id,{left_date:d, archived:true, active:false, number:null});
    wrap.remove(); toastOk(t("saved")); render();
  };
  const un=wrap.querySelector("#lv-undo");
  if(un) un.onclick=async ()=>{
    await DB.updateUser(u.id,{left_date:"", archived:false, active:true});
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openSkillEditor(username){
  const u=(S.users||[]).find(x=>x.username===username); if(!u) return;
  if(S.session.role!=="manager"){ toast(t("profileReadOnly")); return; }
  if(u.role==="manager") return; // manager is never part of the activity skill matrix
  let can=canDoList(u), cant=cannotDoList(u);
  const wrap=baseModal(`
    <h3>${esc(u.display_name||u.username)}</h3>
    <p class="mini">${t("skillEditHint2")}</p>
    <div id="sk-box"></div>
    <button class="btn" id="sk-go">${t("save")}</button>
    <button class="btn ghost" id="sk-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#sk-box");
  if(isEventsOnly(u)){
    box.innerHTML=`<p class="mini">${t("eventsCrewHint")}</p>`;
    const go=wrap.querySelector("#sk-go"); if(go) go.style.display="none";
    return;
  }
  const list=programActivities();
  const paint=()=>{
    if(!list.length){ box.innerHTML=`<p class="mini">${t("noActsYet")}</p>`; return; }
    box.innerHTML=list.map(([k,label])=>{
      const st=cant.includes(k)?"cant":(can.includes(k)?"can":"none");
      return `<button class="sk-btn ${st}" data-sk="${esc(k)}">
        <span>${esc(label)}</span>
        <span class="sk-tag">${st==="can"?t("skCan"):st==="cant"?t("skCant"):t("skAny")}</span>
      </button>`;}).join("");
    box.querySelectorAll("[data-sk]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.sk;
      if(can.includes(k)){ can=can.filter(x=>x!==k); cant.push(k); }        // can -> can't
      else if(cant.includes(k)){ cant=cant.filter(x=>x!==k); }              // can't -> not set
      else { can.push(k); }                                                 // not set -> can
      paint();
    });
  };
  paint();
  wrap.querySelector("#sk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sk-go").onclick=async ()=>{
    await DB.updateUser(u.id,{can_do:can.join(";"), cannot_do:cant.join(";")});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* ================= ASSIGNMENT CENTER =================
   One screen: who is working, what still has nobody, tasks, and one-tap
   automatic assignment that the manager reviews before anything is saved. */
function assignDay(){
  if(S.assignDay==null) S.assignDay=todayIndex();
  return S.assignDay;
}
function assignDateStr(day){
  const base=hotelDateStr(), td=todayIndex();
  let diff=day-td; if(diff<0) diff+=7;
  const d=new Date(base+"T12:00:00"); d.setDate(d.getDate()+diff);
  return d.toISOString().slice(0,10);
}
/* how many of the team are allowed to run this activity */
function whoCanRun(a){
  if(activitySlot(a)==="event"){
    const dj=(S.users||[]).find(u=>u.role==="staff" && +u.number===DJ_NUMBER && u.active!==false && !hasLeft(u));
    return dj ? ((dj.display_name||dj.username)+" · DJ") : "DJ —";
  }
  const ds=assignDateStr(a.day);
  const team=assignableStaff(a.day,ds);
  const n=team.filter(u=>canRunActivity(u,a) && !entranceConflict(u,a.day,a)).length;
  return n+"/"+team.length+" "+t("canRunIt");
}
/* Entrance duty lives here now — Day Plan only handles days off. */
function openEntranceModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("door",20)} ${t("entranceDuty")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b></p>
    <label style="margin-top:10px">${t("selectEntrance")}</label>
    <select id="ent-sel">
      <option value="">—</option>
      ${roster.map(r=>`<option value="${r.n}" ${dp.entrance===r.n?"selected":""}>#${r.n} ${esc(r.name||r.role)}</option>`).join("")}
    </select>
    <button class="btn" id="ent-save">${t("save")}</button>
    <button class="btn ghost" id="ent-x">${t("close")}</button>`);
  wrap.querySelector("#ent-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ent-save").onclick=async ()=>{
    const raw=wrap.querySelector("#ent-sel").value;
    const all={...(S.settings.dayOverrides||{})};
    const cur=all[String(day)] || {off:[...dp.off], entrance:dp.entrance};
    all[String(day)]={...cur, entrance: raw?+raw:null};   // days off stay as they are
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function assignView(){
  const day=assignDay(), ds=assignDateStr(day);
  const sub=S.sub.assign||"acts";
  const acts=(S.activities||[]).filter(a=>a.day===day)
    .sort((a,b)=>(timeToMin(a.time)||0)-(timeToMin(b.time)||0));
  const open=acts.filter(a=>!String(a.entertainer||"").trim());
  const team=(S.users||[]).filter(u=>u.role==="staff"); // manager never runs activities and has no can/can't profile
  const working=team.filter(u=>availableOn(u,day,ds));
  const offList=team.filter(u=>!availableOn(u,day,ds));
  const openTasks=(S.tasks||[]).filter(x=>taskStatus(x)!=="verified");
  return `<div class="screen fadein">
    ${topBar(t("assignCenter"),"")}
    <div class="seg" id="asg-tabs">
      <button class="${sub==="acts"?"on":""}" data-asub="acts">${t("asgActs")}${open.length?` <span class="seg-b">${open.length}</span>`:""}</button>
      <button class="${sub==="tasks"?"on":""}" data-asub="tasks">${t("tasks")}${openTasks.length?` <span class="seg-b">${openTasks.length}</span>`:""}</button>
      <button class="${sub==="who"?"on":""}" data-asub="who">${t("asgWho")}</button>
    </div>
    <div class="daypick" id="asg-days">
      ${t("daysShort").map((d,i)=>`<button class="${i===day?"on":""}" data-aday="${i}">${d}</button>`).join("")}
    </div>
    ${sub==="acts"?assignActsInner(day,ds,acts,open,working)
     :sub==="tasks"?`<div style="margin-top:12px">${tasksInner()}</div>`
     :assignWhoInner(day,ds,working,offList)}
  </div>`;
}
function assignActsInner(day, ds, acts, open, working){
  return `
    <div class="g3-stats" style="margin-top:12px">
      <div class="stat"><b>${acts.length}</b><span>${t("activities")}</span></div>
      <div class="stat"><b>${open.length}</b><span>${t("asgOpen")}</span></div>
      <div class="stat"><b>${working.length}</b><span>${t("workingToday")}</span></div>
    </div>
    <div class="card ent-card" id="asg-ent" style="margin-top:12px">
      <span class="ent-ic">${ic("door",20)}</span>
      <span class="asg-mid"><b>${t("entranceDuty")}</b>
        <span class="mini">${personTag(dayPlanFor(day).entrance)||t("noOneEntrance")}</span></span>
      <span class="ent-go">${ic("pen",15)}</span>
    </div>
    ${open.length?`<button class="btn" id="asg-auto" style="margin-top:12px">
        ${ic("sparkle",18)} ${t("autoAssign")}</button>
      <p class="mini" style="margin-top:6px">${t("autoAssignHint")}</p>`
      :`<div class="ok-note" style="margin-top:12px">${ic("check",18)} ${t("allAssigned")}</div>`}
    <div class="card" style="margin-top:12px">
      ${acts.length?acts.map(a=>{
        const who=String(a.entertainer||"").trim();
        const sk=activitySkill(a);
        return `<div class="asg-row" data-aopen="${a.id}">
          <span class="asg-t">${esc(a.time||"")}</span>
          <span class="asg-mid"><b>${esc(a.name)}</b>
            <span class="mini">${esc(whoCanRun(a))}${a.location?" · "+esc(a.location):""}</span></span>
          ${who?`<span class="asg-who">${esc(who)}</span>`
               :`<span class="asg-who none">${t("asgNobody")}</span>`}
        </div>`;}).join("")
        :`<p class="mini" style="padding:8px 2px">${t("noneToday")}</p>`}
    </div>`;
}
function assignWhoInner(day, ds, working, offList){
  const row=(u,ok)=>{
    const can=canDoList(u), cant=cannotDoList(u);
    const ent=onEntranceDuty(u,day);
    const n=assignedCount(u.username,day);
    return `<div class="asg-row" data-aemp="${esc(u.username)}">
      <span class="loc-av">${esc(String(u.display_name||u.username).trim().charAt(0).toUpperCase())}</span>
      <span class="asg-mid"><b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${ok?`${n} ${t("activities")}${ent?" · "+t("entranceDuty"):""}`
          :(notYetHired(u,ds.slice(0,7),+ds.slice(8,10))?t("attN")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="A"?t("attA")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="V"?t("attV")
            :t("dayOff"))}</span>
        ${isEventsOnly(u)?`<span class="skill-chips"><span class="chip evt">${t("eventsCrewTag")}</span></span>`
         :(can.length||cant.length?`<span class="skill-chips">
          ${can.map(k=>`<span class="chip can">${esc(prettyAct(k))}</span>`).join("")}
          ${cant.map(k=>`<span class="chip cant">${esc(prettyAct(k))}</span>`).join("")}
        </span>`:`<span class="mini dim">${t("noSkillsSet")}</span>`)}
      </span></div>`;};
  return `<p class="mini" style="margin:12px 0 6px">${t("asgWhoHint")}</p>
    <div class="card">${working.length?working.map(u=>row(u,true)).join(""):`<p class="mini">${t("nobodyWorking")}</p>`}</div>
    ${offList.length?`<h4 style="margin:16px 0 8px">${t("dayOffToday")}</h4>
      <div class="card dim-card">${offList.map(u=>row(u,false)).join("")}</div>`:""}`;
}
/* "Today 14:30", "Yesterday 09:15", otherwise the date — so nothing is a mystery. */
function whenLabel(ts){
  if(!ts) return "";
  const d=new Date(ts);
  if(isNaN(d.getTime())) return "";
  const time=d.toLocaleTimeString(S.lang||"en",{hour:"2-digit",minute:"2-digit"});
  const dayOf=x=>{ const y=new Date(x); y.setHours(0,0,0,0); return y.getTime(); };
  const today=dayOf(hotelNow()), that=dayOf(d);
  const diff=Math.round((today-that)/86400000);
  if(diff===0) return t("todayWord")+" "+time;
  if(diff===1) return t("yesterdayWord")+" "+time;
  if(diff>1 && diff<7) return t("days")[d.getDay()]+" "+time;
  return d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"})+" "+time;
}
/* Collect a dated list into one row per day, newest first. Tap a day to open it. */
function dayKeyOf(ts){ const d=new Date(ts); return isNaN(d)?"" : d.toISOString().slice(0,10); }
function dayHeading(key){
  const today=hotelDateStr();
  const y=new Date(today+"T12:00:00"); y.setDate(y.getDate()-1);
  const yest=y.toISOString().slice(0,10);
  if(key===today) return t("todayWord");
  if(key===yest)  return t("yesterdayWord");
  const d=new Date(key+"T12:00:00");
  return d.toLocaleDateString(S.lang||"en",{weekday:"short",day:"2-digit",month:"2-digit",year:"numeric"});
}
function groupByDay(list, tsField){
  const map=new Map();
  (list||[]).forEach(x=>{
    const k=dayKeyOf(x[tsField||"created_at"]) || "0000-00-00";
    if(!map.has(k)) map.set(k,[]);
    map.get(k).push(x);
  });
  return [...map.entries()].sort((a,b)=>b[0].localeCompare(a[0]));
}
function openDayKey(kind){ return (S.openDay && S.openDay[kind]) || null; }
function dayGroups(kind, list, tsField, rowFn, unitKey){
  const groups=groupByDay(list, tsField);
  if(!groups.length) return `<div class="empty"><div class="big">${ic("calendar",30)}</div>${t("none")}</div>`;
  const open=openDayKey(kind) || groups[0][0];
  return `<div class="dg-wrap">${groups.map(([key,items])=>{
    const isOpen=key===open;
    return `<div class="dg ${isOpen?"open":""}">
      <button class="dg-h" data-dgopen="${esc(kind)}|${esc(key)}">
        <span class="dg-t">${esc(dayHeading(key))}</span>
        <span class="dg-d">${esc(key.split("-").reverse().join("/"))}</span>
        <span class="dg-n">${items.length} ${t(unitKey||"itemsWord")}</span>
        <span class="dg-c">${ic("back",14)}</span>
      </button>
      ${isOpen?`<div class="dg-body">${items.map(rowFn).join("")}</div>`:""}
    </div>`;}).join("")}</div>`;
}
/* ================= SKILLS & AUTOMATIC ASSIGNMENT =================
   A person is only ever suggested for an activity when ALL of these hold:
     - they are employed on that date (hire date) and not on a day off
     - they are not marked absent
     - they are not on entrance duty at that hour
     - the activity's skill is in their "can do" and NOT in their "can't do"
     - they are not already busy at that time
   The manager always reviews the suggestions before anything is saved. */
/* The list she ticks is her OWN programme — the real activity names —
   so automatic assignment matches exactly what is on the plan. */
function actKey(name){ return String(name||"").trim().toLowerCase().replace(/\s+/g," "); }
function programActivities(){
  const seen=new Map();
  (S.activities||[]).forEach(a=>{
    if(activitySlot(a)!=="morning" && activitySlot(a)!=="afternoon") return; // no events/shows/parties in entertainer skills
    const k=actKey(a.name);
    if(k && !seen.has(k)) seen.set(k, String(a.name).trim());
  });
  return [...seen.entries()].sort((x,y)=>x[1].localeCompare(y[1]));
}
/* turn a stored key back into the activity name as she wrote it */
function prettyAct(k){
  const hit=programActivities().find(([key])=>key===k);
  return hit ? hit[1] : k;
}
function parseSkills(v){
  return String(v||"").split(/[;|\n]/).map(x=>actKey(x)).filter(Boolean);
}
function canDoList(u){ return parseSkills(u && u.can_do); }
function cannotDoList(u){ return parseSkills(u && u.cannot_do); }
/* the skill an activity needs — set on the activity, else guessed from its name */
function activitySkill(a){
  const explicit=String(a && a.needs_skill||"").trim().toLowerCase();
  if(explicit) return explicit;
  const n=String((a&&a.name)||"").toLowerCase();
  const guess=[["water",/aqua|water|pool|snorkel|swim/],["dance",/dance|zumba|salsa|show ?dance/],
    ["show",/show|theatre|theater|performance|stage/],["kids",/kids|mini ?disco|children/],
    ["dj",/\bdj\b|disco|party/],["music",/music|band|karaoke|sing/],
    ["fitness",/gym|fitness|yoga|pilates|stretch|workout/],
    ["sport",/football|volley|tennis|basket|boccia|petanque|dart|archer|bowl|table ?tennis|sport/],
    ["beach",/beach|sunset|sand/],["craft",/craft|paint|workshop|art/],
    ["games",/game|quiz|bingo|tournament|cocktail/]];
  for(const [k,re] of guess){ if(re.test(n)) return k; }
  return "host";
}
/* Can this person run THIS activity? */
function canRunActivity(u, act){
  const k=actKey(act && act.name);
  if(!k) return true;
  if(cannotDoList(u).includes(k)) return false;   // "can't do" always wins
  const can=canDoList(u);
  if(!can.length) return true;                     // nothing ticked = available for anything
  return can.includes(k);
}
/* is this person available on that weekday? */
function availableOn(u, day, dateStr_){
  if(!u || u.role==="guest") return false;
  if(u.active===false) return false;
  if(hasLeft(u)) return false;
  const mk=String(dateStr_||"").slice(0,7), dd=+String(dateStr_||"").slice(8,10);
  if(mk && dd && notYetHired(u,mk,dd)) return false;      // not employed yet
  if(mk && dd){
    const st=attStatus(u,mk,dd);
    if(st==="A" || st==="V") return false;               // absent or on vacation
  }
  let num=u.number; if(!num && u.role==="manager") num=1;
  const dp=dayPlanFor(day);
  if(num && dp.off.includes(num)) return false;            // day off
  return true;
}
function onEntranceDuty(u, day){
  let num=u.number; if(!num && u.role==="manager") num=1;
  return !!num && dayPlanFor(day).entrance===num;
}
/* Entrance duty takes the person out of activities from 16:00 until 18:30. */
function entranceConflict(u, day, act){
  if(!onEntranceDuty(u,day)) return false;
  const w=actWindow(act);
  if(!w) return true; // unknown time: safer not to create a mistaken assignment
  const dutyStart=16*60, dutyEnd=18*60+30;
  return w.s0 < dutyEnd && w.e0 > dutyStart;
}
/* activities already on this person for that day, to spot clashes and share the load */
function assignedCount(username, day, extra){
  const name=String(username||"").toLowerCase();
  let n=(S.activities||[]).filter(a=>a.day===day &&
    String(a.entertainer||"").toLowerCase().split(/[,;]/).map(x=>x.trim()).includes(name)).length;
  return n+((extra&&extra[username])||0);
}
function timeToMin(hhmm){
  const m=String(hhmm||"").match(/(\d{1,2}):(\d{2})/);
  return m ? (+m[1])*60+(+m[2]) : null;
}
/* Global time formatter used by manager Live Operations and later enhancement layers.
   It MUST live in base scope; keeping it inside a later IIFE caused runtime ReferenceError on login. */
function fmtCountdown(sec){
  sec=Math.max(0,Math.floor(Number(sec)||0));
  const h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), ss=sec%60;
  return (h?String(h).padStart(2,"0")+":":"")+String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");
}
window.fmtCountdown=fmtCountdown;
/* Suggest one person per unassigned activity on a given weekday. */
/* ================= WEATHER =================
   Free open service, no key needed, so it works for guests too.
   Defaults to Hurghada; the manager can set exact coordinates. */
const WMO={0:["wSun","sun"],1:["wSun","sun"],2:["wPartly","cloud"],3:["wCloud","cloud"],
  45:["wFog","cloud"],48:["wFog","cloud"],51:["wDrizzle","rain"],53:["wDrizzle","rain"],55:["wDrizzle","rain"],
  61:["wRain","rain"],63:["wRain","rain"],65:["wRain","rain"],66:["wRain","rain"],67:["wRain","rain"],
  71:["wSnow","snow"],73:["wSnow","snow"],75:["wSnow","snow"],77:["wSnow","snow"],
  80:["wShower","rain"],81:["wShower","rain"],82:["wShower","rain"],85:["wSnow","snow"],86:["wSnow","snow"],
  95:["wStorm","storm"],96:["wStorm","storm"],99:["wStorm","storm"]};
function wmoLabel(code){ const e=WMO[code]; return e?t(e[0]):""; }
function wmoIcon(code){ const e=WMO[code]; return e?e[1]:"sun"; }
function weatherCoords(){
  const st=S.settings||{};
  const lat=parseFloat(st.lat), lon=parseFloat(st.lon);
  return { lat: isNaN(lat)?27.2579:lat, lon: isNaN(lon)?33.8116:lon };   // Hurghada
}
async function loadWeather(force){
  if(S.weatherBusy) return;
  const fresh = S.weather && (Date.now()-S.weather.at < 30*60*1000);      // 30 min cache
  if(fresh && !force) return;
  S.weatherBusy=true;
  const {lat,lon}=weatherCoords();
  const tz=hotelTz()||"auto";
  const url="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+
    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"+
    "&daily=weather_code,temperature_2m_max,temperature_2m_min"+
    "&timezone="+encodeURIComponent(tz)+"&forecast_days=7";
  try{
    const res=await fetch(url);
    if(!res.ok) throw new Error("weather "+res.status);
    const d=await res.json();
    S.weather={at:Date.now(), cur:d.current||null, daily:d.daily||null};
  }catch(e){ S.weather={at:Date.now(), error:true}; }
  S.weatherBusy=false;
  if(S.session && safeToRender()) render();
}
function weatherView(){
  const w=S.weather;
  if(!w || w.error){
    return `<div class="screen fadein">${topBar(t("weatherTab"),"")}
      <div class="empty"><div class="big">${ic("sun",30)}</div>${w?t("weatherFail"):t("loadingMsg")}</div>
      <button class="btn ghost" id="w-reload">${t("close")}</button></div>`;
  }
  const cur=w.cur||{}, dly=w.daily||{};
  const days=(dly.time||[]).map((iso,i)=>({iso,
    code:(dly.weather_code||[])[i], max:(dly.temperature_2m_max||[])[i], min:(dly.temperature_2m_min||[])[i]}));
  return `<div class="screen fadein">
    ${topBar(t("weatherTab"),"")}
    <div class="card wnow">
      <div class="wn-ic">${ic(wmoIcon(cur.weather_code),44)}</div>
      <div class="wn-mid">
        <b class="wn-t">${Math.round(cur.temperature_2m)}°</b>
        <span>${esc(wmoLabel(cur.weather_code))}</span>
        <span class="mini">${t("feelsLike")} ${Math.round(cur.apparent_temperature)}° · ${t("windLbl")} ${Math.round(cur.wind_speed_10m)} km/h</span>
      </div>
    </div>
    <h3 style="margin-top:18px">${ic("calendar",17)} ${t("weatherWeek")}</h3>
    <div class="card wweek">
      ${days.map((d,i)=>{
        const dt=new Date(d.iso+"T12:00:00");
        const lbl=i===0?t("weatherToday"):(t("daysShort")[(dt.getDay()+6)%7]||"");
        return `<div class="ww-row">
          <span class="ww-d">${esc(lbl)}</span>
          <span class="ww-i">${ic(wmoIcon(d.code),19)}</span>
          <span class="ww-x">${esc(wmoLabel(d.code))}</span>
          <span class="ww-t"><b>${Math.round(d.max)}°</b> <i>${Math.round(d.min)}°</i></span>
        </div>`;
      }).join("")}
    </div>
  </div>`;
}
/* small strip for the home screens */
/* ================= PAGE DESIGNER (blocks) =================
   The manager builds pages from blocks, like a simple website builder.
   Every block carries its own style, so no code is ever needed. */
const BLOCK_TYPES=[
  ["heading","blkHeading","pen"],["text","blkText","clipboard"],["image","blkImage","sparkle"],
  ["gallery","blkGallery","grid"],["button","blkButton","check"],["card","blkCard","clipboard"],
  ["list","blkList","check"],["video","blkVideo","sparkle"],["map","blkMap","pin"],
  ["divider","blkDivider","grid"],["spacer","blkSpacer","grid"]
];
const FONT_CHOICES=[["display","fontElegant"],["body","fontModern"]];
function blockDefaults(type){
  const base={id:"b"+Date.now()+Math.floor(Math.random()*999), type,
    align:"left", size:"m", color:"", bg:"", bold:false, font:"body"};
  if(type==="heading") return {...base, text:"", size:"l", font:"display"};
  if(type==="text")    return {...base, text:""};
  if(type==="image")   return {...base, url:"", caption:""};
  if(type==="gallery") return {...base, urls:[]};
  if(type==="button")  return {...base, text:"", url:"", shape:"round", size:"m", align:"center"};
  if(type==="card")    return {...base, title:"", text:"", url:""};
  if(type==="list")    return {...base, text:""};
  if(type==="video")   return {...base, url:""};
  if(type==="map")     return {...base, text:""};
  if(type==="spacer")  return {...base, size:"m"};
  return base;
}
const SIZE_PX={heading:{s:"20px",m:"26px",l:"32px",xl:"40px"},
  text:{s:"13px",m:"15px",l:"17px",xl:"20px"},
  spacer:{s:"10px",m:"22px",l:"40px",xl:"64px"}};
function blockStyle(b){
  const st=[];
  if(b.align) st.push("text-align:"+(b.align==="right"?"end":b.align==="center"?"center":"start"));
  if(b.color) st.push("color:"+b.color);
  if(b.bold) st.push("font-weight:700");
  if(b.font==="display") st.push("font-family:var(--font-display)");
  return st.join(";");
}
function ytEmbed(url){
  const m=String(url||"").match(/(?:youtu\.be\/|v=|embed\/)([A-Za-z0-9_-]{6,})/);
  return m?("https://www.youtube.com/embed/"+m[1]):"";
}
/* Draws one block for the real page */
function renderBlock(b, ix, pageKey){
  const st=blockStyle(b);
  const wrapBg=b.bg?` style="background:${esc(b.bg)};border-radius:var(--r-lg);padding:14px"`:"";
  switch(b.type){
    case "heading":
      return `<div class="pb-b"${wrapBg}><div class="pb-h" style="${st};font-size:${SIZE_PX.heading[b.size]||"26px"}">${esc(b.text||"")}</div></div>`;
    case "text":
      return `<div class="pb-b"${wrapBg}><p class="pb-t" style="${st};font-size:${SIZE_PX.text[b.size]||"15px"}">${esc(b.text||"")}</p></div>`;
    case "image":
      return b.url?`<div class="pb-b"${wrapBg}><img class="pb-img" src="${esc(b.url)}" alt="" loading="lazy" data-pvsingle="${esc(b.url)}">
        ${b.caption?`<p class="mini" style="${st};margin-top:6px">${esc(b.caption)}</p>`:""}</div>`:"";
    case "gallery":
      return (b.urls&&b.urls.length)?`<div class="pb-b"${wrapBg}>${photoStrip(b.urls,pageKey+"-g"+ix)}</div>`:"";
    case "button": {
      const shape={round:"var(--r-md)",pill:"999px",square:"6px"}[b.shape||"round"];
      const pad={s:"9px 16px",m:"13px 22px",l:"17px 30px"}[b.size||"m"];
      const fs={s:"13px",m:"15px",l:"17px"}[b.size||"m"];
      const align=b.align==="left"?"flex-start":b.align==="right"?"flex-end":"center";
      const bg=b.bg||"";
      return `<div class="pb-b" style="display:flex;justify-content:${align}">
        <a class="pb-btn" ${b.url?`href="${esc(b.url)}" target="_blank" rel="noopener"`:""}
          style="border-radius:${shape};padding:${pad};font-size:${fs}${bg?";background:"+esc(bg):""}${b.color?";color:"+esc(b.color):""}">${esc(b.text||"")}</a></div>`;
    }
    case "card":
      return `<div class="pb-b"><div class="card pb-card"${b.bg?` style="background:${esc(b.bg)}"`:""}>
        ${b.title?`<b style="${st}">${esc(b.title)}</b>`:""}
        ${b.text?`<p style="${st}">${esc(b.text)}</p>`:""}
        ${b.url?`<a class="pb-btn sm" href="${esc(b.url)}" target="_blank" rel="noopener">${t("openLink")}</a>`:""}
      </div></div>`;
    case "list": {
      const items=String(b.text||"").split("\n").map(x=>x.trim()).filter(Boolean);
      return items.length?`<div class="pb-b"${wrapBg}><ul class="pb-list" style="${st}">
        ${items.map(i=>`<li>${esc(i)}</li>`).join("")}</ul></div>`:"";
    }
    case "video": {
      const emb=ytEmbed(b.url);
      return emb?`<div class="pb-b"><div class="pb-video"><iframe src="${esc(emb)}" frameborder="0"
        allow="accelerometer;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div></div>`:"";
    }
    case "map": {
      const q=encodeURIComponent(b.text||"");
      return b.text?`<div class="pb-b"><a class="pb-btn" href="https://www.google.com/maps/search/?api=1&query=${q}"
        target="_blank" rel="noopener">${ic("pin",15)} ${esc(b.text)}</a></div>`:"";
    }
    case "divider": return `<div class="pb-b"><hr class="pb-hr"></div>`;
    case "spacer":  return `<div style="height:${SIZE_PX.spacer[b.size]||"22px"}"></div>`;
  }
  return "";
}
function renderBlocks(blocks, pageKey){
  const list=Array.isArray(blocks)?blocks:[];
  if(!list.length) return "";
  return list.map((b,i)=>renderBlock(b,i,pageKey||"pg")).join("");
}
/* ================= PAGE EDITOR SCREEN ================= */
function pbState(){
  if(!S.pb) S.pb={role:"guest", pageId:null, page:null};
  return S.pb;
}
function pbFindPage(role,id){ return (customPages(role)||[]).find(p=>p.id===id)||null; }
function pbOpen(role,id){
  const st=pbState();
  st.role=role;
  if(id){
    const p2=pbFindPage(role,id);
    st.pageId=id;
    st.page=p2?JSON.parse(JSON.stringify(p2)):null;
  } else {
    st.pageId=null;
    st.page={id:"p"+Date.now(), title:"", kind:"page", icon:"pin", url:"", text:"", blocks:[]};
  }
  if(st.page && !Array.isArray(st.page.blocks)) st.page.blocks=[];
  S.tab="pagedesign"; render();
}
async function pbSave(){
  const st=pbState();
  if(!st.page) return;
  if(!String(st.page.title||"").trim()){ toastWarn(t("fieldRequired")); return; }
  const list=(customPages(st.role)||[]).slice();
  const i=list.findIndex(x=>x.id===st.page.id);
  if(i>=0) list[i]=st.page; else list.push(st.page);
  const menu={...(S.settings.menu||{})};
  menu[st.role]={...menuConf(st.role), custom:list};
  try{
    await DB.saveSettings({...S.settings, menu});
    toastOk(t("pbSaved"));
    S.tab="builder"; render();
  }catch(e){ toastErr(t("errSave")); }
}
function pbAdd(type){
  const st=pbState(); if(!st.page) return;
  st.page.blocks.push(blockDefaults(type)); render();
}
function pbMove(id,dir){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const j=i+dir; if(j<0||j>=b.length) return;
  b.splice(j,0,b.splice(i,1)[0]); render();
}
function pbDup(id){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const copy=JSON.parse(JSON.stringify(b[i]));
  copy.id="b"+Date.now()+Math.floor(Math.random()*999);
  b.splice(i+1,0,copy); render();
}
async function pbDel(id){
  if(!await confirmAction({question:t("delBlock"),danger:true})) return;
  const st=pbState();
  st.page.blocks=st.page.blocks.filter(x=>x.id!==id); render();
}
function pageDesignView(){
  const st=pbState();
  if(!st.page) return `<div class="screen fadein">${topBar(t("pageBuilder"),"")}<div class="empty">${t("none")}</div></div>`;
  const pg=st.page;
  return `<div class="screen fadein">
    ${topBar(pg.title||t("pbNewPage"), t("pageBuilder"))}
    <button class="crumb" id="crumb-pb">${ic("back",15)} ${t("setMenus")}</button>
    <div class="card" style="padding:14px">
      <label>${t("pbTitle")}</label><input id="pb-title" value="${esc(pg.title||"")}">
      <label>${t("pbWho")}</label>
      <select id="pb-role">
        ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
          `<option value="${k}" ${st.role===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="pb-addbar">
      <span class="type-meta">${t("pbAddBlock")}</span>
      <div class="pb-types">
        ${BLOCK_TYPES.map(([k,lb,icn])=>`<button class="pb-type" data-pbadd="${k}">
          <span>${ic(icn,16)}</span>${t(lb)}</button>`).join("")}
      </div>
    </div>
    ${pg.blocks.length?pg.blocks.map((b,i)=>`
      <div class="pb-edit">
        <div class="pb-eh">
          <b>${t((BLOCK_TYPES.find(x=>x[0]===b.type)||[,"blkText"])[1])}</b>
          <span class="pb-eacts">
            <button class="bd-b" data-pbup="${b.id}" ${i===0?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b down" data-pbdown="${b.id}" ${i===pg.blocks.length-1?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b" data-pbdup="${b.id}">${ic("plus",13)}</button>
            <button class="bd-b warn" data-pbdel="${b.id}">${ic("trash",13)}</button>
          </span>
        </div>
        ${pbBlockFields(b)}
        <div class="pb-prev">${renderBlock(b,i,"prev")||`<span class="mini">—</span>`}</div>
      </div>`).join("")
      :`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`}
    <button class="btn" id="pb-save" style="margin-top:14px">${ic("check",16)} ${t("save")}</button>
  </div>`;
}
/* the controls for one block */
function pbBlockFields(b){
  const sel=(id,val,opts)=>`<select data-pbf="${b.id}|${id}">${opts.map(([k,lb])=>
    `<option value="${k}" ${String(val)===k?"selected":""}>${t(lb)}</option>`).join("")}</select>`;
  const txt=(id,val,ph)=>`<input data-pbf="${b.id}|${id}" value="${esc(val||"")}" placeholder="${esc(ph||"")}">`;
  const area=(id,val,ph)=>`<textarea data-pbf="${b.id}|${id}" rows="3" placeholder="${esc(ph||"")}">${esc(val||"")}</textarea>`;
  const col=(id,val)=>`<input type="color" data-pbf="${b.id}|${id}" value="${esc(val||"#3E2A1E")}">`;
  const alignSel=sel("align",b.align,[["left","alignLeft"],["center","alignCenter"],["right","alignRight"]]);
  const sizeSel=sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"],["xl","fsXl"]]);
  let content="";
  if(b.type==="heading"||b.type==="text") content=area("text",b.text,t("pbContent"));
  else if(b.type==="list") content=area("text",b.text,t("listItems"));
  else if(b.type==="image") content=`${pbImageField(b,"url")}${txt("caption",b.caption,t("photoCaption"))}`;
  else if(b.type==="gallery") content=pbGalleryField(b);
  else if(b.type==="button") content=`${txt("text",b.text,t("blkButton"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="card") content=`${txt("title",b.title,t("infoTitle"))}${area("text",b.text,t("pbContent"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="video") content=txt("url",b.url,t("videoUrl"));
  else if(b.type==="map") content=txt("text",b.text,t("mapAddr"));
  let style="";
  if(["heading","text","list","card"].includes(b.type))
    style=`<div class="row2"><div><label>${t("fontSizeB")}</label>${sizeSel}</div>
      <div><label>${t("alignLbl")}</label>${alignSel}</div></div>
      <div class="row2"><div><label>${t("fontFamilyB")}</label>${sel("font",b.font,FONT_CHOICES)}</div>
      <div><label>${t("colorLbl")}</label>${col("color",b.color)}</div></div>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:14px;color:var(--ink)">
        <input type="checkbox" style="width:auto" data-pbc="${b.id}|bold" ${b.bold?"checked":""}> ${t("boldLbl")}</label>`;
  else if(b.type==="button")
    style=`<div class="row2"><div><label>${t("btnShape")}</label>
        ${sel("shape",b.shape,[["round","shapeRound"],["pill","shapePill"],["square","shapeSquare"]])}</div>
      <div><label>${t("btnSize")}</label>${sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"]])}</div></div>
      <div class="row2"><div><label>${t("alignLbl")}</label>${alignSel}</div>
      <div><label>${t("bgLbl")}</label>${col("bg",b.bg)}</div></div>`;
  else if(b.type==="spacer") style=`<label>${t("fontSizeB")}</label>${sizeSel}`;
  else if(b.type==="image") style=`<label>${t("alignLbl")}</label>${alignSel}`;
  return content+style;
}
function pbImageField(b,key){
  return `<div class="pedit" id="pbi-${b.id}">
      ${b[key]?`<div class="pedit-it"><img src="${esc(b[key])}" alt="">
        <button class="pedit-rm" type="button" data-pbimgrm="${b.id}|${key}">${ic("close",13)}</button></div>`:""}
    </div>
    <button class="btn sm ghost" type="button" data-pbimgadd="${b.id}|${key}">${ic("plus",14)} ${t("addPhoto")}</button>`;
}
function pbGalleryField(b){
  return `<div class="pedit">
      ${(b.urls||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
        <button class="pedit-rm" type="button" data-pbgrm="${b.id}|${ix}">${ic("close",13)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" type="button" data-pbgadd="${b.id}">${ic("plus",14)} ${t("addPhotos")}</button>`;
}
/* ================= MENU BUILDER SCREEN ================= */
function builderRole(){ return S.sub.builder || "guest"; }
async function saveMenuConf(role, patch){
  const menu={...(S.settings.menu||{})};
  menu[role]={...menuConf(role), ...patch};
  try{ await DB.saveSettings({...S.settings, menu}); toastOk(t("builderSaved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* The page the app opens on, per role — the manager chooses it in the builder. */
function defaultTabFor(role){
  const conf=menuConf(role)||{};
  const want=conf.start;
  if(want){
    const ok=navGroups(role).flatMap(g=>g.items).some(i=>i[0]===want);
    if(ok) return want;
  }
  return role==="manager" ? "dash" : (role==="staff" ? "workday" : "home");
}
function builderView(){
  const role=builderRole();
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{};
  const base=navGroupsBase(role);
  const items=base.flatMap(g=>g.items);
  const order=(conf.order&&conf.order.length)?conf.order:items.map(i=>i[0]);
  const sorted=items.slice().sort((a,b)=>{
    const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
    return (ia<0?999:ia)-(ib<0?999:ib);
  });
  return `<div class="screen fadein">
    ${topBar(t("builderTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 12px">${t("builderHint")}</p>
    <div class="bd-roles">
      ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
        `<button class="bd-role ${role===k?"on":""}" data-bdrole="${k}">${t(lb)}</button>`).join("")}
    </div>
    <label style="margin-top:4px">${t("startPage")}</label>
    <select id="bd-start">
      ${sorted.filter(it=>!hidden.includes(it[0])).map(it=>
        `<option value="${esc(it[0])}" ${conf.start===it[0]?"selected":""}>${esc(names[it[0]]||it[2])}</option>`).join("")}
    </select>
    <p class="mini" style="margin:-4px 0 12px">${t("startPageHint")}</p>
    <div class="bd-sec-head">${t("secTitles")}</div>
    <p class="mini" style="margin:-2px 0 8px">${t("secTitlesHint")}</p>
    <div class="card bd-list">
      ${base.filter(g=>g.key).map(g=>`<div class="bd-it">
        <span class="bd-ic">${ic("grid",17)}</span>
        <span class="bd-nm">${esc((conf.gnames||{})[g.key]||g.head)}${(conf.gnames||{})[g.key]?` <i>${esc(g.head)}</i>`:""}</span>
        <span class="bd-acts">
          <button class="bd-b" data-bdgname="${esc(g.key)}" aria-label="${t("renameGroup")}">${ic("pen",14)}</button>
        </span></div>`).join("")}
    </div>
    <div class="bd-sec-head">${t("menu")}</div>
    <div class="card bd-list">
      ${sorted.map((it,i)=>{
        const id=it[0], off=hidden.includes(id);
        return `<div class="bd-it ${off?"off":""}">
          <span class="bd-ic">${ic(it[1],17)}</span>
          <span class="bd-nm">${esc(names[id]||it[2])}${names[id]?` <i>${esc(it[2])}</i>`:""}</span>
          <span class="bd-acts">
            <button class="bd-b" data-bdup="${esc(id)}" aria-label="${t("moveUp")}" ${i===0?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b down" data-bddown="${esc(id)}" aria-label="${t("moveDown")}" ${i===sorted.length-1?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b" data-bdname="${esc(id)}" aria-label="${t("renameItem")}">${ic("pen",14)}</button>
            <button class="bd-b ${off?"":"on"}" data-bdhide="${esc(id)}" aria-label="${t("hideItem")}">${ic(off?"belloff":"bell",14)}</button>
          </span>
        </div>`;
      }).join("")}
    </div>
    <button class="btn" id="bd-add" style="margin-top:14px">${ic("plus",16)} ${t("addLink")}</button>
    ${(conf.custom&&conf.custom.length)?`<div class="card" style="margin-top:12px">
      ${conf.custom.map(pg=>`<div class="bd-it">
        <span class="bd-ic">${ic(pg.icon||"pin",17)}</span>
        <span class="bd-nm">${esc(pg.title)}<i>${pg.kind==="link"?t("kindLink"):t("kindPage")}</i></span>
        <span class="bd-acts">
          <button class="bd-b" data-bdedit="${esc(pg.id)}">${ic("pen",14)}</button>
          <button class="bd-b warn" data-bddel="${esc(pg.id)}">${ic("trash",14)}</button>
        </span></div>`).join("")}
    </div>`:""}
    <button class="btn ghost" id="bd-reset" style="margin-top:12px">${ic("back",15)} ${t("resetMenu")}</button>
  </div>`;
}
function moveMenuItem(id, dir){
  const role=builderRole(), conf=menuConf(role);
  const items=navGroupsBase(role).flatMap(g=>g.items).map(i=>i[0]);
  let order=(conf.order&&conf.order.length)?conf.order.slice():items.slice();
  items.forEach(k=>{ if(!order.includes(k)) order.push(k); });
  const i=order.indexOf(id); if(i<0) return;
  const j=i+dir; if(j<0||j>=order.length) return;
  order.splice(j,0,order.splice(i,1)[0]);
  saveMenuConf(role,{order});
}
function toggleMenuItem(id){
  const role=builderRole(), conf=menuConf(role);
  const hidden=(conf.hidden||[]).slice();
  const i=hidden.indexOf(id);
  if(i>=0) hidden.splice(i,1); else hidden.push(id);
  saveMenuConf(role,{hidden});
}
function openRenameModal(id){
  const role=builderRole(), conf=menuConf(role);
  const base=navGroupsBase(role).flatMap(g=>g.items).find(i=>i[0]===id);
  const cur=(conf.names||{})[id]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameItem")}</h3>
    <p class="mini">${esc(base?base[2]:id)}</p>
    <input id="rn-v" value="${esc(cur)}" placeholder="${esc(base?base[2]:"")}">
    <button class="btn" id="rn-go">${t("save")}</button>
    <button class="btn ghost" id="rn-x">${t("close")}</button>`);
  wrap.querySelector("#rn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rn-go").onclick=()=>{
    const names={...(conf.names||{})};
    const v=wrap.querySelector("#rn-v").value.trim();
    if(v) names[id]=v; else delete names[id];
    wrap.remove(); saveMenuConf(role,{names});
  };
}
/* Rename a whole menu section — the grey heading above a group of items. */
function openGroupRenameModal(gkey){
  const role=builderRole(), conf=menuConf(role);
  const g=navGroupsBase(role).find(x=>x.key===gkey);
  const cur=(conf.gnames||{})[gkey]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameGroup")}</h3>
    <p class="mini">${esc(g?g.head:gkey)}</p>
    <input id="gn-v" value="${esc(cur)}" placeholder="${esc(g?g.head:"")}">
    <button class="btn" id="gn-go">${t("save")}</button>
    <button class="btn ghost" id="gn-x">${t("close")}</button>`);
  wrap.querySelector("#gn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#gn-go").onclick=()=>{
    const gnames={...(conf.gnames||{})};
    const v=wrap.querySelector("#gn-v").value.trim();
    if(v) gnames[gkey]=v; else delete gnames[gkey];
    wrap.remove(); saveMenuConf(role,{gnames});
  };
}
function openCustomPageModal(pgId){
  const role=builderRole(), conf=menuConf(role);
  const list=(conf.custom||[]);
  const pg=pgId?list.find(x=>x.id===pgId):null;
  const p2=pg||{id:"p"+Date.now(),title:"",kind:"page",url:"",text:"",icon:"pin"};
  const wrap=baseModal(`
    <h3>${ic("plus",20)} ${t("addLink")}</h3>
    <label>${t("linkTitle")}</label><input id="cp-t" value="${esc(p2.title)}">
    <label>${t("linkKind")}</label>
    <select id="cp-k">
      <option value="page" ${p2.kind==="page"?"selected":""}>${t("kindPage")}</option>
      <option value="link" ${p2.kind==="link"?"selected":""}>${t("kindLink")}</option>
    </select>
    <label>${t("linkUrl")}</label><input id="cp-u" value="${esc(p2.url||"")}" placeholder="https://...">
    <label>${t("linkText")}</label><textarea id="cp-x" rows="4">${esc(p2.text||"")}</textarea>
    <button class="btn" id="cp-go">${t("save")}</button>
    ${pg?`<button class="btn warn" id="cp-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=()=>{
    const title=wrap.querySelector("#cp-t").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const url=wrap.querySelector("#cp-u").value.trim();
    if(url && !/^https:\/\//i.test(url)){ toastErr(t("errHttps")); return; }
    const rec={...p2, title, kind:wrap.querySelector("#cp-k").value, url,
      text:wrap.querySelector("#cp-x").value};
    const next=list.filter(x=>x.id!==rec.id).concat([rec]);
    wrap.remove(); saveMenuConf(role,{custom:next});
  };
  const del=wrap.querySelector("#cp-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    wrap.remove(); saveMenuConf(role,{custom:list.filter(x=>x.id!==p2.id)});
  };
}
/* a page the manager created */
function customPageView(id){
  const role=S.session.role;
  const pg=customPages(role).find(p=>p.id===id);
  if(!pg) return `<div class="screen fadein">${topBar(t("customPage"),"")}<div class="empty">${t("none")}</div></div>`;
  const blocks=Array.isArray(pg.blocks)?pg.blocks:[];
  const isMgr=S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(pg.title,"")}
    ${blocks.length?renderBlocks(blocks,"cp"+id):""}
    ${(!blocks.length&&pg.text)?`<div class="card" style="padding:16px"><p style="white-space:pre-wrap;font-size:15px;line-height:1.55">${esc(pg.text)}</p></div>`:""}
    ${(!blocks.length&&pg.url)?`<a class="btn" href="${esc(pg.url)}" target="_blank" rel="noopener"
      style="display:block;text-align:center;margin-top:12px">${ic("back",15)} ${t("openLink")}</a>`:""}
    ${(!blocks.length&&!pg.text&&!pg.url)?`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`:""}
    ${isMgr?`<button class="btn ghost" data-pbedit="${esc(pg.id)}" style="margin-top:16px">${ic("pen",15)} ${t("pbEditPage")}</button>`:""}
  </div>`;
}
/* ================= QR CODE (spread the app) ================= */
function appUrl(){
  try{ return location.origin + location.pathname; }catch(e){ return ""; }
}
function qrView(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data="+encodeURIComponent(url);
  return `<div class="screen fadein">
    ${topBar(t("qrTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 14px">${t("qrHint")}</p>
    <div class="card qrcard">
      <img class="qr-img" src="${esc(img)}" alt="QR" loading="lazy">
      <p class="mini qr-url">${esc(url)}</p>
    </div>
    <button class="btn" id="qr-print" style="margin-top:14px">${ic("download",16)} ${t("qrDownload")}</button>
  </div>`;
}
function openQrPrint(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=900x900&margin=12&data="+encodeURIComponent(url);
  const name=esc(S.settings.name||"Entertainment");
  const w=window.open("","_blank");
  if(!w){ toastErr(t("errSave")); return; }
  w.document.write('<html><head><title>'+name+'</title><meta charset="utf-8">'+
    '<style>body{font-family:system-ui,sans-serif;text-align:center;padding:40px;color:#2B1F16}'+
    'h1{font-size:34px;margin:0 0 6px}p{color:#6b5a4a;margin:0 0 26px;font-size:18px}'+
    'img{width:70%;max-width:420px}small{display:block;margin-top:18px;color:#8a7a6a;word-break:break-all}</style>'+
    '</head><body><h1>'+name+'</h1><p>'+esc(t("qrHint"))+'</p>'+
    '<img src="'+img+'" alt="QR"><small>'+esc(url)+'</small>'+
    '<scr'+'ipt>setTimeout(function(){window.print();},600);<\/scr'+'ipt></body></html>');
  w.document.close();
}
/* ================= MANAGER: WHAT NEEDS YOU ================= */
function attentionItems(){
  const items=[]; const today=todayIndex();
  // activities today that can be booked but nobody has
  const empty=S.activities.filter(a=>a.day===today && (+a.capacity)>0 && seatsTaken(a.id)===0);
  if(empty.length) items.push({n:empty.length, key:"attEmptyAct", tab:"program", tone:"warn"});
  // guest requests still new
  const waiting=(S.requests||[]).filter(r=>r.status==="new");
  if(waiting.length) items.push({n:waiting.length, key:"attWaitReq", tab:"guests", sub:"requests", tone:"bad"});
  // team requests still new
  const sreq=(S.staffReqs||[]).filter(r=>r.status==="new");
  if(sreq.length) items.push({n:sreq.length, key:"attStaffReq", tab:"team", sub:"requests", tone:"bad"});
  // low ratings in the last 7 days
  const weekAgo=Date.now()-7*864e5;
  const low=(S.feedback||[]).filter(f=>(+f.rate||5)<=3 && new Date(f.created_at).getTime()>weekAgo);
  if(low.length) items.push({n:low.length, key:"attLowRate", tab:"guests", sub:"feedback", tone:"bad"});
  return items;
}
function attentionCard(){
  const items=attentionItems();
  if(!items.length) return `<div class="card attn ok"><span class="attn-ic">${ic("check",20)}</span>
    <span>${t("allGood")}</span></div>`;
  return `<div class="card attn">
    <span class="type-meta">${t("attentionHead")}</span>
    <div class="attn-list">${items.map(i=>`
      <button class="attn-it ${i.tone}" data-attn="${i.tab}${i.sub?"|"+i.sub:""}">
        <span class="attn-n">${i.n}</span>
        <span class="attn-lb">${t(i.key)}</span>
        <span class="attn-go">${ic("back",15)}</span>
      </button>`).join("")}</div>
  </div>`;
}
/* ================= MANAGER: TRENDS ================= */
function last7Days(){
  const out=[];
  for(let i=6;i>=0;i--){ const d=new Date(Date.now()-i*864e5); out.push(d); }
  return out;
}
function trendsCard(){
  const days=last7Days();
  const counts=days.map(d=>{
    const k=d.toISOString().slice(0,10);
    return (S.bookings||[]).filter(b=>String(b.created_at||"").slice(0,10)===k).length;
  });
  const max=Math.max(1,...counts);
  // most and least popular activities by real bookings
  const byAct={};
  (S.bookings||[]).forEach(b=>{ byAct[b.activity_id]=(byAct[b.activity_id]||0)+1; });
  const ranked=S.activities.map(a=>({a, n:byAct[a.id]||0})).sort((x,y)=>y.n-x.n);
  const top=ranked.filter(r=>r.n>0).slice(0,3);
  const low=ranked.filter(r=>(+r.a.capacity)>0).slice(-3).reverse();
  return `<div class="sec"><h3>${ic("grid",18)} ${t("trendsHead")}</h3>
    <div class="card trend">
      <span class="type-meta">${t("bookingTrend")} · ${t("last7")}</span>
      <div class="tr-bars">${counts.map((c,i)=>`
        <div class="tr-b"><span style="height:${Math.round(c/max*100)}%"></span>
          <i>${(t("daysShort")[(days[i].getDay()+6)%7]||"").slice(0,2)}</i>
          <u>${c}</u></div>`).join("")}</div>
    </div>
    ${top.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("topActs")}</span>
      ${top.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
    ${low.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("lowActs")}</span>
      ${low.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
  </div>`;
}
/* ================= ENTERTAINER: MY PAGE ================= */
const REQ_TYPES=[["dayoff","reqDayOff"],["problem","reqProblem"],["cannot","reqCannot"],["other","reqOther"]];
function reqTypeLabel(k){ const f=REQ_TYPES.find(x=>x[0]===k); return f?t(f[1]):k; }
function myStaffReqs(){
  const me=S.session?S.session.username:"";
  return (S.staffReqs||[]).filter(r=>r.username===me);
}
function myFeedbackList(){
  const me=S.session?S.session.username:"";
  return (S.feedback||[]).filter(f=>String(f.by_user||"")===me);
}
/* The entertainer's own page: attendance, ratings and a way to reach the manager */
function myPageView(){
  const mk=currentAttMonth(), me=S.session;
  const user=(S.users||[]).find(u=>u.username===me.username)||{username:me.username,display_name:me.name,number:me.number};
  const tot=attTotals(user,mk);
  const fb=myFeedbackList();
  const avg=fb.length ? Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10 : 0;
  const reqs=myStaffReqs();
  const n=monthDays(mk);
  const strip=Array.from({length:n},(_,i)=>{
    const d=i+1;
    if(isFutureDay(mk,d)) return `<span class="ms-d future" title="${d}">·</span>`;
    if(notYetHired(user,mk,d) || leftBefore(user,mk,d)) return `<span class="ms-d notyet" title="${d}">N</span>`;
    const st=attStatus(user,mk,d);
    return `<span class="ms-d s-${st}" title="${d}">${st}</span>`;
  }).join("");
  return `<div class="screen fadein">
    ${topBar(t("myAttendance"), monthLabel(mk))}
    <div class="att-head">
      <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button>
      <b class="att-month">${esc(monthLabel(mk))}</b>
      <button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button>
    </div>
    <div class="card attsum">
      <div class="as-row">
        <div class="as-n p"><b>${tot.P}</b><span class="mini">${t("workDays")}</span></div>
        <div class="as-n o"><b>${tot.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${tot.A}</b><span class="mini">${t("attTotalsA")}</span></div>
      </div>
      <div class="ms-strip">${strip}</div>
      <p class="mini" style="margin:8px 0 0">${t("attLegend")}</p>
    </div>

    <div class="sec"><h3>${ic("star",18)} ${t("myFeedback")}</h3>
      ${fb.length?`<div class="card">
        <div class="mf-top"><b class="mf-avg">${avg}</b><span class="mini">${t("avgRate")} · ${fb.length}</span></div>
        ${fb.slice(0,6).map(f=>`<div class="mf-row">
          <span class="mf-rate">${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</span>
          <span class="mf-c">${esc(f.comment||"")}</span>
          <span class="mini">${esc(f.nationality||"")} · ${fmtDate(f.created_at)}</span>
        </div>`).join("")}
      </div>`:`<div class="card"><p class="mini" style="padding:4px 2px">${t("noMyFeedback")}</p></div>`}
    </div>

    <div class="sec"><h3>${ic("chat",18)} ${t("myRequestsTeam")}</h3>
      <button class="btn" id="sr-new" style="margin-bottom:10px">${ic("plus",16)} ${t("askManager")}</button>
      ${reqs.length?`<div class="card">${reqs.map(r=>`
        <div class="sr-row">
          <div class="sr-mid"><b>${esc(reqTypeLabel(r.type))}</b>
            <span>${esc(r.detail||"")}</span>
            ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
            ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):r.status==="done"?t("done"):t("statusNew")}</span>
        </div>`).join("")}</div>`:""}
    </div>
  </div>`;
}
/* An entertainer can ask the manager to change their profile — they cannot edit it. */
function openProfileChangeModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("changeRequest")}</h3>
    <p class="mini">${t("profileReadOnly")}</p>
    <label>${t("whatToChange")}</label><textarea id="pc-d" rows="4"></textarea>
    <button class="btn" id="pc-go">${t("send")}</button>
    <button class="btn ghost" id="pc-x">${t("close")}</button>`);
  wrap.querySelector("#pc-x").onclick=()=>wrap.remove();
  wrap.querySelector("#pc-go").onclick=async ()=>{
    const detail=wrap.querySelector("#pc-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:"other", detail:t("changeRequest")+": "+detail, the_date:"", status:"new"});
      wrap.remove(); toastOk(t("reqSentMgr")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openStaffReqModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("newTeamReq")}</h3>
    <label>${t("taskType")}</label>
    <select id="sr-type">${REQ_TYPES.map(([k,lbl])=>`<option value="${k}">${t(lbl)}</option>`).join("")}</select>
    <label>${t("reqDetail")}</label><textarea id="sr-d" rows="3"></textarea>
    <label>${t("reqDateOpt")}</label><input id="sr-date" placeholder="${esc(t("reqDateOpt"))}">
    <button class="btn" id="sr-send">${t("send")}</button>
    <button class="btn ghost" id="sr-x">${t("close")}</button>`);
  wrap.querySelector("#sr-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sr-send").onclick=async ()=>{
    const detail=wrap.querySelector("#sr-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:wrap.querySelector("#sr-type").value, detail,
        the_date:wrap.querySelector("#sr-date").value.trim(), status:"new"});
      wrap.remove(); toastOk(t("reqSent")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= MANAGER: TEAM REQUESTS ================= */
function teamRequestsInner(){
  const list=(S.staffReqs||[]);
  if(!list.length) return `<div class="card"><p class="mini" style="padding:4px 2px">${t("noTeamReqs")}</p></div>`;
  return `<div class="card">${list.map(r=>`
    <div class="sr-row">
      <div class="sr-mid"><b>${esc(r.display_name||r.username)} · ${esc(reqTypeLabel(r.type))}</b>
        <span>${esc(r.detail||"")}</span>
        ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
        <span class="mini">${fmtDate(r.created_at)}</span>
        ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
      ${r.status==="new"?`<span class="sr-acts">
          <button class="btn sm" data-reqok="${r.id}">${t("reqApprove")}</button>
          <button class="btn sm ghost" data-reqno="${r.id}">${t("reqDecline")}</button>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`
        :`<span class="sr-acts">
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):t("done")}</span>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`}
    </div>`).join("")}</div>`;
}
async function answerStaffReq(id, status){
  const wrap=baseModal(`
    <h3>${status==="ok"?t("reqApprove"):t("reqDecline")}</h3>
    <label>${t("reqReply")}</label><textarea id="ar-r" rows="3"></textarea>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-x">${t("close")}</button>`);
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-go").onclick=async ()=>{
    try{
      await DB.updateStaffReq(id,{status, reply:wrap.querySelector("#ar-r").value.trim()});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= HOTEL INFO (guest) ================= */
function hotelInfoList(){ return Array.isArray(S.settings.hotelInfo)?S.settings.hotelInfo:[]; }
/* An entry can have several opening times (restaurant 3x, entertainment 3 operations).
   Older entries stored a single `time` string — both shapes work. */
function infoTimes(it){
  if(Array.isArray(it.times)) return it.times.filter(Boolean);
  return it.time?[it.time]:[];
}
/* an entry can hold several pictures; older entries had one `photo` */
function infoPics(it){
  if(Array.isArray(it.photos) && it.photos.length) return it.photos.filter(Boolean);
  return it.photo?[it.photo]:[];
}
function hotelInfoView(){
  const list=hotelInfoList();
  const isMgr=S.session && S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(t("hotelInfoTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("hotelInfoHint")}</p>
    ${list.length?`<div class="infogrid">${list.map((it,i)=>`
      <div class="info-card" ${isMgr?`data-infoedit="${i}"`:""}>
        ${(()=>{const pics=infoPics(it);
          return pics.length===1
            ? `<img class="info-img" src="${esc(pics[0])}" alt="" loading="lazy" data-pv="info${i}|0">`
            : photoStrip(pics,"info"+i);})()}
        <div class="info-body">
          <b>${esc(it.title||"")}</b>
          ${it.value?`<span class="info-val">${esc(it.value)}</span>`:""}
          <div class="info-meta">
            ${infoTimes(it).map(tm=>`<span>${mi("clock")}${esc(tm)}</span>`).join("")}
            ${it.place?`<span>${mi("pin")}${esc(it.place)}</span>`:""}
          </div>
        </div>
        ${isMgr?`<span class="info-go">${ic("pen",15)}</span>`:""}
      </div>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noInfo")}</div>`}
    ${isMgr?`<button class="btn" id="info-add" style="margin-top:14px">${ic("plus",16)} ${t("addInfo")}</button>`:""}
  </div>`;
}
function openInfoModal(idx){
  const list=hotelInfoList();
  const editing=(typeof idx==="number");
  const it=editing?list[idx]:{title:"",value:"",time:"",place:"",photo:""};
  const wrap=baseModal(`
    <h3>${ic("pin",20)} ${editing?t("infoTitle"):t("addInfo")}</h3>
    ${photoListEditor("hi", infoPics(it))}
    <label>${t("infoTitle")}</label><input id="hi-t" value="${esc(it.title||"")}" placeholder="WiFi">
    <label>${t("infoValue")}</label><textarea id="hi-v" rows="3">${esc(it.value||"")}</textarea>
    <label>${t("timesLbl")}</label>
    <div id="hi-times">
      ${(infoTimes(it).length?infoTimes(it):[""]).map(tm=>`
        <div class="time-row"><input class="hi-t1" value="${esc(tm)}" placeholder="07:00 - 10:00">
          <button class="btn sm ghost hi-rm" type="button">${ic("close",14)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" id="hi-addtime" style="margin-bottom:10px">${ic("plus",14)} ${t("addTime")}</button>
    <label>${t("infoPlace")}</label><input id="hi-place" value="${esc(it.place||"")}" placeholder="Main restaurant">
    <button class="btn" id="hi-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="hi-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="hi-x">${t("close")}</button>`);
  wrap.querySelector("#hi-x").onclick=()=>wrap.remove();
  let hiPics=infoPics(it).slice();
  wirePhotoList(wrap,"hi",()=>hiPics,l=>{ hiPics=l; });
  const timesBox=wrap.querySelector("#hi-times");
  const wireRemove=()=>wrap.querySelectorAll(".hi-rm").forEach(b=>b.onclick=()=>{
    if(wrap.querySelectorAll(".time-row").length>1) b.parentElement.remove();
    else b.parentElement.querySelector(".hi-t1").value="";
  });
  wireRemove();
  const addT=wrap.querySelector("#hi-addtime");
  if(addT) addT.onclick=()=>{
    const row=document.createElement("div");
    row.className="time-row";
    row.innerHTML='<input class="hi-t1" placeholder="07:00 - 10:00"><button class="btn sm ghost hi-rm" type="button">'+ic("close",14)+'</button>';
    timesBox.appendChild(row); wireRemove();
  };
  wrap.querySelector("#hi-save").onclick=async ()=>{
    const title=wrap.querySelector("#hi-t").value.trim();
    const value=wrap.querySelector("#hi-v").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const times=[...wrap.querySelectorAll(".hi-t1")].map(el=>el.value.trim()).filter(Boolean);
    const rec={title, value, times,
      place:wrap.querySelector("#hi-place").value.trim(),
      photos:hiPics, photo:hiPics[0]||""};
    const next=hotelInfoList().slice();
    if(editing) next[idx]=rec; else next.push(rec);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  const del=wrap.querySelector("#hi-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    const next=hotelInfoList().filter((_,i)=>i!==idx);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= PHOTO GALLERY ================= */
function galleryView(){
  const isMgr=S.session && S.session.role==="manager";
  const isStaff=S.session && S.session.role==="staff";
  const canAdd=isMgr||isStaff;
  const list=(S.photos||[]);
  return `<div class="screen fadein">
    ${topBar(t("galleryTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("galleryHint")}</p>
    ${canAdd?`<button class="btn" id="ph-add" style="margin-bottom:14px">${ic("plus",16)} ${t("addPhoto")}</button>`:""}
    ${list.length?`<div class="photogrid">${list.map((ph,i)=>`
      <figure class="photo-it">
        <img src="${esc(ph.url)}" alt="${esc(ph.caption||"")}" loading="lazy" data-pv="gal|${i}">
        ${ph.caption?`<figcaption>${esc(ph.caption)}</figcaption>`:""}
        ${isMgr?`<button class="ph-del" data-phdel="${ph.id}" aria-label="${t("deleteActivity")}">${ic("trash",14)}</button>`:""}
      </figure>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("noPhotos")}</div>`}
  </div>`;
}
function openPhotoModal(){
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${t("addPhoto")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("photoCaption")}</label><input id="ph-cap" placeholder="${esc(t("photoCaption"))}">
    <button class="btn" id="ph-save">${t("save")}</button>
    <button class="btn ghost" id="ph-x">${t("close")}</button>`);
  let url="";
  wirePhotoPicker(wrap, ()=>url, v=>{ url=v; });
  wrap.querySelector("#ph-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ph-save").onclick=async ()=>{
    if(!url){ toastWarn(t("uploadPhoto")); return; }
    try{
      await DB.addPhoto({url, caption:wrap.querySelector("#ph-cap").value.trim(),
        day:todayIndex(), created_by:S.session.username||S.session.name||""});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= FEEDBACK -> REVIEW ================= */
function reviewLinks(){
  const st=S.settings;
  return [["google",st.google],["tripadvisor",st.tripadvisor],["holidaycheck",st.holidaycheck]]
    .filter(([k,v])=>v&&/^https?:\/\//i.test(v));
}
/* After a happy rating, invite the guest to post it publicly. */
function openReviewInvite(rate){
  const links=reviewLinks();
  if(!links.length || S.settings.reviewAsk===false) return;
  if(rate<4) return;                       // unhappy guests are never pushed outside
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("thankYou")}</h3>
    <p class="mini">${t("shareExp")}</p>
    <div style="margin-top:14px">
      ${links.map(([k,v])=>`<a class="btn" href="${esc(v)}" target="_blank" rel="noopener"
        style="display:block;text-align:center;margin-bottom:8px">${k==="google"?"Google":k==="tripadvisor"?"Tripadvisor":"HolidayCheck"}</a>`).join("")}
    </div>
    <button class="btn ghost" id="rv-x">${t("reviewLater")}</button>`);
  wrap.querySelector("#rv-x").onclick=()=>wrap.remove();
}
/* ================= TEAM ATTENDANCE =================
   P = present · O = day off · A = absent
   Normal days are worked out from the duty plan, so only real
   exceptions are stored. Tapping a cell cycles P -> O -> A -> auto. */
const ATT_CYCLE=["P","O","A","V"];
function monthKey(d){ d=d||hotelNow(); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"); }
function currentAttMonth(){ return S.attMonth || monthKey(hotelNow()); }
function monthDays(mk){
  const [y,m]=mk.split("-").map(Number);
  return new Date(y, m, 0).getDate();               // last day of that month
}
function monthLabel(mk){
  const [y,m]=mk.split("-").map(Number);
  const names=t("months");
  const nm=(Array.isArray(names)&&names[m-1])?names[m-1]:String(m);
  return nm+" "+y;
}
function dateStr(mk,day){ return mk+"-"+String(day).padStart(2,"0"); }
function shiftMonth(mk,delta){
  const [y,m]=mk.split("-").map(Number);
  const d=new Date(y, m-1+delta, 1);
  return monthKey(d);
}
function weekdayOf(mk,day){
  const [y,m]=mk.split("-").map(Number);
  return (new Date(y,m-1,day).getDay()+6)%7;        // 0 = Monday
}
/* what the plan says for this person on this date */
/* Before someone's hire date they simply were not employed — that shows as N
   and is never counted as present, day off or absent. */
/* Someone who left the hotel keeps every day they worked; days after their
   leaving date are blank, and their number is free for the next person. */
function hasLeft(user){ return !!(user && (user.archived || String(user.left_date||"").trim())); }
function leftBefore(user, mk, day){
  const ld=String(user && user.left_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(ld)) return false;
  return dateStr(mk,day) > ld;
}
function notYetHired(user, mk, day){
  const hd=String(user && user.hire_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(hd)) return false;
  return dateStr(mk,day) < hd;
}
function attAuto(user, mk, day){
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return "N";
  if(isAttOnly(user)) return "P";        // not on the weekly rota — she marks them herself
  let num=user.number; if(!num && user.role==="manager") num=1;
  if(!num) return "P";
  const dp=dayPlanFor(weekdayOf(mk,day));
  return dp.off.includes(num) ? "O" : "P";
}
/* the value actually shown: a manual mark wins, otherwise the plan */
/* Days in the future have not happened yet — they are blank, never counted. */
function isFutureDay(mk, day){ return dateStr(mk,day) > hotelDateStr(); }
function daysSoFar(mk){
  const n=monthDays(mk);
  const today=hotelDateStr();
  if(mk > today.slice(0,7)) return 0;           // month not started
  if(mk < today.slice(0,7)) return n;           // month already finished
  return Math.min(n, +today.slice(8,10));        // current month -> up to today
}
function attStatus(user, mk, day){
  if(notYetHired(user,mk,day)) return "N";      // had not started yet
  if(leftBefore(user,mk,day)) return "N";       // already finished
  if(isFutureDay(mk,day)){
    /* nothing is assumed about a future day, but a holiday she has already
       planned should be visible */
    const dfut=dateStr(mk,day);
    const planned=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===dfut);
    return planned ? planned.status : "";
  }
  const d=dateStr(mk,day);
  const row=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===d);
  return row ? row.status : attAuto(user,mk,day);
}
function attIsManual(user, mk, day){
  const d=dateStr(mk,day);
  return S.staffAtt.some(x=>x.username===user.username && String(x.date).slice(0,10)===d);
}
/* one tap: P -> O -> A -> automatic */
function attNext(user, mk, day){
  if(isFutureDay(mk,day)) return undefined;     // cannot mark a day that has not come
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return undefined; // not employed that day
  if(!attIsManual(user,mk,day)) return "P";
  const cur=attStatus(user,mk,day);
  const i=ATT_CYCLE.indexOf(cur);
  return (i<0 || i===ATT_CYCLE.length-1) ? null : ATT_CYCLE[i+1];
}
/* Totals across the whole team for the month */
function attMonthTotals(mk){
  const team=attTeamFor(mk); const sum={P:0,O:0,A:0,V:0,N:0};
  team.forEach(u=>{ const x=attTotals(u,mk); sum.P+=x.P; sum.O+=x.O; sum.A+=x.A; sum.V+=x.V; sum.N+=x.N; });
  return {...sum, people:team.length, days:daysSoFar(mk),
          working:sum.P, avg:team.length?Math.round(sum.P/team.length*10)/10:0};
}
/* The attendance sheet still lists people who left, so their record is kept.
   Everywhere else they are gone. */
function attTeam(){ return attTeamFor(currentAttMonth()); }
function attTeamFor(mk){
  return (S.users||[]).filter(u=>{
      if(u.role!=="staff" && u.role!=="manager" && u.role!=="attendance") return false;
      const hd=String(u.hire_date||"").slice(0,7);
      if(hd && hd>mk) return false;               // had not started in that month
      if(!hasLeft(u)) return true;
      const ld=String(u.left_date||"").slice(0,7);
      return !ld || ld>=mk;                       // show them in the months they worked
    })
    .slice().sort((a,b)=>(a.number||99)-(b.number||99));
}
/* month totals per person */
function attTotals(user, mk){
  const n=daysSoFar(mk); const c={P:0,O:0,A:0,V:0,N:0,days:n};
  for(let d=1;d<=n;d++){ const st=attStatus(user,mk,d); if(c[st]!==undefined) c[st]++; }
  c.days=n-c.N;                                  // only days they were actually employed
  return c;
}
function monthAttInner(){
  const __vacBtn=`<div class="att-tools">
    <button class="btn sm ghost" id="att-vac">${ic("sun",15)} ${t("setVacation")}</button>
    <button class="btn sm ghost" id="att-only">${ic("user",15)} ${t("addAttOnly")}</button>
  </div>`;
  const mk=currentAttMonth(), n=monthDays(mk), team=attTeamFor(mk);
  const todayMk=monthKey(hotelNow()), todayD=hotelNow().getDate();
  const head=Array.from({length:n},(_,i)=>{
    const d=i+1,wd=weekdayOf(mk,d),isToday=(mk===todayMk&&d===todayD);
    return `<th class="${wd>=5?"we":""} ${isToday?"td":""}">${d}<span>${(t("daysShort")[wd]||"").slice(0,2)}</span></th>`;
  }).join("");
  const rows=team.map(u=>{
    const tot=attTotals(u,mk),attTag=isAttOnly(u)?` <span class="att-only-tag">${t("attOnlyTag")}</span>`:"";
    const cells=Array.from({length:n},(_,i)=>{
      const d=i+1;
      if(notYetHired(u,mk,d)||leftBefore(u,mk,d))return `<td><span class="att-c notyet">N</span></td>`;
      if(isFutureDay(mk,d)){
        const st=attStatus(u,mk,d);
        return st?`<td><span class="att-c s-${st} planned" title="${esc(t("plannedAhead"))}">${st}</span></td>`:`<td><span class="att-c future">·</span></td>`;
      }
      const st=attStatus(u,mk,d),manual=attIsManual(u,mk,d);
      return `<td><button class="att-c s-${st} ${manual?"man":"auto"}" data-satt="${esc(u.username)}|${mk}|${d}" title="${esc(t("att"+st)||st)}">${st}</button></td>`;
    }).join("");
    return `<tr><th class="att-name${isAttOnly(u)?" tapname":""}"${isAttOnly(u)?` data-attedit="${u.id}"`:""}><b>${esc(u.display_name||u.username)}</b><span class="mini">${u.number?"#"+u.number:""}${attTag}</span></th>${cells}
      <td class="att-tot"><span class="s-P">${tot.P}</span></td><td class="att-tot"><span class="s-O">${tot.O}</span></td><td class="att-tot"><span class="s-A">${tot.A}</span></td><td class="att-tot"><span class="s-V">${tot.V}</span></td></tr>`;
  }).join("");
  const mt=attMonthTotals(mk);
  return `${__vacBtn}<div class="att-head">
    <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button><b class="att-month">${esc(monthLabel(mk))}</b><button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button></div>
    <p class="mini att-legend">P = present · O = day off · A = absent · V = vacation · N = not counted</p>
    ${team.length?`<div class="card attsum"><span class="type-meta">${t("monthTotals")}</span>
      <div class="as-row as-row-v625">
        <div class="as-n total"><b>${mt.people}</b><span class="mini">${t("totalTeam")}</span></div>
        <div class="as-n p"><b>${mt.working}</b><span class="mini">${t("workingToday")} days</span></div>
        <div class="as-n o"><b>${mt.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${mt.A}</b><span class="mini">${t("attTotalsA")}</span></div>
        <div class="as-n vac"><b>${mt.V}</b><span class="mini">${t("attV")} days</span></div>
      </div>
      <p class="mini" style="margin:10px 0 0">${t("avgPerPerson")}: <b>${mt.avg}</b> ${t("workDays").toLowerCase()} · ${t("countedDays")}: <b>${mt.days}</b>/${monthDays(mk)}</p></div>`:""}
    ${team.length?`<div class="att-scroll"><table class="att-table"><thead><tr><th class="att-name"></th>${head}<th class="att-tot">P</th><th class="att-tot">O</th><th class="att-tot">A</th><th class="att-tot">V</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<div class="card"><p class="mini">—</p></div>`}
    <button class="btn" id="att-export" style="margin-top:14px">${ic("download",16)} ${t("attExport")}</button>`;
}

/* ================= DAILY QUIZ ================= */
/* one definition, on the hotel clock */
function todayISO(){ return hotelDateStr(); }
function quizForToday(audience){
  const today=todayISO();
  return (S.quizzes||[]).find(q=>q.audience===audience && String(q.quiz_date).slice(0,10)===today && q.active!==false)||null;
}
function myQuizKey(){
  if(!S.session) return "";
  return S.session.role==="guest" ? String(S.session.room||"") : String(S.session.username||"");
}
function myQuizReply(quizId){
  const me=myQuizKey();
  return (S.quizReplies||[]).find(r=>r.quiz_id===quizId && String(r.who)===me)||null;
}
/* The card guests and entertainers see */
function quizView(){
  const aud = S.session.role==="guest" ? "guest" : "staff";
  const q = quizForToday(aud);
  if(!q){
    return `<div class="screen fadein">
      ${topBar(t("quizTab"),"")}
      <div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("quizNone")}</div>
    </div>`;
  }
  const mine=myQuizReply(q.id);
  return `<div class="screen fadein">
    ${topBar(t("quizTab"),"")}
    <div class="card quizcard">
      <span class="type-meta">${t("quizToday")}</span>
      <h3 class="quiz-q">${esc(q.question)}</h3>
      ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
      ${mine?`<div class="quiz-done">${ic("check",18)} <div><b>${t("quizDone")}</b>
          <span class="mini">${t("quizMine")}: ${esc(mine.answer)}</span></div></div>`
        :`<textarea id="qz-ans" rows="3" placeholder="${esc(t("quizAnswerPh"))}" style="margin-top:12px"></textarea>
          <button class="btn" id="qz-send">${ic("sparkle",16)} ${t("quizSend")}</button>`}
    </div>
  </div>`;
}
async function submitQuizAnswer(){
  const q=quizForToday(S.session.role==="guest"?"guest":"staff"); if(!q) return;
  if(myQuizReply(q.id)){ toastWarn(t("quizAlready")); return; }
  const el=$("#qz-ans"); const val=el?el.value.trim():"";
  if(!val){ toastWarn(t("fieldRequired")); return; }
  try{
    await DB.addQuizReply({quiz_id:q.id, who:myQuizKey(), who_name:S.session.name||"",
      audience:S.session.role==="guest"?"guest":"staff", answer:val});
    toastOk(t("quizDone")); render();
  }catch(e){ toastErr(t("errSave")); }
}
/* Manager: write the question and read every answer */
function quizCenterView(){
  const today=todayISO();
  const gq=quizForToday("guest"), sq=quizForToday("staff");
  const block=(aud,q)=>{
    const replies=q?(S.quizReplies||[]).filter(r=>r.quiz_id===q.id):[];
    return `<div class="sec">
      <h3>${ic("sparkle",18)} ${aud==="guest"?t("quizForGuest"):t("quizForStaff")}</h3>
      ${q?`<div class="card quizcard">
        <h3 class="quiz-q">${esc(q.question)}</h3>
        ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
        ${q.answer_key?`<p class="mini"><b>${t("quizKey")}:</b> ${esc(q.answer_key)}</p>`:""}
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="btn sm ghost" data-quizedit="${q.id}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-quizdel="${q.id}">${ic("trash",14)}</button>
        </div>
      </div>
      <h3 style="margin-top:14px">${t("quizReplies")} (${replies.length})</h3>
      ${replies.length?`<div class="card qr-card">${replies.map(r=>`
        <div class="qr-row"><span class="qr-who">${esc(r.who_name||r.who)}${r.audience==="guest"?` · ${esc(r.who)}`:""}</span>
          <span class="qr-ans">${esc(r.answer)}</span>
          <span class="mini">${fmtDate(r.created_at)}</span></div>`).join("")}</div>`
        :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNoReplies")}</p></div>`}`
      :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNone")}</p>
          <button class="btn sm" data-quiznew="${aud}" style="margin-top:10px">${ic("plus",14)} ${t("quizNew")}</button></div>`}
    </div>`;
  };
  return `<div class="screen fadein">
    ${topBar(t("quizCenter"),today)}
    ${hubBack()}
    ${block("guest",gq)}
    ${block("staff",sq)}
  </div>`;
}
function openQuizModal(quiz, audience){
  const editing=!!quiz;
  const q=quiz||{audience:audience||"guest",question:"",hint:"",answer_key:"",quiz_date:todayISO(),active:true};
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${editing?t("quizQuestion"):t("quizNew")}</h3>
    <label>${t("quizFor")}</label>
    <select id="qz-aud">
      <option value="guest" ${q.audience==="guest"?"selected":""}>${t("quizForGuest")}</option>
      <option value="staff" ${q.audience==="staff"?"selected":""}>${t("quizForStaff")}</option>
    </select>
    <label>${t("quizQuestion")}</label>
    <textarea id="qz-q" rows="3">${esc(q.question)}</textarea>
    <label>${t("quizHint")}</label><input id="qz-h" value="${esc(q.hint||"")}">
    <label>${t("quizKey")}</label><input id="qz-k" value="${esc(q.answer_key||"")}">
    <button class="btn" id="qz-save">${t("save")}</button>
    <button class="btn ghost" id="qz-x">${t("close")}</button>`);
  wrap.querySelector("#qz-x").onclick=()=>wrap.remove();
  wrap.querySelector("#qz-save").onclick=async ()=>{
    const rec={audience:wrap.querySelector("#qz-aud").value,
      question:wrap.querySelector("#qz-q").value.trim(),
      hint:wrap.querySelector("#qz-h").value.trim(),
      answer_key:wrap.querySelector("#qz-k").value.trim(),
      quiz_date:q.quiz_date||todayISO(), active:true};
    if(!rec.question){ toastWarn(t("fieldRequired")); return; }
    if(editing) rec.id=q.id;
    try{ await DB.saveQuiz(rec); wrap.remove(); toastOk(t("quizSaved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function busView(){
  const empty=!(S.buses||[]).length;
  return `<div class="screen fadein">
    ${topBar(t("busSchedule"),"")}
    ${hubBack()}
    ${empty && S.session.role!=="manager"?`<div class="empty"><div class="big">${ic("bus",30)}</div>${t("noBusTimes")}</div>`:`
      <div class="bus-grid">
        ${busColumn("toHotel", 1)}
        ${busColumn("toHouse", -1)}
      </div>`}
  </div>`;
}
/* Manager edits who is off and who has entrance duty for a weekday.
   Saved as an override on top of the standard rotation. */
function openDutyModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("clipboard",20)} ${t("editDayOff")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b>${dayIsCustom(day)?` · ${t("customDay")}`:` · ${t("standardDay")}`}</p>
    <label style="margin-top:10px">${t("selectDayOff")}</label>
    <div class="duty-list">
      ${roster.map(r=>`<label class="duty-it">
        <input type="checkbox" class="duty-off" value="${r.n}" ${dp.off.includes(r.n)?"checked":""}>
        <span class="duty-n">${r.n}</span>
        <span class="duty-nm">${esc(r.name||r.role)}</span></label>`).join("")}
    </div>
    <button class="btn" id="duty-save">${t("save")}</button>
    ${dayIsCustom(day)?`<button class="btn ghost" id="duty-reset">${ic("back",15)} ${t("resetDefault")}</button>`:""}
    <button class="btn ghost" id="duty-x">${t("close")}</button>`);
  wrap.querySelector("#duty-x").onclick=()=>wrap.remove();
  wrap.querySelector("#duty-save").onclick=async ()=>{
    const off=[...wrap.querySelectorAll(".duty-off")].filter(b=>b.checked).map(b=>+b.value);
    const ov={off, entrance: dp.entrance};      // entrance is set in Assignments
    const all={...(S.settings.dayOverrides||{})};
    all[String(day)]=ov;
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  const rst=wrap.querySelector("#duty-reset");
  if(rst) rst.onclick=async ()=>{
    const all={...(S.settings.dayOverrides||{})};
    delete all[String(day)];
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openBusModal(bus, dir){
  const editing=!!bus;
  const b=bus||{direction:dir||"toHotel",time:"08:00",note:""};
  const wrap=baseModal(`
    <h3>${ic("bus",20)} ${editing?t("editBus"):t("addBus")}</h3>
    <label>${t("busDirection")}</label>
    <select id="bs-dir">
      <option value="toHotel" ${b.direction==="toHotel"?"selected":""}>${t("busToHotel")}</option>
      <option value="toHouse" ${b.direction==="toHouse"?"selected":""}>${t("busToHouse")}</option>
    </select>
    <label>${t("busTimeLbl")}</label>
    <input id="bs-time" value="${esc(b.time||"")}" placeholder="08:00">
    <label>${t("busNoteLbl")}</label>
    <input id="bs-note" value="${esc(b.note||"")}" placeholder="${esc(t("busNoteHint"))}">
    <button class="btn" id="bs-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="bs-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="bs-x">${t("close")}</button>`);
  wrap.querySelector("#bs-x").onclick=()=>wrap.remove();
  wrap.querySelector("#bs-save").onclick=async ()=>{
    const rec={direction:wrap.querySelector("#bs-dir").value,
      time:wrap.querySelector("#bs-time").value.trim(),
      note:wrap.querySelector("#bs-note").value.trim(),
      sort:busMinutes(wrap.querySelector("#bs-time").value.trim())};
    if(!rec.time){ return; }
    if(editing) rec.id=b.id;
    await DB.saveBus(rec);
    wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#bs-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delBusQ"),danger:true})) return;
    try{ await DB.deleteBus(b.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function dayChips(){
  const today=todayIndex();
  const sel=(typeof S.planDay==="number")?S.planDay:today;
  return `<div class="daychips">${t("daysShort").map((d,i)=>`<button class="daychip ${sel===i?"on":""} ${i===today?"istoday":""}" data-planday="${i}">${d}</button>`).join("")}</div>`;
}
function myWorkDayView(){
  const num=S.session.number;
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  if(!num){
    return `<div class="screen fadein">
      ${topBar(t("myWorkDay"),S.session.name)}
      ${dayChips()}
      <div class="empty"><div class="big">${ic("users",30)}</div>${t("noNumber")}</div>
      ${workdayUnifiedTimeline(day,[])}
      ${workdayFeedbackCard()}
      ${dayPlanStandards(day)}
    </div>`;
  }
  const info=personDayInfo(num,day);
  const unavailableToday=info.isOff||info.isVacation||info.isAbsent;
  const myActs=(unavailableToday?[]:S.activities.filter(a=>a.day===day && canSeeGuests(a))).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  const liveAct = isToday(day) ? (myActs.find(a=>activityStatus(a)==="live") || myActs.find(a=>activityStatus(a)==="todo") || myActs[myActs.length-1]) : null;
  const photoRing = liveAct ? statusRing(liveAct) : "";
  const photoBlock = `<div class="wd-photo">
      <div class="wd-av avring ${photoRing}">${S.session.photo?`<img src="${esc(S.session.photo)}" alt="">`:`<span>${esc(String(S.session.name||"?").trim().charAt(0).toUpperCase())}</span>`}
        <span class="wd-num">${num}</span></div>
      <div class="wd-who"><b>${esc(S.session.name)}</b>
        <span class="mini">${esc(roleForNumber(num))}</span>
        ${liveAct?`<span style="margin-top:4px">${statusPill(liveAct)} <span class="mini">${esc(liveAct.name)}</span></span>`:""}</div>
    </div>`;
  let banner="";
  if(info.isVacation){
    banner=`<div class="wd-banner off">${ic("sun",22)} You are on vacation today — enjoy your holiday ☀️</div>`;
  }else if(info.isAbsent){
    banner=`<div class="wd-banner off">${ic("user",22)} You are marked absent today.</div>`;
  }else if(info.isOff){
    const nd=(day+1)%7, nu=info.u, tomorrowWorking=nu?availableOn(nu,nd,(typeof dayDutyDate==="function"?dayDutyDate(nd):assignDateStr(nd))):true;
    banner=`<div class="wd-banner off">${ic("sun",22)} Have a nice day — today is your day off. Enjoy${tomorrowWorking?", but sleep early — you have work tomorrow :)":" your day off :)"}</div>`;
  }else if(info.isEntrance){
    banner=`<div class="wd-banner entrance">${ic("door",20)} ${t("youHaveEntrance")} · ${esc(info.entranceWindow)}</div>`;
  }
  return `<div class="screen fadein workday-clean">
    ${topBar(t("myWorkDay"),"#"+num+" · "+S.session.name)}
    ${dayChips()}
    ${photoBlock}
    ${banner}
    ${info.makeupForMe?`<div class="wd-banner makeup">${ic("star",18)} ${t("makeupPractice")}: ${esc(makeupText(info.makeupForMe))}</div>`:""}
    ${info.isDJ?`<div class="wd-banner dj">${ic("bell",18)} ${t("djSchedule")}: ${esc(info.djNote)}</div>`:""}
    ${workdayUnifiedTimeline(day,myActs)}
    ${workdayCompactInfo(day)}
    ${workdayFeedbackCard()}
    ${dayPlanStandards(day)}
  </div>`;
}
function taskDueMinutes(x){
  if(!x || !x.due) return 24*60+1;
  const d=new Date(String(x.due).replace(" ","T"));
  if(isNaN(d.getTime())) return 24*60+1;
  return d.getHours()*60+d.getMinutes();
}
function taskBelongsToDay(x,day){
  if(!x || !(x.assigned_to===S.session.username || !x.assigned_to || x.assigned_to==="team")) return false;
  if(["verified"].includes(taskStatus(x))) return false;
  const target=assignDateStr(day);
  if(x.due){
    const d=new Date(String(x.due).replace(" ","T"));
    if(!isNaN(d.getTime())) return localDateKey(d)===target;
  }
  return isToday(day) && ["new","accepted","progress"].includes(taskStatus(x));
}
function workdayUnifiedTimeline(day,acts){
  const activityItems=(acts||[]).map(a=>({kind:"activity",sort:timeToMin(a.time)??9999,a}));
  const taskItems=(S.tasks||[]).filter(x=>taskBelongsToDay(x,day)).map(x=>({kind:"task",sort:taskDueMinutes(x),x}));
  const items=activityItems.concat(taskItems).sort((a,b)=>a.sort-b.sort);
  return `<div class="sec workday-yourday"><h3>${ic("clock",18)} ${t("yourDay")}</h3>
    <p class="mini wd-sub">Activities and manager tasks in one place.</p>
    ${items.length?`<div class="tlx unified">${items.map(it=>{
      if(it.kind==="task"){
        const x=it.x, st=taskStatus(x), over=taskIsOverdue(x);
        const due=x.due?new Date(String(x.due).replace(" ","T")):null;
        const tm=due&&!isNaN(due.getTime())?fmtTime(due.toISOString()):"";
        return `<div class="tlx-row task ${st} ${over?"overdue":""}">
          <span class="tlx-mark">${ic("check",12)}</span>
          <div class="tlx-body task-body" data-taskopen="${x.id}">
            <span class="eyebrow">${t("tasks")}</span>
            <b>${esc(x.title||x.type||t("tasks"))}</b>
            <span class="mini">${tm?esc(tm)+(x.location?" · "+esc(x.location):""):(x.location?esc(x.location):"")}</span>
            ${x.desc?`<span class="mini">${esc(x.desc)}</span>`:""}
            <span class="task-inline-status">${taskStatusLabel(st)}</span>
          </div>
        </div>`;
      }
      const a=it.a, st=isToday(day)?activityStatus(a):"todo", booked=seatsTaken(a.id);
      return `<div class="tlx-row ${st}">
        <span class="tlx-mark">${st==="done"?ic("check",13):(st==="live"?"":"")}</span>
        <div class="tlx-body" data-actopen="${esc(String(a.id))}">
          ${st==="live"?`<span class="eyebrow tlx-now">${t("nowLbl")}</span>`:""}
          <span class="eyebrow">${t("activities")||"Activity"}</span>
          <b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" · "+esc(a.location):""}</span>
          ${booked?`<span class="mini">${booked} ${t("registered")}</span>`:""}
        </div>
      </div>`;
    }).join("")}</div>`:`<div class="empty compact-empty">${t("noneToday")}</div>`}
  </div>`;
}
function workdayCompactInfo(day){
  const dp=dayPlanFor(day);
  const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
    .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
  return `<div class="sec wd-dayinfo"><h3>${ic("calendar",18)} ${t("dayInfoSec")}</h3>
    <div class="card wd-info-compact">
      <div><span>${t("dressCode")}</span><b>${esc(dp.dress||"—")}</b></div>
      <div><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>${dp.showTime?`<small>${esc(dp.showTime)}</small>`:""}</div>
      <div><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
      <div><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
      ${evs.length?`<div class="wide"><span>${t("eventsToday")}</span><b>${evs.map(e=>esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])+" · "+esc(e.name)).join("<br>")}</b></div>`:""}
    </div>
  </div>`;
}
/* Collecting guest feedback is a daily job, so it sits inside the work day
   rather than behind a menu item they would have to go looking for. */
function workdayFeedbackCard(){
  const me=(S.session&&S.session.username)||"";
  const mine=(S.feedback||[]).filter(f=>String(f.by_user||"")===String(me))
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const today=mine.filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    return ts && !isNaN(ts.getTime()) && localDateKey(ts)===localDateKey(new Date());
  });
  return `<div class="sec wd-feedback-compact">
    <div class="wd-fb-head"><div><h3>${ic("star",18)} ${t("fbMyFeedback")}</h3><p class="mini">${today.length} ${t("today")} · ${mine.length} ${t("feedback")}</p></div>
      <button class="btn sm" id="btn-addfb">＋ ${t("fbNew")}</button></div>
  </div>`;
}
/* full day detail: theme, dress, timings, show — used by staff + manager */
/* The day's special events (day events + parties) pulled from the real programme */
function staffFeedbackView(){
  const mine=S.feedback.filter(f=>f.by_user===S.session.username);
  return `<div class="screen fadein">
    ${topBar(t("feedback"),S.session.name)}
    <button class="btn" id="btn-addfb" style="margin:0 0 14px">\uFF0B ${t("fbNew")}</button>
    ${mine.length?`<p class="mini" style="margin:-4px 0 8px">${t("fbTapHint")}</p>
      <div class="card">${mine.map(fbRowHtml).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("star",30)}</div>${t("noMyFeedback")}</div>`}
  </div>`;
}
function chatThreadScreen(){
  const isStaff=String(S.chatRoom).startsWith("staff:");
  let title,sub;
  if(isStaff){ const un=S.chatRoom.slice(6); const u=S.users.find(x=>x.username===un);
    title=(u&&u.display_name)||un; sub=t("staff"); }
  else { title=accountName(S.chatRoom); sub=t("room")+" "+S.chatRoom; }
  return `<div class="screen fadein">
    <div class="top">
      <div class="who" style="display:flex;align-items:center;gap:10px">
        <button class="iconbtn" id="btn-chatback" aria-label="back">${ic("back",20)}</button>
        <div><h2 style="font-size:22px">${esc(title)}</h2><p>${esc(sub)}</p></div>
      </div>
    </div>
    ${chatTools(S.chatRoom)}
    ${threadView(S.chatRoom,"team")}
  </div>`;
}
/* Tidying a conversation: pick a few messages, or empty it completely. */
function chatSelOn(){ return Array.isArray(S.chatSel); }
function chatSelHas(id){ return chatSelOn() && S.chatSel.includes(id); }
function chatTools(room){
  if(!S.session || S.session.role!=="manager") return "";
  const total=(S.messages||[]).filter(m=>m.room===room).length;
  if(!total) return "";
  if(!chatSelOn()){
    return `<div class="chat-tools">
      <button class="btn sm ghost" id="ct-select">${ic("check",14)} ${t("selectMsgs")}</button>
      <button class="btn sm ghost warn" id="ct-clear">${ic("trash",14)} ${t("clearChat")}</button>
    </div>`;
  }
  const n=S.chatSel.length;
  return `<div class="chat-tools sel">
    <span class="ct-n">${n} ${t("selectedWord")}</span>
    <button class="btn sm ghost" id="ct-all">${n===total?t("selectNone"):t("selectAll")}</button>
    <button class="btn sm warn" id="ct-del" ${n?"":"disabled"}>${ic("trash",14)} ${t("delete")}</button>
    <button class="btn sm ghost" id="ct-cancel">${t("cancelBtn")}</button>
  </div>`;
}
function staffChatInbox(){
  const staff=S.users.filter(u=>u.role==="staff");
  const rows=staff.map(u=>{
    const room="staff:"+u.username;
    const ms=S.messages.filter(m=>m.room===room);
    const last=ms[ms.length-1];
    const unread=ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length;
    return {u,room,last,unread,ts:last?Date.parse(last.created_at):0};
  }).sort((a,b)=>b.ts-a.ts);
  return `<div class="chatlist">
    ${rows.map(c=>`<div class="card" data-staffchat="${esc(c.u.username)}">
      <div class="mb-av" style="width:44px;height:44px;flex:none">${esc((c.u.display_name||c.u.username).trim().charAt(0).toUpperCase())}</div>
      <div style="min-width:0;flex:1">
        <div class="nm">${esc(c.u.display_name||c.u.username)}</div>
        <div class="lastm">${c.last?esc(c.last.text):"—"}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
        ${c.last?`<span class="mini">${fmtTime(c.last.created_at)}</span>`:""}
        ${c.unread?`<span class="badge">${c.unread}</span>`:""}
      </div>
    </div>`).join("")||`<div class="empty"><div class="big">${ic("users",34)}</div>${t("none")}</div>`}
  </div>`;
}
/* A room name starting with "staff:" is an entertainer thread — it belongs
   in Team, never in the guest inbox. */
function isStaffRoom(room){ return String(room||"").startsWith("staff:"); }
function chatInboxInner(){
  const rooms={};
  S.messages.filter(m=>!isStaffRoom(m.room)).forEach(m=>{ (rooms[m.room]=rooms[m.room]||[]).push(m); });
  const list=Object.entries(rooms).map(([room,ms])=>({room,last:ms[ms.length-1],
    unread:ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length}))
    .sort((a,b)=>new Date(b.last.created_at)-new Date(a.last.created_at));
  return `<div class="chatlist">
      ${list.length?list.map(c=>`<div class="card" data-chatroom="${esc(c.room)}">
        <div style="min-width:0">
          <div class="nm">${esc(accountName(c.room))} <span class="mini">· ${t("room")} ${esc(c.room)}</span></div>
          <div class="lastm">${esc(c.last.text)}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
          <span class="mini">${fmtTime(c.last.created_at)}</span>
          ${c.unread?`<span class="badge">${c.unread}</span>`:""}
        </div>
      </div>`).join(""):`<div class="empty"><div class="big">${ic("chat",34)}</div>${t("noMessages")}</div>`}
    </div>`;
}
function bookingsView(title){
  return `<div class="screen fadein">
    ${topBar(title,t("days")[S.day])}
    ${bookingsInner()}
  </div>`;
}
function bookingsInner(){
  const isMgr=S.session.role==="manager";
  let acts=S.activities.filter(a=>a.day===S.day);
  if(!isMgr) acts=acts.filter(a=>canSeeGuests(a));
  return dayTabs() + (acts.length?acts.sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>{
    const bks=bookingsFor(a.id);
    const visible=canSeeGuests(a);
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:${visible&&bks.length?8:0}px;gap:8px">
        <h4 style="font-size:17px;min-width:0">${visible?"":mi("lock")}${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></h4>
        <span class="pill">${a.capacity>0?seatsTaken(a.id)+"/"+a.capacity:bks.length+" "+t("guests")}</span></div>
      ${visible?bks.map(b=>`<div class="booking-line">
        <span style="min-width:0" ${isMgr&&accountForRoom(b.room)?`data-bkguest="${accountForRoom(b.room).id}"`:""}><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}${isMgr&&b.nationality?` · ${esc(b.nationality)}`:""}${isMgr&&b.phone?` · ${esc(b.phone)}`:""}
          ${b.created_at?`<br><span class="mini">${whenLabel(b.created_at)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="pill">${((+b.adults)||0)+((+b.children)||0)} ${t("personsShort")}${b.status==="waitlist"?" · …":""}</span>
          ${isMgr?`<button class="btn sm ghost" data-bkedit="${b.id}" aria-label="${t("editBooking")}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-bkdel="${b.id}" aria-label="${t("removeBooking")}">${ic("close",14)}</button>`:""}
        </span></div>`).join(""):""}
    </div>`;}).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
/* ---------------- manager (full access — manager role only) ---------------- */
function managerView(){
  if(S.tab==="dash") return dashView();
  if(S.tab==="req") return requirementsView();
  if(S.tab==="program"){
    const inner = S.sub.program==="tickets" ? managerTicketsInner()
      : S.sub.program==="performance" ? performanceAttendanceInner636()
      : managerActsInner();
    return `<div class="screen fadein">
      ${topBar(t("manage"),S.session.name)}
      ${arrangeBtn("program")}
      ${subTabs("program",[["acts",t("activities")],["tickets",t("tickets")],["performance","Shows / Events Attendance"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="guests"){
    const sub=S.sub.guests;
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    let inner="";
    if(sub==="history") inner=(typeof window.guestHistoryInnerV619==="function" ? window.guestHistoryInnerV619() : `<div class="empty">Guest history is loading…</div>`);
    else if(sub==="rooms") inner=roomsInner();
    else if(sub==="crm") inner=guestCrmInner();
    else if(sub==="bookings") inner=bookingsInner();
    else if(sub==="tickets") inner=(typeof window.guestTicketsManagerInnerV620==="function" ? window.guestTicketsManagerInnerV620() : `<div class="empty">Tickets are loading…</div>`);
    else if(sub==="chat") inner=chatInboxInner();
    else if(sub==="feedback") inner=feedbackInner();
    else inner=requestsInner();
    const gTabs=[["crm",t("guestCrm")],["rooms",t("rooms")],["bookings",t("bookings")],["tickets",t("tickets")],
                 ["chat",t("guestChatTab")],["requests",t("requests")],["feedback",t("feedback")],["history","Guest history"]];
    return `<div class="screen fadein">
      ${topBar(t("guestsTab"),S.session.name)}
      ${arrangeBtn("guests")}
      ${subTabs("guests",gTabs)}
      ${inner}
    </div>`;
  }
  if(String(S.tab||"").startsWith("g360:")) return guest360View(S.tab.slice(5));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="dayplan") return managerDayPlanView();
  if(S.tab==="bus") return busView();
  if(S.tab==="quiz") return quizCenterView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  if(S.tab==="qr") return qrView();
  if(S.tab==="weather") return weatherView();
  if(S.tab==="assign") return assignView();
  if(S.tab==="builder") return builderView();
  if(S.tab==="pagedesign") return pageDesignView();
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(S.tab==="settings") return settingsHubView();
  if(String(S.tab||"").startsWith("set:")){
    const k=S.tab.slice(4);
    if(k==="theme")    return setThemeView();
    if(k==="publictext") return setPublicExperienceView639();
    if(k==="brand")    return setBrandView();
    if(k==="features") return setFeaturesView();
    if(k==="location") return setLocationView();
    if(k==="links")    return setLinksView();
    if(k==="advanced") return setAdvancedView();
    if(k==="notif")    return setNotifView();
    return settingsHubView();
  }
  if(S.tab==="team"){
    let sub=S.sub.team;
    if(["tasks","profiles"].includes(sub)) sub=S.sub.team="accounts";  // moved to Assignments
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    const inner = sub==="requests" ? teamRequestsInner() : sub==="monthatt" ? monthAttInner() : sub==="attendance" ? attendanceInner()
      : sub==="payroll" ? payrollManagerInner630() : sub==="chat" ? staffChatInbox() : accountsInner();
    return `<div class="screen fadein">
      ${topBar(t("teamTab"),S.session.name)}
      ${arrangeBtn("team")}
      ${subTabs("team",[["accounts",t("teamAccounts")],["chat",t("teamChatTab")],["requests",t("teamRequests")],["monthatt",t("monthAtt")],["attendance",t("attendance")],["payroll","Payroll"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="ai") return aiView();
  return dashView();   // unknown tab: go home, never Settings
}
/* Totals for the chosen day + the button to change duty */
function dutyBar(day){
  const st=dayDutyStats(day);
  const names=list=>(list||[]).map(u=>esc(u.display_name||u.username)).join(", ")||"—";
  return `<div class="card dutybar">
    <div class="db-nums db-nums-five">
      <div class="db-n"><b>${st.total}</b><span class="mini">${t("totalTeam")}</span></div>
      <div class="db-n ok"><b>${st.workingCount}</b><span class="mini">${t("workingToday")}</span></div>
      <div class="db-n off"><b>${st.offCount}</b><span class="mini">${t("dayOffToday")}</span></div>
      <div class="db-n absent"><b>${st.absentCount}</b><span class="mini">${t("attA")}</span></div>
      <div class="db-n vac"><b>${st.vacationCount}</b><span class="mini">${t("attV")}</span></div>
    </div>
    <div class="db-meta">
      <span class="mini">${st.date}</span>
      <span class="mini">${t("dayOff")}: ${names(st.off)}</span>
      ${st.absentCount?`<span class="mini">${t("attA")}: ${names(st.absent)}</span>`:""}
      ${st.vacationCount?`<span class="mini">${t("attV")}: ${names(st.vacation)}</span>`:""}
      ${dayIsCustom(day)?`<span class="db-tag">${t("customDay")}</span>`:""}
    </div>
    <button class="btn sm" data-dutyedit="${day}">${ic("pen",14)} ${t("editDayOff")}</button>
  </div>`;
}
/* ---- Day Plan sections she can reorder herself, no code ---- */
const DAYPLAN_SECTIONS=["info","times","team","standards"];
/* ---- Arrange this page: every manager page she can rearrange herself ----
   Pages built from cards list their sections; pages built from pills list
   their sub-tabs. The same button and the same modal handle both. */
const PAGE_SECTIONS={
  dayplan: ["team","standards"],
  dash:    ["attention","dayinfo","wholeday","tonight","live","export","stats","feedback","nations","activities","trends"],
  guests:  ["crm","rooms","bookings","tickets","chat","requests","feedback","history"],
  team:    ["accounts","chat","requests","monthatt","attendance","payroll"],
  program: ["acts","tickets","performance"],
  settings:["set:theme","set:publictext","set:brand","builder","set:features","set:notif","set:links",
            "bus","set:location","export","set:advanced"]
};
const SECTION_LABELS={
  dayplan: {team:"teamAccounts",standards:"standardsHead"},
  dash:    {attention:"attentionHead",dayinfo:"dayInfoSec",wholeday:"wholeDay",tonight:"tonightLbl",live:"liveOps",export:"exportData",stats:"overview",feedback:"fbAnalytics",
            nations:"natStats",activities:"activities",trends:"trendsHead"},
  guests:  {crm:"guestCrm",rooms:"rooms",bookings:"bookings",tickets:"tickets",chat:"guestChatTab",
            requests:"requests",feedback:"feedback",history:"Guest history"},
  team:    {accounts:"teamAccounts",chat:"teamChatTab",requests:"teamRequests",
            monthatt:"monthAtt",attendance:"attendance",payroll:"Payroll"},
  program: {acts:"activities",tickets:"tickets",performance:"Shows / Events Attendance"},
  settings:{"set:theme":"setTheme","set:publictext":"Public experience","set:brand":"setBrand","builder":"setMenus",
            "set:features":"setFeatures","set:notif":"setNotif","set:links":"setLinksT",
            "bus":"busItem","set:location":"setLocation","export":"setData","set:advanced":"setAdvanced"}
};
function sectionLabel(pageKey,k){ const m=SECTION_LABELS[pageKey]||{}; return m[k]?t(m[k]):k; }
function pageHidden(pageKey){
  const all=(S.settings && S.settings.pageHidden) || {};
  let hidden=(all[pageKey]||[]).slice();
  // V6.19.3 one-time migration: stale saved Guest layouts could hide the newly-added Tickets tab.
  // Until the migration is recorded, Tickets must remain visible. Afterwards normal Arrange Page control resumes.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193)) hidden=hidden.filter(k=>k!=="tickets");
  return hidden;
}
function pageOrder(pageKey,withHidden){
  const def=PAGE_SECTIONS[pageKey]||[];
  const all=(S.settings && S.settings.pageOrder) || {};
  let saved=all[pageKey];
  if(!saved && pageKey==="dayplan") saved=(S.settings && S.settings.dayPlanOrder);  // the older name
  const kept=(saved||[]).filter(k=>def.includes(k));
  let out=kept.concat(def.filter(k=>!kept.includes(k)));
  // V6.19.3 one-time migration: older/stale saved Guest layouts may already contain Tickets
  // in the wrong position, or may have hidden it. Force the intended location once.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193) && out.includes("tickets")){
    out=out.filter(k=>k!=="tickets");
    const bi=out.indexOf("bookings");
    out.splice(bi>=0?bi+1:Math.min(3,out.length),0,"tickets");
  }
  if(pageKey==="dash" && !(S.settings&&S.settings.dashboardDayOpsMigrationV626)){
    out=out.filter(k=>k!=="dayinfo"&&k!=="wholeday");
    const ai=out.indexOf("attention"),at=ai>=0?ai+1:0;
    out.splice(at,0,"dayinfo","wholeday");
  }
  if(!withHidden){ const h=pageHidden(pageKey); out=out.filter(k=>!h.includes(k)); }
  return out.length?out:def.slice();
}
function dayPlanOrder(){ return pageOrder("dayplan"); }
function arrangeBtn(pageKey){
  if(!S.session || S.session.role!=="manager") return "";
  if(!PAGE_SECTIONS[pageKey]) return "";
  return `<button class="btn sm ghost arrange-b" data-arrange="${pageKey}">${ic("grid",14)} ${t("arrangeSections")}</button>`;
}
function renderParts(pageKey,parts){
  return pageOrder(pageKey).map(k=>parts[k]?parts[k]():"").join("");
}
/* Everything that happens today, split into morning / afternoon / evening. */
/* Turn whatever is written in the entertainer field into a real name. */
function entertainerName(raw){
  const v=String(raw||"").trim();
  if(!v) return "";
  return v.split(/\s*[,;\/]\s*/).map(part=>{
    const p=part.trim(); if(!p) return "";
    const pl=p.toLowerCase();
    const hit=(S.users||[]).find(u=>
      String(u.display_name||"").toLowerCase()===pl ||
      String(u.username||"").toLowerCase()===pl ||
      String(u.number||"")===p.replace(/^#/,"") ||
      String(u.employee_id||"")===p ||
      String(u.phone||"").replace(/\s/g,"")===p.replace(/\s/g,"")
    );
    return hit ? (hit.display_name||hit.username) : p;
  }).filter(Boolean).join(", ");
}
/* is this the logged-in entertainer's own activity? */
function isMineAct(a){
  if(!S.session || S.session.role!=="staff") return false;
  const me=String(S.session.name||"").toLowerCase();
  const un=String(S.session.username||"").toLowerCase();
  return String(a && a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
    .map(x=>x.trim()).some(x=>x && (x===me || x===un || entertainerName(x).toLowerCase()===me));
}
function dayTimeline(day){
  const items=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>({a,slot:operationSlotFromMinutes(timeToMin(a.time))}))
    .filter(x=>["morning","afternoon","evening"].includes(x.slot))
    .sort((x,y)=>(timeToMin(x.a.time)||0)-(timeToMin(y.a.time)||0));
  const slots=[
    {k:"morning",label:"10:00 – 12:30"},
    {k:"afternoon",label:"15:00 – 17:30"},
    {k:"evening",label:"19:30 – 23:00"}
  ];
  return slots.map(sl=>{
    const rows=items.filter(x=>x.slot===sl.k).map(x=>x.a);
    return `<div class="tl-block">
      <div class="tl-head"><span class="tl-dot ${sl.k}"></span>${t(sl.k+"Part")}
        <span class="mini" style="margin-left:6px">${sl.label}</span><span class="tl-n">${rows.length}</span></div>
      ${rows.length?rows.map(x=>{
        const c=normCat(x), who=entertainerName(x.entertainer);
        const type=c==="mAdult"?"":(catLabel(c)||c);
        return `<div class="tl-row ${x._tag?("is-"+x._tag):""}${isMineAct(x)?" mine":""}">
          <span class="tl-t">${esc(x.time||"")}</span>
          <span class="tl-x"><b>${esc(x.name)}</b>${x.location?`<span class="mini">${esc(x.location)}</span>`:""}
            ${who?`<span class="mini who">${esc(who)}</span>`:""}</span>
          ${type?`<span class="tl-tag">${esc(type)}</span>`:""}
        </div>`;
      }).join(""):`<p class="mini tl-empty">${t("noneToday")}</p>`}
    </div>`;
  }).join("");
}
function dayPlanInfoCard(day){
  const dp=dayPlanFor(day);
  return `<div class="sec"><h3>${ic("calendar",18)} ${esc(t("days")[dp.day]||dp.name)}</h3>
    <div class="card daycard">
      <div class="dc-grid">
        <div class="dc-cell"><span>${t("restaurantTheme")}</span><b>${esc(dp.theme)}</b></div>
        <div class="dc-cell"><span>${t("dressCode")}</span><b>${esc(dp.dress)}</b></div>
        <div class="dc-cell"><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>
          ${dp.showTime?`<i class="mini">${esc(dp.showTime)}${dp.showLoc?" · "+esc(dp.showLoc):""}</i>`:""}</div>
        <div class="dc-cell"><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
        <div class="dc-cell"><span>${t("dayOff")}</span><b>${personTags(dp.off)||"—"}</b></div>
        <div class="dc-cell"><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
        <div class="dc-cell wide"><span>${t("eventsToday")}</span>
          ${(()=>{
            const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
              .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
            if(!evs.length) return `<b>—</b>`;
            return evs.map(e=>`<b class="ev-line">${esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])} · ${esc(e.name)}${e.location?` <i class="mini">${esc(e.location)}</i>`:""}</b>`).join("");
          })()}</div>
        <div class="dc-cell"><span>${t("practiceHead")}</span>
          <b>${dp.practice?t("practiceDays"):(dp.makeup?t("makeupPractice"):"—")}</b>
          ${dp.practice?`<i class="mini">${esc(t("practiceWindow"))}</i>`
            :(dp.makeup?`<i class="mini">${esc(makeupText(dp.makeup))}</i>`:"")}</div>
      </div>
    </div>
  </div>`;
}
function dayPlanTeamCard(day){
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const mk=currentAttMonth(), ds=assignDateStr(day), dd=+ds.slice(8,10);
  const isThisMonth=ds.slice(0,7)===mk;
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n]; const info=personDayInfo(n,day);
    let status="", cls="";
    const st = (u && isThisMonth) ? attStatus(u,mk,dd) : "";
    if(st==="A"){ status=t("attA"); cls="absent"; }        // marked absent
    else if(st==="V"){ status=t("attV"); cls="vac"; }      // on holiday
    else if(info.isOff){ status=t("dayOff"); cls="off"; }
    roster.push({n,u,role:roleForNumber(n),status,cls});
  }
  const away=roster.filter(r=>r.cls==="absent").length;
  const onHol=roster.filter(r=>r.cls==="vac").length;
  return `<div class="sec"><h3>${ic("users",18)} ${t("teamAccounts")}
      ${away?`<span class="hd-chip absent">${away} ${t("attA")}</span>`:""}
      ${onHol?`<span class="hd-chip vac">${onHol} ${t("attV")}</span>`:""}</h3>
    <div class="card rostercard">
      ${roster.map(r=>`<div class="roster-row ${r.cls}">
        <span class="rnum">${r.u&&r.u.photo?`<img src="${esc(r.u.photo)}" alt="">`:r.n}</span>
        <span class="rinfo"><b>${esc(r.u?(r.u.display_name||r.u.username):r.role)}</b>
          <span class="mini">#${r.n} · ${esc(r.role)}${r.u?"":" · —"}</span></span>
        ${r.status?`<span class="rstat ${r.cls}">${esc(r.status)}</span>`:`<span class="rstat working">${ic("check",14)}</span>`}
      </div>`).join("")}
    </div>
  </div>`;
}
function dayPlanStandards(day){
  const dp=dayPlanFor(day);
  const rows=DAILY_STANDARDS.map(r=>{
    let note=r.nk?t(r.nk):"";
    if(r.morning){ note = dp.practice ? t("practiceInline") : ""; }
    return `<div class="std-row"><span class="std-t">${esc(r.time)}</span>
      <span class="std-x"><b>${esc(t(r.k))}</b>${note?`<span class="mini"> · ${esc(note)}</span>`:""}</span></div>`;
  }).join("");
  return `<div class="sec"><h3>${ic("clock",18)} ${t("standardsHead")}</h3>
    <div class="card">${rows}</div></div>`;
}
function dayPlanTimes(day){
  return `<div class="sec"><h3>${ic("clock",18)} ${t("wholeDay")}</h3>
    <div class="card tlcard">${dayTimeline(day)}</div></div>`;
}
function managerDayPlanView(){
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  const dp=dayPlanFor(day);
  // roster: numbers 1-10; manager account -> slot #1, numbered staff -> their slot
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n];
    const info=personDayInfo(n,day);
    let status="", cls="";
    if(info.isOff){ status=t("dayOff"); cls="off"; }   // entrance duty lives in Assignments
    else { status=""; cls=""; }
    roster.push({n,u,role:roleForNumber(n),status,cls,info});
  }
  const parts={
    team:      ()=>dayPlanTeamCard(day),
    standards: ()=>dayPlanStandards(day)
  };
  return `<div class="screen fadein">
    ${topBar(t("dayPlan"),(t("days")[dp.day]||dp.name)+" · "+dp.theme)}
    ${dayChips()}
    ${dutyBar(day)}
    ${arrangeBtn("dayplan")}
    ${renderParts("dayplan",parts)}
  </div>`;
}
/* Move the sections of this page around — no code, just up and down. */
function openArrangeModal(pageKey){
  pageKey=pageKey||"dayplan";
  if(!PAGE_SECTIONS[pageKey]) return;
  let order=pageOrder(pageKey,true);
  let hidden=pageHidden(pageKey);
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("arrangeSections")}</h3>
    <p class="mini">${t("arrangeAnyHint")}</p>
    <div id="ar-box"></div>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-reset">${t("resetDefault")}</button>
    <button class="btn ghost" id="ar-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#ar-box");
  const paint=()=>{
    box.innerHTML=order.map((k,i)=>{
      const off=hidden.includes(k);
      return `<div class="ar-it" style="${off?"opacity:.45":""}">
      <span class="ar-nm">${esc(sectionLabel(pageKey,k))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-arup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-ardown="${i}" ${i===order.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b ${off?"":"on"}" data-arhide="${esc(k)}" aria-label="${off?t("showSection"):t("hideSection")}">${ic(off?"belloff":"bell",14)}</button>
      </span></div>`;}).join("");
    box.querySelectorAll("[data-arup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.arup; [order[i-1],order[i]]=[order[i],order[i-1]]; paint();
    });
    box.querySelectorAll("[data-ardown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.ardown; [order[i+1],order[i]]=[order[i],order[i+1]]; paint();
    });
    box.querySelectorAll("[data-arhide]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.arhide, i=hidden.indexOf(k);
      if(i>=0) hidden.splice(i,1);
      else if(order.length-hidden.length>1) hidden.push(k);   // never hide the last one
      paint();
    });
  };
  paint();
  const save=async (ord,hid)=>{
    const po={...((S.settings&&S.settings.pageOrder)||{})}; po[pageKey]=ord;
    const ph={...((S.settings&&S.settings.pageHidden)||{})}; ph[pageKey]=hid;
    const next={...S.settings, pageOrder:po, pageHidden:ph};
    if(pageKey==="dayplan") next.dayPlanOrder=ord;             // keep the old field in step
    try{ await DB.saveSettings(next); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-reset").onclick=()=>save(PAGE_SECTIONS[pageKey].slice(),[]);
  wrap.querySelector("#ar-go").onclick=()=>save(order,hidden);
}
function feedbackInner(){
  const list=S.feedback||[];
  const avg=fbAvgAll(list);
  return `<div class="row2" style="margin-bottom:12px">
      <button class="btn" id="btn-addfb">\uFF0B ${t("fbNew")}</button>
      <button class="btn ghost" id="btn-fbexport">${ic("download",15)} ${t("fbExport")}</button>
    </div>
    ${S.session && S.session.role==="manager"
      ? `<button class="btn ghost sm" id="btn-fbdepts" style="margin:0 0 12px">${ic("grid",14)} ${t("fbDeptsEdit")}</button>` : ""}
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${avg?avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${list.length}</b><span>${t("feedback")}</span></div>
    </div>
    <p class="mini" style="margin:-2px 0 8px">${t("fbTapOne")}</p>`
  + dayGroups("fb", list, "created_at", fbRowHtml, "feedback");
}
function dashView(){
  if(S.sub.dash==="rooms") S.sub.dash="overview";   // rooms live under Guests now
  const totalB=S.bookings.length;
  const wait=S.bookings.filter(b=>b.status==="waitlist").length;
  const withCap=S.activities.filter(a=>a.capacity>0);
  const occ=withCap.length?Math.round(withCap.reduce((n,a)=>n+Math.min(1,seatsTaken(a.id)/a.capacity),0)/withCap.length*100):0;
  const tSold=S.orders.reduce((n,o)=>n+(+o.qty||0),0);
  const rooms=new Set(S.bookings.map(b=>b.room)).size;
  const people=S.bookings.filter(b=>b.status==="booked").reduce((n,b)=>n+(+b.adults||0)+(+b.children||0),0);
  const natMap={};
  S.bookings.forEach(b=>{ if(b.nationality){ (natMap[b.nationality]=natMap[b.nationality]||new Set()).add(b.room); } });
  S.orders.forEach(o=>{ if(o.nationality){ (natMap[o.nationality]=natMap[o.nationality]||new Set()).add(o.room); } });
  const nats=Object.entries(natMap).map(([n,s])=>[n,s.size]).sort((x,y)=>y[1]-x[1]);
  const top=[...S.activities].map(a=>({a,n:seatsTaken(a.id)})).sort((x,y)=>y.n-x.n).slice(0,5).filter(x=>x.n>0);
  const parts={
    attention: ()=>attentionCard(),
    dayinfo:   ()=>dayPlanInfoCard(todayIndex()),
    wholeday:  ()=>dayPlanTimes(todayIndex()),
    tonight:   ()=>tonightCard(),
    live:      ()=>liveOpsCard(),
    export:    ()=>`<button class="btn ghost" id="btn-exportdata" style="margin:0 0 16px">${ic("download",16)} ${t("exportData")}</button>`,
    stats:     ()=>`<div class="stat-grid">
      <div class="stat"><b>${totalB}</b><span>${t("totalBookings")}</span></div>
      <div class="stat accent"><b>${occ}%</b><span>${t("occupancy")}</span></div>
      <div class="stat"><b>${tSold}</b><span>${t("tickets")}</span></div>
      <div class="stat"><b>${wait}</b><span>${t("waitlisted")}</span></div>
      <div class="stat"><b>${rooms}</b><span>${t("uniqueGuests")}</span></div>
      <div class="stat"><b>${people}</b><span>${t("totalPeople")}</span></div>
    </div>`,
    feedback:  ()=>feedbackAnalyticsCard(),
    nations:   ()=>nats.length?`<div class="sec"><h3>${t("natStats")}</h3><div class="card">
      ${nats.map(([n,c])=>`<div class="booking-line"><span>${esc(n)}</span><span class="pill">${c}</span></div>`).join("")}
    </div></div>`:"",
    activities:()=>`<div class="sec"><h3>${ic("star",18)} ${t("activities")}</h3>
      ${top.length?top.map(x=>`<div class="card booking-line" style="padding:12px 14px">
        <span><b>${esc(x.a.name)}</b> · ${t("daysShort")[x.a.day]} ${x.a.time}</span>
        <span class="pill">${x.n} ${t("guests")}</span></div>`).join(""):`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("none")}</div>`}
    </div>`,
    trends:    ()=>trendsCard()
  };
  return `<div class="screen fadein">
    ${topBar(t("dashboard"),S.session.name)}
        ${!REMOTE?`<div class="setup">${t("demoNote")}</div>`:""}
    ${arrangeBtn("dash")}
    ${renderParts("dash",parts)}
  </div>`;
}
/* Tonight's show or party, and whether the hotel is actually ready for it.
   The readiness comes straight from its requirement sheet. */
function tonightAct(day){
  const d=(typeof day==="number")?day:todayIndex();
  const evening=(S.activities||[]).filter(a=>a && a.day===d && ["eShow","eParty"].includes(normCat(a)));
  if(!evening.length) return null;
  return evening.sort((x,y)=>(timeToMin(reqStartTime(y))||0)-(timeToMin(reqStartTime(x))||0))[0];
}
function reqSheetForAct(a){
  if(!a) return null;
  const all=reqSheets();
  return all.find(sh=>String(sh.actId||"")===String(a.id))
      || all.find(sh=>String(sh.title||"").toLowerCase()===String(a.name||"").toLowerCase())
      || null;
}
function tonightCard(){
  const a=tonightAct();
  if(!a) return "";
  const sh=reqSheetForAct(a);
  const rows=(sh && sh.rows) || [];
  const done=rows.filter(r=>r.done).length;
  const pct=rows.length?Math.round(done/rows.length*100):0;
  const who=String(a.entertainer||"").trim();
  const byDept={};
  rows.forEach(r=>{ const k=r.dept||"\u2014"; byDept[k]=byDept[k]||{n:0,d:0}; byDept[k].n++; if(r.done) byDept[k].d++; });
  const chips=Object.keys(byDept).slice(0,3).map(k=>{
    const v=byDept[k], full=v.d===v.n;
    return `<span class="schip ${full?"live":"warn"}"><i></i>${esc(k)} ${full?"\u2713":v.d+"/"+v.n}</span>`;
  }).join("");
  return `<div class="sec"><h3>${ic("sparkle",18)} ${t("tonightLbl")}</h3>
    <div class="card tn">
      <div class="tn-head" data-actopen="${esc(String(a.id))}">
        <span class="tn-mid"><b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}</span></span>
        <span class="tn-go">${ic("back",16)}</span>
      </div>
      <div class="tn-chips">
        <span class="schip ${who?"live":"warn"}"><i></i>${t("readyTeam")} ${who?esc(who):"\u2014"}</span>
        ${chips}
      </div>
      ${rows.length?`<div class="tn-bar"><i style="width:${pct}%"></i></div>
        <span class="mini">${t("readySetup")} ${pct}% \u00b7 ${done}/${rows.length}</span>`
        :`<button class="btn sm ghost" id="tn-make">${ic("clipboard",14)} ${t("readyMake")}</button>`}
    </div>
  </div>`;
}
/* What is running right now, what starts next, and whether anyone is on it.
   The manager's first question every afternoon. */
function liveOpsCard(){
  const day=todayIndex();
  const now=(()=>{ const d=new Date(); return d.getHours()*60+d.getMinutes(); })();
  const list=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>{
      const w=actWindow(a);
      const s0=w?w.s0:(timeToMin(String(a.time||"").split(/\s*[\u2013\u2014-]\s*/)[0])||0);
      const s1=(w && (w.e0!=null?w.e0:w.s1)) ?? (s0+45);   // actWindow calls the end e0
      return {a, s0, s1};
    })
    .filter(x=>x.s1>=now-30)                       // still running, or still to come
    .sort((x,y)=>x.s0-y.s0)
    .slice(0,5);
  if(!list.length) return "";
  const staffOf=a=>entertainerName(a.entertainer);   // always show the team member display name
  const row=x=>{
    const a=x.a, who=staffOf(a), booked=seatsTaken(a.id);
    const live = x.s0<=now && now<=x.s1;
    const mins = Math.round(x.s0-now);
    const chip = live ? `<span class="schip live"><i></i>${t("liveNow")}</span>`
      : !who   ? `<span class="schip warn"><i></i>${t("liveNoStaff")}</span>`
      : mins<=60 ? `<span class="schip gold"><i></i>${t("liveSoon").replace("{n}",Math.max(0,mins))}</span>`
      : `<span class="schip"><i></i>${t("liveAssigned")}</span>`;
    return `<div class="booking-line" data-actopen="${esc(String(a.id))}" style="cursor:pointer">
      <span style="min-width:0"><b>${esc(a.name)}</b>
        <br><span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}${
          booked?" \u00b7 "+booked+" "+t("guests"):""}${who?" \u00b7 "+esc(who):""}</span></span>
      ${chip}
    </div>`;
  };
  return `<div class="sec"><h3>${ic("clock",18)} ${t("liveOps")}</h3>
    <div class="card">${list.map(row).join("")}</div>
  </div>`;
}
/* The feedback picture at a glance — tap a department to read the ratings behind it. */
function feedbackAnalyticsCard(){
  const list=S.feedback||[];
  const sum=fbSummary(list);
  return `<div class="sec"><h3>${ic("star",18)} ${t("fbAnalytics")}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${sum.overall?sum.overall.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${sum.count}</b><span>${t("feedback")}</span></div>
      <div class="stat good"><b>${sum.allFive}</b><span>${t("fbAllFiveN")}</span></div>
      <div class="stat ${sum.toReview?"warn":""}"><b>${sum.toReview}</b><span>${t("fbToReview")}</span></div>
    </div>
    ${sum.weak
      ? `<button class="fb-dept low" data-fbdept="${esc(sum.weak.k)}" style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:10px">
          <span class="fb-nm">${t("fbLowest")}<br><span class="mini">${esc(fbDeptLabel(sum.weak.k))}</span></span>
          <span class="fb-bar"><i style="width:${Math.round(sum.weak.avg/5*100)}%"></i></span>
          <span class="fb-val">${sum.weak.avg.toFixed(1)}</span></button>`
      : (sum.rated?`<p class="mini" style="margin:0 0 10px">${ic("star",13)} ${
          sum.perfect ? t("fbHotelGeneral")+" \u00b7 "+t("fbPerfect")
          : t("fbHotelGeneral")+" \u00b7 "+t("fbNoneWeak")}</p>`:"")}
    ${fbDeptListCard(list)}
    ${sum.rated?`<p class="mini" style="margin-top:6px">${t("fbTapHint")}</p>`:""}
  </div>`;
}
function managerActsInner(){
  const acts=S.activities.filter(a=>a.day===S.day);
  const head=dayTabs()+`<button class="btn" id="btn-add" style="margin:0 0 14px">＋ ${t("addActivity")}</button>`;
  if(!acts.length) return head+`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return head + OPS.map(o=>{
    const list=acts.filter(a=>actOp(a)===o.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    if(!list.length) return "";
    return `<div class="sec"><h3>${esc(opLabel(o.id))}</h3>${list.map(a=>activityCard(a,{manager:true,showBook:false,showFav:false})).join("")}</div>`;
  }).join("");
}
function managerTicketsInner(){
  return `<button class="btn" id="btn-addticket" style="margin:0 0 14px">＋ ${t("addTicket")}</button>`
  + (S.tickets.length?S.tickets.map(tk=>{
    const os=ordersFor(tk.id), sold=ticketsSold(tk.id);
    return `<div class="card">
      <div class="act" style="margin-bottom:${os.length?10:0}px">
        <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
        <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span>
          <h4>${esc(tk.name)}</h4>
          <div class="meta"><span>${esc(tk.price||"")}</span><span>${mi("ticket")}${sold}${tk.capacity>0?"/"+tk.capacity:""}</span></div></div>
        <div class="side"><button class="btn sm ghost" data-tedit="${tk.id}">${ic("pen",15)}</button></div>
      </div>
      ${os.map(o=>`<div class="booking-line">
        <span style="min-width:0"><b>${t("room")} ${esc(o.room)}</b> · ${esc(o.guest_name)} · ×${o.qty}${o.collect_from?`<br><span class="mini">${mi("user")}${t("handTo")}: ${esc(o.collect_from)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <button class="chip ${o.status==="paid"?"ok":"res"}" data-tpaid="${o.id}">${o.status==="paid"?t("paid"):t("reserved")}</button>
          <button class="btn sm warn" data-tdel="${o.id}">${ic("close",14)}</button>
        </span></div>`).join("")}
    </div>`;
  }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`);
}
function requestsInner(){
  return S.requests.length?dayGroups("req", S.requests, "created_at", r=>`<div class="booking-line">
    <span style="min-width:0">${ic(r.type==="song"?"music":"gift",15)} <b>${esc(r.detail)}</b>${r.date?` · ${esc(r.date)}`:""}
      <br><span class="mini">${t("room")} ${esc(r.room)} · ${esc(r.guest_name)}${r.note?` — ${esc(r.note)}`:""}
        ${r.created_at?` · ${whenLabel(r.created_at)}`:""}</span></span>
    <span style="display:flex;gap:6px;align-items:center;flex:none">
      <button class="chip ${r.status==="done"?"ok":"res"}" data-reqdone="${r.id}">${r.status==="done"?t("done"):t("statusNew")}</button>
      <button class="btn sm warn" data-reqdel="${r.id}">${ic("close",14)}</button>
    </span></div>`, "requests")
  :`<div class="empty"><div class="big">${ic("gift",30)}</div>${t("none")}</div>`;
}
function roomsInner(){
  return `<label>${t("addRooms")}</label>
    <textarea id="rooms-in" rows="3" placeholder="${t("roomsHint")}"></textarea>
    <button class="btn" id="btn-addrooms" style="margin:10px 0 16px">＋ ${t("addRooms")}</button>
    <input id="rooms-filter" placeholder="..." style="margin-bottom:10px">
    <div class="card roomgrid">
      ${S.rooms.length?S.rooms.map(r=>{
        const acc=S.accounts.find(a=>a.room===r.room && a.active!==false && !stayExpired(a));
        return `<div class="booking-line roomline" data-room="${esc(r.room)}">
          <span style="min-width:0"><b>${esc(r.room)}</b>${acc?` · ${esc(acc.name)}`:""}</span>
          <span style="display:flex;gap:6px;align-items:center;flex:none">
            ${acc?`<button class="btn sm ghost" data-gedit="${acc.id}">${ic("pen",15)}</button>`:""}
            <button class="chip ${r.active?"ok":"full"}" data-roomact="${r.id}">${t("activeLbl")}</button>
            <button class="btn sm warn" data-roomdel="${r.id}">${ic("close",14)}</button>
          </span></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("door",30)}</div>${t("none")}</div>`}
    </div>`;
}
function teamSummaryCard(){
  const st=teamStats();
  if(!st.total) return "";
  return `<div class="card tsum">
    <div class="ts-top">
      <div class="ts-big"><b>${st.total}</b><span class="mini">${t("totalEntertainers")}</span></div>
      <div class="ts-gen">
        <span class="ts-chip m">${ic("users",14)} ${st.byGender.male} ${t("genderM")}</span>
        <span class="ts-chip f">${ic("users",14)} ${st.byGender.female} ${t("genderF")}</span>
        ${st.byGender.none?`<span class="ts-chip n">${st.byGender.none} ${t("genderNone")}</span>`:""}
      </div>
    </div>
    ${st.natList.length?`<div class="ts-nat"><span class="type-meta">${t("byNationality")}</span>
      <div class="ts-nats">${st.natList.map(n=>`<span class="ts-chip">${esc(n.name)} · ${n.count}</span>`).join("")}</div>
    </div>`:""}
  </div>`;
}
function accountsInner(){
  const managerCount=S.users.filter(u=>u.role==="manager").length;
  return `${teamSummaryCard()}
    <button class="btn" id="btn-adduser" style="margin:0 0 12px">＋ ${t("addUser")}</button>
    <div class="card">
      ${S.users.filter(u=>!isAttOnly(u)).sort((a,b)=>(hasLeft(a)?1:0)-(hasLeft(b)?1:0) || (a.number||99)-(b.number||99)).map(u=>{
        const lastManager=u.role==="manager"&&managerCount<=1;
        return `<div class="acct-row">
        <div class="acct-av">${u.photo?`<img src="${esc(u.photo)}" alt="">`:`<span>${esc((u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</span>`}${u.number?`<span class="acct-num">${u.number}</span>`:""}</div>
        <div class="acct-info" data-uview="${esc(u.username)}"><b>${esc(u.display_name||u.username)}${hasLeft(u)?` <span class="off-tag">${t("leftTag")}</span>`:(u.active===false?` <span class="off-tag">${t("inactiveAcc")}</span>`:"")}</b><span class="mini">${esc(u.username)} · ${u.role==="manager"?t("manager"):t("staff")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span></div>
        <div style="display:flex;gap:6px;align-items:center;flex:none">
          <button class="btn sm ghost" data-uedit="${u.id}">${ic("pen",15)}</button>
          ${u.role==="staff"?`<button class="btn sm ghost" data-userleave="${u.id}" aria-label="${t("markLeft")}">${ic("exit",15)}</button>`:""}
          ${u.id===S.session.userId||lastManager?"":`<button class="btn sm warn" data-deluser="${u.id}">${ic("close",14)}</button>`}
        </div></div>`;}).join("")}
    </div>`;
}
function openProfileModal(p){
  const isNew=!p; p=p||{name:"",position:"",photo:"",nationality:"",languages:"",skills:"",instagram:""};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${isNew?t("addProfile"):t("profiles")}</h3>
    <label>${t("name")}</label><input id="pr-name" value="${esc(p.name)}">
    <label>${t("positionLbl")}</label><input id="pr-pos" value="${esc(p.position)}" placeholder="Entertainment Manager / Entertainer">
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="pr-photo" type="hidden" value="${esc(p.photo)}">
    <label>${t("nationality")}</label>
    <input id="pr-nat" list="prnatlist" value="${esc(p.nationality)}">
    <datalist id="prnatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <label>${t("languagesLbl")}</label><input id="pr-lang" value="${esc(p.languages)}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="pr-skills" value="${esc(p.skills)}" placeholder="Dance · Shows · Kids">
    <label>${t("instagramLbl")}</label><input id="pr-ig" value="${esc(p.instagram)}" placeholder="https://instagram.com/...">
    <button class="btn" id="pr-go">${t("save")}</button>
    <button class="btn ghost" id="pr-x">${t("close")}</button>`);
  wrap.querySelector("#pr-x").onclick=()=>wrap.remove();
  let prPhoto=p.photo||"";
  wirePhotoPicker(wrap, ()=>prPhoto, v=>{ prPhoto=v; wrap.querySelector("#pr-photo").value=v; });
  wrap.querySelector("#pr-go").onclick=async ()=>{
    const name=wrap.querySelector("#pr-name").value.trim();
    if(!name) return;
    await DB.saveProfile({...p,name,
      position:wrap.querySelector("#pr-pos").value.trim(),
      photo:prPhoto,
      nationality:wrap.querySelector("#pr-nat").value.trim(),
      languages:wrap.querySelector("#pr-lang").value.trim(),
      skills:wrap.querySelector("#pr-skills").value.trim(),
      instagram:wrap.querySelector("#pr-ig").value.trim()});
    wrap.remove(); toast(t("saved")); render();
  };
}
function tasksInner(){
  const rk=rankingRows();
  return `<button class="btn" id="btn-addtask" style="margin:0 0 12px">＋ ${t("addTask")}</button>
    <button class="btn ghost" id="btn-export" style="margin:0 0 14px">${ic("download",16)} ${t("exportReport")}</button>`
    + (rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("taskStats")}</h3><div class="card">
      ${rk.map((r,i)=>`<div class="booking-line">
        <span style="min-width:0">${rankBadge(i)} <b>${esc(r.u.display_name||r.u.username)}</b>
          <br><span class="mini">${t("done")}: ${r.done} · ${t("late")}: ${r.late} · ${t("cantDo")}: ${r.cant} · ${t("statusNew")}: ${r.open}</span></span>
        <span class="pill" style="flex:none">${r.points} ${t("points")}</span></div>`).join("")}
    </div></div>`:"")
    + (S.tasks.length?`<div class="card">${S.tasks.map(x=>taskLine(x,true)).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`);
}
/* ---------------- AI assistant (manager only) ---------------- */
function aiView(){
  const key=localStorage.getItem("ent_ai_key")||"";
  if(!key){
    return `<div class="screen fadein">
      ${topBar(t("aiTab"),S.session.name)}
      ${hubBack()}
      <div class="card" style="padding:16px">
        <p style="font-size:15px">${ic("sparkle",16)} ${t("aiIntro")}</p>
        <label>${t("aiKeyLbl")}</label>
        <input id="ai-key" type="password" placeholder="sk-ant-...">
        <p class="hint" style="text-align:start">${t("aiKeyHint")}<br>→ console.anthropic.com</p>
        <button class="btn" id="ai-savekey">${t("save")}</button>
      </div>
    </div>`;
  }
  return `<div class="screen fadein">
    ${topBar(t("aiTab"),S.session.name)}
    ${hubBack()}
    <div class="thread">
      ${S.aiChat.length?S.aiChat.map(m=>`<div class="bub ${m.role==="user"?"me":"them"}">${esc(m.content)}</div>`).join("")
        :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("aiIntro")}</div>`}
      ${S.aiBusy?`<div class="bub them">…</div>`:""}
    </div>
    <div class="chatbar">
      <input id="ai-in" placeholder="${t("aiAsk")}" autocomplete="off">
      <button id="ai-send" aria-label="${t("send")}">${ic("send",17)}</button>
    </div>
  </div>`;
}
function aiContext(){
  const days=t("days");
  const prog=S.activities.slice(0,200).map(a=>`${days[a.day]} ${a.time} ${a.name} @${a.location}${a.entertainer?" [entertainer:"+a.entertainer+"]":""}`).join("; ");
  const rk=rankingRows().map(r=>`${r.u.display_name||r.u.username}: ${r.points}pts (done ${r.done}, late ${r.late}, can't ${r.cant}, open ${r.open})`).join("; ");
  const avg=S.feedback.length?(S.feedback.reduce((n,f)=>n+(+f.rate||0),0)/S.feedback.length).toFixed(1):"n/a";
  // full guest directory — lets the assistant answer "tell me about room 1111"
  const guests=S.accounts.map(a=>{
    const info=guestFullInfo(a.room); if(!info) return "";
    return `Room ${info.room}: ${info.name} (user ${info.username}), ${info.nationality||"?"}, phone ${info.phone||"?"}, stay ${info.arrival||"?"}→${info.departure||"?"}, ${info.days!=null?info.days+" days in app":""}, joined: ${info.activities.join("/")||"none"}, ${info.tickets} tickets, ${info.requests} requests`;
  }).filter(Boolean).join(" | ");
  const reqs=S.requests.slice(0,40).map(r=>`${r.type} "${r.detail}" room ${r.room} (${r.status})`).join("; ");
  const team=S.profiles.map(p=>`${p.name} — ${p.position||""} (${p.languages||""})`).join("; ");
  return `App: ${S.settings.name}. Today totals — bookings ${S.bookings.length}, ticket orders ${S.orders.reduce((n,o)=>n+(+o.qty||0),0)}, open requests ${S.requests.filter(r=>r.status==="new").length}, registered guest rooms ${S.accounts.length}, feedback avg ${avg}/5 (${S.feedback.length}). 
TEAM: ${team||"none"}. 
TEAM RANKING: ${rk||"none"}. 
GUEST DIRECTORY: ${guests||"no guests yet"}. 
RECENT REQUESTS: ${reqs||"none"}. 
WEEKLY PROGRAM: ${prog}`;
}
function aiSystemPrompt(){
  return "You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
    "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
    "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
    "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
    "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
    "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
    "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
    "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext();
}
/* Preferred path: a deployed Supabase Edge Function, so the API key never touches the browser. */
async function askAIViaEndpoint(endpoint){
  const res=await fetch(endpoint,{
    method:"POST",
    headers:{"content-type":"application/json"},
    body:JSON.stringify({
      system:aiSystemPrompt(),
      max_tokens:1200,
      messages:S.aiChat.map(m=>({role:m.role,content:m.content}))
    })
  });
  if(!res.ok) throw new Error("AI "+res.status);
  const data=await res.json();
  if(data.error) throw new Error(data.error);
  return String(data.text||"").trim();
}
async function askAI(text){
  const key=localStorage.getItem("ent_ai_key");
  const endpoint=(S.settings.aiEndpoint||"").trim();
  S.aiChat.push({role:"user",content:text});
  S.aiBusy=true; render();
  // Secure path first — only fall back to the browser key if no endpoint is set up yet.
  if(endpoint){
    try{
      const reply=await askAIViaEndpoint(endpoint);
      S.aiChat.push({role:"assistant",content:reply||"…"});
      S.aiBusy=false; render();
      window.scrollTo(0,document.body.scrollHeight);
      return;
    }catch(e){
      console.error("AI endpoint failed:", e && e.message);
      // The server link is wrong or not deployed yet.
      if(!key){
        S.aiChat.pop(); toastErr(t("aiEndpointErr"));
        S.aiBusy=false; render();
        window.scrollTo(0,document.body.scrollHeight);
        return;
      }
      // A key is stored on this device -> keep the assistant working and say so.
      toastWarn(t("aiEndpointFallback"));
    }
  }
  try{
    const res=await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{"content-type":"application/json","x-api-key":key,
        "anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
      body:JSON.stringify({model:"claude-haiku-4-5-20251001",max_tokens:1000,
        system:"You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
          "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
          "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
          "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
          "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
          "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
          "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
          "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext(),
        messages:S.aiChat.map(m=>({role:m.role,content:m.content}))})
    });
    if(!res.ok) throw new Error("AI "+res.status);
    const data=await res.json();
    const reply=(data.content||[]).map(c=>c.text||"").join("\n").trim();
    S.aiChat.push({role:"assistant",content:reply||"…"});
  }catch(e){ console.error(e); S.aiChat.pop(); toast(t("aiErr")); }
  S.aiBusy=false; render();
  window.scrollTo(0,document.body.scrollHeight);
}
function fmtDate(d){ return String(d||"").slice(0,16).replace("T"," "); }
/* build every exportable dataset as {title, headers, rows} */
function buildDataset(kind){
  const acts=id=>{ const a=S.activities.find(x=>x.id===id); return a?a.name:("#"+id); };
  const tkName=id=>{ const x=S.tickets.find(t=>t.id===id); return x?x.name:("#"+id); };
  if(kind==="bookings"){
   const okAct=new Set(exportActivities().map(a=>a.id));
   return {title:t("expBookings")+exportFilterNote(),
    headers:[t("room"),t("name"),t("nationality"),t("phone"),t("actName"),t("day"),t("time"),t("persons"),"Status"],
    rows:S.bookings.filter(b=>okAct.has(b.activity_id)).map(b=>{ const a=S.activities.find(x=>x.id===b.activity_id)||{};
      return [b.room,b.guest_name,b.nationality||"",b.phone||"",a.name||"",t("days")[a.day]||"",a.time||"",((+b.adults)||0)+((+b.children)||0),b.status||""]; })};
  }
  if(kind==="requests") return {title:t("expRequests"),
    headers:[t("room"),t("name"),t("taskType"),"Detail",t("day"),"Note","Status","Date"],
    rows:S.requests.map(r=>[r.room,r.guest_name||"",r.type,r.detail,r.date||"",r.note||"",r.status,fmtDate(r.created_at)])};
  if(kind==="chat") return {title:t("expChat"),
    headers:[t("room"),"From","Message","Date"],
    rows:S.messages.map(m=>[m.room,m.sender==="team"?"Team":"Guest",m.text,fmtDate(m.created_at)])};
  if(kind==="users") return {title:t("expUsers"),
    headers:[t("shirtNumber"),t("displayName"),t("user"),t("roleLabel"),t("nationality"),t("genderLbl")],
    rows:S.users.slice().sort((a,b)=>(a.number||99)-(b.number||99))
      .map(u=>[u.number?("#"+u.number):"", u.display_name||"", u.username, u.role,
               u.nationality||"", u.gender?genderLabel(u.gender):""])};
  if(kind==="monthatt"){
    /* export whichever month she picked, not only the one on screen */
    const mk=S.exportMonth || currentAttMonth();
    const n=monthDays(mk), team=attTeamFor(mk);
    const headers=[t("displayName")]
      .concat(Array.from({length:n},(_,i)=>String(i+1)))
      .concat([t("attTotalsP"), t("attTotalsO"), t("attTotalsA")]);
    /* On the official sheet a day off is a paid day, so it counts as present.
       The days-off column still shows them separately. */
    const rows=team.map(u=>{
      const tot=attTotals(u,mk);
      return [u.display_name||u.username]
        .concat(Array.from({length:n},(_,i)=>isFutureDay(mk,i+1)?"":attStatus(u,mk,i+1)))
        .concat([String(tot.P+tot.O), String(tot.O), String(tot.A)]);
    });
    if(team.length){
      const mt=attMonthTotals(mk);
      rows.push([t("totalRow")].concat(Array.from({length:n},()=>""))
        .concat([String(mt.P+mt.O), String(mt.O), String(mt.A)]));
    }
    const soFar=(mk===currentAttMonth()) ? daysSoFar(mk) : n;
    return {title:t("monthAtt")+" — "+monthLabel(mk)+(soFar<n?" ("+t("upToToday")+")":""),
            headers, rows, signatures:true};
  }
  if(kind==="teamsummary"){
    const st=teamStats();
    const rows=[
      [t("totalTeam"), String(st.total)],
      [t("totalEntertainers"), String(st.entertainers)],
      [t("genderM"), String(st.byGender.male)],
      [t("genderF"), String(st.byGender.female)]
    ];
    if(st.byGender.none) rows.push([t("genderNone"), String(st.byGender.none)]);
    const dToday=todayIndex(), dutyT=dayDutyStats(dToday);
    rows.push([t("workingToday"), String(dutyT.workingCount)]);
    rows.push([t("dayOffToday"), String(dutyT.offCount)]);
    st.natList.forEach(n=>rows.push([t("byNationality")+" · "+n.name, String(n.count)]));
    return {title:t("teamSummary"), headers:["",""], rows};
  }
  if(kind==="guests") return {title:t("expGuests"),
    headers:[t("room"),t("user"),t("name"),t("nationality"),t("phone"),t("arrival"),t("departure"),t("daysHere"),t("joinedActs"),t("tickets"),t("requests")],
    rows:S.accounts.map(a=>{ const info=guestFullInfo(a.room)||{};
      return [a.room,a.username||a.room,a.name,a.nationality||"",a.phone||"",a.arrival||"",a.departure||"",info.days!=null?info.days:"",(info.activities||[]).join(", "),info.tickets||0,info.requests||0]; })};
  if(kind==="tickets") return {title:t("expTickets"),
    headers:[t("room"),t("name"),"Ticket","Qty","Status",t("handTo"),"Date"],
    rows:S.orders.map(o=>[o.room,o.guest_name,tkName(o.ticket_id),o.qty,o.status,o.collect_from||"",fmtDate(o.created_at)])};
  if(kind==="feedback"){
    const list=exportFeedbackList();
    return {title:t("expFeedback")+fbFilterNote(),
      landscape:true,
      stars:{from:3, to:3+fbDeptKeys().length},          // Overall + every department
      notes:list.map(f=>fbComment(f)),                    // printed full width under the row
      noteLabel:t("comment"),
      headers:[t("room"),t("fbGuestName"),t("nationality"),t("fbOverall")]
        .concat(fbDeptKeys().map(fbDeptLabel))
        .concat([t("fbCollectedBy"),"Date"]),
      rows:list.map(f=>{ const d=fbDepts(f);
        return [f.room,f.guest_name||"",f.nationality||"",fbOverall(f)||""]
          .concat(fbDeptKeys().map(k=>+d[k]>0?+d[k]:""))
          .concat([teamName(f.by_user),fmtDate(f.created_at)]); })};
  }
  if(kind==="fbdepts"){
    const st=fbDeptStats(exportFeedbackList()).sort((a,b)=>b.avg-a.avg);
    return {title:t("fbDeptSheet")+fbFilterNote(),
      stars:{from:1, to:1},
      headers:[t("fbByDept"),t("avgRate"),t("fbResponses")],
      rows:st.map(d=>[fbDeptLabel(d.k), d.avg.toFixed(2), d.n])};
  }
  if(kind==="program") return {title:t("manage")+exportFilterNote(),
    headers:[t("day"),t("time"),t("actName"),t("category"),t("location"),t("entertainer"),t("capacity"),t("makeHighlight")],
    rows:exportActivities().slice().sort((x,y)=>(x.day-y.day)||String(x.time).localeCompare(String(y.time)))
      .map(a=>[t("days")[a.day]||"",a.time||"",a.name||"",catLabel(normCat(a)),a.location||"",a.entertainer||"",a.capacity||0,a.highlight?"★":""])};
  if(kind==="dayplan"){
    // One clean row per day — exactly what hotel management needs at a glance
    const onlyDay=expDay();
    const rows=DAY_PLAN.filter(dp=>onlyDay==null || dp.day===onlyDay).map(dp=>{
      const evs=S.activities.filter(a=>{
        const c=normCat(a); return a.day===dp.day && (c==="mEvents"||c==="eParty");
      }).sort((x,y)=>String(x.time).localeCompare(String(y.time)))
        .map(a=>String(a.time||"").split(/\s*[–—-]\s*/)[0]+" "+a.name+(a.location?" ("+a.location+")":""));
      const duty=dayDutyStats(dp.day);
      return [
        t("days")[dp.day]||dp.name,
        dp.theme,
        dp.dress,
        evs.length?evs.join(" | "):"—",
        dp.liveBand||"—",
        dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc,
        personTags(dp.off)||"—",
        personTag(dp.entrance),
        String(duty.workingCount),
        String(duty.offCount)
      ];
    });
    return {title:t("dayPlan"),
      headers:[t("day"),t("restaurantTheme"),t("dressCode"),t("eventsToday"),
               t("liveBandLbl"),t("eveningShowLbl"),t("dayOff"),t("entranceDuty"),
               t("workingToday"),t("dayOffToday")],
      rows};
  }
  if(kind==="todayplan"){
    // Just today — the sheet she sends to management each morning
    const d=todayIndex();
    const dp=dayPlanFor(d);
    const evs=S.activities.filter(a=>{
      const c=normCat(a); return a.day===d && (c==="mEvents"||c==="eParty");
    }).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    // Management sheet — the day first, then the team totals at the end.
    // Order exactly as the hotel reads it. No practice, no internal notes.
    const rows=[ [t("restaurantTheme"), dp.theme] ];
    evs.forEach(a=>rows.push([t("eventsToday"),
      String(a.time||"").split(/\s*[–—-]\s*/)[0]+" — "+a.name+(a.location?" ("+a.location+")":"")]));
    if(!evs.length) rows.push([t("eventsToday"),"—"]);
    rows.push([t("liveBandLbl"), dp.liveBand||"—"]);
    rows.push([t("eveningShowLbl"), dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc]);
    rows.push([t("dressCode"), dp.dress]);
    rows.push([t("entranceDuty"), personTag(dp.entrance)]);
    rows.push([t("dayOff"), personTags(dp.off)||"—"]);
    // ---- team totals ----
    const st=teamStats(), duty=dayDutyStats(d);
    if(st.total){
      // entertainers working today = entertainers minus the ones off (manager excluded)
      const offEnt=duty.off.filter(u=>u.role!=="manager").length;
      rows.push([t("workingEntToday"), String(Math.max(0, st.entertainers-offEnt))+" / "+st.entertainers]);
      rows.push([t("totalAllTeam"), String(st.total)]);
      if(st.natList.length) rows.push([t("byNationality"), st.natList.map(n=>n.name+" "+n.count).join(" · ")]);
      const gen=[st.byGender.male+" "+t("genderM"), st.byGender.female+" "+t("genderF")];
      if(st.byGender.none) gen.push(st.byGender.none+" "+t("genderNone"));
      rows.push([t("byGender"), gen.join(" · ")]);
    }
    return {title:(t("days")[d]||"")+" · "+t("dayPlan"), headers:["",""], rows};
  }
  return null;
}
const EXPORT_KINDS=["todayplan","dayplan","monthatt","teamsummary","program","guests","bookings","requests","chat","tickets","feedback","fbdepts","users"];
function exportKindLabel(k){ return {todayplan:t("todayPlanExp"),monthatt:t("attExport"),teamsummary:t("teamSummary"),program:t("manage"),dayplan:t("dayPlan"),guests:t("expGuests"),bookings:t("expBookings"),requests:t("expRequests"),chat:t("expChat"),tickets:t("expTickets"),feedback:t("expFeedback"),fbdepts:t("fbDeptSheet"),users:t("expUsers")}[k]; }
async function loadXLSX(){
  if(window.XLSX) return true;
  return new Promise(res=>{const sc=document.createElement("script");
    sc.src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
    sc.onload=()=>res(true); sc.onerror=()=>res(false); document.head.appendChild(sc);});
}
function downloadBlob(name,blob){
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=name;
  document.body.appendChild(a); a.click(); a.remove();
}
async function exportExcelSets(sets,fname){
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      const ws=XLSX.utils.aoa_to_sheet([headers,...rows]);
      const name=(ds.title||"Sheet").replace(/[\\/?*\[\]:]/g,"").slice(0,28)||"Sheet";
      XLSX.utils.book_append_sheet(wb,ws,name);
    });
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const lines=[];
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      lines.push([ds.title]); lines.push(headers); rows.forEach(r=>lines.push(r)); lines.push([]); });
    const csv=lines.map(r=>r.map(c=>'"'+String(c==null?"":c).replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
}
function exportPdfSets(sets,titleText){
  const esc2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const css="body{font-family:Arial,Helvetica,sans-serif;color:#2B1F16;padding:26px}"
    +"h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px;color:#6B4A32;border-bottom:2px solid #B98A5C;padding-bottom:4px}"
    +"table{border-collapse:collapse;width:100%;margin-bottom:10px;font-size:11px}"
    +"th{background:#F2E7D6;text-align:left;padding:6px 8px;border:1px solid #E4D3BC}"
    +"td{padding:5px 8px;border:1px solid #EEE3D2;vertical-align:top}"
    +".sub{color:#8A7358;font-size:12px;margin-bottom:6px}@media print{h2{page-break-after:avoid}}"
    +"table.sig{margin-top:26px;page-break-inside:avoid}"
    +"table.sig th{text-align:center;font-size:11px;letter-spacing:.04em;text-transform:uppercase}"
    +"td.sigbox{height:74px;border:1px solid #E4D3BC}"
    +"table.rated{font-size:10px}table.rated th{font-size:9px;padding:5px 3px;line-height:1.25}"
   +".band{flex-wrap:wrap}"
    +"table.rated td{padding:4px 3px}"
    +"td.st{text-align:center;white-space:nowrap;font-size:11px;letter-spacing:0}"
    +".sg{color:#DDD1BE}.nr{color:#CFC3B0}"
    +".sx{display:block;font-size:9px;color:#8A7358;letter-spacing:0}"
    +"tr.note td{background:#FBF7F0;color:#4A3826;font-size:11px;border-top:0;line-height:1.5}"
    +"tr.note b{color:#8A7358;font-weight:600}"
    +"tr.main td{border-bottom:0}"
    +(sets.some(d=>d.landscape)?"@page{size:A4 landscape;margin:12mm}":"");
  const starCell=(v,exact)=>{
    const n=Math.round(+v||0);
    if(!n) return '<span class=nr>\u2014</span>';
    const col = n<=3 ? "#C0392B" : n===4 ? "#E08A2E" : "#C9A227";
    return '<span style="color:'+col+'">'+"\u2605".repeat(n)+'</span>'
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span>'
      +(exact!=null?'<span class=sx>'+esc2(exact)+'</span>':'');
  };
  let html="<h1>"+esc2(titleText)+"</h1><div class=sub>"+esc2(new Date().toLocaleString())+"</div>";
  sets.forEach(ds=>{
    html+="<h2>"+esc2(ds.title)+"</h2><table"+(ds.stars?" class=rated":"")+"><thead><tr>"
      +ds.headers.map(h=>"<th>"+esc2(h)+"</th>").join("")+"</tr></thead><tbody>";
    html+=ds.rows.map((r,ri)=>{
      const hasNote=ds.notes && ds.notes[ri];
      let out="<tr"+(hasNote?" class=main":"")+">"+r.map((c,ci)=>{
        const isStar=ds.stars && ci>=ds.stars.from && ci<=ds.stars.to;
        if(!isStar) return "<td>"+esc2(c)+"</td>";
        const exact = ds.exact ? ds.exact[ri] : (ci===ds.stars.from && String(c).includes(".") ? c : null);
        return "<td class=st>"+starCell(c, exact)+"</td>";
      }).join("")+"</tr>";
      if(hasNote) out+="<tr class=note><td colspan="+ds.headers.length+"><b>"
        +esc2(ds.noteLabel||"")+":</b> "+esc2(ds.notes[ri])+"</td></tr>";
      return out;
    }).join("");
    if(!ds.rows.length) html+="<tr><td colspan="+ds.headers.length+" style=\"color:#999\">—</td></tr>";
    html+="</tbody></table>";
    if(ds.signatures){
      const sigRoles=[t("sigEntertainment"), t("sigSecurity"), t("sigFB"), t("sigGM")];
      html+="<table class=sig><tr>"
        +sigRoles.map(r=>"<th>"+esc2(r)+"</th>").join("")
        +"</tr><tr>"
        +sigRoles.map(()=>"<td class=sigbox></td>").join("")
        +"</tr></table>";
    }
  });
  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+esc2(titleText)+"</title><meta charset=utf-8><style>"+css+"</style></head><body>"+html+"<scr"+"ipt>setTimeout(function(){window.print();},350);<\/scr"+"ipt></body></html>");
  w.document.close();
}
/* An attendance sheet gets an official heading; anything else keeps the plain one. */
/* Months she can export: this one and the seventeen before it. */
/* What she ticked in the export screen: a weekday, a part of the day, or both. */
function expDay(){
  if(S.exportDate){
    const dt=new Date(String(S.exportDate)+"T12:00:00");
    if(!isNaN(dt.getTime())) return (dt.getDay()+6)%7;
  }
  return S.exportDay===""||S.exportDay==null ? null : +S.exportDay;
}
function expSlot(){ return S.exportSlot || ""; }
function inExportSlot(time){
  const slot=expSlot(); if(!slot) return true;
  const m=timeToMin(time); if(m==null) return false;
  return operationSlotFromMinutes(m)===slot;
}
/* activities that survive the day and time filters */
function exportActivities(){
  const d=expDay();
  return (S.activities||[])
    .filter(a=>d==null || a.day===d)
    .filter(a=>inExportSlot(a.time));
}
/* Feedback the manager asked for: a month, a weekday and a part of the day.
   All three are optional and stack. */
function exportFeedbackList(){
  const mk=S.fbMonth||"", day=S.fbDate||"", slot=expSlot();
  const list=(S.feedback||[]).filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    if(!ts || isNaN(ts.getTime())) return !mk && !day && !slot;
    if(day) return localDateKey(ts)===day && slotOk(ts,slot);   // one exact date wins over the month
    if(mk && localMonthKey(ts)!==mk) return false;
    return slotOk(ts,slot);
  });
  return list.sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
}
function localMonthKey(dt){
  return dt.getFullYear()+"-"+String(dt.getMonth()+1).padStart(2,"0");
}
function localDateKey(dt){
  return localMonthKey(dt)+"-"+String(dt.getDate()).padStart(2,"0");
}
function slotOk(ts,slot){
  if(!slot) return true;
  const m=ts.getHours()*60+ts.getMinutes();
  return operationSlotFromMinutes(m)===slot;
}
/* Reads back as "Wednesday 3 September 2026" so the report says what it covers. */
/* 03/09 · 22:29 — short enough for a narrow column, still unambiguous. */
function shortStamp(iso){
  const dt=iso?new Date(iso):null;
  if(!dt || isNaN(dt.getTime())) return "";
  const p=n=>String(n).padStart(2,"0");
  return p(dt.getDate())+"/"+p(dt.getMonth()+1)+" \u00b7 "+p(dt.getHours())+":"+p(dt.getMinutes());
}
function niceDate(key){
  const bits=String(key||"").split("-");
  if(bits.length!==3) return key||"";
  const dt=new Date(+bits[0], +bits[1]-1, +bits[2]);
  if(isNaN(dt.getTime())) return key;
  return (t("days")[(dt.getDay()+6)%7]||"")+" "+dt.getDate()+" "+(t("months")[dt.getMonth()]||"")+" "+dt.getFullYear();
}
function fbFilterBits(){
  const bits=[];
  if(S.fbDate) bits.push(niceDate(S.fbDate));
  else if(S.fbMonth) bits.push(monthLabel(S.fbMonth));
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.filter(Boolean);
}
function fbFilterNote(){
  const bits=fbFilterBits();
  return bits.length ? " \u00b7 "+bits.join(" \u00b7 ") : "";
}
function exportFilterNote(){
  const bits=[];
  if(S.exportDate){
    const p=String(S.exportDate).split("-");
    if(p.length===3) bits.push((+p[2])+"/"+(+p[1])+"/"+p[0]);
  }else{
    const d=expDay(); if(d!=null) bits.push(t("days")[d]||"");
  }
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.length ? " · "+bits.join(" · ") : "";
}
function exportMonthOptions(){
  const out=[]; const d=hotelNow(); d.setDate(1);
  for(let i=0;i<18;i++){
    const mk=d.toISOString().slice(0,7);
    out.push([mk, monthLabel(mk)]);
    d.setMonth(d.getMonth()-1);
  }
  return out;
}
function exportTitle(sets){
  const hotel=(S.settings && S.settings.name) || "";
  const onlyAtt = sets.length===1 && sets[0].signatures;
  return onlyAtt ? (t("officialAtt").replace("{hotel}", hotel).trim())
                 : (hotel+" — "+t("exportData"));
}
function openExportModal(){
  let picked=new Set(["guests"]);
  S.fbMonth=""; S.fbDate="";          // the month picker here belongs to attendance

  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("exportData")}</h3>
    <p class="mini" style="margin-bottom:10px">${t("exportWhat")}</p>
    <div class="explist">
      ${EXPORT_KINDS.map(k=>`<label class="exp-it"><input type="checkbox" data-exp="${k}" ${k==="guests"?"checked":""}> <span>${exportKindLabel(k)}</span></label>`).join("")}
      <label class="exp-it exp-all"><input type="checkbox" id="exp-all"> <span>${t("expAll")}</span></label>
    </div>
    <div id="exp-month-row" style="display:none">
      <label style="margin-top:12px">${t("whichMonth")}</label>
      <select id="exp-month">
        ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===(S.exportMonth||currentAttMonth())?"selected":""}>${esc(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="row2" style="margin-top:12px">
      <div><label>${t("whichDay")}</label>
        <select id="exp-day">
          <option value="">${t("allDays")}</option>
          ${t("days").map((d,i)=>`<option value="${i}" ${String(S.exportDay)===String(i)?"selected":""}>${esc(d)}</option>`).join("")}
        </select></div>
      <div><label>${t("whichTime")}</label>
        <select id="exp-slot">
          <option value="">${t("allDayLong")}</option>
          ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
        </select></div>
    </div>
    <p class="mini" id="exp-note" style="margin-top:6px"></p>
    <button class="btn" id="exp-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="exp-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="exp-x">${t("close")}</button>`);
  const boxes=[...wrap.querySelectorAll("[data-exp]")];
  const monthRow=wrap.querySelector("#exp-month-row");
  const monthSel=wrap.querySelector("#exp-month");
  const showMonth=()=>{ if(monthRow) monthRow.style.display = picked.has("monthatt") ? "" : "none"; };
  const sync=()=>{ picked=new Set(boxes.filter(b=>b.checked).map(b=>b.dataset.exp)); showMonth(); };
  if(monthSel) monthSel.onchange=()=>{ S.exportMonth=monthSel.value; };
  const daySel=wrap.querySelector("#exp-day"), slotSel=wrap.querySelector("#exp-slot");
  const note=wrap.querySelector("#exp-note");
  const applyFilters=()=>{
    if(daySel)  S.exportDay  = daySel.value;
    if(slotSel) S.exportSlot = slotSel.value;
    if(note) note.textContent = (S.exportDay==="" && !S.exportSlot)
      ? t("noFilterNote") : t("filterNote")+exportFilterNote().replace(/^ · /," ");
  };
  if(daySel)  daySel.onchange=applyFilters;
  if(slotSel) slotSel.onchange=applyFilters;
  applyFilters();
  boxes.forEach(b=>b.onchange=sync);
  sync();
  wrap.querySelector("#exp-all").onchange=e=>{ boxes.forEach(b=>{b.checked=e.target.checked;}); sync(); };
  wrap.querySelector("#exp-x").onclick=()=>wrap.remove();
  const gather=()=>{
    if(monthSel) S.exportMonth=monthSel.value;      // whichever month she chose
    applyFilters();                                  // and the day / time she ticked
    return EXPORT_KINDS.filter(k=>picked.has(k)).map(buildDataset).filter(Boolean);
  };
  const fname="entertainment-data-"+todayISO();
  wrap.querySelector("#exp-xlsx").onclick=async ()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    await exportExcelSets(sets,fname); toast(t("saved"));
  };
  wrap.querySelector("#exp-pdf").onclick=()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    exportPdfSets(sets, exportTitle(sets)); wrap.remove();
  };
}
async function exportReport(){
  const weekAgo=Date.now()-7*864e5;
  const weekTasks=S.tasks.filter(x=>!x.created_at||Date.parse(x.created_at)>=weekAgo);
  const rank=rankingRows().map((r,i)=>[i+1,r.u.display_name||r.u.username,r.done,r.late,r.cant,r.open,r.points]);
  const taskRows=weekTasks.map(x=>[String(x.created_at||"").slice(0,16).replace("T"," "),taskTypeLabel(x.type),x.title,
    x.assigned_to?((S.users.find(u=>u.username===x.assigned_to)||{}).display_name||x.assigned_to):t("allTeam"),
    x.location||"",String(x.due||"").replace("T"," "),
    x.status==="done"?(x.was_still?t("done")+" ("+t("late")+")":t("done")):x.status==="cant"?t("cantDo"):x.status==="still"?t("still"):x.status==="accepted"?t("accepted"):t("statusNew")]);
  const fbRows=S.feedback.filter(f=>!f.created_at||Date.parse(f.created_at)>=weekAgo)
    .map(f=>[String(f.created_at||"").slice(0,16).replace("T"," "),f.room,f.nationality||"",f.rate,f.comment||"",f.by_user||""]);
  const fname="entertainment-report-"+todayISO();
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank]),"Ranking");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows]),"Tasks");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]),"Feedback");
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const csv=[["RANKING"],["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank,[],
      ["TASKS"],["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows,[],
      ["FEEDBACK"],["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]
      .map(r=>r.map(c=>'"'+String(c??"").replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
  toast(t("saved"));
}
function attendanceInner(){
  const todayIdx=todayIndex(), date=todayISO();
  const acts=S.activities.filter(a=>a.day===todayIdx).sort((x,y)=>x.time.localeCompare(y.time));
  return `<p class="mini" style="margin-bottom:10px">${t("today")} · ${t("days")[todayIdx]}</p>`
    + (acts.length?`<div class="card">${acts.map(a=>{
      const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
      const pres=bks.filter(b=>S.attendance.some(x=>x.booking_id===b.id&&x.date===date)).length;
      return `<div class="booking-line"><span>${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></span>
        <span class="pill">${pres}/${bks.length} ${t("present")}</span></div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
/* Settings is a hub of small pages, not one long form. */
const SETTINGS_GROUPS=[
  {head:"secLook", items:[
    ["set:theme","palette","setTheme","setThemeSub"],
    ["set:publictext","sparkle","Public experience","Explore & sign-in text"],
    ["set:brand","sparkle","setBrand","setBrandSub"],
    ["builder","grid","setMenus","setMenusSub"]]},
  {head:"secManage", items:[
    ["set:features","check","setFeatures","setFeaturesSub"],
    ["set:notif","bell","setNotif","setNotifSub"],
    ["set:links","star","setLinksT","setLinksSub"],
    ["bus","bus","busItem","busItem"]]},
  {head:"secSettings", items:[
    ["set:location","pin","setLocation","setLocationSub"],
    ["export","download","setData","setDataSub"],
    ["set:advanced","grid","setAdvanced","setAdvancedSub"]]}
];
function settingsHubView(){
  return `<div class="screen fadein">
    ${topBar(t("settingsHub"),S.session.name)}
    <p class="mini" style="margin:-4px 0 16px">${t("settingsSub")}</p>
    ${arrangeBtn("settings")}
    ${SETTINGS_GROUPS.map(g=>{
      const ord=pageOrder("settings");
      const items=g.items.filter(it=>ord.includes(it[0])).sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
      if(!items.length) return "";
      return `
      <div class="set-sec">${t(g.head)}</div>
      <div class="card set-list">
        ${items.map(([id,icn,lb,sub])=>`<button class="set-it" data-hub="${id}">
          <span class="set-ic">${ic(icn,19)}</span>
          <span class="set-mid"><b>${esc(t(lb))}</b>${sub&&sub!==lb?`<span class="mini">${esc(t(sub))}</span>`:""}</span>
          <span class="set-go">${ic("back",16)}</span>
        </button>`).join("")}
      </div>`;}).join("")}
  </div>`;
}
function setThemeView(){
  const st=S.settings;
  const fontOpts=[["elegant",t("fontElegant")],["royal",t("fontRoyal")],["modern",t("fontModern")],["soft",t("fontSoft")]];
  const btnOpts=[["rounded",t("btnRounded")],["pill",t("btnPill")],["square",t("btnSquare")]];
  return `<div class="screen fadein">
    ${topBar(t("setTheme"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("themeHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("themeHint")}</p>
      <div class="theme-grid">
        ${paletteList().map(k=>{
          const p=PALETTES[k], c=p.light;
          return `<button class="theme-card ${st.palette===k?"on":""}" data-palette="${k}">
            <span class="tc-sw"><i style="background:${c.primary}"></i><i style="background:${c.accent}"></i><i style="background:${c.bg};border:1px solid ${c.line}"></i></span>
            <span class="tc-lb">${esc(p.label)}</span></button>`;
        }).join("")}
        <button class="theme-card ${!PALETTES[st.palette]?"on":""}" data-palette="custom">
          <span class="tc-sw"><i style="background:${esc(st.primary)}"></i><i style="background:${esc(st.accent)}"></i><i style="background:${esc(st.bg)};border:1px solid var(--line)"></i></span>
          <span class="tc-lb">${t("themeCustom")}</span></button>
      </div>
      <label style="margin-top:14px">${t("fontSizeLbl")}</label>
      <select id="s-fs">
        ${[["small","fsSmall"],["normal","fsNormal"],["large","fsLarge"],["xl","fsXl"]].map(([k,lb])=>
          `<option value="${k}" ${(st.fontScale||"normal")===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
        <input id="s-autodark" type="checkbox" style="width:auto" ${st.autoDark?"checked":""}> ${t("autoDarkLbl")}</label>

      <label>${t("colorsHead")}</label>
      <div class="row2">
        <div><label style="margin-top:0">${t("primaryC")}</label><input id="s-primary" type="color" value="${esc(st.primary)}"></div>
        <div><label style="margin-top:0">${t("accentC")}</label><input id="s-accent" type="color" value="${esc(st.accent)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("bgC")}</label><input id="s-bg" type="color" value="${esc(st.bg)}"></div>
        <div><label>${t("textC")}</label><input id="s-text" type="color" value="${esc(st.textColor)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("navC")}</label><input id="s-navbg" type="color" value="${esc(st.navBg)}"></div>
        <div><label>${t("navActiveC")}</label><input id="s-navon" type="color" value="${esc(st.navActive)}"></div>
      </div>
      <label>${t("styleHead")}</label>
      <select id="s-font">${fontOpts.map(([v,l])=>`<option value="${v}" ${st.fontStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <label>${t("buttonHead")}</label>
      <select id="s-btn">${btnOpts.map(([v,l])=>`<option value="${v}" ${st.buttonStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setBrandView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setBrand"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("secIdentity")}</label>
      <div class="photo-pick"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("logoLbl")}</b><span class="mini">${t("logoHint")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>
      <input id="s-logo" type="hidden" value="${esc(st.logo||"")}">
      ${st.logo?`<button class="btn sm ghost" id="s-logo-rm" type="button" style="margin-bottom:10px">${ic("trash",14)} ${t("removeLogo")}</button>`:""}
      <input id="s-hotel" value="${esc(st.hotelName||"")}" placeholder="${esc(t("hotelNameLbl"))}" style="margin-bottom:8px">
      <input id="s-contact" value="${esc(st.contact||"")}" placeholder="${esc(t("contactLbl"))}" style="margin-bottom:8px">
      <input id="s-cur" value="${esc(st.currency||"")}" placeholder="${esc(t("currencyLbl"))}" style="margin-bottom:8px">
      <label style="margin-top:16px">${t("appName")}</label><input id="s-name" value="${esc(st.name)}">
      <label>${t("appSubtitle")}</label><input id="s-sub" value="${esc(st.subtitle)}" placeholder="${t("appSub")}">
      <label>${t("welcomeMsgLbl")}</label><textarea id="s-welcome" rows="2">${esc(st.welcomeMsg)}</textarea>
      <label>${t("menuHead")}</label>
      <input id="s-mhome" value="${esc(st.menuHome)}" placeholder="${t("home")}" style="margin-bottom:8px">
      <input id="s-mprog" value="${esc(st.menuProgram)}" placeholder="${t("program")}" style="margin-bottom:8px">
      <input id="s-mtick" value="${esc(st.menuTickets)}" placeholder="${t("tickets")}" style="margin-bottom:8px">
      <input id="s-mchat" value="${esc(st.menuChat)}" placeholder="${t("chat")}" style="margin-bottom:8px">
      <input id="s-mstay" value="${esc(st.menuStay)}" placeholder="${t("myStay")}">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setFeaturesView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setFeatures"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("featuresLbl")}</label>
      <div class="feat-list">
        ${[["quiz","featQuiz"],["tickets","featTickets"],["gallery","featGallery"],["bus","featBus"],["hotelinfo","featInfo"],["weather","weatherTab"]].map(([k,lb])=>
          `<label class="feat-it"><input type="checkbox" class="feat-cb" value="${k}" ${featureOn(k)?"checked":""}> ${t(lb)}</label>`).join("")}
      </div>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLocationView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLocation"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("weatherLoc")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("weatherLocHint")}</p>
      <div class="row2">
        <div><input id="s-lat" value="${esc(st.lat||"")}" placeholder="27.2579" inputmode="decimal"></div>
        <div><input id="s-lon" value="${esc(st.lon||"")}" placeholder="33.8116" inputmode="decimal"></div>
      </div>
      <label>${t("timezoneLbl")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("timezoneHint")}</p>
      <select id="s-tz">${TIMEZONES.map(z=>`<option value="${esc(z)}" ${(st.timezone||"")===z?"selected":""}>${z||"—"}</option>`).join("")}</select>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLinksView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLinksT"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("linksHead")}</label>
      <input id="s-trip" value="${esc(st.tripadvisor)}" placeholder="Tripadvisor URL" style="margin-bottom:8px">
      <input id="s-goog" value="${esc(st.google)}" placeholder="Google URL" style="margin-bottom:8px">
      <input id="s-holi" value="${esc(st.holidaycheck)}" placeholder="HolidayCheck URL">
      <label>${t("socialHead")}</label>
      <input id="s-insta" value="${esc(st.instagram)}" placeholder="Instagram URL" style="margin-bottom:8px">
      <input id="s-tiktok" value="${esc(st.tiktok)}" placeholder="TikTok URL" style="margin-bottom:8px">
      <input id="s-fb" value="${esc(st.facebook)}" placeholder="Facebook URL" style="margin-bottom:8px">
      <input id="s-yt" value="${esc(st.youtube)}" placeholder="YouTube URL" style="margin-bottom:8px">
      <label style="margin-top:4px">${t("whatsappLbl")}</label>
      <input id="s-wa" value="${esc(st.whatsapp)}" placeholder="+20 100 000 0000" inputmode="tel">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setAdvancedView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setAdvanced"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:10px">${t("serverHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("serverHint")}</p>
      <input id="s-aiep" value="${esc(st.aiEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/ai-assistant" style="margin-bottom:8px">
      <input id="s-pushep" value="${esc(st.pushEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/send-push">
            <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setNotifView(){
  return `<div class="screen fadein">
    ${topBar(t("setNotif"),S.session.name)}
    ${hubBack()}
    <div class="card notif-card" id="notif-toggle">
      <div class="nt-l"><span class="nt-ic">${ic(notifSoundOn()?"bell":"belloff",20)}</span>
        <div><b>${t("notifSound")}</b><p class="mini">${t("enableNotif")}</p></div></div>
      <span class="switch ${notifSoundOn()?"on":""}"><span class="knob"></span></span>
    </div>
  </div>`;
}

/* ---------------- modals ---------------- */
function baseModal(html){
  const wrap=document.createElement("div"); wrap.className="modal-bg";
  wrap.innerHTML=`<div class="modal"><div class="grab"></div>${html}</div>`;
  document.body.appendChild(wrap);
  wrap.onclick=e=>{ if(e.target===wrap) wrap.remove(); };
  return wrap;
}
function openBookModal(a){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const wrap=baseModal(`
    <h3>${esc(a.name)}</h3>
    <p class="mini">${mi("clock")}${esc(a.time)} · ${mi("pin")}${esc(a.location)}${unlimited?"":" · "+(full?t("full"):left+" "+t("seatsLeft"))}</p>
    <p style="margin-top:8px">${esc(a.desc)}</p>
    <label>${t("persons")}</label>
    <input id="m-ad" type="number" min="1" max="20" value="1" inputmode="numeric">
    <button class="btn" id="m-go">${full?t("waitlist"):t("confirm")}</button>
    <button class="btn ghost" id="m-x">${t("close")}</button>`);
  wrap.querySelector("#m-x").onclick=()=>wrap.remove();
  wrap.querySelector("#m-go").onclick=async ()=>{
    const g=S.session;
    await DB.addBooking({activity_id:a.id,room:g.room,guest_name:g.name,phone:g.phone||"",nationality:g.nationality||"",
      adults:Math.max(1,+wrap.querySelector("#m-ad").value||1),children:0,
      status: full?"waitlist":"booked"});
    wrap.remove(); toast(full?t("waitOk"):t("bookingOk")); render();
  };
}
function openTicketBuyModal(tk){
  const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
  const max=left!==null?Math.max(1,Math.min(10,left)):10;
  const team=teamMemberList();
  let chosen="";
  const wrap=baseModal(`
    <h3>${esc(tk.name)}</h3>
    <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}</p>
    <p style="margin-top:8px">${esc(tk.desc)}</p>
    <p class="mini" style="margin-top:8px">${t("payNote")}</p>
    <div class="row2" style="align-items:end">
      <div><label>${t("qty")}</label><input id="tq" type="number" min="1" max="${max}" value="1"></div>
      <div style="text-align:end;font-family:var(--font-display);font-size:24px;color:var(--cacao);padding-bottom:10px">${esc(tk.price||"")}</div>
    </div>
    ${team.length?`<label>${t("collectFrom")}</label>
    <div class="memberrow">
      ${team.map(m=>`<button type="button" class="memb" data-memb="${esc(m.name)}">
        <span class="mb-av">${m.photo?`<img src="${esc(m.photo)}" alt="">`:esc(m.name.trim().charAt(0).toUpperCase())}</span>
        <span class="mb-nm">${esc(m.name)}</span>
      </button>`).join("")}
    </div>`:""}
    <button class="btn" id="t-go">${t("buyTicket")}</button>
    <div class="err" id="t-err"></div>
    <button class="btn ghost" id="t-x">${t("close")}</button>`);
  wrap.querySelector("#t-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-memb]").forEach(b=>b.onclick=()=>{
    chosen=b.dataset.memb;
    wrap.querySelectorAll(".memb").forEach(x=>x.classList.toggle("on",x===b));
    wrap.querySelector("#t-err").textContent="";
  });
  wrap.querySelector("#t-go").onclick=async ()=>{
    if(team.length && !chosen){ wrap.querySelector("#t-err").textContent=t("chooseMember"); return; }
    const g=S.session;
    const qty=Math.max(1,Math.min(max,+wrap.querySelector("#tq").value||1));
    await DB.addOrder({ticket_id:tk.id,room:g.room,guest_name:g.name,nationality:g.nationality||"",
      qty,status:"reserved",collect_from:chosen});
    wrap.remove(); toast(t("ticketOk")); render();
  };
}
function openRequestModal(type){
  const isSong=type==="song";
  const wrap=baseModal(`
    <h3>${ic(isSong?"music":"gift",20)} ${isSong?t("songRequest"):t("birthdayRequest")}</h3>
    <label>${isSong?t("songName"):t("forWhom")}</label><input id="r-detail">
    ${isSong?"":`<label>${t("birthdayDate")}</label><input id="r-date" type="date">`}
    <label>${t("reqNote")}</label><textarea id="r-note" rows="2"></textarea>
    <button class="btn" id="r-go">${t("send")}</button>
    <button class="btn ghost" id="r-x">${t("close")}</button>`);
  wrap.querySelector("#r-x").onclick=()=>wrap.remove();
  wrap.querySelector("#r-go").onclick=async ()=>{
    const detail=wrap.querySelector("#r-detail").value.trim();
    if(!detail) return;
    const g=S.session;
    await DB.addRequest({room:g.room,guest_name:g.name,type,detail,
      date:isSong?"":(wrap.querySelector("#r-date").value||""),
      note:wrap.querySelector("#r-note").value.trim(),status:"new"});
    wrap.remove(); toast(t("saved")); render();
  };
}
function openTaskAddModal(){
  const staffOpts=S.users.filter(u=>u.role==="staff").map(u=>`<option value="${esc(u.username)}">${esc(u.display_name||u.username)}</option>`).join("");
  const typeOpts=TASK_TYPES.map(ty=>`<option value="${ty}">${taskTypeLabel(ty)}</option>`).join("");
  const wrap=baseModal(`
    <h3>${t("addTask")}</h3>
    <label>${t("taskType")}</label><select id="tk-type">${typeOpts}</select>
    <label>${t("actName")}</label><input id="tk-title">
    <label>${t("location")}</label><input id="tk-loc">
    <label>${t("desc")}</label><textarea id="tk-desc" rows="2"></textarea>
    <label>${t("taskFor")}</label>
    <select id="tk-for"><option value="">${t("allTeam")}</option>${staffOpts}</select>
    <label>${t("taskPriority")}</label>
    <select id="tk-pri">${PRIORITIES.map(([k,lb])=>`<option value="${k}" ${k==="normal"?"selected":""}>${t(lb)}</option>`).join("")}</select>
    <label>${t("dueLbl")}</label><input id="tk-due" type="datetime-local">
    <button class="btn" id="tk-go">${t("save")}</button>
    <button class="btn ghost" id="tk-x">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tk-go").onclick=async ()=>{
    const title=wrap.querySelector("#tk-title").value.trim();
    if(!title) return;
    await DB.addTask({type:wrap.querySelector("#tk-type").value,title,
      location:wrap.querySelector("#tk-loc").value.trim(),
      desc:wrap.querySelector("#tk-desc").value.trim(),
      assigned_to:wrap.querySelector("#tk-for").value,
      due:wrap.querySelector("#tk-due").value||"",
      priority:wrap.querySelector("#tk-pri").value,
      created_by:S.session.name||S.session.username||"",
      status:"new",was_still:false,
      history:[{at:new Date().toISOString(), by:S.session.name||S.session.username||"", to:"new"}],
      comments:[]});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* The full feedback sheet: who the guest is and a 1-5 score per department.
   Nothing is compulsory except the room number, so a guest who only wants to
   rate the food can still be recorded. */
function openFeedbackModal(id){
  const ex = id!=null ? (S.feedback||[]).find(f=>String(f.id)===String(id)) : null;
  const vals = ex ? {...fbDepts(ex)} : {};
  const rooms=knownRooms();
  const wrap=baseModal(`
    <h3>${ic("star",18)} ${ex?t("fbEdit"):t("fbNew")}</h3>
    <label>${t("room")}</label>
    <input id="fb-room" inputmode="numeric" list="fbroomlist" autocomplete="off" value="${esc(ex&&ex.room||"")}">
    <datalist id="fbroomlist">${rooms.map(r=>`<option value="${esc(r)}">`).join("")}</datalist>
    ${rooms.length?`<div class="fb-rooms" id="fb-roomchips">${rooms.slice(0,40).map(r=>
      `<button class="fb-rchip" data-fbroom="${esc(r)}">${esc(r)}</button>`).join("")}</div>`:""}
    <p class="mini" id="fb-found" style="margin:6px 0 0">${t("fbRoomHint")}</p>
    <label style="margin-top:12px">${t("fbGuestName")}</label><input id="fb-name" value="${esc(ex&&ex.guest_name||"")}">
    <label>${t("nationality")}</label>
    ${nationField("fb-natsel","fb-nattxt", ex&&ex.nationality||"")}
    <p class="mini" style="margin:4px 0 0">${t("natOtherHint")}</p>
    <label style="margin-top:12px">${t("fbByDept")}</label>
    <p class="mini" style="margin:-4px 0 6px">${t("fbFormHint")}</p>
    <div class="card" id="fb-depts" style="padding:4px 14px"></div>
    <label style="margin-top:12px">${t("comment")}</label><textarea id="fb-com" rows="2">${esc(ex?fbComment(ex):"")}</textarea>
    <button class="btn" id="fb-go">${t("save")}</button>
    <button class="btn ghost" id="fb-x">${t("close")}</button>`);
  const box=wrap.querySelector("#fb-depts");
  const paint=()=>{
    box.innerHTML=fbDeptKeys().map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>
      <span class="fb-stars">${[1,2,3,4,5].map(i=>
        `<button class="fb-st ${i<=(+vals[k]||0)?"on":""}" data-fbset="${k}|${i}" aria-label="${i}">${i<=(+vals[k]||0)?"\u2605":"\u2606"}</button>`).join("")}</span>
      <button class="fb-clear" data-fbclr="${k}" aria-label="${t("fbNotRated")}" ${vals[k]?"":'style="visibility:hidden"'}>\u00d7</button>
    </div>`).join("");
    box.querySelectorAll("[data-fbset]").forEach(b=>b.onclick=()=>{
      const [k,v]=b.dataset.fbset.split("|"); vals[k]=+v; paint();
    });
    box.querySelectorAll("[data-fbclr]").forEach(b=>b.onclick=()=>{ delete vals[b.dataset.fbclr]; paint(); });
  };
  paint();
  wireNatPicker(wrap,"fb-natsel","fb-nattxt");
  /* Look the room up as she types: a registered guest fills in their own name
     and nationality, but anything she typed herself is left alone. */
  const roomIn=wrap.querySelector("#fb-room");
  const nameIn=wrap.querySelector("#fb-name");
  const natSel=wrap.querySelector("#fb-natsel");
  const natTxt=wrap.querySelector("#fb-nattxt");
  const found=wrap.querySelector("#fb-found");
  let nameTouched=!!(ex&&ex.guest_name), natTouched=!!(ex&&ex.nationality);
  if(nameIn) nameIn.oninput=()=>{ nameTouched=true; };
  if(natSel) natSel.addEventListener("change",()=>{ natTouched=true; });
  if(natTxt) natTxt.oninput=()=>{ natTouched=true; };
  const setNat=v=>{
    if(!natSel) return;
    const known=NATIONS.includes(v);
    natSel.value = v ? (known?v:"Other") : "";
    if(natTxt){ natTxt.value = (v && !known) ? v : ""; natTxt.style.display = natSel.value==="Other" ? "" : "none"; }
  };
  const lookup=()=>{
    const g=guestForRoom(roomIn?roomIn.value:"");
    if(!found) return;
    if(!roomIn || !roomIn.value.trim()){ found.textContent=t("fbRoomHint"); return; }
    if(!g){ found.textContent=t("noGuestAccount"); return; }
    found.textContent=t("fbFoundGuest")+": "+(g.name||g.room)+(g.nationality?" \u00b7 "+g.nationality:"");
    if(!nameTouched && nameIn) nameIn.value=g.name||"";
    if(!natTouched) setNat(g.nationality||"");
  };
  if(roomIn){ roomIn.oninput=lookup; roomIn.onchange=lookup; }
  wrap.querySelectorAll("[data-fbroom]").forEach(b=>b.onclick=()=>{
    if(roomIn){ roomIn.value=b.dataset.fbroom; lookup(); }
  });
  lookup();
  wrap.querySelector("#fb-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fb-go").onclick=async ()=>{
    const room=wrap.querySelector("#fb-room").value.trim();
    if(!room){ toastErr(t("fbNeedRoom")); return; }
    const dep={}; fbDeptKeys().forEach(k=>{ if(+vals[k]>0) dep[k]=+vals[k]; });
    const scores=Object.values(dep);
    const rate = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : (ex?+ex.rate||5:5);
    const payload={
      room, guest_name:wrap.querySelector("#fb-name").value.trim(),
      nationality:readNatField(wrap,"fb-natsel","fb-nattxt"),
      rate, depts:JSON.stringify(dep),
      comment:wrap.querySelector("#fb-com").value.trim()
    };
    try{
      if(ex) await DB.updateFeedback(ex.id,payload);
      else await DB.addFeedback({...payload, by_user:(S.session&&S.session.username)||""});
      wrap.remove();
      if(S.fbOldDb){ S.fbOldDb=false; openFbSqlNote(); } else toastOk(t("saved"));
      render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* Shown once if her database is still missing the two new columns. */
function openFbSqlNote(){
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbSqlNote")}</h3>
    <p class="mini">${t("fbOldDb")}</p>
    <div class="fb-sql">${esc(FB_SQL)}</div>
    <button class="btn" id="fq-x">${t("close")}</button>`);
  wrap.querySelector("#fq-x").onclick=()=>wrap.remove();
}
/* One feedback, opened up: every department it scored, then edit or delete. */
function openFeedbackDetail(id){
  const f=(S.feedback||[]).find(x=>String(x.id)===String(id));
  if(!f) return;
  const d=fbDepts(f);
  const rated=fbDeptKeys().filter(k=>+d[k]>0);
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("fbDetails")}</h3>
    <p class="mini">${t("room")} ${esc(f.room)}${f.guest_name?" \u00b7 "+esc(f.guest_name):""}${f.nationality?" \u00b7 "+esc(f.nationality):""}</p>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${fbOverall(f)?fbOverall(f).toFixed(1)+" \u2605":"\u2014"}</b><span>${t("fbOverall")}</span></div>
      <div class="stat"><b>${rated.length}</b><span>${t("fbDepartments")}</span></div>
    </div>
    ${rated.length?`<div class="card" style="padding:4px 14px">${rated.map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>${fbStars(d[k])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    ${fbComment(f)?`<p style="margin-top:10px">${esc(fbComment(f))}</p>`:""}
    <p class="mini">${mi("user")}${t("fbCollectedBy")}: ${esc(teamName(f.by_user))} \u00b7 ${fmtTime(f.created_at)}</p>
    ${fbCanEdit(f)?`<button class="btn" id="fd-edit">${ic("pen",16)} ${t("fbEdit")}</button>
    <button class="btn ghost warn" id="fd-del">${ic("trash",16)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="fd-x">${t("close")}</button>`);
  wrap.querySelector("#fd-x").onclick=()=>wrap.remove();
  const ed=wrap.querySelector("#fd-edit");
  if(ed) ed.onclick=()=>{ wrap.remove(); openFeedbackModal(f.id); };
  const del=wrap.querySelector("#fd-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),note:t("cannotUndo"),danger:true})) return;
    try{ await DB.deleteFeedback(f.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
/* One department, opened up: every rating behind the average. */
function openDeptDetail(key){
  const all=S.feedback||[];
  const list=all.filter(f=>+fbDepts(f)[key]>0)
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const st=fbDeptStats(all).find(x=>x.k===key)||{avg:0,n:0};
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${esc(fbDeptLabel(key))}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${st.avg?st.avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${st.n}</b><span>${t("fbResponses")}</span></div>
    </div>
    ${list.length?`<div class="card">${list.map(f=>`<div class="fb-line" data-fbjump="${esc(String(f.id))}">
      <span style="min-width:0"><b>${t("room")} ${esc(f.room)}</b>${f.guest_name?" \u00b7 "+esc(f.guest_name):""}
        <br><span class="mini">${fmtTime(f.created_at)}${fbComment(f)?" \u00b7 "+esc(fbComment(f)):""}</span></span>
      ${fbStars(fbDepts(f)[key])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    <button class="btn ghost" id="dd-x">${t("close")}</button>`);
  wrap.querySelector("#dd-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-fbjump]").forEach(b=>b.onclick=()=>{
    const fid=b.dataset.fbjump; wrap.remove(); openFeedbackDetail(fid);
  });
}
/* Excel or PDF, straight from the feedback page: the sheet plus a department summary. */
/* The manager decides what guests get asked about. Keys are never reused or
   rewritten, so renaming a department keeps every rating it already has. */
function openDeptEditor(){
  let rows=fbDeptRows();
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbDeptsEdit")}</h3>
    <p class="mini">${t("fbDeptsHint")}</p>
    <div id="de-box"></div>
    <button class="btn ghost" id="de-add">\uFF0B ${t("fbAddDept")}</button>
    <button class="btn" id="de-go">${t("save")}</button>
    <button class="btn ghost" id="de-reset">${t("fbResetDepts")}</button>
    <button class="btn ghost" id="de-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#de-box");
  const label=r=>r.name || (t("d_"+r.key)==="d_"+r.key ? r.key : t("d_"+r.key));
  const paint=()=>{
    box.innerHTML=rows.map((r,i)=>`<div class="ar-it">
      <span class="ar-nm">${esc(label(r))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-deup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-dedown="${i}" ${i===rows.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b" data-dename="${i}" aria-label="${t("rename")}">${ic("pen",14)}</button>
        <button class="bd-b warn" data-dedel="${i}" aria-label="${t("delete")}">${ic("trash",14)}</button>
      </span></div>`).join("");
    box.querySelectorAll("[data-deup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.deup; [rows[i-1],rows[i]]=[rows[i],rows[i-1]]; paint(); });
    box.querySelectorAll("[data-dedown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dedown; [rows[i+1],rows[i]]=[rows[i],rows[i+1]]; paint(); });
    box.querySelectorAll("[data-dename]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dename;
      openTextPrompt(t("fbDeptName"), label(rows[i]), v=>{ if(v){ rows[i]={...rows[i], name:v}; paint(); } });
    });
    box.querySelectorAll("[data-dedel]").forEach(b=>b.onclick=async ()=>{
      const i=+b.dataset.dedel;
      if(rows.length<=1){ toastErr(t("fbLastDept")); return; }
      if(!await confirmAction({question:label(rows[i]),note:t("fbDeptGone"),danger:true})) return;
      rows.splice(i,1); paint();
    });
  };
  paint();
  wrap.querySelector("#de-add").onclick=()=>openTextPrompt(t("fbDeptName"),"",v=>{
    if(!v) return;
    rows.push({key:fbNewDeptKeyFrom(rows,v), name:v}); paint();
  });
  wrap.querySelector("#de-x").onclick=()=>wrap.remove();
  const save=async list=>{
    try{
      await DB.saveSettings({...S.settings, fbDepts:list});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#de-reset").onclick=()=>save(FB_DEPT_KEYS.map(k=>({key:k,name:""})));
  wrap.querySelector("#de-go").onclick=()=>save(rows);
}
/* A key that is unique inside the list being edited, not just the saved one. */
function fbNewDeptKeyFrom(rows,name){
  const slug=String(name||"").toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,20);
  const base="x_"+(slug||"dept");
  const taken=rows.map(r=>String(r.key)).concat(FB_DEPT_KEYS);
  let k=base, i=2;
  while(taken.includes(k)) k=base+"_"+(i++);
  return k;
}
/* A one-field prompt — used for renaming and adding departments. */
function openTextPrompt(title, value, done){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${esc(title)}</h3>
    <input id="tp-v" value="${esc(value||"")}" autocapitalize="words">
    <button class="btn" id="tp-go">${t("save")}</button>
    <button class="btn ghost" id="tp-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#tp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tp-go").onclick=()=>{
    const v=wrap.querySelector("#tp-v").value.trim();
    wrap.remove(); done(v);
  };
}
/* ===== REQUIREMENT SHEETS =====
   One sheet per event, activity or party: what is needed, how much of it, and
   which department provides it. Sent to hotel management the day before.
   Everything lives in settings so there is no new database table to create. */
const REQ_KINDS=["event","activity","party"];
const REQ_DEPTS_DEFAULT=["Entertainment","F&B","Housekeeping","Engineering","Security","Reception"];
const REQ_TEMPLATES_DEFAULT={
  event:[
    {need:"Tables", qty:"5",  dept:"F&B"},
    {need:"Chairs", qty:"30", dept:"F&B"},
    {need:"Decoration", qty:"\u2014", dept:"Housekeeping"},
    {need:"Sound system", qty:"1", dept:"Entertainment"},
    {need:"Lighting", qty:"4", dept:"Engineering"}],
  activity:[
    {need:"Mats", qty:"10", dept:"Entertainment"},
    {need:"Speaker", qty:"1", dept:"Entertainment"},
    {need:"Water", qty:"10", dept:"F&B"}],
  party:[
    {need:"DJ setup", qty:"1", dept:"Entertainment"},
    {need:"Lights", qty:"6", dept:"Engineering"},
    {need:"Bar setup", qty:"1", dept:"F&B"},
    {need:"Decoration", qty:"\u2014", dept:"Housekeeping"},
    {need:"Security", qty:"2", dept:"Security"}]
};
/* Event sheets pick from the day events, activity sheets from the daytime
   activities, party sheets from the parties and the shows. */
function reqCatsFor(kind){
  return kind==="activity" ? ["mAdult"]
       : kind==="party"    ? ["eParty","eShow"]
       : ["mEvents"];
}
function reqStartTime(a){
  return String(a && a.time || "").split(/\s*[\u2013\u2014-]\s*/)[0].trim();
}
function reqProgramList(kind){
  const cats=reqCatsFor(kind);
  return (S.activities||[]).filter(a=>a && a.name && cats.includes(normCat(a)))
    .slice().sort((x,y)=>((x.day||0)-(y.day||0)) || ((timeToMin(reqStartTime(x))||0)-(timeToMin(reqStartTime(y))||0)));
}
/* An activity repeats every week, a sheet is for one date: take the next time
   that weekday comes round, counting from the date already on the sheet. */
function nextDateForDay(dayIdx, fromISO){
  const base = fromISO ? new Date(fromISO+"T12:00:00") : new Date();
  if(isNaN(base.getTime())) return todayISO();
  const add=(((+dayIdx||0)-((base.getDay()+6)%7))+7)%7;
  const d=new Date(base.getTime()); d.setDate(d.getDate()+add);
  const p2=n=>String(n).padStart(2,"0");
  return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate());
}
function reqKindLabel(k){
  return k==="activity" ? t("reqKindActivity") : k==="party" ? t("reqKindParty") : t("reqKindEvent");
}
function reqSheetTitle(k){
  return k==="activity" ? t("reqActivity") : k==="party" ? t("reqParty") : t("reqEvent");
}
function reqDepts(){
  const c=S.settings && S.settings.reqDepts;
  return (Array.isArray(c) && c.length) ? c.slice() : REQ_DEPTS_DEFAULT.slice();
}
function reqTemplate(kind){
  const c=S.settings && S.settings.reqTemplates;
  const v=c && c[kind];
  return (Array.isArray(v) ? v : (REQ_TEMPLATES_DEFAULT[kind]||[]))
    .map(r=>({need:r.need||"", qty:r.qty||"", dept:r.dept||""}));
}
function reqSheets(){
  const c=S.settings && S.settings.reqSheets;
  return Array.isArray(c) ? c.filter(x=>x && x.id) : [];
}
function reqSheet(id){ return reqSheets().find(x=>String(x.id)===String(id)) || null; }
async function reqSave(list){
  await DB.saveSettings({...S.settings, reqSheets:list});
}
function reqSorted(){
  return reqSheets().slice().sort((a,b)=>
    String(a.date||"9999").localeCompare(String(b.date||"9999"))
    || String(a.time||"").localeCompare(String(b.time||"")));
}
function reqForDate(day){
  const all=reqSorted();
  return day ? all.filter(x=>String(x.date||"")===day) : all;
}
function reqDone(sh){ return (sh.rows||[]).filter(r=>r.done).length; }

/* ---- the page ---- */
function requirementsView(){
  const day=S.reqDate||"";
  const list=reqForDate(day);
  return `<div class="screen fadein">
    ${topBar(t("reqTab"),S.session.name)}
    <p class="mini" style="margin:-4px 0 12px">${t("reqSub")}</p>
    <div class="row2" style="margin-bottom:10px">
      <button class="btn" id="rq-new">\uFF0B ${t("reqNew")}</button>
      <button class="btn ghost" id="rq-pack">${ic("download",15)} ${t("reqExportDay")}</button>
    </div>
    <div class="row2" style="margin-bottom:14px">
      <button class="btn ghost sm" id="rq-depts">${ic("grid",14)} ${t("reqDepts")}</button>
      <button class="btn ghost sm" id="rq-tpl">${ic("pen",14)} ${t("reqTemplates")}</button>
    </div>
    <label>${t("reqPickDate")}</label>
    <input type="date" id="rq-date" value="${esc(day)}" style="margin-bottom:14px">
    ${list.length ? `<div class="card" style="padding:2px 14px">${list.map(sh=>`
      <div class="rq-it" data-rqopen="${esc(String(sh.id))}">
        <span class="rq-kind ${esc(sh.kind)}">${esc(reqKindLabel(sh.kind))}</span>
        <span class="rq-mid"><b>${esc(sh.title||reqSheetTitle(sh.kind))}</b>
          <span class="mini">${[sh.date?niceDate(sh.date):"", sh.time, sh.location].filter(Boolean).map(esc).join(" \u00b7 ")}</span>
          <span class="mini">${(sh.rows||[]).length} ${t("reqLines")} \u00b7 ${reqDone(sh)}/${(sh.rows||[]).length} ${t("reqStatus").toLowerCase()}</span></span>
        <span class="rq-go">${ic("back",16)}</span>
      </div>`).join("")}</div>`
      : `<div class="empty"><div class="big">${ic("clipboard",30)}</div>${day?t("reqNothingOn"):t("reqNone")}</div>`}
  </div>`;
}

/* ---- the sheet editor ---- */
function openReqEditor(id,prefillActId){
  const ex=id?reqSheet(id):null;
  const pre=(!ex && prefillActId)?(S.activities||[]).find(a=>String(a.id)===String(prefillActId)):null;
  const preKind=pre?(normCat(pre)==="mAdult"?"activity":(["eParty","eShow"].includes(normCat(pre))?"party":"event")):"event";
  let sh = ex ? JSON.parse(JSON.stringify(ex)) : {
    id:"rq"+Date.now(), kind:preKind, actId:pre?pre.id:"", title:pre?(pre.name||""):"",
    date:pre?nextDateForDay(pre.day,todayISO()):todayISO(), time:pre?reqStartTime(pre):"", location:pre?(pre.location||""):"",
    responsible:"", note:"", rows:reqTemplate(preKind)
  };
  sh.rows=Array.isArray(sh.rows)?sh.rows:[];
  const wrap=baseModal(`
    <h3>${ic("clipboard",20)} ${ex?t("reqEdit"):t("reqNew")}</h3>
    <label>${t("reqKind")}</label>
    <div class="pills" id="rq-kinds" style="margin-bottom:10px">
      ${REQ_KINDS.map(k=>`<button class="pill ${sh.kind===k?"on":""}" data-rqkind="${k}">${esc(reqKindLabel(k))}</button>`).join("")}
    </div>
    <label>${t("reqFromProgram")}</label>
    <select id="rq-pick"></select>
    <p class="mini" style="margin:4px 0 0">${t("reqFromProgramHint")}</p>
    <label style="margin-top:12px">${t("reqName")}</label><input id="rq-title" value="${esc(sh.title||"")}">
    <div class="row2" style="margin-top:10px">
      <div><label>${t("reqDate")}</label><input type="date" id="rq-d" value="${esc(sh.date||"")}"></div>
      <div><label>${t("time")}</label><input id="rq-t" value="${esc(sh.time||"")}" placeholder="21:00"></div>
    </div>
    <label style="margin-top:10px">${t("reqLocation")}</label><input id="rq-loc" value="${esc(sh.location||"")}">
    <label style="margin-top:14px">${t("reqNeed")}</label>
    <div id="rq-rows"></div>
    <div class="row2" style="margin-top:8px">
      <button class="btn ghost sm" id="rq-add">\uFF0B ${t("reqAddLine")}</button>
      <button class="btn ghost sm" id="rq-std">${t("reqStandard")}</button>
    </div>
    <label style="margin-top:14px">${t("reqNote")}</label><textarea id="rq-note" rows="2">${esc(sh.note||"")}</textarea>
    <label>${t("reqResponsible")}</label><input id="rq-resp" value="${esc(sh.responsible||"")}">
    <button class="btn" id="rq-go" style="margin-top:14px">${t("save")}</button>
    <button class="btn ghost" id="rq-pdf">${ic("download",16)} ${t("reqExportOne")}</button>
    ${ex?`<button class="btn ghost warn" id="rq-del">${ic("trash",16)} ${t("reqDelete")}</button>`:""}
    <button class="btn ghost" id="rq-x">${t("cancelBtn")}</button>`);

  const box=wrap.querySelector("#rq-rows");
  const paintRows=()=>{
    const depts=reqDepts();
    box.innerHTML = sh.rows.length ? sh.rows.map((r,i)=>`<div class="rq-row">
      <input class="rq-need" data-rqneed="${i}" value="${esc(r.need||"")}" placeholder="${esc(t("reqNeed"))}">
      <input class="rq-qty" data-rqqty="${i}" value="${esc(r.qty||"")}" placeholder="${esc(t("reqQty"))}">
      <select class="rq-dep" data-rqdept="${i}">
        <option value="">\u2014</option>
        ${depts.map(d=>`<option value="${esc(d)}" ${String(r.dept||"")===d?"selected":""}>${esc(d)}</option>`).join("")}
        ${r.dept && !depts.includes(r.dept) ? `<option value="${esc(r.dept)}" selected>${esc(r.dept)}</option>` : ""}
      </select>
      <span class="rq-acts">
        <button class="bd-b ${r.done?"on":""}" data-rqtick="${i}" aria-label="${t("reqStatus")}">${ic("check",13)}</button>
        <button class="bd-b" data-rqup="${i}" ${i===0?"disabled":""}>${ic("back",13)}</button>
        <button class="bd-b down" data-rqdown="${i}" ${i===sh.rows.length-1?"disabled":""}>${ic("back",13)}</button>
        <button class="bd-b warn" data-rqdel="${i}">${ic("trash",13)}</button>
      </span></div>`).join("")
      : `<p class="mini">${t("reqNoLines")}</p>`;
    box.querySelectorAll("[data-rqneed]").forEach(el=>el.oninput=()=>{ sh.rows[+el.dataset.rqneed].need=el.value; });
    box.querySelectorAll("[data-rqqty]").forEach(el=>el.oninput=()=>{ sh.rows[+el.dataset.rqqty].qty=el.value; });
    box.querySelectorAll("[data-rqdept]").forEach(el=>el.onchange=()=>{ sh.rows[+el.dataset.rqdept].dept=el.value; });
    box.querySelectorAll("[data-rqtick]").forEach(b=>b.onclick=()=>{
      const r=sh.rows[+b.dataset.rqtick]; r.done=!r.done; paintRows(); });
    box.querySelectorAll("[data-rqup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rqup; [sh.rows[i-1],sh.rows[i]]=[sh.rows[i],sh.rows[i-1]]; paintRows(); });
    box.querySelectorAll("[data-rqdown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rqdown; [sh.rows[i+1],sh.rows[i]]=[sh.rows[i],sh.rows[i+1]]; paintRows(); });
    box.querySelectorAll("[data-rqdel]").forEach(b=>b.onclick=()=>{
      sh.rows.splice(+b.dataset.rqdel,1); paintRows(); });
  };
  paintRows();

  const pick=wrap.querySelector("#rq-pick");
  const paintPick=()=>{
    if(!pick) return;
    const list=reqProgramList(sh.kind);
    pick.innerHTML=`<option value="">${esc(t("reqFromProgramOwn"))}</option>`
      + list.map(a=>{
          const bits=[(t("daysShort")[a.day]||""), reqStartTime(a), a.name, a.location].filter(Boolean);
          return `<option value="${esc(String(a.id))}" ${String(sh.actId||"")===String(a.id)?"selected":""}>${esc(bits.join(" \u00b7 "))}</option>`;
        }).join("")
      + (list.length?"":`<option value="" disabled>${esc(t("reqNoProgram"))}</option>`);
    pick.onchange=()=>{
      const a=(S.activities||[]).find(x=>String(x.id)===String(pick.value));
      sh.actId = a ? a.id : "";
      if(!a) return;
      const tt=wrap.querySelector("#rq-title"), dd=wrap.querySelector("#rq-d");
      const tm=wrap.querySelector("#rq-t"),     lc=wrap.querySelector("#rq-loc");
      if(tt) tt.value=a.name||"";
      if(tm) tm.value=reqStartTime(a);
      if(lc) lc.value=a.location||"";
      if(dd) dd.value=nextDateForDay(a.day, dd.value||todayISO());
    };
  };
  paintPick();

  wrap.querySelectorAll("[data-rqkind]").forEach(b=>b.onclick=()=>{
    sh.kind=b.dataset.rqkind;
    sh.actId="";                                  // a different kind means a different list
    wrap.querySelectorAll("[data-rqkind]").forEach(x=>x.classList.toggle("on", x.dataset.rqkind===sh.kind));
    paintPick();
  });
  wrap.querySelector("#rq-add").onclick=()=>{ sh.rows.push({need:"",qty:"",dept:""}); paintRows(); };
  wrap.querySelector("#rq-std").onclick=()=>{ sh.rows=sh.rows.concat(reqTemplate(sh.kind)); paintRows(); };

  const collect=()=>{
    sh.title=wrap.querySelector("#rq-title").value.trim();
    sh.date=wrap.querySelector("#rq-d").value;
    sh.time=wrap.querySelector("#rq-t").value.trim();
    sh.location=wrap.querySelector("#rq-loc").value.trim();
    sh.note=wrap.querySelector("#rq-note").value.trim();
    sh.responsible=wrap.querySelector("#rq-resp").value.trim();
    sh.rows=sh.rows.filter(r=>(r.need||"").trim() || (r.qty||"").trim())
      .map(r=>({need:r.need||"", qty:r.qty||"", dept:r.dept||"", done:!!r.done}));
    if(pick && !pick.value) sh.actId="";
    return sh;
  };
  wrap.querySelector("#rq-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rq-pdf").onclick=()=>{ exportRequirements([collect()]); };
  wrap.querySelector("#rq-go").onclick=async ()=>{
    const next=collect();
    const list=reqSheets().filter(x=>String(x.id)!==String(next.id));
    list.push(next);
    try{ await reqSave(list); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  const del=wrap.querySelector("#rq-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:sh.title||reqSheetTitle(sh.kind),note:t("cannotUndo"),danger:true})) return;
    try{ await reqSave(reqSheets().filter(x=>String(x.id)!==String(sh.id)));
      wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}

/* ---- the department list ---- */
function openReqDeptEditor(){
  let list=reqDepts();
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("reqDepts")}</h3>
    <p class="mini">${t("reqDeptsHint")}</p>
    <div id="rd-box"></div>
    <button class="btn ghost" id="rd-add">\uFF0B ${t("reqAddDept")}</button>
    <button class="btn" id="rd-go">${t("save")}</button>
    <button class="btn ghost" id="rd-reset">${t("reqResetLists")}</button>
    <button class="btn ghost" id="rd-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#rd-box");
  const paint=()=>{
    box.innerHTML=list.map((d,i)=>`<div class="ar-it">
      <span class="ar-nm">${esc(d)}</span>
      <span class="ar-acts">
        <button class="bd-b" data-rdup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-rddown="${i}" ${i===list.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b" data-rdname="${i}">${ic("pen",14)}</button>
        <button class="bd-b warn" data-rddel="${i}">${ic("trash",14)}</button>
      </span></div>`).join("");
    box.querySelectorAll("[data-rdup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rdup; [list[i-1],list[i]]=[list[i],list[i-1]]; paint(); });
    box.querySelectorAll("[data-rddown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rddown; [list[i+1],list[i]]=[list[i],list[i+1]]; paint(); });
    box.querySelectorAll("[data-rdname]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rdname;
      openTextPrompt(t("reqDept"), list[i], v=>{ if(v){ list[i]=v; paint(); } });
    });
    box.querySelectorAll("[data-rddel]").forEach(b=>b.onclick=()=>{
      if(list.length<=1){ toastErr(t("reqLastDept")); return; }
      list.splice(+b.dataset.rddel,1); paint(); });
  };
  paint();
  wrap.querySelector("#rd-add").onclick=()=>openTextPrompt(t("reqDept"),"",v=>{
    if(v && !list.includes(v)){ list.push(v); paint(); } });
  wrap.querySelector("#rd-x").onclick=()=>wrap.remove();
  const save=async v=>{
    try{ await DB.saveSettings({...S.settings, reqDepts:v}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#rd-reset").onclick=()=>save(REQ_DEPTS_DEFAULT.slice());
  wrap.querySelector("#rd-go").onclick=()=>save(list);
}

/* ---- the standard lists ---- */
function openReqTemplateEditor(){
  let kind="event";
  let data={}; REQ_KINDS.forEach(k=>{ data[k]=reqTemplate(k); });
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("reqTemplates")}</h3>
    <p class="mini">${t("reqTemplatesHint")}</p>
    <div class="pills" id="rt-kinds" style="margin-bottom:10px">
      ${REQ_KINDS.map(k=>`<button class="pill ${k==="event"?"on":""}" data-rtkind="${k}">${esc(reqKindLabel(k))}</button>`).join("")}
    </div>
    <div id="rt-box"></div>
    <button class="btn ghost" id="rt-add">\uFF0B ${t("reqAddLine")}</button>
    <button class="btn" id="rt-go">${t("save")}</button>
    <button class="btn ghost" id="rt-reset">${t("reqResetLists")}</button>
    <button class="btn ghost" id="rt-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#rt-box");
  const paint=()=>{
    const depts=reqDepts(), rows=data[kind];
    box.innerHTML = rows.length ? rows.map((r,i)=>`<div class="rq-row">
      <input class="rq-need" data-rtneed="${i}" value="${esc(r.need||"")}" placeholder="${esc(t("reqNeed"))}">
      <input class="rq-qty" data-rtqty="${i}" value="${esc(r.qty||"")}" placeholder="${esc(t("reqQty"))}">
      <select class="rq-dep" data-rtdept="${i}">
        <option value="">\u2014</option>
        ${depts.map(d=>`<option value="${esc(d)}" ${String(r.dept||"")===d?"selected":""}>${esc(d)}</option>`).join("")}
        ${r.dept && !depts.includes(r.dept) ? `<option value="${esc(r.dept)}" selected>${esc(r.dept)}</option>` : ""}
      </select>
      <span class="rq-acts"><button class="bd-b warn" data-rtdel="${i}">${ic("trash",13)}</button></span>
    </div>`).join("") : `<p class="mini">${t("reqNoLines")}</p>`;
    box.querySelectorAll("[data-rtneed]").forEach(el=>el.oninput=()=>{ data[kind][+el.dataset.rtneed].need=el.value; });
    box.querySelectorAll("[data-rtqty]").forEach(el=>el.oninput=()=>{ data[kind][+el.dataset.rtqty].qty=el.value; });
    box.querySelectorAll("[data-rtdept]").forEach(el=>el.onchange=()=>{ data[kind][+el.dataset.rtdept].dept=el.value; });
    box.querySelectorAll("[data-rtdel]").forEach(b=>b.onclick=()=>{ data[kind].splice(+b.dataset.rtdel,1); paint(); });
  };
  paint();
  wrap.querySelectorAll("[data-rtkind]").forEach(b=>b.onclick=()=>{
    kind=b.dataset.rtkind;
    wrap.querySelectorAll("[data-rtkind]").forEach(x=>x.classList.toggle("on", x.dataset.rtkind===kind));
    paint();
  });
  wrap.querySelector("#rt-add").onclick=()=>{ data[kind].push({need:"",qty:"",dept:""}); paint(); };
  wrap.querySelector("#rt-x").onclick=()=>wrap.remove();
  const save=async v=>{
    try{ await DB.saveSettings({...S.settings, reqTemplates:v}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#rt-reset").onclick=()=>save(JSON.parse(JSON.stringify(REQ_TEMPLATES_DEFAULT)));
  wrap.querySelector("#rt-go").onclick=()=>{
    REQ_KINDS.forEach(k=>{ data[k]=data[k].filter(r=>(r.need||"").trim()||(r.qty||"").trim()); });
    save(data);
  };
}

/* ---- the day pack ---- */
function openReqPack(){
  const day=S.reqDate||todayISO();
  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("reqExportDay")}</h3>
    <label>${t("reqPickDate")}</label>
    <input type="date" id="rp-d" value="${esc(day)}">
    <p class="mini" id="rp-n" style="margin-top:8px"></p>
    <button class="btn" id="rp-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="rp-xls">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="rp-blank">${t("reqBlank")}</button>
    <button class="btn ghost" id="rp-x">${t("close")}</button>`);
  const dIn=wrap.querySelector("#rp-d"), note=wrap.querySelector("#rp-n");
  const pick=()=>reqForDate(dIn?dIn.value:"");
  const sync=()=>{ if(note) note.textContent=pick().length+" "+t("reqDayPack").toLowerCase(); };
  if(dIn){ dIn.onchange=sync; dIn.oninput=sync; }
  sync();
  wrap.querySelector("#rp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rp-pdf").onclick=()=>{
    const list=pick();
    if(!list.length){ toastErr(t("reqNothingOn")); return; }
    exportRequirements(list, dIn?dIn.value:""); wrap.remove();
  };
  wrap.querySelector("#rp-xls").onclick=async ()=>{
    const list=pick();
    if(!list.length){ toastErr(t("reqNothingOn")); return; }
    await exportExcelSets(list.map(reqDataset), "requirements-"+(dIn?dIn.value:todayISO()));
    toast(t("saved"));
  };
  wrap.querySelector("#rp-blank").onclick=()=>{
    exportRequirements(REQ_KINDS.map(k=>({
      id:"blank-"+k, kind:k, title:"", date:"", time:"", location:"", responsible:"", note:"",
      rows:reqTemplate(k)
    })), "", true);
    wrap.remove();
  };
}
/* A one-page management sheet per event: hotel header, the table, a note box
   and signature lines. Almost no colour, because it gets printed and signed. */
function exportRequirements(sheets, day, blank){
  const E2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const hotel=(S.settings&&(S.settings.hotelName||S.settings.name))||"";
  const line=v=>v ? E2(v) : '<span class=bl></span>';
  const css=""
   +"@page{size:A4 portrait;margin:14mm}"
   +"*{box-sizing:border-box}"
   +"body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#1F1A15;margin:0;"
     +"-webkit-print-color-adjust:exact;print-color-adjust:exact}"
   +".sheet{page-break-after:always}"
   +".sheet:last-child{page-break-after:auto}"
   +".head{border-bottom:1.5px solid #2B1F16;padding-bottom:9px;margin-bottom:14px}"
   +".hotel{font-size:9.5px;letter-spacing:.3em;text-transform:uppercase;color:#6B5C4A;font-weight:700}"
   +"h1{font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400;margin:5px 0 0}"
   +".when{font-size:9px;color:#8A7C6A;margin-top:4px}"
   +".facts{display:flex;flex-wrap:wrap;gap:0 26px;margin-bottom:14px}"
   +".f{font-size:11px;padding:5px 0;min-width:150px}"
   +".f i{display:block;font-style:normal;font-size:8px;letter-spacing:.14em;text-transform:uppercase;"
     +"color:#8A7C6A;font-weight:700;margin-bottom:2px}"
   +".bl{display:inline-block;min-width:120px;border-bottom:1px solid #B9AE9E;height:12px}"
   +"table{border-collapse:collapse;width:100%;font-size:11px;margin-bottom:12px}"
   +"th{background:#F4F1EB;text-align:left;padding:7px 9px;border:1px solid #C9BEAE;font-size:8.5px;"
     +"letter-spacing:.12em;text-transform:uppercase;color:#4A3F33}"
   +"td{padding:8px 9px;border:1px solid #D8CFC1;vertical-align:middle}"
   +"td.qty{width:56px;text-align:center;font-weight:700}"
   +"td.dep{width:130px}"
   +"td.box{width:52px;text-align:center}"
   +".ck{display:inline-block;width:12px;height:12px;border:1.2px solid #6B5C4A}"
   +".notebox{border:1px solid #D8CFC1;border-radius:3px;padding:8px 10px;min-height:56px;margin-bottom:14px}"
   +".notebox i{display:block;font-style:normal;font-size:8px;letter-spacing:.14em;text-transform:uppercase;"
     +"color:#8A7C6A;font-weight:700;margin-bottom:4px}"
   +".notebox p{margin:0;font-size:10.5px;line-height:1.5}"
   +".sign{display:flex;gap:26px;margin-top:20px}"
   +".sign div{flex:1;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7C6A;font-weight:700}"
   +".sign span{display:block;border-bottom:1px solid #B9AE9E;height:26px;margin-bottom:4px}"
   +".foot{margin-top:16px;padding-top:8px;border-top:1px solid #E0D8CB;font-size:8.5px;color:#9C9081;"
     +"display:flex;justify-content:space-between}";

  const one=sh=>{
    const rows=(sh.rows||[]);
    const pad=Math.max(0, (blank?10:rows.length+2)-rows.length);   // room to write more by hand
    return '<div class=sheet><div class=head>'
      +(hotel?'<div class=hotel>'+E2(hotel)+'</div>':'')
      +'<h1>'+E2(reqSheetTitle(sh.kind))+'</h1>'
      +'<div class=when>'+E2(t("fbPrepared"))+' '+E2(new Date().toLocaleString())
        +(S.session&&S.session.name?' \u00b7 '+E2(S.session.name):'')+'</div>'
      +'</div>'
      +'<div class=facts>'
        +'<div class=f><i>'+E2(reqKindLabel(sh.kind))+'</i>'+line(sh.title)+'</div>'
        +'<div class=f><i>'+E2(t("reqDate"))+'</i>'+line(sh.date?niceDate(sh.date):"")+'</div>'
        +'<div class=f><i>'+E2(t("time"))+'</i>'+line(sh.time)+'</div>'
        +'<div class=f><i>'+E2(t("reqLocation"))+'</i>'+line(sh.location)+'</div>'
      +'</div>'
      +'<table><thead><tr>'
        +'<th>'+E2(t("reqNeed"))+'</th><th>'+E2(t("reqQty"))+'</th>'
        +'<th>'+E2(t("reqDept"))+'</th><th>'+E2(t("reqStatus"))+'</th></tr></thead><tbody>'
      + rows.map(r=>'<tr><td>'+E2(r.need||"")+'</td><td class=qty>'+E2(r.qty||"")+'</td>'
          +'<td class=dep>'+E2(r.dept||"")+'</td><td class=box><span class=ck></span></td></tr>').join("")
      + Array.from({length:pad}).map(()=>'<tr><td>&nbsp;</td><td class=qty></td>'
          +'<td class=dep></td><td class=box><span class=ck></span></td></tr>').join("")
      +'</tbody></table>'
      +'<div class=notebox><i>'+E2(t("reqNote"))+'</i><p>'+E2(sh.note||"")+'</p></div>'
      +'<div class=sign>'
        +'<div><span></span>'+E2(t("reqResponsible"))+(sh.responsible?' \u00b7 '+E2(sh.responsible):'')+'</div>'
        +'<div><span></span>'+E2(t("reqReceived"))+'</div>'
        +'<div><span></span>'+E2(t("reqSignature"))+'</div>'
      +'</div>'
      +'<div class=foot><span>'+E2(hotel||t("reqTab"))+'</span><span>'
        +E2(sh.date?niceDate(sh.date):(day?niceDate(day):t("reqTab")))+'</span></div>'
      +'</div>';
  };

  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+E2(t("reqTab"))+"</title><meta charset=utf-8>"
    +"<style>"+css+"</style></head><body>"+sheets.map(one).join("")
    +"<scr"+"ipt>setTimeout(function(){window.print();},400);<\/scr"+"ipt></body></html>");
  w.document.close();
}
function reqDataset(sh){
  return {
    title:(sh.title||reqSheetTitle(sh.kind))+(sh.date?" \u00b7 "+niceDate(sh.date):""),
    headers:[t("reqNeed"),t("reqQty"),t("reqDept"),t("reqStatus")],
    rows:(sh.rows||[]).map(r=>[r.need||"", r.qty||"", r.dept||"", r.done?"OK":""])
  };
}
/* ===== THE GUEST FEEDBACK REPORT =====
   Its own printed document rather than a generic table: a proper letterhead,
   a summary band, colour-coded stars, and only the departments that were
   actually rated in this selection — so no walls of empty dashes. */
function exportFeedbackReport(){
  const list=exportFeedbackList();
  const E2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const hotel=(S.settings&&(S.settings.hotelName||S.settings.name))||"";
  const bits=fbFilterBits();
  const cover=bits.length?bits.join(" \u00b7 "):t("fbWholeStay");
  const sum=fbSummary(list);
  const avg=sum.overall;

  const tone=n=>{ n=+n||0; return n<3.5?"#B0392B":n<4.5?"#D08526":"#B98A5C"; };
  const stars=(v,exact,strict)=>{
    let n=Math.round(+v||0);
    // in the shortfall table a 4.5 must not print as a full five
    if(strict && n>=5 && (+v||0)<4.995) n=4;
    if(!n) return '<span class=nr>\u00b7</span>';
    return '<span class=s style="color:'+tone(v)+'">'+"\u2605".repeat(n)
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span></span>'
      +(exact?'<em>'+E2(exact)+'</em>':'');
  };
  const tile=(lb,val,sub)=>'<div class=tile><span class=tl>'+E2(lb)+'</span>'
    +'<b>'+val+'</b>'+(sub?'<span class=ts>'+E2(sub)+'</span>':'')+'</div>';

  const css=""
   +"@page{size:A4 portrait;margin:14mm}"
   +"*{box-sizing:border-box}"
   +"body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#2B1F16;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
   +".head{padding:0 0 14px;border-bottom:2px solid #B98A5C;margin-bottom:16px}"
   +".hotel{font-size:10px;letter-spacing:.32em;text-transform:uppercase;color:#B98A5C;font-weight:700}"
   +"h1{font-family:Georgia,'Times New Roman',serif;font-size:27px;font-weight:400;margin:5px 0 3px;letter-spacing:.01em}"
   +".cover{font-size:13px;color:#6B4A32;font-weight:600}"
   +".meta{font-size:10px;color:#9C8A74;margin-top:5px}"
   +".band{display:flex;gap:9px;margin-bottom:16px}"
   +".tile{flex:1;background:#FBF7F0;border:1px solid #EADFCC;border-radius:9px;padding:10px 13px}"
   +".tile .tl{display:block;font-size:8.5px;letter-spacing:.16em;text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +".tile b{display:block;font-family:Georgia,serif;font-size:20px;font-weight:400;margin-top:3px;line-height:1.15}"
   +".tile .ts{display:block;font-size:10px;color:#6B4A32;margin-top:2px}"
   +".tile.warn{background:#FBF0EC;border-color:#E8CFC5}"
   +".tile.warn .tl{color:#B0392B}"
   +".pct{font-family:Georgia,serif}"
   +"h2.sub{font-family:Georgia,'Times New Roman',serif;font-size:15px;font-weight:400;"
     +"margin:20px 0 2px;color:#5A4029;letter-spacing:.01em}"
   +".subnote{font-size:10px;color:#9C8A74;margin:0 0 8px}"
   +".legend{margin:10px 0 0;font-size:9px;color:#9C8A74}"
   +"tr.r.low td{background:#FBF0EC}tr.c.low td{background:#F9EDE8}"
   +"tr.r.low td:first-child{box-shadow:inset 3px 0 0 #B0392B}"
   +"tr.r.low td.room{color:#B0392B}"
   +"tr.r.good td{background:#F5F8F2}tr.c.good td{background:#F8FAF6}"
   +"tr.r.good td:first-child{box-shadow:inset 3px 0 0 #6E9155}"
   +"tr.r.good td.room{color:#4A6B36}"
   +"tr.r.mid td{background:#FDF6EE}tr.c.mid td{background:#FAEEDF}"
   +"tr.r.mid td:first-child{box-shadow:inset 3px 0 0 #D08526}"
   +"tr.r.mid td.room{color:#A9631A}"
   +".tile.good{background:#F5F8F2;border-color:#DCE7D4}"
   +".tile.good .tl{color:#4A6B36}.tile.good b{color:#3F5C2F}"
   +".tile.attn{background:#FDF6EE;border-color:#EDDCC6}"
   +".tile.attn .tl{color:#A9631A}.tile.attn b{color:#8A4E12}"
   +".g{border:1px solid #EADFCC;border-radius:9px;padding:10px 12px;margin-bottom:8px;"
     +"page-break-inside:avoid;border-left-width:4px}"
   +".g.priority{border-left-color:#B0392B;background:#FCF4F2}"
   +".g.attn{border-left-color:#D08526;background:#FDF9F3}"
   +".g.none{border-left-color:#6E9155;background:#F7FAF5}"
   +".ghead{display:flex;align-items:center;gap:9px}"
   +".gr{font-family:Georgia,serif;font-size:16px;font-weight:400;color:#2B1F16}"
   +".gov{font-size:11px;letter-spacing:.3px}"
   +".gov .s em{display:inline;font-style:normal;font-size:10px;color:#6B4A32;margin-left:3px}"
   +".gs{margin-left:auto;font-size:8px;letter-spacing:.13em;text-transform:uppercase;font-weight:700;"
     +"display:inline-flex;align-items:center;gap:5px}"
   +".gs i{width:7px;height:7px;border-radius:50%;display:inline-block}"
   +".gs.priority{color:#B0392B}.gs.priority i{background:#B0392B}"
   +".gs.attn{color:#A9631A}.gs.attn i{background:#D08526}"
   +".gs.none{color:#4A6B36}.gs.none i{background:#6E9155}"
   +".gmeta{font-size:8.5px;color:#9C8A74;margin-top:2px}"
   +".gchips{margin-top:6px}"
   +".cleanbox{border:1px solid #DCE7D4;border-radius:9px;background:#F7FAF5;padding:2px 12px}"
   +".g5{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:7px 0;page-break-inside:avoid}"
   +".g5+.g5{border-top:1px solid #E4EEDE}"
   +".g5 .gmeta{margin:0}"
   +".tick{color:#6E9155;font-weight:700;font-size:12px}"
   +".g5 p.note{flex:1 0 100%;margin:2px 0 0}"
   +"table.rooms{font-size:10px}"
   +"table.rooms td{padding:7px 6px}"
   +"td.by{font-size:9px;color:#6B4A32}"
   +".chip{display:inline-block;margin:0 5px 3px 0;padding:2px 7px;border-radius:999px;"
     +"font-size:8.5px;background:#F7EFE3;color:#6B4A32;border:1px solid #EADFCC;white-space:nowrap}"
   +".chip b{font-weight:700;letter-spacing:.5px}"
   +".chip.c4 b{color:#D08526}.chip.c3{background:#FBEDE9;border-color:#EBD3CB}.chip.c3 b{color:#B0392B}"
   +".chip.ok{background:#F1F6EC;border-color:#DCE7D4;color:#4A6B36}"
   +".dl{display:inline-block;margin:0 6px 3px 0;font-size:8px;letter-spacing:.12em;"
     +"text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +"p.note{margin:5px 0 0;font-size:8.5px;line-height:1.5;color:#6B4A32}"
   +".okmark{color:#7C9A6B;font-size:22px;line-height:1}"
   +"table{border-collapse:collapse;width:100%;font-size:9.5px}"
   +"thead{display:table-header-group}"
   +"th{background:#F2E7D6;color:#5A4029;text-align:left;padding:6px 5px;border:1px solid #E4D3BC;"
     +"font-size:8.5px;letter-spacing:.05em;text-transform:uppercase;line-height:1.25;vertical-align:bottom}"
   +"td{padding:6px 5px;border-left:1px solid #F0E6D6;border-right:1px solid #F0E6D6;vertical-align:middle}"
   +"tr.r{page-break-inside:avoid}"
   +"tr.r td{border-top:1px solid #E4D3BC}"
   +"tr.r.alt td{background:#FDFBF7}"
   +"td.st{text-align:center;white-space:nowrap;letter-spacing:.3px;font-size:10px}"
   +"td.st .s em{display:block;font-style:normal;font-size:8px;color:#9C8A74;letter-spacing:0;margin-top:1px}"
   +".sg{color:#E2D6C2}.nr{color:#D9CDBA}"
   +"td.room{font-weight:700;font-size:11px}"
   +"td.dt{white-space:nowrap;font-size:9px;color:#6B4A32}"
   +"tr.c{page-break-inside:avoid}"
   +"tr.c td{background:#FBF7F0;border-top:0;color:#4A3826;font-size:9px;line-height:1.5;padding:3px 8px 8px}"
   +"tr.c b{color:#B98A5C;font-weight:700;font-size:8.5px;letter-spacing:.12em;text-transform:uppercase}"
   +".foot{margin-top:18px;padding-top:9px;border-top:1px solid #EADFCC;font-size:9px;color:#9C8A74;display:flex;justify-content:space-between}"
   +".none{padding:34px;text-align:center;color:#9C8A74;font-size:13px;background:#FBF7F0;border-radius:10px}";

  let html='<div class=head>'
    +(hotel?'<div class=hotel>'+E2(hotel)+'</div>':'')
    +'<h1>'+E2(t("fbReport"))+'</h1>'
    +'<div class=cover>'+E2(cover)+'</div>'
    +'<div class=meta>'+E2(t("fbPrepared"))+" "+E2(new Date().toLocaleString())
      +(S.session&&S.session.name?" \u00b7 "+E2(S.session.name):"")+'</div>'
    +'</div>';

  html+='<div class=band>'
    + tile(t("fbCollected"), String(sum.count), sum.rated+" "+t("fbDeptsRated").toLowerCase())
    + tile(t("avgRate"), avg?stars(avg, avg.toFixed(1)):'<span class=nr>\u2014</span>')
    + '<div class="tile good"><span class=tl>'+E2(t("fbAllFiveN"))+'</span>'
      +'<b>'+sum.allFive+'</b><span class=ts>'+E2(t("fbAllFiveSub"))+'</span></div>'
    + '<div class="tile '+(sum.toReview?"attn":"")+'"><span class=tl>'+E2(t("fbToReview"))+'</span>'
      +'<b>'+sum.toReview+'</b><span class=ts>'+E2(t("fbToReviewSub"))+'</span></div>'
    +'</div>';

  /* The guests who raised something come first, worst first, each with exactly
     what they marked down. The guests who gave straight fives are listed after,
     one line each — they need no follow-up. */
  if(!list.length){
    html+='<div class=none>'+E2(t("fbNothing"))+'</div>';
  } else {
    const rank={priority:0, attn:1, none:2};
    const marked=f=>{
      const d=fbDepts(f);
      return fbDeptKeys().filter(k=>+d[k]>0 && +d[k]<5).sort((a,b)=>d[a]-d[b])
        .map(k=>'<span class="chip '+(d[k]<=3?"c3":"c4")+'">'+E2(fbDeptLabel(k))
          +' <b>'+"\u2605".repeat(+d[k])+'</b></span>').join("");
    };
    const meta=f=>[f.guest_name, f.nationality, teamName(f.by_user), shortStamp(f.created_at)]
      .filter(Boolean).map(E2).join(" \u00b7 ");
    const sorted=list.slice().sort((a,b)=>
      (rank[fbStatus(a)]-rank[fbStatus(b)]) || (fbOverall(a)-fbOverall(b)));
    const review=sorted.filter(f=>fbStatus(f)!=="none");
    const clean=sorted.filter(f=>fbStatus(f)==="none");

    html+='<h2 class=sub>'+E2(t("fbReviewHead"))+'</h2>'
      +'<p class=subnote>'+E2(review.length?t("fbReviewSub"):t("fbNoReview"))+'</p>';
    if(review.length){
      html+=review.map(f=>{
        const st=fbStatus(f), ov=fbOverall(f), note=fbComment(f), chips=marked(f);
        return '<div class="g '+st+'">'
          +'<div class=ghead>'
            +'<span class=gr>'+E2(f.room)+'</span>'
            +'<span class=gov>'+stars(ov, ov?ov.toFixed(1):"")+'</span>'
            +'<span class="gs '+st+'"><i></i>'+E2(fbStatusLabel(st))+'</span>'
          +'</div>'
          +'<div class=gmeta>'+meta(f)+'</div>'
          +(chips?'<div class=gchips>'+chips+'</div>':'')
          +(note?'<p class=note>'+E2(note)+'</p>':'')
          +'</div>';
      }).join("");
    }

    if(clean.length){
      html+='<h2 class=sub>'+E2(t("fbPerfectHead"))+'</h2>'
        +'<p class=subnote>'+E2(t("fbPerfectSub"))+'</p>'
        +'<div class=cleanbox>'
        + clean.map(f=>{
            const note=fbComment(f);
            return '<div class=g5>'
              +'<span class=gr>'+E2(f.room)+'</span>'
              +'<span class=gov>'+stars(fbOverall(f), fbOverall(f)?fbOverall(f).toFixed(1):"")+'</span>'
              +'<span class=tick>\u2713</span>'
              +'<span class=gmeta>'+meta(f)+'</span>'
              +(note?'<p class=note>'+E2(note)+'</p>':'')
              +'</div>';
          }).join("")
        +'</div>';
    }
    html+='<p class=legend>'+E2(t("fbLegend2"))+'</p>';
  }

  html+='<div class=foot><span>'+E2(hotel||t("fbReport"))+'</span>'
    +'<span>'+E2(cover)+' \u00b7 '+list.length+' '+E2(t("feedback"))+'</span></div>';

  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+E2(t("fbReport"))+"</title><meta charset=utf-8>"
    +"<style>"+css+"</style></head><body>"+html
    +"<scr"+"ipt>setTimeout(function(){window.print();},400);<\/scr"+"ipt></body></html>");
  w.document.close();
}
function openFeedbackExport(){
  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("fbExport")}</h3>
    <p class="mini">${t("fbFilterHead")}</p>
    <label>${t("whichMonth")}</label>
    <select id="fe-month">
      <option value="">${t("allMonths")}</option>
      ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===S.fbMonth?"selected":""}>${esc(lb)}</option>`).join("")}
    </select>
    <label style="margin-top:12px">${t("fbExactDate")}</label>
    <input type="date" id="fe-date" value="${esc(S.fbDate||"")}">
    <p class="mini" style="margin:4px 0 0">${t("fbExactHint")}</p>
    <label style="margin-top:12px">${t("whichTime")}</label>
    <select id="fe-slot">
      <option value="">${t("allDayLong")}</option>
      ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
    </select>
    <p class="mini" id="fe-note" style="margin-top:8px"></p>
    <button class="btn" id="fe-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="fe-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="fe-x">${t("close")}</button>`);
  const mSel=wrap.querySelector("#fe-month");
  const sSel=wrap.querySelector("#fe-slot"), xDate=wrap.querySelector("#fe-date");
  const note=wrap.querySelector("#fe-note");
  const apply=()=>{
    if(xDate) S.fbDate=xDate.value;
    if(mSel) S.fbMonth=mSel.value;
    if(sSel) S.exportSlot=sSel.value;
    // an exact date makes the month meaningless — grey it out
    if(mSel) mSel.disabled=!!S.fbDate;
    const n=exportFeedbackList().length;
    const bits=fbFilterBits();
    if(note) note.textContent = bits.length
      ? t("filterNote")+" "+bits.join(" \u00b7 ")+" \u2014 "+n+" "+t("feedback")
      : t("noFilterNote")+" "+n+" "+t("feedback");
  };
  [mSel,sSel,xDate].forEach(el=>{ if(el){ el.onchange=apply; el.oninput=apply; } });
  apply();
  wrap.querySelector("#fe-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fe-xlsx").onclick=async ()=>{
    apply();
    await exportExcelSets([buildDataset("feedback")].filter(Boolean),"guest-feedback-"+todayISO());
    toast(t("saved"));
  };
  wrap.querySelector("#fe-pdf").onclick=()=>{ apply(); exportFeedbackReport(); wrap.remove(); };
}
function openNotesModal(){
  const role=S.session?S.session.role:"guest";
  const list=visibleNotes(role);
  const wrap=baseModal(`
    <h3>${ic("bell",18)} ${t("notifications")}</h3>
    ${role==="manager"?`<button class="btn sm" id="n-new" style="margin-bottom:12px">＋ ${t("newAnnouncement")}</button>`:""}
    ${list.length?list.map(n=>`<div class="card" style="padding:12px 14px">
      <div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline">
        <b>${esc(n.title)}</b>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="mini">${fmtTime(n.created_at)}</span>
          ${role==="manager"?`<button class="btn sm warn" data-notedel="${n.id}">${ic("close",14)}</button>`:""}
        </span>
      </div>
      <p style="font-size:14.5px;margin-top:4px">${esc(n.body)}</p>
      ${role==="manager"?`<p class="mini" style="margin-top:4px">${n.audience==="all"?t("audAll"):n.audience==="guests"?t("audGuests"):t("audTeam")}</p>`:""}
    </div>`).join(""):`<div class="empty"><div class="big">${ic("bell",30)}</div>${t("noNotifs")}</div>`}
    <button class="btn ghost" id="n-x">${t("close")}</button>`);
  const maxId=list.reduce((m,n)=>Math.max(m,n.id),S.seenNote);
  if(maxId>S.seenNote){ S.seenNote=maxId; persist(); }
  wrap.querySelector("#n-x").onclick=()=>{ wrap.remove(); render(); };
  const nn=wrap.querySelector("#n-new");
  if(nn) nn.onclick=()=>{ wrap.remove(); openComposeNoteModal(); };
  wrap.querySelectorAll("[data-notedel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteNote(+b.dataset.notedel); wrap.remove(); openNotesModal();
  });
}
function openComposeNoteModal(){
  const wrap=baseModal(`
    <h3>＋ ${t("newAnnouncement")}</h3>
    <label>${t("actName")}</label><input id="nn-title">
    <label>${t("desc")}</label><textarea id="nn-body" rows="3"></textarea>
    <label>${t("audience")}</label>
    <select id="nn-aud">
      <option value="all">${t("audAll")}</option>
      <option value="guests">${t("audGuests")}</option>
      <option value="team">${t("audTeam")}</option>
    </select>
    <button class="btn" id="nn-go">${t("send")}</button>
    <button class="btn ghost" id="nn-x">${t("close")}</button>`);
  wrap.querySelector("#nn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#nn-go").onclick=async ()=>{
    const title=wrap.querySelector("#nn-title").value.trim();
    const body=wrap.querySelector("#nn-body").value.trim();
    if(!title&&!body) return;
    await DB.addNote({title:title||"★",body,audience:wrap.querySelector("#nn-aud").value});
    S.seenNote=S.notes.reduce((m,n)=>Math.max(m,n.id),S.seenNote); persist();
    wrap.remove(); toast(t("saved")); render();
  };
}
function openAttendanceModal(a){
  const date=todayISO();
  const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
  const wrap=baseModal(`
    <h3>${ic("check",18)} ${t("attendance")}</h3>
    <p class="mini">${esc(a.name)} · ${esc(a.time)}</p>
    ${bks.length?`<div class="card" style="margin-top:12px">${bks.map(b=>{
      const on=S.attendance.some(x=>x.booking_id===b.id&&x.date===date);
      return `<div class="booking-line">
        <span><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}</span>
        <button class="chip ${on?"ok":""}" data-attb="${b.id}">${t("present")}</button>
      </div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
    <button class="btn ghost" id="at-x">${t("close")}</button>`);
  wrap.querySelector("#at-x").onclick=()=>{ wrap.remove(); render(); };
  wrap.querySelectorAll("[data-attb]").forEach(b=>b.onclick=async ()=>{
    const id=+b.dataset.attb;
    const on=S.attendance.some(x=>x.booking_id===id&&x.date===date);
    await DB.setAttendance(id,date,!on);
    b.classList.toggle("ok",!on);
  });
}
function openTicketEditModal(tk){
  const isNew=!tk; tk=tk||{day:S.day,name:"",desc:"",location:"",time:"20:00",price:"",capacity:0,image:""};
  let ticketImage=String(tk.image||""),uploading=false;
  const wrap=baseModal(`
    <h3>${isNew?t("addTicket"):t("editTicket")}</h3>
    <label>${t("actName")}</label><input id="k-name" value="${esc(tk.name)}">
    <label>${t("desc")}</label><textarea id="k-desc" rows="2">${esc(tk.desc)}</textarea>
    <div class="row2"><div><label>${t("day")}</label><select id="k-day">${t("days").map((d,i)=>`<option value="${i}" ${tk.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
    <div><label>${t("time")}</label><input id="k-time" type="time" value="${esc(tk.time)}"></div></div>
    <div class="row2"><div><label>${t("price")}</label><input id="k-price" value="${esc(tk.price)}" placeholder="5 €"></div>
    <div><label>${t("capacity")} (0 = ∞)</label><input id="k-cap" type="number" min="0" value="${tk.capacity}"></div></div>
    <label>${t("location")}</label><input id="k-loc" value="${esc(tk.location)}">
    <label>${t("photo")}</label>
    <div class="photo-pick" id="k-photo-pick"><div class="photo-box" id="k-photo-box"></div><div class="pp-txt"><b>${t("photo")}</b><span class="mini">Tap to choose a photo from your phone</span></div><input type="file" id="k-photo-file" accept="image/*" hidden></div>
    <button class="btn ghost sm" id="k-photo-remove" style="${ticketImage?"":"display:none"}">Remove photo</button>
    <p class="mini" id="k-photo-status"></p>
    <button class="btn" id="k-save">${t("save")}</button>${isNew?"":`<button class="btn warn" id="k-del">${t("deleteActivity")}</button>`}<button class="btn ghost" id="k-x">${t("close")}</button>`);
  const box=wrap.querySelector("#k-photo-box"),file=wrap.querySelector("#k-photo-file"),rm=wrap.querySelector("#k-photo-remove"),status=wrap.querySelector("#k-photo-status"),save=wrap.querySelector("#k-save");
  const paint=()=>{box.innerHTML=ticketImage?`<img src="${esc(ticketImage)}" alt="">`:`<span>${ic("photo",26)}</span>`;rm.style.display=ticketImage?"":"none";};
  paint(); box.onclick=()=>file.click();
  file.onchange=async()=>{
    const f=file.files&&file.files[0]; if(!f)return;
    uploading=true;save.disabled=true;status.textContent="Uploading photo…";box.classList.add("uploading");
    try{ticketImage=await uploadAvatar(f);paint();status.textContent="Photo ready";}
    catch(e){console.error("ticket photo upload",e);status.textContent="Photo upload failed";toastErr(t("uploadErr"));}
    finally{uploading=false;save.disabled=false;box.classList.remove("uploading");file.value="";}
  };
  rm.onclick=()=>{ticketImage="";paint();status.textContent="Photo removed";};
  wrap.querySelector("#k-x").onclick=()=>wrap.remove();
  save.onclick=async()=>{
    if(uploading){toastWarn("Please wait for the photo upload.");return;}
    const upd={...tk,name:wrap.querySelector("#k-name").value.trim(),desc:wrap.querySelector("#k-desc").value.trim(),
      day:+wrap.querySelector("#k-day").value,time:wrap.querySelector("#k-time").value||"20:00",
      price:wrap.querySelector("#k-price").value.trim(),capacity:+wrap.querySelector("#k-cap").value||0,
      location:wrap.querySelector("#k-loc").value.trim(),image:ticketImage};
    if(!upd.name)return;
    save.disabled=true;
    try{await DB.saveTicket(upd);wrap.remove();toast(t("saved"));render();}
    catch(e){console.error("save ticket",e);save.disabled=false;toastErr(t("errSave"));}
  };
  const del=wrap.querySelector("#k-del");
  if(del)del.onclick=async()=>{await DB.deleteTicket(tk.id);wrap.remove();toast(t("deleted"));render();};
}

function splitTime(tm){
  const p=String(tm||"").split(/\s*[–—-]\s*/);
  return {start:(p[0]||"").trim(),end:(p[1]||"").trim()};
}
/* minutes-since-midnight from a "HH:MM" fragment, or -1 */
function hmToMin(x){ const m=String(x||"").match(/(\d{1,2})[:.\s](\d{2})/); return m?(+m[1])*60+(+m[2]):-1; }
/* start & end minutes for an activity (end defaults to start+45 if none) */
function actWindow(a){
  const {start,end}=splitTime(a.time);
  const s0=hmToMin(start); if(s0<0) return null;
  let e0=hmToMin(end); if(e0<0) e0=s0+45; if(e0<s0) e0+=1440;
  return {s0,e0};
}
/* status for TODAY only: 'todo' (green, not started), 'live' (yellow, running), 'done' (red, finished) */
function activityStatus(a, nowMin){
  const w=actWindow(a); if(!w) return "todo";
  const now=(typeof nowMin==="number")?nowMin:nowMinutes();
  if(now < w.s0) return "todo";
  if(now >= w.e0) return "done";
  return "live";
}
/* ===== HOTEL CLOCK =====
   With a timezone set, the app uses the HOTEL's local time everywhere, so a
   guest whose phone is on another timezone still sees the right day and gets
   alarms at the right moment. Without one, it falls back to the phone clock. */
const TIMEZONES=["","Africa/Cairo","Europe/Berlin","Europe/London","Europe/Moscow","Europe/Warsaw",
  "Europe/Prague","Europe/Amsterdam","Europe/Paris","Europe/Madrid","Europe/Rome","Europe/Istanbul",
  "Asia/Dubai","Asia/Riyadh","Atlantic/Canary","America/New_York"];
function hotelTz(){ try{ return (typeof S!=="undefined" && S.settings && S.settings.timezone) || ""; }catch(e){ return ""; } }
function hotelNow(){
  const tz=hotelTz();
  if(!tz) return new Date();
  try{ const d=new Date(new Date().toLocaleString("en-US",{timeZone:tz})); return isNaN(d.getTime())?new Date():d; }
  catch(e){ return new Date(); }
}
function nowMinutes(){ const d=hotelNow(); return d.getHours()*60+d.getMinutes(); }
function todayIndex(){ return (hotelNow().getDay()+6)%7; }
function hotelDateStr(){
  const d=hotelNow();
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}
/* only show status dots when looking at the actual current weekday */
function isToday(day){ return day===(todayIndex()); }
function statusDot(a){
  if(!isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-dot ${st}" title="${t("st_"+st)}"></span>`;
}
/* class that draws the coloured ring around a card / photo */
function statusRing(a){
  if(!a || !isToday(a.day)) return "";
  return "ring-"+activityStatus(a);
}
/* small coloured label used inside the ring */
function statusPill(a){
  if(!a || !isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-pill ${st}">${t("st_"+st)}</span>`;
}
function statusLegend(){
  if(!isToday(S.day)) return "";
  return `<div class="stat-legend">
    <span><i class="stat-dot todo"></i>${t("st_todo")}</span>
    <span><i class="stat-dot live"></i>${t("st_live")}</span>
    <span><i class="stat-dot done"></i>${t("st_done")}</span>
  </div>`;
}
function joinTime(a,b){ a=(a||"").trim(); b=(b||"").trim(); return b?`${a} – ${b}`:a; }
function openEditModal(a){
  const isNew=!a; a=a||{day:S.day,category:(S.cat&&allCats().includes(S.cat)?S.cat:"mAdult"),name:"",desc:"",location:"",time:"10:00",capacity:20,entertainer:"",image:"",highlight:false};
  const cur=normCat(a);
  const tm=splitTime(a.time);
  const catOptions=OPS.map(o=>`<optgroup label="${esc(opLabel(o.id))}">${o.cats.map(c=>`<option value="${c}" ${cur===c?"selected":""}>${catLabel(c)}</option>`).join("")}</optgroup>`).join("");
  const staff=S.users.filter(u=>u.role==="staff");
  const entOptions=`<option value="">${t("allTeam")}</option>`
    + staff.map(u=>`<option value="${esc(u.username)}" ${String(a.entertainer||"").toLowerCase()===u.username.toLowerCase()?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("");
  const knownEnt=!a.entertainer || staff.some(u=>u.username.toLowerCase()===String(a.entertainer).toLowerCase());
  const wrap=baseModal(`
    <h3>${isNew?t("addActivity"):t("editActivity")}</h3>
    <label>${t("actName")}</label><input id="e-name" value="${esc(a.name)}">
    <label>${t("desc")}</label><textarea id="e-desc" rows="2">${esc(a.desc)}</textarea>
    <div class="row2">
      <div><label>${t("day")}</label><select id="e-day">${t("days").map((d,i)=>`<option value="${i}" ${a.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
      <div><label>${t("category")}</label><select id="e-cat">${catOptions}</select></div>
    </div>
    <div class="row2">
      <div><label>${t("startTime")}</label><input id="e-start" type="time" value="${esc(tm.start)}"></div>
      <div><label>${t("endTime")}</label><input id="e-end" type="time" value="${esc(tm.end)}"></div>
    </div>
    <label>${t("capacity")} (0 = ∞)</label><input id="e-cap" type="number" min="0" value="${a.capacity}">
    <label>${t("location")}</label><input id="e-loc" value="${esc(a.location)}">
    <label>${t("entertainer")}</label>
    <select id="e-ent">${entOptions}${knownEnt?"":`<option value="${esc(a.entertainer)}" selected>${esc(a.entertainer)}</option>`}</select>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="e-img" type="hidden" value="${esc(a.image)}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink)">
      <input id="e-hl" type="checkbox" style="width:auto" ${a.highlight?"checked":""}> ${ic("sparkle",14)} ${t("makeHighlight")}</label>
    <button class="btn" id="e-save">${t("save")}</button>
    ${isNew?"":`<button class="btn warn" id="e-del">${t("deleteActivity")}</button>`}
    <button class="btn ghost" id="e-x">${t("close")}</button>`);
  wrap.querySelector("#e-x").onclick=()=>wrap.remove();
  let ePhoto=a.image||"";
  wirePhotoPicker(wrap, ()=>ePhoto, v=>{ ePhoto=v; wrap.querySelector("#e-img").value=v; });
  wrap.querySelector("#e-save").onclick=async ()=>{
    const upd={...a,
      name:wrap.querySelector("#e-name").value.trim(),
      desc:wrap.querySelector("#e-desc").value.trim(),
      day:+wrap.querySelector("#e-day").value,
      category:wrap.querySelector("#e-cat").value,
      time:joinTime(wrap.querySelector("#e-start").value||"10:00",wrap.querySelector("#e-end").value),
      capacity:+wrap.querySelector("#e-cap").value||0,
      location:wrap.querySelector("#e-loc").value.trim(),
      entertainer:wrap.querySelector("#e-ent").value.trim(),
      image:ePhoto,
      highlight:wrap.querySelector("#e-hl").checked};
    if(!upd.name) return;
    await DB.saveActivity(upd); wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#e-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delActivityQ"),danger:true})) return;
    try{ await DB.deleteActivity(a.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function openUserModal(){
  const wrap=baseModal(`
    <h3>${t("addUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="u-name" autocapitalize="none">
    <label>${t("pass")}</label><input id="u-pass">
    <label>${t("displayName")}</label><input id="u-disp">
    <label>${t("roleLabel")}</label>
    <select id="u-role"><option value="staff">${t("staff")}</option><option value="manager">${t("manager")}</option></select>
    <label>${t("shirtNumber")} (2–10)</label><input id="u-num" type="number" min="2" max="10" placeholder="e.g. 4">
    <label>${t("nationality")}</label>${nationField("u-nat","u-natx","")}
    <label>${t("genderLbl")}</label><select id="u-gen">${genderOptions("")}</select>
    <div class="pay630-editbox">
      <div class="pay630-edithead"><b>Salary</b><span>Monthly payroll</span></div>
      <div class="row2">
        <div><label>Monthly salary</label><input id="u-salary" type="number" min="0" step="0.01" inputmode="decimal" placeholder="10000"></div>
        <div><label>Currency</label><select id="u-currency"><option value="EGP">EGP</option><option value="USD">USD</option></select></div>
      </div>
      <label class="pay630-toggle"><input id="u-vacpaid" type="checkbox" checked> Paid vacation</label>
      <p class="mini">Present and Day Off are paid. Absence is deducted automatically.</p>
    </div>
    <button class="btn" id="u-save">${t("save")}</button>
    <div class="err" id="u-err"></div>
    <button class="btn ghost" id="u-x">${t("close")}</button>`);
  wrap.querySelector("#u-x").onclick=()=>wrap.remove();
  let uPhoto="";
  wirePhotoPicker(wrap, ()=>uPhoto, v=>{ uPhoto=v; });
  wireNatPicker(wrap,"u-nat","u-natx");
  wrap.querySelector("#u-save").onclick=async ()=>{
    const username=wrap.querySelector("#u-name").value.trim();
    const password=wrap.querySelector("#u-pass").value;
    const display_name=wrap.querySelector("#u-disp").value.trim();
    const role=wrap.querySelector("#u-role").value;
    const numRaw=wrap.querySelector("#u-num").value;
    const number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    const err=wrap.querySelector("#u-err");
    if(!username||!password){ err.textContent=t("loginErr"); return; }
    if(S.users.some(x=>x.username===username)){ err.textContent=t("userExists"); return; }
    await DB.addUser({username,password,role,display_name,number,photo:uPhoto,
      nationality:readNatField(wrap,"u-nat","u-natx"),
      gender:wrap.querySelector("#u-gen").value});
    const created=(S.users||[]).find(x=>String(x.username).toLowerCase()===String(username).toLowerCase());
    if(created){
      const amount=Math.max(0,+wrap.querySelector("#u-salary").value||0);
      const currency=wrap.querySelector("#u-currency").value==="USD"?"USD":"EGP";
      await savePayrollConfig630(created,{amount,currency,vacationPaid:!!wrap.querySelector("#u-vacpaid").checked});
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openMsgEditModal(m){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editMsg")}</h3>
    <label>${t("desc")}</label><textarea id="me-txt" rows="3">${esc(m.text)}</textarea>
    <button class="btn" id="me-go">${t("save")}</button>
    <button class="btn warn" id="me-del">${t("deleteMsg")}</button>
    <button class="btn ghost" id="me-x">${t("close")}</button>`);
  wrap.querySelector("#me-x").onclick=()=>wrap.remove();
  wrap.querySelector("#me-go").onclick=async ()=>{
    const v=wrap.querySelector("#me-txt").value.trim();
    if(!v) return;
    await DB.updateMessage(m.id,v); wrap.remove(); toast(t("saved")); render();
  };
  wrap.querySelector("#me-del").onclick=async ()=>{
    await DB.deleteMessage(m.id); wrap.remove(); toast(t("deleted")); render();
  };
}
function openChangePassModal(){
  const wrap=baseModal(`
    <h3>${ic("key",22)} ${t("changePass")}</h3>
    <label>${t("newPass")}</label><input id="cp-new" type="text" autocapitalize="none">
    <button class="btn" id="cp-go">${t("save")}</button>
    <div class="err" id="cp-err"></div>
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=async ()=>{
    const v=wrap.querySelector("#cp-new").value.trim();
    if(v.length<4){ wrap.querySelector("#cp-err").textContent=t("loginErr"); return; }
    await DB.updateAccount(S.session.accountId,{password:v});
    wrap.remove(); toast(t("saved"));
  };
}
function openUserEditModal(u){
  const managerCount=S.users.filter(x=>x.role==="manager").length;
  const lastManager=u.role==="manager"&&managerCount<=1;
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="ue-user" value="${esc(u.username)}" autocapitalize="none">
    <label>${t("displayName")}</label><input id="ue-disp" value="${esc(u.display_name||"")}">
    <label>${t("pass")}</label><input id="ue-pass" value="${esc(u.password||"")}">
    <label>${t("roleLabel")}</label>
    <select id="ue-role" ${lastManager?"disabled":""}>
      <option value="staff" ${u.role==="staff"?"selected":""}>${t("staff")}</option>
      <option value="manager" ${u.role==="manager"?"selected":""}>${t("manager")}</option>
    </select>
    <label>${t("shirtNumber")} (2–10)</label><input id="ue-num" type="number" min="2" max="10" value="${u.number||""}">
    <div class="row2">
      <div><label>${t("employeeId")}</label><input id="ue-eid" value="${esc(u.employee_id||"")}"></div>
      <div><label>${t("positionLbl2")}</label><input id="ue-pos" value="${esc(u.position||"")}"></div>
    </div>
    <div class="row2">
      <div><label>${t("phoneLbl2")}</label><input id="ue-phone" value="${esc(u.phone||"")}" inputmode="tel"></div>
      <div><label>${t("whatsappLbl2")}</label><input id="ue-wa" value="${esc(u.whatsapp||"")}" inputmode="tel"></div>
    </div>
    <label>${t("instagramLbl2")}</label><input id="ue-ig" value="${esc(u.instagram||"")}">
    <label>${t("languagesLbl")}</label><input id="ue-lang" value="${esc(u.languages||"")}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="ue-skills" value="${esc(u.skills||"")}">
    <label>${t("hireDate")}</label><input id="ue-hire" type="date" value="${esc(u.hire_date||"")}">
    ${photoListEditor("uep", (()=>{try{return Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]");}catch(e){return [];}})())}
    <label>${t("nationality")}</label>${nationField("ue-nat","ue-natx",u.nationality||"")}
    <label>${t("genderLbl")}</label><select id="ue-gen">${genderOptions(u.gender||"")}</select>
    ${payrollEditorHtml630(u)}
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ue-active" type="checkbox" style="width:auto" ${u.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ue-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ue-go">${t("save")}</button>
    <button class="btn ghost" id="ue-x">${t("close")}</button>`);
  wrap.querySelector("#ue-x").onclick=()=>wrap.remove();
  let uePhoto=u.photo||"";
  wirePhotoPicker(wrap, ()=>uePhoto, v=>{ uePhoto=v; });
  wireNatPicker(wrap,"ue-nat","ue-natx");
  let uePics=(()=>{try{return Array.isArray(u.photos)?u.photos.slice():JSON.parse(u.photos||"[]");}catch(e){return [];}})();
  wirePhotoList(wrap,"uep",()=>uePics,l=>{ uePics=l; });
  const ueReset=wrap.querySelector("#ue-reset");
  if(ueReset) ueReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateUser(u.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ue-go").onclick=async ()=>{
    const newUser=wrap.querySelector("#ue-user").value.trim();
    const patch={display_name:wrap.querySelector("#ue-disp").value.trim(),
      password:wrap.querySelector("#ue-pass").value, photo:uePhoto,
      nationality:readNatField(wrap,"ue-nat","ue-natx"),
      gender:wrap.querySelector("#ue-gen").value,
      active:wrap.querySelector("#ue-active").checked,
      employee_id:wrap.querySelector("#ue-eid").value.trim(),
      position:wrap.querySelector("#ue-pos").value.trim(),
      phone:wrap.querySelector("#ue-phone").value.trim(),
      whatsapp:wrap.querySelector("#ue-wa").value.trim(),
      instagram:wrap.querySelector("#ue-ig").value.trim(),
      languages:wrap.querySelector("#ue-lang").value.trim(),
      skills:wrap.querySelector("#ue-skills").value.trim(),
      hire_date:wrap.querySelector("#ue-hire").value,
      photos:uePics};
    const numRaw=wrap.querySelector("#ue-num").value;
    patch.number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    if(!lastManager) patch.role=wrap.querySelector("#ue-role").value;
    if(newUser && newUser!==u.username){
      if(S.users.some(x=>x.id!==u.id && String(x.username).toLowerCase()===newUser.toLowerCase())){ toast(t("userExists")); return; }
      patch.username=newUser;
    }
    if(!patch.password){ return; }
    await DB.updateUser(u.id,patch);
    await savePayrollConfig630(u,{
      amount:Math.max(0,+wrap.querySelector("#ue-salary").value||0),
      currency:wrap.querySelector("#ue-currency").value==="USD"?"USD":"EGP",
      vacationPaid:!!wrap.querySelector("#ue-vacpaid").checked
    });
    wrap.remove(); toast(t("saved")); render();
  };
}
function openGuestEditModal(acc){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("profile")} · ${t("room")} ${esc(acc.room)}</h3>
    <label>${t("name")}</label><input id="ge-name" value="${esc(acc.name||"")}">
    <label>${t("phone")}</label><input id="ge-phone" value="${esc(acc.phone||"")}">
    <label>${t("nationality")}</label>
    <input id="ge-nat" list="genatlist" value="${esc(acc.nationality||"")}">
    <datalist id="genatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <div class="row2">
      <div><label>${t("arrival")}</label><input id="ge-arr" type="date" value="${esc(acc.arrival||"")}"></div>
      <div><label>${t("departure")}</label><input id="ge-dep" type="date" value="${esc(acc.departure||"")}"></div>
    </div>
    <label>${t("pass")}</label><input id="ge-pass" value="${esc(acc.password||"")}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ge-active" type="checkbox" style="width:auto" ${acc.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ge-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ge-go">${t("save")}</button>
    <button class="btn ghost" id="ge-x">${t("close")}</button>`);
  wrap.querySelector("#ge-x").onclick=()=>wrap.remove();
  const geReset=wrap.querySelector("#ge-reset");
  if(geReset) geReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateAccount(acc.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ge-go").onclick=async ()=>{
    const name=wrap.querySelector("#ge-name").value.trim();
    if(!name) return;
    await DB.updateAccount(acc.id,{name,
      phone:wrap.querySelector("#ge-phone").value.trim(),
      nationality:wrap.querySelector("#ge-nat").value.trim(),
      arrival:wrap.querySelector("#ge-arr").value,
      departure:wrap.querySelector("#ge-dep").value,
      password:wrap.querySelector("#ge-pass").value.trim(),
      active:wrap.querySelector("#ge-active").checked});
    if(S.session && S.session.role==="guest" && S.session.accountId===acc.id){
      const a2=S.accounts.find(x=>x.id===acc.id); if(a2) startGuestSession(a2);
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openLangModal(){
  const wrap=baseModal(`
    <h3>${t("language")}</h3>
    <div class="langlist">
      ${LANGS.map(([l,label])=>`<button data-mlang="${l}" class="${S.lang===l?"on":""}">${label}</button>`).join("")}
    </div>
    <button class="btn ghost" id="l-x">${t("close")}</button>`);
  wrap.querySelector("#l-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-mlang]").forEach(b=>b.onclick=()=>{ wrap.remove(); setLang(b.dataset.mlang); });
}
/* ---------------- wiring ---------------- */
function wireCommon(){
  document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{S.tab=b.dataset.tab;S.chatRoom=null;S.op=null;S.cat=null;S.planDay=undefined;render();});
  document.querySelectorAll("[data-op]").forEach(b=>b.onclick=()=>{S.op=b.dataset.op;S.cat=null;render();});
  document.querySelectorAll("[data-planday]").forEach(b=>b.onclick=()=>{S.planDay=+b.dataset.planday;render();});
  document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{S.cat=b.dataset.cat;render();});
  const c1=$("#crumb-ops"); if(c1) c1.onclick=()=>{S.op=null;S.cat=null;render();};
  const c2=$("#crumb-cats"); if(c2) c2.onclick=()=>{S.cat=null;render();};
  document.querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>{S.day=+b.dataset.day;render();});
  document.querySelectorAll("[data-sub]").forEach(b=>b.onclick=()=>{
    const [g,v]=b.dataset.sub.split(":"); S.sub[g]=v; S.chatRoom=null; render();
  });
  const mn=$("#btn-menu"); if(mn) mn.onclick=openMenuDrawer;
  const nb=$("#btn-notes"); if(nb) nb.onclick=openNotesModal;
  document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const id=+b.dataset.fav;
    S.favorites=S.favorites.includes(id)?S.favorites.filter(x=>x!==id):[...S.favorites,id]; persist(); render();
  });
  document.querySelectorAll("[data-book]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.book); if(a) openBookModal(a);
  });
  document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.buy); if(tk) openTicketBuyModal(tk);
  });
  document.querySelectorAll("[data-cancel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await DB.removeBooking(+b.dataset.cancel); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-cancelorder]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await DB.deleteOrder(+b.dataset.cancelorder); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-delreq]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRequest(+b.dataset.delreq); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.edit); openEditModal(a);
  });
  document.querySelectorAll("[data-att]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.att); if(a) openAttendanceModal(a);
  });
  document.querySelectorAll("[data-tedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.tedit); openTicketEditModal(tk);
  });
  document.querySelectorAll("[data-tpaid]").forEach(b=>b.onclick=async ()=>{
    const o=S.orders.find(x=>x.id===+b.dataset.tpaid); if(!o) return;
    await DB.setOrderStatus(o.id, o.status==="paid"?"reserved":"paid"); render();
  });
  document.querySelectorAll("[data-tdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deleteOrder(+b.dataset.tdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-deluser]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delUserQ"),danger:true})) return;
    try{ await DB.deleteUser(+b.dataset.deluser); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-reqdone]").forEach(b=>b.onclick=async ()=>{
    const r=S.requests.find(x=>x.id===+b.dataset.reqdone); if(!r) return;
    await DB.setRequestStatus(r.id, r.status==="done"?"new":"done"); render();
  });
  document.querySelectorAll("[data-reqdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delReqQ"),danger:true})) return;
    try{ await DB.deleteRequest(+b.dataset.reqdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskdone]").forEach(b=>b.onclick=async ()=>{
    const x=S.tasks.find(y=>y.id===+b.dataset.taskdone); if(!x) return;
    await DB.updateTask(x.id,{status:x.status==="done"?"open":"done"}); render();
  });
  document.querySelectorAll("[data-taccept]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.taccept,{status:"accepted"}); render();
  });
  document.querySelectorAll("[data-tsdone]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tsdone,{status:"done"}); toast(t("saved")); render();
  });
  document.querySelectorAll("[data-tstill]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tstill,{status:"still",was_still:true}); render();
  });
  document.querySelectorAll("[data-tcant]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tcant,{status:"cant"}); render();
  });
  document.querySelectorAll("[data-fbopen]").forEach(b=>b.onclick=()=>openFeedbackDetail(b.dataset.fbopen));
  document.querySelectorAll("[data-fbdept]").forEach(b=>b.onclick=()=>openDeptDetail(b.dataset.fbdept));
  const fbx=$("#btn-fbexport"); if(fbx) fbx.onclick=openFeedbackExport;
  const fbd=$("#btn-fbdepts"); if(fbd) fbd.onclick=openDeptEditor;
  const rail=$("#hero-rail"), dots=$("#hero-dots");
  if(rail && dots){
    const marks=dots.querySelectorAll("i");
    const sync=()=>{
      const w=rail.scrollWidth/Math.max(1,marks.length);
      const i=Math.min(marks.length-1, Math.round(rail.scrollLeft/Math.max(1,w)));
      marks.forEach((m,j)=>m.classList.toggle("on", j===i));
    };
    rail.onscroll=sync;
    marks.forEach((m,j)=>m.onclick=()=>{
      rail.scrollTo({left:(rail.scrollWidth/marks.length)*j, behavior:"smooth"});
    });
  }
  /* One tap on an activity does whatever that person can actually do with it:
     the manager edits it, an entertainer opens the guest list, a guest books. */
  const openAct=id=>{
    const a=S.activities.find(x=>String(x.id)===String(id));
    if(!a || !S.session) return;
    if(S.session.role==="manager") return openEditModal(a);
    if(S.session.role==="staff") return canSeeGuests(a) ? openAttendanceModal(a) : openEditModal(a);
    if(!myBooking(a.id)) openBookModal(a);
  };
  document.querySelectorAll("[data-actopen]").forEach(el=>el.onclick=()=>openAct(el.dataset.actopen));
  document.querySelectorAll("[data-startact]").forEach(b=>b.onclick=ev=>{
    if(ev && ev.stopPropagation) ev.stopPropagation();
    openAct(b.dataset.startact);
  });
  const tnMake=$("#tn-make");
  if(tnMake) tnMake.onclick=()=>{ S.tab="req"; render(); setTimeout(()=>openReqEditor(),0); };
  const rqN=$("#rq-new");    if(rqN) rqN.onclick=()=>openReqEditor();
  const rqP=$("#rq-pack");   if(rqP) rqP.onclick=openReqPack;
  const rqD=$("#rq-depts");  if(rqD) rqD.onclick=openReqDeptEditor;
  const rqT=$("#rq-tpl");    if(rqT) rqT.onclick=openReqTemplateEditor;
  const rqDate=$("#rq-date");
  if(rqDate) rqDate.onchange=()=>{ S.reqDate=rqDate.value; render(); };
  document.querySelectorAll("[data-rqopen]").forEach(b=>b.onclick=()=>openReqEditor(b.dataset.rqopen));
  const fbs=$("#btn-fbseeall"); if(fbs) fbs.onclick=()=>{ S.tab="feedback"; render(); };
  const fb=$("#btn-addfb"); if(fb) fb.onclick=()=>openFeedbackModal();
  const cp=$("#btn-chpass"); if(cp) cp.onclick=openChangePassModal;
  const ap=$("#btn-addprofile"); if(ap) ap.onclick=()=>openProfileModal(null);
  document.querySelectorAll("[data-pedit]").forEach(b=>b.onclick=()=>{
    const pr=S.profiles.find(x=>x.id===+b.dataset.pedit); if(pr) openProfileModal(pr);
  });
  document.querySelectorAll("[data-pdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteProfile(+b.dataset.pdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-uedit]").forEach(b=>b.onclick=()=>{
    const u=S.users.find(x=>x.id===+b.dataset.uedit); if(u) openUserEditModal(u);
  });
  document.querySelectorAll("[data-gedit]").forEach(b=>b.onclick=()=>{
    const a=S.accounts.find(x=>x.id===+b.dataset.gedit); if(a) openGuestEditModal(a);
  });
  const ex=$("#btn-export"); if(ex) ex.onclick=exportReport;
  const exd=$("#btn-exportdata"); if(exd) exd.onclick=openExportModal;
  document.querySelectorAll("[data-busedit]").forEach(el=>el.onclick=()=>{
    const b=S.buses.find(x=>x.id==el.dataset.busedit); if(b) openBusModal(b);
  });
  document.querySelectorAll("[data-busadd]").forEach(el=>el.onclick=()=>openBusModal(null, el.dataset.busadd));
  document.querySelectorAll("[data-hub]").forEach(el=>el.onclick=()=>{
    const h=el.dataset.hub;
    if(h==="export"){ openExportModal(); return; }
    S.tab=h; render();
  });
  const crumbHub=$("#crumb-hub"); if(crumbHub) crumbHub.onclick=()=>{ S.tab="settings"; render(); };
  const crumbPb=$("#crumb-pb"); if(crumbPb) crumbPb.onclick=()=>{ S.tab="builder"; render(); };
  document.querySelectorAll("[data-pbedit]").forEach(b=>b.onclick=()=>pbOpen(S.session.role, b.dataset.pbedit));
  document.querySelectorAll("[data-pbadd]").forEach(b=>b.onclick=()=>pbAdd(b.dataset.pbadd));
  document.querySelectorAll("[data-pbup]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbup,-1));
  document.querySelectorAll("[data-pbdown]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbdown,1));
  document.querySelectorAll("[data-pbdup]").forEach(b=>b.onclick=()=>pbDup(b.dataset.pbdup));
  document.querySelectorAll("[data-pbdel]").forEach(b=>b.onclick=()=>pbDel(b.dataset.pbdel));
  // live editing of block fields
  document.querySelectorAll("[data-pbf]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbf).split("|");
    const apply=()=>{
      const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.value; render();
    };
    if(el.tagName==="SELECT"||el.type==="color") el.onchange=apply; else el.onblur=apply;
  });
  document.querySelectorAll("[data-pbc]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbc).split("|");
    el.onchange=()=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.checked; render(); };
  });
  const pbT=$("#pb-title"); if(pbT) pbT.onblur=()=>{ const st=pbState(); if(st.page) st.page.title=pbT.value; };
  const pbR=$("#pb-role"); if(pbR) pbR.onchange=()=>{ pbState().role=pbR.value; };
  const pbS=$("#pb-save"); if(pbS) pbS.onclick=()=>{ const t2=$("#pb-title"); if(t2&&pbState().page) pbState().page.title=t2.value; pbSave(); };
  // block images
  document.querySelectorAll("[data-pbimgadd]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgadd).split("|");
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk[key]=url; render(); } });
  });
  document.querySelectorAll("[data-pbimgrm]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk[key]=""; render(); }
  });
  document.querySelectorAll("[data-pbgadd]").forEach(b=>b.onclick=()=>{
    const bid=b.dataset.pbgadd;
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk.urls=(blk.urls||[]).concat([url]); render(); } }, true);
  });
  document.querySelectorAll("[data-pbgrm]").forEach(b=>b.onclick=()=>{
    const [bid,ix]=String(b.dataset.pbgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk.urls=(blk.urls||[]).filter((_,i)=>i!==+ix); render(); }
  });
  document.querySelectorAll("[data-translate]").forEach(b=>b.onclick=()=>translateMessage(b.dataset.translate));
  const navB=$("#btn-navback"); if(navB) navB.onclick=navBack;
  const navF=$("#btn-navfwd");  if(navF) navF.onclick=navForward;
  const qzSend=$("#qz-send"); if(qzSend) qzSend.onclick=submitQuizAnswer;
  document.querySelectorAll("[data-dutyedit]").forEach(b=>b.onclick=()=>openDutyModal(+b.dataset.dutyedit));
  const qrP=$("#qr-print"); if(qrP) qrP.onclick=openQrPrint;
  document.querySelectorAll("[data-gotab]").forEach(b=>b.onclick=()=>{ S.tab=b.dataset.gotab; render(); });
  const crmQ=$("#crm-q"); if(crmQ && !crmQ.dataset.searchFixedV6242){
    crmQ.dataset.searchFixedV6242="1";
    const filterCrm=()=>{
      S.crmQuery=crmQ.value;
      const q=crmQ.value.trim().toLowerCase();
      const rows=[...document.querySelectorAll("[data-crm-search]")];
      let shown=0;
      rows.forEach(row=>{
        const ok=!q||String(row.dataset.crmSearch||"").includes(q);
        row.style.display=ok?"":"none";
        if(ok)shown++;
      });
      const empty=document.querySelector("#crm-search-empty");
      if(empty)empty.style.display=(rows.length&&shown===0)?"":"none";
    };
    crmQ.oninput=filterCrm;
    crmQ.onkeydown=e=>{ if(e.key==="Enter"){ e.preventDefault(); filterCrm(); crmQ.blur(); } };
    crmQ.onsearch=()=>{ filterCrm(); crmQ.blur(); };
    filterCrm();
  }
  document.querySelectorAll("[data-crm]").forEach(b=>b.onclick=()=>{ S.tab="g360:"+b.dataset.crm; render(); });
  const crumbCrm=$("#crumb-crm"); if(crumbCrm) crumbCrm.onclick=()=>{ S.tab="guests"; S.sub.guests="crm"; render(); };
  document.querySelectorAll("[data-uview]").forEach(b=>b.onclick=()=>{ S.tab="emp:"+b.dataset.uview; render(); });
  const profReq=$("#prof-req"); if(profReq) profReq.onclick=openProfileChangeModal;
  // any picture with data-pv opens the big viewer
  /* photo taps are handled globally by initPhotoTaps() */
  const crumbTeam=$("#crumb-team"); if(crumbTeam) crumbTeam.onclick=()=>{
    if(S.session.role==="manager"){ S.tab="team"; S.sub.team="accounts"; }
    else S.tab="teaminfo";
    render();
  };
  document.querySelectorAll("[data-ususpend]").forEach(b=>b.onclick=async ()=>{
    const u=S.users.find(x=>x.id==b.dataset.ususpend); if(!u) return;
    try{ await DB.updateUser(u.id,{active:u.active===false}); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskopen]").forEach(b=>b.onclick=()=>openTaskModal(b.dataset.taskopen));
  const wRe=$("#w-reload"); if(wRe) wRe.onclick=()=>loadWeather(true);
  document.querySelectorAll("[data-asub]").forEach(b=>b.onclick=()=>{ S.sub.assign=b.dataset.asub; render(); });
  document.querySelectorAll("[data-aday]").forEach(b=>b.onclick=()=>{ S.assignDay=+b.dataset.aday; render(); });
  const aAuto=$("#asg-auto"); if(aAuto) aAuto.onclick=()=>openAutoAssignModal(assignDay());
  document.querySelectorAll("[data-arrange]").forEach(b=>b.onclick=()=>openArrangeModal(b.dataset.arrange));
  const ctSel=$("#ct-select"); if(ctSel) ctSel.onclick=()=>{ S.chatSel=[]; render(); };
  const ctCancel=$("#ct-cancel"); if(ctCancel) ctCancel.onclick=()=>{ S.chatSel=null; render(); };
  const ctAll=$("#ct-all"); if(ctAll) ctAll.onclick=()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    S.chatSel = (S.chatSel||[]).length===ids.length ? [] : ids;
    render();
  };
  document.querySelectorAll("[data-msgpick]").forEach(el=>el.onclick=()=>{
    const id=+el.dataset.msgpick;
    const cur=S.chatSel||[];
    S.chatSel = cur.includes(id) ? cur.filter(x=>x!==id) : cur.concat([id]);
    render();
  });
  const ctDel=$("#ct-del"); if(ctDel) ctDel.onclick=async ()=>{
    const ids=(S.chatSel||[]).slice();
    if(!ids.length) return;
    if(!(await confirmAction({title:t("deleteMsgsQ").replace("{n}",ids.length), body:t("cannotUndo"), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  const ctClear=$("#ct-clear"); if(ctClear) ctClear.onclick=async ()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    if(!ids.length) return;
    if(!(await confirmAction({title:t("clearChatQ"), body:t("clearChatHint").replace("{n}",ids.length), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-sreqdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    if(!(await confirmAction({title:t("deleteReqQ"), body:t("cannotUndo"), danger:true}))) return;
    await DB.deleteStaffReq(+b.dataset.sreqdel); toastOk(t("saved")); render();
  });
  const avBtn=$("#att-vac"); if(avBtn) avBtn.onclick=()=>openVacationModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  const aoBtn=$("#att-only"); if(aoBtn) aoBtn.onclick=()=>openAttPersonModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  document.querySelectorAll("[data-dgopen]").forEach(b=>b.onclick=()=>{
    const [kind,key]=String(b.dataset.dgopen).split("|");
    S.openDay={...(S.openDay||{})};
    S.openDay[kind] = (S.openDay[kind]===key) ? null : key;   // tap again to close
    render();
  });
  const aEnt=$("#asg-ent"); if(aEnt) aEnt.onclick=()=>openEntranceModal(assignDay());
  document.querySelectorAll("[data-aopen]").forEach(el=>el.onclick=()=>{
    openEditModal(el.dataset.aopen);
  });
  document.querySelectorAll("[data-userleave]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openLeaveModal(+b.dataset.userleave);
  });
  document.querySelectorAll("[data-bkedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openBookingEditor(+b.dataset.bkedit);
  });
  document.querySelectorAll("[data-bkguest]").forEach(b=>b.onclick=()=>{
    S.tab="g360:"+b.dataset.bkguest; render();
  });
  document.querySelectorAll("[data-bkdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    const id=+b.dataset.bkdel;
    const bk=S.bookings.find(x=>x.id===id); if(!bk) return;
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(id); toastOk(t("saved")); render();
  });
  document.querySelectorAll("[data-aemp]").forEach(el=>el.onclick=()=>openSkillEditor(el.dataset.aemp));
  if(S.tab==="weather" && !S.weather) loadWeather(false);
  document.querySelectorAll("[data-bdrole]").forEach(b=>b.onclick=()=>{ S.sub.builder=b.dataset.bdrole; render(); });
  const bdStart=$("#bd-start");
  if(bdStart) bdStart.onchange=async ()=>{
    const role=builderRole(), m={...(S.settings.menu||{})};
    m[role]={...(m[role]||{}), start:bdStart.value};
    await DB.saveSettings({...S.settings, menu:m});
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-bdup]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bdup,-1));
  document.querySelectorAll("[data-bddown]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bddown,1));
  document.querySelectorAll("[data-bdname]").forEach(b=>b.onclick=()=>openRenameModal(b.dataset.bdname));
  document.querySelectorAll("[data-bdhide]").forEach(b=>b.onclick=()=>toggleMenuItem(b.dataset.bdhide));
  document.querySelectorAll("[data-bdgname]").forEach(b=>b.onclick=()=>openGroupRenameModal(b.dataset.bdgname));
  document.querySelectorAll("[data-bdedit]").forEach(b=>b.onclick=()=>pbOpen(builderRole(), b.dataset.bdedit));
  document.querySelectorAll("[data-bddel]").forEach(b=>b.onclick=()=>openCustomPageModal(b.dataset.bddel));
  const bdAdd=$("#bd-add"); if(bdAdd) bdAdd.onclick=()=>pbOpen(builderRole(), null);
  const bdReset=$("#bd-reset"); if(bdReset) bdReset.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle")})) return;
    saveMenuConf(builderRole(),{order:[],hidden:[],names:{},custom:[]});
  };
  if($("#s-logo")){
    const fileIn=document.querySelector("[data-photoinput]");
    const box=document.querySelector("[data-photobox]");
    const paint=()=>{ if(!box) return; const u=$("#s-logo").value;
      box.innerHTML = u ? `<img src="${esc(u)}" alt="">` : `<span>${ic("user",26)}</span>`; };
    paint();
    if(box) box.onclick=()=>fileIn&&fileIn.click();
    if(fileIn) fileIn.onchange=()=>{
      const f=fileIn.files&&fileIn.files[0]; if(!f) return;
      openCropModal(f, url=>{ const el=$("#s-logo"); if(el) el.value=url; paint(); toastOk(t("saved")); });
      fileIn.value="";
    };
    const rmL=$("#s-logo-rm");
    if(rmL) rmL.onclick=()=>{ const el=$("#s-logo"); if(el) el.value=""; paint(); };
  }
  const infoAdd=$("#info-add"); if(infoAdd) infoAdd.onclick=()=>openInfoModal();
  document.querySelectorAll("[data-infoedit]").forEach(b=>b.onclick=()=>openInfoModal(+b.dataset.infoedit));
  const phAdd=$("#ph-add"); if(phAdd) phAdd.onclick=openPhotoModal;
  document.querySelectorAll("[data-phdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deletePhoto(+b.dataset.phdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const srNew=$("#sr-new"); if(srNew) srNew.onclick=openStaffReqModal;
  document.querySelectorAll("[data-reqok]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqok,"ok"));
  document.querySelectorAll("[data-reqno]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqno,"no"));
  document.querySelectorAll("[data-guestrate]").forEach(b=>b.onclick=async ()=>{
    const rate=+b.dataset.guestrate;
    try{
      await DB.addFeedback({room:String(S.session.room||""), nationality:S.session.nationality||"",
        rate, comment:"", by_user:""});
      toastOk(t("thankYou"));
      render();
      // happy guests are invited to post publicly; unhappy ones stay private with the manager
      setTimeout(()=>openReviewInvite(rate), 350);
    }catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-attn]").forEach(b=>b.onclick=()=>{
    const [tab,sub]=b.dataset.attn.split("|");
    S.tab=tab; if(sub) S.sub[tab]=sub; render();
  });
  document.querySelectorAll("[data-satt]").forEach(b=>b.onclick=async ()=>{
    const [un,mk,d]=b.dataset.satt.split("|");
    const u=S.users.find(x=>x.username===un); if(!u) return;
    const next=attNext(u,mk,+d);
    if(next===undefined) return;                 // future day — nothing to mark
    try{ await DB.setStaffAtt(un, dateStr(mk,+d), next); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const attP=$("#att-prev"); if(attP) attP.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),-1); render(); };
  const attN=$("#att-next"); if(attN) attN.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),1); render(); };
  const attX=$("#att-export"); if(attX) attX.onclick=()=>openExportModal("monthatt");
  document.querySelectorAll("[data-quiznew]").forEach(b=>b.onclick=()=>openQuizModal(null,b.dataset.quiznew));
  document.querySelectorAll("[data-quizedit]").forEach(b=>b.onclick=()=>{
    const q=S.quizzes.find(x=>x.id==b.dataset.quizedit); if(q) openQuizModal(q);
  });
  document.querySelectorAll("[data-quizdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deleteQuiz(+b.dataset.quizdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-palette]").forEach(b=>b.onclick=()=>openThemePreview(b.dataset.palette));
  const nt=$("#notif-toggle"); if(nt) nt.onclick=()=>{
    const turningOn=!notifSoundOn();
    localStorage.setItem("ent_notif",turningOn?"on":"off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    render();
  };
  const aks=$("#ai-savekey"); if(aks) aks.onclick=()=>{
    const v=$("#ai-key").value.trim(); if(!v) return;
    localStorage.setItem("ent_ai_key",v); toast(t("saved")); render();
  };
  const ais=$("#ai-send");
  if(ais){
    const go=()=>{ const inp=$("#ai-in"); const v=inp.value.trim(); if(!v||S.aiBusy) return; inp.value=""; askAI(v); };
    ais.onclick=go;
    $("#ai-in").onkeydown=e=>{ if(e.key==="Enter") go(); };
  }
  document.querySelectorAll("[data-taskdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteTask(+b.dataset.taskdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-roomact]").forEach(b=>b.onclick=async ()=>{
    const r=S.rooms.find(x=>x.id==b.dataset.roomact); if(!r) return;
    await DB.setRoomActive(r.id,!r.active); render();
  });
  document.querySelectorAll("[data-roomdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRoom(+b.dataset.roomdel||b.dataset.roomdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-chatroom]").forEach(el=>el.onclick=()=>{
    S.chatRoom=el.dataset.chatroom; render();
  });
  document.querySelectorAll("[data-staffchat]").forEach(el=>el.onclick=()=>{
    S.chatRoom="staff:"+el.dataset.staffchat; render();
  });
  document.querySelectorAll("[data-msgedit]").forEach(b=>b.onclick=()=>{
    const m=S.messages.find(x=>x.id==b.dataset.msgedit); if(m) openMsgEditModal(m);
  });
  document.querySelectorAll("[data-msgdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteMessage(+b.dataset.msgdel||b.dataset.msgdel); toast(t("deleted")); render();
  });
  S.chatSel = S.chatRoom ? S.chatSel : null;
  const cb=$("#btn-chatback"); if(cb) cb.onclick=()=>{S.chatRoom=null;render();};
  const add=$("#btn-add"); if(add) add.onclick=()=>openEditModal(null);
  const addT=$("#btn-addticket"); if(addT) addT.onclick=()=>openTicketEditModal(null);
  const addU=$("#btn-adduser"); if(addU) addU.onclick=openUserModal;
  const addTk=$("#btn-addtask"); if(addTk) addTk.onclick=openTaskAddModal;
  const rs=$("#btn-req-song"); if(rs) rs.onclick=()=>openRequestModal("song");
  const rb=$("#btn-req-bday"); if(rb) rb.onclick=()=>openRequestModal("birthday");
  const ar=$("#btn-addrooms"); if(ar) ar.onclick=async ()=>{
    const raw=$("#rooms-in").value;
    const list=[...new Set(raw.split(/[\n,;]+/).map(x=>x.trim()).filter(Boolean))];
    if(!list.length) return;
    await DB.addRooms(list); toast(t("saved")); render();
  };
  const rf=$("#rooms-filter"); if(rf) rf.oninput=()=>{
    const q=rf.value.trim().toLowerCase();
    document.querySelectorAll(".roomline").forEach(el=>{
      el.style.display = !q || el.dataset.room.toLowerCase().includes(q) || el.textContent.toLowerCase().includes(q) ? "" : "none";
    });
  };
  const sv=$("#btn-savesettings"); if(sv) sv.onclick=async ()=>{
    // Each settings page shows only some fields — save exactly what is on screen,
    // and leave everything else untouched.
    const v=(id,fb)=>{ const el=$(id); return el?el.value:fb; };
    const has=id=>!!$(id);
    const st={...S.settings};
    if(has("#s-name"))    st.name=v("#s-name","").trim()||"Entertainment";
    if(has("#s-sub"))     st.subtitle=v("#s-sub","").trim();
    if(has("#s-welcome")) st.welcomeMsg=v("#s-welcome","").trim();
    if(has("#s-primary")){ st.primary=v("#s-primary",st.primary); st.accent=v("#s-accent",st.accent);
      st.bg=v("#s-bg",st.bg); st.textColor=v("#s-text",st.textColor);
      st.navBg=v("#s-navbg",st.navBg); st.navActive=v("#s-navon",st.navActive); }
    if(has("#s-font"))    st.fontStyle=v("#s-font",st.fontStyle);
    if(has("#s-btn"))     st.buttonStyle=v("#s-btn",st.buttonStyle);
    if(has("#s-mhome")){ st.menuHome=v("#s-mhome","").trim(); st.menuProgram=v("#s-mprog","").trim();
      st.menuTickets=v("#s-mtick","").trim(); st.menuChat=v("#s-mchat","").trim(); st.menuStay=v("#s-mstay","").trim(); }
    if(has("#s-trip")){ st.tripadvisor=v("#s-trip","").trim(); st.google=v("#s-goog","").trim();
      st.holidaycheck=v("#s-holi","").trim(); }
    if(has("#s-insta")){ st.instagram=v("#s-insta","").trim(); st.tiktok=v("#s-tiktok","").trim();
      st.facebook=v("#s-fb","").trim(); st.youtube=v("#s-yt","").trim(); st.whatsapp=v("#s-wa","").trim(); }
    if(has("#s-fs"))       st.fontScale=v("#s-fs",st.fontScale);
    if(has("#s-autodark")) st.autoDark=$("#s-autodark").checked;
    if(has("#s-logo"))     st.logo=v("#s-logo","").trim();
    if(has("#s-hotel"))    st.hotelName=v("#s-hotel","").trim();
    if(has("#s-contact"))  st.contact=v("#s-contact","").trim();
    if(has("#s-cur"))      st.currency=v("#s-cur","").trim();
    if(has("#s-tz"))       st.timezone=v("#s-tz",st.timezone);
    if(has("#s-lat")){ st.lat=v("#s-lat","").trim(); st.lon=v("#s-lon","").trim(); }
    const featBoxes=document.querySelectorAll(".feat-cb");
    if(featBoxes.length){ const f={}; ["quiz","tickets","gallery","bus","hotelinfo","weather"].forEach(k=>f[k]=false);
      featBoxes.forEach(cb=>{ if(cb.checked) f[cb.value]=true; }); st.features=f; }
    if(has("#s-aiep"))   st.aiEndpoint=v("#s-aiep","").trim();
    if(has("#s-pushep")) st.pushEndpoint=v("#s-pushep","").trim();
    // only accept secure https endpoints
    for(const f of ["aiEndpoint","pushEndpoint"]){
      if(st[f] && !/^https:\/\//i.test(st[f])){ toastErr(t("errHttps")); return; }
    }
    const coordsChanged = st.lat!==S.settings.lat || st.lon!==S.settings.lon || st.timezone!==S.settings.timezone;
    await DB.saveSettings(st); applySettings();
    if(coordsChanged) loadWeather(true);
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-open]").forEach(el=>el.onclick=()=>{
    if(!S.session || S.session.role!=="guest") return;
    const a=S.activities.find(x=>x.id===+el.dataset.open);
    if(a) openGuestActivityDetail(a);
  });
  /* chat send + read marking + scroll */
  const cs=$("#chat-send");
  if(cs){
    const g=S.session;
    let room, meSide, readSide;
    if(g.role==="guest"){ room=g.room; meSide="guest"; readSide="guest"; }
    else if(g.role==="staff"){ room="staff:"+g.username; meSide="guest"; readSide="guest"; }
    else { room=S.chatRoom; meSide="team"; readSide="team"; }
    if(room){
      const flag = readSide==="team"?"read_by_team":"read_by_guest";
      const sender = readSide==="team"?"guest":"team";
      if(S.messages.some(m=>m.room===room&&m.sender===sender&&!m[flag])){
        DB.markRead(room,readSide).then(()=>render());
      }
      window.scrollTo(0,document.body.scrollHeight);
      const doSend=async ()=>{
        const inp=$("#chat-in"); const txt=inp.value.trim(); if(!txt) return;
        inp.value="";
        await DB.addMessage({room,sender:meSide,sender_name:g.name,text:txt,
          read_by_team:meSide==="team",read_by_guest:meSide==="guest"});
        render();
      };
      cs.onclick=doSend;
      $("#chat-in").onkeydown=e=>{ if(e.key==="Enter") doSend(); };
    }
  }
}

/* ---------------- boot ---------------- */
function safeToRender(){
  if(document.querySelector(".modal-bg")) return false;
  const a=document.activeElement;
  return !(a && ["INPUT","TEXTAREA","SELECT"].includes(a.tagName));
}
/* ============ NOTIFICATIONS (sound + vibrate + banner) ============ */
let AUDIO_CTX=null;
function notifSoundOn(){ return localStorage.getItem("ent_notif")!=="off"; }
function playChime(){
  if(!notifSoundOn()) return;
  try{
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    const ctx=AUDIO_CTX; if(ctx.state==="suspended") ctx.resume();
    const now=ctx.currentTime;
    // two-note soft "ding-dong" using sine tones
    [[880,0],[1174,0.14]].forEach(([f,dt])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.type="sine"; o.frequency.value=f;
      o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0,now+dt);
      g.gain.linearRampToValueAtTime(0.35,now+dt+0.02);
      g.gain.exponentialRampToValueAtTime(0.001,now+dt+0.42);
      o.start(now+dt); o.stop(now+dt+0.45);
    });
  }catch(e){}
}
function vibrate(){ if(notifSoundOn() && navigator.vibrate){ try{ navigator.vibrate([120,60,120]); }catch(e){} } }
let SW_REG=null;
let SW_READY=false;
/* Registers the REAL static service worker file (sw.js) that sits next to index.html.
   Relative path keeps the scope correct on GitHub Pages sub-paths. */
/* ===================== SERVICE WORKER =====================
   SAFE MODE: set USE_SERVICE_WORKER to true again only once sw.js
   is confirmed uploaded next to index.html and the app logs in fine.
   While false, this actively REMOVES any old/stuck service worker and
   clears its caches, so a bad cached copy can never keep the app broken. */
const APP_BUILD = "2026.09.07-aurea-stability-v6.2";   // shown in the menu, so an upload can be checked at a glance
const USE_SERVICE_WORKER = false;

function cleanupServiceWorkers(){
  if(!("serviceWorker" in navigator)) return;
  try{
    navigator.serviceWorker.getRegistrations().then(regs=>{
      regs.forEach(r=>{ r.unregister().catch(()=>{}); });
      if(regs.length){ console.warn("removed", regs.length, "old service worker(s)"); }
    }).catch(()=>{});
    if(window.caches && caches.keys){
      caches.keys().then(keys=>keys.forEach(k=>caches.delete(k).catch(()=>{}))).catch(()=>{});
    }
  }catch(e){ console.warn("sw cleanup:", e && e.message); }
}

function registerServiceWorker(){
  if(!("serviceWorker" in navigator)) return;
  if(!USE_SERVICE_WORKER){ cleanupServiceWorkers(); return; }
  try{
    navigator.serviceWorker.register("sw.js").then(reg=>{
      SW_REG=reg; SW_READY=true;
      if(reg.waiting) reg.waiting.postMessage({kind:"skip-waiting"});
      reg.addEventListener&&reg.addEventListener("updatefound",()=>{
        const nw=reg.installing;
        if(nw) nw.addEventListener("statechange",()=>{
          if(nw.state==="installed" && navigator.serviceWorker.controller) toastOk(t("updateReady"));
        });
      });
    }).catch(err=>{ console.warn("service worker not registered:", err && err.message); });

    navigator.serviceWorker.addEventListener("message", ev=>{
      const d=ev.data||{};
      if(d.kind==="notification-click"){ routeFromNotification(d.type); }
      if(d.kind==="resubscribe"){ subscribeForPush(); }
    });
  }catch(e){ console.warn("service worker error:", e && e.message); }
}
/* Opens the right page when a notification is tapped */
const NOTIF_ROUTE={
  booking:"bookings", booking_confirmed:"tickets", booking_cancelled:"tickets",
  activity_soon:"program", announcement:"home", message:"chat", chat:"chat",
  ticket:"tickets", request:"guests", task:"tasks", assignment:"tasks",
  attendance:"workday", feedback:"guests", occupancy:"dash"
};
function routeFromNotification(type){
  if(!S.session) return;
  const tab=NOTIF_ROUTE[type]; if(!tab) return;
  const allowed=navItems(S.session.role).map(x=>x[0]);
  if(allowed.includes(tab)){ S.tab=tab; S.op=null; S.cat=null; persist(); render(); }
}
/* If the app was opened fresh from a notification (?open=tab) */
function applyOpenParam(){
  try{
    const m=String(location.search||"").match(/[?&]open=([a-z]+)/i);
    if(!m || !S.session) return;
    const tab=m[1];
    const allowed=navItems(S.session.role).map(x=>x[0]);
    if(allowed.includes(tab)){ S.tab=tab; }
    history.replaceState({}, "", location.pathname);
  }catch(e){}
}
function showBanner(title,body){
  if(!notifSoundOn()) return;
  try{
    if("Notification" in window && Notification.permission==="granted"){
      // Prefer the service worker — its notifications persist even when the tab is in the background.
      if(SW_REG && SW_REG.showNotification){
        SW_REG.showNotification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true,vibrate:[120,60,120]});
      } else {
        const n=new Notification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true});
        setTimeout(()=>{ try{ n.close(); }catch(e){} },6000);
      }
    }
  }catch(e){}
}
function notify(title,body){ playChime(); vibrate(); showBanner(title,body); toast(title); }
/* Public push key — already set. Nothing to edit. */
const PUSH_PUBLIC_KEY="BBVFLaJhNy8JyyYiGPGOI7hFk9GVmgzWxo7ZSy5_Uo44xTg91TlQAppm8Y96xnmUHcr-4u81w4YxVrtZqqCSML8";
function urlB64ToUint8(base64){
  const pad="=".repeat((4-base64.length%4)%4);
  const b=(base64+pad).replace(/-/g,"+").replace(/_/g,"/");
  const raw=atob(b); const out=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i);
  return out;
}
async function subscribeForPush(){
  try{
    if(!("serviceWorker" in navigator) || !("PushManager" in window)) return;
    if(!PUSH_PUBLIC_KEY || PUSH_PUBLIC_KEY.indexOf("__")===0) return; // key not set → skip silently
    const reg = SW_REG || await navigator.serviceWorker.ready;
    if(!reg || !reg.pushManager) return;
    let sub = await reg.pushManager.getSubscription();
    if(!sub){
      sub = await reg.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:urlB64ToUint8(PUSH_PUBLIC_KEY)});
    }
    const j = sub.toJSON();
    const sess = S.session||{};
    const row = {
      endpoint: j.endpoint,
      p256dh: j.keys && j.keys.p256dh,
      auth: j.keys && j.keys.auth,
      role: sess.role||"",
      username: sess.username||"",
      room: sess.role==="guest" ? String(sess.room||"") : ""
    };
    // upsert into push_subscriptions (endpoint is primary key)
    if(REMOTE){
      await sb("push_subscriptions?on_conflict=endpoint",{
        method:"POST",
        headers:{ "Prefer":"resolution=merge-duplicates" },
        body: JSON.stringify(row)
      });
    }
  }catch(e){}
}
function askNotifPermission(){
  try{
    registerServiceWorker();
    if("Notification" in window && Notification.permission==="default"){
      Notification.requestPermission().then(p=>{ if(p==="granted") subscribeForPush(); }).catch(()=>{});
    } else if("Notification" in window && Notification.permission==="granted"){
      subscribeForPush();
    }
    // unlock audio on this user gesture
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    if(AUDIO_CTX.state==="suspended") AUDIO_CTX.resume();
  }catch(e){}
}
/* decide what changed after a poll and alert the current user accordingly */
function detectAndNotify(before){
  if(!S.session) return;
  const role=S.session.role, me=S.session.username;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  // MANAGER: new guest booking, new request, new incoming chat (from guest or staff)
  if(role==="manager"){
    if(S.bookings.length>before.bookings) notify(t("notifBooking"), "");
    if(S.requests.length>before.requests) notify(t("notifRequest"), "");
    const incoming=S.messages.filter(m=>m.sender==="guest").length;
    if(incoming>before.incomingMsgs) notify(t("notifMsg"), "");
  }
  // STAFF: new task assigned to me, or new chat reply from manager
  if(role==="staff"){
    const myTasks=S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length;
    if(myTasks>before.myTasks) notify(t("notifTask"), "");
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // GUEST: new chat reply from team, or new announcement
  if(role==="guest"){
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // EVERYONE: new announcement for them
  if(S.notes.length>before.notes) notify(t("notifNew"), "");
}
function notifySnapshot(){
  const role=S.session?S.session.role:null, me=S.session?S.session.username:null;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  return {
    bookings:S.bookings.length, requests:S.requests.length, notes:S.notes.length,
    incomingMsgs:S.messages.filter(m=>m.sender==="guest").length,
    myTasks:role==="staff"?S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length:0,
    myMsgs:myRoom?S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length:0
  };
}
let __polling=false;
/* ============ ACTIVITY ALARMS (time-based, fire once each) ============
   For the current user, checks every minute and alerts:
   - 5 minutes before start, at start, and at end of each activity today.
   Targeting:
   - GUEST: only activities they booked.
   - ASSIGNED entertainer: personal messages (be there 5 min early / take feedback after).
   - OTHER staff + manager: a general heads-up for every activity.
   Each (activity, phase) fires only once per day per device (tracked in localStorage). */
function alarmSeen(){ try{ return JSON.parse(localStorage.getItem("ent_alarms")||"{}"); }catch(e){ return {}; } }
function alarmSeenSave(o){ try{ localStorage.setItem("ent_alarms", JSON.stringify(o)); }catch(e){} }
function alarmKey(day,id,phase){ const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); return stamp+":"+day+":"+id+":"+phase; }
function fireActivityAlarm(a, phase){
  if(!S.session) return;
  const role=S.session.role;
  const name=a.name||"";
  const assigned = role==="staff" && a.entertainer && String(a.entertainer).toLowerCase()===String(S.session.username).toLowerCase();
  let title="", body=name;
  if(role==="guest"){
    // only booked activities (checked by caller)
    if(phase==="soon") title=t("almSoonG");
    else if(phase==="start") title=t("almStartG");
    else title=t("almDoneG");
    body=name;
  } else if(assigned){
    if(phase==="soon"){ title=t("almSoonS"); body=name; }
    else if(phase==="start"){ title=t("almStartS"); body=name; }
    else { title=t("almDoneS"); body=name; } // feedback reminder with room number
  } else {
    // other staff + manager: general heads-up
    if(phase==="soon") title=t("almSoonTeam");
    else if(phase==="start") title=t("almStartTeam");
    else title=t("almDoneTeam");
    body=name;
  }
  notify(title, body);
}
function checkActivityAlarms(){
  if(!S.session) return;
  if(!notifSoundOn()) return;               // respect the sound/alerts toggle
  const role=S.session.role;
  const todayIdx=todayIndex();
  const now=nowMinutes();
  const seen=alarmSeen();
  let changed=false;
  const todays=S.activities.filter(a=>a.day===todayIdx);
  todays.forEach(a=>{
    const w=actWindow(a); if(!w) return;
    // Relevance filter
    if(role==="guest"){ if(!myBooking(a.id)) return; }        // only booked
    // staff & manager: everyone gets it (assigned gets personal copy inside fireActivityAlarm)
    const phases=[["soon", w.s0-5],["start", w.s0],["done", w.e0]];
    phases.forEach(([phase, mark])=>{
      // fire when we're within the same minute or just past it (catch-up window of 2 min)
      if(now>=mark && now<mark+2){
        const k=alarmKey(a.day,a.id,phase);
        if(!seen[k]){ seen[k]=1; changed=true; fireActivityAlarm(a, phase); }
      }
    });
  });
  if(changed) alarmSeenSave(seen);
  // prune old keys (keep it small) — drop anything not from today
  const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
  const pruned={}; let prunedChanged=false;
  Object.keys(seen).forEach(k=>{ if(k.indexOf(stamp+":")===0) pruned[k]=1; else prunedChanged=true; });
  if(prunedChanged) alarmSeenSave(pruned);
}
/* re-render the visible list each minute so the status dots stay current */
function tickStatus(){ if(S.session && safeToRender()) render(); }
async function runPoll(){
  if(!REMOTE || __polling || !S.session) return;
  if(enforceAccess()){ render(); return; }
  __polling=true;
  try{ const before=notifySnapshot(); const changed=await DB.poll();
    if(changed){ detectAndNotify(before); if(safeToRender()) render(); }
  }catch(e){}
  __polling=false;
}
/* Maps a database table to the matching array in app state. */
const RT_TABLES={
  activities:"activities", bookings:"bookings", app_users:"users", tickets:"tickets",
  ticket_orders:"orders", rooms:"rooms", guest_accounts:"accounts", messages:"messages",
  requests:"requests", tasks:"tasks", announcements:"notes", attendance:"attendance",
  feedback:"feedback", team_profiles:"profiles", buses:"buses", quizzes:"quizzes", quiz_replies:"quizReplies", staff_attendance:"staffAtt", photos:"photos", staff_requests:"staffReqs"
};
/* Applies ONE row change straight into state — no full database reload. */
function applyRealtimeChange(payload){
  try{
    const table=payload.table, ev=payload.eventType||payload.type;
    // app_settings is a single row of config — merge it directly
    if(table==="app_settings"){
      const row=payload.new;
      if(row && row.data){ S.settings={...DEFAULT_SETTINGS,...row.data}; applySettings(); return true; }
      return false;
    }
    const key=RT_TABLES[table]; if(!key || !Array.isArray(S[key])) return false;
    const list=S[key];
    if(ev==="INSERT" && payload.new){
      if(!list.some(x=>x.id===payload.new.id)) list.push(payload.new);
      return true;
    }
    if(ev==="UPDATE" && payload.new){
      const i=list.findIndex(x=>x.id===payload.new.id);
      if(i>=0) list[i]={...list[i],...payload.new}; else list.push(payload.new);
      return true;
    }
    if(ev==="DELETE"){
      const oldRow=payload.old||{};
      if(oldRow.id==null) return false;
      S[key]=list.filter(x=>x.id!==oldRow.id);
      return true;
    }
  }catch(e){ console.warn("realtime patch failed:", e && e.message); }
  return false;
}
function startRealtime(){
  if(!REMOTE || window.__rt) return;
  window.__rt=true;
  const sc=document.createElement("script");
  sc.src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
  sc.onload=()=>{ try{
    const client=window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
    let tmr=null, pending=false;
    client.channel("live-changes")
      .on("postgres_changes",{event:"*",schema:"public"},payload=>{
        const before=notifySnapshot();
        const patched=applyRealtimeChange(payload);
        if(patched){
          // targeted update: state is already correct, just alert + repaint
          detectAndNotify(before);
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ if(S.session && safeToRender()) render(); }, 120);
        } else if(!pending){
          // unknown table -> fall back to a single full refresh
          pending=true;
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ pending=false; runPoll(); }, 300);
        }
      })
      .subscribe();
  }catch(e){ console.warn("realtime unavailable",e); } };
  sc.onerror=()=>console.warn("realtime script blocked — polling continues");
  document.head.appendChild(sc);
}
(async function(){
  restore();
  document.documentElement.setAttribute("data-theme",S.theme);
  document.documentElement.lang=S.lang;
  document.documentElement.dir=(S.lang==="ar"?"rtl":"ltr");
  try{ await DB.load(); }
  catch(e){
    console.error(e);
    if(REMOTE){ S.loadError=true; applySettings(); render(); return; }
    S.activities=demoActivities(); S.bookings=demoBookings();
    S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
    S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
    S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
  }
  /* validate remembered session against fresh data */
  if(S.session){
    if(S.session.role==="guest"){
      const rm=S.rooms.find(x=>String(x.room)===String(S.session.room));
      const acc=S.accounts.find(a=>a.id===S.session.accountId) || S.accounts.find(a=>String(a.room)===String(S.session.room));
      const sameStay=!!acc && String(S.session.arrival||"")===String(acc.arrival||"") && String(S.session.departure||"")===String(acc.departure||"");
      if(!rm || !rm.active || !acc || !sameStay || acc.active===false || stayExpired(acc)) S.session=null;
      else S.session={role:"guest",room:acc.room,name:acc.name,phone:acc.phone||"",
        nationality:acc.nationality||"",arrival:acc.arrival,departure:acc.departure,
        accountId:acc.id,username:acc.username||acc.room};
    } else {
      const su=String(S.session.username||"").trim().toLowerCase();
      const u=S.users.find(x=>String(x.username||"").trim().toLowerCase()===su && !isAttOnly(x));
      const roleOk=!!u && (S.session.role==="manager" ? u.role==="manager" : u.role==="staff");
      if(!roleOk || !accountActive(u)) S.session=null;
      else S.session={...S.session,name:u.display_name||u.username,userId:u.id,number:u.number||null,photo:u.photo||''};
    }
    if(!S.session){ S.tab="home"; }
    persist();
  }
  /* V5: resolve the final landing screen before the first paint, preventing the remembered-screen -> start-screen flash. */
  if(S.session) S.tab=defaultTabFor(S.session.role);
  enforceAccess();
  applyOpenParam();
  applySettings();
  render();
  startRealtime();
  // Fast polling backup — makes updates feel instant even if websockets are blocked.
  if(REMOTE){
    setInterval(()=>{ if(S.session) runPoll(); }, 5000);
    // Poll immediately when the app regains focus or becomes visible
    window.addEventListener("focus", ()=>{ if(S.session) runPoll(); });
    document.addEventListener("visibilitychange", ()=>{ if(!document.hidden && S.session) runPoll(); });
  }
  initPhotoTaps();
  setTimeout(()=>loadWeather(false), 800);
  initConnectionWatch();
  initErrorGuard();
  // ===== Activity alarms + live status dots =====
  // Check every 30s so a minute boundary is never missed; re-render keeps dots current.
  let __lastMin=-1;
  function alarmTick(){
    try{
      checkActivityAlarms();
      const m=nowMinutes();
      if(m!==__lastMin){ __lastMin=m; tickStatus(); }   // refresh dots once per minute
    }catch(e){}
  }
  setInterval(alarmTick, 30000);
  setTimeout(alarmTick, 1500);                            // run shortly after load
  window.addEventListener("focus", alarmTick);            // catch phone waking up
  document.addEventListener("visibilitychange", ()=>{ if(!document.hidden) alarmTick(); });
})();
