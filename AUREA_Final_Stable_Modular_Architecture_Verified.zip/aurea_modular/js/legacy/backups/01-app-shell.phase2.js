/* ---------------- shared pieces ---------------- */
function socialTopIcons(){
  const st=S.settings;
  const links=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube],["WhatsApp",waLink()]].filter(x=>x[1]);
  return links.map(([n,u])=>`<a class="iconbtn socialtop" href="${esc(u)}" target="_blank" rel="noopener" aria-label="${n}">${brandIc(n)}</a>`).join("");
}
function waLink(){
  const num=String(S.settings.whatsapp||"").replace(/[^0-9]/g,"");
  return num?("https://wa.me/"+num):"";
}
function navGroupsBase(role){
  if(role==="guest"){
    const un=unreadFor("guest");
    return [
      {key:"secProgram", head:t("secProgram"), items:[
        ["home","home",menuLabel("menuHome",t("home")),0],
        ["program","calendar",menuLabel("menuProgram",t("program")),0],
        ["chat","chat",menuLabel("menuChat",t("chat")),un],
        ["teaminfo","users",t("teamPage"),0],
        ["stay","user",t("myActs"),0],
        ...(featureOn("tickets")?[["tickets","ticket",t("myTickets"),0]]:[])]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["social","star",t("socialPage"),0]]}
    ];
  }
  if(role==="staff"){
    const myRoom="staff:"+S.session.username;
    const un=S.messages.filter(m=>m.room===myRoom&&m.sender==="team"&&!m.read_by_guest).length;
    const taskN=S.tasks.filter(x=>["open","accepted","still"].includes(x.status)&&(!x.assigned_to||x.assigned_to===S.session.username)).length;
    return [
      {key:"secTeamwork", head:t("secTeamwork"), items:[
        ["workday","clipboard",t("myWorkDay"),0],
        ["mypage","user",t("myAttendance"),0],
        ...(featureOn("quiz")?[["quiz","sparkle",t("quizTab"),quizForToday("staff")&&!myQuizReply(quizForToday("staff").id)?1:0]]:[]),
        ...(featureOn("bus")?[["bus","bus",t("busTimes"),0]]:[]),
        ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[])]},
      {key:"secProgram", head:t("secProgram"), items:[
        ["today","calendar",t("todayProgram"),0],
        ["week","calendar",t("program"),0],
        ["bookings","ticket",t("bookings"),0]]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["chat","chat",t("chatManager"),un],
        ...(featureOn("gallery")?[["gallery","sparkle",t("galleryTab"),0]]:[]),
        ["teaminfo","users",t("teamPage"),0]]}
    ];
  }
  const un=unreadFor("manager");
  const newReq=S.requests.filter(r=>r.status==="new").length;
  return [
    {key:"secManage", head:t("secManage"), items:[
      ["dash","grid",t("dashboard"),0],
      ["program","calendar",t("manage"),0],
      ["dayplan","clipboard",t("dayPlan"),0],
      ["req","clipboard",t("reqTab"),0],
      ["assign","check",t("assignCenter"),0],
      ["quiz","sparkle",t("quizCenter"),0],
      ["gallery","sparkle",t("galleryTab"),0],
      ["hotelinfo","pin",t("hotelInfoTab"),0],
      ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[]),
      ["qr","sparkle",t("qrTab"),0]]},
    {key:"secGuests", head:t("secGuests"), items:[
      ["guests","chat",t("guestsTab"),unreadGuests()+newReq],
      ["team","users",t("teamTab"),unreadTeam()+teamReqCount()]]},
    {key:"secSettings", head:t("secSettings"), items:[
      ["settings","palette",t("settingsHub"),0]]}
  ];
}
/* ===== MENU BUILDER =====
   The manager can rename, reorder, hide and add items per role. Stored in
   settings.menu so it syncs to every device. */
function menuConf(role){
  const m=(S.settings && S.settings.menu) || {};
  return m[role] || {order:[], hidden:[], names:{}, custom:[]};
}
function customPages(role){ return (menuConf(role).custom||[]); }
function applyMenuConf(role, groups){
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{}, order=conf.order||[];
  // rename + hide
  const gnames=conf.gnames||{};
  let out=groups.map(g=>({key:g.key, head:(g.key&&gnames[g.key])||g.head, items:g.items
    .filter(it=>!hidden.includes(it[0]))
    .map(it=>[it[0], it[1], names[it[0]]||it[2], it[3]])}));
  // the manager's own pages go into the first section
  const extra=customPages(role).map(p=>[ "cp:"+p.id, p.icon||"pin", p.title, 0 ]);
  if(extra.length && out.length) out[0]={...out[0], items:out[0].items.concat(extra)};
  // a section whose title she blanked out simply loses its heading
  // custom order inside each section
  if(order.length){
    out=out.map(g=>({...g, items:g.items.slice().sort((a,b)=>{
      const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
      if(ia<0&&ib<0) return 0;
      if(ia<0) return 1;
      if(ib<0) return -1;
      return ia-ib;
    })}));
  }
  return out.filter(g=>g.items.length);
}
function navGroups(role){
  const groups=applyMenuConf(role, navGroupsBase(role));
  if(role!=="guest") return groups;
  const wanted=["home","program","chat","teaminfo","stay","tickets","social"];
  const all=groups.flatMap(g=>g.items), byId=new Map(all.map(it=>[it[0],it]));
  // Re-add required guest destinations if an old Menu Builder configuration hid them.
  const base=navGroupsBase("guest").flatMap(g=>g.items);
  base.forEach(it=>{ if(!byId.has(it[0])) byId.set(it[0],it); });
  const primary=wanted.slice(0,6).map(id=>byId.get(id)).filter(Boolean);
  const social=byId.get("social");
  return [{key:"secProgram",head:t("secProgram"),items:primary}, ...(social?[{key:"secConnect",head:t("secConnect"),items:[social]}]:[])];
}
function navItems(role){ return navGroups(role).flatMap(g=>g.items); }
function topBar(title,sub){
  const role=S.session?S.session.role:"guest";
  const anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow">
      <button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button>
    </div>
  </div>
  <div class="who whobar"><h2>${esc(title)}</h2><p>${esc(sub||"")}</p></div>`;
}
function hubBack(){
  // shown on Settings sub-pages so the manager can go back to the hub
  if(S.session && S.session.role==="manager")
    return `<button class="crumb" id="crumb-hub">${ic("back",15)} ${t("settingsHub")}</button>`;
  return "";
}
/* Which menu sections are expanded — defaults to the one you are currently in. */
function drawerOpenSection(i, hasCurrent){
  if(!S.drawerOpen) S.drawerOpen={};
  if(S.drawerOpen[i]===undefined) return hasCurrent;
  return !!S.drawerOpen[i];
}
function openMenuDrawer(){
  askNotifPermission();
  const role=S.session?S.session.role:"guest";
  const wrap=document.createElement("div"); wrap.className="drawer-bg";
  wrap.innerHTML=`<div class="drawer">
    <div class="dr-head">
      <div class="mono serif sm">${esc((S.settings.name||"E").trim().charAt(0).toUpperCase())}</div>
      <div><h3>${esc(S.settings.name)}</h3><div class="dr-person"><p>${esc(S.session?S.session.name:"")}</p>${role==="guest"?guestWeatherChip():""}</div></div>
    </div>
    <div class="dr-items">
      ${navGroups(role).map((g,gi)=>{
        const hasCurrent=g.items.some(it=>it[0]===S.tab);
        const dots=g.items.reduce((n,it)=>n+(it[3]||0),0);
        const open=drawerOpenSection(gi, hasCurrent);
        return `
        <button class="dr-sec dr-sech ${open?"open":""}" data-drsec="${gi}">
          <span>${esc(g.head)}</span>
          ${dots?`<span class="badge">${dots}</span>`:""}
          <span class="dr-caret">${ic("back",14)}</span>
        </button>
        <div class="dr-group ${open?"open":""}">
          ${g.items.map(([id,icn,lb,dot])=>`<button class="dr-it ${S.tab===id?"on":""}" data-drtab="${id}">
            <span class="dr-ic">${ic(icn,19)}</span><span class="dr-lb">${lb}</span>${dot?`<span class="badge">${dot}</span>`:""}
          </button>`).join("")}
        </div>`;
      }).join("")}
    </div>
    <div class="dr-foot">
      <button class="iconbtn" id="dr-lang" aria-label="${t("language")}">${ic("globe",19)}</button>
      <button class="iconbtn" id="dr-theme" aria-label="theme">${ic(S.theme==="light"?"moon":"sun",19)}</button>
      <button class="iconbtn ${notifSoundOn()?"on-notif":""}" id="dr-notif" aria-label="${t("notifSound")}">${ic(notifSoundOn()?"bell":"belloff",19)}</button>
      <button class="dr-out" id="dr-out">${ic("power",16)} ${t("logout")}</button>
    </div>
    <div class="dr-build">${esc(APP_BUILD)}</div>
  </div>`;
  document.body.appendChild(wrap);
  requestAnimationFrame(()=>wrap.classList.add("open"));
  const close=(cb)=>{ wrap.classList.remove("open"); setTimeout(()=>{ wrap.remove(); if(cb) cb(); },240); };
  wrap.onclick=e=>{ if(e.target===wrap) close(); };
  wrap.querySelectorAll("[data-drsec]").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.drsec;
    if(!S.drawerOpen) S.drawerOpen={};
    const groups=navGroups(S.session?S.session.role:"guest");
    const hasCur=(groups[i]&&groups[i].items||[]).some(it=>it[0]===S.tab);
    S.drawerOpen[i]=!drawerOpenSection(i,hasCur);
    wrap.remove(); openMenuDrawer();
  });
  wrap.querySelectorAll("[data-drtab]").forEach(b=>b.onclick=()=>{
    close(()=>{ S.tab=b.dataset.drtab; S.chatRoom=null; render(); });
  });
  wrap.querySelector("#dr-lang").onclick=()=>close(openLangModal);
  wrap.querySelector("#dr-theme").onclick=()=>close(()=>setTheme(S.theme==="light"?"dark":"light"));
  wrap.querySelector("#dr-notif").onclick=()=>{
    const turningOn = !notifSoundOn();
    localStorage.setItem("ent_notif", turningOn ? "on" : "off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    close(()=>render());
  };
  wrap.querySelector("#dr-out").onclick=()=>close(()=>{S.session=null;S.chatRoom=null;loginMode="guest";guestMode="new";resetWiz();persist();render();});
}
function heroCard(a){
  if(!a) return "";
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken);
  return `<div class="hero" data-open="${a.id}">
    <img src="${esc(a.image||IMG.show)}" alt="">
    <div class="veil"></div>
    <div class="tag">${ic("sparkle",13)} ${t("highlight")}</div>
    <div class="body">
      <h3>${esc(a.name)}</h3>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span>${a.capacity?`<span>${mi("users")}${left} ${t("seatsLeft")}</span>`:""}</div>
      <div class="desc">${esc(a.desc)}</div>
    </div>
  </div>`;
}
/* Today's highlights, swiped sideways. One card behaves exactly as before, so
   a day with a single highlight looks the way it always did. */
function heroCarousel(list){
  list=(list||[]).filter(Boolean).slice(0,5);
  if(!list.length) return "";
  if(list.length===1) return heroCard(list[0]);
  return `<div class="hero-wrap">
    <div class="hero-rail" id="hero-rail">${list.map(a=>heroCard(a)).join("")}</div>
    <div class="hero-dots" id="hero-dots">${list.map((a,i)=>
      `<i class="${i===0?"on":""}" data-herodot="${i}"></i>`).join("")}</div>
  </div>`;
}
function activityCard(a,{showBook=true,showFav=true,manager=false,staff=false}={}){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id);
  const fav=S.favorites.includes(a.id);
  let side="";
  if(manager){
    side=`<button class="btn sm ghost" data-edit="${a.id}">${ic("pen",15)}</button><span class="seats">${taken}/${a.capacity}</span>`;
  } else if(staff){
    side=`${canSeeGuests(a)?`<button class="btn sm ghost" data-att="${a.id}">${ic("check",15)}</button>`:""}<span class="pill">${bookingsFor(a.id).length} ${t("guests")}</span>`;
  } else if(showBook){
    /* Once today's activity has finished (or the day has passed) it can no longer
       be booked — the guest sees that straight away instead of after tapping. */
    const over = isToday(a.day) && activityStatus(a)==="done";
    const running = isToday(a.day) && activityStatus(a)==="live";
    if(over){
      side = mine
        ? `<span class="chip done">${t("wasBooked")}</span>`
        : `<span class="chip done">${t("finishedChip")}</span>`;
    } else {
      side = mine
        ? `<span class="chip ${mine.status==="booked"?"ok":""}">${mine.status==="booked"?t("booked"):t("onWaitlist")}</span>`
        : full ? `<span class="chip full">${t("full")}</span>`
        : `<button class="btn sm" data-book="${a.id}">${running?t("bookNowLive"):t("book")}</button>`;
      side += `<span class="seats">${unlimited||full?"":left+" "+t("seatsLeft")}</span>`;
    }
  }
  // the coloured ring is drawn around the guest's own booked activity
  const ringCls = (mine && isToday(a.day)) ? (" "+statusRing(a)) : "";
  const overNow = isToday(a.day) && activityStatus(a)==="done";
  const guestCard=!manager&&!staff;
  return `<div class="card act${guestCard?" guest-act":""}${ringCls}${overNow?" is-over":""}" ${manager||staff||overNow?"":`data-open="${a.id}"`}>
    <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" loading="lazy" ${guestCard?"":`data-pvsingle="${esc(a.image||IMG.show)}"` }>
    <div class="mid">
      <span class="catbadge">${catLabel(a.category)}</span>
      <h4>${statusDot(a)}${esc(a.name)}</h4>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div>
      ${guestCard&&a.desc?`<p class="guest-act-desc">${esc(a.desc)}</p>`:""}
      ${mine&&isToday(a.day)?`<div class="guest-status-line">${statusPill(a)}</div>`:""}
    </div>
    <div class="side">
      ${showFav&&!manager&&!staff?`<button class="fav" data-fav="${a.id}">${fav?`<span class="hf">${ic("heart",19)}</span>`:ic("heart",19)}</button>`:""}
      ${side}
      ${guestCard&&!overNow?`<span class="guest-detail-arrow">${ic("back",15)}</span>`:""}
    </div>
  </div>`;
}
function dayTabs(){
  return `<div class="daytabs">${t("daysShort").map((d,i)=>
    `<button data-day="${i}" class="${S.day===i?"on":""}">${d}</button>`).join("")}</div>`;
}
function subTabs(group,items){
  if(PAGE_SECTIONS[group]){
    const ord=pageOrder(group);
    items=items.filter(it=>ord.includes(it[0]))
               .sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
    if(!items.some(it=>it[0]===S.sub[group]) && items.length) S.sub[group]=items[0][0];
  }
  return `<div class="pills">${items.map(([id,lb])=>
    `<button data-sub="${group}:${id}" class="${S.sub[group]===id?"on":""}">${lb}</button>`).join("")}</div>`;
}
function listByCat(acts,opts){
  if(!acts.length) return `<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return CAT_ORDER.filter(c=>acts.some(a=>a.category===c)).map(c=>`
    <div class="sec"><h3>${catLabel(c)}</h3>
      ${acts.filter(a=>a.category===c).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a,opts)).join("")}
    </div>`).join("");
}
function operationCard(op){
  const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id);
  const img=opImage(op.id);
  return `<button class="opcard" data-op="${op.id}">
    <img src="${esc(img)}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h3>${esc(opLabel(op.id))}</h3><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",18)}</span>
  </button>`;
}
function categoryCard(cat){
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===cat);
  return `<button class="catcard ${acts.length?"":"empty-cat"}" data-cat="${cat}">
    <img src="${esc(catImage(cat))}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h4>${esc(catLabel(cat))}</h4><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",16)}</span>
  </button>`;
}
function browseView(title){
  // level 1: operations
  if(!S.op){
    let mineBanner="";
    if(S.session && S.session.role==="staff"){
      const mine=S.activities.filter(a=>a.day===S.day && canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
      if(mine.length) mineBanner=`<div class="sec"><h3>${ic("clipboard",18)} ${t("myActs")}</h3>
        <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
        ${mine.map(a=>activityCard(a,{staff:true,showBook:false,showFav:false})).join("")}</div>`;
    }
    const dp=dayPlanFor(S.day);
    const themeBanner=dp&&dp.theme?`<div class="theme-banner"><span class="tb-l">${t("restaurantTheme")}</span><b class="serif">${esc(dp.theme)}</b></div>`:"";
    return `<div class="screen fadein">${topBar(title,t("days")[S.day])}${dayTabs()}
      ${themeBanner}
      ${mineBanner}
      <div class="opgrid">${OPS.map(operationCard).join("")}</div></div>`;
  }
  const op=OPS.find(o=>o.id===S.op)||OPS[0];
  // Single-category operation -> show its activities directly (no middle level)
  if(op.cats.length===1){
    const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      ${acts.length?statusLegend():""}
      ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
    </div>`;
  }
  // level 2: categories inside a multi-category operation
  if(!S.cat){
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      <div class="catgrid">${op.cats.map(categoryCard).join("")}</div></div>`;
  }
  // level 3: the activities of the chosen category
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===S.cat).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  return `<div class="screen fadein">${topBar(catLabel(S.cat),opLabel(op.id))}
    <button class="crumb" id="crumb-cats">${ic("back",15)} ${esc(opLabel(op.id))}</button>
    ${dayTabs()}
    ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
  </div>`;
}
/* ================= CHAT TRANSLATION =================
   Guests write in their language, the team reads in theirs. Uses a free
   public translation service (no key needed, so it works for guests too).
   Results are remembered for the session so nothing is fetched twice. */
const TRANS_CACHE={};
const TRANS_SHOWN={};
function transKey(id,lang){ return id+"|"+lang; }
async function translateText(text, to){
  const from="auto";
  const url="https://api.mymemory.translated.net/get?q="+encodeURIComponent(text)+
    "&langpair="+encodeURIComponent(from+"|"+to);
  const res=await fetch(url);
  if(!res.ok) throw new Error("translate "+res.status);
  const data=await res.json();
  const out=data && data.responseData && data.responseData.translatedText;
  if(!out || /^please select|invalid/i.test(out)) throw new Error("no translation");
  return String(out);
}
async function translateMessage(id){
  const m=S.messages.find(x=>String(x.id)===String(id));
  if(!m) return;
  const to=S.lang||"en";
  const k=transKey(id,to);
  if(TRANS_CACHE[k]){ TRANS_SHOWN[k]=!TRANS_SHOWN[k]; render(); return; }
  TRANS_SHOWN[k]=true; TRANS_CACHE[k]="__loading__"; render();
  try{
    TRANS_CACHE[k]=await translateText(m.text, to);
  }catch(e){
    delete TRANS_CACHE[k]; delete TRANS_SHOWN[k];
    toastErr(t("translateFail"));
  }
  render();
}
function bubbleTranslation(m){
  const to=S.lang||"en";
  const k=transKey(m.id,to);
  const val=TRANS_CACHE[k];
  if(!val || !TRANS_SHOWN[k]) return "";
  if(val==="__loading__") return `<span class="tr-line loading">${t("translating")}</span>`;
  return `<span class="tr-line"><i>${t("translatedTag")}</i>${esc(val)}</span>`;
}
function threadView(room,meSide){
  const msgs=S.messages.filter(m=>m.room===room);
  const isManager=S.session && S.session.role==="manager";
  const emptyTxt = String(room).startsWith("staff:") ? t("noStaffMsg") : t("noMessages");
  return `<div class="thread">
    ${msgs.length?msgs.map(m=>{
      const mine = m.sender===meSide;
      const picking=chatSelOn(), picked=chatSelHas(m.id);
      return `<div class="bubwrap ${mine?"me":"them"}${picking?" picking":""}${picked?" picked":""}"
        ${picking?`data-msgpick="${m.id}"`:""}>
        ${picking?`<span class="pick-dot">${picked?ic("check",13):""}</span>`:""}
        <div class="bub ${mine?"me":"them"}">${esc(m.text)}${bubbleTranslation(m)}<span class="tm">${mine?"":esc(m.sender_name)+" · "}${fmtTime(m.created_at)}</span></div>
        ${mine?"":`<button class="tr-btn" data-translate="${m.id}">${ic("sparkle",12)} ${TRANS_SHOWN[transKey(m.id,S.lang||"en")]?t("showOriginal"):t("translateBtn")}</button>`}
        ${isManager&&!chatSelOn()?`<div class="bub-tools">
          <button class="bubtool" data-msgedit="${m.id}" aria-label="${t("editMsg")}">${ic("pen",14)}</button>
          <button class="bubtool" data-msgdel="${m.id}" aria-label="${t("deleteMsg")}">${ic("exit",14)}</button>
        </div>`:""}
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("chat",30)}</div>${emptyTxt}</div>`}
  </div>
  <div class="chatbar">
    <input id="chat-in" placeholder="${t("typeMessage")}" autocomplete="off">
    <button id="chat-send" aria-label="${t("send")}">${ic("send",17)}</button>
  </div>`;
}
/* ---------------- guest ---------------- */
function guestWeatherChip(){
  if(!featureOn("weather")) return "";
  const w=S.weather;
  if(w && !w.error && w.cur){
    const c=w.cur;
    return `<button class="guest-weather" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
      <span class="gw-icon">${ic(wmoIcon(c.weather_code),18)}</span>
      <span class="gw-temp">${Math.round(c.temperature_2m)}°</span>
      <span class="gw-label">${esc(wmoLabel(c.weather_code))}</span>
    </button>`;
  }
  return `<button class="guest-weather loading" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
    <span class="gw-icon">${ic("sun",18)}</span><span class="gw-label">${esc(t("weatherTab"))}</span>
  </button>`;
}
function guestHomeTopBar(g,todayIdx){
  const role="guest", anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top guest-top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow"><button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button></div>
  </div>
  <div class="guest-welcome-head">
    <div><h1>${esc(t("welcome"))}, ${esc(g.name)}</h1><p>${esc(t("room"))} ${esc(g.room)} · ${esc(t("days")[todayIdx])}</p></div>
    ${guestWeatherChip()}
  </div>`;
}
function guestQuickActions(){
  const items=[];
  if(featureOn("hotelinfo")) items.push(["hotelinfo","pin",t("hotelInfoTab")]);
  if(featureOn("gallery")) items.push(["gallery","sparkle",t("galleryTab")]);
  if(featureOn("quiz")) items.push(["quiz","sparkle",t("quizTab")]);
  if(!items.length) return "";
  return `<div class="guest-quick-actions">${items.map(([tab,icon,label])=>
    `<button data-tab="${tab}" class="gqa"><span class="gqa-ic">${ic(icon,22)}</span><span>${esc(label)}</span><i>${ic("back",14)}</i></button>`
  ).join("")}</div>`;
}
function openGuestActivityDetail(a){
  if(!a) return;
  const unlimited=!(+a.capacity), taken=seatsTaken(a.id), left=Math.max(0,(+a.capacity||0)-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id), status=isToday(a.day)?activityStatus(a):"";
  const wrap=baseModal(`<div class="guest-detail">
    <div class="gd-photo"><img src="${esc(a.image||IMG.show)}" alt=""><span class="gd-cat">${esc(catLabel(normCat(a)))}</span></div>
    <div class="gd-copy">
      <h3>${esc(a.name)}</h3>
      <div class="gd-meta"><span>${mi("clock")}${esc(a.time)}${a.end_time?" – "+esc(a.end_time):""}</span><span>${mi("pin")}${esc(a.location||"")}</span></div>
      ${a.desc?`<p class="gd-desc">${esc(a.desc)}</p>`:""}
      <div class="gd-facts">
        ${!unlimited?`<span>${ic("users",16)} <b>${full?t("full"):left+" "+t("seatsLeft")}</b></span>`:""}
        ${status?`<span>${statusDot(a)} <b>${status==="live"?t("st_live"):status==="done"?t("st_done"):t("st_todo")}</b></span>`:""}
      </div>
    </div>
    ${mine?`<div class="gd-booked">${ic("check",17)} ${mine.status==="booked"?t("booked"):t("onWaitlist")}</div>`:
      `<button class="btn guest-book-now" id="gd-book">${full?t("waitlist"):t("book")}</button>`}
    <button class="btn ghost" id="gd-close">${t("close")}</button>
  </div>`);
  wrap.querySelector("#gd-close").onclick=()=>wrap.remove();
  const book=wrap.querySelector("#gd-book");
  if(book) book.onclick=()=>{wrap.remove();openBookModal(a);};
}
function guestView(){
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  const g=S.session;
  const todayIdx=todayIndex();
  if(S.tab==="home"){
    const todays=S.activities.filter(a=>a.day===todayIdx);
    const hl=todays.find(a=>a.highlight)||todays[0];
    const wm=(S.settings.welcomeMsg||"").trim();
    return `<div class="screen fadein">
      ${guestHomeTopBar(g,todayIdx)}
      ${stayCard((S.accounts||[]).find(a=>a.id===g.accountId)||(S.accounts||[]).find(a=>String(a.room)===String(g.room)))}
      ${wm?`<div class="card guest-welcome-msg">${esc(wm)}</div>`:""}
      ${guestQuickActions()}
      ${heroCarousel([hl].concat(todays.filter(a=>a!==hl && a.highlight)))}
      <div class="quickrow">
        <button id="btn-req-song"><span>${ic("music",22)}</span>${t("songRequest")}</button>
        <button id="btn-req-bday"><span>${ic("gift",22)}</span>${t("birthdayRequest")}</button>
      </div>
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${todays.filter(a=>a!==hl).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a)).join("")||`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
      </div>
      ${reviewDue(g)?reviewBlock():""}
      ${socialBlock()}
    </div>`;
  }
  if(S.tab==="program") return browseView(menuLabel("menuProgram",t("program")));
  if(S.tab==="social") return socialPageView();
  if(S.tab==="teaminfo") return teamInfoView();
  if(S.tab==="tickets") return guestTicketsView();
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chat"),accountName(g.room))}
      ${threadView(g.room,"guest")}
    </div>`;
  }
  const mine=S.bookings.filter(b=>b.room===g.room);
  const orders=myOrders();
  const reqs=myRequestsList();
  const favActs=S.activities.filter(a=>S.favorites.includes(a.id));
  return `<div class="screen fadein">
    ${topBar(t("myStay"),g.name)}
    <div class="card profcard">
      <div class="pf-ava">${ic("user",26)}</div>
      <div style="min-width:0">
        <h4>${esc(g.name)}</h4>
        <p class="mini">${t("room")} ${esc(g.room)}${g.nationality?` · ${esc(g.nationality)}`:""}</p>
        <p class="mini">${esc(g.arrival||"")} → ${esc(g.departure||"")}</p>
      </div>
      <button class="btn sm ghost" id="btn-chpass" style="flex:none">${ic("key",15)} ${t("changePass")}</button>
    </div>
    <div class="sec"><h3>${t("myBookings")} <span class="count">${mine.length}</span></h3>
      ${mine.length?mine.map(b=>{
        const a=S.activities.find(x=>x.id===b.activity_id); if(!a) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" data-pvsingle="${esc(a.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[a.day]}</span><h4>${esc(a.name)}</h4>
            <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div></div>
          <div class="side">
            <span class="chip ${b.status==="booked"?"ok":""}">${b.status==="booked"?t("booked"):t("onWaitlist")}</span>
            <button class="btn sm warn" data-cancel="${b.id}">${ic("close",14)}</button>
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("noBookings")}</div>`}
    </div>
    <div class="sec"><h3>${t("myTickets")} <span class="count">${orders.length}</span></h3>
      ${orders.length?orders.map(o=>{
        const tk=S.tickets.find(x=>x.id===o.ticket_id); if(!tk) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span><h4>${esc(tk.name)}</h4>
            <div class="meta"><span>${mi("ticket")}×${o.qty}</span><span>${esc(tk.price||"")}</span>${o.collect_from?`<span>${mi("user")}${esc(o.collect_from)}</span>`:""}</div></div>
          <div class="side">
            <span class="chip ${o.status==="paid"?"ok":"res"}">${o.status==="paid"?t("paid"):t("reserved")}</span>
            ${o.status==="paid"?"":`<button class="btn sm warn" data-cancelorder="${o.id}">${ic("close",14)}</button>`}
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
    </div>
    ${reqs.length?`<div class="sec"><h3>${t("myRequests")} <span class="count">${reqs.length}</span></h3>
      <div class="card">${reqs.map(r=>`<div class="booking-line">
        <span>${ic(r.type==="song"?"music":"gift",15)} ${esc(r.detail)}${r.date?` · ${esc(r.date)}`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <span class="chip ${r.status==="done"?"ok":"res"}">${r.status==="done"?t("done"):t("statusNew")}</span>
          ${r.status==="done"?"":`<button class="btn sm warn" data-delreq="${r.id}">${ic("close",14)}</button>`}
        </span></div>`).join("")}</div>
    </div>`:""}
    <div class="sec"><h3>${t("favorites")} <span class="count">${favActs.length}</span></h3>
      ${favActs.length?favActs.map(a=>activityCard(a)).join(""):`<div class="empty"><div class="big">${ic("heart",30)}</div>${t("noFavs")}</div>`}
    </div>
    ${reviewDue(g)?reviewBlock():""}
  </div>`;
}
function socialPageView(){
  const st=S.settings;
  const socials=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube]].filter(x=>x[1]);
  const reviews=[["Google",st.google],["Facebook",st.facebook],["Tripadvisor",st.tripadvisor],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  const wa=waLink();
  return `<div class="screen fadein">
    ${topBar(t("socialPage"),S.settings.name)}
    ${S.session.role==="guest"?`<div class="card ratecard">
      <b>${t("howWasIt")}</b>
      <div class="rate-stars">${[1,2,3,4,5].map(r=>`<button class="rs" data-guestrate="${r}" aria-label="${r}">${ic("star",26)}</button>`).join("")}</div>
    </div>`:""}
    ${wa?`<a class="wa-cta" href="${esc(wa)}" target="_blank" rel="noopener">${brandIc("WhatsApp")} ${t("contactWa")}</a>`:""}
    ${socials.length?`<div class="sec"><h3>${t("followUs")}</h3>
      ${socials.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic">${brandIc(n)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
    ${reviews.length?`<div class="sec"><h3>${t("leaveReview")}</h3>
      ${reviews.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic star">${ic("star",17)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
  </div>`;
}
function teamInfoView(){
  /* one single team list — the real accounts the manager edits, so what she
     changes on a person is exactly what guests see. */
  const list=(S.users||[])
    .filter(u=>(u.role==="staff"||u.role==="manager") && u.active!==false)
    .map(u=>({...u, name:u.display_name||u.username}))
    .sort((a,b)=>{
      const am=/manager/i.test(a.position||"")?0:1, bm=/manager/i.test(b.position||"")?0:1;
      return am-bm || (a.number||99)-(b.number||99) || a.id-b.id;
    });
  const entCount=list.filter(p=>!/manager/i.test(p.position||"")).length;
  return `<div class="screen fadein">
    ${topBar(t("teamPage"),S.settings.name)}
    <div class="teamcount card"><b class="serif">${entCount}</b><span>${t("ourTeam")} · ${entCount} ${t("entertainersWord")}</span></div>
    ${list.length?list.map(p=>teamCard(p)).join(""):`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
  </div>`;
}
/* match a Meet-the-Team card to a real team account so it can open the profile */
function userForProfileName(name){
  const nm=String(name||"").trim().toLowerCase();
  if(!nm) return null;
  return (S.users||[]).find(u=>String(u.display_name||u.username||"").trim().toLowerCase()===nm)||null;
}
function teamCard(p){
  const chips=x=>String(x||"").split(/[·,;\/|]+/).map(v=>v.trim()).filter(Boolean)
    .map(v=>`<span class="tchip">${esc(v)}</span>`).join("");
  const linked=userForProfileName(p.name);
  return `<div class="card team-card${linked?" tappable":""}" ${linked?`data-uview="${esc(linked.username)}"`:""}>
    <div class="tc-photo">${p.photo?`<img src="${esc(p.photo)}" alt="" loading="lazy">`:`<div class="tc-mono serif">${esc((p.name||"?").trim().charAt(0).toUpperCase())}</div>`}</div>
    <div class="tc-body">
      <h4 class="serif">${esc(p.name)}</h4>
      <p class="tc-pos">${esc(p.position||"")}</p>
      <p class="mini">${esc(p.nationality||"")}${p.nationality&&p.languages?" · ":""}${esc(p.languages||"")}</p>
      ${p.skills?`<div class="tc-chips">${chips(p.skills)}</div>`:""}
      ${p.instagram?`<a class="btn sm ghost social-a" href="${esc(p.instagram)}" target="_blank" rel="noopener">${brandIc("Instagram")} Instagram</a>`:""}
    </div>
  </div>`;
}
function guestTicketsView(){
  return `<div class="screen fadein">
    ${topBar(t("tickets"),"")}
    <p class="mini" style="margin:-6px 0 16px">${t("payNote")}</p>
    ${S.tickets.length?S.tickets.map(tk=>{
      const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
      const soldOut=left!==null&&left<=0;
      return `<div class="tk">
        <img src="${esc(tk.image||IMG.show)}" alt="" loading="lazy">
        <div class="bd">
          <h4>${esc(tk.name)}</h4>
          <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}${left!==null?` · ${left} ${t("seatsLeft")}`:""}</p>
          <p class="desc">${esc(tk.desc)}</p>
          <div class="rowend">
            <span class="price">${esc(tk.price||"")}</span>
            ${soldOut?`<span class="chip full">${t("soldOut")}</span>`:`<button class="btn sm" data-buy="${tk.id}">${t("buyTicket")}</button>`}
          </div>
        </div>
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
  </div>`;
}
function reviewBlock(){
  const st=S.settings;
  const links=[["Tripadvisor",st.tripadvisor],["Google",st.google],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("reviews")}</h3>
    <p class="mini" style="margin:4px 0 12px">${t("reviewsSub")}</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${links.map(([n,u])=>`<a class="btn sm ghost" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${ic("star",14)} ${n}</a>`).join("")}
    </div></div>`;
}
function socialBlock(){
  const st=S.settings;
  const links=[["Instagram",st.instagram],["TikTok",st.tiktok],["Facebook",st.facebook],["YouTube",st.youtube]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("followUs")}</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      ${links.map(([n,u])=>`<a class="btn sm ghost social-a" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${brandIc(n)} ${n}</a>`).join("")}
    </div></div>`;
}

/* ---------------- staff ---------------- */
function staffView(){
  const todayIdx=todayIndex();
  // My Work Day is the entertainer's home screen
  const STAFF_TABS=["workday","mypage","quiz","gallery","weather","bus","today","week","bookings","tasks","chat","feedback","teaminfo"];
  if(!S.tab || (!STAFF_TABS.includes(S.tab) && !String(S.tab).startsWith("cp:") && !String(S.tab).startsWith("emp:"))) S.tab="workday";
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="workday") return myWorkDayView();
  if(S.tab==="mypage") return myPageView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="bus") return busView();
  if(S.tab==="today"){
    const acts=S.activities.filter(a=>a.day===todayIdx);
    const hl=acts.find(a=>a.highlight);
    const mine=acts.filter(a=>canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">
      ${topBar(t("schedule"),t("days")[todayIdx]+" · "+S.session.name)}
      ${heroCard(hl)}
      ${statusLegend()}
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${listByCat(acts.filter(a=>a!==hl),{staff:true,showBook:false,showFav:false})}</div>
    </div>`;
  }
  if(S.tab==="week") return browseView(t("program"));
  if(S.tab==="tasks"){
    const me=S.session.username;
    const mine=S.tasks.filter(x=>!x.assigned_to || x.assigned_to===me);
    const rk=rankingRows();
    return `<div class="screen fadein">
      ${topBar(t("myTasks"),S.session.name)}
      ${rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("rank")}</h3><div class="card">
        ${rk.map((r,i)=>`<div class="booking-line"><span>${rankBadge(i)} ${esc(r.u.display_name||r.u.username)}${r.u.username===me?" ✦":""}</span><span class="pill">${r.points} ${t("points")}</span></div>`).join("")}
      </div></div>`:""}
      ${mine.length?`<div class="card">${mine.map(x=>taskLine(x,false)).join("")}</div>`:`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`}
      ${myActsCard()}
    </div>`;
  }
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chatManager"),S.session.name)}
      ${threadView("staff:"+S.session.username,"guest")}
    </div>`;
  }
  if(S.tab==="feedback") return staffFeedbackView();
  if(S.tab==="teaminfo") return teamInfoView();
  return bookingsView(t("guestsBooked"));
}
function taskStatusChip(x,clickAttr){
  const map={open:[t("statusNew"),"res"],accepted:[t("accepted"),"res"],still:[t("still"),"res"],done:[x.was_still?t("done")+" · "+t("late"):t("done"),"ok"],cant:[t("cantDo"),"full"]};
  const [lb,cls]=map[x.status]||map.open;
  return `<${clickAttr?"button":"span"} class="chip ${cls}" ${clickAttr?clickAttr+'="'+x.id+'"':""}>${lb}</${clickAttr?"button":"span"}>`;
}
/* ================= TASK MANAGEMENT =================
   Flow: New → Accepted → In progress → Completed → Verified.
   Old statuses (open/accepted/still/done) still work. */
const TASK_FLOW=["new","accepted","progress","completed","verified"];
const PRIORITIES=[["low","prLow"],["normal","prNormal"],["high","prHigh"],["urgent","prUrgent"]];
function taskStatus(x){
  const st=String(x.status||"new");
  if(st==="open") return "new";
  if(st==="still") return "progress";
  if(st==="done") return "completed";
  return TASK_FLOW.includes(st)?st:"new";
}
function taskStatusLabel(st){
  return {new:t("stNew"),accepted:t("stAccepted"),progress:t("stProgress"),
    completed:t("stCompleted"),verified:t("stVerified")}[st]||st;
}
function taskPriorityLabel(p){ const f=PRIORITIES.find(x=>x[0]===p); return f?t(f[1]):t("prNormal"); }
function taskIsOverdue(x){
  const st=taskStatus(x);
  if(st==="completed"||st==="verified") return false;
  if(!x.due) return false;
  const d=new Date(String(x.due).replace(" ","T"));
  return !isNaN(d.getTime()) && d.getTime() < Date.now();
}
function taskNextStatus(st){
  const i=TASK_FLOW.indexOf(st);
  return (i<0||i>=TASK_FLOW.length-1)?null:TASK_FLOW[i+1];
}
function taskActionLabel(st){
  return {new:t("acceptTask"),accepted:t("startTask"),progress:t("completeTask"),
    completed:t("verifyTask")}[st]||"";
}
function taskHistory(x){ try{ return Array.isArray(x.history)?x.history:JSON.parse(x.history||"[]"); }catch(e){ return []; } }
function taskComments(x){ try{ return Array.isArray(x.comments)?x.comments:JSON.parse(x.comments||"[]"); }catch(e){ return []; } }
async function advanceTask(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const cur=taskStatus(x), next=taskNextStatus(cur);
  if(!next) return;
  const stamp=new Date().toISOString();
  const patch={status:next};
  if(next==="accepted")  patch.accepted_at=stamp;
  if(next==="progress")  patch.started_at=stamp;
  if(next==="completed") patch.completed_at=stamp;
  if(next==="verified")  patch.verified_at=stamp;
  patch.history=taskHistory(x).concat([{at:stamp, by:S.session.name||S.session.username||"", to:next}]);
  try{ await DB.updateTask(id,patch); toastOk(t("saved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
async function addTaskComment(id, text){
  const x=S.tasks.find(y=>y.id==id); if(!x||!text) return;
  const c={at:new Date().toISOString(), by:S.session.name||S.session.username||"", text};
  try{ await DB.updateTask(id,{comments:taskComments(x).concat([c])}); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* Full task detail — everything about one task in one place */
function openTaskModal(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const st=taskStatus(x), over=taskIsOverdue(x);
  const u=S.users.find(u=>u.username===x.assigned_to);
  const hist=taskHistory(x), cmts=taskComments(x);
  const isMgr=S.session.role==="manager";
  const canAdvance = isMgr || (x.assigned_to===S.session.username) || !x.assigned_to;
  const next=taskNextStatus(st);
  const wrap=baseModal(`
    <h3>${ic(TASK_ICON[x.type]||"check",20)} ${esc(x.title)}</h3>
    <div class="tk-badges">
      <span class="tk-st s-${st}">${taskStatusLabel(st)}</span>
      <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
      ${over?`<span class="tk-over">${t("overdue")}</span>`:""}
    </div>
    ${x.desc?`<p class="mini" style="margin-top:8px">${esc(x.desc)}</p>`:""}
    <div class="tk-meta">
      ${x.assigned_to?`<span>${mi("user")}${esc((u&&u.display_name)||x.assigned_to)}</span>`:`<span>${mi("users")}${t("allTeam")}</span>`}
      ${x.location?`<span>${mi("pin")}${esc(x.location)}</span>`:""}
      ${x.due?`<span>${mi("clock")}${esc(String(x.due).replace("T"," "))}</span>`:""}
      ${x.created_by?`<span>${mi("pen")}${t("createdBy")}: ${esc(x.created_by)}</span>`:""}
    </div>
    ${x.proof_url?`<img class="tk-proof" src="${esc(x.proof_url)}" alt="">`:""}
    ${(st==="progress"||st==="completed")&&canAdvance?`
      <div class="photo-pick" style="margin-top:12px"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("taskProof")}</b><span class="mini">${t("uploadPhoto")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>`:""}
    ${next&&canAdvance?`<button class="btn" id="tk-next">${taskActionLabel(st)}</button>`:""}
    <label style="margin-top:12px">${t("taskComments")}</label>
    ${cmts.length?`<div class="card tk-cmts">${cmts.map(cm=>`<div class="tk-cm">
      <b>${esc(cm.by)}</b><span>${esc(cm.text)}</span><span class="mini">${fmtDate(cm.at)}</span></div>`).join("")}</div>`:""}
    <div class="time-row"><input id="tk-cm" placeholder="${esc(t("addComment"))}">
      <button class="btn sm" id="tk-cmadd" type="button">${ic("send",14)}</button></div>
    ${hist.length?`<label style="margin-top:12px">${t("taskHistory")}</label>
      <div class="card tk-hist">${hist.map(h=>`<div class="tk-h">
        <span>${taskStatusLabel(h.to)}</span><span class="mini">${esc(h.by)} · ${fmtDate(h.at)}</span></div>`).join("")}</div>`:""}
    <button class="btn ghost" id="tk-x" style="margin-top:12px">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  let proof=x.proof_url||"";
  wirePhotoPicker(wrap, ()=>proof, async v=>{
    proof=v; try{ await DB.updateTask(x.id,{proof_url:v}); }catch(e){}
  });
  const nx=wrap.querySelector("#tk-next");
  if(nx) nx.onclick=async ()=>{ wrap.remove(); await advanceTask(x.id); };
  const ca=wrap.querySelector("#tk-cmadd");
  if(ca) ca.onclick=async ()=>{
    const el=wrap.querySelector("#tk-cm"); const v=el?el.value.trim():"";
    if(!v) return; wrap.remove(); await addTaskComment(x.id, v);
  };
}
function taskLine(x,managerMode){
  const u=S.users.find(u=>u.username===x.assigned_to);
  const assignee = x.assigned_to ? ((u&&u.display_name)||x.assigned_to) : t("allTeam");
  const due=x.due?String(x.due).replace("T"," "):"";
  const info=`<span style="min-width:0">${ic(TASK_ICON[x.type]||"check",15)} <b>${esc(x.title)}</b>
    <br><span class="mini">${taskTypeLabel(x.type)}${x.location?` · ${mi("pin")}${esc(x.location)}`:""}</span>
    ${x.desc?`<br><span class="mini">${esc(x.desc)}</span>`:""}
    ${due?`<br><span class="mini">${mi("clock")}${esc(due)}</span>`:""}
    ${managerMode?`<br><span class="mini">${mi("user")}${esc(assignee)}</span>`:""}</span>`;
  const st2=taskStatus(x), over2=taskIsOverdue(x);
  const badges=`<br><span class="tk-inline">
    <span class="tk-st s-${st2}">${taskStatusLabel(st2)}</span>
    <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
    ${over2?`<span class="tk-over">${t("overdue")}</span>`:""}</span>`;
  if(managerMode){
    return `<div class="booking-line ${over2?"row-over":""}">${info.replace("</span>", badges+"</span>")}
      <span style="display:flex;gap:6px;align-items:center;flex:none">
        <button class="btn sm ghost" data-taskopen="${x.id}">${ic("pen",14)}</button>
        ${taskStatusChip(x,"data-taskdone")}
        <button class="btn sm warn" data-taskdel="${x.id}">${ic("close",14)}</button>
      </span></div>`;
  }
  let actions="";
  if(x.status==="open") actions=`<button class="btn sm" data-taccept="${x.id}">${t("accept")}</button>`;
  else if(x.status==="accepted"||x.status==="still"){
    actions=`<button class="btn sm" data-tsdone="${x.id}">${t("done")}</button>
      ${x.status==="accepted"?`<button class="btn sm ghost" data-tstill="${x.id}">${t("still")}</button>`:""}
      <button class="btn sm warn" data-tcant="${x.id}">${t("cantDo")}</button>`;
  } else actions=taskStatusChip(x,null);
  return `<div class="booking-line">${info}
    <span style="display:flex;gap:6px;align-items:center;flex:none;flex-wrap:wrap;justify-content:flex-end;max-width:46%">${actions}</span></div>`;
}
function myActsCard(){
  const mine=S.activities.filter(a=>canSeeGuests(a));
  if(!mine.length) return "";
  const byDay={};
  mine.forEach(a=>{ (byDay[a.day]=byDay[a.day]||[]).push(a); });
  const order=Object.keys(byDay).map(Number).sort((a,b)=>a-b);
  return `<div class="sec"><h3>${ic("calendar",18)} ${t("myActs")}</h3>
    <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
    <div class="card">${order.map(d=>`
      <div class="booking-line"><span style="min-width:0"><b>${t("daysShort")[d]}</b>
        ${byDay[d].sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>`<br><span class="mini">${mi("clock")}${esc(a.time)} · ${esc(a.name)}</span>`).join("")}
      </span></div>`).join("")}</div>
  </div>`;
}
function busMinutes(tm){
  const m=String(tm||"").match(/(\d{1,2})[:.\s](\d{2})/);
  return m?(+m[1])*60+(+m[2]):-1;
}
/* next upcoming bus (today) among a list of bus rows */
function nextBusId(list){
  const now=new Date(); const cur=now.getHours()*60+now.getMinutes();
  let best=null, bestMin=Infinity;
  list.forEach(b=>{ const mins=busMinutes(b.time); if(mins>=cur && mins<bestMin){ bestMin=mins; best=b.id; } });
  return best;
}
function busColumn(dir, iconRot){
  const list=(S.buses||[]).filter(b=>b.direction===dir)
    .sort((a,b)=>busMinutes(a.time)-busMinutes(b.time));
  const nxt=nextBusId(list);
  const isManager=S.session.role==="manager";
  return `<div class="bus-col">
    <div class="bus-col-head"><span class="bus-ic" style="transform:scaleX(${iconRot})">${ic("bus",20)}</span>
      <b>${t(dir==="toHotel"?"busToHotel":"busToHouse")}</b></div>
    ${list.length?`<div class="bus-rows">${list.map(b=>{
      const isNext=b.id===nxt;
      return `<div class="bus-row ${isNext?"next":""}" ${isManager?`data-busedit="${b.id}"`:""}>
        <span class="bus-time">${esc(b.time)}</span>
        <span class="bus-mid">${b.note?`<span class="bus-note">${esc(b.note)}</span>`:""}${isNext?`<span class="bus-next">${t("busNextHint")}</span>`:""}</span>
        ${isManager?`<span class="bus-go">${ic("pen",15)}</span>`:""}
      </div>`;
    }).join("")}</div>`:`<p class="mini bus-empty">—</p>`}
    ${isManager?`<button class="btn sm ghost bus-add" data-busadd="${dir}">${ic("plus",15)} ${t("addBus")}</button>`:""}
  </div>`;
}
/* ================= EMPLOYEE PROFILE ================= */
/* profile pictures: the main photo first, then any extra ones */
function empPics(u){
  let extra=[];
  try{ extra=Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]"); }catch(e){ extra=[]; }
  return [u.photo].concat(extra).filter(Boolean);
}
function employeeRecord(u){
  const mk=currentAttMonth();
  const att=attTotals(u,mk);
  const myTasks=(S.tasks||[]).filter(x=>x.assigned_to===u.username);
  const doneT=myTasks.filter(x=>["completed","verified","done"].includes(String(x.status))).length;
  const lateT=myTasks.filter(x=>taskIsOverdue(x)).length;
  const acts=(S.activities||[]).filter(a=>String(a.entertainer||"").toLowerCase()===String(u.username||"").toLowerCase());
  const fb=(S.feedback||[]).filter(f=>String(f.by_user||"")===u.username);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  const points=doneT*10 - lateT*5 + Math.round(avg*4);
  return {u, att, myTasks, doneT, lateT, acts, fb, avg, points,
    onTime: myTasks.length?Math.round((myTasks.length-lateT)/myTasks.length*100):100};
}
function employeeRank(u){
  const rows=(S.users||[]).filter(x=>x.role==="staff").map(x=>employeeRecord(x))
    .sort((a,b)=>b.points-a.points);
  const i=rows.findIndex(r=>r.u.username===u.username);
  return {pos:i+1, total:rows.length};
}
function employeeView(username){
  const u=(S.users||[]).find(x=>x.username===username);
  if(!u) return `<div class="screen fadein">${topBar(t("employeeProfile"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=employeeRecord(u), rank=employeeRank(u);
  const isMgr=S.session.role==="manager";
  const isSelf=S.session.role==="staff" && S.session.username===u.username;
  const full=isMgr||isSelf;                 // guests see the public part only
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  const line=(lb,v)=>v?`<div class="ep-row"><span class="mini">${lb}</span><b>${esc(v)}</b></div>`:"";
  return `<div class="screen fadein">
    ${topBar(esc(u.display_name||u.username), u.number?("#"+u.number):"")}
    <button class="crumb" id="crumb-team">${ic("back",15)} ${isMgr?t("teamAccounts"):t("teamPage")}</button>
    <div class="card g3-head">
      <div class="g3-av${u.photo?" haspic":""}" ${u.photo?`data-pv="emp|0"`:""}>${u.photo?`<img src="${esc(u.photo)}" alt="">`:esc(String(u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${esc(u.position||roleForNumber(u.number||0))}${u.number?" · #"+u.number:""}</span>
        <span class="mini">${u.active===false?t("inactiveAcc"):t("activeAcc")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span>
      </div>
    </div>
    ${full?`<div class="g3-stats">
      ${stat(r.att.P, t("workDays"))}
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.doneT, t("tasksDone"))}
      ${stat(r.onTime+"%", t("onTime"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
      ${stat(r.points, t("pointsLbl"))}
      ${stat(rank.pos?("#"+rank.pos):"—", t("rankLbl"))}
      ${stat(r.att.A, t("attTotalsA"))}
    </div>`:`<div class="g3-stats">
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
    </div>`}
    ${empPics(u).length?`<div class="sec">${photoStrip(empPics(u),"emp")}</div>`:""}
    <div class="sec"><h3>${ic("user",17)} ${t("employeeProfile")}</h3>
      <div class="card ep-card">
        ${full?line(t("employeeId"), u.employee_id):""}
        ${line(t("positionLbl2"), u.position)}
        ${full?line(t("user"), u.username):""}
        ${full?line(t("phoneLbl2"), u.phone):""}
        ${full?line(t("whatsappLbl2"), u.whatsapp):""}
        ${line(t("instagramLbl2"), u.instagram)}
        ${line(t("languagesLbl"), u.languages)}
        ${line(t("skills"), u.skills)}
        ${full?line(t("hireDate"), u.hire_date):""}
        ${line(t("nationality"), u.nationality)}
      </div>
    </div>
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("assignedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}${a.location?" · "+esc(a.location):""}</span></div>`).join("")}</div></div>`:""}
    ${full&&r.myTasks.length?`<div class="sec"><h3>${ic("check",17)} ${t("tasks")}</h3>
      <div class="card">${r.myTasks.slice(0,8).map(x=>`<div class="g3-row" data-taskopen="${x.id}">
        <b>${esc(x.title)}</b><span class="mini">${taskStatusLabel(taskStatus(x))}${taskIsOverdue(x)?" · "+t("overdue"):""}</span></div>`).join("")}</div></div>`:""}
    ${isMgr?`<div class="sec">
      <button class="btn" data-uedit="${u.id}">${ic("pen",16)} ${t("editUser")}</button>
      <button class="btn ghost" data-ususpend="${u.id}">${ic(u.active===false?"bell":"belloff",16)} ${u.active===false?t("activate"):t("suspend")}</button>
    </div>`
    :`<div class="sec">
      <p class="mini" style="margin-bottom:8px">${t("profileReadOnly")}</p>
      ${S.session.role==="staff"&&S.session.username===u.username
        ? `<button class="btn ghost" id="prof-req">${ic("chat",15)} ${t("requestChange")}</button>` : ""}
    </div>`}
  </div>`;
}
/* ================= GUEST CRM (360° profile) ================= */
/* How the guest's holiday is going: which day they are on and what is left. */
function stayProgress(acc){
  if(!acc || !acc.arrival || !acc.departure) return null;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  if(isNaN(a)||isNaN(d)) return null;
  const now=hotelNow(); now.setHours(0,0,0,0);
  const total=Math.max(1, Math.round((d-a)/864e5));
  const done=Math.max(0, Math.min(total, Math.round((now-a)/864e5)));
  const left=Math.max(0, total-done);
  const dayNo=Math.max(1, Math.min(total+1, done+1));
  return {total, done, left, dayNo, arrival:acc.arrival, departure:acc.departure,
          pct: Math.round((done/total)*100), lastDay:left===0, firstDay:done===0};
}
function stayCard(acc){
  const p=stayProgress(acc);
  if(!p) return "";
  const fmt=x=>{ const d=new Date(x+"T12:00:00");
    return isNaN(d)?x:d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"}); };
  const headline = p.lastDay ? t("stayLastDay")
    : p.firstDay ? t("stayWelcome")
    : t("stayDayOf").replace("{n}", p.dayNo).replace("{t}", p.total);
  return `<div class="card staycard">
    <div class="sc-top">
      <span class="sc-day"><b>${p.dayNo}</b><span class="mini">${t("dayWord")}</span></span>
      <span class="sc-mid"><b>${esc(headline)}</b>
        <span class="mini">${fmt(p.arrival)} → ${fmt(p.departure)} · ${p.total} ${t("nightsWord")}</span></span>
    </div>
    <div class="sc-bar"><span style="width:${Math.max(3,Math.min(100,p.pct))}%"></span></div>
    <div class="sc-foot">
      <span>${p.left} ${t("nightsLeft")}</span>
      <span>${p.done}/${p.total}</span>
    </div>
  </div>`;
}
function guestStayNights(acc){
  if(!acc||!acc.arrival||!acc.departure) return 0;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  const n=Math.round((d-a)/864e5);
  return isNaN(n)?0:Math.max(0,n);
}
function guestDaysInApp(acc){
  if(!acc||!acc.created_at) return 0;
  return Math.max(1, Math.round((Date.now()-new Date(acc.created_at).getTime())/864e5));
}
function guestRecord(acc){
  const room=String(acc.room);
  const bookings=(S.bookings||[]).filter(b=>String(b.room)===room);
  const actIds=bookings.map(b=>b.activity_id);
  const acts=(S.activities||[]).filter(a=>actIds.includes(a.id));
  const orders=(S.orders||[]).filter(o=>String(o.room)===room);
  const reqs=(S.requests||[]).filter(r=>String(r.room)===room);
  const fb=(S.feedback||[]).filter(f=>String(f.room)===room);
  const msgs=(S.messages||[]).filter(m=>String(m.room)===room);
  const quiz=(S.quizReplies||[]).filter(q=>String(q.who)===room);
  // favourites = the categories they book most
  const byCat={};
  acts.forEach(a=>{ const k=catLabel(normCat(a)); byCat[k]=(byCat[k]||0)+1; });
  const favs=Object.keys(byCat).sort((x,y)=>byCat[y]-byCat[x]).slice(0,3);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  return {acc, bookings, acts, orders, reqs, fb, msgs, quiz, favs, avg,
    nights:guestStayNights(acc), daysApp:guestDaysInApp(acc)};
}
function guestCrmInner(){
  let list=(S.accounts||[]).filter(a=>a.active!==false && !stayExpired(a));
  list.sort((a,b)=>String(a.room).localeCompare(String(b.room),undefined,{numeric:true}));
  return `<input id="crm-q" enterkeyhint="done" autocomplete="off" autocorrect="off" placeholder="${esc(t("crmSearch"))}" value="${esc(S.crmQuery||"")}" style="margin-bottom:12px">
    ${list.length?`<div class="card" id="crm-results">${list.map(a=>{
      const r=guestRecord(a);
      const searchText=[a.room,a.name,a.nationality].map(v=>String(v||"").toLowerCase()).join(" ");
      return `<div class="crm-row" data-crm="${a.id}" data-crm-search="${esc(searchText)}">
        <div class="crm-av">${esc(String(a.name||"?").trim().charAt(0).toUpperCase())}</div>
        <div class="crm-mid"><b>${esc(a.name||"")}</b>
          <span class="mini">${t("room")} ${esc(a.room)}${a.nationality?" · "+esc(a.nationality):""}</span>
          <span class="mini">${r.bookings.length} ${t("bookings").toLowerCase()} · ${r.reqs.length} ${t("requests").toLowerCase()}${r.fb.length?" · ★ "+r.avg:""}</span>
        </div>
        <span class="crm-go">${ic("back",15)}</span>
      </div>`;
    }).join("")}</div><div class="empty" id="crm-search-empty" style="display:none"><div class="big">${ic("users",30)}</div>No matching guests</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("noGuests")}</div>`}`;
}
function guest360View(id){
  const acc=(S.accounts||[]).find(a=>a.id==id);
  if(!acc) return `<div class="screen fadein">${topBar(t("guest360"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=guestRecord(acc);
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  return `<div class="screen fadein">
    ${topBar(esc(acc.name||""), t("room")+" "+esc(acc.room))}
    <button class="crumb" id="crumb-crm">${ic("back",15)} ${t("guestCrm")}</button>
    <div class="card g3-head">
      <div class="g3-av">${esc(String(acc.name||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(acc.name||"")}</b>
        <span class="mini">${esc(acc.nationality||"")}${acc.phone?" · "+esc(acc.phone):""}</span>
        <span class="mini">${esc(acc.arrival||"")} → ${esc(acc.departure||"")} · ${r.nights} ${t("nights")}</span>
      </div>
    </div>
    <div class="g3-stats">
      ${stat(r.bookings.length, t("bookings"))}
      ${stat(r.acts.length, t("attendedActs"))}
      ${stat(r.orders.length, t("tickets"))}
      ${stat(r.reqs.length, t("requests"))}
      ${stat(r.msgs.length, t("msgCount"))}
      ${stat(r.quiz.length, t("quizPart"))}
      ${stat(r.daysApp, t("appUsage"))}
      ${stat(r.fb.length?r.avg:"—", t("feedback"))}
    </div>
    ${r.favs.length?`<div class="sec"><h3>${ic("star",17)} ${t("favActs")}</h3>
      <div class="card"><div class="g3-tags">${r.favs.map(f=>`<span class="ts-chip">${esc(f)}</span>`).join("")}</div></div></div>`:""}
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("attendedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.reqs.length?`<div class="sec"><h3>${ic("chat",17)} ${t("requests")}</h3>
      <div class="card">${r.reqs.map(x=>`<div class="g3-row"><b>${esc(x.type||"")}</b>
        <span class="mini">${esc(x.detail||"")} · ${esc(x.status||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.fb.length?`<div class="sec"><h3>${ic("star",17)} ${t("feedback")}</h3>
      <div class="card">${r.fb.map(f=>`<div class="g3-row"><b>${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</b>
        <span class="mini">${esc(f.comment||"")} · ${fmtDate(f.created_at)}</span></div>`).join("")}</div></div>`:""}
  </div>`;
}
/* ================= AUTOMATIC ACTIVITY ROSTER =================
   Rules (agreed with the manager):
   - every entertainer gets ONE morning and ONE afternoon activity
   - EVENTS are joined by the whole team, so they are never assigned to one person
   - the MANAGER (#1) and the DJ (#3) never get activities
   - anyone on their day off is skipped
   - it is FAIR: whoever has done the least so far goes first, and the
     starting point rotates each day so it is never the same person. */
/* #2 social media (films) and #3 the DJ (music) — events and shows only, never
   the normal activity rota. #1 is the manager. */
/* Attendance-only people: numbers 11–50. They exist so their days can be
   recorded and nothing else — no login, no activities, not on the day plan,
   not counted in the team. */
const ATT_ONLY_MIN=11, ATT_ONLY_MAX=50;
function isAttOnly(u){ return !!u && u.role==="attendance"; }
function nextAttNumber(){
  const taken=new Set((S.users||[]).map(u=>+u.number).filter(Boolean));
  for(let n=ATT_ONLY_MIN;n<=ATT_ONLY_MAX;n++) if(!taken.has(n)) return n;
  return null;
}
const DJ_NUMBER=3;
const EVENTS_ONLY_NUMBERS=[DJ_NUMBER];
const NO_ACTIVITY_NUMBERS=[1,2,3];          // manager, social media and DJ never enter the normal activity rota
/* Shows, parties and events belong to the DJ. Entertainers only receive normal activities. */
function eventsCrew(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && +u.number===DJ_NUMBER && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
function isEventsOnly(u){ return !!u && +u.number===DJ_NUMBER; }
function assignableStaff(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && u.number && !NO_ACTIVITY_NUMBERS.includes(+u.number)
      && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
/* Hotel operation windows — one source of truth across rota, Whole Day and exports.
   Morning 10:00–12:30 · Afternoon 15:00–17:30 · Evening 19:30–23:00. */
function operationSlotFromMinutes(m){
  if(m==null || !Number.isFinite(+m)) return "other";
  m=+m;
  if(m>=10*60 && m<12*60+30) return "morning";
  if(m>=15*60 && m<17*60+30) return "afternoon";
  if(m>=19*60+30 && m<=23*60) return "evening";
  return "other";
}
/* Only mAdult enters the entertainer activity rota. Other programme categories remain event/show/party operations. */
function activitySlot(a){
  const c=normCat(a);
  if(c!=="mAdult") return "event";
  const w=actWindow(a);
  if(!w) return "other";
  return operationSlotFromMinutes(w.s0);
}
/* What each person ALREADY has that we are not going to touch.
   When she replaces everything, nothing is kept, so everyone starts at zero. */
function baseLoad(opts){
  const o=opts||{};
  const load={c:{}, last:{}, tick:0};
  (S.activities||[]).forEach(a=>{
    const slot=activitySlot(a);
    if(slot!=="morning" && slot!=="afternoon") return;
    const who=String(a.entertainer||"").trim().toLowerCase();
    if(!who) return;
    if(o.onlyEmpty) load.c[who]=(load.c[who]||0)+1;   // this one stays, so it counts
  });
  return load;
}
function baseCounts(opts){ return baseLoad(opts).c; }
function loadKey(u){ return String(u.username).toLowerCase(); }
function loadOf(load,u){ return (load.c&&load.c[loadKey(u)])||0; }
function bumpLoad(load,u,act,day){
  const k=loadKey(u);
  load.c[k]=(load.c[k]||0)+1;
  load.last[k]=++load.tick;                    // remember when they last got one
  if(act && act.name){                         // and which activity, so it is not repeated
    load.acts=load.acts||{};
    const ak=k+"|"+actKey(act.name);
    load.acts[ak]=(load.acts[ak]||0)+1;
    load.days=load.days||{};
    load.days[ak]=load.days[ak]||[];
    if(typeof day==="number") load.days[ak].push(day);
  }
}
/* Picks whoever has the FEWEST activities; if several are equal, the one who
   has waited longest. That keeps everybody within one of each other. */
/* Who already has this same activity on the other days of the week?
   Yesterday counts hardest, then anywhere else in the week. */
/* how far apart two weekdays are, going the short way round the week */
function dayGap(a,b){ const d=Math.abs(a-b)%7; return Math.min(d, 7-d); }
function repeatPenalty(u, act, day, load){
  if(!act || !act.name) return 0;
  /* what this run has already given them counts as much as what is saved */
  let planned=0, plannedYesterday=false;
  if(load && load.acts){
    const ak=loadKey(u)+"|"+actKey(act.name);
    planned=load.acts[ak]||0;
    plannedYesterday=((load.days&&load.days[ak])||[]).some(d=>dayGap(d,day)<=1);
  }
  const key=actKey(act.name), me=String(u.username||"").toLowerCase();
  const mine=a=>String(a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
      .map(x=>x.trim()).some(x=>{
        if(!x) return false;
        if(x===me) return true;
        const disp=String(u.display_name||"").toLowerCase();
        return disp && x===disp;
      });
  const sameAct=(S.activities||[]).filter(a=>actKey(a.name)===key && a.day!==day && mine(a));
  const didYesterday=sameAct.some(a=>dayGap(a.day,day)<=1)
    || plannedYesterday
    || (((load&&load.days&&load.days[loadKey(u)+"|"+actKey(act.name)])||[]).some(d=>dayGap(d,day)<=1));
  const times=sameAct.length + planned;
  if(!times && !didYesterday) return 0;
  return (didYesterday?4:0) + times;               // repeated yesterday hurts most
}
function pickFairest(pool, load, usedThisSlot, act, day){
  /* fairness first: never the same activity twice for one person if it can be
     avoided, then an even share of the work, then whoever went longest ago */
  const score=u=>repeatPenalty(u,act,day,load)*1e9 + loadOf(load,u)*1e6 + (load.last[loadKey(u)]||0);
  /* only people who are allowed to run this activity */
  const allowed=act ? pool.filter(u=>canRunActivity(u,act) && !entranceConflict(u,day,act)) : pool;
  if(!allowed.length) return null;             // nobody may do it — leave it empty
  let best=null, bestScore=Infinity;
  allowed.forEach(u=>{
    if(usedThisSlot.has(u.username)) return;
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  if(best) return best;
  allowed.forEach(u=>{                         // more activities than people
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  return best;
}
/* One day. Pass a shared `load` so a whole week stays balanced across days. */
function autoAssignDay(day, opts, sharedLoad){
  const o=opts||{};
  const dateStr_=assignDateStr(day);
  const out=[];
  const load=sharedLoad || baseLoad(o);

  /* Every event/show/party is assigned to the DJ only, provided the DJ is actually working. */
  const crew=eventsCrew(day,dateStr_);
  const dj=crew[0]||null;
  (S.activities||[])
    .filter(a=>a.day===day && activitySlot(a)==="event")
    .filter(a=>o.onlyEmpty ? !String(a.entertainer||"").trim() : true)
    .forEach(a=>{
      if(!dj) return;
      out.push({activity:a, slot:"event", username:dj.username,
        name:dj.display_name||dj.username, day});
    });

  const pool=assignableStaff(day,dateStr_);
  if(!pool.length) return out;

  ["morning","afternoon"].forEach(slot=>{
    const acts=(S.activities||[])
      .filter(a=>a.day===day && activitySlot(a)===slot)
      .filter(a=>o.onlyEmpty ? !String(a.entertainer||"").trim() : true)
      .sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    if(!acts.length) return;
    const usedThisSlot=new Set();
    acts.forEach(a=>{
      const pick=pickFairest(pool, load, usedThisSlot, a, day);
      if(!pick) return;
      usedThisSlot.add(pick.username);
      bumpLoad(load,pick,a,day);
      out.push({activity:a, username:pick.username, name:pick.display_name||pick.username, slot, day});
    });
  });
  return out;
}
/* The whole week, sharing ONE running count so everybody ends up even. */
function autoAssignWeek(opts){
  const load=baseLoad(opts||{});
  let all=[];
  for(let d=0; d<7; d++) all=all.concat(autoAssignDay(d, opts, load));
  return fixRepeats(balancePlan(all, opts||{}));
}
/* Last tidy-up: if anyone still ends up with the same activity on two days next
   to each other, swap it with another activity on that same day. */
function fixRepeats(plan){
  const clash=(p, list)=>list.some(x=>x!==p
    && String(x.username).toLowerCase()===String(p.username).toLowerCase()
    && actKey(x.activity.name)===actKey(p.activity.name)
    && dayGap(x.activity.day, p.activity.day)<=1);
  for(let round=0; round<40; round++){
    const bad=plan.find(p=>p.slot!=="event" && clash(p, plan));
    if(!bad) break;
    const sameDay=plan.filter(x=>x!==bad && x.slot!=="event" && x.activity.day===bad.activity.day);
    let fixed=false;
    for(const other of sameDay){
      const u1=(S.users||[]).find(u=>u.username===bad.username);
      const u2=(S.users||[]).find(u=>u.username===other.username);
      if(!u1||!u2) continue;
      if(!canRunActivity(u1, other.activity) || !canRunActivity(u2, bad.activity)) continue;
      /* pretend the swap happened and check nobody is worse off */
      const trial=plan.map(x=> x===bad ? {...x, username:other.username, name:other.name}
                            : x===other ? {...x, username:bad.username, name:bad.name} : x);
      const a2=trial.find(x=>x.activity===bad.activity), b2=trial.find(x=>x.activity===other.activity);
      if(clash(a2,trial) || clash(b2,trial)) continue;
      plan=trial; fixed=true; break;
    }
    if(!fixed) break;                                  // cannot do better honestly
  }
  return plan;
}
/* Final tidy-up: if anyone is still more than one ahead, hand one of their
   activities to somebody who has fewer — but only if that person is actually
   working that day and does not already have that half of the day. */
function balancePlan(plan, opts){
  for(let guard=0; guard<300; guard++){
    const bal=planBalance(plan, opts);
    if(bal.spread<=1) break;
    const hi=Object.keys(bal.per).filter(k=>bal.per[k]===bal.max);
    const lo=Object.keys(bal.per).filter(k=>bal.per[k]===bal.min);
    let moved=false;
    for(const h of hi){
      for(const l of lo){
        for(let i=0;i<plan.length && !moved;i++){
          const it=plan[i];
          if(String(it.username).toLowerCase()!==h) continue;
          const day=it.activity.day;
          const cand=assignableStaff(day,assignDateStr(day)).find(u=>String(u.username).toLowerCase()===l);
          if(!cand) continue;                                   // not working that day
          if(!canRunActivity(cand, it.activity)) continue;       // they are not allowed to run it
          const clash=plan.some(x=>x!==it && x.activity.day===day && x.slot===it.slot
            && String(x.username).toLowerCase()===l);
          if(clash) continue;                                   // already has that half-day
          /* and never hand them the same activity on the day before or after */
          const nextTo=plan.some(x=>x!==it && String(x.username).toLowerCase()===l
            && actKey(x.activity.name)===actKey(it.activity.name)
            && dayGap(x.activity.day, day)<=1);      // same activity on a neighbouring day
          if(nextTo) continue;
          plan[i]={...it, username:cand.username, name:cand.display_name||cand.username};
          moved=true;
        }
        if(moved) break;
      }
      if(moved) break;
    }
    if(!moved) break;                                           // cannot improve further
  }
  return plan;
}
/* How even the result is — she sees this before applying. */
function planBalance(list, opts){
  const per={};
  const everyone=new Set();
  for(let d=0; d<7; d++) assignableStaff(d,assignDateStr(d)).forEach(u=>everyone.add(u.username));
  if((opts||{}).onlyEmpty){
    const b=baseCounts(opts);
    Object.keys(b).forEach(k=>{ per[k]=b[k]; });
  }
  everyone.forEach(u=>{ if(per[String(u).toLowerCase()]===undefined) per[String(u).toLowerCase()]=0; });
  list.forEach(x=>{ const k=String(x.username).toLowerCase(); per[k]=(per[k]||0)+1; });
  const vals=Object.values(per);
  return {per, min:vals.length?Math.min(...vals):0, max:vals.length?Math.max(...vals):0,
          spread:vals.length?Math.max(...vals)-Math.min(...vals):0};
}
async function applyAssignments(list){
  for(const it of list){
    try{ await DB.saveActivity({...it.activity, entertainer:it.username}); }
    catch(e){ toastErr(t("errSave")); return false; }
  }
  return true;
}
/* She sees the proposal, can change ANY name, and only then applies it. */
function openAutoAssignModal(day){
  let scope="day", onlyEmpty=true;
  let plan=[];
  const wrap=baseModal("");
  const rebuild=()=>{ plan=(scope==="day")?autoAssignDay(day,{onlyEmpty}):autoAssignWeek({onlyEmpty}); };
  rebuild();
  const draw=()=>{
    const bal=planBalance(plan,{onlyEmpty});
    const byDay={};
    plan.forEach(x=>{ (byDay[x.activity.day]=byDay[x.activity.day]||[]).push(x); });
    const nameOf=un=>{ const u=(S.users||[]).find(y=>y.username===un); return u?(u.display_name||u.username):un; };
    wrap.innerHTML=`<div class="modal">
      <h3>${ic("users",20)} ${t("autoAssign")}</h3>
      <p class="mini">${t("autoHint")}</p>
      <div class="bd-roles" style="margin-top:12px">
        <button class="bd-role ${scope==="day"?"on":""}" data-ascope="day">${t("autoDay")}</button>
        <button class="bd-role ${scope==="week"?"on":""}" data-ascope="week">${t("autoWeek")}</button>
      </div>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:14.5px;color:var(--ink);margin:10px 0">
        <input type="checkbox" id="a-empty" style="width:auto" ${onlyEmpty?"checked":""}> ${t("onlyEmptyLbl")}</label>
      ${plan.length?`
        <div class="aa-bal ${bal.spread<=1?"good":"warn"}">
          <b>${t("balanceLbl")}</b>
          <span>${bal.spread<=1?t("evenSpread"):(t("spreadOff")+" "+bal.spread)} · ${bal.min}–${bal.max} ${t("activityCount")}</span>
        </div>
        <p class="mini" style="margin:8px 0">${ic("pen",12)} ${t("editHint")}</p>
        <div class="card aa-list">
          ${Object.keys(byDay).sort((a,b)=>a-b).map(d=>{
            const pool=assignableStaff(+d,assignDateStr(+d));
            return `<div class="aa-day"><b>${esc(t("days")[+d]||"")}</b></div>
            ${byDay[d].map(x=>{
              const i=plan.indexOf(x);
              return `<div class="aa-row">
                <span class="aa-slot ${x.slot}">${x.slot==="morning"?t("morningSlot"):t("afternoonSlot")}</span>
                <span class="aa-mid"><b>${esc(x.activity.name)}</b><span class="mini">${esc(x.activity.time||"")}</span></span>
                <select class="aa-sel" data-aarow="${i}">
                  <option value="">${t("noneAssigned")}</option>
                  ${pool.map(u=>`<option value="${esc(u.username)}" ${u.username===x.username?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("")}
                </select>
              </div>`;
            }).join("")}`;
          }).join("")}
        </div>
        <label style="margin-top:10px">${t("perPerson")}</label>
        <div class="aa-per">${Object.keys(bal.per).sort((a,b)=>bal.per[b]-bal.per[a]).map(k=>
          `<span class="ts-chip ${bal.per[k]===bal.max&&bal.spread>1?"hot":""}">${esc(nameOf(k))} · ${bal.per[k]}</span>`).join("")}</div>
        <p class="mini" style="margin-top:10px">${ic("sparkle",13)} ${t("eventsAllTeam")}</p>
        <button class="btn ghost" id="a-recalc">${ic("back",15)} ${t("recalc")}</button>
        <button class="btn" id="a-go">${ic("check",16)} ${t("autoApply")}</button>`
      :`<div class="empty" style="margin-top:12px"><div class="big">${ic("users",28)}</div>${t("autoNothing")}</div>`}
      <button class="btn ghost" id="a-x">${t("close")}</button>
    </div>`;
    wrap.querySelectorAll("[data-ascope]").forEach(b=>b.onclick=()=>{ scope=b.dataset.ascope; rebuild(); draw(); });
    const ce=wrap.querySelector("#a-empty"); if(ce) ce.onchange=()=>{ onlyEmpty=ce.checked; rebuild(); draw(); };
    // change any single assignment by hand
    wrap.querySelectorAll("[data-aarow]").forEach(sel=>sel.onchange=()=>{
      const i=+sel.dataset.aarow;
      if(!plan[i]) return;
      if(!sel.value){ plan.splice(i,1); }
      else { plan[i]={...plan[i], username:sel.value,
        name:((S.users||[]).find(u=>u.username===sel.value)||{}).display_name||sel.value}; }
      draw();
    });
    const rc=wrap.querySelector("#a-recalc"); if(rc) rc.onclick=()=>{ rebuild(); draw(); };
    wrap.querySelector("#a-x").onclick=()=>wrap.remove();
    const go=wrap.querySelector("#a-go");
    if(go) go.onclick=async ()=>{
      go.disabled=true;
      const ok=await applyAssignments(plan);
      wrap.remove();
      if(ok){ toastOk(t("autoDone")); render(); }
    };
  };
  draw();
}
/* Manager sets what a person can and cannot do — this drives automatic assignment. */
/* When an entertainer leaves: keep every day they worked, take them out of
   today's plans, and free their number for whoever replaces them. */
/* Open one booking: change how many people, move to waiting list, or remove it. */
function accountForRoom(room){
  const r=String(room||"").trim();
  return (S.accounts||[]).find(a=>String(a.room).trim()===r) || null;
}
function openBookingEditor(id){
  const b=(S.bookings||[]).find(x=>x.id===id); if(!b) return;
  const act=(S.activities||[]).find(a=>a.id===b.activity_id)||{};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editBooking")}</h3>
    <p class="mini">${esc(act.name||"")}${act.time?" · "+esc(act.time):""}</p>
    <div class="card" style="margin:10px 0">
      <div class="bk-line"><span class="mini">${t("room")}</span><b>${esc(b.room)}</b></div>
      <div class="bk-line"><span class="mini">${t("name")}</span><b>${esc(b.guest_name||"")}</b></div>
      ${b.phone?`<div class="bk-line"><span class="mini">${t("phone")}</span><b>${esc(b.phone)}</b></div>`:""}
      ${b.nationality?`<div class="bk-line"><span class="mini">${t("nationality")}</span><b>${esc(b.nationality)}</b></div>`:""}
      ${b.created_at?`<div class="bk-line"><span class="mini">${t("bookedAt")}</span><b>${esc(whenLabel(b.created_at))}</b></div>`:""}
    </div>
    <label>${t("persons")}</label>
    <input id="bk-n" type="number" min="1" max="20" value="${(+b.adults||1)+(+b.children||0)}" inputmode="numeric">
    <label style="margin-top:10px">${t("status")}</label>
    <select id="bk-st">
      <option value="booked" ${b.status!=="waitlist"?"selected":""}>${t("booked")}</option>
      <option value="waitlist" ${b.status==="waitlist"?"selected":""}>${t("waitlist")}</option>
    </select>
    <button class="btn" id="bk-save">${t("save")}</button>
    <button class="btn ghost" id="bk-open">${ic("user",15)} ${t("openGuest")}</button>
    <button class="btn warn" id="bk-del">${ic("trash",15)} ${t("removeBooking")}</button>
    <button class="btn ghost" id="bk-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#bk-x").onclick=()=>wrap.remove();
  const acc=accountForRoom(b.room);
  const openBtn=wrap.querySelector("#bk-open");
  if(openBtn){
    if(acc) openBtn.onclick=()=>{ wrap.remove(); S.tab="g360:"+acc.id; render(); };
    else { openBtn.disabled=true; openBtn.textContent=t("noGuestAccount"); }
  }
  wrap.querySelector("#bk-save").onclick=async ()=>{
    const n=Math.max(1,+wrap.querySelector("#bk-n").value||1);
    const st=wrap.querySelector("#bk-st").value;
    await DB.updateBooking(b.id,{adults:n, children:0, status:st});
    wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#bk-del").onclick=async ()=>{
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(b.id); wrap.remove(); toastOk(t("saved")); render();
  };
}
/* Set someone on holiday from one date to another, instead of tapping day by day. */
/* A person who is only on the attendance sheet — a name and a number, nothing else. */
function openAttPersonModal(userId){
  const u=userId ? (S.users||[]).find(x=>x.id===userId && isAttOnly(x)) : null;
  const suggested=u ? u.number : nextAttNumber();
  const wrap=baseModal(`
    <h3>${ic(u?"pen":"plus",20)} ${u?esc(u.display_name||""):t("addAttOnly")}</h3>
    <p class="mini">${t("addAttOnlyHint")}</p>
    <label>${t("name")}</label>
    <input id="ao-name" type="text" autocomplete="off" value="${u?esc(u.display_name||""):""}">
    <label style="margin-top:10px">${t("attNumber")}</label>
    <input id="ao-num" type="number" min="${ATT_ONLY_MIN}" max="${ATT_ONLY_MAX}" value="${suggested||ATT_ONLY_MIN}" inputmode="numeric">
    <div class="row2" style="margin-top:10px">
      <div><label>${t("startedOn")}</label>
        <input id="ao-from" type="date" value="${u&&u.hire_date?esc(String(u.hire_date).slice(0,10)):hotelDateStr()}"></div>
      <div><label>${t("lastDayOpt")}</label>
        <input id="ao-to" type="date" value="${u&&u.left_date?esc(String(u.left_date).slice(0,10)):""}"></div>
    </div>
    <p class="mini">${t("attDatesHint")}</p>
    <p class="mini" id="ao-err" style="color:#BE3C3C;min-height:16px"></p>
    <button class="btn" id="ao-go">${t("save")}</button>
    ${u?`<button class="btn warn" id="ao-del">${ic("trash",15)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="ao-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#ao-x").onclick=()=>wrap.remove();
  const del=wrap.querySelector("#ao-del");
  if(del) del.onclick=async ()=>{
    if(!(await confirmAction({title:t("deleteQ"), body:t("attDeleteHint"), danger:true}))) return;
    await DB.deleteUser(u.id); wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#ao-go").onclick=async ()=>{
    const err=wrap.querySelector("#ao-err");
    const name=wrap.querySelector("#ao-name").value.trim();
    const num=+wrap.querySelector("#ao-num").value;
    const from=wrap.querySelector("#ao-from").value;
    const to=wrap.querySelector("#ao-to").value;
    if(!name){ err.textContent=t("nameNeeded"); return; }
    if(!(num>=ATT_ONLY_MIN && num<=ATT_ONLY_MAX)){ err.textContent=t("attNumRange"); return; }
    if((S.users||[]).some(x=>+x.number===num && (!u || x.id!==u.id))){ err.textContent=t("numberTaken"); return; }
    if(to && from && to<from){ err.textContent=t("checkDates"); return; }
    const patch={ display_name:name, number:num,
      hire_date:from||"", left_date:to||"", archived:!!to, active:!to };
    if(u){ await DB.updateUser(u.id, patch); }
    else {
      await DB.addUser({ username:"att"+num+"_"+Date.now().toString(36),
        password:"", role:"attendance", ...patch });
    }
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openVacationModal(username){
  const team=(S.users||[]).filter(u=>(u.role==="staff"||u.role==="manager"||isAttOnly(u)) && !hasLeft(u));
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("sun",20)} ${t("setVacation")}</h3>
    <p class="mini">${t("setVacationHint")}</p>
    <label>${t("person")}</label>
    <select id="vc-who">
      ${team.map(u=>`<option value="${esc(u.username)}" ${u.username===username?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("")}
    </select>
    <div class="row2" style="margin-top:10px">
      <div><label>${t("fromDate")}</label><input id="vc-from" type="date" value="${today}"></div>
      <div><label>${t("toDate")}</label><input id="vc-to" type="date" value="${today}"></div>
    </div>
    <p class="mini" id="vc-count" style="margin-top:8px"></p>
    <button class="btn" id="vc-go">${t("setVacation")}</button>
    <button class="btn ghost" id="vc-clear">${t("clearVacation")}</button>
    <button class="btn ghost" id="vc-x">${t("cancelBtn")}</button>`);
  const from=wrap.querySelector("#vc-from"), to=wrap.querySelector("#vc-to");
  const note=wrap.querySelector("#vc-count");
  const daysBetween=()=>{
    const a=from.value, b=to.value;
    if(!a||!b||b<a) return [];
    const out=[]; const d=new Date(a+"T12:00:00"), end=new Date(b+"T12:00:00");
    while(d<=end && out.length<200){ out.push(d.toISOString().slice(0,10)); d.setDate(d.getDate()+1); }
    return out;
  };
  const refresh=()=>{
    const n=daysBetween().length;
    note.textContent = n ? (n+" "+t("daysWord")) : t("checkDates");
  };
  from.onchange=()=>{ if(to.value<from.value) to.value=from.value; refresh(); };
  to.onchange=refresh; refresh();
  wrap.querySelector("#vc-x").onclick=()=>wrap.remove();
  const apply=async status=>{
    const who=wrap.querySelector("#vc-who").value;
    const days=daysBetween();
    if(!days.length){ toastErr(t("checkDates")); return; }
    for(const d of days){ await DB.setStaffAtt(who, d, status); }
    wrap.remove(); toastOk(days.length+" "+t("daysWord")); render();
  };
  wrap.querySelector("#vc-go").onclick=()=>apply("V");
  wrap.querySelector("#vc-clear").onclick=()=>apply(null);
}
function openLeaveModal(userId){
  const u=(S.users||[]).find(x=>x.id===userId); if(!u) return;
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("exit",20)} ${t("markLeft")}</h3>
    <p class="mini">${esc(u.display_name||u.username)} · ${t("markLeftHint")}</p>
    <label style="margin-top:10px">${t("leftDate")}</label>
    <input id="lv-date" type="date" value="${esc(u.left_date||today)}">
    <button class="btn" id="lv-go">${t("markLeft")}</button>
    ${hasLeft(u)?`<button class="btn ghost" id="lv-undo">${t("undoLeft")}</button>`:""}
    <button class="btn ghost" id="lv-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#lv-x").onclick=()=>wrap.remove();
  wrap.querySelector("#lv-go").onclick=async ()=>{
    const d=wrap.querySelector("#lv-date").value || today;
    await DB.updateUser(u.id,{left_date:d, archived:true, active:false, number:null});
    wrap.remove(); toastOk(t("saved")); render();
  };
  const un=wrap.querySelector("#lv-undo");
  if(un) un.onclick=async ()=>{
    await DB.updateUser(u.id,{left_date:"", archived:false, active:true});
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openSkillEditor(username){
  const u=(S.users||[]).find(x=>x.username===username); if(!u) return;
  if(S.session.role!=="manager"){ toast(t("profileReadOnly")); return; }
  if(u.role==="manager") return; // manager is never part of the activity skill matrix
  let can=canDoList(u), cant=cannotDoList(u);
  const wrap=baseModal(`
    <h3>${esc(u.display_name||u.username)}</h3>
    <p class="mini">${t("skillEditHint2")}</p>
    <div id="sk-box"></div>
    <button class="btn" id="sk-go">${t("save")}</button>
    <button class="btn ghost" id="sk-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#sk-box");
  if(isEventsOnly(u)){
    box.innerHTML=`<p class="mini">${t("eventsCrewHint")}</p>`;
    const go=wrap.querySelector("#sk-go"); if(go) go.style.display="none";
    return;
  }
  const list=programActivities();
  const paint=()=>{
    if(!list.length){ box.innerHTML=`<p class="mini">${t("noActsYet")}</p>`; return; }
    box.innerHTML=list.map(([k,label])=>{
      const st=cant.includes(k)?"cant":(can.includes(k)?"can":"none");
      return `<button class="sk-btn ${st}" data-sk="${esc(k)}">
        <span>${esc(label)}</span>
        <span class="sk-tag">${st==="can"?t("skCan"):st==="cant"?t("skCant"):t("skAny")}</span>
      </button>`;}).join("");
    box.querySelectorAll("[data-sk]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.sk;
      if(can.includes(k)){ can=can.filter(x=>x!==k); cant.push(k); }        // can -> can't
      else if(cant.includes(k)){ cant=cant.filter(x=>x!==k); }              // can't -> not set
      else { can.push(k); }                                                 // not set -> can
      paint();
    });
  };
  paint();
  wrap.querySelector("#sk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sk-go").onclick=async ()=>{
    await DB.updateUser(u.id,{can_do:can.join(";"), cannot_do:cant.join(";")});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* ================= ASSIGNMENT CENTER =================
   One screen: who is working, what still has nobody, tasks, and one-tap
   automatic assignment that the manager reviews before anything is saved. */
function assignDay(){
  if(S.assignDay==null) S.assignDay=todayIndex();
  return S.assignDay;
}
function assignDateStr(day){
  const base=hotelDateStr(), td=todayIndex();
  let diff=day-td; if(diff<0) diff+=7;
  const d=new Date(base+"T12:00:00"); d.setDate(d.getDate()+diff);
  return d.toISOString().slice(0,10);
}
/* how many of the team are allowed to run this activity */
function whoCanRun(a){
  if(activitySlot(a)==="event"){
    const dj=(S.users||[]).find(u=>u.role==="staff" && +u.number===DJ_NUMBER && u.active!==false && !hasLeft(u));
    return dj ? ((dj.display_name||dj.username)+" · DJ") : "DJ —";
  }
  const ds=assignDateStr(a.day);
  const team=assignableStaff(a.day,ds);
  const n=team.filter(u=>canRunActivity(u,a) && !entranceConflict(u,a.day,a)).length;
  return n+"/"+team.length+" "+t("canRunIt");
}
/* Entrance duty lives here now — Day Plan only handles days off. */
function openEntranceModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("door",20)} ${t("entranceDuty")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b></p>
    <label style="margin-top:10px">${t("selectEntrance")}</label>
    <select id="ent-sel">
      <option value="">—</option>
      ${roster.map(r=>`<option value="${r.n}" ${dp.entrance===r.n?"selected":""}>#${r.n} ${esc(r.name||r.role)}</option>`).join("")}
    </select>
    <button class="btn" id="ent-save">${t("save")}</button>
    <button class="btn ghost" id="ent-x">${t("close")}</button>`);
  wrap.querySelector("#ent-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ent-save").onclick=async ()=>{
    const raw=wrap.querySelector("#ent-sel").value;
    const all={...(S.settings.dayOverrides||{})};
    const cur=all[String(day)] || {off:[...dp.off], entrance:dp.entrance};
    all[String(day)]={...cur, entrance: raw?+raw:null};   // days off stay as they are
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function assignView(){
  const day=assignDay(), ds=assignDateStr(day);
  const sub=S.sub.assign||"acts";
  const acts=(S.activities||[]).filter(a=>a.day===day)
    .sort((a,b)=>(timeToMin(a.time)||0)-(timeToMin(b.time)||0));
  const open=acts.filter(a=>!String(a.entertainer||"").trim());
  const team=(S.users||[]).filter(u=>u.role==="staff"); // manager never runs activities and has no can/can't profile
  const working=team.filter(u=>availableOn(u,day,ds));
  const offList=team.filter(u=>!availableOn(u,day,ds));
  const openTasks=(S.tasks||[]).filter(x=>taskStatus(x)!=="verified");
  return `<div class="screen fadein">
    ${topBar(t("assignCenter"),"")}
    <div class="seg" id="asg-tabs">
      <button class="${sub==="acts"?"on":""}" data-asub="acts">${t("asgActs")}${open.length?` <span class="seg-b">${open.length}</span>`:""}</button>
      <button class="${sub==="tasks"?"on":""}" data-asub="tasks">${t("tasks")}${openTasks.length?` <span class="seg-b">${openTasks.length}</span>`:""}</button>
      <button class="${sub==="who"?"on":""}" data-asub="who">${t("asgWho")}</button>
    </div>
    <div class="daypick" id="asg-days">
      ${t("daysShort").map((d,i)=>`<button class="${i===day?"on":""}" data-aday="${i}">${d}</button>`).join("")}
    </div>
    ${sub==="acts"?assignActsInner(day,ds,acts,open,working)
     :sub==="tasks"?`<div style="margin-top:12px">${tasksInner()}</div>`
     :assignWhoInner(day,ds,working,offList)}
  </div>`;
}
function assignActsInner(day, ds, acts, open, working){
  return `
    <div class="g3-stats" style="margin-top:12px">
      <div class="stat"><b>${acts.length}</b><span>${t("activities")}</span></div>
      <div class="stat"><b>${open.length}</b><span>${t("asgOpen")}</span></div>
      <div class="stat"><b>${working.length}</b><span>${t("workingToday")}</span></div>
    </div>
    <div class="card ent-card" id="asg-ent" style="margin-top:12px">
      <span class="ent-ic">${ic("door",20)}</span>
      <span class="asg-mid"><b>${t("entranceDuty")}</b>
        <span class="mini">${personTag(dayPlanFor(day).entrance)||t("noOneEntrance")}</span></span>
      <span class="ent-go">${ic("pen",15)}</span>
    </div>
    ${open.length?`<button class="btn" id="asg-auto" style="margin-top:12px">
        ${ic("sparkle",18)} ${t("autoAssign")}</button>
      <p class="mini" style="margin-top:6px">${t("autoAssignHint")}</p>`
      :`<div class="ok-note" style="margin-top:12px">${ic("check",18)} ${t("allAssigned")}</div>`}
    <div class="card" style="margin-top:12px">
      ${acts.length?acts.map(a=>{
        const who=String(a.entertainer||"").trim();
        const sk=activitySkill(a);
        return `<div class="asg-row" data-aopen="${a.id}">
          <span class="asg-t">${esc(a.time||"")}</span>
          <span class="asg-mid"><b>${esc(a.name)}</b>
            <span class="mini">${esc(whoCanRun(a))}${a.location?" · "+esc(a.location):""}</span></span>
          ${who?`<span class="asg-who">${esc(who)}</span>`
               :`<span class="asg-who none">${t("asgNobody")}</span>`}
        </div>`;}).join("")
        :`<p class="mini" style="padding:8px 2px">${t("noneToday")}</p>`}
    </div>`;
}
function assignWhoInner(day, ds, working, offList){
  const row=(u,ok)=>{
    const can=canDoList(u), cant=cannotDoList(u);
    const ent=onEntranceDuty(u,day);
    const n=assignedCount(u.username,day);
    return `<div class="asg-row" data-aemp="${esc(u.username)}">
      <span class="loc-av">${esc(String(u.display_name||u.username).trim().charAt(0).toUpperCase())}</span>
      <span class="asg-mid"><b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${ok?`${n} ${t("activities")}${ent?" · "+t("entranceDuty"):""}`
          :(notYetHired(u,ds.slice(0,7),+ds.slice(8,10))?t("attN")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="A"?t("attA")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="V"?t("attV")
            :t("dayOff"))}</span>
        ${isEventsOnly(u)?`<span class="skill-chips"><span class="chip evt">${t("eventsCrewTag")}</span></span>`
         :(can.length||cant.length?`<span class="skill-chips">
          ${can.map(k=>`<span class="chip can">${esc(prettyAct(k))}</span>`).join("")}
          ${cant.map(k=>`<span class="chip cant">${esc(prettyAct(k))}</span>`).join("")}
        </span>`:`<span class="mini dim">${t("noSkillsSet")}</span>`)}
      </span></div>`;};
  return `<p class="mini" style="margin:12px 0 6px">${t("asgWhoHint")}</p>
    <div class="card">${working.length?working.map(u=>row(u,true)).join(""):`<p class="mini">${t("nobodyWorking")}</p>`}</div>
    ${offList.length?`<h4 style="margin:16px 0 8px">${t("dayOffToday")}</h4>
      <div class="card dim-card">${offList.map(u=>row(u,false)).join("")}</div>`:""}`;
}
/* "Today 14:30", "Yesterday 09:15", otherwise the date — so nothing is a mystery. */
function whenLabel(ts){
  if(!ts) return "";
  const d=new Date(ts);
  if(isNaN(d.getTime())) return "";
  const time=d.toLocaleTimeString(S.lang||"en",{hour:"2-digit",minute:"2-digit"});
  const dayOf=x=>{ const y=new Date(x); y.setHours(0,0,0,0); return y.getTime(); };
  const today=dayOf(hotelNow()), that=dayOf(d);
  const diff=Math.round((today-that)/86400000);
  if(diff===0) return t("todayWord")+" "+time;
  if(diff===1) return t("yesterdayWord")+" "+time;
  if(diff>1 && diff<7) return t("days")[d.getDay()]+" "+time;
  return d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"})+" "+time;
}
/* Collect a dated list into one row per day, newest first. Tap a day to open it. */
function dayKeyOf(ts){ const d=new Date(ts); return isNaN(d)?"" : d.toISOString().slice(0,10); }
function dayHeading(key){
  const today=hotelDateStr();
  const y=new Date(today+"T12:00:00"); y.setDate(y.getDate()-1);
  const yest=y.toISOString().slice(0,10);
  if(key===today) return t("todayWord");
  if(key===yest)  return t("yesterdayWord");
  const d=new Date(key+"T12:00:00");
  return d.toLocaleDateString(S.lang||"en",{weekday:"short",day:"2-digit",month:"2-digit",year:"numeric"});
}
function groupByDay(list, tsField){
  const map=new Map();
  (list||[]).forEach(x=>{
    const k=dayKeyOf(x[tsField||"created_at"]) || "0000-00-00";
    if(!map.has(k)) map.set(k,[]);
    map.get(k).push(x);
  });
  return [...map.entries()].sort((a,b)=>b[0].localeCompare(a[0]));
}
function openDayKey(kind){ return (S.openDay && S.openDay[kind]) || null; }
function dayGroups(kind, list, tsField, rowFn, unitKey){
  const groups=groupByDay(list, tsField);
  if(!groups.length) return `<div class="empty"><div class="big">${ic("calendar",30)}</div>${t("none")}</div>`;
  const open=openDayKey(kind) || groups[0][0];
  return `<div class="dg-wrap">${groups.map(([key,items])=>{
    const isOpen=key===open;
    return `<div class="dg ${isOpen?"open":""}">
      <button class="dg-h" data-dgopen="${esc(kind)}|${esc(key)}">
        <span class="dg-t">${esc(dayHeading(key))}</span>
        <span class="dg-d">${esc(key.split("-").reverse().join("/"))}</span>
        <span class="dg-n">${items.length} ${t(unitKey||"itemsWord")}</span>
        <span class="dg-c">${ic("back",14)}</span>
      </button>
      ${isOpen?`<div class="dg-body">${items.map(rowFn).join("")}</div>`:""}
    </div>`;}).join("")}</div>`;
}
/* ================= SKILLS & AUTOMATIC ASSIGNMENT =================
   A person is only ever suggested for an activity when ALL of these hold:
     - they are employed on that date (hire date) and not on a day off
     - they are not marked absent
     - they are not on entrance duty at that hour
     - the activity's skill is in their "can do" and NOT in their "can't do"
     - they are not already busy at that time
   The manager always reviews the suggestions before anything is saved. */
/* The list she ticks is her OWN programme — the real activity names —
   so automatic assignment matches exactly what is on the plan. */
function actKey(name){ return String(name||"").trim().toLowerCase().replace(/\s+/g," "); }
function programActivities(){
  const seen=new Map();
  (S.activities||[]).forEach(a=>{
    if(activitySlot(a)!=="morning" && activitySlot(a)!=="afternoon") return; // no events/shows/parties in entertainer skills
    const k=actKey(a.name);
    if(k && !seen.has(k)) seen.set(k, String(a.name).trim());
  });
  return [...seen.entries()].sort((x,y)=>x[1].localeCompare(y[1]));
}
/* turn a stored key back into the activity name as she wrote it */
function prettyAct(k){
  const hit=programActivities().find(([key])=>key===k);
  return hit ? hit[1] : k;
}
function parseSkills(v){
  return String(v||"").split(/[;|\n]/).map(x=>actKey(x)).filter(Boolean);
}
function canDoList(u){ return parseSkills(u && u.can_do); }
function cannotDoList(u){ return parseSkills(u && u.cannot_do); }
/* the skill an activity needs — set on the activity, else guessed from its name */
function activitySkill(a){
  const explicit=String(a && a.needs_skill||"").trim().toLowerCase();
  if(explicit) return explicit;
  const n=String((a&&a.name)||"").toLowerCase();
  const guess=[["water",/aqua|water|pool|snorkel|swim/],["dance",/dance|zumba|salsa|show ?dance/],
    ["show",/show|theatre|theater|performance|stage/],["kids",/kids|mini ?disco|children/],
    ["dj",/\bdj\b|disco|party/],["music",/music|band|karaoke|sing/],
    ["fitness",/gym|fitness|yoga|pilates|stretch|workout/],
    ["sport",/football|volley|tennis|basket|boccia|petanque|dart|archer|bowl|table ?tennis|sport/],
    ["beach",/beach|sunset|sand/],["craft",/craft|paint|workshop|art/],
    ["games",/game|quiz|bingo|tournament|cocktail/]];
  for(const [k,re] of guess){ if(re.test(n)) return k; }
  return "host";
}
/* Can this person run THIS activity? */
function canRunActivity(u, act){
  const k=actKey(act && act.name);
  if(!k) return true;
  if(cannotDoList(u).includes(k)) return false;   // "can't do" always wins
  const can=canDoList(u);
  if(!can.length) return true;                     // nothing ticked = available for anything
  return can.includes(k);
}
/* is this person available on that weekday? */
function availableOn(u, day, dateStr_){
  if(!u || u.role==="guest") return false;
  if(u.active===false) return false;
  if(hasLeft(u)) return false;
  const mk=String(dateStr_||"").slice(0,7), dd=+String(dateStr_||"").slice(8,10);
  if(mk && dd && notYetHired(u,mk,dd)) return false;      // not employed yet
  if(mk && dd){
    const st=attStatus(u,mk,dd);
    if(st==="A" || st==="V") return false;               // absent or on vacation
  }
  let num=u.number; if(!num && u.role==="manager") num=1;
  const dp=dayPlanFor(day);
  if(num && dp.off.includes(num)) return false;            // day off
  return true;
}
function onEntranceDuty(u, day){
  let num=u.number; if(!num && u.role==="manager") num=1;
  return !!num && dayPlanFor(day).entrance===num;
}
/* Entrance duty takes the person out of activities from 16:00 until 18:30. */
function entranceConflict(u, day, act){
  if(!onEntranceDuty(u,day)) return false;
  const w=actWindow(act);
  if(!w) return true; // unknown time: safer not to create a mistaken assignment
  const dutyStart=16*60, dutyEnd=18*60+30;
  return w.s0 < dutyEnd && w.e0 > dutyStart;
}
/* activities already on this person for that day, to spot clashes and share the load */
function assignedCount(username, day, extra){
  const name=String(username||"").toLowerCase();
  let n=(S.activities||[]).filter(a=>a.day===day &&
    String(a.entertainer||"").toLowerCase().split(/[,;]/).map(x=>x.trim()).includes(name)).length;
  return n+((extra&&extra[username])||0);
}
function timeToMin(hhmm){
  const m=String(hhmm||"").match(/(\d{1,2}):(\d{2})/);
  return m ? (+m[1])*60+(+m[2]) : null;
}
/* Global time formatter used by manager Live Operations and later enhancement layers.
   It MUST live in base scope; keeping it inside a later IIFE caused runtime ReferenceError on login. */
function fmtCountdown(sec){
  sec=Math.max(0,Math.floor(Number(sec)||0));
  const h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), ss=sec%60;
  return (h?String(h).padStart(2,"0")+":":"")+String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");
}
window.fmtCountdown=fmtCountdown;
/* Suggest one person per unassigned activity on a given weekday. */
/* ================= WEATHER =================
   Free open service, no key needed, so it works for guests too.
   Defaults to Hurghada; the manager can set exact coordinates. */
const WMO={0:["wSun","sun"],1:["wSun","sun"],2:["wPartly","cloud"],3:["wCloud","cloud"],
  45:["wFog","cloud"],48:["wFog","cloud"],51:["wDrizzle","rain"],53:["wDrizzle","rain"],55:["wDrizzle","rain"],
  61:["wRain","rain"],63:["wRain","rain"],65:["wRain","rain"],66:["wRain","rain"],67:["wRain","rain"],
  71:["wSnow","snow"],73:["wSnow","snow"],75:["wSnow","snow"],77:["wSnow","snow"],
  80:["wShower","rain"],81:["wShower","rain"],82:["wShower","rain"],85:["wSnow","snow"],86:["wSnow","snow"],
  95:["wStorm","storm"],96:["wStorm","storm"],99:["wStorm","storm"]};
function wmoLabel(code){ const e=WMO[code]; return e?t(e[0]):""; }
function wmoIcon(code){ const e=WMO[code]; return e?e[1]:"sun"; }
function weatherCoords(){
  const st=S.settings||{};
  const lat=parseFloat(st.lat), lon=parseFloat(st.lon);
  return { lat: isNaN(lat)?27.2579:lat, lon: isNaN(lon)?33.8116:lon };   // Hurghada
}
async function loadWeather(force){
  if(S.weatherBusy) return;
  const fresh = S.weather && (Date.now()-S.weather.at < 30*60*1000);      // 30 min cache
  if(fresh && !force) return;
  S.weatherBusy=true;
  const {lat,lon}=weatherCoords();
  const tz=hotelTz()||"auto";
  const url="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+
    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"+
    "&daily=weather_code,temperature_2m_max,temperature_2m_min"+
    "&timezone="+encodeURIComponent(tz)+"&forecast_days=7";
  try{
    const res=await fetch(url);
    if(!res.ok) throw new Error("weather "+res.status);
    const d=await res.json();
    S.weather={at:Date.now(), cur:d.current||null, daily:d.daily||null};
  }catch(e){ S.weather={at:Date.now(), error:true}; }
  S.weatherBusy=false;
  if(S.session && safeToRender()) render();
}
function weatherView(){
  const w=S.weather;
  if(!w || w.error){
    return `<div class="screen fadein">${topBar(t("weatherTab"),"")}
      <div class="empty"><div class="big">${ic("sun",30)}</div>${w?t("weatherFail"):t("loadingMsg")}</div>
      <button class="btn ghost" id="w-reload">${t("close")}</button></div>`;
  }
  const cur=w.cur||{}, dly=w.daily||{};
  const days=(dly.time||[]).map((iso,i)=>({iso,
    code:(dly.weather_code||[])[i], max:(dly.temperature_2m_max||[])[i], min:(dly.temperature_2m_min||[])[i]}));
  return `<div class="screen fadein">
    ${topBar(t("weatherTab"),"")}
    <div class="card wnow">
      <div class="wn-ic">${ic(wmoIcon(cur.weather_code),44)}</div>
      <div class="wn-mid">
        <b class="wn-t">${Math.round(cur.temperature_2m)}°</b>
        <span>${esc(wmoLabel(cur.weather_code))}</span>
        <span class="mini">${t("feelsLike")} ${Math.round(cur.apparent_temperature)}° · ${t("windLbl")} ${Math.round(cur.wind_speed_10m)} km/h</span>
      </div>
    </div>
    <h3 style="margin-top:18px">${ic("calendar",17)} ${t("weatherWeek")}</h3>
    <div class="card wweek">
      ${days.map((d,i)=>{
        const dt=new Date(d.iso+"T12:00:00");
        const lbl=i===0?t("weatherToday"):(t("daysShort")[(dt.getDay()+6)%7]||"");
        return `<div class="ww-row">
          <span class="ww-d">${esc(lbl)}</span>
          <span class="ww-i">${ic(wmoIcon(d.code),19)}</span>
          <span class="ww-x">${esc(wmoLabel(d.code))}</span>
          <span class="ww-t"><b>${Math.round(d.max)}°</b> <i>${Math.round(d.min)}°</i></span>
        </div>`;
      }).join("")}
    </div>
  </div>`;
}
/* small strip for the home screens */
/* ================= PAGE DESIGNER (blocks) =================
   The manager builds pages from blocks, like a simple website builder.
   Every block carries its own style, so no code is ever needed. */
const BLOCK_TYPES=[
  ["heading","blkHeading","pen"],["text","blkText","clipboard"],["image","blkImage","sparkle"],
  ["gallery","blkGallery","grid"],["button","blkButton","check"],["card","blkCard","clipboard"],
  ["list","blkList","check"],["video","blkVideo","sparkle"],["map","blkMap","pin"],
  ["divider","blkDivider","grid"],["spacer","blkSpacer","grid"]
];
const FONT_CHOICES=[["display","fontElegant"],["body","fontModern"]];
function blockDefaults(type){
  const base={id:"b"+Date.now()+Math.floor(Math.random()*999), type,
    align:"left", size:"m", color:"", bg:"", bold:false, font:"body"};
  if(type==="heading") return {...base, text:"", size:"l", font:"display"};
  if(type==="text")    return {...base, text:""};
  if(type==="image")   return {...base, url:"", caption:""};
  if(type==="gallery") return {...base, urls:[]};
  if(type==="button")  return {...base, text:"", url:"", shape:"round", size:"m", align:"center"};
  if(type==="card")    return {...base, title:"", text:"", url:""};
  if(type==="list")    return {...base, text:""};
  if(type==="video")   return {...base, url:""};
  if(type==="map")     return {...base, text:""};
  if(type==="spacer")  return {...base, size:"m"};
  return base;
}
const SIZE_PX={heading:{s:"20px",m:"26px",l:"32px",xl:"40px"},
  text:{s:"13px",m:"15px",l:"17px",xl:"20px"},
  spacer:{s:"10px",m:"22px",l:"40px",xl:"64px"}};
function blockStyle(b){
  const st=[];
  if(b.align) st.push("text-align:"+(b.align==="right"?"end":b.align==="center"?"center":"start"));
  if(b.color) st.push("color:"+b.color);
  if(b.bold) st.push("font-weight:700");
  if(b.font==="display") st.push("font-family:var(--font-display)");
  return st.join(";");
}
function ytEmbed(url){
  const m=String(url||"").match(/(?:youtu\.be\/|v=|embed\/)([A-Za-z0-9_-]{6,})/);
  return m?("https://www.youtube.com/embed/"+m[1]):"";
}
/* Draws one block for the real page */
function renderBlock(b, ix, pageKey){
  const st=blockStyle(b);
  const wrapBg=b.bg?` style="background:${esc(b.bg)};border-radius:var(--r-lg);padding:14px"`:"";
  switch(b.type){
    case "heading":
      return `<div class="pb-b"${wrapBg}><div class="pb-h" style="${st};font-size:${SIZE_PX.heading[b.size]||"26px"}">${esc(b.text||"")}</div></div>`;
    case "text":
      return `<div class="pb-b"${wrapBg}><p class="pb-t" style="${st};font-size:${SIZE_PX.text[b.size]||"15px"}">${esc(b.text||"")}</p></div>`;
    case "image":
      return b.url?`<div class="pb-b"${wrapBg}><img class="pb-img" src="${esc(b.url)}" alt="" loading="lazy" data-pvsingle="${esc(b.url)}">
        ${b.caption?`<p class="mini" style="${st};margin-top:6px">${esc(b.caption)}</p>`:""}</div>`:"";
    case "gallery":
      return (b.urls&&b.urls.length)?`<div class="pb-b"${wrapBg}>${photoStrip(b.urls,pageKey+"-g"+ix)}</div>`:"";
    case "button": {
      const shape={round:"var(--r-md)",pill:"999px",square:"6px"}[b.shape||"round"];
      const pad={s:"9px 16px",m:"13px 22px",l:"17px 30px"}[b.size||"m"];
      const fs={s:"13px",m:"15px",l:"17px"}[b.size||"m"];
      const align=b.align==="left"?"flex-start":b.align==="right"?"flex-end":"center";
      const bg=b.bg||"";
      return `<div class="pb-b" style="display:flex;justify-content:${align}">
        <a class="pb-btn" ${b.url?`href="${esc(b.url)}" target="_blank" rel="noopener"`:""}
          style="border-radius:${shape};padding:${pad};font-size:${fs}${bg?";background:"+esc(bg):""}${b.color?";color:"+esc(b.color):""}">${esc(b.text||"")}</a></div>`;
    }
    case "card":
      return `<div class="pb-b"><div class="card pb-card"${b.bg?` style="background:${esc(b.bg)}"`:""}>
        ${b.title?`<b style="${st}">${esc(b.title)}</b>`:""}
        ${b.text?`<p style="${st}">${esc(b.text)}</p>`:""}
        ${b.url?`<a class="pb-btn sm" href="${esc(b.url)}" target="_blank" rel="noopener">${t("openLink")}</a>`:""}
      </div></div>`;
    case "list": {
      const items=String(b.text||"").split("\n").map(x=>x.trim()).filter(Boolean);
      return items.length?`<div class="pb-b"${wrapBg}><ul class="pb-list" style="${st}">
        ${items.map(i=>`<li>${esc(i)}</li>`).join("")}</ul></div>`:"";
    }
    case "video": {
      const emb=ytEmbed(b.url);
      return emb?`<div class="pb-b"><div class="pb-video"><iframe src="${esc(emb)}" frameborder="0"
        allow="accelerometer;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div></div>`:"";
    }
    case "map": {
      const q=encodeURIComponent(b.text||"");
      return b.text?`<div class="pb-b"><a class="pb-btn" href="https://www.google.com/maps/search/?api=1&query=${q}"
        target="_blank" rel="noopener">${ic("pin",15)} ${esc(b.text)}</a></div>`:"";
    }
    case "divider": return `<div class="pb-b"><hr class="pb-hr"></div>`;
    case "spacer":  return `<div style="height:${SIZE_PX.spacer[b.size]||"22px"}"></div>`;
  }
  return "";
}
function renderBlocks(blocks, pageKey){
  const list=Array.isArray(blocks)?blocks:[];
  if(!list.length) return "";
  return list.map((b,i)=>renderBlock(b,i,pageKey||"pg")).join("");
}
/* ================= PAGE EDITOR SCREEN ================= */
function pbState(){
  if(!S.pb) S.pb={role:"guest", pageId:null, page:null};
  return S.pb;
}
function pbFindPage(role,id){ return (customPages(role)||[]).find(p=>p.id===id)||null; }
function pbOpen(role,id){
  const st=pbState();
  st.role=role;
  if(id){
    const p2=pbFindPage(role,id);
    st.pageId=id;
    st.page=p2?JSON.parse(JSON.stringify(p2)):null;
  } else {
    st.pageId=null;
    st.page={id:"p"+Date.now(), title:"", kind:"page", icon:"pin", url:"", text:"", blocks:[]};
  }
  if(st.page && !Array.isArray(st.page.blocks)) st.page.blocks=[];
  S.tab="pagedesign"; render();
}
async function pbSave(){
  const st=pbState();
  if(!st.page) return;
  if(!String(st.page.title||"").trim()){ toastWarn(t("fieldRequired")); return; }
  const list=(customPages(st.role)||[]).slice();
  const i=list.findIndex(x=>x.id===st.page.id);
  if(i>=0) list[i]=st.page; else list.push(st.page);
  const menu={...(S.settings.menu||{})};
  menu[st.role]={...menuConf(st.role), custom:list};
  try{
    await DB.saveSettings({...S.settings, menu});
    toastOk(t("pbSaved"));
    S.tab="builder"; render();
  }catch(e){ toastErr(t("errSave")); }
}
function pbAdd(type){
  const st=pbState(); if(!st.page) return;
  st.page.blocks.push(blockDefaults(type)); render();
}
function pbMove(id,dir){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const j=i+dir; if(j<0||j>=b.length) return;
  b.splice(j,0,b.splice(i,1)[0]); render();
}
function pbDup(id){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const copy=JSON.parse(JSON.stringify(b[i]));
  copy.id="b"+Date.now()+Math.floor(Math.random()*999);
  b.splice(i+1,0,copy); render();
}
async function pbDel(id){
  if(!await confirmAction({question:t("delBlock"),danger:true})) return;
  const st=pbState();
  st.page.blocks=st.page.blocks.filter(x=>x.id!==id); render();
}
function pageDesignView(){
  const st=pbState();
  if(!st.page) return `<div class="screen fadein">${topBar(t("pageBuilder"),"")}<div class="empty">${t("none")}</div></div>`;
  const pg=st.page;
  return `<div class="screen fadein">
    ${topBar(pg.title||t("pbNewPage"), t("pageBuilder"))}
    <button class="crumb" id="crumb-pb">${ic("back",15)} ${t("setMenus")}</button>
    <div class="card" style="padding:14px">
      <label>${t("pbTitle")}</label><input id="pb-title" value="${esc(pg.title||"")}">
      <label>${t("pbWho")}</label>
      <select id="pb-role">
        ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
          `<option value="${k}" ${st.role===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="pb-addbar">
      <span class="type-meta">${t("pbAddBlock")}</span>
      <div class="pb-types">
        ${BLOCK_TYPES.map(([k,lb,icn])=>`<button class="pb-type" data-pbadd="${k}">
          <span>${ic(icn,16)}</span>${t(lb)}</button>`).join("")}
      </div>
    </div>
    ${pg.blocks.length?pg.blocks.map((b,i)=>`
      <div class="pb-edit">
        <div class="pb-eh">
          <b>${t((BLOCK_TYPES.find(x=>x[0]===b.type)||[,"blkText"])[1])}</b>
          <span class="pb-eacts">
            <button class="bd-b" data-pbup="${b.id}" ${i===0?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b down" data-pbdown="${b.id}" ${i===pg.blocks.length-1?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b" data-pbdup="${b.id}">${ic("plus",13)}</button>
            <button class="bd-b warn" data-pbdel="${b.id}">${ic("trash",13)}</button>
          </span>
        </div>
        ${pbBlockFields(b)}
        <div class="pb-prev">${renderBlock(b,i,"prev")||`<span class="mini">—</span>`}</div>
      </div>`).join("")
      :`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`}
    <button class="btn" id="pb-save" style="margin-top:14px">${ic("check",16)} ${t("save")}</button>
  </div>`;
}
/* the controls for one block */
function pbBlockFields(b){
  const sel=(id,val,opts)=>`<select data-pbf="${b.id}|${id}">${opts.map(([k,lb])=>
    `<option value="${k}" ${String(val)===k?"selected":""}>${t(lb)}</option>`).join("")}</select>`;
  const txt=(id,val,ph)=>`<input data-pbf="${b.id}|${id}" value="${esc(val||"")}" placeholder="${esc(ph||"")}">`;
  const area=(id,val,ph)=>`<textarea data-pbf="${b.id}|${id}" rows="3" placeholder="${esc(ph||"")}">${esc(val||"")}</textarea>`;
  const col=(id,val)=>`<input type="color" data-pbf="${b.id}|${id}" value="${esc(val||"#3E2A1E")}">`;
  const alignSel=sel("align",b.align,[["left","alignLeft"],["center","alignCenter"],["right","alignRight"]]);
  const sizeSel=sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"],["xl","fsXl"]]);
  let content="";
  if(b.type==="heading"||b.type==="text") content=area("text",b.text,t("pbContent"));
  else if(b.type==="list") content=area("text",b.text,t("listItems"));
  else if(b.type==="image") content=`${pbImageField(b,"url")}${txt("caption",b.caption,t("photoCaption"))}`;
  else if(b.type==="gallery") content=pbGalleryField(b);
  else if(b.type==="button") content=`${txt("text",b.text,t("blkButton"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="card") content=`${txt("title",b.title,t("infoTitle"))}${area("text",b.text,t("pbContent"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="video") content=txt("url",b.url,t("videoUrl"));
  else if(b.type==="map") content=txt("text",b.text,t("mapAddr"));
  let style="";
  if(["heading","text","list","card"].includes(b.type))
    style=`<div class="row2"><div><label>${t("fontSizeB")}</label>${sizeSel}</div>
      <div><label>${t("alignLbl")}</label>${alignSel}</div></div>
      <div class="row2"><div><label>${t("fontFamilyB")}</label>${sel("font",b.font,FONT_CHOICES)}</div>
      <div><label>${t("colorLbl")}</label>${col("color",b.color)}</div></div>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:14px;color:var(--ink)">
        <input type="checkbox" style="width:auto" data-pbc="${b.id}|bold" ${b.bold?"checked":""}> ${t("boldLbl")}</label>`;
  else if(b.type==="button")
    style=`<div class="row2"><div><label>${t("btnShape")}</label>
        ${sel("shape",b.shape,[["round","shapeRound"],["pill","shapePill"],["square","shapeSquare"]])}</div>
      <div><label>${t("btnSize")}</label>${sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"]])}</div></div>
      <div class="row2"><div><label>${t("alignLbl")}</label>${alignSel}</div>
      <div><label>${t("bgLbl")}</label>${col("bg",b.bg)}</div></div>`;
  else if(b.type==="spacer") style=`<label>${t("fontSizeB")}</label>${sizeSel}`;
  else if(b.type==="image") style=`<label>${t("alignLbl")}</label>${alignSel}`;
  return content+style;
}
function pbImageField(b,key){
  return `<div class="pedit" id="pbi-${b.id}">
      ${b[key]?`<div class="pedit-it"><img src="${esc(b[key])}" alt="">
        <button class="pedit-rm" type="button" data-pbimgrm="${b.id}|${key}">${ic("close",13)}</button></div>`:""}
    </div>
    <button class="btn sm ghost" type="button" data-pbimgadd="${b.id}|${key}">${ic("plus",14)} ${t("addPhoto")}</button>`;
}
function pbGalleryField(b){
  return `<div class="pedit">
      ${(b.urls||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
        <button class="pedit-rm" type="button" data-pbgrm="${b.id}|${ix}">${ic("close",13)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" type="button" data-pbgadd="${b.id}">${ic("plus",14)} ${t("addPhotos")}</button>`;
}
/* ================= MENU BUILDER SCREEN ================= */
function builderRole(){ return S.sub.builder || "guest"; }
async function saveMenuConf(role, patch){
  const menu={...(S.settings.menu||{})};
  menu[role]={...menuConf(role), ...patch};
  try{ await DB.saveSettings({...S.settings, menu}); toastOk(t("builderSaved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* The page the app opens on, per role — the manager chooses it in the builder. */
function defaultTabFor(role){
  const conf=menuConf(role)||{};
  const want=conf.start;
  if(want){
    const ok=navGroups(role).flatMap(g=>g.items).some(i=>i[0]===want);
    if(ok) return want;
  }
  return role==="manager" ? "dash" : (role==="staff" ? "workday" : "home");
}
function builderView(){
  const role=builderRole();
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{};
  const base=navGroupsBase(role);
  const items=base.flatMap(g=>g.items);
  const order=(conf.order&&conf.order.length)?conf.order:items.map(i=>i[0]);
  const sorted=items.slice().sort((a,b)=>{
    const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
    return (ia<0?999:ia)-(ib<0?999:ib);
  });
  return `<div class="screen fadein">
    ${topBar(t("builderTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 12px">${t("builderHint")}</p>
    <div class="bd-roles">
      ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
        `<button class="bd-role ${role===k?"on":""}" data-bdrole="${k}">${t(lb)}</button>`).join("")}
    </div>
    <label style="margin-top:4px">${t("startPage")}</label>
    <select id="bd-start">
      ${sorted.filter(it=>!hidden.includes(it[0])).map(it=>
        `<option value="${esc(it[0])}" ${conf.start===it[0]?"selected":""}>${esc(names[it[0]]||it[2])}</option>`).join("")}
    </select>
    <p class="mini" style="margin:-4px 0 12px">${t("startPageHint")}</p>
    <div class="bd-sec-head">${t("secTitles")}</div>
    <p class="mini" style="margin:-2px 0 8px">${t("secTitlesHint")}</p>
    <div class="card bd-list">
      ${base.filter(g=>g.key).map(g=>`<div class="bd-it">
        <span class="bd-ic">${ic("grid",17)}</span>
        <span class="bd-nm">${esc((conf.gnames||{})[g.key]||g.head)}${(conf.gnames||{})[g.key]?` <i>${esc(g.head)}</i>`:""}</span>
        <span class="bd-acts">
          <button class="bd-b" data-bdgname="${esc(g.key)}" aria-label="${t("renameGroup")}">${ic("pen",14)}</button>
        </span></div>`).join("")}
    </div>
    <div class="bd-sec-head">${t("menu")}</div>
    <div class="card bd-list">
      ${sorted.map((it,i)=>{
        const id=it[0], off=hidden.includes(id);
        return `<div class="bd-it ${off?"off":""}">
          <span class="bd-ic">${ic(it[1],17)}</span>
          <span class="bd-nm">${esc(names[id]||it[2])}${names[id]?` <i>${esc(it[2])}</i>`:""}</span>
          <span class="bd-acts">
            <button class="bd-b" data-bdup="${esc(id)}" aria-label="${t("moveUp")}" ${i===0?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b down" data-bddown="${esc(id)}" aria-label="${t("moveDown")}" ${i===sorted.length-1?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b" data-bdname="${esc(id)}" aria-label="${t("renameItem")}">${ic("pen",14)}</button>
            <button class="bd-b ${off?"":"on"}" data-bdhide="${esc(id)}" aria-label="${t("hideItem")}">${ic(off?"belloff":"bell",14)}</button>
          </span>
        </div>`;
      }).join("")}
    </div>
    <button class="btn" id="bd-add" style="margin-top:14px">${ic("plus",16)} ${t("addLink")}</button>
    ${(conf.custom&&conf.custom.length)?`<div class="card" style="margin-top:12px">
      ${conf.custom.map(pg=>`<div class="bd-it">
        <span class="bd-ic">${ic(pg.icon||"pin",17)}</span>
        <span class="bd-nm">${esc(pg.title)}<i>${pg.kind==="link"?t("kindLink"):t("kindPage")}</i></span>
        <span class="bd-acts">
          <button class="bd-b" data-bdedit="${esc(pg.id)}">${ic("pen",14)}</button>
          <button class="bd-b warn" data-bddel="${esc(pg.id)}">${ic("trash",14)}</button>
        </span></div>`).join("")}
    </div>`:""}
    <button class="btn ghost" id="bd-reset" style="margin-top:12px">${ic("back",15)} ${t("resetMenu")}</button>
  </div>`;
}
function moveMenuItem(id, dir){
  const role=builderRole(), conf=menuConf(role);
  const items=navGroupsBase(role).flatMap(g=>g.items).map(i=>i[0]);
  let order=(conf.order&&conf.order.length)?conf.order.slice():items.slice();
  items.forEach(k=>{ if(!order.includes(k)) order.push(k); });
  const i=order.indexOf(id); if(i<0) return;
  const j=i+dir; if(j<0||j>=order.length) return;
  order.splice(j,0,order.splice(i,1)[0]);
  saveMenuConf(role,{order});
}
function toggleMenuItem(id){
  const role=builderRole(), conf=menuConf(role);
  const hidden=(conf.hidden||[]).slice();
  const i=hidden.indexOf(id);
  if(i>=0) hidden.splice(i,1); else hidden.push(id);
  saveMenuConf(role,{hidden});
}
function openRenameModal(id){
  const role=builderRole(), conf=menuConf(role);
  const base=navGroupsBase(role).flatMap(g=>g.items).find(i=>i[0]===id);
  const cur=(conf.names||{})[id]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameItem")}</h3>
    <p class="mini">${esc(base?base[2]:id)}</p>
    <input id="rn-v" value="${esc(cur)}" placeholder="${esc(base?base[2]:"")}">
    <button class="btn" id="rn-go">${t("save")}</button>
    <button class="btn ghost" id="rn-x">${t("close")}</button>`);
  wrap.querySelector("#rn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rn-go").onclick=()=>{
    const names={...(conf.names||{})};
    const v=wrap.querySelector("#rn-v").value.trim();
    if(v) names[id]=v; else delete names[id];
    wrap.remove(); saveMenuConf(role,{names});
  };
}
/* Rename a whole menu section — the grey heading above a group of items. */
function openGroupRenameModal(gkey){
  const role=builderRole(), conf=menuConf(role);
  const g=navGroupsBase(role).find(x=>x.key===gkey);
  const cur=(conf.gnames||{})[gkey]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameGroup")}</h3>
    <p class="mini">${esc(g?g.head:gkey)}</p>
    <input id="gn-v" value="${esc(cur)}" placeholder="${esc(g?g.head:"")}">
    <button class="btn" id="gn-go">${t("save")}</button>
    <button class="btn ghost" id="gn-x">${t("close")}</button>`);
  wrap.querySelector("#gn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#gn-go").onclick=()=>{
    const gnames={...(conf.gnames||{})};
    const v=wrap.querySelector("#gn-v").value.trim();
    if(v) gnames[gkey]=v; else delete gnames[gkey];
    wrap.remove(); saveMenuConf(role,{gnames});
  };
}
function openCustomPageModal(pgId){
  const role=builderRole(), conf=menuConf(role);
  const list=(conf.custom||[]);
  const pg=pgId?list.find(x=>x.id===pgId):null;
  const p2=pg||{id:"p"+Date.now(),title:"",kind:"page",url:"",text:"",icon:"pin"};
  const wrap=baseModal(`
    <h3>${ic("plus",20)} ${t("addLink")}</h3>
    <label>${t("linkTitle")}</label><input id="cp-t" value="${esc(p2.title)}">
    <label>${t("linkKind")}</label>
    <select id="cp-k">
      <option value="page" ${p2.kind==="page"?"selected":""}>${t("kindPage")}</option>
      <option value="link" ${p2.kind==="link"?"selected":""}>${t("kindLink")}</option>
    </select>
    <label>${t("linkUrl")}</label><input id="cp-u" value="${esc(p2.url||"")}" placeholder="https://...">
    <label>${t("linkText")}</label><textarea id="cp-x" rows="4">${esc(p2.text||"")}</textarea>
    <button class="btn" id="cp-go">${t("save")}</button>
    ${pg?`<button class="btn warn" id="cp-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=()=>{
    const title=wrap.querySelector("#cp-t").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const url=wrap.querySelector("#cp-u").value.trim();
    if(url && !/^https:\/\//i.test(url)){ toastErr(t("errHttps")); return; }
    const rec={...p2, title, kind:wrap.querySelector("#cp-k").value, url,
      text:wrap.querySelector("#cp-x").value};
    const next=list.filter(x=>x.id!==rec.id).concat([rec]);
    wrap.remove(); saveMenuConf(role,{custom:next});
  };
  const del=wrap.querySelector("#cp-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    wrap.remove(); saveMenuConf(role,{custom:list.filter(x=>x.id!==p2.id)});
  };
}
/* a page the manager created */
function customPageView(id){
  const role=S.session.role;
  const pg=customPages(role).find(p=>p.id===id);
  if(!pg) return `<div class="screen fadein">${topBar(t("customPage"),"")}<div class="empty">${t("none")}</div></div>`;
  const blocks=Array.isArray(pg.blocks)?pg.blocks:[];
  const isMgr=S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(pg.title,"")}
    ${blocks.length?renderBlocks(blocks,"cp"+id):""}
    ${(!blocks.length&&pg.text)?`<div class="card" style="padding:16px"><p style="white-space:pre-wrap;font-size:15px;line-height:1.55">${esc(pg.text)}</p></div>`:""}
    ${(!blocks.length&&pg.url)?`<a class="btn" href="${esc(pg.url)}" target="_blank" rel="noopener"
      style="display:block;text-align:center;margin-top:12px">${ic("back",15)} ${t("openLink")}</a>`:""}
    ${(!blocks.length&&!pg.text&&!pg.url)?`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`:""}
    ${isMgr?`<button class="btn ghost" data-pbedit="${esc(pg.id)}" style="margin-top:16px">${ic("pen",15)} ${t("pbEditPage")}</button>`:""}
  </div>`;
}
/* ================= QR CODE (spread the app) ================= */
function appUrl(){
  try{ return location.origin + location.pathname; }catch(e){ return ""; }
}
function qrView(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data="+encodeURIComponent(url);
  return `<div class="screen fadein">
    ${topBar(t("qrTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 14px">${t("qrHint")}</p>
    <div class="card qrcard">
      <img class="qr-img" src="${esc(img)}" alt="QR" loading="lazy">
      <p class="mini qr-url">${esc(url)}</p>
    </div>
    <button class="btn" id="qr-print" style="margin-top:14px">${ic("download",16)} ${t("qrDownload")}</button>
  </div>`;
}
function openQrPrint(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=900x900&margin=12&data="+encodeURIComponent(url);
  const name=esc(S.settings.name||"Entertainment");
  const w=window.open("","_blank");
  if(!w){ toastErr(t("errSave")); return; }
  w.document.write('<html><head><title>'+name+'</title><meta charset="utf-8">'+
    '<style>body{font-family:system-ui,sans-serif;text-align:center;padding:40px;color:#2B1F16}'+
    'h1{font-size:34px;margin:0 0 6px}p{color:#6b5a4a;margin:0 0 26px;font-size:18px}'+
    'img{width:70%;max-width:420px}small{display:block;margin-top:18px;color:#8a7a6a;word-break:break-all}</style>'+
    '</head><body><h1>'+name+'</h1><p>'+esc(t("qrHint"))+'</p>'+
    '<img src="'+img+'" alt="QR"><small>'+esc(url)+'</small>'+
    '<scr'+'ipt>setTimeout(function(){window.print();},600);<\/scr'+'ipt></body></html>');
  w.document.close();
}
/* ================= MANAGER: WHAT NEEDS YOU ================= */
function attentionItems(){
  const items=[]; const today=todayIndex();
  // activities today that can be booked but nobody has
  const empty=S.activities.filter(a=>a.day===today && (+a.capacity)>0 && seatsTaken(a.id)===0);
  if(empty.length) items.push({n:empty.length, key:"attEmptyAct", tab:"program", tone:"warn"});
  // guest requests still new
  const waiting=(S.requests||[]).filter(r=>r.status==="new");
  if(waiting.length) items.push({n:waiting.length, key:"attWaitReq", tab:"guests", sub:"requests", tone:"bad"});
  // team requests still new
  const sreq=(S.staffReqs||[]).filter(r=>r.status==="new");
  if(sreq.length) items.push({n:sreq.length, key:"attStaffReq", tab:"team", sub:"requests", tone:"bad"});
  // low ratings in the last 7 days
  const weekAgo=Date.now()-7*864e5;
  const low=(S.feedback||[]).filter(f=>(+f.rate||5)<=3 && new Date(f.created_at).getTime()>weekAgo);
  if(low.length) items.push({n:low.length, key:"attLowRate", tab:"guests", sub:"feedback", tone:"bad"});
  return items;
}
function attentionCard(){
  const items=attentionItems();
  if(!items.length) return `<div class="card attn ok"><span class="attn-ic">${ic("check",20)}</span>
    <span>${t("allGood")}</span></div>`;
  return `<div class="card attn">
    <span class="type-meta">${t("attentionHead")}</span>
    <div class="attn-list">${items.map(i=>`
      <button class="attn-it ${i.tone}" data-attn="${i.tab}${i.sub?"|"+i.sub:""}">
        <span class="attn-n">${i.n}</span>
        <span class="attn-lb">${t(i.key)}</span>
        <span class="attn-go">${ic("back",15)}</span>
      </button>`).join("")}</div>
  </div>`;
}
/* ================= MANAGER: TRENDS ================= */
function last7Days(){
  const out=[];
  for(let i=6;i>=0;i--){ const d=new Date(Date.now()-i*864e5); out.push(d); }
  return out;
}
function trendsCard(){
  const days=last7Days();
  const counts=days.map(d=>{
    const k=d.toISOString().slice(0,10);
    return (S.bookings||[]).filter(b=>String(b.created_at||"").slice(0,10)===k).length;
  });
  const max=Math.max(1,...counts);
  // most and least popular activities by real bookings
  const byAct={};
  (S.bookings||[]).forEach(b=>{ byAct[b.activity_id]=(byAct[b.activity_id]||0)+1; });
  const ranked=S.activities.map(a=>({a, n:byAct[a.id]||0})).sort((x,y)=>y.n-x.n);
  const top=ranked.filter(r=>r.n>0).slice(0,3);
  const low=ranked.filter(r=>(+r.a.capacity)>0).slice(-3).reverse();
  return `<div class="sec"><h3>${ic("grid",18)} ${t("trendsHead")}</h3>
    <div class="card trend">
      <span class="type-meta">${t("bookingTrend")} · ${t("last7")}</span>
      <div class="tr-bars">${counts.map((c,i)=>`
        <div class="tr-b"><span style="height:${Math.round(c/max*100)}%"></span>
          <i>${(t("daysShort")[(days[i].getDay()+6)%7]||"").slice(0,2)}</i>
          <u>${c}</u></div>`).join("")}</div>
    </div>
    ${top.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("topActs")}</span>
      ${top.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
    ${low.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("lowActs")}</span>
      ${low.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
  </div>`;
}
/* ================= ENTERTAINER: MY PAGE ================= */
const REQ_TYPES=[["dayoff","reqDayOff"],["problem","reqProblem"],["cannot","reqCannot"],["other","reqOther"]];
function reqTypeLabel(k){ const f=REQ_TYPES.find(x=>x[0]===k); return f?t(f[1]):k; }
function myStaffReqs(){
  const me=S.session?S.session.username:"";
  return (S.staffReqs||[]).filter(r=>r.username===me);
}
function myFeedbackList(){
  const me=S.session?S.session.username:"";
  return (S.feedback||[]).filter(f=>String(f.by_user||"")===me);
}
/* The entertainer's own page: attendance, ratings and a way to reach the manager */
function myPageView(){
  const mk=currentAttMonth(), me=S.session;
  const user=(S.users||[]).find(u=>u.username===me.username)||{username:me.username,display_name:me.name,number:me.number};
  const tot=attTotals(user,mk);
  const fb=myFeedbackList();
  const avg=fb.length ? Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10 : 0;
  const reqs=myStaffReqs();
  const n=monthDays(mk);
  const strip=Array.from({length:n},(_,i)=>{
    const d=i+1;
    if(isFutureDay(mk,d)) return `<span class="ms-d future" title="${d}">·</span>`;
    if(notYetHired(user,mk,d) || leftBefore(user,mk,d)) return `<span class="ms-d notyet" title="${d}">N</span>`;
    const st=attStatus(user,mk,d);
    return `<span class="ms-d s-${st}" title="${d}">${st}</span>`;
  }).join("");
  return `<div class="screen fadein">
    ${topBar(t("myAttendance"), monthLabel(mk))}
    <div class="att-head">
      <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button>
      <b class="att-month">${esc(monthLabel(mk))}</b>
      <button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button>
    </div>
    <div class="card attsum">
      <div class="as-row">
        <div class="as-n p"><b>${tot.P}</b><span class="mini">${t("workDays")}</span></div>
        <div class="as-n o"><b>${tot.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${tot.A}</b><span class="mini">${t("attTotalsA")}</span></div>
      </div>
      <div class="ms-strip">${strip}</div>
      <p class="mini" style="margin:8px 0 0">${t("attLegend")}</p>
    </div>

    <div class="sec"><h3>${ic("star",18)} ${t("myFeedback")}</h3>
      ${fb.length?`<div class="card">
        <div class="mf-top"><b class="mf-avg">${avg}</b><span class="mini">${t("avgRate")} · ${fb.length}</span></div>
        ${fb.slice(0,6).map(f=>`<div class="mf-row">
          <span class="mf-rate">${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</span>
          <span class="mf-c">${esc(f.comment||"")}</span>
          <span class="mini">${esc(f.nationality||"")} · ${fmtDate(f.created_at)}</span>
        </div>`).join("")}
      </div>`:`<div class="card"><p class="mini" style="padding:4px 2px">${t("noMyFeedback")}</p></div>`}
    </div>

    <div class="sec"><h3>${ic("chat",18)} ${t("myRequestsTeam")}</h3>
      <button class="btn" id="sr-new" style="margin-bottom:10px">${ic("plus",16)} ${t("askManager")}</button>
      ${reqs.length?`<div class="card">${reqs.map(r=>`
        <div class="sr-row">
          <div class="sr-mid"><b>${esc(reqTypeLabel(r.type))}</b>
            <span>${esc(r.detail||"")}</span>
            ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
            ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):r.status==="done"?t("done"):t("statusNew")}</span>
        </div>`).join("")}</div>`:""}
    </div>
  </div>`;
}
/* An entertainer can ask the manager to change their profile — they cannot edit it. */
function openProfileChangeModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("changeRequest")}</h3>
    <p class="mini">${t("profileReadOnly")}</p>
    <label>${t("whatToChange")}</label><textarea id="pc-d" rows="4"></textarea>
    <button class="btn" id="pc-go">${t("send")}</button>
    <button class="btn ghost" id="pc-x">${t("close")}</button>`);
  wrap.querySelector("#pc-x").onclick=()=>wrap.remove();
  wrap.querySelector("#pc-go").onclick=async ()=>{
    const detail=wrap.querySelector("#pc-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:"other", detail:t("changeRequest")+": "+detail, the_date:"", status:"new"});
      wrap.remove(); toastOk(t("reqSentMgr")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openStaffReqModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("newTeamReq")}</h3>
    <label>${t("taskType")}</label>
    <select id="sr-type">${REQ_TYPES.map(([k,lbl])=>`<option value="${k}">${t(lbl)}</option>`).join("")}</select>
    <label>${t("reqDetail")}</label><textarea id="sr-d" rows="3"></textarea>
    <label>${t("reqDateOpt")}</label><input id="sr-date" placeholder="${esc(t("reqDateOpt"))}">
    <button class="btn" id="sr-send">${t("send")}</button>
    <button class="btn ghost" id="sr-x">${t("close")}</button>`);
  wrap.querySelector("#sr-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sr-send").onclick=async ()=>{
    const detail=wrap.querySelector("#sr-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:wrap.querySelector("#sr-type").value, detail,
        the_date:wrap.querySelector("#sr-date").value.trim(), status:"new"});
      wrap.remove(); toastOk(t("reqSent")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= MANAGER: TEAM REQUESTS ================= */
function teamRequestsInner(){
  const list=(S.staffReqs||[]);
  if(!list.length) return `<div class="card"><p class="mini" style="padding:4px 2px">${t("noTeamReqs")}</p></div>`;
  return `<div class="card">${list.map(r=>`
    <div class="sr-row">
      <div class="sr-mid"><b>${esc(r.display_name||r.username)} · ${esc(reqTypeLabel(r.type))}</b>
        <span>${esc(r.detail||"")}</span>
        ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
        <span class="mini">${fmtDate(r.created_at)}</span>
        ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
      ${r.status==="new"?`<span class="sr-acts">
          <button class="btn sm" data-reqok="${r.id}">${t("reqApprove")}</button>
          <button class="btn sm ghost" data-reqno="${r.id}">${t("reqDecline")}</button>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`
        :`<span class="sr-acts">
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):t("done")}</span>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`}
    </div>`).join("")}</div>`;
}
async function answerStaffReq(id, status){
  const wrap=baseModal(`
    <h3>${status==="ok"?t("reqApprove"):t("reqDecline")}</h3>
    <label>${t("reqReply")}</label><textarea id="ar-r" rows="3"></textarea>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-x">${t("close")}</button>`);
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-go").onclick=async ()=>{
    try{
      await DB.updateStaffReq(id,{status, reply:wrap.querySelector("#ar-r").value.trim()});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= HOTEL INFO (guest) ================= */
function hotelInfoList(){ return Array.isArray(S.settings.hotelInfo)?S.settings.hotelInfo:[]; }
/* An entry can have several opening times (restaurant 3x, entertainment 3 operations).
   Older entries stored a single `time` string — both shapes work. */
function infoTimes(it){
  if(Array.isArray(it.times)) return it.times.filter(Boolean);
  return it.time?[it.time]:[];
}
/* an entry can hold several pictures; older entries had one `photo` */
function infoPics(it){
  if(Array.isArray(it.photos) && it.photos.length) return it.photos.filter(Boolean);
  return it.photo?[it.photo]:[];
}
function hotelInfoView(){
  const list=hotelInfoList();
  const isMgr=S.session && S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(t("hotelInfoTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("hotelInfoHint")}</p>
    ${list.length?`<div class="infogrid">${list.map((it,i)=>`
      <div class="info-card" ${isMgr?`data-infoedit="${i}"`:""}>
        ${(()=>{const pics=infoPics(it);
          return pics.length===1
            ? `<img class="info-img" src="${esc(pics[0])}" alt="" loading="lazy" data-pv="info${i}|0">`
            : photoStrip(pics,"info"+i);})()}
        <div class="info-body">
          <b>${esc(it.title||"")}</b>
          ${it.value?`<span class="info-val">${esc(it.value)}</span>`:""}
          <div class="info-meta">
            ${infoTimes(it).map(tm=>`<span>${mi("clock")}${esc(tm)}</span>`).join("")}
            ${it.place?`<span>${mi("pin")}${esc(it.place)}</span>`:""}
          </div>
        </div>
        ${isMgr?`<span class="info-go">${ic("pen",15)}</span>`:""}
      </div>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noInfo")}</div>`}
    ${isMgr?`<button class="btn" id="info-add" style="margin-top:14px">${ic("plus",16)} ${t("addInfo")}</button>`:""}
  </div>`;
}
function openInfoModal(idx){
  const list=hotelInfoList();
  const editing=(typeof idx==="number");
  const it=editing?list[idx]:{title:"",value:"",time:"",place:"",photo:""};
  const wrap=baseModal(`
    <h3>${ic("pin",20)} ${editing?t("infoTitle"):t("addInfo")}</h3>
    ${photoListEditor("hi", infoPics(it))}
    <label>${t("infoTitle")}</label><input id="hi-t" value="${esc(it.title||"")}" placeholder="WiFi">
    <label>${t("infoValue")}</label><textarea id="hi-v" rows="3">${esc(it.value||"")}</textarea>
    <label>${t("timesLbl")}</label>
    <div id="hi-times">
      ${(infoTimes(it).length?infoTimes(it):[""]).map(tm=>`
        <div class="time-row"><input class="hi-t1" value="${esc(tm)}" placeholder="07:00 - 10:00">
          <button class="btn sm ghost hi-rm" type="button">${ic("close",14)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" id="hi-addtime" style="margin-bottom:10px">${ic("plus",14)} ${t("addTime")}</button>
    <label>${t("infoPlace")}</label><input id="hi-place" value="${esc(it.place||"")}" placeholder="Main restaurant">
    <button class="btn" id="hi-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="hi-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="hi-x">${t("close")}</button>`);
  wrap.querySelector("#hi-x").onclick=()=>wrap.remove();
  let hiPics=infoPics(it).slice();
  wirePhotoList(wrap,"hi",()=>hiPics,l=>{ hiPics=l; });
  const timesBox=wrap.querySelector("#hi-times");
  const wireRemove=()=>wrap.querySelectorAll(".hi-rm").forEach(b=>b.onclick=()=>{
    if(wrap.querySelectorAll(".time-row").length>1) b.parentElement.remove();
    else b.parentElement.querySelector(".hi-t1").value="";
  });
  wireRemove();
  const addT=wrap.querySelector("#hi-addtime");
  if(addT) addT.onclick=()=>{
    const row=document.createElement("div");
    row.className="time-row";
    row.innerHTML='<input class="hi-t1" placeholder="07:00 - 10:00"><button class="btn sm ghost hi-rm" type="button">'+ic("close",14)+'</button>';
    timesBox.appendChild(row); wireRemove();
  };
  wrap.querySelector("#hi-save").onclick=async ()=>{
    const title=wrap.querySelector("#hi-t").value.trim();
    const value=wrap.querySelector("#hi-v").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const times=[...wrap.querySelectorAll(".hi-t1")].map(el=>el.value.trim()).filter(Boolean);
    const rec={title, value, times,
      place:wrap.querySelector("#hi-place").value.trim(),
      photos:hiPics, photo:hiPics[0]||""};
    const next=hotelInfoList().slice();
    if(editing) next[idx]=rec; else next.push(rec);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  const del=wrap.querySelector("#hi-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    const next=hotelInfoList().filter((_,i)=>i!==idx);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= PHOTO GALLERY ================= */
function galleryView(){
  const isMgr=S.session && S.session.role==="manager";
  const isStaff=S.session && S.session.role==="staff";
  const canAdd=isMgr||isStaff;
  const list=(S.photos||[]);
  return `<div class="screen fadein">
    ${topBar(t("galleryTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("galleryHint")}</p>
    ${canAdd?`<button class="btn" id="ph-add" style="margin-bottom:14px">${ic("plus",16)} ${t("addPhoto")}</button>`:""}
    ${list.length?`<div class="photogrid">${list.map((ph,i)=>`
      <figure class="photo-it">
        <img src="${esc(ph.url)}" alt="${esc(ph.caption||"")}" loading="lazy" data-pv="gal|${i}">
        ${ph.caption?`<figcaption>${esc(ph.caption)}</figcaption>`:""}
        ${isMgr?`<button class="ph-del" data-phdel="${ph.id}" aria-label="${t("deleteActivity")}">${ic("trash",14)}</button>`:""}
      </figure>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("noPhotos")}</div>`}
  </div>`;
}
function openPhotoModal(){
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${t("addPhoto")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("photoCaption")}</label><input id="ph-cap" placeholder="${esc(t("photoCaption"))}">
    <button class="btn" id="ph-save">${t("save")}</button>
    <button class="btn ghost" id="ph-x">${t("close")}</button>`);
  let url="";
  wirePhotoPicker(wrap, ()=>url, v=>{ url=v; });
  wrap.querySelector("#ph-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ph-save").onclick=async ()=>{
    if(!url){ toastWarn(t("uploadPhoto")); return; }
    try{
      await DB.addPhoto({url, caption:wrap.querySelector("#ph-cap").value.trim(),
        day:todayIndex(), created_by:S.session.username||S.session.name||""});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* ================= FEEDBACK -> REVIEW ================= */
function reviewLinks(){
  const st=S.settings;
  return [["google",st.google],["tripadvisor",st.tripadvisor],["holidaycheck",st.holidaycheck]]
    .filter(([k,v])=>v&&/^https?:\/\//i.test(v));
}
/* After a happy rating, invite the guest to post it publicly. */
function openReviewInvite(rate){
  const links=reviewLinks();
  if(!links.length || S.settings.reviewAsk===false) return;
  if(rate<4) return;                       // unhappy guests are never pushed outside
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("thankYou")}</h3>
    <p class="mini">${t("shareExp")}</p>
    <div style="margin-top:14px">
      ${links.map(([k,v])=>`<a class="btn" href="${esc(v)}" target="_blank" rel="noopener"
        style="display:block;text-align:center;margin-bottom:8px">${k==="google"?"Google":k==="tripadvisor"?"Tripadvisor":"HolidayCheck"}</a>`).join("")}
    </div>
    <button class="btn ghost" id="rv-x">${t("reviewLater")}</button>`);
  wrap.querySelector("#rv-x").onclick=()=>wrap.remove();
}
/* ================= TEAM ATTENDANCE =================
   P = present · O = day off · A = absent
   Normal days are worked out from the duty plan, so only real
   exceptions are stored. Tapping a cell cycles P -> O -> A -> auto. */
const ATT_CYCLE=["P","O","A","V"];
function monthKey(d){ d=d||hotelNow(); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"); }
function currentAttMonth(){ return S.attMonth || monthKey(hotelNow()); }
function monthDays(mk){
  const [y,m]=mk.split("-").map(Number);
  return new Date(y, m, 0).getDate();               // last day of that month
}
function monthLabel(mk){
  const [y,m]=mk.split("-").map(Number);
  const names=t("months");
  const nm=(Array.isArray(names)&&names[m-1])?names[m-1]:String(m);
  return nm+" "+y;
}
function dateStr(mk,day){ return mk+"-"+String(day).padStart(2,"0"); }
function shiftMonth(mk,delta){
  const [y,m]=mk.split("-").map(Number);
  const d=new Date(y, m-1+delta, 1);
  return monthKey(d);
}
function weekdayOf(mk,day){
  const [y,m]=mk.split("-").map(Number);
  return (new Date(y,m-1,day).getDay()+6)%7;        // 0 = Monday
}
/* what the plan says for this person on this date */
/* Before someone's hire date they simply were not employed — that shows as N
   and is never counted as present, day off or absent. */
/* Someone who left the hotel keeps every day they worked; days after their
   leaving date are blank, and their number is free for the next person. */
function hasLeft(user){ return !!(user && (user.archived || String(user.left_date||"").trim())); }
function leftBefore(user, mk, day){
  const ld=String(user && user.left_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(ld)) return false;
  return dateStr(mk,day) > ld;
}
function notYetHired(user, mk, day){
  const hd=String(user && user.hire_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(hd)) return false;
  return dateStr(mk,day) < hd;
}
function attAuto(user, mk, day){
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return "N";
  if(isAttOnly(user)) return "P";        // not on the weekly rota — she marks them herself
  let num=user.number; if(!num && user.role==="manager") num=1;
  if(!num) return "P";
  const dp=dayPlanFor(weekdayOf(mk,day));
  return dp.off.includes(num) ? "O" : "P";
}
/* the value actually shown: a manual mark wins, otherwise the plan */
/* Days in the future have not happened yet — they are blank, never counted. */
function isFutureDay(mk, day){ return dateStr(mk,day) > hotelDateStr(); }
function daysSoFar(mk){
  const n=monthDays(mk);
  const today=hotelDateStr();
  if(mk > today.slice(0,7)) return 0;           // month not started
  if(mk < today.slice(0,7)) return n;           // month already finished
  return Math.min(n, +today.slice(8,10));        // current month -> up to today
}
function attStatus(user, mk, day){
  if(notYetHired(user,mk,day)) return "N";      // had not started yet
  if(leftBefore(user,mk,day)) return "N";       // already finished
  if(isFutureDay(mk,day)){
    /* nothing is assumed about a future day, but a holiday she has already
       planned should be visible */
    const dfut=dateStr(mk,day);
    const planned=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===dfut);
    return planned ? planned.status : "";
  }
  const d=dateStr(mk,day);
  const row=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===d);
  return row ? row.status : attAuto(user,mk,day);
}
function attIsManual(user, mk, day){
  const d=dateStr(mk,day);
  return S.staffAtt.some(x=>x.username===user.username && String(x.date).slice(0,10)===d);
}
/* one tap: P -> O -> A -> automatic */
function attNext(user, mk, day){
  if(isFutureDay(mk,day)) return undefined;     // cannot mark a day that has not come
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return undefined; // not employed that day
  if(!attIsManual(user,mk,day)) return "P";
  const cur=attStatus(user,mk,day);
  const i=ATT_CYCLE.indexOf(cur);
  return (i<0 || i===ATT_CYCLE.length-1) ? null : ATT_CYCLE[i+1];
}
/* Totals across the whole team for the month */
function attMonthTotals(mk){
  const team=attTeamFor(mk); const sum={P:0,O:0,A:0,V:0,N:0};
  team.forEach(u=>{ const x=attTotals(u,mk); sum.P+=x.P; sum.O+=x.O; sum.A+=x.A; sum.V+=x.V; sum.N+=x.N; });
  return {...sum, people:team.length, days:daysSoFar(mk),
          working:sum.P, avg:team.length?Math.round(sum.P/team.length*10)/10:0};
}
/* The attendance sheet still lists people who left, so their record is kept.
   Everywhere else they are gone. */
function attTeam(){ return attTeamFor(currentAttMonth()); }
function attTeamFor(mk){
  return (S.users||[]).filter(u=>{
      if(u.role!=="staff" && u.role!=="manager" && u.role!=="attendance") return false;
      const hd=String(u.hire_date||"").slice(0,7);
      if(hd && hd>mk) return false;               // had not started in that month
      if(!hasLeft(u)) return true;
      const ld=String(u.left_date||"").slice(0,7);
      return !ld || ld>=mk;                       // show them in the months they worked
    })
    .slice().sort((a,b)=>(a.number||99)-(b.number||99));
}
/* month totals per person */
function attTotals(user, mk){
  const n=daysSoFar(mk); const c={P:0,O:0,A:0,V:0,N:0,days:n};
  for(let d=1;d<=n;d++){ const st=attStatus(user,mk,d); if(c[st]!==undefined) c[st]++; }
  c.days=n-c.N;                                  // only days they were actually employed
  return c;
}
function monthAttInner(){
  const __vacBtn=`<div class="att-tools">
    <button class="btn sm ghost" id="att-vac">${ic("sun",15)} ${t("setVacation")}</button>
    <button class="btn sm ghost" id="att-only">${ic("user",15)} ${t("addAttOnly")}</button>
  </div>`;
  const mk=currentAttMonth(), n=monthDays(mk), team=attTeamFor(mk);
  const todayMk=monthKey(hotelNow()), todayD=hotelNow().getDate();
  const head=Array.from({length:n},(_,i)=>{
    const d=i+1,wd=weekdayOf(mk,d),isToday=(mk===todayMk&&d===todayD);
    return `<th class="${wd>=5?"we":""} ${isToday?"td":""}">${d}<span>${(t("daysShort")[wd]||"").slice(0,2)}</span></th>`;
  }).join("");
  const rows=team.map(u=>{
    const tot=attTotals(u,mk),attTag=isAttOnly(u)?` <span class="att-only-tag">${t("attOnlyTag")}</span>`:"";
    const cells=Array.from({length:n},(_,i)=>{
      const d=i+1;
      if(notYetHired(u,mk,d)||leftBefore(u,mk,d))return `<td><span class="att-c notyet">N</span></td>`;
      if(isFutureDay(mk,d)){
        const st=attStatus(u,mk,d);
        return st?`<td><span class="att-c s-${st} planned" title="${esc(t("plannedAhead"))}">${st}</span></td>`:`<td><span class="att-c future">·</span></td>`;
      }
      const st=attStatus(u,mk,d),manual=attIsManual(u,mk,d);
      return `<td><button class="att-c s-${st} ${manual?"man":"auto"}" data-satt="${esc(u.username)}|${mk}|${d}" title="${esc(t("att"+st)||st)}">${st}</button></td>`;
    }).join("");
    return `<tr><th class="att-name${isAttOnly(u)?" tapname":""}"${isAttOnly(u)?` data-attedit="${u.id}"`:""}><b>${esc(u.display_name||u.username)}</b><span class="mini">${u.number?"#"+u.number:""}${attTag}</span></th>${cells}
      <td class="att-tot"><span class="s-P">${tot.P}</span></td><td class="att-tot"><span class="s-O">${tot.O}</span></td><td class="att-tot"><span class="s-A">${tot.A}</span></td><td class="att-tot"><span class="s-V">${tot.V}</span></td></tr>`;
  }).join("");
  const mt=attMonthTotals(mk);
  return `${__vacBtn}<div class="att-head">
    <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button><b class="att-month">${esc(monthLabel(mk))}</b><button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button></div>
    <p class="mini att-legend">P = present · O = day off · A = absent · V = vacation · N = not counted</p>
    ${team.length?`<div class="card attsum"><span class="type-meta">${t("monthTotals")}</span>
      <div class="as-row as-row-v625">
        <div class="as-n total"><b>${mt.people}</b><span class="mini">${t("totalTeam")}</span></div>
        <div class="as-n p"><b>${mt.working}</b><span class="mini">${t("workingToday")} days</span></div>
        <div class="as-n o"><b>${mt.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${mt.A}</b><span class="mini">${t("attTotalsA")}</span></div>
        <div class="as-n vac"><b>${mt.V}</b><span class="mini">${t("attV")} days</span></div>
      </div>
      <p class="mini" style="margin:10px 0 0">${t("avgPerPerson")}: <b>${mt.avg}</b> ${t("workDays").toLowerCase()} · ${t("countedDays")}: <b>${mt.days}</b>/${monthDays(mk)}</p></div>`:""}
    ${team.length?`<div class="att-scroll"><table class="att-table"><thead><tr><th class="att-name"></th>${head}<th class="att-tot">P</th><th class="att-tot">O</th><th class="att-tot">A</th><th class="att-tot">V</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<div class="card"><p class="mini">—</p></div>`}
    <button class="btn" id="att-export" style="margin-top:14px">${ic("download",16)} ${t("attExport")}</button>`;
}

/* ================= DAILY QUIZ ================= */
/* one definition, on the hotel clock */
function todayISO(){ return hotelDateStr(); }
function quizForToday(audience){
  const today=todayISO();
  return (S.quizzes||[]).find(q=>q.audience===audience && String(q.quiz_date).slice(0,10)===today && q.active!==false)||null;
}
function myQuizKey(){
  if(!S.session) return "";
  return S.session.role==="guest" ? String(S.session.room||"") : String(S.session.username||"");
}
function myQuizReply(quizId){
  const me=myQuizKey();
  return (S.quizReplies||[]).find(r=>r.quiz_id===quizId && String(r.who)===me)||null;
}
/* The card guests and entertainers see */
function quizView(){
  const aud = S.session.role==="guest" ? "guest" : "staff";
  const q = quizForToday(aud);
  if(!q){
    return `<div class="screen fadein">
      ${topBar(t("quizTab"),"")}
      <div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("quizNone")}</div>
    </div>`;
  }
  const mine=myQuizReply(q.id);
  return `<div class="screen fadein">
    ${topBar(t("quizTab"),"")}
    <div class="card quizcard">
      <span class="type-meta">${t("quizToday")}</span>
      <h3 class="quiz-q">${esc(q.question)}</h3>
      ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
      ${mine?`<div class="quiz-done">${ic("check",18)} <div><b>${t("quizDone")}</b>
          <span class="mini">${t("quizMine")}: ${esc(mine.answer)}</span></div></div>`
        :`<textarea id="qz-ans" rows="3" placeholder="${esc(t("quizAnswerPh"))}" style="margin-top:12px"></textarea>
          <button class="btn" id="qz-send">${ic("sparkle",16)} ${t("quizSend")}</button>`}
    </div>
  </div>`;
}
async function submitQuizAnswer(){
  const q=quizForToday(S.session.role==="guest"?"guest":"staff"); if(!q) return;
  if(myQuizReply(q.id)){ toastWarn(t("quizAlready")); return; }
  const el=$("#qz-ans"); const val=el?el.value.trim():"";
  if(!val){ toastWarn(t("fieldRequired")); return; }
  try{
    await DB.addQuizReply({quiz_id:q.id, who:myQuizKey(), who_name:S.session.name||"",
      audience:S.session.role==="guest"?"guest":"staff", answer:val});
    toastOk(t("quizDone")); render();
  }catch(e){ toastErr(t("errSave")); }
}
/* Manager: write the question and read every answer */
function quizCenterView(){
  const today=todayISO();
  const gq=quizForToday("guest"), sq=quizForToday("staff");
  const block=(aud,q)=>{
    const replies=q?(S.quizReplies||[]).filter(r=>r.quiz_id===q.id):[];
    return `<div class="sec">
      <h3>${ic("sparkle",18)} ${aud==="guest"?t("quizForGuest"):t("quizForStaff")}</h3>
      ${q?`<div class="card quizcard">
        <h3 class="quiz-q">${esc(q.question)}</h3>
        ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
        ${q.answer_key?`<p class="mini"><b>${t("quizKey")}:</b> ${esc(q.answer_key)}</p>`:""}
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="btn sm ghost" data-quizedit="${q.id}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-quizdel="${q.id}">${ic("trash",14)}</button>
        </div>
      </div>
      <h3 style="margin-top:14px">${t("quizReplies")} (${replies.length})</h3>
      ${replies.length?`<div class="card qr-card">${replies.map(r=>`
        <div class="qr-row"><span class="qr-who">${esc(r.who_name||r.who)}${r.audience==="guest"?` · ${esc(r.who)}`:""}</span>
          <span class="qr-ans">${esc(r.answer)}</span>
          <span class="mini">${fmtDate(r.created_at)}</span></div>`).join("")}</div>`
        :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNoReplies")}</p></div>`}`
      :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNone")}</p>
          <button class="btn sm" data-quiznew="${aud}" style="margin-top:10px">${ic("plus",14)} ${t("quizNew")}</button></div>`}
    </div>`;
  };
  return `<div class="screen fadein">
    ${topBar(t("quizCenter"),today)}
    ${hubBack()}
    ${block("guest",gq)}
    ${block("staff",sq)}
  </div>`;
}
function openQuizModal(quiz, audience){
  const editing=!!quiz;
  const q=quiz||{audience:audience||"guest",question:"",hint:"",answer_key:"",quiz_date:todayISO(),active:true};
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${editing?t("quizQuestion"):t("quizNew")}</h3>
    <label>${t("quizFor")}</label>
    <select id="qz-aud">
      <option value="guest" ${q.audience==="guest"?"selected":""}>${t("quizForGuest")}</option>
      <option value="staff" ${q.audience==="staff"?"selected":""}>${t("quizForStaff")}</option>
    </select>
    <label>${t("quizQuestion")}</label>
    <textarea id="qz-q" rows="3">${esc(q.question)}</textarea>
    <label>${t("quizHint")}</label><input id="qz-h" value="${esc(q.hint||"")}">
    <label>${t("quizKey")}</label><input id="qz-k" value="${esc(q.answer_key||"")}">
    <button class="btn" id="qz-save">${t("save")}</button>
    <button class="btn ghost" id="qz-x">${t("close")}</button>`);
  wrap.querySelector("#qz-x").onclick=()=>wrap.remove();
  wrap.querySelector("#qz-save").onclick=async ()=>{
    const rec={audience:wrap.querySelector("#qz-aud").value,
      question:wrap.querySelector("#qz-q").value.trim(),
      hint:wrap.querySelector("#qz-h").value.trim(),
      answer_key:wrap.querySelector("#qz-k").value.trim(),
      quiz_date:q.quiz_date||todayISO(), active:true};
    if(!rec.question){ toastWarn(t("fieldRequired")); return; }
    if(editing) rec.id=q.id;
    try{ await DB.saveQuiz(rec); wrap.remove(); toastOk(t("quizSaved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function busView(){
  const empty=!(S.buses||[]).length;
  return `<div class="screen fadein">
    ${topBar(t("busSchedule"),"")}
    ${hubBack()}
    ${empty && S.session.role!=="manager"?`<div class="empty"><div class="big">${ic("bus",30)}</div>${t("noBusTimes")}</div>`:`
      <div class="bus-grid">
        ${busColumn("toHotel", 1)}
        ${busColumn("toHouse", -1)}
      </div>`}
  </div>`;
}
/* Manager edits who is off and who has entrance duty for a weekday.
   Saved as an override on top of the standard rotation. */
function openDutyModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("clipboard",20)} ${t("editDayOff")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b>${dayIsCustom(day)?` · ${t("customDay")}`:` · ${t("standardDay")}`}</p>
    <label style="margin-top:10px">${t("selectDayOff")}</label>
    <div class="duty-list">
      ${roster.map(r=>`<label class="duty-it">
        <input type="checkbox" class="duty-off" value="${r.n}" ${dp.off.includes(r.n)?"checked":""}>
        <span class="duty-n">${r.n}</span>
        <span class="duty-nm">${esc(r.name||r.role)}</span></label>`).join("")}
    </div>
    <button class="btn" id="duty-save">${t("save")}</button>
    ${dayIsCustom(day)?`<button class="btn ghost" id="duty-reset">${ic("back",15)} ${t("resetDefault")}</button>`:""}
    <button class="btn ghost" id="duty-x">${t("close")}</button>`);
  wrap.querySelector("#duty-x").onclick=()=>wrap.remove();
  wrap.querySelector("#duty-save").onclick=async ()=>{
    const off=[...wrap.querySelectorAll(".duty-off")].filter(b=>b.checked).map(b=>+b.value);
    const ov={off, entrance: dp.entrance};      // entrance is set in Assignments
    const all={...(S.settings.dayOverrides||{})};
    all[String(day)]=ov;
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  const rst=wrap.querySelector("#duty-reset");
  if(rst) rst.onclick=async ()=>{
    const all={...(S.settings.dayOverrides||{})};
    delete all[String(day)];
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openBusModal(bus, dir){
  const editing=!!bus;
  const b=bus||{direction:dir||"toHotel",time:"08:00",note:""};
  const wrap=baseModal(`
    <h3>${ic("bus",20)} ${editing?t("editBus"):t("addBus")}</h3>
    <label>${t("busDirection")}</label>
    <select id="bs-dir">
      <option value="toHotel" ${b.direction==="toHotel"?"selected":""}>${t("busToHotel")}</option>
      <option value="toHouse" ${b.direction==="toHouse"?"selected":""}>${t("busToHouse")}</option>
    </select>
    <label>${t("busTimeLbl")}</label>
    <input id="bs-time" value="${esc(b.time||"")}" placeholder="08:00">
    <label>${t("busNoteLbl")}</label>
    <input id="bs-note" value="${esc(b.note||"")}" placeholder="${esc(t("busNoteHint"))}">
    <button class="btn" id="bs-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="bs-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="bs-x">${t("close")}</button>`);
  wrap.querySelector("#bs-x").onclick=()=>wrap.remove();
  wrap.querySelector("#bs-save").onclick=async ()=>{
    const rec={direction:wrap.querySelector("#bs-dir").value,
      time:wrap.querySelector("#bs-time").value.trim(),
      note:wrap.querySelector("#bs-note").value.trim(),
      sort:busMinutes(wrap.querySelector("#bs-time").value.trim())};
    if(!rec.time){ return; }
    if(editing) rec.id=b.id;
    await DB.saveBus(rec);
    wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#bs-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delBusQ"),danger:true})) return;
    try{ await DB.deleteBus(b.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function dayChips(){
  const today=todayIndex();
  const sel=(typeof S.planDay==="number")?S.planDay:today;
  return `<div class="daychips">${t("daysShort").map((d,i)=>`<button class="daychip ${sel===i?"on":""} ${i===today?"istoday":""}" data-planday="${i}">${d}</button>`).join("")}</div>`;
}
function myWorkDayView(){
  const num=S.session.number;
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  if(!num){
    return `<div class="screen fadein">
      ${topBar(t("myWorkDay"),S.session.name)}
      ${dayChips()}
      <div class="empty"><div class="big">${ic("users",30)}</div>${t("noNumber")}</div>
      ${workdayUnifiedTimeline(day,[])}
      ${workdayFeedbackCard()}
      ${dayPlanStandards(day)}
    </div>`;
  }
  const info=personDayInfo(num,day);
  const unavailableToday=info.isOff||info.isVacation||info.isAbsent;
  const myActs=(unavailableToday?[]:S.activities.filter(a=>a.day===day && canSeeGuests(a))).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  const liveAct = isToday(day) ? (myActs.find(a=>activityStatus(a)==="live") || myActs.find(a=>activityStatus(a)==="todo") || myActs[myActs.length-1]) : null;
  const photoRing = liveAct ? statusRing(liveAct) : "";
  const photoBlock = `<div class="wd-photo">
      <div class="wd-av avring ${photoRing}">${S.session.photo?`<img src="${esc(S.session.photo)}" alt="">`:`<span>${esc(String(S.session.name||"?").trim().charAt(0).toUpperCase())}</span>`}
        <span class="wd-num">${num}</span></div>
      <div class="wd-who"><b>${esc(S.session.name)}</b>
        <span class="mini">${esc(roleForNumber(num))}</span>
        ${liveAct?`<span style="margin-top:4px">${statusPill(liveAct)} <span class="mini">${esc(liveAct.name)}</span></span>`:""}</div>
    </div>`;
  let banner="";
  if(info.isVacation){
    banner=`<div class="wd-banner off">${ic("sun",22)} You are on vacation today — enjoy your holiday ☀️</div>`;
  }else if(info.isAbsent){
    banner=`<div class="wd-banner off">${ic("user",22)} You are marked absent today.</div>`;
  }else if(info.isOff){
    const nd=(day+1)%7, nu=info.u, tomorrowWorking=nu?availableOn(nu,nd,(typeof dayDutyDate==="function"?dayDutyDate(nd):assignDateStr(nd))):true;
    banner=`<div class="wd-banner off">${ic("sun",22)} Have a nice day — today is your day off. Enjoy${tomorrowWorking?", but sleep early — you have work tomorrow :)":" your day off :)"}</div>`;
  }else if(info.isEntrance){
    banner=`<div class="wd-banner entrance">${ic("door",20)} ${t("youHaveEntrance")} · ${esc(info.entranceWindow)}</div>`;
  }
  return `<div class="screen fadein workday-clean">
    ${topBar(t("myWorkDay"),"#"+num+" · "+S.session.name)}
    ${dayChips()}
    ${photoBlock}
    ${banner}
    ${info.makeupForMe?`<div class="wd-banner makeup">${ic("star",18)} ${t("makeupPractice")}: ${esc(makeupText(info.makeupForMe))}</div>`:""}
    ${info.isDJ?`<div class="wd-banner dj">${ic("bell",18)} ${t("djSchedule")}: ${esc(info.djNote)}</div>`:""}
    ${workdayUnifiedTimeline(day,myActs)}
    ${workdayCompactInfo(day)}
    ${workdayFeedbackCard()}
    ${dayPlanStandards(day)}
  </div>`;
}
function taskDueMinutes(x){
  if(!x || !x.due) return 24*60+1;
  const d=new Date(String(x.due).replace(" ","T"));
  if(isNaN(d.getTime())) return 24*60+1;
  return d.getHours()*60+d.getMinutes();
}
function taskBelongsToDay(x,day){
  if(!x || !(x.assigned_to===S.session.username || !x.assigned_to || x.assigned_to==="team")) return false;
  if(["verified"].includes(taskStatus(x))) return false;
  const target=assignDateStr(day);
  if(x.due){
    const d=new Date(String(x.due).replace(" ","T"));
    if(!isNaN(d.getTime())) return localDateKey(d)===target;
  }
  return isToday(day) && ["new","accepted","progress"].includes(taskStatus(x));
}
function workdayUnifiedTimeline(day,acts){
  const activityItems=(acts||[]).map(a=>({kind:"activity",sort:timeToMin(a.time)??9999,a}));
  const taskItems=(S.tasks||[]).filter(x=>taskBelongsToDay(x,day)).map(x=>({kind:"task",sort:taskDueMinutes(x),x}));
  const items=activityItems.concat(taskItems).sort((a,b)=>a.sort-b.sort);
  return `<div class="sec workday-yourday"><h3>${ic("clock",18)} ${t("yourDay")}</h3>
    <p class="mini wd-sub">Activities and manager tasks in one place.</p>
    ${items.length?`<div class="tlx unified">${items.map(it=>{
      if(it.kind==="task"){
        const x=it.x, st=taskStatus(x), over=taskIsOverdue(x);
        const due=x.due?new Date(String(x.due).replace(" ","T")):null;
        const tm=due&&!isNaN(due.getTime())?fmtTime(due.toISOString()):"";
        return `<div class="tlx-row task ${st} ${over?"overdue":""}">
          <span class="tlx-mark">${ic("check",12)}</span>
          <div class="tlx-body task-body" data-taskopen="${x.id}">
            <span class="eyebrow">${t("tasks")}</span>
            <b>${esc(x.title||x.type||t("tasks"))}</b>
            <span class="mini">${tm?esc(tm)+(x.location?" · "+esc(x.location):""):(x.location?esc(x.location):"")}</span>
            ${x.desc?`<span class="mini">${esc(x.desc)}</span>`:""}
            <span class="task-inline-status">${taskStatusLabel(st)}</span>
          </div>
        </div>`;
      }
      const a=it.a, st=isToday(day)?activityStatus(a):"todo", booked=seatsTaken(a.id);
      return `<div class="tlx-row ${st}">
        <span class="tlx-mark">${st==="done"?ic("check",13):(st==="live"?"":"")}</span>
        <div class="tlx-body" data-actopen="${esc(String(a.id))}">
          ${st==="live"?`<span class="eyebrow tlx-now">${t("nowLbl")}</span>`:""}
          <span class="eyebrow">${t("activities")||"Activity"}</span>
          <b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" · "+esc(a.location):""}</span>
          ${booked?`<span class="mini">${booked} ${t("registered")}</span>`:""}
        </div>
      </div>`;
    }).join("")}</div>`:`<div class="empty compact-empty">${t("noneToday")}</div>`}
  </div>`;
}
function workdayCompactInfo(day){
  const dp=dayPlanFor(day);
  const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
    .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
  return `<div class="sec wd-dayinfo"><h3>${ic("calendar",18)} ${t("dayInfoSec")}</h3>
    <div class="card wd-info-compact">
      <div><span>${t("dressCode")}</span><b>${esc(dp.dress||"—")}</b></div>
      <div><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>${dp.showTime?`<small>${esc(dp.showTime)}</small>`:""}</div>
      <div><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
      <div><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
      ${evs.length?`<div class="wide"><span>${t("eventsToday")}</span><b>${evs.map(e=>esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])+" · "+esc(e.name)).join("<br>")}</b></div>`:""}
    </div>
  </div>`;
}
/* Collecting guest feedback is a daily job, so it sits inside the work day
   rather than behind a menu item they would have to go looking for. */
function workdayFeedbackCard(){
  const me=(S.session&&S.session.username)||"";
  const mine=(S.feedback||[]).filter(f=>String(f.by_user||"")===String(me))
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const today=mine.filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    return ts && !isNaN(ts.getTime()) && localDateKey(ts)===localDateKey(new Date());
  });
  return `<div class="sec wd-feedback-compact">
    <div class="wd-fb-head"><div><h3>${ic("star",18)} ${t("fbMyFeedback")}</h3><p class="mini">${today.length} ${t("today")} · ${mine.length} ${t("feedback")}</p></div>
      <button class="btn sm" id="btn-addfb">＋ ${t("fbNew")}</button></div>
  </div>`;
}
/* full day detail: theme, dress, timings, show — used by staff + manager */
/* The day's special events (day events + parties) pulled from the real programme */
function staffFeedbackView(){
  const mine=S.feedback.filter(f=>f.by_user===S.session.username);
  return `<div class="screen fadein">
    ${topBar(t("feedback"),S.session.name)}
    <button class="btn" id="btn-addfb" style="margin:0 0 14px">\uFF0B ${t("fbNew")}</button>
    ${mine.length?`<p class="mini" style="margin:-4px 0 8px">${t("fbTapHint")}</p>
      <div class="card">${mine.map(fbRowHtml).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("star",30)}</div>${t("noMyFeedback")}</div>`}
  </div>`;
}
function chatThreadScreen(){
  const isStaff=String(S.chatRoom).startsWith("staff:");
  let title,sub;
  if(isStaff){ const un=S.chatRoom.slice(6); const u=S.users.find(x=>x.username===un);
    title=(u&&u.display_name)||un; sub=t("staff"); }
  else { title=accountName(S.chatRoom); sub=t("room")+" "+S.chatRoom; }
  return `<div class="screen fadein">
    <div class="top">
      <div class="who" style="display:flex;align-items:center;gap:10px">
        <button class="iconbtn" id="btn-chatback" aria-label="back">${ic("back",20)}</button>
        <div><h2 style="font-size:22px">${esc(title)}</h2><p>${esc(sub)}</p></div>
      </div>
    </div>
    ${chatTools(S.chatRoom)}
    ${threadView(S.chatRoom,"team")}
  </div>`;
}
/* Tidying a conversation: pick a few messages, or empty it completely. */
function chatSelOn(){ return Array.isArray(S.chatSel); }
function chatSelHas(id){ return chatSelOn() && S.chatSel.includes(id); }
function chatTools(room){
  if(!S.session || S.session.role!=="manager") return "";
  const total=(S.messages||[]).filter(m=>m.room===room).length;
  if(!total) return "";
  if(!chatSelOn()){
    return `<div class="chat-tools">
      <button class="btn sm ghost" id="ct-select">${ic("check",14)} ${t("selectMsgs")}</button>
      <button class="btn sm ghost warn" id="ct-clear">${ic("trash",14)} ${t("clearChat")}</button>
    </div>`;
  }
  const n=S.chatSel.length;
  return `<div class="chat-tools sel">
    <span class="ct-n">${n} ${t("selectedWord")}</span>
    <button class="btn sm ghost" id="ct-all">${n===total?t("selectNone"):t("selectAll")}</button>
    <button class="btn sm warn" id="ct-del" ${n?"":"disabled"}>${ic("trash",14)} ${t("delete")}</button>
    <button class="btn sm ghost" id="ct-cancel">${t("cancelBtn")}</button>
  </div>`;
}
function staffChatInbox(){
  const staff=S.users.filter(u=>u.role==="staff");
  const rows=staff.map(u=>{
    const room="staff:"+u.username;
    const ms=S.messages.filter(m=>m.room===room);
    const last=ms[ms.length-1];
    const unread=ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length;
    return {u,room,last,unread,ts:last?Date.parse(last.created_at):0};
  }).sort((a,b)=>b.ts-a.ts);
  return `<div class="chatlist">
    ${rows.map(c=>`<div class="card" data-staffchat="${esc(c.u.username)}">
      <div class="mb-av" style="width:44px;height:44px;flex:none">${esc((c.u.display_name||c.u.username).trim().charAt(0).toUpperCase())}</div>
      <div style="min-width:0;flex:1">
        <div class="nm">${esc(c.u.display_name||c.u.username)}</div>
        <div class="lastm">${c.last?esc(c.last.text):"—"}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
        ${c.last?`<span class="mini">${fmtTime(c.last.created_at)}</span>`:""}
        ${c.unread?`<span class="badge">${c.unread}</span>`:""}
      </div>
    </div>`).join("")||`<div class="empty"><div class="big">${ic("users",34)}</div>${t("none")}</div>`}
  </div>`;
}
/* A room name starting with "staff:" is an entertainer thread — it belongs
   in Team, never in the guest inbox. */
function isStaffRoom(room){ return String(room||"").startsWith("staff:"); }
function chatInboxInner(){
  const rooms={};
  S.messages.filter(m=>!isStaffRoom(m.room)).forEach(m=>{ (rooms[m.room]=rooms[m.room]||[]).push(m); });
  const list=Object.entries(rooms).map(([room,ms])=>({room,last:ms[ms.length-1],
    unread:ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length}))
    .sort((a,b)=>new Date(b.last.created_at)-new Date(a.last.created_at));
  return `<div class="chatlist">
      ${list.length?list.map(c=>`<div class="card" data-chatroom="${esc(c.room)}">
        <div style="min-width:0">
          <div class="nm">${esc(accountName(c.room))} <span class="mini">· ${t("room")} ${esc(c.room)}</span></div>
          <div class="lastm">${esc(c.last.text)}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
          <span class="mini">${fmtTime(c.last.created_at)}</span>
          ${c.unread?`<span class="badge">${c.unread}</span>`:""}
        </div>
      </div>`).join(""):`<div class="empty"><div class="big">${ic("chat",34)}</div>${t("noMessages")}</div>`}
    </div>`;
}
function bookingsView(title){
  return `<div class="screen fadein">
    ${topBar(title,t("days")[S.day])}
    ${bookingsInner()}
  </div>`;
}
function bookingsInner(){
  const isMgr=S.session.role==="manager";
  let acts=S.activities.filter(a=>a.day===S.day);
  if(!isMgr) acts=acts.filter(a=>canSeeGuests(a));
  return dayTabs() + (acts.length?acts.sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>{
    const bks=bookingsFor(a.id);
    const visible=canSeeGuests(a);
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:${visible&&bks.length?8:0}px;gap:8px">
        <h4 style="font-size:17px;min-width:0">${visible?"":mi("lock")}${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></h4>
        <span class="pill">${a.capacity>0?seatsTaken(a.id)+"/"+a.capacity:bks.length+" "+t("guests")}</span></div>
      ${visible?bks.map(b=>`<div class="booking-line">
        <span style="min-width:0" ${isMgr&&accountForRoom(b.room)?`data-bkguest="${accountForRoom(b.room).id}"`:""}><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}${isMgr&&b.nationality?` · ${esc(b.nationality)}`:""}${isMgr&&b.phone?` · ${esc(b.phone)}`:""}
          ${b.created_at?`<br><span class="mini">${whenLabel(b.created_at)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="pill">${((+b.adults)||0)+((+b.children)||0)} ${t("personsShort")}${b.status==="waitlist"?" · …":""}</span>
          ${isMgr?`<button class="btn sm ghost" data-bkedit="${b.id}" aria-label="${t("editBooking")}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-bkdel="${b.id}" aria-label="${t("removeBooking")}">${ic("close",14)}</button>`:""}
        </span></div>`).join(""):""}
    </div>`;}).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
/* ---------------- manager (full access — manager role only) ---------------- */
function managerView(){
  if(S.tab==="dash") return dashView();
  if(S.tab==="req") return requirementsView();
  if(S.tab==="program"){
    const inner = S.sub.program==="tickets" ? managerTicketsInner()
      : S.sub.program==="performance" ? performanceAttendanceInner636()
      : managerActsInner();
    return `<div class="screen fadein">
      ${topBar(t("manage"),S.session.name)}
      ${arrangeBtn("program")}
      ${subTabs("program",[["acts",t("activities")],["tickets",t("tickets")],["performance","Shows / Events Attendance"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="guests"){
    const sub=S.sub.guests;
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    let inner="";
    if(sub==="history") inner=(typeof window.guestHistoryInnerV619==="function" ? window.guestHistoryInnerV619() : `<div class="empty">Guest history is loading…</div>`);
    else if(sub==="rooms") inner=roomsInner();
    else if(sub==="crm") inner=guestCrmInner();
    else if(sub==="bookings") inner=bookingsInner();
    else if(sub==="tickets") inner=(typeof window.guestTicketsManagerInnerV620==="function" ? window.guestTicketsManagerInnerV620() : `<div class="empty">Tickets are loading…</div>`);
    else if(sub==="chat") inner=chatInboxInner();
    else if(sub==="feedback") inner=feedbackInner();
    else inner=requestsInner();
    const gTabs=[["crm",t("guestCrm")],["rooms",t("rooms")],["bookings",t("bookings")],["tickets",t("tickets")],
                 ["chat",t("guestChatTab")],["requests",t("requests")],["feedback",t("feedback")],["history","Guest history"]];
    return `<div class="screen fadein">
      ${topBar(t("guestsTab"),S.session.name)}
      ${arrangeBtn("guests")}
      ${subTabs("guests",gTabs)}
      ${inner}
    </div>`;
  }
  if(String(S.tab||"").startsWith("g360:")) return guest360View(S.tab.slice(5));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="dayplan") return managerDayPlanView();
  if(S.tab==="bus") return busView();
  if(S.tab==="quiz") return quizCenterView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  if(S.tab==="qr") return qrView();
  if(S.tab==="weather") return weatherView();
  if(S.tab==="assign") return assignView();
  if(S.tab==="builder") return builderView();
  if(S.tab==="pagedesign") return pageDesignView();
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(S.tab==="settings") return settingsHubView();
  if(String(S.tab||"").startsWith("set:")){
    const k=S.tab.slice(4);
    if(k==="theme")    return setThemeView();
    if(k==="publictext") return setPublicExperienceView639();
    if(k==="brand")    return setBrandView();
    if(k==="features") return setFeaturesView();
    if(k==="location") return setLocationView();
    if(k==="links")    return setLinksView();
    if(k==="advanced") return setAdvancedView();
    if(k==="notif")    return setNotifView();
    return settingsHubView();
  }
  if(S.tab==="team"){
    let sub=S.sub.team;
    if(["tasks","profiles"].includes(sub)) sub=S.sub.team="accounts";  // moved to Assignments
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    const inner = sub==="requests" ? teamRequestsInner() : sub==="monthatt" ? monthAttInner() : sub==="attendance" ? attendanceInner()
      : sub==="payroll" ? payrollManagerInner630() : sub==="chat" ? staffChatInbox() : accountsInner();
    return `<div class="screen fadein">
      ${topBar(t("teamTab"),S.session.name)}
      ${arrangeBtn("team")}
      ${subTabs("team",[["accounts",t("teamAccounts")],["chat",t("teamChatTab")],["requests",t("teamRequests")],["monthatt",t("monthAtt")],["attendance",t("attendance")],["payroll","Payroll"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="ai") return aiView();
  return dashView();   // unknown tab: go home, never Settings
}
/* Totals for the chosen day + the button to change duty */
function dutyBar(day){
  const st=dayDutyStats(day);
  const names=list=>(list||[]).map(u=>esc(u.display_name||u.username)).join(", ")||"—";
  return `<div class="card dutybar">
    <div class="db-nums db-nums-five">
      <div class="db-n"><b>${st.total}</b><span class="mini">${t("totalTeam")}</span></div>
      <div class="db-n ok"><b>${st.workingCount}</b><span class="mini">${t("workingToday")}</span></div>
      <div class="db-n off"><b>${st.offCount}</b><span class="mini">${t("dayOffToday")}</span></div>
      <div class="db-n absent"><b>${st.absentCount}</b><span class="mini">${t("attA")}</span></div>
      <div class="db-n vac"><b>${st.vacationCount}</b><span class="mini">${t("attV")}</span></div>
    </div>
    <div class="db-meta">
      <span class="mini">${st.date}</span>
      <span class="mini">${t("dayOff")}: ${names(st.off)}</span>
      ${st.absentCount?`<span class="mini">${t("attA")}: ${names(st.absent)}</span>`:""}
      ${st.vacationCount?`<span class="mini">${t("attV")}: ${names(st.vacation)}</span>`:""}
      ${dayIsCustom(day)?`<span class="db-tag">${t("customDay")}</span>`:""}
    </div>
    <button class="btn sm" data-dutyedit="${day}">${ic("pen",14)} ${t("editDayOff")}</button>
  </div>`;
}
/* ---- Day Plan sections she can reorder herself, no code ---- */
const DAYPLAN_SECTIONS=["info","times","team","standards"];
/* ---- Arrange this page: every manager page she can rearrange herself ----
   Pages built from cards list their sections; pages built from pills list
   their sub-tabs. The same button and the same modal handle both. */
const PAGE_SECTIONS={
  dayplan: ["team","standards"],
  dash:    ["attention","dayinfo","wholeday","tonight","live","export","stats","feedback","nations","activities","trends"],
  guests:  ["crm","rooms","bookings","tickets","chat","requests","feedback","history"],
  team:    ["accounts","chat","requests","monthatt","attendance","payroll"],
  program: ["acts","tickets","performance"],
  settings:["set:theme","set:publictext","set:brand","builder","set:features","set:notif","set:links",
            "bus","set:location","export","set:advanced"]
};
const SECTION_LABELS={
  dayplan: {team:"teamAccounts",standards:"standardsHead"},
  dash:    {attention:"attentionHead",dayinfo:"dayInfoSec",wholeday:"wholeDay",tonight:"tonightLbl",live:"liveOps",export:"exportData",stats:"overview",feedback:"fbAnalytics",
            nations:"natStats",activities:"activities",trends:"trendsHead"},
  guests:  {crm:"guestCrm",rooms:"rooms",bookings:"bookings",tickets:"tickets",chat:"guestChatTab",
            requests:"requests",feedback:"feedback",history:"Guest history"},
  team:    {accounts:"teamAccounts",chat:"teamChatTab",requests:"teamRequests",
            monthatt:"monthAtt",attendance:"attendance",payroll:"Payroll"},
  program: {acts:"activities",tickets:"tickets",performance:"Shows / Events Attendance"},
  settings:{"set:theme":"setTheme","set:publictext":"Public experience","set:brand":"setBrand","builder":"setMenus",
            "set:features":"setFeatures","set:notif":"setNotif","set:links":"setLinksT",
            "bus":"busItem","set:location":"setLocation","export":"setData","set:advanced":"setAdvanced"}
};
function sectionLabel(pageKey,k){ const m=SECTION_LABELS[pageKey]||{}; return m[k]?t(m[k]):k; }
function pageHidden(pageKey){
  const all=(S.settings && S.settings.pageHidden) || {};
  let hidden=(all[pageKey]||[]).slice();
  // V6.19.3 one-time migration: stale saved Guest layouts could hide the newly-added Tickets tab.
  // Until the migration is recorded, Tickets must remain visible. Afterwards normal Arrange Page control resumes.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193)) hidden=hidden.filter(k=>k!=="tickets");
  return hidden;
}
function pageOrder(pageKey,withHidden){
  const def=PAGE_SECTIONS[pageKey]||[];
  const all=(S.settings && S.settings.pageOrder) || {};
  let saved=all[pageKey];
  if(!saved && pageKey==="dayplan") saved=(S.settings && S.settings.dayPlanOrder);  // the older name
  const kept=(saved||[]).filter(k=>def.includes(k));
  let out=kept.concat(def.filter(k=>!kept.includes(k)));
  // V6.19.3 one-time migration: older/stale saved Guest layouts may already contain Tickets
  // in the wrong position, or may have hidden it. Force the intended location once.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193) && out.includes("tickets")){
    out=out.filter(k=>k!=="tickets");
    const bi=out.indexOf("bookings");
    out.splice(bi>=0?bi+1:Math.min(3,out.length),0,"tickets");
  }
  if(pageKey==="dash" && !(S.settings&&S.settings.dashboardDayOpsMigrationV626)){
    out=out.filter(k=>k!=="dayinfo"&&k!=="wholeday");
    const ai=out.indexOf("attention"),at=ai>=0?ai+1:0;
    out.splice(at,0,"dayinfo","wholeday");
  }
  if(!withHidden){ const h=pageHidden(pageKey); out=out.filter(k=>!h.includes(k)); }
  return out.length?out:def.slice();
}
function dayPlanOrder(){ return pageOrder("dayplan"); }
function arrangeBtn(pageKey){
  if(!S.session || S.session.role!=="manager") return "";
  if(!PAGE_SECTIONS[pageKey]) return "";
  return `<button class="btn sm ghost arrange-b" data-arrange="${pageKey}">${ic("grid",14)} ${t("arrangeSections")}</button>`;
}
function renderParts(pageKey,parts){
  return pageOrder(pageKey).map(k=>parts[k]?parts[k]():"").join("");
}
/* Everything that happens today, split into morning / afternoon / evening. */
/* Turn whatever is written in the entertainer field into a real name. */
function entertainerName(raw){
  const v=String(raw||"").trim();
  if(!v) return "";
  return v.split(/\s*[,;\/]\s*/).map(part=>{
    const p=part.trim(); if(!p) return "";
    const pl=p.toLowerCase();
    const hit=(S.users||[]).find(u=>
      String(u.display_name||"").toLowerCase()===pl ||
      String(u.username||"").toLowerCase()===pl ||
      String(u.number||"")===p.replace(/^#/,"") ||
      String(u.employee_id||"")===p ||
      String(u.phone||"").replace(/\s/g,"")===p.replace(/\s/g,"")
    );
    return hit ? (hit.display_name||hit.username) : p;
  }).filter(Boolean).join(", ");
}
/* is this the logged-in entertainer's own activity? */
function isMineAct(a){
  if(!S.session || S.session.role!=="staff") return false;
  const me=String(S.session.name||"").toLowerCase();
  const un=String(S.session.username||"").toLowerCase();
  return String(a && a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
    .map(x=>x.trim()).some(x=>x && (x===me || x===un || entertainerName(x).toLowerCase()===me));
}
function dayTimeline(day){
  const items=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>({a,slot:operationSlotFromMinutes(timeToMin(a.time))}))
    .filter(x=>["morning","afternoon","evening"].includes(x.slot))
    .sort((x,y)=>(timeToMin(x.a.time)||0)-(timeToMin(y.a.time)||0));
  const slots=[
    {k:"morning",label:"10:00 – 12:30"},
    {k:"afternoon",label:"15:00 – 17:30"},
    {k:"evening",label:"19:30 – 23:00"}
  ];
  return slots.map(sl=>{
    const rows=items.filter(x=>x.slot===sl.k).map(x=>x.a);
    return `<div class="tl-block">
      <div class="tl-head"><span class="tl-dot ${sl.k}"></span>${t(sl.k+"Part")}
        <span class="mini" style="margin-left:6px">${sl.label}</span><span class="tl-n">${rows.length}</span></div>
      ${rows.length?rows.map(x=>{
        const c=normCat(x), who=entertainerName(x.entertainer);
        const type=c==="mAdult"?"":(catLabel(c)||c);
        return `<div class="tl-row ${x._tag?("is-"+x._tag):""}${isMineAct(x)?" mine":""}">
          <span class="tl-t">${esc(x.time||"")}</span>
          <span class="tl-x"><b>${esc(x.name)}</b>${x.location?`<span class="mini">${esc(x.location)}</span>`:""}
            ${who?`<span class="mini who">${esc(who)}</span>`:""}</span>
          ${type?`<span class="tl-tag">${esc(type)}</span>`:""}
        </div>`;
      }).join(""):`<p class="mini tl-empty">${t("noneToday")}</p>`}
    </div>`;
  }).join("");
}
function dayPlanInfoCard(day){
  const dp=dayPlanFor(day);
  return `<div class="sec"><h3>${ic("calendar",18)} ${esc(t("days")[dp.day]||dp.name)}</h3>
    <div class="card daycard">
      <div class="dc-grid">
        <div class="dc-cell"><span>${t("restaurantTheme")}</span><b>${esc(dp.theme)}</b></div>
        <div class="dc-cell"><span>${t("dressCode")}</span><b>${esc(dp.dress)}</b></div>
        <div class="dc-cell"><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>
          ${dp.showTime?`<i class="mini">${esc(dp.showTime)}${dp.showLoc?" · "+esc(dp.showLoc):""}</i>`:""}</div>
        <div class="dc-cell"><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
        <div class="dc-cell"><span>${t("dayOff")}</span><b>${personTags(dp.off)||"—"}</b></div>
        <div class="dc-cell"><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
        <div class="dc-cell wide"><span>${t("eventsToday")}</span>
          ${(()=>{
            const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
              .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
            if(!evs.length) return `<b>—</b>`;
            return evs.map(e=>`<b class="ev-line">${esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])} · ${esc(e.name)}${e.location?` <i class="mini">${esc(e.location)}</i>`:""}</b>`).join("");
          })()}</div>
        <div class="dc-cell"><span>${t("practiceHead")}</span>
          <b>${dp.practice?t("practiceDays"):(dp.makeup?t("makeupPractice"):"—")}</b>
          ${dp.practice?`<i class="mini">${esc(t("practiceWindow"))}</i>`
            :(dp.makeup?`<i class="mini">${esc(makeupText(dp.makeup))}</i>`:"")}</div>
      </div>
    </div>
  </div>`;
}
function dayPlanTeamCard(day){
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const mk=currentAttMonth(), ds=assignDateStr(day), dd=+ds.slice(8,10);
  const isThisMonth=ds.slice(0,7)===mk;
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n]; const info=personDayInfo(n,day);
    let status="", cls="";
    const st = (u && isThisMonth) ? attStatus(u,mk,dd) : "";
    if(st==="A"){ status=t("attA"); cls="absent"; }        // marked absent
    else if(st==="V"){ status=t("attV"); cls="vac"; }      // on holiday
    else if(info.isOff){ status=t("dayOff"); cls="off"; }
    roster.push({n,u,role:roleForNumber(n),status,cls});
  }
  const away=roster.filter(r=>r.cls==="absent").length;
  const onHol=roster.filter(r=>r.cls==="vac").length;
  return `<div class="sec"><h3>${ic("users",18)} ${t("teamAccounts")}
      ${away?`<span class="hd-chip absent">${away} ${t("attA")}</span>`:""}
      ${onHol?`<span class="hd-chip vac">${onHol} ${t("attV")}</span>`:""}</h3>
    <div class="card rostercard">
      ${roster.map(r=>`<div class="roster-row ${r.cls}">
        <span class="rnum">${r.u&&r.u.photo?`<img src="${esc(r.u.photo)}" alt="">`:r.n}</span>
        <span class="rinfo"><b>${esc(r.u?(r.u.display_name||r.u.username):r.role)}</b>
          <span class="mini">#${r.n} · ${esc(r.role)}${r.u?"":" · —"}</span></span>
        ${r.status?`<span class="rstat ${r.cls}">${esc(r.status)}</span>`:`<span class="rstat working">${ic("check",14)}</span>`}
      </div>`).join("")}
    </div>
  </div>`;
}
function dayPlanStandards(day){
  const dp=dayPlanFor(day);
  const rows=DAILY_STANDARDS.map(r=>{
    let note=r.nk?t(r.nk):"";
    if(r.morning){ note = dp.practice ? t("practiceInline") : ""; }
    return `<div class="std-row"><span class="std-t">${esc(r.time)}</span>
      <span class="std-x"><b>${esc(t(r.k))}</b>${note?`<span class="mini"> · ${esc(note)}</span>`:""}</span></div>`;
  }).join("");
  return `<div class="sec"><h3>${ic("clock",18)} ${t("standardsHead")}</h3>
    <div class="card">${rows}</div></div>`;
}
function dayPlanTimes(day){
  return `<div class="sec"><h3>${ic("clock",18)} ${t("wholeDay")}</h3>
    <div class="card tlcard">${dayTimeline(day)}</div></div>`;
}
function managerDayPlanView(){
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  const dp=dayPlanFor(day);
  // roster: numbers 1-10; manager account -> slot #1, numbered staff -> their slot
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n];
    const info=personDayInfo(n,day);
    let status="", cls="";
    if(info.isOff){ status=t("dayOff"); cls="off"; }   // entrance duty lives in Assignments
    else { status=""; cls=""; }
    roster.push({n,u,role:roleForNumber(n),status,cls,info});
  }
  const parts={
    team:      ()=>dayPlanTeamCard(day),
    standards: ()=>dayPlanStandards(day)
  };
  return `<div class="screen fadein">
    ${topBar(t("dayPlan"),(t("days")[dp.day]||dp.name)+" · "+dp.theme)}
    ${dayChips()}
    ${dutyBar(day)}
    ${arrangeBtn("dayplan")}
    ${renderParts("dayplan",parts)}
  </div>`;
}
/* Move the sections of this page around — no code, just up and down. */
function openArrangeModal(pageKey){
  pageKey=pageKey||"dayplan";
  if(!PAGE_SECTIONS[pageKey]) return;
  let order=pageOrder(pageKey,true);
  let hidden=pageHidden(pageKey);
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("arrangeSections")}</h3>
    <p class="mini">${t("arrangeAnyHint")}</p>
    <div id="ar-box"></div>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-reset">${t("resetDefault")}</button>
    <button class="btn ghost" id="ar-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#ar-box");
  const paint=()=>{
    box.innerHTML=order.map((k,i)=>{
      const off=hidden.includes(k);
      return `<div class="ar-it" style="${off?"opacity:.45":""}">
      <span class="ar-nm">${esc(sectionLabel(pageKey,k))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-arup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-ardown="${i}" ${i===order.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b ${off?"":"on"}" data-arhide="${esc(k)}" aria-label="${off?t("showSection"):t("hideSection")}">${ic(off?"belloff":"bell",14)}</button>
      </span></div>`;}).join("");
    box.querySelectorAll("[data-arup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.arup; [order[i-1],order[i]]=[order[i],order[i-1]]; paint();
    });
    box.querySelectorAll("[data-ardown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.ardown; [order[i+1],order[i]]=[order[i],order[i+1]]; paint();
    });
    box.querySelectorAll("[data-arhide]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.arhide, i=hidden.indexOf(k);
      if(i>=0) hidden.splice(i,1);
      else if(order.length-hidden.length>1) hidden.push(k);   // never hide the last one
      paint();
    });
  };
  paint();
  const save=async (ord,hid)=>{
    const po={...((S.settings&&S.settings.pageOrder)||{})}; po[pageKey]=ord;
    const ph={...((S.settings&&S.settings.pageHidden)||{})}; ph[pageKey]=hid;
    const next={...S.settings, pageOrder:po, pageHidden:ph};
    if(pageKey==="dayplan") next.dayPlanOrder=ord;             // keep the old field in step
    try{ await DB.saveSettings(next); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-reset").onclick=()=>save(PAGE_SECTIONS[pageKey].slice(),[]);
  wrap.querySelector("#ar-go").onclick=()=>save(order,hidden);
}
function feedbackInner(){
  const list=S.feedback||[];
  const avg=fbAvgAll(list);
  return `<div class="row2" style="margin-bottom:12px">
      <button class="btn" id="btn-addfb">\uFF0B ${t("fbNew")}</button>
      <button class="btn ghost" id="btn-fbexport">${ic("download",15)} ${t("fbExport")}</button>
    </div>
    ${S.session && S.session.role==="manager"
      ? `<button class="btn ghost sm" id="btn-fbdepts" style="margin:0 0 12px">${ic("grid",14)} ${t("fbDeptsEdit")}</button>` : ""}
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${avg?avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${list.length}</b><span>${t("feedback")}</span></div>
    </div>
    <p class="mini" style="margin:-2px 0 8px">${t("fbTapOne")}</p>`
  + dayGroups("fb", list, "created_at", fbRowHtml, "feedback");
}
function dashView(){
  if(S.sub.dash==="rooms") S.sub.dash="overview";   // rooms live under Guests now
  const totalB=S.bookings.length;
  const wait=S.bookings.filter(b=>b.status==="waitlist").length;
  const withCap=S.activities.filter(a=>a.capacity>0);
  const occ=withCap.length?Math.round(withCap.reduce((n,a)=>n+Math.min(1,seatsTaken(a.id)/a.capacity),0)/withCap.length*100):0;
  const tSold=S.orders.reduce((n,o)=>n+(+o.qty||0),0);
  const rooms=new Set(S.bookings.map(b=>b.room)).size;
  const people=S.bookings.filter(b=>b.status==="booked").reduce((n,b)=>n+(+b.adults||0)+(+b.children||0),0);
  const natMap={};
  S.bookings.forEach(b=>{ if(b.nationality){ (natMap[b.nationality]=natMap[b.nationality]||new Set()).add(b.room); } });
  S.orders.forEach(o=>{ if(o.nationality){ (natMap[o.nationality]=natMap[o.nationality]||new Set()).add(o.room); } });
  const nats=Object.entries(natMap).map(([n,s])=>[n,s.size]).sort((x,y)=>y[1]-x[1]);
  const top=[...S.activities].map(a=>({a,n:seatsTaken(a.id)})).sort((x,y)=>y.n-x.n).slice(0,5).filter(x=>x.n>0);
  const parts={
    attention: ()=>attentionCard(),
    dayinfo:   ()=>dayPlanInfoCard(todayIndex()),
    wholeday:  ()=>dayPlanTimes(todayIndex()),
    tonight:   ()=>tonightCard(),
    live:      ()=>liveOpsCard(),
    export:    ()=>`<button class="btn ghost" id="btn-exportdata" style="margin:0 0 16px">${ic("download",16)} ${t("exportData")}</button>`,
    stats:     ()=>`<div class="stat-grid">
      <div class="stat"><b>${totalB}</b><span>${t("totalBookings")}</span></div>
      <div class="stat accent"><b>${occ}%</b><span>${t("occupancy")}</span></div>
      <div class="stat"><b>${tSold}</b><span>${t("tickets")}</span></div>
      <div class="stat"><b>${wait}</b><span>${t("waitlisted")}</span></div>
      <div class="stat"><b>${rooms}</b><span>${t("uniqueGuests")}</span></div>
      <div class="stat"><b>${people}</b><span>${t("totalPeople")}</span></div>
    </div>`,
    feedback:  ()=>feedbackAnalyticsCard(),
    nations:   ()=>nats.length?`<div class="sec"><h3>${t("natStats")}</h3><div class="card">
      ${nats.map(([n,c])=>`<div class="booking-line"><span>${esc(n)}</span><span class="pill">${c}</span></div>`).join("")}
    </div></div>`:"",
    activities:()=>`<div class="sec"><h3>${ic("star",18)} ${t("activities")}</h3>
      ${top.length?top.map(x=>`<div class="card booking-line" style="padding:12px 14px">
        <span><b>${esc(x.a.name)}</b> · ${t("daysShort")[x.a.day]} ${x.a.time}</span>
        <span class="pill">${x.n} ${t("guests")}</span></div>`).join(""):`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("none")}</div>`}
    </div>`,
    trends:    ()=>trendsCard()
  };
  return `<div class="screen fadein">
    ${topBar(t("dashboard"),S.session.name)}
        ${!REMOTE?`<div class="setup">${t("demoNote")}</div>`:""}
    ${arrangeBtn("dash")}
    ${renderParts("dash",parts)}
  </div>`;
}
/* Tonight's show or party, and whether the hotel is actually ready for it.
   The readiness comes straight from its requirement sheet. */
function tonightAct(day){
  const d=(typeof day==="number")?day:todayIndex();
  const evening=(S.activities||[]).filter(a=>a && a.day===d && ["eShow","eParty"].includes(normCat(a)));
  if(!evening.length) return null;
  return evening.sort((x,y)=>(timeToMin(reqStartTime(y))||0)-(timeToMin(reqStartTime(x))||0))[0];
}
function reqSheetForAct(a){
  if(!a) return null;
  const all=reqSheets();
  return all.find(sh=>String(sh.actId||"")===String(a.id))
      || all.find(sh=>String(sh.title||"").toLowerCase()===String(a.name||"").toLowerCase())
      || null;
}
function tonightCard(){
  const a=tonightAct();
  if(!a) return "";
  const sh=reqSheetForAct(a);
  const rows=(sh && sh.rows) || [];
  const done=rows.filter(r=>r.done).length;
  const pct=rows.length?Math.round(done/rows.length*100):0;
  const who=String(a.entertainer||"").trim();
  const byDept={};
  rows.forEach(r=>{ const k=r.dept||"\u2014"; byDept[k]=byDept[k]||{n:0,d:0}; byDept[k].n++; if(r.done) byDept[k].d++; });
  const chips=Object.keys(byDept).slice(0,3).map(k=>{
    const v=byDept[k], full=v.d===v.n;
    return `<span class="schip ${full?"live":"warn"}"><i></i>${esc(k)} ${full?"\u2713":v.d+"/"+v.n}</span>`;
  }).join("");
  return `<div class="sec"><h3>${ic("sparkle",18)} ${t("tonightLbl")}</h3>
    <div class="card tn">
      <div class="tn-head" data-actopen="${esc(String(a.id))}">
        <span class="tn-mid"><b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}</span></span>
        <span class="tn-go">${ic("back",16)}</span>
      </div>
      <div class="tn-chips">
        <span class="schip ${who?"live":"warn"}"><i></i>${t("readyTeam")} ${who?esc(who):"\u2014"}</span>
        ${chips}
      </div>
      ${rows.length?`<div class="tn-bar"><i style="width:${pct}%"></i></div>
        <span class="mini">${t("readySetup")} ${pct}% \u00b7 ${done}/${rows.length}</span>`
        :`<button class="btn sm ghost" id="tn-make">${ic("clipboard",14)} ${t("readyMake")}</button>`}
    </div>
  </div>`;
}
/* What is running right now, what starts next, and whether anyone is on it.
   The manager's first question every afternoon. */
function liveOpsCard(){
  const day=todayIndex();
  const now=(()=>{ const d=new Date(); return d.getHours()*60+d.getMinutes(); })();
  const list=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>{
      const w=actWindow(a);
      const s0=w?w.s0:(timeToMin(String(a.time||"").split(/\s*[\u2013\u2014-]\s*/)[0])||0);
      const s1=(w && (w.e0!=null?w.e0:w.s1)) ?? (s0+45);   // actWindow calls the end e0
      return {a, s0, s1};
    })
    .filter(x=>x.s1>=now-30)                       // still running, or still to come
    .sort((x,y)=>x.s0-y.s0)
    .slice(0,5);
  if(!list.length) return "";
  const staffOf=a=>entertainerName(a.entertainer);   // always show the team member display name
  const row=x=>{
    const a=x.a, who=staffOf(a), booked=seatsTaken(a.id);
    const live = x.s0<=now && now<=x.s1;
    const mins = Math.round(x.s0-now);
    const chip = live ? `<span class="schip live"><i></i>${t("liveNow")}</span>`
      : !who   ? `<span class="schip warn"><i></i>${t("liveNoStaff")}</span>`
      : mins<=60 ? `<span class="schip gold"><i></i>${t("liveSoon").replace("{n}",Math.max(0,mins))}</span>`
      : `<span class="schip"><i></i>${t("liveAssigned")}</span>`;
    return `<div class="booking-line" data-actopen="${esc(String(a.id))}" style="cursor:pointer">
      <span style="min-width:0"><b>${esc(a.name)}</b>
        <br><span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}${
          booked?" \u00b7 "+booked+" "+t("guests"):""}${who?" \u00b7 "+esc(who):""}</span></span>
      ${chip}
    </div>`;
  };
  return `<div class="sec"><h3>${ic("clock",18)} ${t("liveOps")}</h3>
    <div class="card">${list.map(row).join("")}</div>
  </div>`;
}
/* The feedback picture at a glance — tap a department to read the ratings behind it. */
function feedbackAnalyticsCard(){
  const list=S.feedback||[];
  const sum=fbSummary(list);
  return `<div class="sec"><h3>${ic("star",18)} ${t("fbAnalytics")}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${sum.overall?sum.overall.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${sum.count}</b><span>${t("feedback")}</span></div>
      <div class="stat good"><b>${sum.allFive}</b><span>${t("fbAllFiveN")}</span></div>
      <div class="stat ${sum.toReview?"warn":""}"><b>${sum.toReview}</b><span>${t("fbToReview")}</span></div>
    </div>
    ${sum.weak
      ? `<button class="fb-dept low" data-fbdept="${esc(sum.weak.k)}" style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:10px">
          <span class="fb-nm">${t("fbLowest")}<br><span class="mini">${esc(fbDeptLabel(sum.weak.k))}</span></span>
          <span class="fb-bar"><i style="width:${Math.round(sum.weak.avg/5*100)}%"></i></span>
          <span class="fb-val">${sum.weak.avg.toFixed(1)}</span></button>`
      : (sum.rated?`<p class="mini" style="margin:0 0 10px">${ic("star",13)} ${
          sum.perfect ? t("fbHotelGeneral")+" \u00b7 "+t("fbPerfect")
          : t("fbHotelGeneral")+" \u00b7 "+t("fbNoneWeak")}</p>`:"")}
    ${fbDeptListCard(list)}
    ${sum.rated?`<p class="mini" style="margin-top:6px">${t("fbTapHint")}</p>`:""}
  </div>`;
}
function managerActsInner(){
  const acts=S.activities.filter(a=>a.day===S.day);
  const head=dayTabs()+`<button class="btn" id="btn-add" style="margin:0 0 14px">＋ ${t("addActivity")}</button>`;
  if(!acts.length) return head+`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return head + OPS.map(o=>{
    const list=acts.filter(a=>actOp(a)===o.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    if(!list.length) return "";
    return `<div class="sec"><h3>${esc(opLabel(o.id))}</h3>${list.map(a=>activityCard(a,{manager:true,showBook:false,showFav:false})).join("")}</div>`;
  }).join("");
}
function managerTicketsInner(){
  return `<button class="btn" id="btn-addticket" style="margin:0 0 14px">＋ ${t("addTicket")}</button>`
  + (S.tickets.length?S.tickets.map(tk=>{
    const os=ordersFor(tk.id), sold=ticketsSold(tk.id);
    return `<div class="card">
      <div class="act" style="margin-bottom:${os.length?10:0}px">
        <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
        <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span>
          <h4>${esc(tk.name)}</h4>
          <div class="meta"><span>${esc(tk.price||"")}</span><span>${mi("ticket")}${sold}${tk.capacity>0?"/"+tk.capacity:""}</span></div></div>
        <div class="side"><button class="btn sm ghost" data-tedit="${tk.id}">${ic("pen",15)}</button></div>
      </div>
      ${os.map(o=>`<div class="booking-line">
        <span style="min-width:0"><b>${t("room")} ${esc(o.room)}</b> · ${esc(o.guest_name)} · ×${o.qty}${o.collect_from?`<br><span class="mini">${mi("user")}${t("handTo")}: ${esc(o.collect_from)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <button class="chip ${o.status==="paid"?"ok":"res"}" data-tpaid="${o.id}">${o.status==="paid"?t("paid"):t("reserved")}</button>
          <button class="btn sm warn" data-tdel="${o.id}">${ic("close",14)}</button>
        </span></div>`).join("")}
    </div>`;
  }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`);
}
function requestsInner(){
  return S.requests.length?dayGroups("req", S.requests, "created_at", r=>`<div class="booking-line">
    <span style="min-width:0">${ic(r.type==="song"?"music":"gift",15)} <b>${esc(r.detail)}</b>${r.date?` · ${esc(r.date)}`:""}
      <br><span class="mini">${t("room")} ${esc(r.room)} · ${esc(r.guest_name)}${r.note?` — ${esc(r.note)}`:""}
        ${r.created_at?` · ${whenLabel(r.created_at)}`:""}</span></span>
    <span style="display:flex;gap:6px;align-items:center;flex:none">
      <button class="chip ${r.status==="done"?"ok":"res"}" data-reqdone="${r.id}">${r.status==="done"?t("done"):t("statusNew")}</button>
      <button class="btn sm warn" data-reqdel="${r.id}">${ic("close",14)}</button>
    </span></div>`, "requests")
  :`<div class="empty"><div class="big">${ic("gift",30)}</div>${t("none")}</div>`;
}
function roomsInner(){
  return `<label>${t("addRooms")}</label>
    <textarea id="rooms-in" rows="3" placeholder="${t("roomsHint")}"></textarea>
    <button class="btn" id="btn-addrooms" style="margin:10px 0 16px">＋ ${t("addRooms")}</button>
    <input id="rooms-filter" placeholder="..." style="margin-bottom:10px">
    <div class="card roomgrid">
      ${S.rooms.length?S.rooms.map(r=>{
        const acc=S.accounts.find(a=>a.room===r.room && a.active!==false && !stayExpired(a));
        return `<div class="booking-line roomline" data-room="${esc(r.room)}">
          <span style="min-width:0"><b>${esc(r.room)}</b>${acc?` · ${esc(acc.name)}`:""}</span>
          <span style="display:flex;gap:6px;align-items:center;flex:none">
            ${acc?`<button class="btn sm ghost" data-gedit="${acc.id}">${ic("pen",15)}</button>`:""}
            <button class="chip ${r.active?"ok":"full"}" data-roomact="${r.id}">${t("activeLbl")}</button>
            <button class="btn sm warn" data-roomdel="${r.id}">${ic("close",14)}</button>
          </span></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("door",30)}</div>${t("none")}</div>`}
    </div>`;
}
function teamSummaryCard(){
  const st=teamStats();
  if(!st.total) return "";
  return `<div class="card tsum">
    <div class="ts-top">
      <div class="ts-big"><b>${st.total}</b><span class="mini">${t("totalEntertainers")}</span></div>
      <div class="ts-gen">
        <span class="ts-chip m">${ic("users",14)} ${st.byGender.male} ${t("genderM")}</span>
        <span class="ts-chip f">${ic("users",14)} ${st.byGender.female} ${t("genderF")}</span>
        ${st.byGender.none?`<span class="ts-chip n">${st.byGender.none} ${t("genderNone")}</span>`:""}
      </div>
    </div>
    ${st.natList.length?`<div class="ts-nat"><span class="type-meta">${t("byNationality")}</span>
      <div class="ts-nats">${st.natList.map(n=>`<span class="ts-chip">${esc(n.name)} · ${n.count}</span>`).join("")}</div>
    </div>`:""}
  </div>`;
}
function accountsInner(){
  const managerCount=S.users.filter(u=>u.role==="manager").length;
  return `${teamSummaryCard()}
    <button class="btn" id="btn-adduser" style="margin:0 0 12px">＋ ${t("addUser")}</button>
    <div class="card">
      ${S.users.filter(u=>!isAttOnly(u)).sort((a,b)=>(hasLeft(a)?1:0)-(hasLeft(b)?1:0) || (a.number||99)-(b.number||99)).map(u=>{
        const lastManager=u.role==="manager"&&managerCount<=1;
        return `<div class="acct-row">
        <div class="acct-av">${u.photo?`<img src="${esc(u.photo)}" alt="">`:`<span>${esc((u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</span>`}${u.number?`<span class="acct-num">${u.number}</span>`:""}</div>
        <div class="acct-info" data-uview="${esc(u.username)}"><b>${esc(u.display_name||u.username)}${hasLeft(u)?` <span class="off-tag">${t("leftTag")}</span>`:(u.active===false?` <span class="off-tag">${t("inactiveAcc")}</span>`:"")}</b><span class="mini">${esc(u.username)} · ${u.role==="manager"?t("manager"):t("staff")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span></div>
        <div style="display:flex;gap:6px;align-items:center;flex:none">
          <button class="btn sm ghost" data-uedit="${u.id}">${ic("pen",15)}</button>
          ${u.role==="staff"?`<button class="btn sm ghost" data-userleave="${u.id}" aria-label="${t("markLeft")}">${ic("exit",15)}</button>`:""}
          ${u.id===S.session.userId||lastManager?"":`<button class="btn sm warn" data-deluser="${u.id}">${ic("close",14)}</button>`}
        </div></div>`;}).join("")}
    </div>`;
}
function openProfileModal(p){
  const isNew=!p; p=p||{name:"",position:"",photo:"",nationality:"",languages:"",skills:"",instagram:""};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${isNew?t("addProfile"):t("profiles")}</h3>
    <label>${t("name")}</label><input id="pr-name" value="${esc(p.name)}">
    <label>${t("positionLbl")}</label><input id="pr-pos" value="${esc(p.position)}" placeholder="Entertainment Manager / Entertainer">
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="pr-photo" type="hidden" value="${esc(p.photo)}">
    <label>${t("nationality")}</label>
    <input id="pr-nat" list="prnatlist" value="${esc(p.nationality)}">
    <datalist id="prnatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <label>${t("languagesLbl")}</label><input id="pr-lang" value="${esc(p.languages)}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="pr-skills" value="${esc(p.skills)}" placeholder="Dance · Shows · Kids">
    <label>${t("instagramLbl")}</label><input id="pr-ig" value="${esc(p.instagram)}" placeholder="https://instagram.com/...">
    <button class="btn" id="pr-go">${t("save")}</button>
    <button class="btn ghost" id="pr-x">${t("close")}</button>`);
  wrap.querySelector("#pr-x").onclick=()=>wrap.remove();
  let prPhoto=p.photo||"";
  wirePhotoPicker(wrap, ()=>prPhoto, v=>{ prPhoto=v; wrap.querySelector("#pr-photo").value=v; });
  wrap.querySelector("#pr-go").onclick=async ()=>{
    const name=wrap.querySelector("#pr-name").value.trim();
    if(!name) return;
    await DB.saveProfile({...p,name,
      position:wrap.querySelector("#pr-pos").value.trim(),
      photo:prPhoto,
      nationality:wrap.querySelector("#pr-nat").value.trim(),
      languages:wrap.querySelector("#pr-lang").value.trim(),
      skills:wrap.querySelector("#pr-skills").value.trim(),
      instagram:wrap.querySelector("#pr-ig").value.trim()});
    wrap.remove(); toast(t("saved")); render();
  };
}
function tasksInner(){
  const rk=rankingRows();
  return `<button class="btn" id="btn-addtask" style="margin:0 0 12px">＋ ${t("addTask")}</button>
    <button class="btn ghost" id="btn-export" style="margin:0 0 14px">${ic("download",16)} ${t("exportReport")}</button>`
    + (rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("taskStats")}</h3><div class="card">
      ${rk.map((r,i)=>`<div class="booking-line">
        <span style="min-width:0">${rankBadge(i)} <b>${esc(r.u.display_name||r.u.username)}</b>
          <br><span class="mini">${t("done")}: ${r.done} · ${t("late")}: ${r.late} · ${t("cantDo")}: ${r.cant} · ${t("statusNew")}: ${r.open}</span></span>
        <span class="pill" style="flex:none">${r.points} ${t("points")}</span></div>`).join("")}
    </div></div>`:"")
    + (S.tasks.length?`<div class="card">${S.tasks.map(x=>taskLine(x,true)).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`);
}
/* ---------------- AI assistant (manager only) ---------------- */
function aiView(){
  const key=localStorage.getItem("ent_ai_key")||"";
  if(!key){
    return `<div class="screen fadein">
      ${topBar(t("aiTab"),S.session.name)}
      ${hubBack()}
      <div class="card" style="padding:16px">
        <p style="font-size:15px">${ic("sparkle",16)} ${t("aiIntro")}</p>
        <label>${t("aiKeyLbl")}</label>
        <input id="ai-key" type="password" placeholder="sk-ant-...">
        <p class="hint" style="text-align:start">${t("aiKeyHint")}<br>→ console.anthropic.com</p>
        <button class="btn" id="ai-savekey">${t("save")}</button>
      </div>
    </div>`;
  }
  return `<div class="screen fadein">
    ${topBar(t("aiTab"),S.session.name)}
    ${hubBack()}
    <div class="thread">
      ${S.aiChat.length?S.aiChat.map(m=>`<div class="bub ${m.role==="user"?"me":"them"}">${esc(m.content)}</div>`).join("")
        :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("aiIntro")}</div>`}
      ${S.aiBusy?`<div class="bub them">…</div>`:""}
    </div>
    <div class="chatbar">
      <input id="ai-in" placeholder="${t("aiAsk")}" autocomplete="off">
      <button id="ai-send" aria-label="${t("send")}">${ic("send",17)}</button>
    </div>
  </div>`;
}
function aiContext(){
  const days=t("days");
  const prog=S.activities.slice(0,200).map(a=>`${days[a.day]} ${a.time} ${a.name} @${a.location}${a.entertainer?" [entertainer:"+a.entertainer+"]":""}`).join("; ");
  const rk=rankingRows().map(r=>`${r.u.display_name||r.u.username}: ${r.points}pts (done ${r.done}, late ${r.late}, can't ${r.cant}, open ${r.open})`).join("; ");
  const avg=S.feedback.length?(S.feedback.reduce((n,f)=>n+(+f.rate||0),0)/S.feedback.length).toFixed(1):"n/a";
  // full guest directory — lets the assistant answer "tell me about room 1111"
  const guests=S.accounts.map(a=>{
    const info=guestFullInfo(a.room); if(!info) return "";
    return `Room ${info.room}: ${info.name} (user ${info.username}), ${info.nationality||"?"}, phone ${info.phone||"?"}, stay ${info.arrival||"?"}→${info.departure||"?"}, ${info.days!=null?info.days+" days in app":""}, joined: ${info.activities.join("/")||"none"}, ${info.tickets} tickets, ${info.requests} requests`;
  }).filter(Boolean).join(" | ");
  const reqs=S.requests.slice(0,40).map(r=>`${r.type} "${r.detail}" room ${r.room} (${r.status})`).join("; ");
  const team=S.profiles.map(p=>`${p.name} — ${p.position||""} (${p.languages||""})`).join("; ");
  return `App: ${S.settings.name}. Today totals — bookings ${S.bookings.length}, ticket orders ${S.orders.reduce((n,o)=>n+(+o.qty||0),0)}, open requests ${S.requests.filter(r=>r.status==="new").length}, registered guest rooms ${S.accounts.length}, feedback avg ${avg}/5 (${S.feedback.length}). 
TEAM: ${team||"none"}. 
TEAM RANKING: ${rk||"none"}. 
GUEST DIRECTORY: ${guests||"no guests yet"}. 
RECENT REQUESTS: ${reqs||"none"}. 
WEEKLY PROGRAM: ${prog}`;
}
function aiSystemPrompt(){
  return "You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
    "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
    "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
    "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
    "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
    "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
    "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
    "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext();
}
/* Preferred path: a deployed Supabase Edge Function, so the API key never touches the browser. */
async function askAIViaEndpoint(endpoint){
  const res=await fetch(endpoint,{
    method:"POST",
    headers:{"content-type":"application/json"},
    body:JSON.stringify({
      system:aiSystemPrompt(),
      max_tokens:1200,
      messages:S.aiChat.map(m=>({role:m.role,content:m.content}))
    })
  });
  if(!res.ok) throw new Error("AI "+res.status);
  const data=await res.json();
  if(data.error) throw new Error(data.error);
  return String(data.text||"").trim();
}
async function askAI(text){
  const key=localStorage.getItem("ent_ai_key");
  const endpoint=(S.settings.aiEndpoint||"").trim();
  S.aiChat.push({role:"user",content:text});
  S.aiBusy=true; render();
  // Secure path first — only fall back to the browser key if no endpoint is set up yet.
  if(endpoint){
    try{
      const reply=await askAIViaEndpoint(endpoint);
      S.aiChat.push({role:"assistant",content:reply||"…"});
      S.aiBusy=false; render();
      window.scrollTo(0,document.body.scrollHeight);
      return;
    }catch(e){
      console.error("AI endpoint failed:", e && e.message);
      // The server link is wrong or not deployed yet.
      if(!key){
        S.aiChat.pop(); toastErr(t("aiEndpointErr"));
        S.aiBusy=false; render();
        window.scrollTo(0,document.body.scrollHeight);
        return;
      }
      // A key is stored on this device -> keep the assistant working and say so.
      toastWarn(t("aiEndpointFallback"));
    }
  }
  try{
    const res=await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{"content-type":"application/json","x-api-key":key,
        "anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
      body:JSON.stringify({model:"claude-haiku-4-5-20251001",max_tokens:1000,
        system:"You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
          "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
          "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
          "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
          "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
          "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
          "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
          "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext(),
        messages:S.aiChat.map(m=>({role:m.role,content:m.content}))})
    });
    if(!res.ok) throw new Error("AI "+res.status);
    const data=await res.json();
    const reply=(data.content||[]).map(c=>c.text||"").join("\n").trim();
    S.aiChat.push({role:"assistant",content:reply||"…"});
  }catch(e){ console.error(e); S.aiChat.pop(); toast(t("aiErr")); }
  S.aiBusy=false; render();
  window.scrollTo(0,document.body.scrollHeight);
}
function fmtDate(d){ return String(d||"").slice(0,16).replace("T"," "); }
/* build every exportable dataset as {title, headers, rows} */
function buildDataset(kind){
  const acts=id=>{ const a=S.activities.find(x=>x.id===id); return a?a.name:("#"+id); };
  const tkName=id=>{ const x=S.tickets.find(t=>t.id===id); return x?x.name:("#"+id); };
  if(kind==="bookings"){
   const okAct=new Set(exportActivities().map(a=>a.id));
   return {title:t("expBookings")+exportFilterNote(),
    headers:[t("room"),t("name"),t("nationality"),t("phone"),t("actName"),t("day"),t("time"),t("persons"),"Status"],
    rows:S.bookings.filter(b=>okAct.has(b.activity_id)).map(b=>{ const a=S.activities.find(x=>x.id===b.activity_id)||{};
      return [b.room,b.guest_name,b.nationality||"",b.phone||"",a.name||"",t("days")[a.day]||"",a.time||"",((+b.adults)||0)+((+b.children)||0),b.status||""]; })};
  }
  if(kind==="requests") return {title:t("expRequests"),
    headers:[t("room"),t("name"),t("taskType"),"Detail",t("day"),"Note","Status","Date"],
    rows:S.requests.map(r=>[r.room,r.guest_name||"",r.type,r.detail,r.date||"",r.note||"",r.status,fmtDate(r.created_at)])};
  if(kind==="chat") return {title:t("expChat"),
    headers:[t("room"),"From","Message","Date"],
    rows:S.messages.map(m=>[m.room,m.sender==="team"?"Team":"Guest",m.text,fmtDate(m.created_at)])};
  if(kind==="users") return {title:t("expUsers"),
    headers:[t("shirtNumber"),t("displayName"),t("user"),t("roleLabel"),t("nationality"),t("genderLbl")],
    rows:S.users.slice().sort((a,b)=>(a.number||99)-(b.number||99))
      .map(u=>[u.number?("#"+u.number):"", u.display_name||"", u.username, u.role,
               u.nationality||"", u.gender?genderLabel(u.gender):""])};
  if(kind==="monthatt"){
    /* export whichever month she picked, not only the one on screen */
    const mk=S.exportMonth || currentAttMonth();
    const n=monthDays(mk), team=attTeamFor(mk);
    const headers=[t("displayName")]
      .concat(Array.from({length:n},(_,i)=>String(i+1)))
      .concat([t("attTotalsP"), t("attTotalsO"), t("attTotalsA")]);
    /* On the official sheet a day off is a paid day, so it counts as present.
       The days-off column still shows them separately. */
    const rows=team.map(u=>{
      const tot=attTotals(u,mk);
      return [u.display_name||u.username]
        .concat(Array.from({length:n},(_,i)=>isFutureDay(mk,i+1)?"":attStatus(u,mk,i+1)))
        .concat([String(tot.P+tot.O), String(tot.O), String(tot.A)]);
    });
    if(team.length){
      const mt=attMonthTotals(mk);
      rows.push([t("totalRow")].concat(Array.from({length:n},()=>""))
        .concat([String(mt.P+mt.O), String(mt.O), String(mt.A)]));
    }
    const soFar=(mk===currentAttMonth()) ? daysSoFar(mk) : n;
    return {title:t("monthAtt")+" — "+monthLabel(mk)+(soFar<n?" ("+t("upToToday")+")":""),
            headers, rows, signatures:true};
  }
  if(kind==="teamsummary"){
    const st=teamStats();
    const rows=[
      [t("totalTeam"), String(st.total)],
      [t("totalEntertainers"), String(st.entertainers)],
      [t("genderM"), String(st.byGender.male)],
      [t("genderF"), String(st.byGender.female)]
    ];
    if(st.byGender.none) rows.push([t("genderNone"), String(st.byGender.none)]);
    const dToday=todayIndex(), dutyT=dayDutyStats(dToday);
    rows.push([t("workingToday"), String(dutyT.workingCount)]);
    rows.push([t("dayOffToday"), String(dutyT.offCount)]);
    st.natList.forEach(n=>rows.push([t("byNationality")+" · "+n.name, String(n.count)]));
    return {title:t("teamSummary"), headers:["",""], rows};
  }
  if(kind==="guests") return {title:t("expGuests"),
    headers:[t("room"),t("user"),t("name"),t("nationality"),t("phone"),t("arrival"),t("departure"),t("daysHere"),t("joinedActs"),t("tickets"),t("requests")],
    rows:S.accounts.map(a=>{ const info=guestFullInfo(a.room)||{};
      return [a.room,a.username||a.room,a.name,a.nationality||"",a.phone||"",a.arrival||"",a.departure||"",info.days!=null?info.days:"",(info.activities||[]).join(", "),info.tickets||0,info.requests||0]; })};
  if(kind==="tickets") return {title:t("expTickets"),
    headers:[t("room"),t("name"),"Ticket","Qty","Status",t("handTo"),"Date"],
    rows:S.orders.map(o=>[o.room,o.guest_name,tkName(o.ticket_id),o.qty,o.status,o.collect_from||"",fmtDate(o.created_at)])};
  if(kind==="feedback"){
    const list=exportFeedbackList();
    return {title:t("expFeedback")+fbFilterNote(),
      landscape:true,
      stars:{from:3, to:3+fbDeptKeys().length},          // Overall + every department
      notes:list.map(f=>fbComment(f)),                    // printed full width under the row
      noteLabel:t("comment"),
      headers:[t("room"),t("fbGuestName"),t("nationality"),t("fbOverall")]
        .concat(fbDeptKeys().map(fbDeptLabel))
        .concat([t("fbCollectedBy"),"Date"]),
      rows:list.map(f=>{ const d=fbDepts(f);
        return [f.room,f.guest_name||"",f.nationality||"",fbOverall(f)||""]
          .concat(fbDeptKeys().map(k=>+d[k]>0?+d[k]:""))
          .concat([teamName(f.by_user),fmtDate(f.created_at)]); })};
  }
  if(kind==="fbdepts"){
    const st=fbDeptStats(exportFeedbackList()).sort((a,b)=>b.avg-a.avg);
    return {title:t("fbDeptSheet")+fbFilterNote(),
      stars:{from:1, to:1},
      headers:[t("fbByDept"),t("avgRate"),t("fbResponses")],
      rows:st.map(d=>[fbDeptLabel(d.k), d.avg.toFixed(2), d.n])};
  }
  if(kind==="program") return {title:t("manage")+exportFilterNote(),
    headers:[t("day"),t("time"),t("actName"),t("category"),t("location"),t("entertainer"),t("capacity"),t("makeHighlight")],
    rows:exportActivities().slice().sort((x,y)=>(x.day-y.day)||String(x.time).localeCompare(String(y.time)))
      .map(a=>[t("days")[a.day]||"",a.time||"",a.name||"",catLabel(normCat(a)),a.location||"",a.entertainer||"",a.capacity||0,a.highlight?"★":""])};
  if(kind==="dayplan"){
    // One clean row per day — exactly what hotel management needs at a glance
    const onlyDay=expDay();
    const rows=DAY_PLAN.filter(dp=>onlyDay==null || dp.day===onlyDay).map(dp=>{
      const evs=S.activities.filter(a=>{
        const c=normCat(a); return a.day===dp.day && (c==="mEvents"||c==="eParty");
      }).sort((x,y)=>String(x.time).localeCompare(String(y.time)))
        .map(a=>String(a.time||"").split(/\s*[–—-]\s*/)[0]+" "+a.name+(a.location?" ("+a.location+")":""));
      const duty=dayDutyStats(dp.day);
      return [
        t("days")[dp.day]||dp.name,
        dp.theme,
        dp.dress,
        evs.length?evs.join(" | "):"—",
        dp.liveBand||"—",
        dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc,
        personTags(dp.off)||"—",
        personTag(dp.entrance),
        String(duty.workingCount),
        String(duty.offCount)
      ];
    });
    return {title:t("dayPlan"),
      headers:[t("day"),t("restaurantTheme"),t("dressCode"),t("eventsToday"),
               t("liveBandLbl"),t("eveningShowLbl"),t("dayOff"),t("entranceDuty"),
               t("workingToday"),t("dayOffToday")],
      rows};
  }
  if(kind==="todayplan"){
    // Just today — the sheet she sends to management each morning
    const d=todayIndex();
    const dp=dayPlanFor(d);
    const evs=S.activities.filter(a=>{
      const c=normCat(a); return a.day===d && (c==="mEvents"||c==="eParty");
    }).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    // Management sheet — the day first, then the team totals at the end.
    // Order exactly as the hotel reads it. No practice, no internal notes.
    const rows=[ [t("restaurantTheme"), dp.theme] ];
    evs.forEach(a=>rows.push([t("eventsToday"),
      String(a.time||"").split(/\s*[–—-]\s*/)[0]+" — "+a.name+(a.location?" ("+a.location+")":"")]));
    if(!evs.length) rows.push([t("eventsToday"),"—"]);
    rows.push([t("liveBandLbl"), dp.liveBand||"—"]);
    rows.push([t("eveningShowLbl"), dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc]);
    rows.push([t("dressCode"), dp.dress]);
    rows.push([t("entranceDuty"), personTag(dp.entrance)]);
    rows.push([t("dayOff"), personTags(dp.off)||"—"]);
    // ---- team totals ----
    const st=teamStats(), duty=dayDutyStats(d);
    if(st.total){
      // entertainers working today = entertainers minus the ones off (manager excluded)
      const offEnt=duty.off.filter(u=>u.role!=="manager").length;
      rows.push([t("workingEntToday"), String(Math.max(0, st.entertainers-offEnt))+" / "+st.entertainers]);
      rows.push([t("totalAllTeam"), String(st.total)]);
      if(st.natList.length) rows.push([t("byNationality"), st.natList.map(n=>n.name+" "+n.count).join(" · ")]);
      const gen=[st.byGender.male+" "+t("genderM"), st.byGender.female+" "+t("genderF")];
      if(st.byGender.none) gen.push(st.byGender.none+" "+t("genderNone"));
      rows.push([t("byGender"), gen.join(" · ")]);
    }
    return {title:(t("days")[d]||"")+" · "+t("dayPlan"), headers:["",""], rows};
  }
  return null;
}
const EXPORT_KINDS=["todayplan","dayplan","monthatt","teamsummary","program","guests","bookings","requests","chat","tickets","feedback","fbdepts","users"];
function exportKindLabel(k){ return {todayplan:t("todayPlanExp"),monthatt:t("attExport"),teamsummary:t("teamSummary"),program:t("manage"),dayplan:t("dayPlan"),guests:t("expGuests"),bookings:t("expBookings"),requests:t("expRequests"),chat:t("expChat"),tickets:t("expTickets"),feedback:t("expFeedback"),fbdepts:t("fbDeptSheet"),users:t("expUsers")}[k]; }
async function loadXLSX(){
  if(window.XLSX) return true;
  return new Promise(res=>{const sc=document.createElement("script");
    sc.src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
    sc.onload=()=>res(true); sc.onerror=()=>res(false); document.head.appendChild(sc);});
}
function downloadBlob(name,blob){
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=name;
  document.body.appendChild(a); a.click(); a.remove();
}
async function exportExcelSets(sets,fname){
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      const ws=XLSX.utils.aoa_to_sheet([headers,...rows]);
      const name=(ds.title||"Sheet").replace(/[\\/?*\[\]:]/g,"").slice(0,28)||"Sheet";
      XLSX.utils.book_append_sheet(wb,ws,name);
    });
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const lines=[];
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      lines.push([ds.title]); lines.push(headers); rows.forEach(r=>lines.push(r)); lines.push([]); });
    const csv=lines.map(r=>r.map(c=>'"'+String(c==null?"":c).replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
}
function exportPdfSets(sets,titleText){
  const esc2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const css="body{font-family:Arial,Helvetica,sans-serif;color:#2B1F16;padding:26px}"
    +"h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px;color:#6B4A32;border-bottom:2px solid #B98A5C;padding-bottom:4px}"
    +"table{border-collapse:collapse;width:100%;margin-bottom:10px;font-size:11px}"
    +"th{background:#F2E7D6;text-align:left;padding:6px 8px;border:1px solid #E4D3BC}"
    +"td{padding:5px 8px;border:1px solid #EEE3D2;vertical-align:top}"
    +".sub{color:#8A7358;font-size:12px;margin-bottom:6px}@media print{h2{page-break-after:avoid}}"
    +"table.sig{margin-top:26px;page-break-inside:avoid}"
    +"table.sig th{text-align:center;font-size:11px;letter-spacing:.04em;text-transform:uppercase}"
    +"td.sigbox{height:74px;border:1px solid #E4D3BC}"
    +"table.rated{font-size:10px}table.rated th{font-size:9px;padding:5px 3px;line-height:1.25}"
   +".band{flex-wrap:wrap}"
    +"table.rated td{padding:4px 3px}"
    +"td.st{text-align:center;white-space:nowrap;font-size:11px;letter-spacing:0}"
    +".sg{color:#DDD1BE}.nr{color:#CFC3B0}"
    +".sx{display:block;font-size:9px;color:#8A7358;letter-spacing:0}"
    +"tr.note td{background:#FBF7F0;color:#4A3826;font-size:11px;border-top:0;line-height:1.5}"
    +"tr.note b{color:#8A7358;font-weight:600}"
    +"tr.main td{border-bottom:0}"
    +(sets.some(d=>d.landscape)?"@page{size:A4 landscape;margin:12mm}":"");
  const starCell=(v,exact)=>{
    const n=Math.round(+v||0);
    if(!n) return '<span class=nr>\u2014</span>';
    const col = n<=3 ? "#C0392B" : n===4 ? "#E08A2E" : "#C9A227";
    return '<span style="color:'+col+'">'+"\u2605".repeat(n)+'</span>'
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span>'
      +(exact!=null?'<span class=sx>'+esc2(exact)+'</span>':'');
  };
  let html="<h1>"+esc2(titleText)+"</h1><div class=sub>"+esc2(new Date().toLocaleString())+"</div>";
  sets.forEach(ds=>{
    html+="<h2>"+esc2(ds.title)+"</h2><table"+(ds.stars?" class=rated":"")+"><thead><tr>"
      +ds.headers.map(h=>"<th>"+esc2(h)+"</th>").join("")+"</tr></thead><tbody>";
    html+=ds.rows.map((r,ri)=>{
      const hasNote=ds.notes && ds.notes[ri];
      let out="<tr"+(hasNote?" class=main":"")+">"+r.map((c,ci)=>{
        const isStar=ds.stars && ci>=ds.stars.from && ci<=ds.stars.to;
        if(!isStar) return "<td>"+esc2(c)+"</td>";
        const exact = ds.exact ? ds.exact[ri] : (ci===ds.stars.from && String(c).includes(".") ? c : null);
        return "<td class=st>"+starCell(c, exact)+"</td>";
      }).join("")+"</tr>";
      if(hasNote) out+="<tr class=note><td colspan="+ds.headers.length+"><b>"
        +esc2(ds.noteLabel||"")+":</b> "+esc2(ds.notes[ri])+"</td></tr>";
      return out;
    }).join("");
    if(!ds.rows.length) html+="<tr><td colspan="+ds.headers.length+" style=\"color:#999\">—</td></tr>";
    html+="</tbody></table>";
    if(ds.signatures){
      const sigRoles=[t("sigEntertainment"), t("sigSecurity"), t("sigFB"), t("sigGM")];
      html+="<table class=sig><tr>"
        +sigRoles.map(r=>"<th>"+esc2(r)+"</th>").join("")
        +"</tr><tr>"
        +sigRoles.map(()=>"<td class=sigbox></td>").join("")
        +"</tr></table>";
    }
  });
  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+esc2(titleText)+"</title><meta charset=utf-8><style>"+css+"</style></head><body>"+html+"<scr"+"ipt>setTimeout(function(){window.print();},350);<\/scr"+"ipt></body></html>");
  w.document.close();
}
/* An attendance sheet gets an official heading; anything else keeps the plain one. */
/* Months she can export: this one and the seventeen before it. */
/* What she ticked in the export screen: a weekday, a part of the day, or both. */
function expDay(){
  if(S.exportDate){
    const dt=new Date(String(S.exportDate)+"T12:00:00");
    if(!isNaN(dt.getTime())) return (dt.getDay()+6)%7;
  }
  return S.exportDay===""||S.exportDay==null ? null : +S.exportDay;
}
function expSlot(){ return S.exportSlot || ""; }
function inExportSlot(time){
  const slot=expSlot(); if(!slot) return true;
  const m=timeToMin(time); if(m==null) return false;
  return operationSlotFromMinutes(m)===slot;
}
/* activities that survive the day and time filters */
function exportActivities(){
  const d=expDay();
  return (S.activities||[])
    .filter(a=>d==null || a.day===d)
    .filter(a=>inExportSlot(a.time));
}
/* Feedback the manager asked for: a month, a weekday and a part of the day.
   All three are optional and stack. */
function exportFeedbackList(){
  const mk=S.fbMonth||"", day=S.fbDate||"", slot=expSlot();
  const list=(S.feedback||[]).filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    if(!ts || isNaN(ts.getTime())) return !mk && !day && !slot;
    if(day) return localDateKey(ts)===day && slotOk(ts,slot);   // one exact date wins over the month
    if(mk && localMonthKey(ts)!==mk) return false;
    return slotOk(ts,slot);
  });
  return list.sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
}
function localMonthKey(dt){
  return dt.getFullYear()+"-"+String(dt.getMonth()+1).padStart(2,"0");
}
function localDateKey(dt){
  return localMonthKey(dt)+"-"+String(dt.getDate()).padStart(2,"0");
}
function slotOk(ts,slot){
  if(!slot) return true;
  const m=ts.getHours()*60+ts.getMinutes();
  return operationSlotFromMinutes(m)===slot;
}
/* Reads back as "Wednesday 3 September 2026" so the report says what it covers. */
/* 03/09 · 22:29 — short enough for a narrow column, still unambiguous. */
function shortStamp(iso){
  const dt=iso?new Date(iso):null;
  if(!dt || isNaN(dt.getTime())) return "";
  const p=n=>String(n).padStart(2,"0");
  return p(dt.getDate())+"/"+p(dt.getMonth()+1)+" \u00b7 "+p(dt.getHours())+":"+p(dt.getMinutes());
}
function niceDate(key){
  const bits=String(key||"").split("-");
  if(bits.length!==3) return key||"";
  const dt=new Date(+bits[0], +bits[1]-1, +bits[2]);
  if(isNaN(dt.getTime())) return key;
  return (t("days")[(dt.getDay()+6)%7]||"")+" "+dt.getDate()+" "+(t("months")[dt.getMonth()]||"")+" "+dt.getFullYear();
}
function fbFilterBits(){
  const bits=[];
  if(S.fbDate) bits.push(niceDate(S.fbDate));
  else if(S.fbMonth) bits.push(monthLabel(S.fbMonth));
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.filter(Boolean);
}
function fbFilterNote(){
  const bits=fbFilterBits();
  return bits.length ? " \u00b7 "+bits.join(" \u00b7 ") : "";
}
function exportFilterNote(){
  const bits=[];
  if(S.exportDate){
    const p=String(S.exportDate).split("-");
    if(p.length===3) bits.push((+p[2])+"/"+(+p[1])+"/"+p[0]);
  }else{
    const d=expDay(); if(d!=null) bits.push(t("days")[d]||"");
  }
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.length ? " · "+bits.join(" · ") : "";
}
function exportMonthOptions(){
  const out=[]; const d=hotelNow(); d.setDate(1);
  for(let i=0;i<18;i++){
    const mk=d.toISOString().slice(0,7);
    out.push([mk, monthLabel(mk)]);
    d.setMonth(d.getMonth()-1);
  }
  return out;
}
function exportTitle(sets){
  const hotel=(S.settings && S.settings.name) || "";
  const onlyAtt = sets.length===1 && sets[0].signatures;
  return onlyAtt ? (t("officialAtt").replace("{hotel}", hotel).trim())
                 : (hotel+" — "+t("exportData"));
}
function openExportModal(){
  let picked=new Set(["guests"]);
  S.fbMonth=""; S.fbDate="";          // the month picker here belongs to attendance

  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("exportData")}</h3>
    <p class="mini" style="margin-bottom:10px">${t("exportWhat")}</p>
    <div class="explist">
      ${EXPORT_KINDS.map(k=>`<label class="exp-it"><input type="checkbox" data-exp="${k}" ${k==="guests"?"checked":""}> <span>${exportKindLabel(k)}</span></label>`).join("")}
      <label class="exp-it exp-all"><input type="checkbox" id="exp-all"> <span>${t("expAll")}</span></label>
    </div>
    <div id="exp-month-row" style="display:none">
      <label style="margin-top:12px">${t("whichMonth")}</label>
      <select id="exp-month">
        ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===(S.exportMonth||currentAttMonth())?"selected":""}>${esc(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="row2" style="margin-top:12px">
      <div><label>${t("whichDay")}</label>
        <select id="exp-day">
          <option value="">${t("allDays")}</option>
          ${t("days").map((d,i)=>`<option value="${i}" ${String(S.exportDay)===String(i)?"selected":""}>${esc(d)}</option>`).join("")}
        </select></div>
      <div><label>${t("whichTime")}</label>
        <select id="exp-slot">
          <option value="">${t("allDayLong")}</option>
          ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
        </select></div>
    </div>
    <p class="mini" id="exp-note" style="margin-top:6px"></p>
    <button class="btn" id="exp-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="exp-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="exp-x">${t("close")}</button>`);
  const boxes=[...wrap.querySelectorAll("[data-exp]")];
  const monthRow=wrap.querySelector("#exp-month-row");
  const monthSel=wrap.querySelector("#exp-month");
  const showMonth=()=>{ if(monthRow) monthRow.style.display = picked.has("monthatt") ? "" : "none"; };
  const sync=()=>{ picked=new Set(boxes.filter(b=>b.checked).map(b=>b.dataset.exp)); showMonth(); };
  if(monthSel) monthSel.onchange=()=>{ S.exportMonth=monthSel.value; };
  const daySel=wrap.querySelector("#exp-day"), slotSel=wrap.querySelector("#exp-slot");
  const note=wrap.querySelector("#exp-note");
  const applyFilters=()=>{
    if(daySel)  S.exportDay  = daySel.value;
    if(slotSel) S.exportSlot = slotSel.value;
    if(note) note.textContent = (S.exportDay==="" && !S.exportSlot)
      ? t("noFilterNote") : t("filterNote")+exportFilterNote().replace(/^ · /," ");
  };
  if(daySel)  daySel.onchange=applyFilters;
  if(slotSel) slotSel.onchange=applyFilters;
  applyFilters();
  boxes.forEach(b=>b.onchange=sync);
  sync();
  wrap.querySelector("#exp-all").onchange=e=>{ boxes.forEach(b=>{b.checked=e.target.checked;}); sync(); };
  wrap.querySelector("#exp-x").onclick=()=>wrap.remove();
  const gather=()=>{
    if(monthSel) S.exportMonth=monthSel.value;      // whichever month she chose
    applyFilters();                                  // and the day / time she ticked
    return EXPORT_KINDS.filter(k=>picked.has(k)).map(buildDataset).filter(Boolean);
  };
  const fname="entertainment-data-"+todayISO();
  wrap.querySelector("#exp-xlsx").onclick=async ()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    await exportExcelSets(sets,fname); toast(t("saved"));
  };
  wrap.querySelector("#exp-pdf").onclick=()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    exportPdfSets(sets, exportTitle(sets)); wrap.remove();
  };
}
async function exportReport(){
  const weekAgo=Date.now()-7*864e5;
  const weekTasks=S.tasks.filter(x=>!x.created_at||Date.parse(x.created_at)>=weekAgo);
  const rank=rankingRows().map((r,i)=>[i+1,r.u.display_name||r.u.username,r.done,r.late,r.cant,r.open,r.points]);
  const taskRows=weekTasks.map(x=>[String(x.created_at||"").slice(0,16).replace("T"," "),taskTypeLabel(x.type),x.title,
    x.assigned_to?((S.users.find(u=>u.username===x.assigned_to)||{}).display_name||x.assigned_to):t("allTeam"),
    x.location||"",String(x.due||"").replace("T"," "),
    x.status==="done"?(x.was_still?t("done")+" ("+t("late")+")":t("done")):x.status==="cant"?t("cantDo"):x.status==="still"?t("still"):x.status==="accepted"?t("accepted"):t("statusNew")]);
  const fbRows=S.feedback.filter(f=>!f.created_at||Date.parse(f.created_at)>=weekAgo)
    .map(f=>[String(f.created_at||"").slice(0,16).replace("T"," "),f.room,f.nationality||"",f.rate,f.comment||"",f.by_user||""]);
  const fname="entertainment-report-"+todayISO();
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank]),"Ranking");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows]),"Tasks");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]),"Feedback");
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const csv=[["RANKING"],["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank,[],
      ["TASKS"],["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows,[],
      ["FEEDBACK"],["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]
      .map(r=>r.map(c=>'"'+String(c??"").replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
  toast(t("saved"));
}
function attendanceInner(){
  const todayIdx=todayIndex(), date=todayISO();
  const acts=S.activities.filter(a=>a.day===todayIdx).sort((x,y)=>x.time.localeCompare(y.time));
  return `<p class="mini" style="margin-bottom:10px">${t("today")} · ${t("days")[todayIdx]}</p>`
    + (acts.length?`<div class="card">${acts.map(a=>{
      const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
      const pres=bks.filter(b=>S.attendance.some(x=>x.booking_id===b.id&&x.date===date)).length;
      return `<div class="booking-line"><span>${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></span>
        <span class="pill">${pres}/${bks.length} ${t("present")}</span></div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
/* Settings is a hub of small pages, not one long form. */
const SETTINGS_GROUPS=[
  {head:"secLook", items:[
    ["set:theme","palette","setTheme","setThemeSub"],
    ["set:publictext","sparkle","Public experience","Explore & sign-in text"],
    ["set:brand","sparkle","setBrand","setBrandSub"],
    ["builder","grid","setMenus","setMenusSub"]]},
  {head:"secManage", items:[
    ["set:features","check","setFeatures","setFeaturesSub"],
    ["set:notif","bell","setNotif","setNotifSub"],
    ["set:links","star","setLinksT","setLinksSub"],
    ["bus","bus","busItem","busItem"]]},
  {head:"secSettings", items:[
    ["set:location","pin","setLocation","setLocationSub"],
    ["export","download","setData","setDataSub"],
    ["set:advanced","grid","setAdvanced","setAdvancedSub"]]}
];
function settingsHubView(){
  return `<div class="screen fadein">
    ${topBar(t("settingsHub"),S.session.name)}
    <p class="mini" style="margin:-4px 0 16px">${t("settingsSub")}</p>
    ${arrangeBtn("settings")}
    ${SETTINGS_GROUPS.map(g=>{
      const ord=pageOrder("settings");
      const items=g.items.filter(it=>ord.includes(it[0])).sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
      if(!items.length) return "";
      return `
      <div class="set-sec">${t(g.head)}</div>
      <div class="card set-list">
        ${items.map(([id,icn,lb,sub])=>`<button class="set-it" data-hub="${id}">
          <span class="set-ic">${ic(icn,19)}</span>
          <span class="set-mid"><b>${esc(t(lb))}</b>${sub&&sub!==lb?`<span class="mini">${esc(t(sub))}</span>`:""}</span>
          <span class="set-go">${ic("back",16)}</span>
        </button>`).join("")}
      </div>`;}).join("")}
  </div>`;
}
function setThemeView(){
  const st=S.settings;
  const fontOpts=[["elegant",t("fontElegant")],["royal",t("fontRoyal")],["modern",t("fontModern")],["soft",t("fontSoft")]];
  const btnOpts=[["rounded",t("btnRounded")],["pill",t("btnPill")],["square",t("btnSquare")]];
  return `<div class="screen fadein">
    ${topBar(t("setTheme"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("themeHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("themeHint")}</p>
      <div class="theme-grid">
        ${paletteList().map(k=>{
          const p=PALETTES[k], c=p.light;
          return `<button class="theme-card ${st.palette===k?"on":""}" data-palette="${k}">
            <span class="tc-sw"><i style="background:${c.primary}"></i><i style="background:${c.accent}"></i><i style="background:${c.bg};border:1px solid ${c.line}"></i></span>
            <span class="tc-lb">${esc(p.label)}</span></button>`;
        }).join("")}
        <button class="theme-card ${!PALETTES[st.palette]?"on":""}" data-palette="custom">
          <span class="tc-sw"><i style="background:${esc(st.primary)}"></i><i style="background:${esc(st.accent)}"></i><i style="background:${esc(st.bg)};border:1px solid var(--line)"></i></span>
          <span class="tc-lb">${t("themeCustom")}</span></button>
      </div>
      <label style="margin-top:14px">${t("fontSizeLbl")}</label>
      <select id="s-fs">
        ${[["small","fsSmall"],["normal","fsNormal"],["large","fsLarge"],["xl","fsXl"]].map(([k,lb])=>
          `<option value="${k}" ${(st.fontScale||"normal")===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
        <input id="s-autodark" type="checkbox" style="width:auto" ${st.autoDark?"checked":""}> ${t("autoDarkLbl")}</label>

      <label>${t("colorsHead")}</label>
      <div class="row2">
        <div><label style="margin-top:0">${t("primaryC")}</label><input id="s-primary" type="color" value="${esc(st.primary)}"></div>
        <div><label style="margin-top:0">${t("accentC")}</label><input id="s-accent" type="color" value="${esc(st.accent)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("bgC")}</label><input id="s-bg" type="color" value="${esc(st.bg)}"></div>
        <div><label>${t("textC")}</label><input id="s-text" type="color" value="${esc(st.textColor)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("navC")}</label><input id="s-navbg" type="color" value="${esc(st.navBg)}"></div>
        <div><label>${t("navActiveC")}</label><input id="s-navon" type="color" value="${esc(st.navActive)}"></div>
      </div>
      <label>${t("styleHead")}</label>
      <select id="s-font">${fontOpts.map(([v,l])=>`<option value="${v}" ${st.fontStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <label>${t("buttonHead")}</label>
      <select id="s-btn">${btnOpts.map(([v,l])=>`<option value="${v}" ${st.buttonStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setBrandView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setBrand"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("secIdentity")}</label>
      <div class="photo-pick"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("logoLbl")}</b><span class="mini">${t("logoHint")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>
      <input id="s-logo" type="hidden" value="${esc(st.logo||"")}">
      ${st.logo?`<button class="btn sm ghost" id="s-logo-rm" type="button" style="margin-bottom:10px">${ic("trash",14)} ${t("removeLogo")}</button>`:""}
      <input id="s-hotel" value="${esc(st.hotelName||"")}" placeholder="${esc(t("hotelNameLbl"))}" style="margin-bottom:8px">
      <input id="s-contact" value="${esc(st.contact||"")}" placeholder="${esc(t("contactLbl"))}" style="margin-bottom:8px">
      <input id="s-cur" value="${esc(st.currency||"")}" placeholder="${esc(t("currencyLbl"))}" style="margin-bottom:8px">
      <label style="margin-top:16px">${t("appName")}</label><input id="s-name" value="${esc(st.name)}">
      <label>${t("appSubtitle")}</label><input id="s-sub" value="${esc(st.subtitle)}" placeholder="${t("appSub")}">
      <label>${t("welcomeMsgLbl")}</label><textarea id="s-welcome" rows="2">${esc(st.welcomeMsg)}</textarea>
      <label>${t("menuHead")}</label>
      <input id="s-mhome" value="${esc(st.menuHome)}" placeholder="${t("home")}" style="margin-bottom:8px">
      <input id="s-mprog" value="${esc(st.menuProgram)}" placeholder="${t("program")}" style="margin-bottom:8px">
      <input id="s-mtick" value="${esc(st.menuTickets)}" placeholder="${t("tickets")}" style="margin-bottom:8px">
      <input id="s-mchat" value="${esc(st.menuChat)}" placeholder="${t("chat")}" style="margin-bottom:8px">
      <input id="s-mstay" value="${esc(st.menuStay)}" placeholder="${t("myStay")}">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setFeaturesView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setFeatures"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("featuresLbl")}</label>
      <div class="feat-list">
        ${[["quiz","featQuiz"],["tickets","featTickets"],["gallery","featGallery"],["bus","featBus"],["hotelinfo","featInfo"],["weather","weatherTab"]].map(([k,lb])=>
          `<label class="feat-it"><input type="checkbox" class="feat-cb" value="${k}" ${featureOn(k)?"checked":""}> ${t(lb)}</label>`).join("")}
      </div>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLocationView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLocation"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("weatherLoc")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("weatherLocHint")}</p>
      <div class="row2">
        <div><input id="s-lat" value="${esc(st.lat||"")}" placeholder="27.2579" inputmode="decimal"></div>
        <div><input id="s-lon" value="${esc(st.lon||"")}" placeholder="33.8116" inputmode="decimal"></div>
      </div>
      <label>${t("timezoneLbl")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("timezoneHint")}</p>
      <select id="s-tz">${TIMEZONES.map(z=>`<option value="${esc(z)}" ${(st.timezone||"")===z?"selected":""}>${z||"—"}</option>`).join("")}</select>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLinksView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLinksT"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("linksHead")}</label>
      <input id="s-trip" value="${esc(st.tripadvisor)}" placeholder="Tripadvisor URL" style="margin-bottom:8px">
      <input id="s-goog" value="${esc(st.google)}" placeholder="Google URL" style="margin-bottom:8px">
      <input id="s-holi" value="${esc(st.holidaycheck)}" placeholder="HolidayCheck URL">
      <label>${t("socialHead")}</label>
      <input id="s-insta" value="${esc(st.instagram)}" placeholder="Instagram URL" style="margin-bottom:8px">
      <input id="s-tiktok" value="${esc(st.tiktok)}" placeholder="TikTok URL" style="margin-bottom:8px">
      <input id="s-fb" value="${esc(st.facebook)}" placeholder="Facebook URL" style="margin-bottom:8px">
      <input id="s-yt" value="${esc(st.youtube)}" placeholder="YouTube URL" style="margin-bottom:8px">
      <label style="margin-top:4px">${t("whatsappLbl")}</label>
      <input id="s-wa" value="${esc(st.whatsapp)}" placeholder="+20 100 000 0000" inputmode="tel">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setAdvancedView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setAdvanced"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:10px">${t("serverHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("serverHint")}</p>
      <input id="s-aiep" value="${esc(st.aiEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/ai-assistant" style="margin-bottom:8px">
      <input id="s-pushep" value="${esc(st.pushEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/send-push">
            <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setNotifView(){
  return `<div class="screen fadein">
    ${topBar(t("setNotif"),S.session.name)}
    ${hubBack()}
    <div class="card notif-card" id="notif-toggle">
      <div class="nt-l"><span class="nt-ic">${ic(notifSoundOn()?"bell":"belloff",20)}</span>
        <div><b>${t("notifSound")}</b><p class="mini">${t("enableNotif")}</p></div></div>
      <span class="switch ${notifSoundOn()?"on":""}"><span class="knob"></span></span>
    </div>
  </div>`;
}

/* ---------------- modals ---------------- */
function baseModal(html){
  const wrap=document.createElement("div"); wrap.className="modal-bg";
  wrap.innerHTML=`<div class="modal"><div class="grab"></div>${html}</div>`;
  document.body.appendChild(wrap);
  wrap.onclick=e=>{ if(e.target===wrap) wrap.remove(); };
  return wrap;
}
function openBookModal(a){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const wrap=baseModal(`
    <h3>${esc(a.name)}</h3>
    <p class="mini">${mi("clock")}${esc(a.time)} · ${mi("pin")}${esc(a.location)}${unlimited?"":" · "+(full?t("full"):left+" "+t("seatsLeft"))}</p>
    <p style="margin-top:8px">${esc(a.desc)}</p>
    <label>${t("persons")}</label>
    <input id="m-ad" type="number" min="1" max="20" value="1" inputmode="numeric">
    <button class="btn" id="m-go">${full?t("waitlist"):t("confirm")}</button>
    <button class="btn ghost" id="m-x">${t("close")}</button>`);
  wrap.querySelector("#m-x").onclick=()=>wrap.remove();
  wrap.querySelector("#m-go").onclick=async ()=>{
    const g=S.session;
    await DB.addBooking({activity_id:a.id,room:g.room,guest_name:g.name,phone:g.phone||"",nationality:g.nationality||"",
      adults:Math.max(1,+wrap.querySelector("#m-ad").value||1),children:0,
      status: full?"waitlist":"booked"});
    wrap.remove(); toast(full?t("waitOk"):t("bookingOk")); render();
  };
}
function openTicketBuyModal(tk){
  const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
  const max=left!==null?Math.max(1,Math.min(10,left)):10;
  const team=teamMemberList();
  let chosen="";
  const wrap=baseModal(`
    <h3>${esc(tk.name)}</h3>
    <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}</p>
    <p style="margin-top:8px">${esc(tk.desc)}</p>
    <p class="mini" style="margin-top:8px">${t("payNote")}</p>
    <div class="row2" style="align-items:end">
      <div><label>${t("qty")}</label><input id="tq" type="number" min="1" max="${max}" value="1"></div>
      <div style="text-align:end;font-family:var(--font-display);font-size:24px;color:var(--cacao);padding-bottom:10px">${esc(tk.price||"")}</div>
    </div>
    ${team.length?`<label>${t("collectFrom")}</label>
    <div class="memberrow">
      ${team.map(m=>`<button type="button" class="memb" data-memb="${esc(m.name)}">
        <span class="mb-av">${m.photo?`<img src="${esc(m.photo)}" alt="">`:esc(m.name.trim().charAt(0).toUpperCase())}</span>
        <span class="mb-nm">${esc(m.name)}</span>
      </button>`).join("")}
    </div>`:""}
    <button class="btn" id="t-go">${t("buyTicket")}</button>
    <div class="err" id="t-err"></div>
    <button class="btn ghost" id="t-x">${t("close")}</button>`);
  wrap.querySelector("#t-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-memb]").forEach(b=>b.onclick=()=>{
    chosen=b.dataset.memb;
    wrap.querySelectorAll(".memb").forEach(x=>x.classList.toggle("on",x===b));
    wrap.querySelector("#t-err").textContent="";
  });
  wrap.querySelector("#t-go").onclick=async ()=>{
    if(team.length && !chosen){ wrap.querySelector("#t-err").textContent=t("chooseMember"); return; }
    const g=S.session;
    const qty=Math.max(1,Math.min(max,+wrap.querySelector("#tq").value||1));
    await DB.addOrder({ticket_id:tk.id,room:g.room,guest_name:g.name,nationality:g.nationality||"",
      qty,status:"reserved",collect_from:chosen});
    wrap.remove(); toast(t("ticketOk")); render();
  };
}
function openRequestModal(type){
  const isSong=type==="song";
  const wrap=baseModal(`
    <h3>${ic(isSong?"music":"gift",20)} ${isSong?t("songRequest"):t("birthdayRequest")}</h3>
    <label>${isSong?t("songName"):t("forWhom")}</label><input id="r-detail">
    ${isSong?"":`<label>${t("birthdayDate")}</label><input id="r-date" type="date">`}
    <label>${t("reqNote")}</label><textarea id="r-note" rows="2"></textarea>
    <button class="btn" id="r-go">${t("send")}</button>
    <button class="btn ghost" id="r-x">${t("close")}</button>`);
  wrap.querySelector("#r-x").onclick=()=>wrap.remove();
  wrap.querySelector("#r-go").onclick=async ()=>{
    const detail=wrap.querySelector("#r-detail").value.trim();
    if(!detail) return;
    const g=S.session;
    await DB.addRequest({room:g.room,guest_name:g.name,type,detail,
      date:isSong?"":(wrap.querySelector("#r-date").value||""),
      note:wrap.querySelector("#r-note").value.trim(),status:"new"});
    wrap.remove(); toast(t("saved")); render();
  };
}
function openTaskAddModal(){
  const staffOpts=S.users.filter(u=>u.role==="staff").map(u=>`<option value="${esc(u.username)}">${esc(u.display_name||u.username)}</option>`).join("");
  const typeOpts=TASK_TYPES.map(ty=>`<option value="${ty}">${taskTypeLabel(ty)}</option>`).join("");
  const wrap=baseModal(`
    <h3>${t("addTask")}</h3>
    <label>${t("taskType")}</label><select id="tk-type">${typeOpts}</select>
    <label>${t("actName")}</label><input id="tk-title">
    <label>${t("location")}</label><input id="tk-loc">
    <label>${t("desc")}</label><textarea id="tk-desc" rows="2"></textarea>
    <label>${t("taskFor")}</label>
    <select id="tk-for"><option value="">${t("allTeam")}</option>${staffOpts}</select>
    <label>${t("taskPriority")}</label>
    <select id="tk-pri">${PRIORITIES.map(([k,lb])=>`<option value="${k}" ${k==="normal"?"selected":""}>${t(lb)}</option>`).join("")}</select>
    <label>${t("dueLbl")}</label><input id="tk-due" type="datetime-local">
    <button class="btn" id="tk-go">${t("save")}</button>
    <button class="btn ghost" id="tk-x">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tk-go").onclick=async ()=>{
    const title=wrap.querySelector("#tk-title").value.trim();
    if(!title) return;
    await DB.addTask({type:wrap.querySelector("#tk-type").value,title,
      location:wrap.querySelector("#tk-loc").value.trim(),
      desc:wrap.querySelector("#tk-desc").value.trim(),
      assigned_to:wrap.querySelector("#tk-for").value,
      due:wrap.querySelector("#tk-due").value||"",
      priority:wrap.querySelector("#tk-pri").value,
      created_by:S.session.name||S.session.username||"",
      status:"new",was_still:false,
      history:[{at:new Date().toISOString(), by:S.session.name||S.session.username||"", to:"new"}],
      comments:[]});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* The full feedback sheet: who the guest is and a 1-5 score per department.
   Nothing is compulsory except the room number, so a guest who only wants to
   rate the food can still be recorded. */
function openFeedbackModal(id){
  const ex = id!=null ? (S.feedback||[]).find(f=>String(f.id)===String(id)) : null;
  const vals = ex ? {...fbDepts(ex)} : {};
  const rooms=knownRooms();
  const wrap=baseModal(`
    <h3>${ic("star",18)} ${ex?t("fbEdit"):t("fbNew")}</h3>
    <label>${t("room")}</label>
    <input id="fb-room" inputmode="numeric" list="fbroomlist" autocomplete="off" value="${esc(ex&&ex.room||"")}">
    <datalist id="fbroomlist">${rooms.map(r=>`<option value="${esc(r)}">`).join("")}</datalist>
    ${rooms.length?`<div class="fb-rooms" id="fb-roomchips">${rooms.slice(0,40).map(r=>
      `<button class="fb-rchip" data-fbroom="${esc(r)}">${esc(r)}</button>`).join("")}</div>`:""}
    <p class="mini" id="fb-found" style="margin:6px 0 0">${t("fbRoomHint")}</p>
    <label style="margin-top:12px">${t("fbGuestName")}</label><input id="fb-name" value="${esc(ex&&ex.guest_name||"")}">
    <label>${t("nationality")}</label>
    ${nationField("fb-natsel","fb-nattxt", ex&&ex.nationality||"")}
    <p class="mini" style="margin:4px 0 0">${t("natOtherHint")}</p>
    <label style="margin-top:12px">${t("fbByDept")}</label>
    <p class="mini" style="margin:-4px 0 6px">${t("fbFormHint")}</p>
    <div class="card" id="fb-depts" style="padding:4px 14px"></div>
    <label style="margin-top:12px">${t("comment")}</label><textarea id="fb-com" rows="2">${esc(ex?fbComment(ex):"")}</textarea>
    <button class="btn" id="fb-go">${t("save")}</button>
    <button class="btn ghost" id="fb-x">${t("close")}</button>`);
  const box=wrap.querySelector("#fb-depts");
  const paint=()=>{
    box.innerHTML=fbDeptKeys().map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>
      <span class="fb-stars">${[1,2,3,4,5].map(i=>
        `<button class="fb-st ${i<=(+vals[k]||0)?"on":""}" data-fbset="${k}|${i}" aria-label="${i}">${i<=(+vals[k]||0)?"\u2605":"\u2606"}</button>`).join("")}</span>
      <button class="fb-clear" data-fbclr="${k}" aria-label="${t("fbNotRated")}" ${vals[k]?"":'style="visibility:hidden"'}>\u00d7</button>
    </div>`).join("");
    box.querySelectorAll("[data-fbset]").forEach(b=>b.onclick=()=>{
      const [k,v]=b.dataset.fbset.split("|"); vals[k]=+v; paint();
    });
    box.querySelectorAll("[data-fbclr]").forEach(b=>b.onclick=()=>{ delete vals[b.dataset.fbclr]; paint(); });
  };
  paint();
  wireNatPicker(wrap,"fb-natsel","fb-nattxt");
  /* Look the room up as she types: a registered guest fills in their own name
     and nationality, but anything she typed herself is left alone. */
  const roomIn=wrap.querySelector("#fb-room");
  const nameIn=wrap.querySelector("#fb-name");
  const natSel=wrap.querySelector("#fb-natsel");
  const natTxt=wrap.querySelector("#fb-nattxt");
  const found=wrap.querySelector("#fb-found");
  let nameTouched=!!(ex&&ex.guest_name), natTouched=!!(ex&&ex.nationality);
  if(nameIn) nameIn.oninput=()=>{ nameTouched=true; };
  if(natSel) natSel.addEventListener("change",()=>{ natTouched=true; });
  if(natTxt) natTxt.oninput=()=>{ natTouched=true; };
  const setNat=v=>{
    if(!natSel) return;
    const known=NATIONS.includes(v);
    natSel.value = v ? (known?v:"Other") : "";
    if(natTxt){ natTxt.value = (v && !known) ? v : ""; natTxt.style.display = natSel.value==="Other" ? "" : "none"; }
  };
  const lookup=()=>{
    const g=guestForRoom(roomIn?roomIn.value:"");
    if(!found) return;
    if(!roomIn || !roomIn.value.trim()){ found.textContent=t("fbRoomHint"); return; }
    if(!g){ found.textContent=t("noGuestAccount"); return; }
    found.textContent=t("fbFoundGuest")+": "+(g.name||g.room)+(g.nationality?" \u00b7 "+g.nationality:"");
    if(!nameTouched && nameIn) nameIn.value=g.name||"";
    if(!natTouched) setNat(g.nationality||"");
  };
  if(roomIn){ roomIn.oninput=lookup; roomIn.onchange=lookup; }
  wrap.querySelectorAll("[data-fbroom]").forEach(b=>b.onclick=()=>{
    if(roomIn){ roomIn.value=b.dataset.fbroom; lookup(); }
  });
  lookup();
  wrap.querySelector("#fb-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fb-go").onclick=async ()=>{
    const room=wrap.querySelector("#fb-room").value.trim();
    if(!room){ toastErr(t("fbNeedRoom")); return; }
    const dep={}; fbDeptKeys().forEach(k=>{ if(+vals[k]>0) dep[k]=+vals[k]; });
    const scores=Object.values(dep);
    const rate = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : (ex?+ex.rate||5:5);
    const payload={
      room, guest_name:wrap.querySelector("#fb-name").value.trim(),
      nationality:readNatField(wrap,"fb-natsel","fb-nattxt"),
      rate, depts:JSON.stringify(dep),
      comment:wrap.querySelector("#fb-com").value.trim()
    };
    try{
      if(ex) await DB.updateFeedback(ex.id,payload);
      else await DB.addFeedback({...payload, by_user:(S.session&&S.session.username)||""});
      wrap.remove();
      if(S.fbOldDb){ S.fbOldDb=false; openFbSqlNote(); } else toastOk(t("saved"));
      render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
/* Shown once if her database is still missing the two new columns. */
function openFbSqlNote(){
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbSqlNote")}</h3>
    <p class="mini">${t("fbOldDb")}</p>
    <div class="fb-sql">${esc(FB_SQL)}</div>
    <button class="btn" id="fq-x">${t("close")}</button>`);
  wrap.querySelector("#fq-x").onclick=()=>wrap.remove();
}
/* One feedback, opened up: every department it scored, then edit or delete. */
function openFeedbackDetail(id){
  const f=(S.feedback||[]).find(x=>String(x.id)===String(id));
  if(!f) return;
  const d=fbDepts(f);
  const rated=fbDeptKeys().filter(k=>+d[k]>0);
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("fbDetails")}</h3>
    <p class="mini">${t("room")} ${esc(f.room)}${f.guest_name?" \u00b7 "+esc(f.guest_name):""}${f.nationality?" \u00b7 "+esc(f.nationality):""}</p>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${fbOverall(f)?fbOverall(f).toFixed(1)+" \u2605":"\u2014"}</b><span>${t("fbOverall")}</span></div>
      <div class="stat"><b>${rated.length}</b><span>${t("fbDepartments")}</span></div>
    </div>
    ${rated.length?`<div class="card" style="padding:4px 14px">${rated.map(k=>`<div class="fb-form-row">
      <span class="fb-nm">${esc(fbDeptLabel(k))}</span>${fbStars(d[k])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    ${fbComment(f)?`<p style="margin-top:10px">${esc(fbComment(f))}</p>`:""}
    <p class="mini">${mi("user")}${t("fbCollectedBy")}: ${esc(teamName(f.by_user))} \u00b7 ${fmtTime(f.created_at)}</p>
    ${fbCanEdit(f)?`<button class="btn" id="fd-edit">${ic("pen",16)} ${t("fbEdit")}</button>
    <button class="btn ghost warn" id="fd-del">${ic("trash",16)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="fd-x">${t("close")}</button>`);
  wrap.querySelector("#fd-x").onclick=()=>wrap.remove();
  const ed=wrap.querySelector("#fd-edit");
  if(ed) ed.onclick=()=>{ wrap.remove(); openFeedbackModal(f.id); };
  const del=wrap.querySelector("#fd-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),note:t("cannotUndo"),danger:true})) return;
    try{ await DB.deleteFeedback(f.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
/* One department, opened up: every rating behind the average. */
function openDeptDetail(key){
  const all=S.feedback||[];
  const list=all.filter(f=>+fbDepts(f)[key]>0)
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const st=fbDeptStats(all).find(x=>x.k===key)||{avg:0,n:0};
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${esc(fbDeptLabel(key))}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${st.avg?st.avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${st.n}</b><span>${t("fbResponses")}</span></div>
    </div>
    ${list.length?`<div class="card">${list.map(f=>`<div class="fb-line" data-fbjump="${esc(String(f.id))}">
      <span style="min-width:0"><b>${t("room")} ${esc(f.room)}</b>${f.guest_name?" \u00b7 "+esc(f.guest_name):""}
        <br><span class="mini">${fmtTime(f.created_at)}${fbComment(f)?" \u00b7 "+esc(fbComment(f)):""}</span></span>
      ${fbStars(fbDepts(f)[key])}</div>`).join("")}</div>`
      :`<p class="mini">${t("fbNoDept")}</p>`}
    <button class="btn ghost" id="dd-x">${t("close")}</button>`);
  wrap.querySelector("#dd-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-fbjump]").forEach(b=>b.onclick=()=>{
    const fid=b.dataset.fbjump; wrap.remove(); openFeedbackDetail(fid);
  });
}
/* Excel or PDF, straight from the feedback page: the sheet plus a department summary. */
/* The manager decides what guests get asked about. Keys are never reused or
   rewritten, so renaming a department keeps every rating it already has. */
function openDeptEditor(){
  let rows=fbDeptRows();
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("fbDeptsEdit")}</h3>
    <p class="mini">${t("fbDeptsHint")}</p>
    <div id="de-box"></div>
    <button class="btn ghost" id="de-add">\uFF0B ${t("fbAddDept")}</button>
    <button class="btn" id="de-go">${t("save")}</button>
    <button class="btn ghost" id="de-reset">${t("fbResetDepts")}</button>
    <button class="btn ghost" id="de-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#de-box");
  const label=r=>r.name || (t("d_"+r.key)==="d_"+r.key ? r.key : t("d_"+r.key));
  const paint=()=>{
    box.innerHTML=rows.map((r,i)=>`<div class="ar-it">
      <span class="ar-nm">${esc(label(r))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-deup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-dedown="${i}" ${i===rows.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b" data-dename="${i}" aria-label="${t("rename")}">${ic("pen",14)}</button>
        <button class="bd-b warn" data-dedel="${i}" aria-label="${t("delete")}">${ic("trash",14)}</button>
      </span></div>`).join("");
    box.querySelectorAll("[data-deup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.deup; [rows[i-1],rows[i]]=[rows[i],rows[i-1]]; paint(); });
    box.querySelectorAll("[data-dedown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dedown; [rows[i+1],rows[i]]=[rows[i],rows[i+1]]; paint(); });
    box.querySelectorAll("[data-dename]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.dename;
      openTextPrompt(t("fbDeptName"), label(rows[i]), v=>{ if(v){ rows[i]={...rows[i], name:v}; paint(); } });
    });
    box.querySelectorAll("[data-dedel]").forEach(b=>b.onclick=async ()=>{
      const i=+b.dataset.dedel;
      if(rows.length<=1){ toastErr(t("fbLastDept")); return; }
      if(!await confirmAction({question:label(rows[i]),note:t("fbDeptGone"),danger:true})) return;
      rows.splice(i,1); paint();
    });
  };
  paint();
  wrap.querySelector("#de-add").onclick=()=>openTextPrompt(t("fbDeptName"),"",v=>{
    if(!v) return;
    rows.push({key:fbNewDeptKeyFrom(rows,v), name:v}); paint();
  });
  wrap.querySelector("#de-x").onclick=()=>wrap.remove();
  const save=async list=>{
    try{
      await DB.saveSettings({...S.settings, fbDepts:list});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#de-reset").onclick=()=>save(FB_DEPT_KEYS.map(k=>({key:k,name:""})));
  wrap.querySelector("#de-go").onclick=()=>save(rows);
}
/* A key that is unique inside the list being edited, not just the saved one. */
function fbNewDeptKeyFrom(rows,name){
  const slug=String(name||"").toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,20);
  const base="x_"+(slug||"dept");
  const taken=rows.map(r=>String(r.key)).concat(FB_DEPT_KEYS);
  let k=base, i=2;
  while(taken.includes(k)) k=base+"_"+(i++);
  return k;
}
/* A one-field prompt — used for renaming and adding departments. */
function openTextPrompt(title, value, done){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${esc(title)}</h3>
    <input id="tp-v" value="${esc(value||"")}" autocapitalize="words">
    <button class="btn" id="tp-go">${t("save")}</button>
    <button class="btn ghost" id="tp-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#tp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#tp-go").onclick=()=>{
    const v=wrap.querySelector("#tp-v").value.trim();
    wrap.remove(); done(v);
  };
}
/* ===== REQUIREMENT SHEETS =====
   One sheet per event, activity or party: what is needed, how much of it, and
   which department provides it. Sent to hotel management the day before.
   Everything lives in settings so there is no new database table to create. */
const REQ_KINDS=["event","activity","party"];
const REQ_DEPTS_DEFAULT=["Entertainment","F&B","Housekeeping","Engineering","Security","Reception"];
const REQ_TEMPLATES_DEFAULT={
  event:[
    {need:"Tables", qty:"5",  dept:"F&B"},
    {need:"Chairs", qty:"30", dept:"F&B"},
    {need:"Decoration", qty:"\u2014", dept:"Housekeeping"},
    {need:"Sound system", qty:"1", dept:"Entertainment"},
    {need:"Lighting", qty:"4", dept:"Engineering"}],
  activity:[
    {need:"Mats", qty:"10", dept:"Entertainment"},
    {need:"Speaker", qty:"1", dept:"Entertainment"},
    {need:"Water", qty:"10", dept:"F&B"}],
  party:[
    {need:"DJ setup", qty:"1", dept:"Entertainment"},
    {need:"Lights", qty:"6", dept:"Engineering"},
    {need:"Bar setup", qty:"1", dept:"F&B"},
    {need:"Decoration", qty:"\u2014", dept:"Housekeeping"},
    {need:"Security", qty:"2", dept:"Security"}]
};
/* Event sheets pick from the day events, activity sheets from the daytime
   activities, party sheets from the parties and the shows. */
function reqCatsFor(kind){
  return kind==="activity" ? ["mAdult"]
       : kind==="party"    ? ["eParty","eShow"]
       : ["mEvents"];
}
function reqStartTime(a){
  return String(a && a.time || "").split(/\s*[\u2013\u2014-]\s*/)[0].trim();
}
function reqProgramList(kind){
  const cats=reqCatsFor(kind);
  return (S.activities||[]).filter(a=>a && a.name && cats.includes(normCat(a)))
    .slice().sort((x,y)=>((x.day||0)-(y.day||0)) || ((timeToMin(reqStartTime(x))||0)-(timeToMin(reqStartTime(y))||0)));
}
/* An activity repeats every week, a sheet is for one date: take the next time
   that weekday comes round, counting from the date already on the sheet. */
function nextDateForDay(dayIdx, fromISO){
  const base = fromISO ? new Date(fromISO+"T12:00:00") : new Date();
  if(isNaN(base.getTime())) return todayISO();
  const add=(((+dayIdx||0)-((base.getDay()+6)%7))+7)%7;
  const d=new Date(base.getTime()); d.setDate(d.getDate()+add);
  const p2=n=>String(n).padStart(2,"0");
  return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate());
}
function reqKindLabel(k){
  return k==="activity" ? t("reqKindActivity") : k==="party" ? t("reqKindParty") : t("reqKindEvent");
}
function reqSheetTitle(k){
  return k==="activity" ? t("reqActivity") : k==="party" ? t("reqParty") : t("reqEvent");
}
function reqDepts(){
  const c=S.settings && S.settings.reqDepts;
  return (Array.isArray(c) && c.length) ? c.slice() : REQ_DEPTS_DEFAULT.slice();
}
function reqTemplate(kind){
  const c=S.settings && S.settings.reqTemplates;
  const v=c && c[kind];
  return (Array.isArray(v) ? v : (REQ_TEMPLATES_DEFAULT[kind]||[]))
    .map(r=>({need:r.need||"", qty:r.qty||"", dept:r.dept||""}));
}
function reqSheets(){
  const c=S.settings && S.settings.reqSheets;
  return Array.isArray(c) ? c.filter(x=>x && x.id) : [];
}
function reqSheet(id){ return reqSheets().find(x=>String(x.id)===String(id)) || null; }
async function reqSave(list){
  await DB.saveSettings({...S.settings, reqSheets:list});
}
function reqSorted(){
  return reqSheets().slice().sort((a,b)=>
    String(a.date||"9999").localeCompare(String(b.date||"9999"))
    || String(a.time||"").localeCompare(String(b.time||"")));
}
function reqForDate(day){
  const all=reqSorted();
  return day ? all.filter(x=>String(x.date||"")===day) : all;
}
function reqDone(sh){ return (sh.rows||[]).filter(r=>r.done).length; }

/* ---- the page ---- */
function requirementsView(){
  const day=S.reqDate||"";
  const list=reqForDate(day);
  return `<div class="screen fadein">
    ${topBar(t("reqTab"),S.session.name)}
    <p class="mini" style="margin:-4px 0 12px">${t("reqSub")}</p>
    <div class="row2" style="margin-bottom:10px">
      <button class="btn" id="rq-new">\uFF0B ${t("reqNew")}</button>
      <button class="btn ghost" id="rq-pack">${ic("download",15)} ${t("reqExportDay")}</button>
    </div>
    <div class="row2" style="margin-bottom:14px">
      <button class="btn ghost sm" id="rq-depts">${ic("grid",14)} ${t("reqDepts")}</button>
      <button class="btn ghost sm" id="rq-tpl">${ic("pen",14)} ${t("reqTemplates")}</button>
    </div>
    <label>${t("reqPickDate")}</label>
    <input type="date" id="rq-date" value="${esc(day)}" style="margin-bottom:14px">
    ${list.length ? `<div class="card" style="padding:2px 14px">${list.map(sh=>`
      <div class="rq-it" data-rqopen="${esc(String(sh.id))}">
        <span class="rq-kind ${esc(sh.kind)}">${esc(reqKindLabel(sh.kind))}</span>
        <span class="rq-mid"><b>${esc(sh.title||reqSheetTitle(sh.kind))}</b>
          <span class="mini">${[sh.date?niceDate(sh.date):"", sh.time, sh.location].filter(Boolean).map(esc).join(" \u00b7 ")}</span>
          <span class="mini">${(sh.rows||[]).length} ${t("reqLines")} \u00b7 ${reqDone(sh)}/${(sh.rows||[]).length} ${t("reqStatus").toLowerCase()}</span></span>
        <span class="rq-go">${ic("back",16)}</span>
      </div>`).join("")}</div>`
      : `<div class="empty"><div class="big">${ic("clipboard",30)}</div>${day?t("reqNothingOn"):t("reqNone")}</div>`}
  </div>`;
}

/* ---- the sheet editor ---- */
function openReqEditor(id,prefillActId){
  const ex=id?reqSheet(id):null;
  const pre=(!ex && prefillActId)?(S.activities||[]).find(a=>String(a.id)===String(prefillActId)):null;
  const preKind=pre?(normCat(pre)==="mAdult"?"activity":(["eParty","eShow"].includes(normCat(pre))?"party":"event")):"event";
  let sh = ex ? JSON.parse(JSON.stringify(ex)) : {
    id:"rq"+Date.now(), kind:preKind, actId:pre?pre.id:"", title:pre?(pre.name||""):"",
    date:pre?nextDateForDay(pre.day,todayISO()):todayISO(), time:pre?reqStartTime(pre):"", location:pre?(pre.location||""):"",
    responsible:"", note:"", rows:reqTemplate(preKind)
  };
  sh.rows=Array.isArray(sh.rows)?sh.rows:[];
  const wrap=baseModal(`
    <h3>${ic("clipboard",20)} ${ex?t("reqEdit"):t("reqNew")}</h3>
    <label>${t("reqKind")}</label>
    <div class="pills" id="rq-kinds" style="margin-bottom:10px">
      ${REQ_KINDS.map(k=>`<button class="pill ${sh.kind===k?"on":""}" data-rqkind="${k}">${esc(reqKindLabel(k))}</button>`).join("")}
    </div>
    <label>${t("reqFromProgram")}</label>
    <select id="rq-pick"></select>
    <p class="mini" style="margin:4px 0 0">${t("reqFromProgramHint")}</p>
    <label style="margin-top:12px">${t("reqName")}</label><input id="rq-title" value="${esc(sh.title||"")}">
    <div class="row2" style="margin-top:10px">
      <div><label>${t("reqDate")}</label><input type="date" id="rq-d" value="${esc(sh.date||"")}"></div>
      <div><label>${t("time")}</label><input id="rq-t" value="${esc(sh.time||"")}" placeholder="21:00"></div>
    </div>
    <label style="margin-top:10px">${t("reqLocation")}</label><input id="rq-loc" value="${esc(sh.location||"")}">
    <label style="margin-top:14px">${t("reqNeed")}</label>
    <div id="rq-rows"></div>
    <div class="row2" style="margin-top:8px">
      <button class="btn ghost sm" id="rq-add">\uFF0B ${t("reqAddLine")}</button>
      <button class="btn ghost sm" id="rq-std">${t("reqStandard")}</button>
    </div>
    <label style="margin-top:14px">${t("reqNote")}</label><textarea id="rq-note" rows="2">${esc(sh.note||"")}</textarea>
    <label>${t("reqResponsible")}</label><input id="rq-resp" value="${esc(sh.responsible||"")}">
    <button class="btn" id="rq-go" style="margin-top:14px">${t("save")}</button>
    <button class="btn ghost" id="rq-pdf">${ic("download",16)} ${t("reqExportOne")}</button>
    ${ex?`<button class="btn ghost warn" id="rq-del">${ic("trash",16)} ${t("reqDelete")}</button>`:""}
    <button class="btn ghost" id="rq-x">${t("cancelBtn")}</button>`);

  const box=wrap.querySelector("#rq-rows");
  const paintRows=()=>{
    const depts=reqDepts();
    box.innerHTML = sh.rows.length ? sh.rows.map((r,i)=>`<div class="rq-row">
      <input class="rq-need" data-rqneed="${i}" value="${esc(r.need||"")}" placeholder="${esc(t("reqNeed"))}">
      <input class="rq-qty" data-rqqty="${i}" value="${esc(r.qty||"")}" placeholder="${esc(t("reqQty"))}">
      <select class="rq-dep" data-rqdept="${i}">
        <option value="">\u2014</option>
        ${depts.map(d=>`<option value="${esc(d)}" ${String(r.dept||"")===d?"selected":""}>${esc(d)}</option>`).join("")}
        ${r.dept && !depts.includes(r.dept) ? `<option value="${esc(r.dept)}" selected>${esc(r.dept)}</option>` : ""}
      </select>
      <span class="rq-acts">
        <button class="bd-b ${r.done?"on":""}" data-rqtick="${i}" aria-label="${t("reqStatus")}">${ic("check",13)}</button>
        <button class="bd-b" data-rqup="${i}" ${i===0?"disabled":""}>${ic("back",13)}</button>
        <button class="bd-b down" data-rqdown="${i}" ${i===sh.rows.length-1?"disabled":""}>${ic("back",13)}</button>
        <button class="bd-b warn" data-rqdel="${i}">${ic("trash",13)}</button>
      </span></div>`).join("")
      : `<p class="mini">${t("reqNoLines")}</p>`;
    box.querySelectorAll("[data-rqneed]").forEach(el=>el.oninput=()=>{ sh.rows[+el.dataset.rqneed].need=el.value; });
    box.querySelectorAll("[data-rqqty]").forEach(el=>el.oninput=()=>{ sh.rows[+el.dataset.rqqty].qty=el.value; });
    box.querySelectorAll("[data-rqdept]").forEach(el=>el.onchange=()=>{ sh.rows[+el.dataset.rqdept].dept=el.value; });
    box.querySelectorAll("[data-rqtick]").forEach(b=>b.onclick=()=>{
      const r=sh.rows[+b.dataset.rqtick]; r.done=!r.done; paintRows(); });
    box.querySelectorAll("[data-rqup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rqup; [sh.rows[i-1],sh.rows[i]]=[sh.rows[i],sh.rows[i-1]]; paintRows(); });
    box.querySelectorAll("[data-rqdown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rqdown; [sh.rows[i+1],sh.rows[i]]=[sh.rows[i],sh.rows[i+1]]; paintRows(); });
    box.querySelectorAll("[data-rqdel]").forEach(b=>b.onclick=()=>{
      sh.rows.splice(+b.dataset.rqdel,1); paintRows(); });
  };
  paintRows();

  const pick=wrap.querySelector("#rq-pick");
  const paintPick=()=>{
    if(!pick) return;
    const list=reqProgramList(sh.kind);
    pick.innerHTML=`<option value="">${esc(t("reqFromProgramOwn"))}</option>`
      + list.map(a=>{
          const bits=[(t("daysShort")[a.day]||""), reqStartTime(a), a.name, a.location].filter(Boolean);
          return `<option value="${esc(String(a.id))}" ${String(sh.actId||"")===String(a.id)?"selected":""}>${esc(bits.join(" \u00b7 "))}</option>`;
        }).join("")
      + (list.length?"":`<option value="" disabled>${esc(t("reqNoProgram"))}</option>`);
    pick.onchange=()=>{
      const a=(S.activities||[]).find(x=>String(x.id)===String(pick.value));
      sh.actId = a ? a.id : "";
      if(!a) return;
      const tt=wrap.querySelector("#rq-title"), dd=wrap.querySelector("#rq-d");
      const tm=wrap.querySelector("#rq-t"),     lc=wrap.querySelector("#rq-loc");
      if(tt) tt.value=a.name||"";
      if(tm) tm.value=reqStartTime(a);
      if(lc) lc.value=a.location||"";
      if(dd) dd.value=nextDateForDay(a.day, dd.value||todayISO());
    };
  };
  paintPick();

  wrap.querySelectorAll("[data-rqkind]").forEach(b=>b.onclick=()=>{
    sh.kind=b.dataset.rqkind;
    sh.actId="";                                  // a different kind means a different list
    wrap.querySelectorAll("[data-rqkind]").forEach(x=>x.classList.toggle("on", x.dataset.rqkind===sh.kind));
    paintPick();
  });
  wrap.querySelector("#rq-add").onclick=()=>{ sh.rows.push({need:"",qty:"",dept:""}); paintRows(); };
  wrap.querySelector("#rq-std").onclick=()=>{ sh.rows=sh.rows.concat(reqTemplate(sh.kind)); paintRows(); };

  const collect=()=>{
    sh.title=wrap.querySelector("#rq-title").value.trim();
    sh.date=wrap.querySelector("#rq-d").value;
    sh.time=wrap.querySelector("#rq-t").value.trim();
    sh.location=wrap.querySelector("#rq-loc").value.trim();
    sh.note=wrap.querySelector("#rq-note").value.trim();
    sh.responsible=wrap.querySelector("#rq-resp").value.trim();
    sh.rows=sh.rows.filter(r=>(r.need||"").trim() || (r.qty||"").trim())
      .map(r=>({need:r.need||"", qty:r.qty||"", dept:r.dept||"", done:!!r.done}));
    if(pick && !pick.value) sh.actId="";
    return sh;
  };
  wrap.querySelector("#rq-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rq-pdf").onclick=()=>{ exportRequirements([collect()]); };
  wrap.querySelector("#rq-go").onclick=async ()=>{
    const next=collect();
    const list=reqSheets().filter(x=>String(x.id)!==String(next.id));
    list.push(next);
    try{ await reqSave(list); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  const del=wrap.querySelector("#rq-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:sh.title||reqSheetTitle(sh.kind),note:t("cannotUndo"),danger:true})) return;
    try{ await reqSave(reqSheets().filter(x=>String(x.id)!==String(sh.id)));
      wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}

/* ---- the department list ---- */
function openReqDeptEditor(){
  let list=reqDepts();
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("reqDepts")}</h3>
    <p class="mini">${t("reqDeptsHint")}</p>
    <div id="rd-box"></div>
    <button class="btn ghost" id="rd-add">\uFF0B ${t("reqAddDept")}</button>
    <button class="btn" id="rd-go">${t("save")}</button>
    <button class="btn ghost" id="rd-reset">${t("reqResetLists")}</button>
    <button class="btn ghost" id="rd-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#rd-box");
  const paint=()=>{
    box.innerHTML=list.map((d,i)=>`<div class="ar-it">
      <span class="ar-nm">${esc(d)}</span>
      <span class="ar-acts">
        <button class="bd-b" data-rdup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-rddown="${i}" ${i===list.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b" data-rdname="${i}">${ic("pen",14)}</button>
        <button class="bd-b warn" data-rddel="${i}">${ic("trash",14)}</button>
      </span></div>`).join("");
    box.querySelectorAll("[data-rdup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rdup; [list[i-1],list[i]]=[list[i],list[i-1]]; paint(); });
    box.querySelectorAll("[data-rddown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rddown; [list[i+1],list[i]]=[list[i],list[i+1]]; paint(); });
    box.querySelectorAll("[data-rdname]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.rdname;
      openTextPrompt(t("reqDept"), list[i], v=>{ if(v){ list[i]=v; paint(); } });
    });
    box.querySelectorAll("[data-rddel]").forEach(b=>b.onclick=()=>{
      if(list.length<=1){ toastErr(t("reqLastDept")); return; }
      list.splice(+b.dataset.rddel,1); paint(); });
  };
  paint();
  wrap.querySelector("#rd-add").onclick=()=>openTextPrompt(t("reqDept"),"",v=>{
    if(v && !list.includes(v)){ list.push(v); paint(); } });
  wrap.querySelector("#rd-x").onclick=()=>wrap.remove();
  const save=async v=>{
    try{ await DB.saveSettings({...S.settings, reqDepts:v}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#rd-reset").onclick=()=>save(REQ_DEPTS_DEFAULT.slice());
  wrap.querySelector("#rd-go").onclick=()=>save(list);
}

/* ---- the standard lists ---- */
function openReqTemplateEditor(){
  let kind="event";
  let data={}; REQ_KINDS.forEach(k=>{ data[k]=reqTemplate(k); });
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("reqTemplates")}</h3>
    <p class="mini">${t("reqTemplatesHint")}</p>
    <div class="pills" id="rt-kinds" style="margin-bottom:10px">
      ${REQ_KINDS.map(k=>`<button class="pill ${k==="event"?"on":""}" data-rtkind="${k}">${esc(reqKindLabel(k))}</button>`).join("")}
    </div>
    <div id="rt-box"></div>
    <button class="btn ghost" id="rt-add">\uFF0B ${t("reqAddLine")}</button>
    <button class="btn" id="rt-go">${t("save")}</button>
    <button class="btn ghost" id="rt-reset">${t("reqResetLists")}</button>
    <button class="btn ghost" id="rt-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#rt-box");
  const paint=()=>{
    const depts=reqDepts(), rows=data[kind];
    box.innerHTML = rows.length ? rows.map((r,i)=>`<div class="rq-row">
      <input class="rq-need" data-rtneed="${i}" value="${esc(r.need||"")}" placeholder="${esc(t("reqNeed"))}">
      <input class="rq-qty" data-rtqty="${i}" value="${esc(r.qty||"")}" placeholder="${esc(t("reqQty"))}">
      <select class="rq-dep" data-rtdept="${i}">
        <option value="">\u2014</option>
        ${depts.map(d=>`<option value="${esc(d)}" ${String(r.dept||"")===d?"selected":""}>${esc(d)}</option>`).join("")}
        ${r.dept && !depts.includes(r.dept) ? `<option value="${esc(r.dept)}" selected>${esc(r.dept)}</option>` : ""}
      </select>
      <span class="rq-acts"><button class="bd-b warn" data-rtdel="${i}">${ic("trash",13)}</button></span>
    </div>`).join("") : `<p class="mini">${t("reqNoLines")}</p>`;
    box.querySelectorAll("[data-rtneed]").forEach(el=>el.oninput=()=>{ data[kind][+el.dataset.rtneed].need=el.value; });
    box.querySelectorAll("[data-rtqty]").forEach(el=>el.oninput=()=>{ data[kind][+el.dataset.rtqty].qty=el.value; });
    box.querySelectorAll("[data-rtdept]").forEach(el=>el.onchange=()=>{ data[kind][+el.dataset.rtdept].dept=el.value; });
    box.querySelectorAll("[data-rtdel]").forEach(b=>b.onclick=()=>{ data[kind].splice(+b.dataset.rtdel,1); paint(); });
  };
  paint();
  wrap.querySelectorAll("[data-rtkind]").forEach(b=>b.onclick=()=>{
    kind=b.dataset.rtkind;
    wrap.querySelectorAll("[data-rtkind]").forEach(x=>x.classList.toggle("on", x.dataset.rtkind===kind));
    paint();
  });
  wrap.querySelector("#rt-add").onclick=()=>{ data[kind].push({need:"",qty:"",dept:""}); paint(); };
  wrap.querySelector("#rt-x").onclick=()=>wrap.remove();
  const save=async v=>{
    try{ await DB.saveSettings({...S.settings, reqTemplates:v}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#rt-reset").onclick=()=>save(JSON.parse(JSON.stringify(REQ_TEMPLATES_DEFAULT)));
  wrap.querySelector("#rt-go").onclick=()=>{
    REQ_KINDS.forEach(k=>{ data[k]=data[k].filter(r=>(r.need||"").trim()||(r.qty||"").trim()); });
    save(data);
  };
}

/* ---- the day pack ---- */
function openReqPack(){
  const day=S.reqDate||todayISO();
  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("reqExportDay")}</h3>
    <label>${t("reqPickDate")}</label>
    <input type="date" id="rp-d" value="${esc(day)}">
    <p class="mini" id="rp-n" style="margin-top:8px"></p>
    <button class="btn" id="rp-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="rp-xls">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="rp-blank">${t("reqBlank")}</button>
    <button class="btn ghost" id="rp-x">${t("close")}</button>`);
  const dIn=wrap.querySelector("#rp-d"), note=wrap.querySelector("#rp-n");
  const pick=()=>reqForDate(dIn?dIn.value:"");
  const sync=()=>{ if(note) note.textContent=pick().length+" "+t("reqDayPack").toLowerCase(); };
  if(dIn){ dIn.onchange=sync; dIn.oninput=sync; }
  sync();
  wrap.querySelector("#rp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rp-pdf").onclick=()=>{
    const list=pick();
    if(!list.length){ toastErr(t("reqNothingOn")); return; }
    exportRequirements(list, dIn?dIn.value:""); wrap.remove();
  };
  wrap.querySelector("#rp-xls").onclick=async ()=>{
    const list=pick();
    if(!list.length){ toastErr(t("reqNothingOn")); return; }
    await exportExcelSets(list.map(reqDataset), "requirements-"+(dIn?dIn.value:todayISO()));
    toast(t("saved"));
  };
  wrap.querySelector("#rp-blank").onclick=()=>{
    exportRequirements(REQ_KINDS.map(k=>({
      id:"blank-"+k, kind:k, title:"", date:"", time:"", location:"", responsible:"", note:"",
      rows:reqTemplate(k)
    })), "", true);
    wrap.remove();
  };
}
/* A one-page management sheet per event: hotel header, the table, a note box
   and signature lines. Almost no colour, because it gets printed and signed. */
function exportRequirements(sheets, day, blank){
  const E2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const hotel=(S.settings&&(S.settings.hotelName||S.settings.name))||"";
  const line=v=>v ? E2(v) : '<span class=bl></span>';
  const css=""
   +"@page{size:A4 portrait;margin:14mm}"
   +"*{box-sizing:border-box}"
   +"body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#1F1A15;margin:0;"
     +"-webkit-print-color-adjust:exact;print-color-adjust:exact}"
   +".sheet{page-break-after:always}"
   +".sheet:last-child{page-break-after:auto}"
   +".head{border-bottom:1.5px solid #2B1F16;padding-bottom:9px;margin-bottom:14px}"
   +".hotel{font-size:9.5px;letter-spacing:.3em;text-transform:uppercase;color:#6B5C4A;font-weight:700}"
   +"h1{font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400;margin:5px 0 0}"
   +".when{font-size:9px;color:#8A7C6A;margin-top:4px}"
   +".facts{display:flex;flex-wrap:wrap;gap:0 26px;margin-bottom:14px}"
   +".f{font-size:11px;padding:5px 0;min-width:150px}"
   +".f i{display:block;font-style:normal;font-size:8px;letter-spacing:.14em;text-transform:uppercase;"
     +"color:#8A7C6A;font-weight:700;margin-bottom:2px}"
   +".bl{display:inline-block;min-width:120px;border-bottom:1px solid #B9AE9E;height:12px}"
   +"table{border-collapse:collapse;width:100%;font-size:11px;margin-bottom:12px}"
   +"th{background:#F4F1EB;text-align:left;padding:7px 9px;border:1px solid #C9BEAE;font-size:8.5px;"
     +"letter-spacing:.12em;text-transform:uppercase;color:#4A3F33}"
   +"td{padding:8px 9px;border:1px solid #D8CFC1;vertical-align:middle}"
   +"td.qty{width:56px;text-align:center;font-weight:700}"
   +"td.dep{width:130px}"
   +"td.box{width:52px;text-align:center}"
   +".ck{display:inline-block;width:12px;height:12px;border:1.2px solid #6B5C4A}"
   +".notebox{border:1px solid #D8CFC1;border-radius:3px;padding:8px 10px;min-height:56px;margin-bottom:14px}"
   +".notebox i{display:block;font-style:normal;font-size:8px;letter-spacing:.14em;text-transform:uppercase;"
     +"color:#8A7C6A;font-weight:700;margin-bottom:4px}"
   +".notebox p{margin:0;font-size:10.5px;line-height:1.5}"
   +".sign{display:flex;gap:26px;margin-top:20px}"
   +".sign div{flex:1;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7C6A;font-weight:700}"
   +".sign span{display:block;border-bottom:1px solid #B9AE9E;height:26px;margin-bottom:4px}"
   +".foot{margin-top:16px;padding-top:8px;border-top:1px solid #E0D8CB;font-size:8.5px;color:#9C9081;"
     +"display:flex;justify-content:space-between}";

  const one=sh=>{
    const rows=(sh.rows||[]);
    const pad=Math.max(0, (blank?10:rows.length+2)-rows.length);   // room to write more by hand
    return '<div class=sheet><div class=head>'
      +(hotel?'<div class=hotel>'+E2(hotel)+'</div>':'')
      +'<h1>'+E2(reqSheetTitle(sh.kind))+'</h1>'
      +'<div class=when>'+E2(t("fbPrepared"))+' '+E2(new Date().toLocaleString())
        +(S.session&&S.session.name?' \u00b7 '+E2(S.session.name):'')+'</div>'
      +'</div>'
      +'<div class=facts>'
        +'<div class=f><i>'+E2(reqKindLabel(sh.kind))+'</i>'+line(sh.title)+'</div>'
        +'<div class=f><i>'+E2(t("reqDate"))+'</i>'+line(sh.date?niceDate(sh.date):"")+'</div>'
        +'<div class=f><i>'+E2(t("time"))+'</i>'+line(sh.time)+'</div>'
        +'<div class=f><i>'+E2(t("reqLocation"))+'</i>'+line(sh.location)+'</div>'
      +'</div>'
      +'<table><thead><tr>'
        +'<th>'+E2(t("reqNeed"))+'</th><th>'+E2(t("reqQty"))+'</th>'
        +'<th>'+E2(t("reqDept"))+'</th><th>'+E2(t("reqStatus"))+'</th></tr></thead><tbody>'
      + rows.map(r=>'<tr><td>'+E2(r.need||"")+'</td><td class=qty>'+E2(r.qty||"")+'</td>'
          +'<td class=dep>'+E2(r.dept||"")+'</td><td class=box><span class=ck></span></td></tr>').join("")
      + Array.from({length:pad}).map(()=>'<tr><td>&nbsp;</td><td class=qty></td>'
          +'<td class=dep></td><td class=box><span class=ck></span></td></tr>').join("")
      +'</tbody></table>'
      +'<div class=notebox><i>'+E2(t("reqNote"))+'</i><p>'+E2(sh.note||"")+'</p></div>'
      +'<div class=sign>'
        +'<div><span></span>'+E2(t("reqResponsible"))+(sh.responsible?' \u00b7 '+E2(sh.responsible):'')+'</div>'
        +'<div><span></span>'+E2(t("reqReceived"))+'</div>'
        +'<div><span></span>'+E2(t("reqSignature"))+'</div>'
      +'</div>'
      +'<div class=foot><span>'+E2(hotel||t("reqTab"))+'</span><span>'
        +E2(sh.date?niceDate(sh.date):(day?niceDate(day):t("reqTab")))+'</span></div>'
      +'</div>';
  };

  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+E2(t("reqTab"))+"</title><meta charset=utf-8>"
    +"<style>"+css+"</style></head><body>"+sheets.map(one).join("")
    +"<scr"+"ipt>setTimeout(function(){window.print();},400);<\/scr"+"ipt></body></html>");
  w.document.close();
}
function reqDataset(sh){
  return {
    title:(sh.title||reqSheetTitle(sh.kind))+(sh.date?" \u00b7 "+niceDate(sh.date):""),
    headers:[t("reqNeed"),t("reqQty"),t("reqDept"),t("reqStatus")],
    rows:(sh.rows||[]).map(r=>[r.need||"", r.qty||"", r.dept||"", r.done?"OK":""])
  };
}
/* ===== THE GUEST FEEDBACK REPORT =====
   Its own printed document rather than a generic table: a proper letterhead,
   a summary band, colour-coded stars, and only the departments that were
   actually rated in this selection — so no walls of empty dashes. */
function exportFeedbackReport(){
  const list=exportFeedbackList();
  const E2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const hotel=(S.settings&&(S.settings.hotelName||S.settings.name))||"";
  const bits=fbFilterBits();
  const cover=bits.length?bits.join(" \u00b7 "):t("fbWholeStay");
  const sum=fbSummary(list);
  const avg=sum.overall;

  const tone=n=>{ n=+n||0; return n<3.5?"#B0392B":n<4.5?"#D08526":"#B98A5C"; };
  const stars=(v,exact,strict)=>{
    let n=Math.round(+v||0);
    // in the shortfall table a 4.5 must not print as a full five
    if(strict && n>=5 && (+v||0)<4.995) n=4;
    if(!n) return '<span class=nr>\u00b7</span>';
    return '<span class=s style="color:'+tone(v)+'">'+"\u2605".repeat(n)
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span></span>'
      +(exact?'<em>'+E2(exact)+'</em>':'');
  };
  const tile=(lb,val,sub)=>'<div class=tile><span class=tl>'+E2(lb)+'</span>'
    +'<b>'+val+'</b>'+(sub?'<span class=ts>'+E2(sub)+'</span>':'')+'</div>';

  const css=""
   +"@page{size:A4 portrait;margin:14mm}"
   +"*{box-sizing:border-box}"
   +"body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#2B1F16;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
   +".head{padding:0 0 14px;border-bottom:2px solid #B98A5C;margin-bottom:16px}"
   +".hotel{font-size:10px;letter-spacing:.32em;text-transform:uppercase;color:#B98A5C;font-weight:700}"
   +"h1{font-family:Georgia,'Times New Roman',serif;font-size:27px;font-weight:400;margin:5px 0 3px;letter-spacing:.01em}"
   +".cover{font-size:13px;color:#6B4A32;font-weight:600}"
   +".meta{font-size:10px;color:#9C8A74;margin-top:5px}"
   +".band{display:flex;gap:9px;margin-bottom:16px}"
   +".tile{flex:1;background:#FBF7F0;border:1px solid #EADFCC;border-radius:9px;padding:10px 13px}"
   +".tile .tl{display:block;font-size:8.5px;letter-spacing:.16em;text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +".tile b{display:block;font-family:Georgia,serif;font-size:20px;font-weight:400;margin-top:3px;line-height:1.15}"
   +".tile .ts{display:block;font-size:10px;color:#6B4A32;margin-top:2px}"
   +".tile.warn{background:#FBF0EC;border-color:#E8CFC5}"
   +".tile.warn .tl{color:#B0392B}"
   +".pct{font-family:Georgia,serif}"
   +"h2.sub{font-family:Georgia,'Times New Roman',serif;font-size:15px;font-weight:400;"
     +"margin:20px 0 2px;color:#5A4029;letter-spacing:.01em}"
   +".subnote{font-size:10px;color:#9C8A74;margin:0 0 8px}"
   +".legend{margin:10px 0 0;font-size:9px;color:#9C8A74}"
   +"tr.r.low td{background:#FBF0EC}tr.c.low td{background:#F9EDE8}"
   +"tr.r.low td:first-child{box-shadow:inset 3px 0 0 #B0392B}"
   +"tr.r.low td.room{color:#B0392B}"
   +"tr.r.good td{background:#F5F8F2}tr.c.good td{background:#F8FAF6}"
   +"tr.r.good td:first-child{box-shadow:inset 3px 0 0 #6E9155}"
   +"tr.r.good td.room{color:#4A6B36}"
   +"tr.r.mid td{background:#FDF6EE}tr.c.mid td{background:#FAEEDF}"
   +"tr.r.mid td:first-child{box-shadow:inset 3px 0 0 #D08526}"
   +"tr.r.mid td.room{color:#A9631A}"
   +".tile.good{background:#F5F8F2;border-color:#DCE7D4}"
   +".tile.good .tl{color:#4A6B36}.tile.good b{color:#3F5C2F}"
   +".tile.attn{background:#FDF6EE;border-color:#EDDCC6}"
   +".tile.attn .tl{color:#A9631A}.tile.attn b{color:#8A4E12}"
   +".g{border:1px solid #EADFCC;border-radius:9px;padding:10px 12px;margin-bottom:8px;"
     +"page-break-inside:avoid;border-left-width:4px}"
   +".g.priority{border-left-color:#B0392B;background:#FCF4F2}"
   +".g.attn{border-left-color:#D08526;background:#FDF9F3}"
   +".g.none{border-left-color:#6E9155;background:#F7FAF5}"
   +".ghead{display:flex;align-items:center;gap:9px}"
   +".gr{font-family:Georgia,serif;font-size:16px;font-weight:400;color:#2B1F16}"
   +".gov{font-size:11px;letter-spacing:.3px}"
   +".gov .s em{display:inline;font-style:normal;font-size:10px;color:#6B4A32;margin-left:3px}"
   +".gs{margin-left:auto;font-size:8px;letter-spacing:.13em;text-transform:uppercase;font-weight:700;"
     +"display:inline-flex;align-items:center;gap:5px}"
   +".gs i{width:7px;height:7px;border-radius:50%;display:inline-block}"
   +".gs.priority{color:#B0392B}.gs.priority i{background:#B0392B}"
   +".gs.attn{color:#A9631A}.gs.attn i{background:#D08526}"
   +".gs.none{color:#4A6B36}.gs.none i{background:#6E9155}"
   +".gmeta{font-size:8.5px;color:#9C8A74;margin-top:2px}"
   +".gchips{margin-top:6px}"
   +".cleanbox{border:1px solid #DCE7D4;border-radius:9px;background:#F7FAF5;padding:2px 12px}"
   +".g5{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:7px 0;page-break-inside:avoid}"
   +".g5+.g5{border-top:1px solid #E4EEDE}"
   +".g5 .gmeta{margin:0}"
   +".tick{color:#6E9155;font-weight:700;font-size:12px}"
   +".g5 p.note{flex:1 0 100%;margin:2px 0 0}"
   +"table.rooms{font-size:10px}"
   +"table.rooms td{padding:7px 6px}"
   +"td.by{font-size:9px;color:#6B4A32}"
   +".chip{display:inline-block;margin:0 5px 3px 0;padding:2px 7px;border-radius:999px;"
     +"font-size:8.5px;background:#F7EFE3;color:#6B4A32;border:1px solid #EADFCC;white-space:nowrap}"
   +".chip b{font-weight:700;letter-spacing:.5px}"
   +".chip.c4 b{color:#D08526}.chip.c3{background:#FBEDE9;border-color:#EBD3CB}.chip.c3 b{color:#B0392B}"
   +".chip.ok{background:#F1F6EC;border-color:#DCE7D4;color:#4A6B36}"
   +".dl{display:inline-block;margin:0 6px 3px 0;font-size:8px;letter-spacing:.12em;"
     +"text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +"p.note{margin:5px 0 0;font-size:8.5px;line-height:1.5;color:#6B4A32}"
   +".okmark{color:#7C9A6B;font-size:22px;line-height:1}"
   +"table{border-collapse:collapse;width:100%;font-size:9.5px}"
   +"thead{display:table-header-group}"
   +"th{background:#F2E7D6;color:#5A4029;text-align:left;padding:6px 5px;border:1px solid #E4D3BC;"
     +"font-size:8.5px;letter-spacing:.05em;text-transform:uppercase;line-height:1.25;vertical-align:bottom}"
   +"td{padding:6px 5px;border-left:1px solid #F0E6D6;border-right:1px solid #F0E6D6;vertical-align:middle}"
   +"tr.r{page-break-inside:avoid}"
   +"tr.r td{border-top:1px solid #E4D3BC}"
   +"tr.r.alt td{background:#FDFBF7}"
   +"td.st{text-align:center;white-space:nowrap;letter-spacing:.3px;font-size:10px}"
   +"td.st .s em{display:block;font-style:normal;font-size:8px;color:#9C8A74;letter-spacing:0;margin-top:1px}"
   +".sg{color:#E2D6C2}.nr{color:#D9CDBA}"
   +"td.room{font-weight:700;font-size:11px}"
   +"td.dt{white-space:nowrap;font-size:9px;color:#6B4A32}"
   +"tr.c{page-break-inside:avoid}"
   +"tr.c td{background:#FBF7F0;border-top:0;color:#4A3826;font-size:9px;line-height:1.5;padding:3px 8px 8px}"
   +"tr.c b{color:#B98A5C;font-weight:700;font-size:8.5px;letter-spacing:.12em;text-transform:uppercase}"
   +".foot{margin-top:18px;padding-top:9px;border-top:1px solid #EADFCC;font-size:9px;color:#9C8A74;display:flex;justify-content:space-between}"
   +".none{padding:34px;text-align:center;color:#9C8A74;font-size:13px;background:#FBF7F0;border-radius:10px}";

  let html='<div class=head>'
    +(hotel?'<div class=hotel>'+E2(hotel)+'</div>':'')
    +'<h1>'+E2(t("fbReport"))+'</h1>'
    +'<div class=cover>'+E2(cover)+'</div>'
    +'<div class=meta>'+E2(t("fbPrepared"))+" "+E2(new Date().toLocaleString())
      +(S.session&&S.session.name?" \u00b7 "+E2(S.session.name):"")+'</div>'
    +'</div>';

  html+='<div class=band>'
    + tile(t("fbCollected"), String(sum.count), sum.rated+" "+t("fbDeptsRated").toLowerCase())
    + tile(t("avgRate"), avg?stars(avg, avg.toFixed(1)):'<span class=nr>\u2014</span>')
    + '<div class="tile good"><span class=tl>'+E2(t("fbAllFiveN"))+'</span>'
      +'<b>'+sum.allFive+'</b><span class=ts>'+E2(t("fbAllFiveSub"))+'</span></div>'
    + '<div class="tile '+(sum.toReview?"attn":"")+'"><span class=tl>'+E2(t("fbToReview"))+'</span>'
      +'<b>'+sum.toReview+'</b><span class=ts>'+E2(t("fbToReviewSub"))+'</span></div>'
    +'</div>';

  /* The guests who raised something come first, worst first, each with exactly
     what they marked down. The guests who gave straight fives are listed after,
     one line each — they need no follow-up. */
  if(!list.length){
    html+='<div class=none>'+E2(t("fbNothing"))+'</div>';
  } else {
    const rank={priority:0, attn:1, none:2};
    const marked=f=>{
      const d=fbDepts(f);
      return fbDeptKeys().filter(k=>+d[k]>0 && +d[k]<5).sort((a,b)=>d[a]-d[b])
        .map(k=>'<span class="chip '+(d[k]<=3?"c3":"c4")+'">'+E2(fbDeptLabel(k))
          +' <b>'+"\u2605".repeat(+d[k])+'</b></span>').join("");
    };
    const meta=f=>[f.guest_name, f.nationality, teamName(f.by_user), shortStamp(f.created_at)]
      .filter(Boolean).map(E2).join(" \u00b7 ");
    const sorted=list.slice().sort((a,b)=>
      (rank[fbStatus(a)]-rank[fbStatus(b)]) || (fbOverall(a)-fbOverall(b)));
    const review=sorted.filter(f=>fbStatus(f)!=="none");
    const clean=sorted.filter(f=>fbStatus(f)==="none");

    html+='<h2 class=sub>'+E2(t("fbReviewHead"))+'</h2>'
      +'<p class=subnote>'+E2(review.length?t("fbReviewSub"):t("fbNoReview"))+'</p>';
    if(review.length){
      html+=review.map(f=>{
        const st=fbStatus(f), ov=fbOverall(f), note=fbComment(f), chips=marked(f);
        return '<div class="g '+st+'">'
          +'<div class=ghead>'
            +'<span class=gr>'+E2(f.room)+'</span>'
            +'<span class=gov>'+stars(ov, ov?ov.toFixed(1):"")+'</span>'
            +'<span class="gs '+st+'"><i></i>'+E2(fbStatusLabel(st))+'</span>'
          +'</div>'
          +'<div class=gmeta>'+meta(f)+'</div>'
          +(chips?'<div class=gchips>'+chips+'</div>':'')
          +(note?'<p class=note>'+E2(note)+'</p>':'')
          +'</div>';
      }).join("");
    }

    if(clean.length){
      html+='<h2 class=sub>'+E2(t("fbPerfectHead"))+'</h2>'
        +'<p class=subnote>'+E2(t("fbPerfectSub"))+'</p>'
        +'<div class=cleanbox>'
        + clean.map(f=>{
            const note=fbComment(f);
            return '<div class=g5>'
              +'<span class=gr>'+E2(f.room)+'</span>'
              +'<span class=gov>'+stars(fbOverall(f), fbOverall(f)?fbOverall(f).toFixed(1):"")+'</span>'
              +'<span class=tick>\u2713</span>'
              +'<span class=gmeta>'+meta(f)+'</span>'
              +(note?'<p class=note>'+E2(note)+'</p>':'')
              +'</div>';
          }).join("")
        +'</div>';
    }
    html+='<p class=legend>'+E2(t("fbLegend2"))+'</p>';
  }

  html+='<div class=foot><span>'+E2(hotel||t("fbReport"))+'</span>'
    +'<span>'+E2(cover)+' \u00b7 '+list.length+' '+E2(t("feedback"))+'</span></div>';

  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+E2(t("fbReport"))+"</title><meta charset=utf-8>"
    +"<style>"+css+"</style></head><body>"+html
    +"<scr"+"ipt>setTimeout(function(){window.print();},400);<\/scr"+"ipt></body></html>");
  w.document.close();
}
function openFeedbackExport(){
  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("fbExport")}</h3>
    <p class="mini">${t("fbFilterHead")}</p>
    <label>${t("whichMonth")}</label>
    <select id="fe-month">
      <option value="">${t("allMonths")}</option>
      ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===S.fbMonth?"selected":""}>${esc(lb)}</option>`).join("")}
    </select>
    <label style="margin-top:12px">${t("fbExactDate")}</label>
    <input type="date" id="fe-date" value="${esc(S.fbDate||"")}">
    <p class="mini" style="margin:4px 0 0">${t("fbExactHint")}</p>
    <label style="margin-top:12px">${t("whichTime")}</label>
    <select id="fe-slot">
      <option value="">${t("allDayLong")}</option>
      ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
    </select>
    <p class="mini" id="fe-note" style="margin-top:8px"></p>
    <button class="btn" id="fe-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="fe-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="fe-x">${t("close")}</button>`);
  const mSel=wrap.querySelector("#fe-month");
  const sSel=wrap.querySelector("#fe-slot"), xDate=wrap.querySelector("#fe-date");
  const note=wrap.querySelector("#fe-note");
  const apply=()=>{
    if(xDate) S.fbDate=xDate.value;
    if(mSel) S.fbMonth=mSel.value;
    if(sSel) S.exportSlot=sSel.value;
    // an exact date makes the month meaningless — grey it out
    if(mSel) mSel.disabled=!!S.fbDate;
    const n=exportFeedbackList().length;
    const bits=fbFilterBits();
    if(note) note.textContent = bits.length
      ? t("filterNote")+" "+bits.join(" \u00b7 ")+" \u2014 "+n+" "+t("feedback")
      : t("noFilterNote")+" "+n+" "+t("feedback");
  };
  [mSel,sSel,xDate].forEach(el=>{ if(el){ el.onchange=apply; el.oninput=apply; } });
  apply();
  wrap.querySelector("#fe-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fe-xlsx").onclick=async ()=>{
    apply();
    await exportExcelSets([buildDataset("feedback")].filter(Boolean),"guest-feedback-"+todayISO());
    toast(t("saved"));
  };
  wrap.querySelector("#fe-pdf").onclick=()=>{ apply(); exportFeedbackReport(); wrap.remove(); };
}
function openNotesModal(){
  const role=S.session?S.session.role:"guest";
  const list=visibleNotes(role);
  const wrap=baseModal(`
    <h3>${ic("bell",18)} ${t("notifications")}</h3>
    ${role==="manager"?`<button class="btn sm" id="n-new" style="margin-bottom:12px">＋ ${t("newAnnouncement")}</button>`:""}
    ${list.length?list.map(n=>`<div class="card" style="padding:12px 14px">
      <div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline">
        <b>${esc(n.title)}</b>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="mini">${fmtTime(n.created_at)}</span>
          ${role==="manager"?`<button class="btn sm warn" data-notedel="${n.id}">${ic("close",14)}</button>`:""}
        </span>
      </div>
      <p style="font-size:14.5px;margin-top:4px">${esc(n.body)}</p>
      ${role==="manager"?`<p class="mini" style="margin-top:4px">${n.audience==="all"?t("audAll"):n.audience==="guests"?t("audGuests"):t("audTeam")}</p>`:""}
    </div>`).join(""):`<div class="empty"><div class="big">${ic("bell",30)}</div>${t("noNotifs")}</div>`}
    <button class="btn ghost" id="n-x">${t("close")}</button>`);
  const maxId=list.reduce((m,n)=>Math.max(m,n.id),S.seenNote);
  if(maxId>S.seenNote){ S.seenNote=maxId; persist(); }
  wrap.querySelector("#n-x").onclick=()=>{ wrap.remove(); render(); };
  const nn=wrap.querySelector("#n-new");
  if(nn) nn.onclick=()=>{ wrap.remove(); openComposeNoteModal(); };
  wrap.querySelectorAll("[data-notedel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteNote(+b.dataset.notedel); wrap.remove(); openNotesModal();
  });
}
function openComposeNoteModal(){
  const wrap=baseModal(`
    <h3>＋ ${t("newAnnouncement")}</h3>
    <label>${t("actName")}</label><input id="nn-title">
    <label>${t("desc")}</label><textarea id="nn-body" rows="3"></textarea>
    <label>${t("audience")}</label>
    <select id="nn-aud">
      <option value="all">${t("audAll")}</option>
      <option value="guests">${t("audGuests")}</option>
      <option value="team">${t("audTeam")}</option>
    </select>
    <button class="btn" id="nn-go">${t("send")}</button>
    <button class="btn ghost" id="nn-x">${t("close")}</button>`);
  wrap.querySelector("#nn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#nn-go").onclick=async ()=>{
    const title=wrap.querySelector("#nn-title").value.trim();
    const body=wrap.querySelector("#nn-body").value.trim();
    if(!title&&!body) return;
    await DB.addNote({title:title||"★",body,audience:wrap.querySelector("#nn-aud").value});
    S.seenNote=S.notes.reduce((m,n)=>Math.max(m,n.id),S.seenNote); persist();
    wrap.remove(); toast(t("saved")); render();
  };
}
function openAttendanceModal(a){
  const date=todayISO();
  const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
  const wrap=baseModal(`
    <h3>${ic("check",18)} ${t("attendance")}</h3>
    <p class="mini">${esc(a.name)} · ${esc(a.time)}</p>
    ${bks.length?`<div class="card" style="margin-top:12px">${bks.map(b=>{
      const on=S.attendance.some(x=>x.booking_id===b.id&&x.date===date);
      return `<div class="booking-line">
        <span><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}</span>
        <button class="chip ${on?"ok":""}" data-attb="${b.id}">${t("present")}</button>
      </div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
    <button class="btn ghost" id="at-x">${t("close")}</button>`);
  wrap.querySelector("#at-x").onclick=()=>{ wrap.remove(); render(); };
  wrap.querySelectorAll("[data-attb]").forEach(b=>b.onclick=async ()=>{
    const id=+b.dataset.attb;
    const on=S.attendance.some(x=>x.booking_id===id&&x.date===date);
    await DB.setAttendance(id,date,!on);
    b.classList.toggle("ok",!on);
  });
}
function openTicketEditModal(tk){
  const isNew=!tk; tk=tk||{day:S.day,name:"",desc:"",location:"",time:"20:00",price:"",capacity:0,image:""};
  let ticketImage=String(tk.image||""),uploading=false;
  const wrap=baseModal(`
    <h3>${isNew?t("addTicket"):t("editTicket")}</h3>
    <label>${t("actName")}</label><input id="k-name" value="${esc(tk.name)}">
    <label>${t("desc")}</label><textarea id="k-desc" rows="2">${esc(tk.desc)}</textarea>
    <div class="row2"><div><label>${t("day")}</label><select id="k-day">${t("days").map((d,i)=>`<option value="${i}" ${tk.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
    <div><label>${t("time")}</label><input id="k-time" type="time" value="${esc(tk.time)}"></div></div>
    <div class="row2"><div><label>${t("price")}</label><input id="k-price" value="${esc(tk.price)}" placeholder="5 €"></div>
    <div><label>${t("capacity")} (0 = ∞)</label><input id="k-cap" type="number" min="0" value="${tk.capacity}"></div></div>
    <label>${t("location")}</label><input id="k-loc" value="${esc(tk.location)}">
    <label>${t("photo")}</label>
    <div class="photo-pick" id="k-photo-pick"><div class="photo-box" id="k-photo-box"></div><div class="pp-txt"><b>${t("photo")}</b><span class="mini">Tap to choose a photo from your phone</span></div><input type="file" id="k-photo-file" accept="image/*" hidden></div>
    <button class="btn ghost sm" id="k-photo-remove" style="${ticketImage?"":"display:none"}">Remove photo</button>
    <p class="mini" id="k-photo-status"></p>
    <button class="btn" id="k-save">${t("save")}</button>${isNew?"":`<button class="btn warn" id="k-del">${t("deleteActivity")}</button>`}<button class="btn ghost" id="k-x">${t("close")}</button>`);
  const box=wrap.querySelector("#k-photo-box"),file=wrap.querySelector("#k-photo-file"),rm=wrap.querySelector("#k-photo-remove"),status=wrap.querySelector("#k-photo-status"),save=wrap.querySelector("#k-save");
  const paint=()=>{box.innerHTML=ticketImage?`<img src="${esc(ticketImage)}" alt="">`:`<span>${ic("photo",26)}</span>`;rm.style.display=ticketImage?"":"none";};
  paint(); box.onclick=()=>file.click();
  file.onchange=async()=>{
    const f=file.files&&file.files[0]; if(!f)return;
    uploading=true;save.disabled=true;status.textContent="Uploading photo…";box.classList.add("uploading");
    try{ticketImage=await uploadAvatar(f);paint();status.textContent="Photo ready";}
    catch(e){console.error("ticket photo upload",e);status.textContent="Photo upload failed";toastErr(t("uploadErr"));}
    finally{uploading=false;save.disabled=false;box.classList.remove("uploading");file.value="";}
  };
  rm.onclick=()=>{ticketImage="";paint();status.textContent="Photo removed";};
  wrap.querySelector("#k-x").onclick=()=>wrap.remove();
  save.onclick=async()=>{
    if(uploading){toastWarn("Please wait for the photo upload.");return;}
    const upd={...tk,name:wrap.querySelector("#k-name").value.trim(),desc:wrap.querySelector("#k-desc").value.trim(),
      day:+wrap.querySelector("#k-day").value,time:wrap.querySelector("#k-time").value||"20:00",
      price:wrap.querySelector("#k-price").value.trim(),capacity:+wrap.querySelector("#k-cap").value||0,
      location:wrap.querySelector("#k-loc").value.trim(),image:ticketImage};
    if(!upd.name)return;
    save.disabled=true;
    try{await DB.saveTicket(upd);wrap.remove();toast(t("saved"));render();}
    catch(e){console.error("save ticket",e);save.disabled=false;toastErr(t("errSave"));}
  };
  const del=wrap.querySelector("#k-del");
  if(del)del.onclick=async()=>{await DB.deleteTicket(tk.id);wrap.remove();toast(t("deleted"));render();};
}

function splitTime(tm){
  const p=String(tm||"").split(/\s*[–—-]\s*/);
  return {start:(p[0]||"").trim(),end:(p[1]||"").trim()};
}
/* minutes-since-midnight from a "HH:MM" fragment, or -1 */
function hmToMin(x){ const m=String(x||"").match(/(\d{1,2})[:.\s](\d{2})/); return m?(+m[1])*60+(+m[2]):-1; }
/* start & end minutes for an activity (end defaults to start+45 if none) */
function actWindow(a){
  const {start,end}=splitTime(a.time);
  const s0=hmToMin(start); if(s0<0) return null;
  let e0=hmToMin(end); if(e0<0) e0=s0+45; if(e0<s0) e0+=1440;
  return {s0,e0};
}
/* status for TODAY only: 'todo' (green, not started), 'live' (yellow, running), 'done' (red, finished) */
function activityStatus(a, nowMin){
  const w=actWindow(a); if(!w) return "todo";
  const now=(typeof nowMin==="number")?nowMin:nowMinutes();
  if(now < w.s0) return "todo";
  if(now >= w.e0) return "done";
  return "live";
}
/* ===== HOTEL CLOCK =====
   With a timezone set, the app uses the HOTEL's local time everywhere, so a
   guest whose phone is on another timezone still sees the right day and gets
   alarms at the right moment. Without one, it falls back to the phone clock. */
const TIMEZONES=["","Africa/Cairo","Europe/Berlin","Europe/London","Europe/Moscow","Europe/Warsaw",
  "Europe/Prague","Europe/Amsterdam","Europe/Paris","Europe/Madrid","Europe/Rome","Europe/Istanbul",
  "Asia/Dubai","Asia/Riyadh","Atlantic/Canary","America/New_York"];
function hotelTz(){ try{ return (typeof S!=="undefined" && S.settings && S.settings.timezone) || ""; }catch(e){ return ""; } }
function hotelNow(){
  const tz=hotelTz();
  if(!tz) return new Date();
  try{ const d=new Date(new Date().toLocaleString("en-US",{timeZone:tz})); return isNaN(d.getTime())?new Date():d; }
  catch(e){ return new Date(); }
}
function nowMinutes(){ const d=hotelNow(); return d.getHours()*60+d.getMinutes(); }
function todayIndex(){ return (hotelNow().getDay()+6)%7; }
function hotelDateStr(){
  const d=hotelNow();
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}
/* only show status dots when looking at the actual current weekday */
function isToday(day){ return day===(todayIndex()); }
function statusDot(a){
  if(!isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-dot ${st}" title="${t("st_"+st)}"></span>`;
}
/* class that draws the coloured ring around a card / photo */
function statusRing(a){
  if(!a || !isToday(a.day)) return "";
  return "ring-"+activityStatus(a);
}
/* small coloured label used inside the ring */
function statusPill(a){
  if(!a || !isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-pill ${st}">${t("st_"+st)}</span>`;
}
function statusLegend(){
  if(!isToday(S.day)) return "";
  return `<div class="stat-legend">
    <span><i class="stat-dot todo"></i>${t("st_todo")}</span>
    <span><i class="stat-dot live"></i>${t("st_live")}</span>
    <span><i class="stat-dot done"></i>${t("st_done")}</span>
  </div>`;
}
function joinTime(a,b){ a=(a||"").trim(); b=(b||"").trim(); return b?`${a} – ${b}`:a; }
function openEditModal(a){
  const isNew=!a; a=a||{day:S.day,category:(S.cat&&allCats().includes(S.cat)?S.cat:"mAdult"),name:"",desc:"",location:"",time:"10:00",capacity:20,entertainer:"",image:"",highlight:false};
  const cur=normCat(a);
  const tm=splitTime(a.time);
  const catOptions=OPS.map(o=>`<optgroup label="${esc(opLabel(o.id))}">${o.cats.map(c=>`<option value="${c}" ${cur===c?"selected":""}>${catLabel(c)}</option>`).join("")}</optgroup>`).join("");
  const staff=S.users.filter(u=>u.role==="staff");
  const entOptions=`<option value="">${t("allTeam")}</option>`
    + staff.map(u=>`<option value="${esc(u.username)}" ${String(a.entertainer||"").toLowerCase()===u.username.toLowerCase()?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("");
  const knownEnt=!a.entertainer || staff.some(u=>u.username.toLowerCase()===String(a.entertainer).toLowerCase());
  const wrap=baseModal(`
    <h3>${isNew?t("addActivity"):t("editActivity")}</h3>
    <label>${t("actName")}</label><input id="e-name" value="${esc(a.name)}">
    <label>${t("desc")}</label><textarea id="e-desc" rows="2">${esc(a.desc)}</textarea>
    <div class="row2">
      <div><label>${t("day")}</label><select id="e-day">${t("days").map((d,i)=>`<option value="${i}" ${a.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
      <div><label>${t("category")}</label><select id="e-cat">${catOptions}</select></div>
    </div>
    <div class="row2">
      <div><label>${t("startTime")}</label><input id="e-start" type="time" value="${esc(tm.start)}"></div>
      <div><label>${t("endTime")}</label><input id="e-end" type="time" value="${esc(tm.end)}"></div>
    </div>
    <label>${t("capacity")} (0 = ∞)</label><input id="e-cap" type="number" min="0" value="${a.capacity}">
    <label>${t("location")}</label><input id="e-loc" value="${esc(a.location)}">
    <label>${t("entertainer")}</label>
    <select id="e-ent">${entOptions}${knownEnt?"":`<option value="${esc(a.entertainer)}" selected>${esc(a.entertainer)}</option>`}</select>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="e-img" type="hidden" value="${esc(a.image)}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink)">
      <input id="e-hl" type="checkbox" style="width:auto" ${a.highlight?"checked":""}> ${ic("sparkle",14)} ${t("makeHighlight")}</label>
    <button class="btn" id="e-save">${t("save")}</button>
    ${isNew?"":`<button class="btn warn" id="e-del">${t("deleteActivity")}</button>`}
    <button class="btn ghost" id="e-x">${t("close")}</button>`);
  wrap.querySelector("#e-x").onclick=()=>wrap.remove();
  let ePhoto=a.image||"";
  wirePhotoPicker(wrap, ()=>ePhoto, v=>{ ePhoto=v; wrap.querySelector("#e-img").value=v; });
  wrap.querySelector("#e-save").onclick=async ()=>{
    const upd={...a,
      name:wrap.querySelector("#e-name").value.trim(),
      desc:wrap.querySelector("#e-desc").value.trim(),
      day:+wrap.querySelector("#e-day").value,
      category:wrap.querySelector("#e-cat").value,
      time:joinTime(wrap.querySelector("#e-start").value||"10:00",wrap.querySelector("#e-end").value),
      capacity:+wrap.querySelector("#e-cap").value||0,
      location:wrap.querySelector("#e-loc").value.trim(),
      entertainer:wrap.querySelector("#e-ent").value.trim(),
      image:ePhoto,
      highlight:wrap.querySelector("#e-hl").checked};
    if(!upd.name) return;
    await DB.saveActivity(upd); wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#e-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delActivityQ"),danger:true})) return;
    try{ await DB.deleteActivity(a.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function openUserModal(){
  const wrap=baseModal(`
    <h3>${t("addUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="u-name" autocapitalize="none">
    <label>${t("pass")}</label><input id="u-pass">
    <label>${t("displayName")}</label><input id="u-disp">
    <label>${t("roleLabel")}</label>
    <select id="u-role"><option value="staff">${t("staff")}</option><option value="manager">${t("manager")}</option></select>
    <label>${t("shirtNumber")} (2–10)</label><input id="u-num" type="number" min="2" max="10" placeholder="e.g. 4">
    <label>${t("nationality")}</label>${nationField("u-nat","u-natx","")}
    <label>${t("genderLbl")}</label><select id="u-gen">${genderOptions("")}</select>
    <div class="pay630-editbox">
      <div class="pay630-edithead"><b>Salary</b><span>Monthly payroll</span></div>
      <div class="row2">
        <div><label>Monthly salary</label><input id="u-salary" type="number" min="0" step="0.01" inputmode="decimal" placeholder="10000"></div>
        <div><label>Currency</label><select id="u-currency"><option value="EGP">EGP</option><option value="USD">USD</option></select></div>
      </div>
      <label class="pay630-toggle"><input id="u-vacpaid" type="checkbox" checked> Paid vacation</label>
      <p class="mini">Present and Day Off are paid. Absence is deducted automatically.</p>
    </div>
    <button class="btn" id="u-save">${t("save")}</button>
    <div class="err" id="u-err"></div>
    <button class="btn ghost" id="u-x">${t("close")}</button>`);
  wrap.querySelector("#u-x").onclick=()=>wrap.remove();
  let uPhoto="";
  wirePhotoPicker(wrap, ()=>uPhoto, v=>{ uPhoto=v; });
  wireNatPicker(wrap,"u-nat","u-natx");
  wrap.querySelector("#u-save").onclick=async ()=>{
    const username=wrap.querySelector("#u-name").value.trim();
    const password=wrap.querySelector("#u-pass").value;
    const display_name=wrap.querySelector("#u-disp").value.trim();
    const role=wrap.querySelector("#u-role").value;
    const numRaw=wrap.querySelector("#u-num").value;
    const number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    const err=wrap.querySelector("#u-err");
    if(!username||!password){ err.textContent=t("loginErr"); return; }
    if(S.users.some(x=>x.username===username)){ err.textContent=t("userExists"); return; }
    await DB.addUser({username,password,role,display_name,number,photo:uPhoto,
      nationality:readNatField(wrap,"u-nat","u-natx"),
      gender:wrap.querySelector("#u-gen").value});
    const created=(S.users||[]).find(x=>String(x.username).toLowerCase()===String(username).toLowerCase());
    if(created){
      const amount=Math.max(0,+wrap.querySelector("#u-salary").value||0);
      const currency=wrap.querySelector("#u-currency").value==="USD"?"USD":"EGP";
      await savePayrollConfig630(created,{amount,currency,vacationPaid:!!wrap.querySelector("#u-vacpaid").checked});
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openMsgEditModal(m){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editMsg")}</h3>
    <label>${t("desc")}</label><textarea id="me-txt" rows="3">${esc(m.text)}</textarea>
    <button class="btn" id="me-go">${t("save")}</button>
    <button class="btn warn" id="me-del">${t("deleteMsg")}</button>
    <button class="btn ghost" id="me-x">${t("close")}</button>`);
  wrap.querySelector("#me-x").onclick=()=>wrap.remove();
  wrap.querySelector("#me-go").onclick=async ()=>{
    const v=wrap.querySelector("#me-txt").value.trim();
    if(!v) return;
    await DB.updateMessage(m.id,v); wrap.remove(); toast(t("saved")); render();
  };
  wrap.querySelector("#me-del").onclick=async ()=>{
    await DB.deleteMessage(m.id); wrap.remove(); toast(t("deleted")); render();
  };
}
function openChangePassModal(){
  const wrap=baseModal(`
    <h3>${ic("key",22)} ${t("changePass")}</h3>
    <label>${t("newPass")}</label><input id="cp-new" type="text" autocapitalize="none">
    <button class="btn" id="cp-go">${t("save")}</button>
    <div class="err" id="cp-err"></div>
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=async ()=>{
    const v=wrap.querySelector("#cp-new").value.trim();
    if(v.length<4){ wrap.querySelector("#cp-err").textContent=t("loginErr"); return; }
    await DB.updateAccount(S.session.accountId,{password:v});
    wrap.remove(); toast(t("saved"));
  };
}
function openUserEditModal(u){
  const managerCount=S.users.filter(x=>x.role==="manager").length;
  const lastManager=u.role==="manager"&&managerCount<=1;
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="ue-user" value="${esc(u.username)}" autocapitalize="none">
    <label>${t("displayName")}</label><input id="ue-disp" value="${esc(u.display_name||"")}">
    <label>${t("pass")}</label><input id="ue-pass" value="${esc(u.password||"")}">
    <label>${t("roleLabel")}</label>
    <select id="ue-role" ${lastManager?"disabled":""}>
      <option value="staff" ${u.role==="staff"?"selected":""}>${t("staff")}</option>
      <option value="manager" ${u.role==="manager"?"selected":""}>${t("manager")}</option>
    </select>
    <label>${t("shirtNumber")} (2–10)</label><input id="ue-num" type="number" min="2" max="10" value="${u.number||""}">
    <div class="row2">
      <div><label>${t("employeeId")}</label><input id="ue-eid" value="${esc(u.employee_id||"")}"></div>
      <div><label>${t("positionLbl2")}</label><input id="ue-pos" value="${esc(u.position||"")}"></div>
    </div>
    <div class="row2">
      <div><label>${t("phoneLbl2")}</label><input id="ue-phone" value="${esc(u.phone||"")}" inputmode="tel"></div>
      <div><label>${t("whatsappLbl2")}</label><input id="ue-wa" value="${esc(u.whatsapp||"")}" inputmode="tel"></div>
    </div>
    <label>${t("instagramLbl2")}</label><input id="ue-ig" value="${esc(u.instagram||"")}">
    <label>${t("languagesLbl")}</label><input id="ue-lang" value="${esc(u.languages||"")}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="ue-skills" value="${esc(u.skills||"")}">
    <label>${t("hireDate")}</label><input id="ue-hire" type="date" value="${esc(u.hire_date||"")}">
    ${photoListEditor("uep", (()=>{try{return Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]");}catch(e){return [];}})())}
    <label>${t("nationality")}</label>${nationField("ue-nat","ue-natx",u.nationality||"")}
    <label>${t("genderLbl")}</label><select id="ue-gen">${genderOptions(u.gender||"")}</select>
    ${payrollEditorHtml630(u)}
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ue-active" type="checkbox" style="width:auto" ${u.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ue-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ue-go">${t("save")}</button>
    <button class="btn ghost" id="ue-x">${t("close")}</button>`);
  wrap.querySelector("#ue-x").onclick=()=>wrap.remove();
  let uePhoto=u.photo||"";
  wirePhotoPicker(wrap, ()=>uePhoto, v=>{ uePhoto=v; });
  wireNatPicker(wrap,"ue-nat","ue-natx");
  let uePics=(()=>{try{return Array.isArray(u.photos)?u.photos.slice():JSON.parse(u.photos||"[]");}catch(e){return [];}})();
  wirePhotoList(wrap,"uep",()=>uePics,l=>{ uePics=l; });
  const ueReset=wrap.querySelector("#ue-reset");
  if(ueReset) ueReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateUser(u.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ue-go").onclick=async ()=>{
    const newUser=wrap.querySelector("#ue-user").value.trim();
    const patch={display_name:wrap.querySelector("#ue-disp").value.trim(),
      password:wrap.querySelector("#ue-pass").value, photo:uePhoto,
      nationality:readNatField(wrap,"ue-nat","ue-natx"),
      gender:wrap.querySelector("#ue-gen").value,
      active:wrap.querySelector("#ue-active").checked,
      employee_id:wrap.querySelector("#ue-eid").value.trim(),
      position:wrap.querySelector("#ue-pos").value.trim(),
      phone:wrap.querySelector("#ue-phone").value.trim(),
      whatsapp:wrap.querySelector("#ue-wa").value.trim(),
      instagram:wrap.querySelector("#ue-ig").value.trim(),
      languages:wrap.querySelector("#ue-lang").value.trim(),
      skills:wrap.querySelector("#ue-skills").value.trim(),
      hire_date:wrap.querySelector("#ue-hire").value,
      photos:uePics};
    const numRaw=wrap.querySelector("#ue-num").value;
    patch.number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    if(!lastManager) patch.role=wrap.querySelector("#ue-role").value;
    if(newUser && newUser!==u.username){
      if(S.users.some(x=>x.id!==u.id && String(x.username).toLowerCase()===newUser.toLowerCase())){ toast(t("userExists")); return; }
      patch.username=newUser;
    }
    if(!patch.password){ return; }
    await DB.updateUser(u.id,patch);
    await savePayrollConfig630(u,{
      amount:Math.max(0,+wrap.querySelector("#ue-salary").value||0),
      currency:wrap.querySelector("#ue-currency").value==="USD"?"USD":"EGP",
      vacationPaid:!!wrap.querySelector("#ue-vacpaid").checked
    });
    wrap.remove(); toast(t("saved")); render();
  };
}
function openGuestEditModal(acc){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("profile")} · ${t("room")} ${esc(acc.room)}</h3>
    <label>${t("name")}</label><input id="ge-name" value="${esc(acc.name||"")}">
    <label>${t("phone")}</label><input id="ge-phone" value="${esc(acc.phone||"")}">
    <label>${t("nationality")}</label>
    <input id="ge-nat" list="genatlist" value="${esc(acc.nationality||"")}">
    <datalist id="genatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <div class="row2">
      <div><label>${t("arrival")}</label><input id="ge-arr" type="date" value="${esc(acc.arrival||"")}"></div>
      <div><label>${t("departure")}</label><input id="ge-dep" type="date" value="${esc(acc.departure||"")}"></div>
    </div>
    <label>${t("pass")}</label><input id="ge-pass" value="${esc(acc.password||"")}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ge-active" type="checkbox" style="width:auto" ${acc.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ge-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ge-go">${t("save")}</button>
    <button class="btn ghost" id="ge-x">${t("close")}</button>`);
  wrap.querySelector("#ge-x").onclick=()=>wrap.remove();
  const geReset=wrap.querySelector("#ge-reset");
  if(geReset) geReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateAccount(acc.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ge-go").onclick=async ()=>{
    const name=wrap.querySelector("#ge-name").value.trim();
    if(!name) return;
    await DB.updateAccount(acc.id,{name,
      phone:wrap.querySelector("#ge-phone").value.trim(),
      nationality:wrap.querySelector("#ge-nat").value.trim(),
      arrival:wrap.querySelector("#ge-arr").value,
      departure:wrap.querySelector("#ge-dep").value,
      password:wrap.querySelector("#ge-pass").value.trim(),
      active:wrap.querySelector("#ge-active").checked});
    if(S.session && S.session.role==="guest" && S.session.accountId===acc.id){
      const a2=S.accounts.find(x=>x.id===acc.id); if(a2) startGuestSession(a2);
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openLangModal(){
  const wrap=baseModal(`
    <h3>${t("language")}</h3>
    <div class="langlist">
      ${LANGS.map(([l,label])=>`<button data-mlang="${l}" class="${S.lang===l?"on":""}">${label}</button>`).join("")}
    </div>
    <button class="btn ghost" id="l-x">${t("close")}</button>`);
  wrap.querySelector("#l-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-mlang]").forEach(b=>b.onclick=()=>{ wrap.remove(); setLang(b.dataset.mlang); });
}
/* ---------------- wiring ---------------- */
function wireCommon(){
  document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{S.tab=b.dataset.tab;S.chatRoom=null;S.op=null;S.cat=null;S.planDay=undefined;render();});
  document.querySelectorAll("[data-op]").forEach(b=>b.onclick=()=>{S.op=b.dataset.op;S.cat=null;render();});
  document.querySelectorAll("[data-planday]").forEach(b=>b.onclick=()=>{S.planDay=+b.dataset.planday;render();});
  document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{S.cat=b.dataset.cat;render();});
  const c1=$("#crumb-ops"); if(c1) c1.onclick=()=>{S.op=null;S.cat=null;render();};
  const c2=$("#crumb-cats"); if(c2) c2.onclick=()=>{S.cat=null;render();};
  document.querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>{S.day=+b.dataset.day;render();});
  document.querySelectorAll("[data-sub]").forEach(b=>b.onclick=()=>{
    const [g,v]=b.dataset.sub.split(":"); S.sub[g]=v; S.chatRoom=null; render();
  });
  const mn=$("#btn-menu"); if(mn) mn.onclick=openMenuDrawer;
  const nb=$("#btn-notes"); if(nb) nb.onclick=openNotesModal;
  document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const id=+b.dataset.fav;
    S.favorites=S.favorites.includes(id)?S.favorites.filter(x=>x!==id):[...S.favorites,id]; persist(); render();
  });
  document.querySelectorAll("[data-book]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.book); if(a) openBookModal(a);
  });
  document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.buy); if(tk) openTicketBuyModal(tk);
  });
  document.querySelectorAll("[data-cancel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await DB.removeBooking(+b.dataset.cancel); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-cancelorder]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await DB.deleteOrder(+b.dataset.cancelorder); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-delreq]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRequest(+b.dataset.delreq); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.edit); openEditModal(a);
  });
  document.querySelectorAll("[data-att]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.att); if(a) openAttendanceModal(a);
  });
  document.querySelectorAll("[data-tedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.tedit); openTicketEditModal(tk);
  });
  document.querySelectorAll("[data-tpaid]").forEach(b=>b.onclick=async ()=>{
    const o=S.orders.find(x=>x.id===+b.dataset.tpaid); if(!o) return;
    await DB.setOrderStatus(o.id, o.status==="paid"?"reserved":"paid"); render();
  });
  document.querySelectorAll("[data-tdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deleteOrder(+b.dataset.tdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-deluser]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delUserQ"),danger:true})) return;
    try{ await DB.deleteUser(+b.dataset.deluser); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-reqdone]").forEach(b=>b.onclick=async ()=>{
    const r=S.requests.find(x=>x.id===+b.dataset.reqdone); if(!r) return;
    await DB.setRequestStatus(r.id, r.status==="done"?"new":"done"); render();
  });
  document.querySelectorAll("[data-reqdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delReqQ"),danger:true})) return;
    try{ await DB.deleteRequest(+b.dataset.reqdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskdone]").forEach(b=>b.onclick=async ()=>{
    const x=S.tasks.find(y=>y.id===+b.dataset.taskdone); if(!x) return;
    await DB.updateTask(x.id,{status:x.status==="done"?"open":"done"}); render();
  });
  document.querySelectorAll("[data-taccept]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.taccept,{status:"accepted"}); render();
  });
  document.querySelectorAll("[data-tsdone]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tsdone,{status:"done"}); toast(t("saved")); render();
  });
  document.querySelectorAll("[data-tstill]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tstill,{status:"still",was_still:true}); render();
  });
  document.querySelectorAll("[data-tcant]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tcant,{status:"cant"}); render();
  });
  document.querySelectorAll("[data-fbopen]").forEach(b=>b.onclick=()=>openFeedbackDetail(b.dataset.fbopen));
  document.querySelectorAll("[data-fbdept]").forEach(b=>b.onclick=()=>openDeptDetail(b.dataset.fbdept));
  const fbx=$("#btn-fbexport"); if(fbx) fbx.onclick=openFeedbackExport;
  const fbd=$("#btn-fbdepts"); if(fbd) fbd.onclick=openDeptEditor;
  const rail=$("#hero-rail"), dots=$("#hero-dots");
  if(rail && dots){
    const marks=dots.querySelectorAll("i");
    const sync=()=>{
      const w=rail.scrollWidth/Math.max(1,marks.length);
      const i=Math.min(marks.length-1, Math.round(rail.scrollLeft/Math.max(1,w)));
      marks.forEach((m,j)=>m.classList.toggle("on", j===i));
    };
    rail.onscroll=sync;
    marks.forEach((m,j)=>m.onclick=()=>{
      rail.scrollTo({left:(rail.scrollWidth/marks.length)*j, behavior:"smooth"});
    });
  }
  /* One tap on an activity does whatever that person can actually do with it:
     the manager edits it, an entertainer opens the guest list, a guest books. */
  const openAct=id=>{
    const a=S.activities.find(x=>String(x.id)===String(id));
    if(!a || !S.session) return;
    if(S.session.role==="manager") return openEditModal(a);
    if(S.session.role==="staff") return canSeeGuests(a) ? openAttendanceModal(a) : openEditModal(a);
    if(!myBooking(a.id)) openBookModal(a);
  };
  document.querySelectorAll("[data-actopen]").forEach(el=>el.onclick=()=>openAct(el.dataset.actopen));
  document.querySelectorAll("[data-startact]").forEach(b=>b.onclick=ev=>{
    if(ev && ev.stopPropagation) ev.stopPropagation();
    openAct(b.dataset.startact);
  });
  const tnMake=$("#tn-make");
  if(tnMake) tnMake.onclick=()=>{ S.tab="req"; render(); setTimeout(()=>openReqEditor(),0); };
  const rqN=$("#rq-new");    if(rqN) rqN.onclick=()=>openReqEditor();
  const rqP=$("#rq-pack");   if(rqP) rqP.onclick=openReqPack;
  const rqD=$("#rq-depts");  if(rqD) rqD.onclick=openReqDeptEditor;
  const rqT=$("#rq-tpl");    if(rqT) rqT.onclick=openReqTemplateEditor;
  const rqDate=$("#rq-date");
  if(rqDate) rqDate.onchange=()=>{ S.reqDate=rqDate.value; render(); };
  document.querySelectorAll("[data-rqopen]").forEach(b=>b.onclick=()=>openReqEditor(b.dataset.rqopen));
  const fbs=$("#btn-fbseeall"); if(fbs) fbs.onclick=()=>{ S.tab="feedback"; render(); };
  const fb=$("#btn-addfb"); if(fb) fb.onclick=()=>openFeedbackModal();
  const cp=$("#btn-chpass"); if(cp) cp.onclick=openChangePassModal;
  const ap=$("#btn-addprofile"); if(ap) ap.onclick=()=>openProfileModal(null);
  document.querySelectorAll("[data-pedit]").forEach(b=>b.onclick=()=>{
    const pr=S.profiles.find(x=>x.id===+b.dataset.pedit); if(pr) openProfileModal(pr);
  });
  document.querySelectorAll("[data-pdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteProfile(+b.dataset.pdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-uedit]").forEach(b=>b.onclick=()=>{
    const u=S.users.find(x=>x.id===+b.dataset.uedit); if(u) openUserEditModal(u);
  });
  document.querySelectorAll("[data-gedit]").forEach(b=>b.onclick=()=>{
    const a=S.accounts.find(x=>x.id===+b.dataset.gedit); if(a) openGuestEditModal(a);
  });
  const ex=$("#btn-export"); if(ex) ex.onclick=exportReport;
  const exd=$("#btn-exportdata"); if(exd) exd.onclick=openExportModal;
  document.querySelectorAll("[data-busedit]").forEach(el=>el.onclick=()=>{
    const b=S.buses.find(x=>x.id==el.dataset.busedit); if(b) openBusModal(b);
  });
  document.querySelectorAll("[data-busadd]").forEach(el=>el.onclick=()=>openBusModal(null, el.dataset.busadd));
  document.querySelectorAll("[data-hub]").forEach(el=>el.onclick=()=>{
    const h=el.dataset.hub;
    if(h==="export"){ openExportModal(); return; }
    S.tab=h; render();
  });
  const crumbHub=$("#crumb-hub"); if(crumbHub) crumbHub.onclick=()=>{ S.tab="settings"; render(); };
  const crumbPb=$("#crumb-pb"); if(crumbPb) crumbPb.onclick=()=>{ S.tab="builder"; render(); };
  document.querySelectorAll("[data-pbedit]").forEach(b=>b.onclick=()=>pbOpen(S.session.role, b.dataset.pbedit));
  document.querySelectorAll("[data-pbadd]").forEach(b=>b.onclick=()=>pbAdd(b.dataset.pbadd));
  document.querySelectorAll("[data-pbup]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbup,-1));
  document.querySelectorAll("[data-pbdown]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbdown,1));
  document.querySelectorAll("[data-pbdup]").forEach(b=>b.onclick=()=>pbDup(b.dataset.pbdup));
  document.querySelectorAll("[data-pbdel]").forEach(b=>b.onclick=()=>pbDel(b.dataset.pbdel));
  // live editing of block fields
  document.querySelectorAll("[data-pbf]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbf).split("|");
    const apply=()=>{
      const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.value; render();
    };
    if(el.tagName==="SELECT"||el.type==="color") el.onchange=apply; else el.onblur=apply;
  });
  document.querySelectorAll("[data-pbc]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbc).split("|");
    el.onchange=()=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.checked; render(); };
  });
  const pbT=$("#pb-title"); if(pbT) pbT.onblur=()=>{ const st=pbState(); if(st.page) st.page.title=pbT.value; };
  const pbR=$("#pb-role"); if(pbR) pbR.onchange=()=>{ pbState().role=pbR.value; };
  const pbS=$("#pb-save"); if(pbS) pbS.onclick=()=>{ const t2=$("#pb-title"); if(t2&&pbState().page) pbState().page.title=t2.value; pbSave(); };
  // block images
  document.querySelectorAll("[data-pbimgadd]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgadd).split("|");
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk[key]=url; render(); } });
  });
  document.querySelectorAll("[data-pbimgrm]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk[key]=""; render(); }
  });
  document.querySelectorAll("[data-pbgadd]").forEach(b=>b.onclick=()=>{
    const bid=b.dataset.pbgadd;
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk.urls=(blk.urls||[]).concat([url]); render(); } }, true);
  });
  document.querySelectorAll("[data-pbgrm]").forEach(b=>b.onclick=()=>{
    const [bid,ix]=String(b.dataset.pbgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk.urls=(blk.urls||[]).filter((_,i)=>i!==+ix); render(); }
  });
  document.querySelectorAll("[data-translate]").forEach(b=>b.onclick=()=>translateMessage(b.dataset.translate));
  const navB=$("#btn-navback"); if(navB) navB.onclick=navBack;
  const navF=$("#btn-navfwd");  if(navF) navF.onclick=navForward;
  const qzSend=$("#qz-send"); if(qzSend) qzSend.onclick=submitQuizAnswer;
  document.querySelectorAll("[data-dutyedit]").forEach(b=>b.onclick=()=>openDutyModal(+b.dataset.dutyedit));
  const qrP=$("#qr-print"); if(qrP) qrP.onclick=openQrPrint;
  document.querySelectorAll("[data-gotab]").forEach(b=>b.onclick=()=>{ S.tab=b.dataset.gotab; render(); });
  const crmQ=$("#crm-q"); if(crmQ && !crmQ.dataset.searchFixedV6242){
    crmQ.dataset.searchFixedV6242="1";
    const filterCrm=()=>{
      S.crmQuery=crmQ.value;
      const q=crmQ.value.trim().toLowerCase();
      const rows=[...document.querySelectorAll("[data-crm-search]")];
      let shown=0;
      rows.forEach(row=>{
        const ok=!q||String(row.dataset.crmSearch||"").includes(q);
        row.style.display=ok?"":"none";
        if(ok)shown++;
      });
      const empty=document.querySelector("#crm-search-empty");
      if(empty)empty.style.display=(rows.length&&shown===0)?"":"none";
    };
    crmQ.oninput=filterCrm;
    crmQ.onkeydown=e=>{ if(e.key==="Enter"){ e.preventDefault(); filterCrm(); crmQ.blur(); } };
    crmQ.onsearch=()=>{ filterCrm(); crmQ.blur(); };
    filterCrm();
  }
  document.querySelectorAll("[data-crm]").forEach(b=>b.onclick=()=>{ S.tab="g360:"+b.dataset.crm; render(); });
  const crumbCrm=$("#crumb-crm"); if(crumbCrm) crumbCrm.onclick=()=>{ S.tab="guests"; S.sub.guests="crm"; render(); };
  document.querySelectorAll("[data-uview]").forEach(b=>b.onclick=()=>{ S.tab="emp:"+b.dataset.uview; render(); });
  const profReq=$("#prof-req"); if(profReq) profReq.onclick=openProfileChangeModal;
  // any picture with data-pv opens the big viewer
  /* photo taps are handled globally by initPhotoTaps() */
  const crumbTeam=$("#crumb-team"); if(crumbTeam) crumbTeam.onclick=()=>{
    if(S.session.role==="manager"){ S.tab="team"; S.sub.team="accounts"; }
    else S.tab="teaminfo";
    render();
  };
  document.querySelectorAll("[data-ususpend]").forEach(b=>b.onclick=async ()=>{
    const u=S.users.find(x=>x.id==b.dataset.ususpend); if(!u) return;
    try{ await DB.updateUser(u.id,{active:u.active===false}); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskopen]").forEach(b=>b.onclick=()=>openTaskModal(b.dataset.taskopen));
  const wRe=$("#w-reload"); if(wRe) wRe.onclick=()=>loadWeather(true);
  document.querySelectorAll("[data-asub]").forEach(b=>b.onclick=()=>{ S.sub.assign=b.dataset.asub; render(); });
  document.querySelectorAll("[data-aday]").forEach(b=>b.onclick=()=>{ S.assignDay=+b.dataset.aday; render(); });
  const aAuto=$("#asg-auto"); if(aAuto) aAuto.onclick=()=>openAutoAssignModal(assignDay());
  document.querySelectorAll("[data-arrange]").forEach(b=>b.onclick=()=>openArrangeModal(b.dataset.arrange));
  const ctSel=$("#ct-select"); if(ctSel) ctSel.onclick=()=>{ S.chatSel=[]; render(); };
  const ctCancel=$("#ct-cancel"); if(ctCancel) ctCancel.onclick=()=>{ S.chatSel=null; render(); };
  const ctAll=$("#ct-all"); if(ctAll) ctAll.onclick=()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    S.chatSel = (S.chatSel||[]).length===ids.length ? [] : ids;
    render();
  };
  document.querySelectorAll("[data-msgpick]").forEach(el=>el.onclick=()=>{
    const id=+el.dataset.msgpick;
    const cur=S.chatSel||[];
    S.chatSel = cur.includes(id) ? cur.filter(x=>x!==id) : cur.concat([id]);
    render();
  });
  const ctDel=$("#ct-del"); if(ctDel) ctDel.onclick=async ()=>{
    const ids=(S.chatSel||[]).slice();
    if(!ids.length) return;
    if(!(await confirmAction({title:t("deleteMsgsQ").replace("{n}",ids.length), body:t("cannotUndo"), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  const ctClear=$("#ct-clear"); if(ctClear) ctClear.onclick=async ()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    if(!ids.length) return;
    if(!(await confirmAction({title:t("clearChatQ"), body:t("clearChatHint").replace("{n}",ids.length), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-sreqdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    if(!(await confirmAction({title:t("deleteReqQ"), body:t("cannotUndo"), danger:true}))) return;
    await DB.deleteStaffReq(+b.dataset.sreqdel); toastOk(t("saved")); render();
  });
  const avBtn=$("#att-vac"); if(avBtn) avBtn.onclick=()=>openVacationModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  const aoBtn=$("#att-only"); if(aoBtn) aoBtn.onclick=()=>openAttPersonModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  document.querySelectorAll("[data-dgopen]").forEach(b=>b.onclick=()=>{
    const [kind,key]=String(b.dataset.dgopen).split("|");
    S.openDay={...(S.openDay||{})};
    S.openDay[kind] = (S.openDay[kind]===key) ? null : key;   // tap again to close
    render();
  });
  const aEnt=$("#asg-ent"); if(aEnt) aEnt.onclick=()=>openEntranceModal(assignDay());
  document.querySelectorAll("[data-aopen]").forEach(el=>el.onclick=()=>{
    openEditModal(el.dataset.aopen);
  });
  document.querySelectorAll("[data-userleave]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openLeaveModal(+b.dataset.userleave);
  });
  document.querySelectorAll("[data-bkedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openBookingEditor(+b.dataset.bkedit);
  });
  document.querySelectorAll("[data-bkguest]").forEach(b=>b.onclick=()=>{
    S.tab="g360:"+b.dataset.bkguest; render();
  });
  document.querySelectorAll("[data-bkdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    const id=+b.dataset.bkdel;
    const bk=S.bookings.find(x=>x.id===id); if(!bk) return;
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(id); toastOk(t("saved")); render();
  });
  document.querySelectorAll("[data-aemp]").forEach(el=>el.onclick=()=>openSkillEditor(el.dataset.aemp));
  if(S.tab==="weather" && !S.weather) loadWeather(false);
  document.querySelectorAll("[data-bdrole]").forEach(b=>b.onclick=()=>{ S.sub.builder=b.dataset.bdrole; render(); });
  const bdStart=$("#bd-start");
  if(bdStart) bdStart.onchange=async ()=>{
    const role=builderRole(), m={...(S.settings.menu||{})};
    m[role]={...(m[role]||{}), start:bdStart.value};
    await DB.saveSettings({...S.settings, menu:m});
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-bdup]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bdup,-1));
  document.querySelectorAll("[data-bddown]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bddown,1));
  document.querySelectorAll("[data-bdname]").forEach(b=>b.onclick=()=>openRenameModal(b.dataset.bdname));
  document.querySelectorAll("[data-bdhide]").forEach(b=>b.onclick=()=>toggleMenuItem(b.dataset.bdhide));
  document.querySelectorAll("[data-bdgname]").forEach(b=>b.onclick=()=>openGroupRenameModal(b.dataset.bdgname));
  document.querySelectorAll("[data-bdedit]").forEach(b=>b.onclick=()=>pbOpen(builderRole(), b.dataset.bdedit));
  document.querySelectorAll("[data-bddel]").forEach(b=>b.onclick=()=>openCustomPageModal(b.dataset.bddel));
  const bdAdd=$("#bd-add"); if(bdAdd) bdAdd.onclick=()=>pbOpen(builderRole(), null);
  const bdReset=$("#bd-reset"); if(bdReset) bdReset.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle")})) return;
    saveMenuConf(builderRole(),{order:[],hidden:[],names:{},custom:[]});
  };
  if($("#s-logo")){
    const fileIn=document.querySelector("[data-photoinput]");
    const box=document.querySelector("[data-photobox]");
    const paint=()=>{ if(!box) return; const u=$("#s-logo").value;
      box.innerHTML = u ? `<img src="${esc(u)}" alt="">` : `<span>${ic("user",26)}</span>`; };
    paint();
    if(box) box.onclick=()=>fileIn&&fileIn.click();
    if(fileIn) fileIn.onchange=()=>{
      const f=fileIn.files&&fileIn.files[0]; if(!f) return;
      openCropModal(f, url=>{ const el=$("#s-logo"); if(el) el.value=url; paint(); toastOk(t("saved")); });
      fileIn.value="";
    };
    const rmL=$("#s-logo-rm");
    if(rmL) rmL.onclick=()=>{ const el=$("#s-logo"); if(el) el.value=""; paint(); };
  }
  const infoAdd=$("#info-add"); if(infoAdd) infoAdd.onclick=()=>openInfoModal();
  document.querySelectorAll("[data-infoedit]").forEach(b=>b.onclick=()=>openInfoModal(+b.dataset.infoedit));
  const phAdd=$("#ph-add"); if(phAdd) phAdd.onclick=openPhotoModal;
  document.querySelectorAll("[data-phdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deletePhoto(+b.dataset.phdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const srNew=$("#sr-new"); if(srNew) srNew.onclick=openStaffReqModal;
  document.querySelectorAll("[data-reqok]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqok,"ok"));
  document.querySelectorAll("[data-reqno]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqno,"no"));
  document.querySelectorAll("[data-guestrate]").forEach(b=>b.onclick=async ()=>{
    const rate=+b.dataset.guestrate;
    try{
      await DB.addFeedback({room:String(S.session.room||""), nationality:S.session.nationality||"",
        rate, comment:"", by_user:""});
      toastOk(t("thankYou"));
      render();
      // happy guests are invited to post publicly; unhappy ones stay private with the manager
      setTimeout(()=>openReviewInvite(rate), 350);
    }catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-attn]").forEach(b=>b.onclick=()=>{
    const [tab,sub]=b.dataset.attn.split("|");
    S.tab=tab; if(sub) S.sub[tab]=sub; render();
  });
  document.querySelectorAll("[data-satt]").forEach(b=>b.onclick=async ()=>{
    const [un,mk,d]=b.dataset.satt.split("|");
    const u=S.users.find(x=>x.username===un); if(!u) return;
    const next=attNext(u,mk,+d);
    if(next===undefined) return;                 // future day — nothing to mark
    try{ await DB.setStaffAtt(un, dateStr(mk,+d), next); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const attP=$("#att-prev"); if(attP) attP.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),-1); render(); };
  const attN=$("#att-next"); if(attN) attN.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),1); render(); };
  const attX=$("#att-export"); if(attX) attX.onclick=()=>openExportModal("monthatt");
  document.querySelectorAll("[data-quiznew]").forEach(b=>b.onclick=()=>openQuizModal(null,b.dataset.quiznew));
  document.querySelectorAll("[data-quizedit]").forEach(b=>b.onclick=()=>{
    const q=S.quizzes.find(x=>x.id==b.dataset.quizedit); if(q) openQuizModal(q);
  });
  document.querySelectorAll("[data-quizdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deleteQuiz(+b.dataset.quizdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-palette]").forEach(b=>b.onclick=()=>openThemePreview(b.dataset.palette));
  const nt=$("#notif-toggle"); if(nt) nt.onclick=()=>{
    const turningOn=!notifSoundOn();
    localStorage.setItem("ent_notif",turningOn?"on":"off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    render();
  };
  const aks=$("#ai-savekey"); if(aks) aks.onclick=()=>{
    const v=$("#ai-key").value.trim(); if(!v) return;
    localStorage.setItem("ent_ai_key",v); toast(t("saved")); render();
  };
  const ais=$("#ai-send");
  if(ais){
    const go=()=>{ const inp=$("#ai-in"); const v=inp.value.trim(); if(!v||S.aiBusy) return; inp.value=""; askAI(v); };
    ais.onclick=go;
    $("#ai-in").onkeydown=e=>{ if(e.key==="Enter") go(); };
  }
  document.querySelectorAll("[data-taskdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteTask(+b.dataset.taskdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-roomact]").forEach(b=>b.onclick=async ()=>{
    const r=S.rooms.find(x=>x.id==b.dataset.roomact); if(!r) return;
    await DB.setRoomActive(r.id,!r.active); render();
  });
  document.querySelectorAll("[data-roomdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRoom(+b.dataset.roomdel||b.dataset.roomdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-chatroom]").forEach(el=>el.onclick=()=>{
    S.chatRoom=el.dataset.chatroom; render();
  });
  document.querySelectorAll("[data-staffchat]").forEach(el=>el.onclick=()=>{
    S.chatRoom="staff:"+el.dataset.staffchat; render();
  });
  document.querySelectorAll("[data-msgedit]").forEach(b=>b.onclick=()=>{
    const m=S.messages.find(x=>x.id==b.dataset.msgedit); if(m) openMsgEditModal(m);
  });
  document.querySelectorAll("[data-msgdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteMessage(+b.dataset.msgdel||b.dataset.msgdel); toast(t("deleted")); render();
  });
  S.chatSel = S.chatRoom ? S.chatSel : null;
  const cb=$("#btn-chatback"); if(cb) cb.onclick=()=>{S.chatRoom=null;render();};
  const add=$("#btn-add"); if(add) add.onclick=()=>openEditModal(null);
  const addT=$("#btn-addticket"); if(addT) addT.onclick=()=>openTicketEditModal(null);
  const addU=$("#btn-adduser"); if(addU) addU.onclick=openUserModal;
  const addTk=$("#btn-addtask"); if(addTk) addTk.onclick=openTaskAddModal;
  const rs=$("#btn-req-song"); if(rs) rs.onclick=()=>openRequestModal("song");
  const rb=$("#btn-req-bday"); if(rb) rb.onclick=()=>openRequestModal("birthday");
  const ar=$("#btn-addrooms"); if(ar) ar.onclick=async ()=>{
    const raw=$("#rooms-in").value;
    const list=[...new Set(raw.split(/[\n,;]+/).map(x=>x.trim()).filter(Boolean))];
    if(!list.length) return;
    await DB.addRooms(list); toast(t("saved")); render();
  };
  const rf=$("#rooms-filter"); if(rf) rf.oninput=()=>{
    const q=rf.value.trim().toLowerCase();
    document.querySelectorAll(".roomline").forEach(el=>{
      el.style.display = !q || el.dataset.room.toLowerCase().includes(q) || el.textContent.toLowerCase().includes(q) ? "" : "none";
    });
  };
  const sv=$("#btn-savesettings"); if(sv) sv.onclick=async ()=>{
    // Each settings page shows only some fields — save exactly what is on screen,
    // and leave everything else untouched.
    const v=(id,fb)=>{ const el=$(id); return el?el.value:fb; };
    const has=id=>!!$(id);
    const st={...S.settings};
    if(has("#s-name"))    st.name=v("#s-name","").trim()||"Entertainment";
    if(has("#s-sub"))     st.subtitle=v("#s-sub","").trim();
    if(has("#s-welcome")) st.welcomeMsg=v("#s-welcome","").trim();
    if(has("#s-primary")){ st.primary=v("#s-primary",st.primary); st.accent=v("#s-accent",st.accent);
      st.bg=v("#s-bg",st.bg); st.textColor=v("#s-text",st.textColor);
      st.navBg=v("#s-navbg",st.navBg); st.navActive=v("#s-navon",st.navActive); }
    if(has("#s-font"))    st.fontStyle=v("#s-font",st.fontStyle);
    if(has("#s-btn"))     st.buttonStyle=v("#s-btn",st.buttonStyle);
    if(has("#s-mhome")){ st.menuHome=v("#s-mhome","").trim(); st.menuProgram=v("#s-mprog","").trim();
      st.menuTickets=v("#s-mtick","").trim(); st.menuChat=v("#s-mchat","").trim(); st.menuStay=v("#s-mstay","").trim(); }
    if(has("#s-trip")){ st.tripadvisor=v("#s-trip","").trim(); st.google=v("#s-goog","").trim();
      st.holidaycheck=v("#s-holi","").trim(); }
    if(has("#s-insta")){ st.instagram=v("#s-insta","").trim(); st.tiktok=v("#s-tiktok","").trim();
      st.facebook=v("#s-fb","").trim(); st.youtube=v("#s-yt","").trim(); st.whatsapp=v("#s-wa","").trim(); }
    if(has("#s-fs"))       st.fontScale=v("#s-fs",st.fontScale);
    if(has("#s-autodark")) st.autoDark=$("#s-autodark").checked;
    if(has("#s-logo"))     st.logo=v("#s-logo","").trim();
    if(has("#s-hotel"))    st.hotelName=v("#s-hotel","").trim();
    if(has("#s-contact"))  st.contact=v("#s-contact","").trim();
    if(has("#s-cur"))      st.currency=v("#s-cur","").trim();
    if(has("#s-tz"))       st.timezone=v("#s-tz",st.timezone);
    if(has("#s-lat")){ st.lat=v("#s-lat","").trim(); st.lon=v("#s-lon","").trim(); }
    const featBoxes=document.querySelectorAll(".feat-cb");
    if(featBoxes.length){ const f={}; ["quiz","tickets","gallery","bus","hotelinfo","weather"].forEach(k=>f[k]=false);
      featBoxes.forEach(cb=>{ if(cb.checked) f[cb.value]=true; }); st.features=f; }
    if(has("#s-aiep"))   st.aiEndpoint=v("#s-aiep","").trim();
    if(has("#s-pushep")) st.pushEndpoint=v("#s-pushep","").trim();
    // only accept secure https endpoints
    for(const f of ["aiEndpoint","pushEndpoint"]){
      if(st[f] && !/^https:\/\//i.test(st[f])){ toastErr(t("errHttps")); return; }
    }
    const coordsChanged = st.lat!==S.settings.lat || st.lon!==S.settings.lon || st.timezone!==S.settings.timezone;
    await DB.saveSettings(st); applySettings();
    if(coordsChanged) loadWeather(true);
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-open]").forEach(el=>el.onclick=()=>{
    if(!S.session || S.session.role!=="guest") return;
    const a=S.activities.find(x=>x.id===+el.dataset.open);
    if(a) openGuestActivityDetail(a);
  });
  /* chat send + read marking + scroll */
  const cs=$("#chat-send");
  if(cs){
    const g=S.session;
    let room, meSide, readSide;
    if(g.role==="guest"){ room=g.room; meSide="guest"; readSide="guest"; }
    else if(g.role==="staff"){ room="staff:"+g.username; meSide="guest"; readSide="guest"; }
    else { room=S.chatRoom; meSide="team"; readSide="team"; }
    if(room){
      const flag = readSide==="team"?"read_by_team":"read_by_guest";
      const sender = readSide==="team"?"guest":"team";
      if(S.messages.some(m=>m.room===room&&m.sender===sender&&!m[flag])){
        DB.markRead(room,readSide).then(()=>render());
      }
      window.scrollTo(0,document.body.scrollHeight);
      const doSend=async ()=>{
        const inp=$("#chat-in"); const txt=inp.value.trim(); if(!txt) return;
        inp.value="";
        await DB.addMessage({room,sender:meSide,sender_name:g.name,text:txt,
          read_by_team:meSide==="team",read_by_guest:meSide==="guest"});
        render();
      };
      cs.onclick=doSend;
      $("#chat-in").onkeydown=e=>{ if(e.key==="Enter") doSend(); };
    }
  }
}

/* ---------------- boot ---------------- */
function safeToRender(){
  if(document.querySelector(".modal-bg")) return false;
  const a=document.activeElement;
  return !(a && ["INPUT","TEXTAREA","SELECT"].includes(a.tagName));
}
/* ============ NOTIFICATIONS (sound + vibrate + banner) ============ */
let AUDIO_CTX=null;
function notifSoundOn(){ return localStorage.getItem("ent_notif")!=="off"; }
function playChime(){
  if(!notifSoundOn()) return;
  try{
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    const ctx=AUDIO_CTX; if(ctx.state==="suspended") ctx.resume();
    const now=ctx.currentTime;
    // two-note soft "ding-dong" using sine tones
    [[880,0],[1174,0.14]].forEach(([f,dt])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.type="sine"; o.frequency.value=f;
      o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0,now+dt);
      g.gain.linearRampToValueAtTime(0.35,now+dt+0.02);
      g.gain.exponentialRampToValueAtTime(0.001,now+dt+0.42);
      o.start(now+dt); o.stop(now+dt+0.45);
    });
  }catch(e){}
}
function vibrate(){ if(notifSoundOn() && navigator.vibrate){ try{ navigator.vibrate([120,60,120]); }catch(e){} } }
let SW_REG=null;
let SW_READY=false;
/* Registers the REAL static service worker file (sw.js) that sits next to index.html.
   Relative path keeps the scope correct on GitHub Pages sub-paths. */
/* ===================== SERVICE WORKER =====================
   SAFE MODE: set USE_SERVICE_WORKER to true again only once sw.js
   is confirmed uploaded next to index.html and the app logs in fine.
   While false, this actively REMOVES any old/stuck service worker and
   clears its caches, so a bad cached copy can never keep the app broken. */
const APP_BUILD = "2026.09.07-aurea-stability-v6.2";   // shown in the menu, so an upload can be checked at a glance
const USE_SERVICE_WORKER = false;

function cleanupServiceWorkers(){
  if(!("serviceWorker" in navigator)) return;
  try{
    navigator.serviceWorker.getRegistrations().then(regs=>{
      regs.forEach(r=>{ r.unregister().catch(()=>{}); });
      if(regs.length){ console.warn("removed", regs.length, "old service worker(s)"); }
    }).catch(()=>{});
    if(window.caches && caches.keys){
      caches.keys().then(keys=>keys.forEach(k=>caches.delete(k).catch(()=>{}))).catch(()=>{});
    }
  }catch(e){ console.warn("sw cleanup:", e && e.message); }
}

function registerServiceWorker(){
  if(!("serviceWorker" in navigator)) return;
  if(!USE_SERVICE_WORKER){ cleanupServiceWorkers(); return; }
  try{
    navigator.serviceWorker.register("sw.js").then(reg=>{
      SW_REG=reg; SW_READY=true;
      if(reg.waiting) reg.waiting.postMessage({kind:"skip-waiting"});
      reg.addEventListener&&reg.addEventListener("updatefound",()=>{
        const nw=reg.installing;
        if(nw) nw.addEventListener("statechange",()=>{
          if(nw.state==="installed" && navigator.serviceWorker.controller) toastOk(t("updateReady"));
        });
      });
    }).catch(err=>{ console.warn("service worker not registered:", err && err.message); });

    navigator.serviceWorker.addEventListener("message", ev=>{
      const d=ev.data||{};
      if(d.kind==="notification-click"){ routeFromNotification(d.type); }
      if(d.kind==="resubscribe"){ subscribeForPush(); }
    });
  }catch(e){ console.warn("service worker error:", e && e.message); }
}
/* Opens the right page when a notification is tapped */
const NOTIF_ROUTE={
  booking:"bookings", booking_confirmed:"tickets", booking_cancelled:"tickets",
  activity_soon:"program", announcement:"home", message:"chat", chat:"chat",
  ticket:"tickets", request:"guests", task:"tasks", assignment:"tasks",
  attendance:"workday", feedback:"guests", occupancy:"dash"
};
function routeFromNotification(type){
  if(!S.session) return;
  const tab=NOTIF_ROUTE[type]; if(!tab) return;
  const allowed=navItems(S.session.role).map(x=>x[0]);
  if(allowed.includes(tab)){ S.tab=tab; S.op=null; S.cat=null; persist(); render(); }
}
/* If the app was opened fresh from a notification (?open=tab) */
function applyOpenParam(){
  try{
    const m=String(location.search||"").match(/[?&]open=([a-z]+)/i);
    if(!m || !S.session) return;
    const tab=m[1];
    const allowed=navItems(S.session.role).map(x=>x[0]);
    if(allowed.includes(tab)){ S.tab=tab; }
    history.replaceState({}, "", location.pathname);
  }catch(e){}
}
function showBanner(title,body){
  if(!notifSoundOn()) return;
  try{
    if("Notification" in window && Notification.permission==="granted"){
      // Prefer the service worker — its notifications persist even when the tab is in the background.
      if(SW_REG && SW_REG.showNotification){
        SW_REG.showNotification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true,vibrate:[120,60,120]});
      } else {
        const n=new Notification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true});
        setTimeout(()=>{ try{ n.close(); }catch(e){} },6000);
      }
    }
  }catch(e){}
}
function notify(title,body){ playChime(); vibrate(); showBanner(title,body); toast(title); }
/* Public push key — already set. Nothing to edit. */
const PUSH_PUBLIC_KEY="BBVFLaJhNy8JyyYiGPGOI7hFk9GVmgzWxo7ZSy5_Uo44xTg91TlQAppm8Y96xnmUHcr-4u81w4YxVrtZqqCSML8";
function urlB64ToUint8(base64){
  const pad="=".repeat((4-base64.length%4)%4);
  const b=(base64+pad).replace(/-/g,"+").replace(/_/g,"/");
  const raw=atob(b); const out=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i);
  return out;
}
async function subscribeForPush(){
  try{
    if(!("serviceWorker" in navigator) || !("PushManager" in window)) return;
    if(!PUSH_PUBLIC_KEY || PUSH_PUBLIC_KEY.indexOf("__")===0) return; // key not set → skip silently
    const reg = SW_REG || await navigator.serviceWorker.ready;
    if(!reg || !reg.pushManager) return;
    let sub = await reg.pushManager.getSubscription();
    if(!sub){
      sub = await reg.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:urlB64ToUint8(PUSH_PUBLIC_KEY)});
    }
    const j = sub.toJSON();
    const sess = S.session||{};
    const row = {
      endpoint: j.endpoint,
      p256dh: j.keys && j.keys.p256dh,
      auth: j.keys && j.keys.auth,
      role: sess.role||"",
      username: sess.username||"",
      room: sess.role==="guest" ? String(sess.room||"") : ""
    };
    // upsert into push_subscriptions (endpoint is primary key)
    if(REMOTE){
      await sb("push_subscriptions?on_conflict=endpoint",{
        method:"POST",
        headers:{ "Prefer":"resolution=merge-duplicates" },
        body: JSON.stringify(row)
      });
    }
  }catch(e){}
}
function askNotifPermission(){
  try{
    registerServiceWorker();
    if("Notification" in window && Notification.permission==="default"){
      Notification.requestPermission().then(p=>{ if(p==="granted") subscribeForPush(); }).catch(()=>{});
    } else if("Notification" in window && Notification.permission==="granted"){
      subscribeForPush();
    }
    // unlock audio on this user gesture
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    if(AUDIO_CTX.state==="suspended") AUDIO_CTX.resume();
  }catch(e){}
}
/* decide what changed after a poll and alert the current user accordingly */
function detectAndNotify(before){
  if(!S.session) return;
  const role=S.session.role, me=S.session.username;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  // MANAGER: new guest booking, new request, new incoming chat (from guest or staff)
  if(role==="manager"){
    if(S.bookings.length>before.bookings) notify(t("notifBooking"), "");
    if(S.requests.length>before.requests) notify(t("notifRequest"), "");
    const incoming=S.messages.filter(m=>m.sender==="guest").length;
    if(incoming>before.incomingMsgs) notify(t("notifMsg"), "");
  }
  // STAFF: new task assigned to me, or new chat reply from manager
  if(role==="staff"){
    const myTasks=S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length;
    if(myTasks>before.myTasks) notify(t("notifTask"), "");
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // GUEST: new chat reply from team, or new announcement
  if(role==="guest"){
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // EVERYONE: new announcement for them
  if(S.notes.length>before.notes) notify(t("notifNew"), "");
}
function notifySnapshot(){
  const role=S.session?S.session.role:null, me=S.session?S.session.username:null;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  return {
    bookings:S.bookings.length, requests:S.requests.length, notes:S.notes.length,
    incomingMsgs:S.messages.filter(m=>m.sender==="guest").length,
    myTasks:role==="staff"?S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length:0,
    myMsgs:myRoom?S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length:0
  };
}
let __polling=false;
/* ============ ACTIVITY ALARMS (time-based, fire once each) ============
   For the current user, checks every minute and alerts:
   - 5 minutes before start, at start, and at end of each activity today.
   Targeting:
   - GUEST: only activities they booked.
   - ASSIGNED entertainer: personal messages (be there 5 min early / take feedback after).
   - OTHER staff + manager: a general heads-up for every activity.
   Each (activity, phase) fires only once per day per device (tracked in localStorage). */
function alarmSeen(){ try{ return JSON.parse(localStorage.getItem("ent_alarms")||"{}"); }catch(e){ return {}; } }
function alarmSeenSave(o){ try{ localStorage.setItem("ent_alarms", JSON.stringify(o)); }catch(e){} }
function alarmKey(day,id,phase){ const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); return stamp+":"+day+":"+id+":"+phase; }
function fireActivityAlarm(a, phase){
  if(!S.session) return;
  const role=S.session.role;
  const name=a.name||"";
  const assigned = role==="staff" && a.entertainer && String(a.entertainer).toLowerCase()===String(S.session.username).toLowerCase();
  let title="", body=name;
  if(role==="guest"){
    // only booked activities (checked by caller)
    if(phase==="soon") title=t("almSoonG");
    else if(phase==="start") title=t("almStartG");
    else title=t("almDoneG");
    body=name;
  } else if(assigned){
    if(phase==="soon"){ title=t("almSoonS"); body=name; }
    else if(phase==="start"){ title=t("almStartS"); body=name; }
    else { title=t("almDoneS"); body=name; } // feedback reminder with room number
  } else {
    // other staff + manager: general heads-up
    if(phase==="soon") title=t("almSoonTeam");
    else if(phase==="start") title=t("almStartTeam");
    else title=t("almDoneTeam");
    body=name;
  }
  notify(title, body);
}
function checkActivityAlarms(){
  if(!S.session) return;
  if(!notifSoundOn()) return;               // respect the sound/alerts toggle
  const role=S.session.role;
  const todayIdx=todayIndex();
  const now=nowMinutes();
  const seen=alarmSeen();
  let changed=false;
  const todays=S.activities.filter(a=>a.day===todayIdx);
  todays.forEach(a=>{
    const w=actWindow(a); if(!w) return;
    // Relevance filter
    if(role==="guest"){ if(!myBooking(a.id)) return; }        // only booked
    // staff & manager: everyone gets it (assigned gets personal copy inside fireActivityAlarm)
    const phases=[["soon", w.s0-5],["start", w.s0],["done", w.e0]];
    phases.forEach(([phase, mark])=>{
      // fire when we're within the same minute or just past it (catch-up window of 2 min)
      if(now>=mark && now<mark+2){
        const k=alarmKey(a.day,a.id,phase);
        if(!seen[k]){ seen[k]=1; changed=true; fireActivityAlarm(a, phase); }
      }
    });
  });
  if(changed) alarmSeenSave(seen);
  // prune old keys (keep it small) — drop anything not from today
  const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
  const pruned={}; let prunedChanged=false;
  Object.keys(seen).forEach(k=>{ if(k.indexOf(stamp+":")===0) pruned[k]=1; else prunedChanged=true; });
  if(prunedChanged) alarmSeenSave(pruned);
}
/* re-render the visible list each minute so the status dots stay current */
function tickStatus(){ if(S.session && safeToRender()) render(); }
async function runPoll(){
  if(!REMOTE || __polling || !S.session) return;
  if(enforceAccess()){ render(); return; }
  __polling=true;
  try{ const before=notifySnapshot(); const changed=await DB.poll();
    if(changed){ detectAndNotify(before); if(safeToRender()) render(); }
  }catch(e){}
  __polling=false;
}
/* Maps a database table to the matching array in app state. */
const RT_TABLES={
  activities:"activities", bookings:"bookings", app_users:"users", tickets:"tickets",
  ticket_orders:"orders", rooms:"rooms", guest_accounts:"accounts", messages:"messages",
  requests:"requests", tasks:"tasks", announcements:"notes", attendance:"attendance",
  feedback:"feedback", team_profiles:"profiles", buses:"buses", quizzes:"quizzes", quiz_replies:"quizReplies", staff_attendance:"staffAtt", photos:"photos", staff_requests:"staffReqs"
};
/* Applies ONE row change straight into state — no full database reload. */
function applyRealtimeChange(payload){
  try{
    const table=payload.table, ev=payload.eventType||payload.type;
    // app_settings is a single row of config — merge it directly
    if(table==="app_settings"){
      const row=payload.new;
      if(row && row.data){ S.settings={...DEFAULT_SETTINGS,...row.data}; applySettings(); return true; }
      return false;
    }
    const key=RT_TABLES[table]; if(!key || !Array.isArray(S[key])) return false;
    const list=S[key];
    if(ev==="INSERT" && payload.new){
      if(!list.some(x=>x.id===payload.new.id)) list.push(payload.new);
      return true;
    }
    if(ev==="UPDATE" && payload.new){
      const i=list.findIndex(x=>x.id===payload.new.id);
      if(i>=0) list[i]={...list[i],...payload.new}; else list.push(payload.new);
      return true;
    }
    if(ev==="DELETE"){
      const oldRow=payload.old||{};
      if(oldRow.id==null) return false;
      S[key]=list.filter(x=>x.id!==oldRow.id);
      return true;
    }
  }catch(e){ console.warn("realtime patch failed:", e && e.message); }
  return false;
}
function startRealtime(){
  if(!REMOTE || window.__rt) return;
  window.__rt=true;
  const sc=document.createElement("script");
  sc.src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
  sc.onload=()=>{ try{
    const client=window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
    let tmr=null, pending=false;
    client.channel("live-changes")
      .on("postgres_changes",{event:"*",schema:"public"},payload=>{
        const before=notifySnapshot();
        const patched=applyRealtimeChange(payload);
        if(patched){
          // targeted update: state is already correct, just alert + repaint
          detectAndNotify(before);
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ if(S.session && safeToRender()) render(); }, 120);
        } else if(!pending){
          // unknown table -> fall back to a single full refresh
          pending=true;
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ pending=false; runPoll(); }, 300);
        }
      })
      .subscribe();
  }catch(e){ console.warn("realtime unavailable",e); } };
  sc.onerror=()=>console.warn("realtime script blocked — polling continues");
  document.head.appendChild(sc);
}
(async function(){
  restore();
  document.documentElement.setAttribute("data-theme",S.theme);
  document.documentElement.lang=S.lang;
  document.documentElement.dir=(S.lang==="ar"?"rtl":"ltr");
  try{ await DB.load(); }
  catch(e){
    console.error(e);
    if(REMOTE){ S.loadError=true; applySettings(); render(); return; }
    S.activities=demoActivities(); S.bookings=demoBookings();
    S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
    S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
    S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
  }
  /* validate remembered session against fresh data */
  if(S.session){
    if(S.session.role==="guest"){
      const rm=S.rooms.find(x=>String(x.room)===String(S.session.room));
      const acc=S.accounts.find(a=>a.id===S.session.accountId) || S.accounts.find(a=>String(a.room)===String(S.session.room));
      const sameStay=!!acc && String(S.session.arrival||"")===String(acc.arrival||"") && String(S.session.departure||"")===String(acc.departure||"");
      if(!rm || !rm.active || !acc || !sameStay || acc.active===false || stayExpired(acc)) S.session=null;
      else S.session={role:"guest",room:acc.room,name:acc.name,phone:acc.phone||"",
        nationality:acc.nationality||"",arrival:acc.arrival,departure:acc.departure,
        accountId:acc.id,username:acc.username||acc.room};
    } else {
      const su=String(S.session.username||"").trim().toLowerCase();
      const u=S.users.find(x=>String(x.username||"").trim().toLowerCase()===su && !isAttOnly(x));
      const roleOk=!!u && (S.session.role==="manager" ? u.role==="manager" : u.role==="staff");
      if(!roleOk || !accountActive(u)) S.session=null;
      else S.session={...S.session,name:u.display_name||u.username,userId:u.id,number:u.number||null,photo:u.photo||''};
    }
    if(!S.session){ S.tab="home"; }
    persist();
  }
  /* V5: resolve the final landing screen before the first paint, preventing the remembered-screen -> start-screen flash. */
  if(S.session) S.tab=defaultTabFor(S.session.role);
  enforceAccess();
  applyOpenParam();
  applySettings();
  render();
  startRealtime();
  // Fast polling backup — makes updates feel instant even if websockets are blocked.
  if(REMOTE){
    setInterval(()=>{ if(S.session) runPoll(); }, 5000);
    // Poll immediately when the app regains focus or becomes visible
    window.addEventListener("focus", ()=>{ if(S.session) runPoll(); });
    document.addEventListener("visibilitychange", ()=>{ if(!document.hidden && S.session) runPoll(); });
  }
  initPhotoTaps();
  setTimeout(()=>loadWeather(false), 800);
  initConnectionWatch();
  initErrorGuard();
  // ===== Activity alarms + live status dots =====
  // Check every 30s so a minute boundary is never missed; re-render keeps dots current.
  let __lastMin=-1;
  function alarmTick(){
    try{
      checkActivityAlarms();
      const m=nowMinutes();
      if(m!==__lastMin){ __lastMin=m; tickStatus(); }   // refresh dots once per minute
    }catch(e){}
  }
  setInterval(alarmTick, 30000);
  setTimeout(alarmTick, 1500);                            // run shortly after load
  window.addEventListener("focus", alarmTick);            // catch phone waking up
  document.addEventListener("visibilitychange", ()=>{ if(!document.hidden) alarmTick(); });
})();
