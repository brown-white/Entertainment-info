
(function(){
  'use strict';
  const __guestViewV610 = guestView;

  function identityKeyV611(name){
    return String(name||'').normalize('NFKD').toLowerCase()
      .replace(/\b(mr|mrs|ms|miss|mister|madam)\.?\b/g,'')
      .replace(/[^a-z0-9\u00c0-\uffff]+/g,'')
      .trim();
  }

  // Canonical team list: merges Team Profiles + Team Accounts even when titles/punctuation differ.
  teamMemberList = function(){
    const map=new Map();
    function add(name,photo,rank){
      const nm=String(name||'').trim(); if(!nm) return;
      const key=identityKeyV611(nm) || nm.toLowerCase();
      const old=map.get(key);
      if(!old){ map.set(key,{name:nm,photo:photo||'',rank:rank||9}); return; }
      if(!old.photo && photo) old.photo=photo;
      if((rank||9)<old.rank){ old.name=nm; old.rank=rank||9; }
    }
    (S.profiles||[]).forEach(p=>add(p.name,p.photo,2));
    (S.users||[]).filter(u=>(u.role==='staff'||u.role==='manager') && u.active!==false && !isAttOnly(u)).forEach(u=>{
      const ph=(u.photos&&u.photos[0])||u.photo||'';
      add(u.display_name||u.username,ph,1);
    });
    return [...map.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(({name,photo})=>({name,photo}));
  };

  function typeInfoV611(a){
    const c=normCat(a);
    if(c==='mEvents') return {cls:'g611-event',label:catLabel(c),icon:'sparkle'};
    if(c==='eLive'||c==='eBefore'||c==='eAfter') return {cls:'g611-live',label:catLabel(c),icon:'music'};
    if(c==='eShow') return {cls:'g611-show',label:catLabel(c),icon:'star'};
    if(c==='eParty') return {cls:'g611-party',label:catLabel(c),icon:'sparkle'};
    return {cls:'g611-activity',label:catLabel(c),icon:'flag'};
  }

  function todayCardV611(a){
    const tp=typeInfoV611(a), mine=myBooking(a.id), st=isToday(a.day)?activityStatus(a):'todo';
    const unlimited=!(+a.capacity), taken=seatsTaken(a.id), left=Math.max(0,(+a.capacity||0)-taken), full=!unlimited&&left<=0;
    let action='';
    if(st==='done') action=`<span class="g611-mini-status">${esc(t('finishedChip'))}</span>`;
    else if(mine) action=`<span class="g611-mini-status">${esc(mine.status==='booked'?t('booked'):t('onWaitlist'))}</span>`;
    else if(full) action=`<span class="g611-mini-status">${esc(t('full'))}</span>`;
    else action=`<button class="g611-mini-book" data-book="${a.id}">${esc(st==='live'?t('bookNowLive'):t('book'))}</button>`;
    return `<div class="g611-today-card ${tp.cls}" data-open="${a.id}">
      <img class="g611-today-img" src="${esc(a.image||IMG.show)}" alt="" loading="lazy">
      <div class="g611-today-copy">
        <div class="g611-today-type">${ic(tp.icon,12)} ${esc(tp.label)}</div>
        <h4>${esc(a.name)}</h4>
        <div class="g611-today-meta"><span>${mi('pin')}${esc(a.location||'')}</span>${!unlimited&&!full?`<span>${left} ${esc(t('seatsLeft'))}</span>`:''}</div>
      </div>
      <div class="g611-today-side"><span class="g611-time-pill">${esc(a.time||'')}</span>${action}</div>
    </div>`;
  }

  function emptyV611(icon,text){
    return `<div class="g611-empty"><div class="g611-empty-ic">${ic(icon,23)}</div>${esc(text)}</div>`;
  }

  function guestHomeV611(){
    const g=S.session, todayIdx=todayIndex();
    const todays=(S.activities||[]).filter(a=>a.day===todayIdx).sort((x,y)=>String(x.time||'').localeCompare(String(y.time||'')));
    const hl=todays.find(a=>a.highlight)||todays[0];
    const rest=todays.filter(a=>!hl||a.id!==hl.id);
    const wm=(S.settings.welcomeMsg||'').trim();
    return `<div class="screen fadein g611 g611-today">
      ${guestHomeTopBar(g,todayIdx)}
      ${stayCard((S.accounts||[]).find(a=>a.id===g.accountId)||(S.accounts||[]).find(a=>String(a.room)===String(g.room)))}
      ${wm?`<div class="card guest-welcome-msg">${esc(wm)}</div>`:''}
      ${guestQuickActions()}
      ${hl?heroCarousel([hl].concat(todays.filter(a=>a.id!==hl.id&&a.highlight))):''}
      <div class="quickrow"><button id="btn-req-song"><span>${ic('music',22)}</span>${t('songRequest')}</button><button id="btn-req-bday"><span>${ic('gift',22)}</span>${t('birthdayRequest')}</button></div>
      <div class="g611-program-head"><h2>${esc(t('todayProgram'))}</h2><span>${rest.length} ${esc(t('itemsWord')||t('activities'))}</span></div>
      <div class="g611-timeline">${rest.length?rest.map(todayCardV611).join(''):emptyV611('calendar',t('noneToday'))}</div>
      ${reviewDue(g)?reviewBlock():''}${socialBlock()}
    </div>`;
  }

  function bookingCardV611(b){
    const a=(S.activities||[]).find(x=>x.id===b.activity_id); if(!a) return '';
    return `<div class="g611-res-card" data-open="${a.id}"><img src="${esc(a.image||IMG.show)}" alt="" loading="lazy"><div><h4>${esc(a.name)}</h4><p class="mini">${esc(t('daysShort')[a.day]||'')} · ${esc(a.time||'')} · ${esc(a.location||'')}</p></div><div class="g611-res-side"><span class="chip ${b.status==='booked'?'ok':''}">${esc(b.status==='booked'?t('booked'):t('onWaitlist'))}</span><button class="btn sm warn" data-cancel="${b.id}">${ic('close',13)}</button></div></div>`;
  }
  function orderCardV611(o){
    const tk=(S.tickets||[]).find(x=>x.id===o.ticket_id); if(!tk) return '';
    return `<div class="g611-res-card"><img src="${esc(tk.image||IMG.show)}" alt="" loading="lazy"><div><h4>${esc(tk.name)}</h4><p class="mini">${esc(t('daysShort')[tk.day]||'')} · ${esc(tk.time||'')} · ×${o.qty}${o.collect_from?' · '+esc(o.collect_from):''}</p></div><div class="g611-res-side"><span class="chip ${o.status==='paid'?'ok':'res'}">${esc(o.status==='paid'?t('paid'):t('reserved'))}</span>${o.status==='paid'?'':`<button class="btn sm warn" data-cancelorder="${o.id}">${ic('close',13)}</button>`}</div></div>`;
  }

  function guestStayV611(){
    const g=S.session, acc=(S.accounts||[]).find(a=>a.id===g.accountId)||(S.accounts||[]).find(a=>String(a.room)===String(g.room));
    const mine=(S.bookings||[]).filter(b=>String(b.room)===String(g.room));
    const orders=myOrders();
    return `<div class="screen fadein g611 g611-stay">
      ${topBar(t('myStay'),g.name)}
      <div class="g611-stay-hero"><div class="g611-eyebrow">${esc(t('myStay'))}</div><h2>${esc(g.name)}</h2><p class="mini">${esc(t('room'))} ${esc(g.room)}${g.nationality?' · '+esc(g.nationality):''}</p>${stayCard(acc)}<button class="btn sm ghost" id="btn-chpass" style="margin-top:12px;color:#fff;border-color:rgba(255,255,255,.25)">${ic('key',14)} ${esc(t('changePass'))}</button></div>
      <div class="g611-stay-actions"><div class="g611-stay-action"><b>${mine.length}</b><span>${esc(t('myBookings'))}</span></div><div class="g611-stay-action"><b>${orders.length}</b><span>${esc(t('myTickets'))}</span></div></div>
      <div class="g611-section-title"><h3>${esc(t('myBookings'))}</h3><span class="count">${mine.length}</span></div>${mine.length?mine.map(bookingCardV611).join(''):emptyV611('calendar',t('noBookings'))}
      <div class="g611-section-title"><h3>${esc(t('myTickets'))}</h3><span class="count">${orders.length}</span></div>${orders.length?orders.map(orderCardV611).join(''):emptyV611('ticket',t('ticketsNone'))}
    </div>`;
  }

  guestTicketsView = function(){
    return `<div class="screen fadein g611 g611-tickets">${topBar(t('tickets'),'')}<div class="g611-ticket-intro">${esc(t('payNote'))}</div>${(S.tickets||[]).length?(S.tickets||[]).map(tk=>{
      const sold=ticketsSold(tk.id),left=tk.capacity>0?Math.max(0,tk.capacity-sold):null,soldOut=left!==null&&left<=0;
      return `<article class="g611-ticket-card"><img src="${esc(tk.image||IMG.show)}" alt="" loading="lazy"><div class="g611-ticket-body"><div class="g611-eyebrow">${esc(t('tickets'))}</div><h4>${esc(tk.name)}</h4><div class="g611-ticket-meta"><span>${esc(t('days')[tk.day])}</span><span>${mi('clock')}${esc(tk.time)}</span><span>${mi('pin')}${esc(tk.location||'')}</span>${left!==null?`<span>${left} ${esc(t('seatsLeft'))}</span>`:''}</div><div class="g611-ticket-desc">${esc(tk.desc||'')}</div><div class="g611-ticket-foot"><span class="g611-ticket-price">${esc(tk.price||'')}</span>${soldOut?`<span class="chip full">${esc(t('soldOut'))}</span>`:`<button class="btn sm" data-buy="${tk.id}">${esc(t('buyTicket'))}</button>`}</div></div></article>`;
    }).join(''):emptyV611('ticket',t('ticketsNone'))}</div>`;
  };

  openTicketBuyModal = function(tk){
    const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null, max=left!==null?Math.max(1,Math.min(10,left)):10;
    const team=teamMemberList(); let chosen='';
    const wrap=baseModal(`<div class="ticket-buy-modern"><div class="g611-eyebrow">${esc(t('tickets'))}</div><h3>${esc(tk.name)}</h3><p class="mini">${esc(t('days')[tk.day])} · ${mi('clock')}${esc(tk.time)} · ${mi('pin')}${esc(tk.location||'')}</p>${tk.desc?`<p style="margin:12px 0 6px">${esc(tk.desc)}</p>`:''}<p class="mini">${esc(t('payNote'))}</p><div class="row2" style="align-items:end;margin-top:12px"><div><label>${esc(t('qty'))}</label><input id="tq" type="number" min="1" max="${max}" value="1"></div><div style="text-align:end;font-family:var(--font-display);font-size:26px;color:var(--cacao);padding-bottom:10px">${esc(tk.price||'')}</div></div>${team.length?`<div class="ticket-collect-title"><label style="margin:0">${esc(t('collectFrom'))}</label><span class="mini">${team.length}</span></div><div class="memberrow">${team.map(m=>`<button type="button" class="memb" data-memb="${esc(m.name)}"><span class="mb-av">${m.photo?`<img src="${esc(m.photo)}" alt="">`:esc(m.name.trim().charAt(0).toUpperCase())}</span><span class="mb-nm">${esc(m.name)}</span></button>`).join('')}</div>`:''}<button class="btn" id="t-go">${esc(t('buyTicket'))}</button><div class="err" id="t-err"></div><button class="btn ghost" id="t-x">${esc(t('close'))}</button></div>`);
    wrap.querySelector('#t-x').onclick=()=>wrap.remove();
    wrap.querySelectorAll('[data-memb]').forEach(b=>b.onclick=()=>{chosen=b.dataset.memb;wrap.querySelectorAll('.memb').forEach(x=>x.classList.toggle('on',x===b));wrap.querySelector('#t-err').textContent='';});
    wrap.querySelector('#t-go').onclick=async()=>{if(team.length&&!chosen){wrap.querySelector('#t-err').textContent=t('chooseMember');return;}const g=S.session,qty=Math.max(1,Math.min(max,+wrap.querySelector('#tq').value||1));await AUREA_TICKET_SERVICE.create({ticket_id:tk.id,room:g.room,guest_name:g.name,nationality:g.nationality||'',qty,status:'reserved',collect_from:chosen});wrap.remove();toast(t('ticketOk'));render();};
  };

  function guestChatV611(){
    const g=S.session, has=(S.messages||[]).some(m=>String(m.room)===String(g.room));
    return `<div class="screen fadein g611 g611-chat">${topBar(t('chat'),accountName(g.room))}<div class="g611-chat-person"><div class="g611-chat-avatar">E</div><div><b>${esc(t('team'))}</b><span>${has?esc(t('chat')):esc(t('noMessages'))}</span></div></div>${threadView(g.room,'guest')}</div>`;
  }

  guestView = function(){
    if(S.session && S.session.role==='guest'){
      if(S.tab==='home') return guestHomeV611();
      if(S.tab==='chat') return guestChatV611();
      if(S.tab==='stay'||S.tab==='bookings') return guestStayV611();
    }
    return __guestViewV610();
  };
})();
