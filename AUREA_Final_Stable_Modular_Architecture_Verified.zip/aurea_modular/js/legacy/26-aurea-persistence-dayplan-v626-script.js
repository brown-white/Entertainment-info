
(()=>{
'use strict';
if(window.__AUREA_PERSISTENCE_DAYPLAN_V626)return;
window.__AUREA_PERSISTENCE_DAYPLAN_V626=true;

let migratingV626=false;
async function migrateDashboardV626(){
  if(migratingV626||!S.settings||S.settings.dashboardDayOpsMigrationV626)return false;
  migratingV626=true;
  try{
    const po={...((S.settings&&S.settings.pageOrder)||{})};
    let order=Array.isArray(po.dash)?po.dash.filter(k=>PAGE_SECTIONS.dash.includes(k)):PAGE_SECTIONS.dash.slice();
    for(const k of PAGE_SECTIONS.dash)if(!order.includes(k))order.push(k);
    order=order.filter(k=>k!=="dayinfo"&&k!=="wholeday");
    const ai=order.indexOf("attention"),at=ai>=0?ai+1:0;
    order.splice(at,0,"dayinfo","wholeday");
    po.dash=order;

    const ph={...((S.settings&&S.settings.pageHidden)||{})};
    ph.dayplan=(Array.isArray(ph.dayplan)?ph.dayplan:[]).filter(k=>PAGE_SECTIONS.dayplan.includes(k));
    ph.dash=(Array.isArray(ph.dash)?ph.dash:[]).filter(k=>PAGE_SECTIONS.dash.includes(k));

    const next={...S.settings,pageOrder:po,pageHidden:ph,dashboardDayOpsMigrationV626:true};
    await DB.saveSettings(next);
    if(S.session&&S.session.role==="manager")render();
    return true;
  }catch(e){console.error("V6.26 dashboard migration",e);return false;}
  finally{migratingV626=false;}
}
window.migrateDashboardV626=migrateDashboardV626;
setTimeout(migrateDashboardV626,1700);

window.AUREA_PERSISTENCE_V626={
  version:"6.26",
  readBackup:readSettingsBackupV626,
  saveBackup:writeSettingsBackupV626,
  migrateDashboard:migrateDashboardV626
};
})();
