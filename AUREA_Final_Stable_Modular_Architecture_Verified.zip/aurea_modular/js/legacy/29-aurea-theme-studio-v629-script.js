
(()=>{
'use strict';
if(window.__AUREA_THEME_STUDIO_V629)return;
window.__AUREA_THEME_STUDIO_V629=true;

const TSKEY629='themeStudioV629';
const FIELDS629=[
 ['primary','Primary / brand'],['accent','Accent'],
 ['bg','Page background'],['card','Cards / surfaces'],
 ['soft','Soft surface'],['text','Primary text'],
 ['muted','Secondary text'],['line','Borders'],
 ['navBg','Menu background'],['navActive','Active menu'],
 ['buttonBg','Primary button'],['buttonText','Button text'],
 ['inputBg','Input background'],['inverseBg','Dark feature panel'],
 ['inverseText','Feature panel text']
];

function validHex629(v){return /^#[0-9a-f]{6}$/i.test(String(v||''));}
function hex629(v,fb){return validHex629(v)?String(v).toUpperCase():fb;}
function rgb629(h){h=hex629(h,'#000000').slice(1);return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16));}
function lum629(h){
  const a=rgb629(h).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});
  return .2126*a[0]+.7152*a[1]+.0722*a[2];
}
function contrast629(a,b){const x=lum629(a),y=lum629(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
function bestText629(bg){return contrast629(bg,'#FFFFFF')>=contrast629(bg,'#17120E')?'#FFFFFF':'#17120E';}
function mix629(a,b,p){
  const A=rgb629(a),B=rgb629(b),q=Math.max(0,Math.min(1,p));
  return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*q).toString(16).padStart(2,'0')).join('').toUpperCase();
}
function presetMode629(mode){
  const st=S.settings||{},pal=PALETTES[st.palette];
  let c;
  if(pal&&pal[mode]) c=pal[mode];
  else if(mode==='light') c={
    primary:st.primary||'#3E2A1E',accent:st.accent||'#B98A5C',bg:st.bg||'#F7F2EA',
    text:st.textColor||'#2B1F16',card:'#FFFFFF',sand:'#EFE6D8',line:'#E2D6C4'
  };
  else c={primary:'#D9B47F',accent:'#C9A26B',bg:'#17110C',text:'#F2E7D8',card:'#221913',sand:'#2C211A',line:'#3A2C22'};
  const primary=hex629(c.primary,'#3E2A1E'),accent=hex629(c.accent,'#B98A5C'),bg=hex629(c.bg,mode==='dark'?'#17110C':'#F7F2EA');
  const card=hex629(c.card,mode==='dark'?'#221913':'#FFFFFF'),text=hex629(c.text,mode==='dark'?'#F2E7D8':'#2B1F16');
  const soft=hex629(c.sand,mix629(card,bg,.35)),line=hex629(c.line,mix629(text,bg,.82));
  return {
    primary,accent,bg,card,soft,text,
    muted:mix629(text,bg,mode==='dark'?.38:.48),
    line,navBg:card,navActive:primary,
    buttonBg:primary,buttonText:bestText629(primary),
    inputBg:card,
    inverseBg:mode==='dark'?mix629(bg,'#000000',.24):primary,
    inverseText:bestText629(mode==='dark'?mix629(bg,'#000000',.24):primary)
  };
}
function studio629(){
  const raw=(S.settings&&S.settings[TSKEY629])||{};
  return {enabled:raw.enabled===true,light:{...presetMode629('light'),...(raw.light||{})},dark:{...presetMode629('dark'),...(raw.dark||{})}};
}
function active629(mode){
  const s=studio629(),base=presetMode629(mode);
  return s.enabled?{...base,...s[mode]}:base;
}
function ensureContrast629(c){
  const o={...c};
  if(contrast629(o.text,o.bg)<4.5)o.text=bestText629(o.bg);
  if(contrast629(o.text,o.card)<4.5)o.text=bestText629(o.card);
  if(contrast629(o.muted,o.bg)<3)o.muted=mix629(o.text,o.bg,.32);
  if(contrast629(o.muted,o.card)<3)o.muted=mix629(o.text,o.card,.34);
  if(contrast629(o.buttonText,o.buttonBg)<4.5)o.buttonText=bestText629(o.buttonBg);
  if(contrast629(o.inverseText,o.inverseBg)<4.5)o.inverseText=bestText629(o.inverseBg);
  if(contrast629(o.text,o.inputBg)<4.5)o.inputBg=o.card;
  return o;
}
function applyTheme629(){
  const st=S.settings||{};
  applyAutoDark();
  const mode=S.theme==='dark'?'dark':'light';
  let c=ensureContrast629(active629(mode));
  const light=ensureContrast629(active629('light')),dark=ensureContrast629(active629('dark'));
  const root=document.documentElement.style;
  const set=(k,v)=>root.setProperty(k,v);

  set('--theme-bg',c.bg);set('--theme-card',c.card);set('--theme-soft',c.soft);
  set('--theme-text',c.text);set('--theme-muted',c.muted);set('--theme-line',c.line);
  set('--theme-primary',c.primary);set('--theme-accent',c.accent);
  set('--theme-button-bg',c.buttonBg);set('--theme-button-text',c.buttonText);
  set('--theme-input-bg',c.inputBg);set('--theme-inverse-bg',c.inverseBg);set('--theme-inverse-text',c.inverseText);

  /* Legacy + modern aliases: every historical design layer reads the same current palette. */
  set('--bg',c.bg);set('--card',c.card);set('--surface',c.card);set('--surface-1',c.card);set('--surface-2',c.soft);
  set('--soft',c.soft);set('--sand',c.soft);set('--cream',c.bg);
  set('--ink',c.text);set('--text',c.text);set('--text-strong',c.text);set('--muted',c.muted);set('--text-soft',c.muted);
  set('--line',c.line);set('--hairline',c.line);
  set('--espresso',c.primary);set('--cacao',mix629(c.primary,c.text,.18));set('--bronze',c.accent);set('--accent',c.accent);set('--accent-strong',c.primary);
  set('--nav-bg',c.navBg);set('--nav-on',c.navActive);
  set('--bg-light',light.bg);set('--ink-light',light.text);set('--bg-dark',dark.bg);set('--ink-dark',dark.text);

  const f=FONTS[st.fontStyle]||FONTS[(PALETTES[st.palette]||{}).font]||FONTS.elegant;
  set('--font-display',f[0]);set('--font-body',f[1]);
  const br=BTN_R[st.buttonStyle]||BTN_R[(PALETTES[st.palette]||{}).btn]||BTN_R.rounded;
  set('--btn-radius',br[0]);set('--btn-radius-sm',br[1]);
  applyFontScale();
  document.documentElement.setAttribute('data-theme',mode);
  const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute('content',c.bg);
  document.title=st.name||'Entertainment';
}
window.applySettings=applySettings=applyTheme629;

function field629(mode,k,label,val){
  return `<div class="ts629-color"><label>${esc(label)}</label><input type="color" data-ts629="${mode}.${k}" value="${esc(hex629(val,'#000000'))}"></div>`;
}
function themeStudioHtml629(){
  const s=studio629(),mode=S._ts629Mode||'light';
  return `<section class="ts629">
    <div class="ts629-head"><div><h3>Theme Studio</h3><p>Edit Light and Dark Mode independently. These controls override old hard-coded colours across Guest, Entertainer and Manager screens.</p></div></div>
    <div class="ts629-mode"><button type="button" data-ts629mode="light" class="${mode==='light'?'on':''}">☀ Light mode</button><button type="button" data-ts629mode="dark" class="${mode==='dark'?'on':''}">☾ Dark mode</button></div>
    ${['light','dark'].map(m=>`<div class="ts629-panel ${mode===m?'on':''}" data-ts629panel="${m}"><div class="ts629-grid">${FIELDS629.map(([k,l])=>field629(m,k,l,s[m][k])).join('')}</div></div>`).join('')}
    <div class="ts629-health" id="ts629-health"></div>
    <div class="ts629-actions"><button type="button" class="btn ghost sm" id="ts629-autofix">Auto-fix contrast</button><button type="button" class="btn ghost sm" id="ts629-reset">Reset selected mode</button></div>
  </section>`;
}

const oldSetThemeView629=setThemeView;
window.setThemeView=setThemeView=function(){
  let html=oldSetThemeView629();
  const marker=`<label>${t("styleHead")}</label>`;
  if(html.includes(marker))html=html.replace(marker,themeStudioHtml629()+marker);
  else html=html.replace('<button class="btn" id="btn-savesettings">',themeStudioHtml629()+'<button class="btn" id="btn-savesettings">');
  return html;
};

function readPanels629(){
  const s=studio629();
  document.querySelectorAll('[data-ts629]').forEach(el=>{
    const [m,k]=String(el.dataset.ts629||'').split('.');
    if(s[m]&&k)s[m][k]=hex629(el.value,s[m][k]);
  });
  s.enabled=true;
  return s;
}
function paintHealth629(){
  const el=document.querySelector('#ts629-health');if(!el)return;
  const s=readPanels629(),m=S._ts629Mode||'light',c=s[m];
  const a=contrast629(c.text,c.bg),b=contrast629(c.text,c.card),bt=contrast629(c.buttonText,c.buttonBg),inv=contrast629(c.inverseText,c.inverseBg);
  const ok=a>=4.5&&b>=4.5&&bt>=4.5&&inv>=4.5;
  el.innerHTML=`<b>${ok?'✓ Contrast looks safe':'⚠ Contrast needs attention'}</b><br>Page ${a.toFixed(1)}:1 · Card ${b.toFixed(1)}:1 · Button ${bt.toFixed(1)}:1 · Feature panel ${inv.toFixed(1)}:1`;
}
function writePanels629(s){
  document.querySelectorAll('[data-ts629]').forEach(el=>{
    const [m,k]=String(el.dataset.ts629||'').split('.');
    if(s[m]&&s[m][k])el.value=s[m][k];
  });paintHealth629();
}

const oldWire629=window.wireCommon;
window.wireCommon=wireCommon=function(){
  oldWire629();

  if(!document.querySelector('[data-ts629]'))return;

  document.querySelectorAll('[data-ts629mode]').forEach(b=>b.onclick=()=>{
    S._ts629Mode=b.dataset.ts629mode;
    document.querySelectorAll('[data-ts629mode]').forEach(x=>x.classList.toggle('on',x.dataset.ts629mode===S._ts629Mode));
    document.querySelectorAll('[data-ts629panel]').forEach(x=>x.classList.toggle('on',x.dataset.ts629panel===S._ts629Mode));
    paintHealth629();
  });
  document.querySelectorAll('[data-ts629]').forEach(el=>el.oninput=paintHealth629);

  const af=document.querySelector('#ts629-autofix');
  if(af)af.onclick=()=>{
    const s=readPanels629(),m=S._ts629Mode||'light';
    s[m]=ensureContrast629(s[m]);writePanels629(s);toastOk('Contrast corrected');
  };
  const rs=document.querySelector('#ts629-reset');
  if(rs)rs.onclick=()=>{
    const s=readPanels629(),m=S._ts629Mode||'light';s[m]=presetMode629(m);writePanels629(s);toastOk(`${m==='dark'?'Dark':'Light'} mode reset`);
  };

  /* Replace only the Theme page save handler. Other Settings pages keep their original save logic. */
  const save=document.querySelector('#btn-savesettings');
  if(save)save.onclick=async()=>{
    if(save.disabled)return;
    save.disabled=true;
    try{
      const v=(sel,fb)=>{const el=document.querySelector(sel);return el?el.value:fb};
      const st={...S.settings};
      if(document.querySelector('#s-primary')){
        st.primary=v('#s-primary',st.primary);st.accent=v('#s-accent',st.accent);
        st.bg=v('#s-bg',st.bg);st.textColor=v('#s-text',st.textColor);
        st.navBg=v('#s-navbg',st.navBg);st.navActive=v('#s-navon',st.navActive);
      }
      if(document.querySelector('#s-font'))st.fontStyle=v('#s-font',st.fontStyle);
      if(document.querySelector('#s-btn'))st.buttonStyle=v('#s-btn',st.buttonStyle);
      if(document.querySelector('#s-fs'))st.fontScale=v('#s-fs',st.fontScale);
      if(document.querySelector('#s-autodark'))st.autoDark=document.querySelector('#s-autodark').checked;
      st[TSKEY629]=readPanels629();
      await DB.saveSettings(st);
      applyTheme629();toastOk(t('saved'));render();
    }catch(e){console.error('Theme Studio save',e);toastErr(t('errSave'));save.disabled=false;}
  };
  paintHealth629();
};

/* Ensure the corrected theme is active after boot and after the first data load. */
setTimeout(()=>{try{applyTheme629();if(typeof safeToRender==='function'&&safeToRender())render();}catch(e){console.error('V6.29 theme apply',e)}},750);

window.AUREA_THEME_STUDIO_V629={
  version:'6.29',studio:studio629,active:active629,contrast:contrast629,
  ensureContrast:ensureContrast629,apply:applyTheme629,preset:presetMode629
};
})();
