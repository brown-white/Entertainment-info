
(()=>{
'use strict';
if(window.__AUREA_EXPERIENCE_V638)return;
window.__AUREA_EXPERIENCE_V638=true;

function loginView638(){
  const st=S.settings||{};
  const logo=st.logo?`<img src="${esc(st.logo)}" alt="">`:esc(String(st.name||'E').trim().charAt(0).toUpperCase());
  const languages=`<div class="login638-langs">${LANGS.map(([l,label])=>`<button type="button" data-lang="${l}" class="${S.lang===l?'on':''}">${label}</button>`).join('')}</div>`;

  if(loginMode==='guest'){
    const remRow=`<label class="remrow"><input type="checkbox" id="cb-rem" ${rememberMe?'checked':''}> ${t('rememberMe')}</label>`;
    const dots=`<div class="wz-dots">${[0,1,2,3,4,5,6].map(i=>`<span class="wz-dot ${wiz.step===i?'on':wiz.step>i?'done':''}"></span>`).join('')}</div>`;
    const backLink=wiz.step>0?`<button class="wz-back" id="wz-back">${ic('back',14)} ${t('backStep')}</button>`:'';
    let stepHtml='';
    if(wiz.step===0) stepHtml=`<label>${t('room')}</label><button class="pickfield" id="wz-pick">${wiz.room?`<b>${esc(wiz.room)}</b>`:t('chooseRoom')}<span class="pf-ch">${ic('back',16)}</span></button>`;
    else if(wiz.step===1) stepHtml=`<label>${t('nationality')}</label><button class="pickfield" id="wz-pick">${wiz.nat?`<b>${esc(wiz.nat)}</b>`:t('chooseNat')}<span class="pf-ch">${ic('back',16)}</span></button>`;
    else if(wiz.step===2) stepHtml=`<label>${t('name')}</label><input id="wz-in" value="${esc(wiz.name)}" placeholder="${t('name')}">`;
    else if(wiz.step===3) stepHtml=`<label>${t('phone')}</label><input id="wz-in" inputmode="tel" value="${esc(wiz.phone)}" placeholder="+49 ...">`;
    else if(wiz.step===4) stepHtml=`<label>${t('arrival')}</label><input id="wz-in" type="date" value="${esc(wiz.arr)}">`;
    else if(wiz.step===5) stepHtml=`<label>${t('departure')}</label><input id="wz-in" type="date" value="${esc(wiz.dep)}" min="${esc(wiz.arr)}">`;
    else stepHtml=`<label>${t('user')}</label><input id="wz-user" autocapitalize="none" value="${esc(wiz.username||wiz.room)}"><label>${t('pass')}</label><input id="wz-pass" autocapitalize="none" value="${esc(wiz.password)}" placeholder="••••••">${remRow}`;
    const fields=guestMode==='new'
      ?`${dots}${stepHtml}${wiz.step<6?`<button class="btn" id="wz-next">${t('nextStep')}</button>`:`<button class="btn" id="wz-create">${t('createAccount')}</button>`}${backLink}`
      :`<label>${t('user')} · ${t('room')}</label><input id="f-room" inputmode="numeric" value="${esc(wiz.room)}" placeholder="4215"><label>${t('pass')}</label><input id="f-gpass" type="password" placeholder="••••••">${remRow}`;

    return `<div class="login-wrap login638 fadein"><div class="login638-shell">
      <div class="login638-top">
        <div class="login638-brand"><div class="login638-mark">${logo}</div><div class="login638-brandtxt"><b>${esc(st.name||'Entertainment')}</b><span>${esc(st.subtitle||t('appSub'))}</span></div></div>
        <button type="button" class="login638-teamtop" id="btn-teamlink">${ic('users',14)} ${t('otherUsers')}</button>
      </div>
      <section class="login638-copy"><div class="ey">Your hotel entertainment</div><h1>${guestMode==='new'?'Create your holiday access.':'Welcome to your stay.'}</h1><p>${guestMode==='new'?'Set up your private guest access in a few simple steps. Your stay, bookings and messages remain connected only to you.':'Sign in for the complete programme, bookings, tickets, chat and everything connected to your stay.'}</p></section>
      ${languages}
      <div class="login638-tabs"><button data-gmode="signin" class="${guestMode==='signin'?'on':''}">${t('signin')}</button><button data-gmode="new" class="${guestMode==='new'?'on':''}">${t('firstVisit')}</button></div>
      <div class="login638-card">${fields}${guestMode==='signin'?`<button class="btn" id="btn-login">${t('signin')}</button>`:''}<div class="err" id="login-err"></div>${!REMOTE?`<p class="hint">${t('demoNote')}</p>`:''}</div>
      <button type="button" class="login638-explore" id="btn-public-explore"><span class="ico">${ic('sparkle',18)}</span><span class="txt"><b>Explore the entertainment</b><small>See a curated programme preview before signing in</small></span><span class="go">${ic('back',17)}</span></button>
      <div class="login638-trust">Public Explore never shows room, booking, ticket, message or guest-account information.</div>
    </div></div>`;
  }

  return `<div class="login-wrap login638 fadein"><div class="login638-shell">
    <div class="login638-top"><div class="login638-brand"><div class="login638-mark">${logo}</div><div class="login638-brandtxt"><b>${esc(st.name||'Entertainment')}</b><span>${esc(st.subtitle||t('appSub'))}</span></div></div><button type="button" class="login638-teamtop" id="btn-guestlink">${ic('back',13)} ${t('backToGuest')}</button></div>
    <section class="login638-copy"><div class="ey">Team workspace</div><h1>Run the day with clarity.</h1><p>Secure access for the Entertainment Team and Manager.</p></section>
    ${languages}
    <div class="login638-tabs">${['staff','manager'].map(r=>`<button data-role="${r}" class="${loginRole===r?'on':''}">${t(r)}</button>`).join('')}</div>
    <div class="login638-card"><label>${t('user')}</label><input id="f-user" autocapitalize="none" placeholder="${loginRole}"><label>${t('pass')}</label><input id="f-pass" type="password" placeholder="••••"><button class="btn" id="btn-login">${t('signin')}</button><div class="err" id="login-err"></div></div>
    <button type="button" class="login638-explore" id="btn-public-explore"><span class="ico">${ic('sparkle',18)}</span><span class="txt"><b>Open public Explore</b><small>Preview exactly what visitors can see without an account</small></span><span class="go">${ic('back',17)}</span></button>
  </div></div>`;
}
window.loginView=loginView638;
try{loginView=loginView638;}catch(e){}

function vxCard638(a,event=false){
  const api=window.AUREA_PUBLIC_EXPLORE_V637||{};
  const img=typeof api.image==='function'?api.image(a):(a&&a.image)||'';
  const type=typeof api.type==='function'?api.type(a):'Entertainment';
  return `<button type="button" class="vx638-card ${event?'event':''}" data-vx637-id="${esc(String(a.id))}"><div class="vx638-img"><img src="${esc(img)}" alt="" loading="lazy"><span class="vx638-type">${esc(type)}</span></div><div class="vx638-body"><h4>${esc(a.name||'')}</h4><p>${esc(a.time||'')}${a.location?' · '+esc(a.location):''}</p></div></button>`;
}
function visitorExploreView638(){
  const day=Number.isInteger(window.__PUBLIC_EXPLORE_DAY_V637)?window.__PUBLIC_EXPLORE_DAY_V637:todayIndex();
  const api=window.AUREA_PUBLIC_EXPLORE_V637||{};
  const acts=typeof api.dayData==='function'?api.dayData(day):[],normal=acts.filter(a=>normCat(a)==='mAdult').slice(0,4),special=acts.filter(a=>normCat(a)!=='mAdult').slice(0,4);
  const hero=acts.find(a=>a.highlight)||special[0]||normal[0]||acts[0]||null;
  const dd=typeof api.dayDesign==='function'?api.dayDesign(day):{identity:'',theme:''},days=t('days')||['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const shorts=t('daysShort')||['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],weekday=days[day]||'';
  const st=S.settings||{};
  const moments=acts.slice(0,3);
  return `<main class="vx638 fadein"><div class="vx638-shell">
    <header class="vx638-top"><div class="vx638-brand"><div class="vx638-logo">${st.logo?`<img src="${esc(st.logo)}" alt="">`:esc(String(st.name||'E').trim().charAt(0).toUpperCase())}</div><div><b>${esc(st.name||'Entertainment')}</b><span>Public programme preview</span></div></div><button type="button" class="vx638-sign" id="vx637-signin-top">Sign in</button></header>
    <section class="vx638-intro"><div class="ey">Discover your holiday</div><h1>Find your next moment.</h1><p>A curated look at what is happening around the hotel. Sign in to unlock the full programme and your personal guest experience.</p></section>
    <nav class="vx638-days" aria-label="Programme days">${shorts.map((d,i)=>`<button type="button" class="vx638-day ${i===day?'on':''}" data-vx637-day="${i}">${esc(d)}</button>`).join('')}</nav>
    <section class="vx638-identity"><div><small>${esc(weekday)} identity</small><b>${esc(dd.identity||weekday)}</b></div>${dd.theme?`<div class="vx638-rest">Restaurant theme<strong>${esc(dd.theme)}</strong></div>`:'<div></div>'}</section>
    ${hero?`<button type="button" class="vx638-feature" data-vx637-id="${esc(String(hero.id))}"><img src="${esc(typeof api.image==='function'?api.image(hero):(hero.image||''))}" alt="" loading="eager"><span class="veil"></span><div class="content"><span class="badge">${esc(hero.highlight?'Highlight of the day':(typeof api.type==='function'?api.type(hero):'Entertainment'))}</span><h2>${esc(hero.name||'')}</h2><div class="meta"><span>${ic('clock',13)} ${esc(hero.time||'')}</span>${hero.location?`<span>${ic('pin',13)} ${esc(hero.location)}</span>`:''}</div></div></button>`:`<div class="vx638-feature empty"><div class="content"><span class="badge">Programme preview</span><h2>${esc(weekday)}</h2><p>The public programme for this day is still being prepared. Choose another day or sign in for your complete stay experience.</p></div></div>`}
    ${moments.length?`<div class="vx638-now">${moments.map(a=>`<div class="vx638-moment"><span>${esc(typeof api.type==='function'?api.type(a):'Entertainment')}</span><b>${esc(a.name||'')}</b><em>${esc(a.time||'')}</em></div>`).join('')}</div>`:''}
    <section class="vx638-section"><div class="vx638-head"><div><small>Move & play</small><h3>Activities</h3></div><span>${normal.length} preview${normal.length===1?'':'s'}</span></div>${normal.length?`<div class="vx638-scroll">${normal.map(a=>vxCard638(a)).join('')}</div>`:`<div class="vx638-empty">No daytime activity preview is published for ${esc(weekday)} yet.</div>`}</section>
    <section class="vx638-section"><div class="vx638-head"><div><small>After-hours moments</small><h3>Events & entertainment</h3></div><span>${special.length} preview${special.length===1?'':'s'}</span></div>${special.length?`<div class="vx638-scroll">${special.map(a=>vxCard638(a,true)).join('')}</div>`:`<div class="vx638-empty">No event, live music or show preview is published for ${esc(weekday)} yet.</div>`}</section>
    <section class="vx638-unlock"><div class="ey">Your private guest account</div><h3>Unlock the whole holiday.</h3><p>Explore is intentionally only a preview. Your guest account opens everything connected to your actual stay.</p><div class="vx638-perks"><span>✓ Full weekly programme</span><span>✓ Activity booking</span><span>✓ Event tickets</span><span>✓ Chat with the team</span><span>✓ My bookings</span><span>✓ Personal stay</span></div><button type="button" id="vx637-signin">Sign in / First visit</button></section>
    <div class="vx638-privacy">Public Explore uses programme information only. Private guest, room, booking, ticket and message data never appears here.</div>
  </div></main>`;
}
window.visitorExploreView637=visitorExploreView638;
window.AUREA_EXPERIENCE_V638={version:'6.38',login:loginView638,explore:visitorExploreView638};
})();
