
(function(){
  var baseActivityCard = activityCard;
  var baseOperationCard = operationCard;
  var baseCategoryCard = categoryCard;
  function guestProgrammeType(a){
    var c=normCat(a||{});
    if(c==="mAdult") return "activity";
    if(c==="mEvents") return "event";
    if(c==="eLive") return "live";
    if(c==="eShow") return "show";
    if(c==="eParty") return "party";
    return "evening";
  }
  activityCard=function(a,opts){
    opts=opts||{};
    var html=baseActivityCard(a,opts);
    if(opts.manager||opts.staff) return html;
    var type=guestProgrammeType(a);
    return html.replace('class="card act guest-act','class="card act guest-act guest-prog-card gp-'+type);
  };
  operationCard=function(op){
    var html=baseOperationCard(op);
    return html.replace('class="opcard"','class="opcard guest-opcard go-'+String(op&&op.id||'daytime')+'"');
  };
  categoryCard=function(cat){
    var html=baseCategoryCard(cat), type=guestProgrammeType({category:cat});
    return html.replace('class="catcard ','class="catcard guest-catcard gc-'+type+' ');
  };
})();
