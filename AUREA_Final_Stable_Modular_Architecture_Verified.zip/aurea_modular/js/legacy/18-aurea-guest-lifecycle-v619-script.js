
(()=>{
'use strict';
if(window.__AUREA_GUEST_LIFECYCLE_V619) return;
window.__AUREA_GUEST_LIFECYCLE_V619=true;

const DATA_ARRAYS619=['bookings','orders','requests','messages'];
const ARCHIVE_KEY619='guestStayArchive';

const norm619=v=>String(v??'').trim().toLowerCase().replace(/\s+/g,' ');
const date619=v=>String(v||'').slice(0,10);
function currentAccounts619(){return (S.accounts||[]).filter(a=>a&&a.active!==false&&!stayExpired(a));}
function currentAccountForRoom619(room){
  const r=visibleRoom619(room);
  return currentAccounts619().find(a=>String(a.room)===String(r))||null;
}
function stayToken619(acc){
  if(!acc)return'';
  const id=String(acc.id??'x').replace(/[^A-Za-z0-9_-]/g,'');
  const ar=date619(acc.arrival).replace(/-/g,'')||'na';
  const room=String(acc.room||'').replace(/[^A-Za-z0-9_-]/g,'');
  return 'g$'+id+'$'+ar+'$'+room;
}
function visibleRoom619(room){
  const s=String(room||'');
  if(!s.startsWith('g$'))return s;
  const p=s.split('$');return p.length>=4?p.slice(3).join('$'):s;
}
function accountFromChannel619(room){
  const s=String(room||'');if(!s.startsWith('g$'))return null;
  const p=s.split('$');if(p.length<4)return null;
  const id=p[1],arr=p[2];
  return (S.accounts||[]).find(a=>String(a.id)===id&&date619(a.arrival).replace(/-/g,'')===arr)||null;
}
function rowTime619(row){
  for(const k of ['created_at','booked_at','updated_at']){
    const v=row&&row[k];if(v){const ms=Date.parse(v);if(Number.isFinite(ms))return ms;}
  }
  return NaN;
}
function withinStay619(row,acc){
  if(!acc)return false;
  const st=date619(acc.arrival),en=date619(acc.departure);
  const ms=rowTime619(row);
  if(Number.isFinite(ms)&&st&&en){
    const d=new Date(ms),key=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
    if(key<st||key>en)return false;
  }
  const gn=norm619(row&&(row.guest_name||row.who_name));
  if(gn&&norm619(acc.name)&&gn!==norm619(acc.name))return false;
  return true;
}
function rowBelongs619(row,acc,field='room'){
  if(!row||!acc)return false;
  const val=String(row[field]??'');
  const tok=stayToken619(acc);
  if(val===tok)return true;
  if(visibleRoom619(val)!==String(acc.room))return false;
  if(val.startsWith('g$'))return false;
  return withinStay619(row,acc);
}
function archiveList619(){return Array.isArray(S.settings&&S.settings[ARCHIVE_KEY619])?S.settings[ARCHIVE_KEY619].slice():[];}
function archiveId619(acc){return [String(acc.id??''),date619(acc.arrival),date619(acc.departure),String(acc.room||'')].join('|');}
function snapshot619(acc){
  return {archiveId:archiveId619(acc),accountId:acc.id,room:String(acc.room||''),name:String(acc.name||''),phone:String(acc.phone||''),nationality:String(acc.nationality||''),username:String(acc.username||''),arrival:date619(acc.arrival),departure:date619(acc.departure),active:false,stayToken:stayToken619(acc),archivedAt:new Date().toISOString()};
}
async function saveArchive619(list){
  const next={...S.settings,[ARCHIVE_KEY619]:list};
  await DB.saveSettings(next);S.settings=next;return list;
}
async function ensureArchived619(acc){
  if(!acc)return null;
  const list=archiveList619(),id=archiveId619(acc);
  const old=list.find(x=>x.archiveId===id);if(old)return old;
  const snap=snapshot619(acc);list.unshift(snap);await saveArchive619(list);return snap;
}
let sweepRunning619=false;
async function lifecycleSweep619(){
  if(sweepRunning619)return false;sweepRunning619=true;
  let changed=false;
  try{
    const ended=(S.accounts||[]).filter(a=>a&&(stayExpired(a)||a.active===false));
    for(const acc of ended){
      const before=archiveList619().length;
      await ensureArchived619(acc);
      if(archiveList619().length!==before)changed=true;
      if(stayExpired(acc)&&acc.active!==false){
        await DB.updateAccount(acc.id,{active:false});
        changed=true;
      }
    }
  }catch(e){console.error('guest lifecycle sweep',e);}
  finally{sweepRunning619=false;}
  return changed;
}

/* Reuse a room safely: archive the previous stay, then recycle the one room-account row.
   This remains compatible with databases where guest_accounts.room is unique. */
const baseAddAccount619=DB.addAccount.bind(DB);
DB.addAccount=async function(acc){
  const prev=(S.accounts||[]).find(a=>String(a.room)===String(acc&&acc.room));
  if(prev&&(prev.active===false||stayExpired(prev))){
    await ensureArchived619(prev);
    try{localStorage.removeItem('aurea_guest_photo_'+String(prev.id));}catch(e){}
    const patch={...acc,active:true};
    await DB.updateAccount(prev.id,patch);
    return (S.accounts||[]).find(a=>a.id===prev.id)||{...prev,...patch};
  }
  return baseAddAccount619({...acc,active:acc&&acc.active!==false});
};

/* Local guest preferences are stay-specific too. This prevents a reused hotel
   phone/tablet from carrying the previous guest's favourites into a new stay. */
function localStayKey619(acc){
  return acc ? 'aurea_guest_local_'+String(acc.id)+'_'+date619(acc.arrival).replace(/-/g,'')+'_'+date619(acc.departure).replace(/-/g,'') : '';
}
function loadStayLocal619(acc){
  const k=localStayKey619(acc);if(!k)return;
  try{const d=JSON.parse(localStorage.getItem(k)||'{}');S.favorites=Array.isArray(d.favorites)?d.favorites:[];}catch(e){S.favorites=[];}
}
function saveStayLocal619(){
  const a=guestAcc619&&guestAcc619();if(!a)return;
  try{localStorage.setItem(localStayKey619(a),JSON.stringify({favorites:Array.isArray(S.favorites)?S.favorites:[]}));}catch(e){}
}
const basePersist619=persist;
persist=function(){if(S.session&&S.session.role==='guest')saveStayLocal619();return basePersist619();};
const baseStartGuest619=startGuestSession;
startGuestSession=function(acc){loadStayLocal619(acc);return baseStartGuest619(acc);};
if(S.session&&S.session.role==='guest'){
  const a0=(S.accounts||[]).find(a=>a.id===S.session.accountId);
  if(a0)loadStayLocal619(a0);
}

/* Every new guest-origin write gets the stay-specific channel automatically.
   No database schema change is required. */
function guestAcc619(){if(!(S.session&&S.session.role==='guest'))return null;return (S.accounts||[]).find(a=>a.id===S.session.accountId)||null;}
function guestChannel619(){const a=guestAcc619();return a?stayToken619(a):String(S.session&&S.session.room||'');}
for(const name of ['addBooking','addOrder','addRequest','addMessage','addFeedback']){
  if(typeof DB[name]!=='function')continue;
  const old=DB[name].bind(DB);
  DB[name]=async function(row,...rest){
    if(S.session&&S.session.role==='guest'&&row&&typeof row==='object'){
      row={...row,room:guestChannel619()};
    }else if(name==='addMessage'&&S.session&&S.session.role==='manager'&&row&&row.room&&!isStaffRoom(row.room)){
      const a=currentAccountForRoom619(row.room);if(a)row={...row,room:stayToken619(a)};
    }
    return old(row,...rest);
  };
}
if(typeof DB.addQuizReply==='function'){
  const old=DB.addQuizReply.bind(DB);
  DB.addQuizReply=async function(row,...rest){
    if(S.session&&S.session.role==='guest'&&row&&typeof row==='object')row={...row,who:guestChannel619()};
    return old(row,...rest);
  };
}

/* Read receipts must target only the current stay, never every historical chat from that room. */
if(typeof DB.markRead==='function'){
  const old=DB.markRead.bind(DB);
  DB.markRead=async function(room,side){
    if(!isStaffRoom(room)){
      const a=(S.session&&S.session.role==='guest')?guestAcc619():currentAccountForRoom619(room);
      if(a){
        const flag=side==='team'?'read_by_team':'read_by_guest',sender=side==='team'?'guest':'team';
        const rows=(S.messages||[]).filter(m=>rowBelongs619(m,a,'room')&&m.sender===sender&&!m[flag]);
        for(const m of rows){
          if(REMOTE)await sb('messages?id=eq.'+encodeURIComponent(m.id),{method:'PATCH',body:JSON.stringify({[flag]:true})});
          m[flag]=true;
        }
        return;
      }
    }
    return old(room,side);
  };
}

/* Current operational data only. Historical stays remain in state/database but do not
   affect today's capacities, ticket sales, badges or a replacement guest. */
function currentRows619(arr,field='room'){
  const accounts=currentAccounts619();
  return (arr||[]).filter(row=>accounts.some(a=>rowBelongs619(row,a,field)));
}
function mappedRows619(arr,field='room'){
  return currentRows619(arr,field).map(row=>{
    const a=currentAccounts619().find(x=>rowBelongs619(row,x,field));
    return a?{...row,[field]:String(a.room)}:{...row};
  });
}
function withOperational619(fn){
  const save={bookings:S.bookings,orders:S.orders,requests:S.requests,messages:S.messages};
  try{
    S.bookings=mappedRows619(save.bookings);
    S.orders=mappedRows619(save.orders);
    S.requests=mappedRows619(save.requests);
    const staff=(save.messages||[]).filter(m=>isStaffRoom(m.room));
    S.messages=staff.concat(mappedRows619((save.messages||[]).filter(m=>!isStaffRoom(m.room))));
    return fn();
  }finally{Object.assign(S,save);}
}
function withCurrentGuest619(fn){
  const a=guestAcc619();if(!a)return fn();
  const save={bookings:S.bookings,orders:S.orders,requests:S.requests,messages:S.messages,quizReplies:S.quizReplies};
  try{
    S.bookings=(save.bookings||[]).filter(x=>rowBelongs619(x,a)).map(x=>({...x,room:String(a.room)}));
    S.orders=(save.orders||[]).filter(x=>rowBelongs619(x,a)).map(x=>({...x,room:String(a.room)}));
    S.requests=(save.requests||[]).filter(x=>rowBelongs619(x,a)).map(x=>({...x,room:String(a.room)}));
    S.messages=(save.messages||[]).filter(x=>rowBelongs619(x,a)).map(x=>({...x,room:String(a.room)}));
    S.quizReplies=(save.quizReplies||[]).filter(x=>rowBelongs619(x,a,'who')).map(x=>({...x,who:String(a.room)}));
    return fn();
  }finally{Object.assign(S,save);}
}

const baseGuestView619=guestView;
guestView=function(){
  if(S.session&&S.session.role==='guest'){
    const a=guestAcc619(),k=localStayKey619(a);
    if(a&&S.__v619LocalLoaded!==k){loadStayLocal619(a);S.__v619LocalLoaded=k;}
    return withCurrentGuest619(()=>baseGuestView619());
  }
  return baseGuestView619();
};
const baseManagerView619=managerView;
managerView=function(){
  if(S.tab==='guests'&&S.sub.guests==='history')return baseManagerView619();
  return withOperational619(()=>baseManagerView619());
};
const baseStaffView619=staffView;
staffView=function(){return withOperational619(()=>baseStaffView619());};

const baseBookingsFor619=bookingsFor;
bookingsFor=function(actId){return currentRows619(S.bookings).filter(b=>String(b.activity_id)===String(actId));};
myBooking=function(actId){
  const a=guestAcc619();if(!a)return null;
  return (S.bookings||[]).find(b=>String(b.activity_id)===String(actId)&&rowBelongs619(b,a));
};
ordersFor=function(tkId){return currentRows619(S.orders).filter(o=>String(o.ticket_id)===String(tkId));};
myOrders=function(){const a=guestAcc619();return a?(S.orders||[]).filter(o=>rowBelongs619(o,a)):[];};
myRequestsList=function(){const a=guestAcc619();return a?(S.requests||[]).filter(r=>rowBelongs619(r,a)):[];};
accountName=function(room){const a=currentAccountForRoom619(room)||accountFromChannel619(room);return a?a.name:visibleRoom619(room);};
guestForRoom=function(room){return currentAccountForRoom619(room);};
accountForRoom=function(room){return currentAccountForRoom619(room);};
guestActivities=function(room){
  const a=currentAccountForRoom619(room);if(!a)return[];
  return (S.bookings||[]).filter(b=>rowBelongs619(b,a)).map(b=>{const x=S.activities.find(z=>z.id===b.activity_id);return x?x.name:null;}).filter(Boolean);
};
guestRecord=function(acc){
  const bookings=(S.bookings||[]).filter(b=>rowBelongs619(b,acc)),actIds=bookings.map(b=>b.activity_id);
  const acts=(S.activities||[]).filter(a=>actIds.includes(a.id));
  const orders=(S.orders||[]).filter(o=>rowBelongs619(o,acc)),reqs=(S.requests||[]).filter(r=>rowBelongs619(r,acc));
  const fb=(S.feedback||[]).filter(f=>rowBelongs619(f,acc)),msgs=(S.messages||[]).filter(m=>rowBelongs619(m,acc));
  const quiz=(S.quizReplies||[]).filter(q=>rowBelongs619(q,acc,'who'));
  const byCat={};acts.forEach(a=>{const k=catLabel(normCat(a));byCat[k]=(byCat[k]||0)+1;});
  const favs=Object.keys(byCat).sort((x,y)=>byCat[y]-byCat[x]).slice(0,3),avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  return{acc,bookings,acts,orders,reqs,fb,msgs,quiz,favs,avg,nights:guestStayNights(acc),daysApp:guestDaysInApp(acc)};
};
guestFullInfo=function(room){
  const acc=currentAccountForRoom619(room);if(!acc)return null;const r=guestRecord(acc);
  return{room:acc.room,name:acc.name,username:acc.username||acc.room,phone:acc.phone||'',nationality:acc.nationality||'',arrival:acc.arrival||'',departure:acc.departure||'',days:guestDaysHere(acc),activities:r.acts.map(a=>a.name),tickets:r.orders.reduce((n,o)=>n+(+o.qty||0),0),requests:r.reqs.length};
};
const oldUnreadFor619=unreadFor;
unreadFor=function(role){
  if(role==='guest'){
    const a=guestAcc619();return a?(S.messages||[]).filter(m=>rowBelongs619(m,a)&&m.sender==='team'&&!m.read_by_guest).length:0;
  }
  return oldUnreadFor619(role);
};
unreadGuests=function(){
  return currentRows619((S.messages||[]).filter(m=>!isStaffRoom(m.room))).filter(m=>m.sender==='guest'&&!m.read_by_team).length;
};

/* History / retention centre */
function archiveAcc619(x){return{id:x.accountId,room:x.room,name:x.name,phone:x.phone,nationality:x.nationality,username:x.username,arrival:x.arrival,departure:x.departure,active:false};}
function historyRowsFor619(snap,kind){
  const a=archiveAcc619(snap);
  if(kind==='bookings')return(S.bookings||[]).filter(x=>rowBelongs619(x,a));
  if(kind==='orders')return(S.orders||[]).filter(x=>rowBelongs619(x,a));
  if(kind==='messages')return(S.messages||[]).filter(x=>rowBelongs619(x,a));
  if(kind==='requests')return(S.requests||[]).filter(x=>rowBelongs619(x,a));
  if(kind==='feedback')return(S.feedback||[]).filter(x=>rowBelongs619(x,a));
  if(kind==='quiz')return(S.quizReplies||[]).filter(x=>rowBelongs619(x,a,'who'));
  return[];
}
function historyCount619(s){return['bookings','orders','messages','requests','feedback','quiz'].reduce((n,k)=>n+historyRowsFor619(s,k).length,0);}
function historyFiltered619(){
  const from=(S.gh619From||''),to=(S.gh619To||'');
  return archiveList619().filter(s=>{const d=date619(s.departure)||date619(s.archivedAt);return(!from||d>=from)&&(!to||d<=to);});
}
function guestHistoryInnerV619(){
  const list=historyFiltered619(),active=currentAccounts619(),all=archiveList619();
  return `<div class="gh619-hero"><div class="k">Guest lifecycle & privacy</div><h3>One stay. One private account.</h3><p>Guest access ends automatically after departure. A future guest using the same room receives a clean stay with no previous bookings, messages, tickets or requests. Historical records are kept for management until you choose to delete them.</p></div>
    <div class="gh619-stats"><div class="gh619-stat"><b>${active.length}</b><span>Active stays</span></div><div class="gh619-stat"><b>${all.length}</b><span>Archived stays</span></div><div class="gh619-stat"><b>${all.reduce((n,s)=>n+historyCount619(s),0)}</b><span>Historical records</span></div></div>
    <div class="gh619-filter"><label>Filter departed stays</label><div class="row"><div><label>From</label><input type="date" id="gh619-from" value="${esc(S.gh619From||'')}"></div><div><label>To</label><input type="date" id="gh619-to" value="${esc(S.gh619To||'')}"></div></div><div class="gh619-filter-actions"><button class="btn ghost sm" id="gh619-apply">Apply dates</button><button class="btn ghost sm" id="gh619-clear">Clear dates</button></div></div>
    <div class="gh619-list">${list.length?list.map(s=>`<label class="gh619-row"><input type="checkbox" data-gh619-stay="${esc(s.archiveId)}"><span><b>${esc(s.name||'Guest')} · Room ${esc(s.room)}</b><p>${esc(s.arrival||'—')} → ${esc(s.departure||'—')} · ${historyCount619(s)} saved records${s.nationality?' · '+esc(s.nationality):''}</p></span><span class="gh619-tag">Archived</span></label>`).join(''):`<div class="gh619-empty">No departed guest stays match this date range.</div>`}</div>
    <div class="gh619-danger"><h4>Data retention controls</h4><p>Nothing is deleted automatically. Choose the departed stays and exactly which information you want to remove. Active guests are never included here.</p>
      <div class="gh619-cats">
        <label><input type="checkbox" data-gh619-cat="bookings" checked> Bookings / activities</label>
        <label><input type="checkbox" data-gh619-cat="orders" checked> Ticket orders</label>
        <label><input type="checkbox" data-gh619-cat="messages" checked> Messages</label>
        <label><input type="checkbox" data-gh619-cat="requests" checked> Guest requests</label>
        <label><input type="checkbox" data-gh619-cat="feedback" checked> Feedback</label>
        <label><input type="checkbox" data-gh619-cat="quiz" checked> Quiz answers</label>
        <label><input type="checkbox" data-gh619-cat="profile"> Archived guest profile</label>
      </div>
      <button class="btn warn" id="gh619-delete-selected">Delete selected data</button>
      <button class="btn ghost warn" id="gh619-delete-all">Delete ALL data in this date range</button>
    </div>`;
}

window.guestHistoryInnerV619=guestHistoryInnerV619;

async function deleteHistory619(stays,cats){
  const unique=(arr)=>[...new Set(arr.map(x=>x.id).filter(x=>x!=null))];
  const jobs=[];
  if(cats.includes('bookings'))for(const id of unique(stays.flatMap(s=>historyRowsFor619(s,'bookings'))))jobs.push(()=>DB.deleteBooking(id));
  if(cats.includes('orders'))for(const id of unique(stays.flatMap(s=>historyRowsFor619(s,'orders'))))jobs.push(()=>DB.deleteOrder(id));
  if(cats.includes('messages'))for(const id of unique(stays.flatMap(s=>historyRowsFor619(s,'messages'))))jobs.push(()=>DB.deleteMessage(id));
  if(cats.includes('requests'))for(const id of unique(stays.flatMap(s=>historyRowsFor619(s,'requests'))))jobs.push(()=>DB.deleteRequest(id));
  if(cats.includes('feedback'))for(const id of unique(stays.flatMap(s=>historyRowsFor619(s,'feedback'))))jobs.push(()=>DB.deleteFeedback(id));
  if(cats.includes('quiz')){
    const ids=unique(stays.flatMap(s=>historyRowsFor619(s,'quiz')));
    for(const id of ids)jobs.push(async()=>{if(REMOTE)await sb('quiz_replies?id=eq.'+encodeURIComponent(id),{method:'DELETE'});S.quizReplies=(S.quizReplies||[]).filter(x=>x.id!==id);});
  }
  for(const job of jobs)await job();
  if(cats.includes('profile')){
    const remove=new Set(stays.map(s=>s.archiveId));
    await saveArchive619(archiveList619().filter(s=>!remove.has(s.archiveId)));
    for(const s of stays){
      const cur=(S.accounts||[]).find(a=>a.id===s.accountId&&date619(a.arrival)===date619(s.arrival)&&date619(a.departure)===date619(s.departure));
      if(cur&&cur.active===false){
        if(REMOTE)await sb('guest_accounts?id=eq.'+encodeURIComponent(cur.id),{method:'DELETE'});
        S.accounts=S.accounts.filter(a=>a.id!==cur.id);
      }
    }
  }
}
function selectedStays619(){
  const ids=[...document.querySelectorAll('[data-gh619-stay]:checked')].map(x=>x.dataset.gh619Stay);
  const map=new Map(archiveList619().map(s=>[s.archiveId,s]));return ids.map(id=>map.get(id)).filter(Boolean);
}
function selectedCats619(){return[...document.querySelectorAll('[data-gh619-cat]:checked')].map(x=>x.dataset.gh619Cat);}

/* Run lifecycle after the first asynchronous boot load, and after future refreshes. */
setTimeout(()=>lifecycleSweep619().then(c=>{if(c&&S.session&&safeToRender())render();}),500);
const basePoll619=DB.poll.bind(DB);
DB.poll=async function(){const c=await basePoll619();const l=await lifecycleSweep619();return c||l;};

/* Fix manager chat actions after the normal render restores the full historical arrays. */
const oldWire619=wireCommon;
wireCommon=function(){
  oldWire619();

  if(S.session&&S.session.role==='manager'&&S.tab==='guests'&&S.sub.guests==='history'){
    const from=document.querySelector('#gh619-from'),to=document.querySelector('#gh619-to');
    const apply=document.querySelector('#gh619-apply');if(apply)apply.onclick=()=>{S.gh619From=from?from.value:'';S.gh619To=to?to.value:'';render();};
    const clear=document.querySelector('#gh619-clear');if(clear)clear.onclick=()=>{S.gh619From='';S.gh619To='';render();};
    const delSel=document.querySelector('#gh619-delete-selected');if(delSel)delSel.onclick=async()=>{
      const stays=selectedStays619(),cats=selectedCats619();if(!stays.length){toastWarn('Select at least one departed stay.');return;}if(!cats.length){toastWarn('Select the data you want to delete.');return;}
      if(!await confirmAction({question:'Delete selected historical guest data?',detail:`${stays.length} departed stay(s). This cannot be undone.`,confirmLabel:'Delete data',danger:true}))return;
      delSel.disabled=true;try{await deleteHistory619(stays,cats);toastOk('Historical guest data updated');render();}catch(e){console.error(e);delSel.disabled=false;toastErr(t('errSave'));}};
    const delAll=document.querySelector('#gh619-delete-all');if(delAll)delAll.onclick=async()=>{
      const stays=historyFiltered619();if(!stays.length){toastWarn('No departed stays in this date range.');return;}
      const cats=['bookings','orders','messages','requests','feedback','quiz','profile'];
      if(!await confirmAction({question:'Delete ALL historical guest data in this date range?',detail:`${stays.length} departed stay(s), including archived profiles. This cannot be undone.`,confirmLabel:'Delete all',danger:true}))return;
      delAll.disabled=true;try{await deleteHistory619(stays,cats);toastOk('Historical guest data deleted');render();}catch(e){console.error(e);delAll.disabled=false;toastErr(t('errSave'));}};
  }

  if(S.session&&S.session.role==='manager'&&S.chatRoom&&!isStaffRoom(S.chatRoom)){
    const acc=currentAccountForRoom619(S.chatRoom);
    const relevant=()=>acc?(S.messages||[]).filter(m=>rowBelongs619(m,acc)):[];
    const all=document.querySelector('#ct-all');if(all)all.onclick=()=>{const ids=relevant().map(m=>m.id);S.chatSel=(S.chatSel||[]).length===ids.length?[]:ids;render();};
    const clear=document.querySelector('#ct-clear');if(clear)clear.onclick=async()=>{const ids=relevant().map(m=>m.id);if(!ids.length)return;if(!await confirmAction({question:t('clearChatQ'),detail:t('clearChatHint').replace('{n}',ids.length),danger:true}))return;for(const id of ids)await DB.deleteMessage(id);S.chatSel=null;toastOk(t('saved'));render();};
  }
};

/* Public diagnostics for regression tests. */
window.AUREA_GUEST_LIFECYCLE={
  version:'6.19',stayToken:stayToken619,visibleRoom:visibleRoom619,rowBelongs:rowBelongs619,
  currentAccounts:currentAccounts619,archive:archiveList619,sweep:lifecycleSweep619
};
})();
