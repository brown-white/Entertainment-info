
(()=>{
'use strict';
if(window.__AUREA_PAYROLL_V630)return;
window.__AUREA_PAYROLL_V630=true;

const PAYKEY630='payrollByUserV630';
const PAYLOCAL631='entapp_payroll_v631';

function payKey630(u){
  const name=String(u&&u.username||'').trim().toLowerCase();
  return name || ('id:'+String(u&&u.id!=null?u.id:''));
}
function idPayKey631(u){ return 'id:'+String(u&&u.id!=null?u.id:''); }

function readPayrollLocal631(){
  try{
    const x=JSON.parse(localStorage.getItem(PAYLOCAL631)||'{}');
    return x&&typeof x==='object'?x:{};
  }catch(e){ return {}; }
}
function writePayrollLocal631(map){
  try{ localStorage.setItem(PAYLOCAL631,JSON.stringify(map||{})); }catch(e){}
}
function newerPayrollEntry631(a,b){
  if(!a)return b||null;if(!b)return a;
  return (+a._updatedAt||0)>=(+b._updatedAt||0)?a:b;
}
function payrollMap630(){
  const remote={...((S.settings&&S.settings[PAYKEY630])||{})};
  const local=readPayrollLocal631();
  const merged={...remote};
  Object.keys(local).forEach(k=>merged[k]=newerPayrollEntry631(local[k],merged[k]));
  /* Keep a local copy of the merged truth immediately. */
  writePayrollLocal631(merged);
  return merged;
}
function rawPayrollConfig631(u){
  const map=payrollMap630(),keys=[
    payKey630(u),idPayKey631(u),String(u&&u.id!=null?u.id:'')
  ].filter(Boolean);
  for(const k of keys)if(map[k])return map[k];
  return {};
}
function payrollConfig630(u){
  const raw=rawPayrollConfig631(u);
  return {
    amount:Math.max(0,+raw.amount||0),
    currency:String(raw.currency||'EGP').toUpperCase()==='USD'?'USD':'EGP',
    vacationPaid:raw.vacationPaid!==false,
    _updatedAt:+raw._updatedAt||0
  };
}
async function savePayrollConfig630(u,cfg){
  if(!u)return;
  const map=payrollMap630();
  const rec={
    amount:Math.max(0,+cfg.amount||0),
    currency:String(cfg.currency||'EGP').toUpperCase()==='USD'?'USD':'EGP',
    vacationPaid:cfg.vacationPaid!==false,
    _updatedAt:Date.now()
  };
  /* Store by username AND stable id so a rename cannot lose payroll. */
  map[payKey630(u)]=rec;
  map[idPayKey631(u)]=rec;
  writePayrollLocal631(map); // survives immediate refresh even if cloud is slow
  try{
    await DB.saveSettings({...S.settings,[PAYKEY630]:map});
  }catch(e){
    console.error('Payroll cloud save failed; local copy retained',e);
    /* Do not lose the salary just because the network failed. */
    S.settings={...S.settings,[PAYKEY630]:map};
    S._payrollCloudPending631=true;
    return rec;
  }
  S._payrollCloudPending631=false;
  return rec;
}
window.savePayrollConfig630=savePayrollConfig630;

async function syncPayroll631(){
  try{
    const merged=payrollMap630();
    const current=(S.settings&&S.settings[PAYKEY630])||{};
    if(JSON.stringify(current)!==JSON.stringify(merged)){
      await DB.saveSettings({...S.settings,[PAYKEY630]:merged});
    }
  }catch(e){ console.warn('Payroll background sync pending',e); }
}

function money630(n,c){
  const v=Math.round((+n||0)*100)/100;
  try{return new Intl.NumberFormat('en-US',{minimumFractionDigits:v%1?2:0,maximumFractionDigits:2}).format(v)+' '+c;}
  catch(e){return v.toFixed(v%1?2:0)+' '+c;}
}
function monthKey630(d=hotelNow()){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');}
function daysMonth630(mk){return monthDays(mk);}
function employmentDays630(u,mk){
  const n=daysMonth630(mk),out=[];
  for(let d=1;d<=n;d++){
    if(notYetHired(u,mk,d)||leftBefore(u,mk,d))continue;
    out.push(d);
  }
  return out;
}
function payrollCalc630(u,mk){
  const cfg=payrollConfig630(u);
  const calendarDays=daysMonth630(mk);
  const eligible=employmentDays630(u,mk);

  /* Monthly salary means salary for the whole calendar month.
     Never divide by only the days somebody happened to be employed. */
  const daily=calendarDays>0 ? cfg.amount/calendarDays : 0;

  const today=hotelDateStr(),monthNow=today.slice(0,7),todayD=+today.slice(8,10);
  const happened=eligible.filter(d=>mk<monthNow||(mk===monthNow&&d<=todayD));

  const statusFor=(d,projection=false)=>{
    let st=attStatus(u,mk,d);
    if(!st && projection) st=attAuto(u,mk,d);
    return st||"";
  };
  const evaluate=(d,projection=false)=>{
    const status=statusFor(d,projection),date=dateStr(mk,d);
    let paid=false,reason="";
    if(status==="P"){paid=true;reason="Present · paid";}
    else if(status==="O"){paid=true;reason="Day off · paid";}
    else if(status==="A"){reason="Absent · unpaid";}
    else if(status==="V"){paid=cfg.vacationPaid;reason=cfg.vacationPaid?"Vacation · paid":"Vacation · unpaid";}
    else if(status==="N"){reason="Not employed / not payable";}
    else {paid=projection;reason=projection?"Planned paid day":"Not counted yet";}
    return {date,status,paid,reason,amount:paid?daily:0};
  };

  const ledger=happened.map(d=>evaluate(d,false));
  const projectedLedger=eligible.map(d=>evaluate(d,true));

  const counts={present:0,off:0,absent:0,vacation:0,paidDays:0};
  ledger.forEach(x=>{
    if(x.status==="P")counts.present++;
    if(x.status==="O")counts.off++;
    if(x.status==="A")counts.absent++;
    if(x.status==="V")counts.vacation++;
    if(x.paid)counts.paidDays++;
  });

  const earned=ledger.reduce((n,x)=>n+x.amount,0);
  const deductions=ledger
    .filter(x=>x.status==="A"||(x.status==="V"&&!cfg.vacationPaid))
    .map(x=>({...x,amount:daily}));

  const projectedDeductions=projectedLedger
    .filter(x=>x.status==="A"||(x.status==="V"&&!cfg.vacationPaid))
    .map(x=>({...x,amount:daily}));

  /* Proration is separate from attendance deductions:
     joining/leaving mid-month reduces the payable base automatically. */
  const proratedBase=daily*eligible.length;
  const employmentProration=Math.max(0,cfg.amount-proratedBase);
  const projectedPay=Math.max(0,proratedBase-projectedDeductions.reduce((n,x)=>n+x.amount,0));
  const remaining=Math.max(0,projectedPay-earned);

  return {
    user:u,mk,cfg,
    calendarDays,
    daily,
    eligibleDays:eligible.length,
    elapsedDays:happened.length,
    paidDays:counts.paidDays,
    present:counts.present,
    off:counts.off,
    absent:counts.absent,
    vacation:counts.vacation,
    earned:Math.max(0,earned),
    deductions,
    projectedDeductions,
    contract:cfg.amount,
    proratedBase,
    employmentProration,
    fullMonthActual:projectedPay,
    remaining,
    progress:projectedPay>0?Math.min(100,Math.round(earned/projectedPay*100)):0,
    ledger,
    projectedLedger
  };
}
window.payrollCalc630=payrollCalc630;

function payrollEditorHtml630(u){
  const c=payrollConfig630(u);
  return `<div class="pay630-editbox">
    <div class="pay630-edithead"><b>Salary</b><span>Monthly payroll</span></div>
    <div class="row2">
      <div><label>Monthly salary</label><input id="ue-salary" type="number" min="0" step="0.01" inputmode="decimal" value="${c.amount||''}" placeholder="10000"></div>
      <div><label>Currency</label><select id="ue-currency"><option value="EGP" ${c.currency==='EGP'?'selected':''}>EGP</option><option value="USD" ${c.currency==='USD'?'selected':''}>USD</option></select></div>
    </div>
    <label class="pay630-toggle"><input id="ue-vacpaid" type="checkbox" ${c.vacationPaid?'checked':''}> Paid vacation</label>
    <p class="mini">Present + Day Off are paid. Absence is deducted automatically. Vacation follows the setting above.</p>
  </div>`;
}
window.payrollEditorHtml630=payrollEditorHtml630;

function payrollMonthOptions630(){
  return Array.from({length:12},(_,i)=>{
    const mk='2000-'+String(i+1).padStart(2,'0');
    return [i+1,monthLabel(mk).replace(/\s+2000$/,'')];
  });
}
function payrollYears631(){
  const now=hotelNow(),ys=new Set();
  for(let y=now.getFullYear()-5;y<=now.getFullYear()+2;y++)ys.add(y);
  (S.staffAtt||[]).forEach(x=>{const y=+String(x.date||'').slice(0,4);if(y)ys.add(y);});
  (S.users||[]).forEach(u=>{
    [u.hire_date,u.left_date].forEach(v=>{const y=+String(v||'').slice(0,4);if(y)ys.add(y);});
  });
  return [...ys].sort((a,b)=>a-b);
}
function payrollSelectedMonth631(){
  return S.payrollMonth630||currentAttMonth()||monthKey630();
}
function payrollPeriodLabel631(mk){
  const nowMk=monthKey630();
  if(mk<nowMk)return 'Final salary';
  if(mk===nowMk)return 'Salary to date';
  return 'Planned salary';
}
function payrollTeam630(mk){
  return attTeamFor(mk).filter(u=>u.role==='staff'||u.role==='manager').map(u=>payrollCalc630(u,mk));
}
function currencyTotals630(rows,field){
  const out={EGP:0,USD:0};
  rows.forEach(r=>out[r.cfg.currency]+=+r[field]||0);
  return out;
}
function payrollDataset630(mk){
  const rows=payrollTeam630(mk);
  const data=rows.map(r=>[
    r.user.number?("#"+r.user.number):"",
    r.user.display_name||r.user.username,
    r.cfg.currency,
    r.contract.toFixed(2),
    r.calendarDays,
    r.eligibleDays,
    r.daily.toFixed(2),
    r.proratedBase.toFixed(2),
    r.present,
    r.off,
    r.absent,
    r.vacation,
    r.cfg.vacationPaid?"Paid":"Unpaid",
    r.paidDays,
    r.earned.toFixed(2),
    r.deductions.reduce((n,x)=>n+x.amount,0).toFixed(2),
    r.employmentProration.toFixed(2),
    r.fullMonthActual.toFixed(2),
    r.deductions.map(x=>`${x.date}: ${x.reason} -${money630(x.amount,r.cfg.currency)}`).join(" | ")
  ]);

  const contract=currencyTotals630(rows,"contract"),
        prorated=currencyTotals630(rows,"proratedBase"),
        earned=currencyTotals630(rows,"earned"),
        actual=currencyTotals630(rows,"fullMonthActual");

  data.push([]);
  data.push(["","","EGP","Contract",contract.EGP.toFixed(2),"","","Prorated base",prorated.EGP.toFixed(2),"","","","","","Earned",earned.EGP.toFixed(2),"","Final / expected",actual.EGP.toFixed(2)]);
  data.push(["","","USD","Contract",contract.USD.toFixed(2),"","","Prorated base",prorated.USD.toFixed(2),"","","","","","Earned",earned.USD.toFixed(2),"","Final / expected",actual.USD.toFixed(2)]);

  return {
    title:"Team Payroll — "+monthLabel(mk),
    headers:[
      "#","Team member","Currency","Monthly salary","Calendar days","Employment days",
      "Daily rate","Prorated salary base","Present","Day off","Absent","Vacation",
      "Vacation salary","Paid days elapsed","Earned to date","Attendance deductions",
      "Employment proration","Final / expected pay","Deduction details"
    ],
    rows:data,
    landscape:true,
    sourceNote:"Payroll rule: monthly salary ÷ calendar days in the month = daily rate. Only employed dates can earn salary. Present and Day Off are paid. Absence is unpaid. Vacation follows each employee setting. Mid-month joining/leaving is prorated automatically. EGP and USD remain separate."
  };
}
window.payrollDataset630=payrollDataset630;

function payrollManagerInner630(){
  const mk=payrollSelectedMonth631(),[yr,mo]=mk.split("-").map(Number),rows=payrollTeam630(mk);
  const contract=currencyTotals630(rows,"contract"),
        prorated=currencyTotals630(rows,"proratedBase"),
        earned=currencyTotals630(rows,"earned"),
        actual=currencyTotals630(rows,"fullMonthActual");

  const attendanceDed={EGP:0,USD:0},employmentProration={EGP:0,USD:0};
  rows.forEach(r=>{
    attendanceDed[r.cfg.currency]+=r.deductions.reduce((n,x)=>n+x.amount,0);
    employmentProration[r.cfg.currency]+=r.employmentProration||0;
  });

  const configured=rows.filter(r=>r.contract>0),period=payrollPeriodLabel631(mk);
  return `<div class="pay630-hero">
      <div class="ey">Team payroll</div>
      <h3>${esc(monthLabel(mk))}</h3>
      <p>Correct monthly payroll: monthly salary is divided by the calendar days of this month. Joining/leaving mid-month is prorated. Present + Day Off are paid. Absence is unpaid. Vacation follows each employee setting.</p>
    </div>

    <div class="row2">
      <div><label>Month</label><select id="pay631-month">${payrollMonthOptions630().map(([v,l])=>`<option value="${v}" ${v===mo?"selected":""}>${esc(l)}</option>`).join("")}</select></div>
      <div><label>Year</label><select id="pay631-year">${payrollYears631().map(y=>`<option value="${y}" ${y===yr?"selected":""}>${y}</option>`).join("")}</select></div>
    </div>

    <div class="pay631-explain">
      <b>${esc(period)} · ${esc(monthLabel(mk))}</b>
      <span><strong>Monthly contract</strong> is the full-month salary. <strong>Prorated base</strong> is what the employee can earn for the dates they were employed. <strong>Earned</strong> is what has actually accumulated so far. <strong>Final / expected pay</strong> is the prorated base minus absence or unpaid-vacation deductions.</span>
    </div>

    <div class="pay630-totals">
      <div class="pay630-total"><b>${money630(contract.EGP,"EGP")}</b><span>Full monthly contracts · EGP</span></div>
      <div class="pay630-total"><b>${money630(contract.USD,"USD")}</b><span>Full monthly contracts · USD</span></div>

      <div class="pay630-total"><b>${money630(prorated.EGP,"EGP")}</b><span>Prorated salary base · EGP</span></div>
      <div class="pay630-total"><b>${money630(prorated.USD,"USD")}</b><span>Prorated salary base · USD</span></div>

      <div class="pay630-total"><b>${money630(earned.EGP,"EGP")}</b><span>Earned ${mk===monthKey630()?"to date":"in period"} · EGP</span></div>
      <div class="pay630-total"><b>${money630(earned.USD,"USD")}</b><span>Earned ${mk===monthKey630()?"to date":"in period"} · USD</span></div>

      <div class="pay630-total"><b>${money630(attendanceDed.EGP,"EGP")}</b><span>Attendance deductions · EGP</span></div>
      <div class="pay630-total"><b>${money630(attendanceDed.USD,"USD")}</b><span>Attendance deductions · USD</span></div>

      <div class="pay630-total"><b>${money630(actual.EGP,"EGP")}</b><span>${mk<monthKey630()?"Final":"Expected"} pay · EGP</span></div>
      <div class="pay630-total"><b>${money630(actual.USD,"USD")}</b><span>${mk<monthKey630()?"Final":"Expected"} pay · USD</span></div>
    </div>

    ${(employmentProration.EGP||employmentProration.USD)?`<div class="pay632-proration-note"><b>Employment proration</b><span>Not a penalty: this is salary outside the employee's employment dates in this month.</span><div>${employmentProration.EGP?money630(employmentProration.EGP,"EGP"):""}${employmentProration.EGP&&employmentProration.USD?" · ":""}${employmentProration.USD?money630(employmentProration.USD,"USD"):""}</div></div>`:""}

    <div class="pay630-actions"><button class="btn" id="pay630-xlsx">${ic("download",16)} Export Excel</button><button class="btn ghost" id="pay630-pdf">${ic("download",16)} PDF / Print</button></div>

    ${configured.length?`<div class="pay630-list">${configured.map(r=>payrollPerson631(r,true)).join("")}</div>`:`<div class="empty"><div class="big">${ic("users",28)}</div>No salaries configured for this team yet. Open Team accounts → Edit person → Salary.</div>`}`;
}
window.payrollManagerInner630=payrollManagerInner630;
window.payrollManagerInner630=payrollManagerInner630;

function payrollPerson631(r,manager){
  const ded=r.deductions.reduce((n,x)=>n+x.amount,0);
  const remaining=r.remaining!=null?r.remaining:Math.max(0,r.fullMonthActual-r.earned);
  const past=r.mk<monthKey630();
  return `<article class="pay630-person">
    <div class="pay630-person-top">
      <div>
        <b>${esc(r.user.display_name||r.user.username)}</b>
        <div class="mini">${r.user.number?"#"+r.user.number+" · ":""}${esc(monthLabel(r.mk))} · ${esc(r.cfg.currency)} · ${r.cfg.vacationPaid?"Paid vacation":"Unpaid vacation"}</div>
      </div>
      <div class="pay630-money"><strong>${money630(r.earned,r.cfg.currency)}</strong><span>${past?"earned in month":"earned so far"}</span></div>
    </div>

    <div class="pay630-progress"><i style="width:${r.progress}%"></i></div>

    <div class="pay631-summary">
      <div><span>Full monthly salary</span><b>${money630(r.contract,r.cfg.currency)}</b></div>
      <div><span>Prorated salary base</span><b>${money630(r.proratedBase,r.cfg.currency)}</b></div>
      <div><span>${past?"Final pay":"Expected pay"}</span><b>${money630(r.fullMonthActual,r.cfg.currency)}</b></div>
      <div><span>${past?"Difference":"Still to earn"}</span><b>${money630(remaining,r.cfg.currency)}</b></div>
    </div>

    <div class="pay630-grid">
      <div class="pay630-cell"><b>${money630(r.daily,r.cfg.currency)}</b><span>Daily rate · ${r.calendarDays} days</span></div>
      <div class="pay630-cell"><b>${r.eligibleDays}</b><span>Employment days</span></div>
      <div class="pay630-cell"><b>${r.paidDays}</b><span>Paid days elapsed</span></div>
      <div class="pay630-cell"><b class="${ded?"pay630-minus":""}">${ded?"− ":""}${money630(ded,r.cfg.currency)}</b><span>Attendance deductions</span></div>
    </div>

    ${r.employmentProration>0?`<div class="pay632-proration"><span>Employment proration</span><b>− ${money630(r.employmentProration,r.cfg.currency)}</b><small>${r.eligibleDays} of ${r.calendarDays} calendar days employed. This is not an absence penalty.</small></div>`:""}

    ${r.deductions.length?`<div class="pay630-deduct"><b style="font-size:10px">Unpaid attendance days</b>${r.deductions.map(x=>`<div class="pay630-deduct-row"><span>${esc(x.date)} · ${esc(x.reason)}</span><strong>− ${money630(x.amount,r.cfg.currency)}</strong></div>`).join("")}</div>`:""}

    ${manager?`<button class="btn ghost sm" data-pay630-edit="${esc(r.user.id)}" style="margin-top:10px">${ic("pen",14)} Edit salary</button>`:""}
  </article>`;
}
function payrollPerson630(r,manager){ return payrollPerson631(r,manager); }

function mySalaryCard630(){
  const u=(S.users||[]).find(x=>x.username===S.session.username);if(!u)return"";
  const mk=currentAttMonth(),r=payrollCalc630(u,mk);if(!r.contract)return"";

  const nowMk=monthKey630(),isCurrent=mk===nowMk,isPast=mk<nowMk;
  const today=hotelDateStr(),todayRow=isCurrent?r.ledger.find(x=>x.date===today):null;
  const ded=r.deductions.reduce((n,x)=>n+x.amount,0);
  const remaining=r.remaining!=null?r.remaining:Math.max(0,r.fullMonthActual-r.earned);

  return `<section class="sec pay630-my">
    <h3>${ic("star",18)} My salary</h3>
    <div class="card pay631-mycard">
      <div class="pay631-readonly">Read only · managed by Entertainment Manager</div>
      <div class="pay631-monthtitle">${esc(monthLabel(mk))}</div>

      <div class="pay631-heroamount">
        <span>${isPast?"Final earned":isCurrent?"Earned so far":"Planned"}</span>
        <b>${money630(r.earned,r.cfg.currency)}</b>
      </div>

      <div class="pay630-progress"><i style="width:${r.progress}%"></i></div>

      <div class="pay631-summary">
        <div><span>Full monthly salary</span><b>${money630(r.contract,r.cfg.currency)}</b></div>
        <div><span>Salary for your employment dates</span><b>${money630(r.proratedBase,r.cfg.currency)}</b></div>
        <div><span>${isPast?"Final pay":"Expected pay"}</span><b>${money630(r.fullMonthActual,r.cfg.currency)}</b></div>
        <div><span>${isPast?"Difference":"Still to earn"}</span><b>${money630(remaining,r.cfg.currency)}</b></div>
      </div>

      <div class="pay630-grid">
        <div class="pay630-cell"><b>${money630(r.daily,r.cfg.currency)}</b><span>Daily rate · ${r.calendarDays} days</span></div>
        <div class="pay630-cell"><b>${r.eligibleDays}</b><span>Employment days</span></div>
        <div class="pay630-cell"><b>${r.paidDays}</b><span>Paid days elapsed</span></div>
        <div class="pay630-cell"><b class="${ded?"pay630-minus":""}">${ded?"− ":""}${money630(ded,r.cfg.currency)}</b><span>Attendance deductions</span></div>
      </div>

      ${r.employmentProration>0?`<div class="pay632-proration"><span>Employment proration</span><b>− ${money630(r.employmentProration,r.cfg.currency)}</b><small>You were employed for ${r.eligibleDays} of ${r.calendarDays} calendar days in ${esc(monthLabel(mk))}. This is not an absence deduction.</small></div>`:""}

      ${todayRow?`<div class="todayearn">${todayRow.paid?`Today · ${esc(todayRow.reason)} · + ${money630(todayRow.amount,r.cfg.currency)}`:`Today · <span class="pay630-minus">${esc(todayRow.reason)} · − ${money630(r.daily,r.cfg.currency)}</span>`}</div>`:""}

      ${r.deductions.length?`<div class="pay630-deduct"><b style="font-size:10px">Why attendance money was deducted</b>${r.deductions.map(x=>`<div class="pay630-deduct-row"><span>${esc(x.date)} · ${esc(x.reason)}</span><strong>− ${money630(x.amount,r.cfg.currency)}</strong></div>`).join("")}</div>`:`<div class="pay631-nodeduct">No attendance deductions in ${esc(monthLabel(mk))}.</div>`}
    </div>
  </section>`;
}

/* Add salary to entertainer My Attendance and My Work Day without replacing their existing content. */
const oldMyPage630=window.myPageView;
window.myPageView=myPageView=function(){
  const html=oldMyPage630();
  const card=mySalaryCard630();
  return card?html.replace(/<\/div>\s*$/i,card+'</div>'):html;
};
const oldWorkday630=window.myWorkDayView;
window.myWorkDayView=myWorkDayView=function(){
  const html=oldWorkday630();
  const card=mySalaryCard630();
  return card?html.replace(/<\/div>\s*$/i,card+'</div>'):html;
};

/* Smart Export dataset */
const buildBefore630=window.buildDataset;
window.buildDataset=buildDataset=function(kind){
  if(kind==='payroll')return payrollDataset630(S.exportMonth||monthKey630());
  return buildBefore630(kind);
};

/* Payroll interactions */
const wireBefore630=window.wireCommon;
window.wireCommon=wireCommon=function(){
  wireBefore630();
  const pm=document.querySelector('#pay631-month'),py=document.querySelector('#pay631-year');
  const setPayrollPeriod631=()=>{
    if(!pm||!py)return;
    S.payrollMonth630=String(py.value)+'-'+String(pm.value).padStart(2,'0');
    render();
  };
  if(pm)pm.onchange=setPayrollPeriod631;
  if(py)py.onchange=setPayrollPeriod631;
  document.querySelectorAll('[data-pay630-edit]').forEach(b=>b.onclick=()=>{
    const u=(S.users||[]).find(x=>String(x.id)===String(b.dataset.pay630Edit));
    if(u)openUserEditModal(u);
  });
  const x=document.querySelector('#pay630-xlsx');
  if(x)x.onclick=async()=>{
    const mk=S.payrollMonth630||monthKey630();
    try{await smartExportExcel620([payrollDataset630(mk)],'team-payroll-'+mk);toastOk(t('saved'));}catch(e){console.error('payroll excel',e);toastErr(t('errSave'));}
  };
  const p=document.querySelector('#pay630-pdf');
  if(p)p.onclick=()=>{
    const mk=S.payrollMonth630||monthKey630();
    exportPdfSets([payrollDataset630(mk)],((S.settings&&(S.settings.hotelName||S.settings.name))||'Hotel')+' — Team Payroll '+monthLabel(mk));
  };
};

setTimeout(syncPayroll631,1900);

window.AUREA_PAYROLL_V630={
  version:'6.32',config:payrollConfig630,save:savePayrollConfig630,
  calculate:payrollCalc630,dataset:payrollDataset630,team:payrollTeam630,sync:syncPayroll631,years:payrollYears631
};
})();
