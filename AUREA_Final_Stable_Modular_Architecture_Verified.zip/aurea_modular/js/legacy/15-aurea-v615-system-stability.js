
(function(){
  'use strict';
  if(window.__AUREA_V615__) return; window.__AUREA_V615__=true;

  const COPY_V615={
    en:{included:'Included for all guests',noBooking:'No booking required',copy:'Just come to the location at the scheduled time and enjoy.',show:'Show',live:'Live Music',other:'Programme'},
    de:{included:'Für alle Gäste inklusive',noBooking:'Keine Buchung erforderlich',copy:'Komm einfach zur angegebenen Zeit zum Veranstaltungsort und genieße das Programm.',show:'Show',live:'Live-Musik',other:'Programm'},
    ru:{included:'Включено для всех гостей',noBooking:'Бронирование не требуется',copy:'Просто приходите в указанное место ко времени начала и наслаждайтесь программой.',show:'Шоу',live:'Живая музыка',other:'Программа'},
    nl:{included:'Inbegrepen voor alle gasten',noBooking:'Reserveren is niet nodig',copy:'Kom gewoon op de aangegeven tijd naar de locatie en geniet.',show:'Show',live:'Live muziek',other:'Programma'},
    fr:{included:'Inclus pour tous les clients',noBooking:'Aucune réservation nécessaire',copy:"Venez simplement au lieu indiqué à l'heure prévue et profitez du programme.",show:'Spectacle',live:'Musique live',other:'Programme'},
    ar:{included:'متاح لجميع الضيوف',noBooking:'لا يحتاج إلى حجز',copy:'فقط تعال إلى المكان في الوقت المحدد واستمتع بالبرنامج.',show:'عرض',live:'موسيقى حية',other:'البرنامج'}
  };
  function cv615(k){const d=COPY_V615[S.lang]||COPY_V615.en;return d[k]||COPY_V615.en[k]||k;}
  function typeLabelV615(a){const c=(()=>{try{return normCat(a);}catch(_){return String((a&&a.category)||'');}})();if(c==='eShow'||c==='eKidsStage')return cv615('show');if(c==='eLive'||c==='eBefore'||c==='eAfter')return cv615('live');return cv615('other');}

  function openIncludedV615(a){
    if(!a)return;
    const wrap=baseModal(`<div class="v615-viewonly"><div class="vo-hero"><img src="${esc(a.image||IMG.show)}" alt="" decoding="async"><span class="vo-badge">${ic('check',13)} ${esc(cv615('included'))}</span><div class="vo-title"><h3>${esc(a.name||'')}</h3><p>${esc(typeLabelV615(a))} · ${esc(a.time||'')} · ${esc(a.location||'')}</p></div></div><div class="vo-info"><b>${esc(cv615('noBooking'))}</b><span>${esc(cv615('copy'))}</span></div>${a.desc?`<p class="vo-desc">${esc(a.desc)}</p>`:''}<button class="btn ghost" id="v615-close">${esc(t('close'))}</button></div>`);
    const x=wrap.querySelector('#v615-close');if(x)x.onclick=()=>wrap.remove();
  }

  /* Universal policy guard. Even stale/legacy UI cannot create a booking for a non-bookable item. */
  const prevOpenBookV615=openBookModal;
  window.openBookModal=openBookModal=function(a){
    if(S.session&&S.session.role==='guest'&&isViewOnlyV615(a))return openIncludedV615(a);
    return prevOpenBookV615(a);
  };

  /* Details-first remains universal. View-only programme items never expose a Book action. */
  const prevDetailV615=openGuestActivityDetail;
  window.openGuestActivityDetail=openGuestActivityDetail=function(a){
    if(S.session&&S.session.role==='guest'&&isViewOnlyV615(a))return openIncludedV615(a);
    return prevDetailV615(a);
  };

  /* Phase 4: booking/ticket write guards moved to canonical services.
     Keep these names as compatibility aliases for later UI patches. */
  const canGuestBookV615=a=>AUREA_BOOKING_SERVICE.canBook(a);
  const isViewOnlyV615=a=>AUREA_BOOKING_SERVICE.isViewOnly(a);
  window.canGuestBookV615=canGuestBookV615;

  function applyGuestPolicyV615(){
    if(!(S.session&&S.session.role==='guest'))return;
    /* Remove any stale Book controls for view-only programme types. */
    document.querySelectorAll('[data-book]').forEach(btn=>{
      const a=(S.activities||[]).find(x=>String(x.id)===String(btn.dataset.book));
      if(!a||canGuestBookV615(a))return;
      const chip=document.createElement('span');chip.className='v615-included';chip.innerHTML=ic('check',13)+' '+esc(cv615('included'));btn.replaceWith(chip);
    });
    /* Any generic activity-open route becomes details-first for guests. */
    document.querySelectorAll('[data-actopen]').forEach(el=>{
      const a=(S.activities||[]).find(x=>String(x.id)===String(el.dataset.actopen));
      if(a)el.onclick=(ev)=>{if(ev&&ev.stopPropagation)ev.stopPropagation();openGuestActivityDetail(a);};
    });
    /* Cheap render hygiene: decode content images asynchronously; preserve eager loading where explicitly set. */
    document.querySelectorAll('.screen img').forEach((img,i)=>{if(!img.decoding)img.decoding='async';if(i>1&&!img.hasAttribute('loading'))img.loading='lazy';});
  }

  const oldWireV615=wireCommon;
  window.wireCommon=wireCommon=function(){oldWireV615();applyGuestPolicyV615();};

  /* Expose policy for diagnostics and future manager UI without duplicating category rules. */
  window.AUREA_BOOKING_POLICY=AUREA_BOOKING_SERVICE;
})();
