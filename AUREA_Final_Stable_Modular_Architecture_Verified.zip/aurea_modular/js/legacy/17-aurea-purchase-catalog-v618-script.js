
(()=>{
  'use strict';
  if(window.__AUREA_PURCHASE_CATALOG_V618) return;
  window.__AUREA_PURCHASE_CATALOG_V618=true;

  const esc618=v=>esc(String(v??''));
  const uid618=()=> 'pci'+Date.now().toString(36)+Math.random().toString(36).slice(2,7);
  const normalizeItem618=(x={})=>({id:String(x.id||uid618()),name:String(x.name||'').trim(),description:String(x.description||'').trim(),quantity:String(x.quantity??x.qty??'').trim()});
  function catalog618(){
    const raw=S.settings&&S.settings.purchaseItemCatalog;
    return (Array.isArray(raw)?raw:[]).map(normalizeItem618).filter(x=>x.name);
  }
  async function saveCatalog618(list){
    const clean=(Array.isArray(list)?list:[]).map(normalizeItem618).filter(x=>x.name);
    const next={...S.settings,purchaseItemCatalog:clean};
    await DB.saveSettings(next);
    S.settings=next;
    return clean;
  }
  function itemText618(it){return it.name+(it.description?' — '+it.description:'');}

  function openItemEditor618(existing,onSaved){
    const item=normalizeItem618(existing||{}),isEdit=!!existing;
    const wrap=baseModal(`<h3>${isEdit?'Edit catalog item':'Add catalog item'}</h3>
      <p class="pr618-editor-note">Save frequently purchased items once, then reuse them inside any Purchase Request.</p>
      <label>Item name</label><input id="pr618-name" value="${esc618(item.name)}" placeholder="e.g. A4 Paper">
      <label style="margin-top:10px">Short description</label><textarea id="pr618-desc" rows="3" placeholder="Brand, size, colour, specification…">${esc618(item.description)}</textarea>
      <label style="margin-top:10px">Default quantity</label><input id="pr618-qty" value="${esc618(item.quantity)}" inputmode="decimal" placeholder="e.g. 10">
      <button class="btn" id="pr618-saveitem">${isEdit?'Save changes':'Add item'}</button>
      <button class="btn ghost" id="pr618-cancelitem">Cancel</button>`);
    wrap.querySelector('#pr618-cancelitem').onclick=()=>wrap.remove();
    wrap.querySelector('#pr618-saveitem').onclick=async()=>{
      const name=wrap.querySelector('#pr618-name').value.trim(),description=wrap.querySelector('#pr618-desc').value.trim(),quantity=wrap.querySelector('#pr618-qty').value.trim();
      if(!name){toastErr('Please add the item name.');return;}
      const list=catalog618(),next={...item,name,description,quantity};
      const idx=list.findIndex(x=>String(x.id)===String(item.id));
      if(idx>=0)list[idx]=next;else list.push(next);
      try{await saveCatalog618(list);wrap.remove();toastOk(isEdit?'Item updated':'Item added');if(typeof onSaved==='function')onSaved(next);}catch(e){console.error('purchase catalog save',e);toastErr(t('errSave'));}
    };
  }

  function openCatalogManager618(){
    const wrap=baseModal(`<h3>Purchase Item List</h3><p class="pr618-editor-note">Manage reusable items for Purchase Requests. Each item has a name, short description and default quantity.</p><button class="btn" id="pr618-newitem">＋ Add item</button><div id="pr618-managelist" class="pr618-catalog"></div><button class="btn ghost" id="pr618-done">Close</button>`);
    const box=wrap.querySelector('#pr618-managelist');
    const paint=()=>{
      const list=catalog618();
      box.innerHTML=list.length?list.map(it=>`<div class="pr618-item"><div><strong>${esc618(it.name)}</strong>${it.description?`<p>${esc618(it.description)}</p>`:''}<span class="qty">Default quantity: ${esc618(it.quantity||'—')}</span></div><div class="pr618-actions"><button class="btn ghost sm" data-pr618-edit="${esc618(it.id)}">Edit</button><button class="btn ghost warn sm" data-pr618-remove="${esc618(it.id)}">Remove</button></div></div>`).join(''):`<div class="pr618-empty">No saved items yet.<br>Add the things your department orders regularly.</div>`;
      box.querySelectorAll('[data-pr618-edit]').forEach(b=>b.onclick=()=>{const it=catalog618().find(x=>String(x.id)===String(b.dataset.pr618Edit));if(it)openItemEditor618(it,paint);});
      box.querySelectorAll('[data-pr618-remove]').forEach(b=>b.onclick=async()=>{const it=catalog618().find(x=>String(x.id)===String(b.dataset.pr618Remove));if(!it)return;if(!await confirmAction({question:'Remove '+it.name+'?',note:t('cannotUndo'),danger:true}))return;try{await saveCatalog618(catalog618().filter(x=>String(x.id)!==String(it.id)));toastOk('Item removed');paint();}catch(e){console.error(e);toastErr(t('errSave'));}});
    };
    paint();wrap.querySelector('#pr618-newitem').onclick=()=>openItemEditor618(null,paint);wrap.querySelector('#pr618-done').onclick=()=>wrap.remove();
  }

  window.openPurchaseItemCatalog=openCatalogManager618;
})();
