
(()=>{
  'use strict';
  if(window.__AUREA_GUEST_TICKET_TAB_MIGRATION_V6193)return;
  window.__AUREA_GUEST_TICKET_TAB_MIGRATION_V6193=true;
  let running=false;
  async function migrateGuestTicketsTabV6193(){
    if(running||!S.settings||S.settings.guestTicketsTabMigrationV6193)return false;
    running=true;
    try{
      const po={...((S.settings&&S.settings.pageOrder)||{})};
      let order=Array.isArray(po.guests)?po.guests.filter(k=>PAGE_SECTIONS.guests.includes(k)):PAGE_SECTIONS.guests.slice();
      for(const k of PAGE_SECTIONS.guests)if(!order.includes(k))order.push(k);
      order=order.filter(k=>k!=="tickets");
      const bi=order.indexOf("bookings");order.splice(bi>=0?bi+1:Math.min(3,order.length),0,"tickets");
      po.guests=order;
      const ph={...((S.settings&&S.settings.pageHidden)||{})};
      ph.guests=(Array.isArray(ph.guests)?ph.guests:[]).filter(k=>k!=="tickets");
      const next={...S.settings,pageOrder:po,pageHidden:ph,guestTicketsTabMigrationV6193:true};
      await DB.saveSettings(next);S.settings=next;
      if(S.session&&S.session.role==="manager"&&S.tab==="guests")render();
      return true;
    }catch(e){console.error('Guest Tickets tab migration V6.19.3',e);return false;}
    finally{running=false;}
  }
  window.migrateGuestTicketsTabV6193=migrateGuestTicketsTabV6193;
  setTimeout(migrateGuestTicketsTabV6193,650);
  const oldPollV6193=DB.poll.bind(DB);
  DB.poll=async function(){const changed=await oldPollV6193();if(S.settings&&!S.settings.guestTicketsTabMigrationV6193)await migrateGuestTicketsTabV6193();return changed;};
})();
