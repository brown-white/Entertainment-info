
(()=>{
'use strict';
if(window.__AUREA_INFO_BOARD_V635)return;
window.__AUREA_INFO_BOARD_V635=true;

function boardDate635(v){
  const s=String(v||todayISO());
  const d=new Date(s+'T12:00:00');
  return isNaN(d.getTime())?new Date():d;
}
function isoLocal635(d){
  const p=n=>String(n).padStart(2,'0');
  return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate());
}
function monday635(d){
  const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());
  const diff=(x.getDay()+6)%7;x.setDate(x.getDate()-diff);return x;
}
function dayIndex635(d){return (d.getDay()+6)%7;}
function dateLabel635(d){
  const days=t('days'),months=t('months');
  return (days[dayIndex635(d)]||'')+' '+d.getDate()+' '+(months[d.getMonth()]||'')+' '+d.getFullYear();
}
function shortDate635(d){return String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0');}
function type635(a){
  const c=normCat(a);
  if(c==='mAdult'||c==='mKids'||c==='mTeen')return'activity';
  if(c==='mEvents')return'event';
  if(c==='eLive'||c==='eBefore'||c==='eAfter')return'live';
  if(c==='eShow'||c==='eKidsStage')return'show';
  if(c==='eParty')return'party';
  return'activity';
}
function typeLabel635(k){return {activity:'Activity',event:'Day Event',live:'Live Music',show:'Show',party:'Party / Special'}[k]||'Program';}
function cleanTime635(v){return String(v||'').replace(/\s+/g,' ').trim();}
function who635(a){
  const raw=String(a&&a.entertainer||'').trim();
  return raw?(typeof entertainerName==='function'?entertainerName(raw):raw):'';
}
function boardItems635(day){
  return (S.activities||[]).filter(a=>a&&a.day===day).slice().sort((a,b)=>{
    const am=timeToMin(a.time),bm=timeToMin(b.time);
    return (am==null?9999:am)-(bm==null?9999:bm)||String(a.name||'').localeCompare(String(b.name||''));
  });
}
function info635(day){
  let identity='',theme='';
  try{
    if(typeof guestProgrammeDayDesignV610==='function'){
      const d=guestProgrammeDayDesignV610(day)||{};identity=d.dayName||d.identity||'';theme=d.restaurantTheme||'';
    }
  }catch(e){}
  try{
    if(typeof dayPlanFor==='function'){
      const d=dayPlanFor(day)||{};theme=theme||d.theme||'';
    }
  }catch(e){}
  try{
    const raw=S.settings&&S.settings.guestProgramDays&&S.settings.guestProgramDays[day];
    if(raw){identity=identity||raw.dayName||raw.identity||'';theme=theme||raw.restaurantTheme||raw.theme||'';}
  }catch(e){}
  return {identity,theme};
}
function escPrint635(x){return String(x??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));}
function boardCss635(scope){
  return `@page{size:${scope==='week'?'A3 landscape':'A4 portrait'};margin:8mm}
  *{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#2d211a;background:#fff}
  .page{width:100%}.top{display:flex;justify-content:space-between;gap:18px;align-items:end;border-bottom:3px solid #b98a5c;padding-bottom:8px;margin-bottom:12px}
  .ey{font-size:8px;letter-spacing:.18em;text-transform:uppercase;font-weight:800;color:#a07149}.title{font-family:Georgia,serif;font-size:${scope==='week'?'27px':'31px'};line-height:1;margin-top:4px}.date{font-size:11px;color:#75685f;text-align:right}.identity{display:flex;gap:8px;flex-wrap:wrap;margin:-3px 0 12px}.identity span{border:1px solid #dfd2c3;background:#f7f1e9;border-radius:999px;padding:5px 9px;font-size:8px;font-weight:700}
  .legend{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}.legend i,.tag{display:inline-flex;align-items:center;border-radius:999px;padding:4px 7px;font-style:normal;font-size:7px;font-weight:800;text-transform:uppercase;letter-spacing:.06em}.activity{background:#efe5d7;color:#674931}.event{background:#f5dfd8;color:#9a4938}.live{background:#e6eee9;color:#3f6851}.show{background:#e9e3f1;color:#62507b}.party{background:#e8dfec;color:#6e456e}
  .op{margin-top:12px}.ophead{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #d9ccbd;padding-bottom:5px;margin-bottom:7px}.ophead b{font-size:10px;letter-spacing:.12em;text-transform:uppercase}.ophead span{font-size:8px;color:#84766b}.rows{display:grid;gap:6px}.row{display:grid;grid-template-columns:72px 1fr 120px ${scope==='week'?'140px':'150px'};gap:9px;align-items:start;border:1px solid #e3d8cc;border-radius:10px;padding:7px 9px;break-inside:avoid}.time{font-weight:800;font-size:10px}.name{font-weight:800;font-size:10px}.meta{font-size:8px;color:#75685f;margin-top:2px}.who{font-size:8px;text-align:right;color:#66564c}.who b{display:block;color:#2d211a;margin-bottom:1px}.empty{font-size:9px;color:#8b7f76;padding:8px;border:1px dashed #ddd0c4;border-radius:9px}
  .week{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}.day{border:1px solid #d9ccbd;border-radius:12px;overflow:hidden;break-inside:avoid;background:#fff}.dayhead{padding:8px;background:#3e2a1e;color:#fff}.dayhead b{font-family:Georgia,serif;font-size:16px}.dayhead span{display:block;font-size:7px;opacity:.8;margin-top:2px}.daybody{padding:6px}.wi{padding:6px 0;border-bottom:1px solid #eee5dc}.wi:last-child{border:0}.wi .tm{font-size:7px;font-weight:800;color:#8f6748}.wi .nm{font-size:8px;font-weight:800;line-height:1.2;margin:2px 0}.wi .loc,.wi .wh{font-size:6.8px;color:#75685f;line-height:1.2}.wi .tag{margin-top:4px}.dayid{font-size:6.5px;color:#6f5d51;padding:5px 6px;background:#f5eee5;border-bottom:1px solid #e4d8cb}.foot{margin-top:12px;text-align:center;font-size:7px;color:#8b7c70}`;
}
function boardDayHtml635(d,includeWho){
  const day=dayIndex635(d),items=boardItems635(day),di=info635(day);
  const ops=[['morning','Morning · 10:00–12:30'],['afternoon','Afternoon · 15:00–17:30'],['evening','Evening · 19:30–23:00']];
  const opItems=k=>items.filter(a=>operationSlotFromMinutes(timeToMin(a.time))===k);
  return `<div class="page"><div class="top"><div><div class="ey">Entertainment Program</div><div class="title">${escPrint635(di.identity||t('days')[day])}</div></div><div class="date">${escPrint635(dateLabel635(d))}</div></div>
    ${(di.theme||di.identity)?`<div class="identity">${di.theme?`<span>Restaurant theme · ${escPrint635(di.theme)}</span>`:''}${di.identity&&di.identity!==t('days')[day]?`<span>Day name · ${escPrint635(di.identity)}</span>`:''}</div>`:''}
    <div class="legend">${['activity','event','live','show','party'].map(k=>`<i class="${k}">${typeLabel635(k)}</i>`).join('')}</div>
    ${ops.map(([k,label])=>{const list=opItems(k);return `<section class="op"><div class="ophead"><b>${label}</b><span>${list.length} item${list.length===1?'':'s'}</span></div><div class="rows">${list.length?list.map(a=>`<div class="row"><div class="time">${escPrint635(cleanTime635(a.time))}</div><div><span class="tag ${type635(a)}">${typeLabel635(type635(a))}</span><div class="name">${escPrint635(a.name)}</div>${a.desc?`<div class="meta">${escPrint635(a.desc)}</div>`:''}</div><div><div class="name">${escPrint635(a.location||'—')}</div><div class="meta">Location</div></div>${includeWho?`<div class="who"><b>${escPrint635(who635(a)||'—')}</b>Entertainment Team</div>`:'<div></div>'}</div>`).join(''):`<div class="empty">No programme in this operation.</div>`}</div></section>`;}).join('')}
    <div class="foot">Times and locations may change when required by hotel operations.</div></div>`;
}
function boardWeekHtml635(base,includeWho){
  const mon=monday635(base),days=Array.from({length:7},(_,i)=>{const d=new Date(mon);d.setDate(mon.getDate()+i);return d;});
  return `<div class="page"><div class="top"><div><div class="ey">Entertainment Program</div><div class="title">Weekly Program</div></div><div class="date">${shortDate635(days[0])} – ${shortDate635(days[6])} · ${days[0].getFullYear()}</div></div>
    <div class="legend">${['activity','event','live','show','party'].map(k=>`<i class="${k}">${typeLabel635(k)}</i>`).join('')}</div>
    <div class="week">${days.map(d=>{const day=dayIndex635(d),items=boardItems635(day),di=info635(day);return `<section class="day"><div class="dayhead"><b>${escPrint635(t('days')[day])}</b><span>${shortDate635(d)}</span></div>${(di.identity||di.theme)?`<div class="dayid">${di.identity?escPrint635(di.identity):''}${di.identity&&di.theme?' · ':''}${di.theme?'Restaurant: '+escPrint635(di.theme):''}</div>`:''}<div class="daybody">${items.length?items.map(a=>`<div class="wi"><div class="tm">${escPrint635(cleanTime635(a.time))}</div><div class="nm">${escPrint635(a.name)}</div><div class="loc">${escPrint635(a.location||'')}</div>${includeWho&&who635(a)?`<div class="wh">${escPrint635(who635(a))}</div>`:''}<span class="tag ${type635(a)}">${typeLabel635(type635(a))}</span></div>`).join(''):`<div class="empty">No programme</div>`}</div></section>`;}).join('')}</div>
    <div class="foot">Times and locations may change when required by hotel operations.</div></div>`;
}
function printBoard635({scope='day',date=todayISO(),includeWho=false}={}){
  const d=boardDate635(date),html=scope==='week'?boardWeekHtml635(d,includeWho):boardDayHtml635(d,includeWho);
  const w=window.open('','_blank');if(!w){toastErr('Could not open the print window.');return;}
  w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Entertainment Program</title><style>'+boardCss635(scope)+'</style></head><body>'+html+'<scr'+'ipt>setTimeout(function(){window.print();},350);<\/scr'+'ipt></body></html>');
  w.document.close();
}
function openInfoBoardExport635(){
  S._ib635Scope=S._ib635Scope||'day';
  const wrap=baseModal(`<div class="ib635-modal"><div class="ib635-intro"><div class="ib635-kicker">Hotel information board</div><h3>Print Entertainment Program</h3><p>Guest-friendly programme generated directly from the live Program. Choose a daily or weekly board, then print with or without the responsible entertainer.</p></div>
    <label>Reference date</label><input type="date" id="ib635-date" value="${esc(S.exportDate||todayISO())}">
    <label>Board format</label><div class="ib635-choice"><button type="button" data-ib635-scope="day" class="${S._ib635Scope==='day'?'on':''}">Selected day</button><button type="button" data-ib635-scope="week" class="${S._ib635Scope==='week'?'on':''}">Full week</button></div>
    <div class="ib635-note">The guest version hides staff names. The team version keeps the same board design and adds the responsible entertainer to each programme item.</div>
    <div class="ib635-actions"><button class="btn" id="ib635-guest">${ic('download',16)} Print without entertainer</button><button class="btn ghost" id="ib635-team">${ic('users',16)} Print with entertainer</button></div>
    <button class="btn ghost" id="ib635-close">${t('close')}</button></div>`);
  const scopeBtns=[...wrap.querySelectorAll('[data-ib635-scope]')];
  scopeBtns.forEach(b=>b.onclick=()=>{S._ib635Scope=b.dataset.ib635Scope;scopeBtns.forEach(x=>x.classList.toggle('on',x===b));});
  wrap.querySelector('#ib635-close').onclick=()=>wrap.remove();
  const args=inc=>({scope:S._ib635Scope||'day',date:wrap.querySelector('#ib635-date').value||todayISO(),includeWho:inc});
  wrap.querySelector('#ib635-guest').onclick=()=>printBoard635(args(false));
  wrap.querySelector('#ib635-team').onclick=()=>printBoard635(args(true));
}
window.openInfoBoardExport635=openInfoBoardExport635;
window.printInfoBoardProgram635=printBoard635;

/* Add a dedicated print action to Manager → Program without changing the programme data model. */
const oldManagerActs635=window.managerActsInner||managerActsInner;
window.managerActsInner=managerActsInner=function(){
  const html=oldManagerActs635();
  const tools=`<div class="ib635-launch"><button class="btn ghost" id="ib635-open">${ic('download',16)} Info board program</button><button class="btn ghost" id="ib635-quick">${ic('calendar',16)} Print today's guest board</button></div>`;
  return tools+html;
};

const oldWire635=window.wireCommon;
window.wireCommon=wireCommon=function(){
  oldWire635();
  const open=document.querySelector('#ib635-open');if(open)open.onclick=openInfoBoardExport635;
  const quick=document.querySelector('#ib635-quick');if(quick)quick.onclick=()=>printBoard635({scope:'day',date:todayISO(),includeWho:false});
};

window.AUREA_INFO_BOARD_V635={version:'6.35',print:printBoard635,dayHtml:boardDayHtml635,weekHtml:boardWeekHtml635,items:boardItems635};
})();
