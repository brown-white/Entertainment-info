
(()=>{
'use strict';
if(window.__AUREA_PUBLIC_FIRST_V639)return;
window.__AUREA_PUBLIC_FIRST_V639=true;

const PUBKEY639='publicExperienceV639';
const PUBDEFAULT639={
  exploreEyebrow:'Discover your holiday',
  exploreTitle:'Find your next moment.',
  exploreIntro:'A curated look at what is happening around the hotel. Sign in to unlock the full programme and your personal guest experience.',
  activitiesEyebrow:'Move & play',activitiesTitle:'Activities',
  eventsEyebrow:'After-hours moments',eventsTitle:'Events & entertainment',
  unlockEyebrow:'Your private guest account',unlockTitle:'Unlock the whole holiday.',
  unlockText:'Explore is intentionally only a preview. Your guest account opens everything connected to your actual stay.',
  signinEyebrow:'Your hotel entertainment',signinTitle:'Welcome to your stay.',
  signinText:'Sign in for the complete programme, bookings, tickets, chat and everything connected to your stay.',
  firstEyebrow:'Your hotel entertainment',firstTitle:'Create your holiday access.',
  firstText:'Set up your private guest access in a few simple steps. Your stay, bookings and messages remain connected only to you.',
  exploreCtaTitle:'Explore the entertainment',exploreCtaText:'See a curated programme preview before signing in',
  teamEyebrow:'Team workspace',teamTitle:'Run the day with clarity.',teamText:'Secure access for the Entertainment Team and Manager.'
};
function pubText639(){return {...PUBDEFAULT639,...((S.settings&&S.settings[PUBKEY639])||{})};}
function img639(a){
  const api=window.AUREA_PUBLIC_EXPLORE_V637||{};
  if(typeof api.image==='function')return api.image(a);
  if(a&&a.image)return a.image;
  try{const c=normCat(a||{});if(c==='mEvents'||c==='eParty')return IMG.party||IMG.show;if(c==='eLive'||c==='eBefore'||c==='eAfter')return IMG.live||IMG.show;if(c==='eShow'||c==='eKidsStage')return IMG.show;return IMG.activity||IMG.yoga||IMG.show;}catch(e){return'';}
}
function type639(a){const api=window.AUREA_PUBLIC_EXPLORE_V637||{};if(typeof api.type==='function')return api.type(a);try{const c=normCat(a||{});if(c==='mAdult')return'Activity';if(c==='mEvents')return'Day Event';if(c==='eLive'||c==='eBefore'||c==='eAfter')return'Live Music';if(c==='eShow'||c==='eKidsStage')return'Show';if(c==='eParty')return'Party';}catch(e){}return'Entertainment';}
function acts639(day){const api=window.AUREA_PUBLIC_EXPLORE_V637||{};if(typeof api.dayData==='function')return api.dayData(day);return(S.activities||[]).filter(a=>a&&+a.day===+day).slice().sort((a,b)=>String(a.time||'').localeCompare(String(b.time||'')));}
function design639(day){const api=window.AUREA_PUBLIC_EXPLORE_V637||{};if(typeof api.dayDesign==='function')return api.dayDesign(day);let identity='',theme='';try{const raw=S.settings&&S.settings.guestProgramDays&&S.settings.guestProgramDays[String(day)];if(raw){identity=String(raw.dayName||raw.identity||'').trim();theme=String(raw.restaurantTheme||raw.theme||'').trim();}}catch(e){}return{identity,theme};}
function card639(a){return `<button type="button" class="vx639-card" data-vx637-id="${esc(String(a.id))}"><div class="vx639-img">${img639(a)?`<img src="${esc(img639(a))}" alt="" loading="lazy">`:''}<span class="vx639-type">${esc(type639(a))}</span></div><div class="vx639-body"><h4>${esc(a.name||'')}</h4><p>${esc(a.time||'')}${a.location?' · '+esc(a.location):''}</p></div></button>`;}

function visitorExploreView639(){
  const tx=pubText639(),day=Number.isInteger(window.__PUBLIC_EXPLORE_DAY_V637)?window.__PUBLIC_EXPLORE_DAY_V637:todayIndex();
  const all=acts639(day),normal=all.filter(a=>normCat(a)==='mAdult').slice(0,4),special=all.filter(a=>normCat(a)!=='mAdult').slice(0,4);
  const hero=all.find(a=>a.highlight)||special[0]||normal[0]||all[0]||null;
  const dd=design639(day),days=t('days')||['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],shorts=t('daysShort')||['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],weekday=days[day]||'';
  const st=S.settings||{},moments=all.slice(0,3);
  return `<main class="vx638 vx639 fadein"><div class="vx638-shell">
    <div class="vx639-topline"><div class="vx639-brand"><div class="vx639-mark">${st.logo?`<img src="${esc(st.logo)}" alt="">`:esc(String(st.name||'E').trim().charAt(0).toUpperCase())}</div><div><b>${esc(st.name||'Entertainment')}</b><span>Public programme preview</span></div></div><button type="button" class="vx639-signin" id="vx637-signin-top">Sign in</button></div>
    <section class="vx639-intro"><div class="ey">${esc(tx.exploreEyebrow)}</div><h1>${esc(tx.exploreTitle)}</h1><p>${esc(tx.exploreIntro)}</p></section>
    <nav class="vx639-days" aria-label="Programme days">${shorts.map((d,i)=>`<button type="button" class="vx639-day ${i===day?'on':''}" data-vx637-day="${i}">${esc(d)}</button>`).join('')}</nav>
    ${(dd.identity||dd.theme)?`<section class="vx639-identity"><div><small>${esc(weekday)} identity</small><b>${esc(dd.identity||weekday)}</b></div>${dd.theme?`<div class="rest"><span>Restaurant theme</span><strong>${esc(dd.theme)}</strong></div>`:''}</section>`:''}
    ${hero?`<button type="button" class="vx639-feature" data-vx637-id="${esc(String(hero.id))}">${img639(hero)?`<img src="${esc(img639(hero))}" alt="" loading="eager">`:''}<span class="veil"></span><div class="copy"><span class="badge">${esc(hero.highlight?'Highlight of the day':type639(hero))}</span><h2>${esc(hero.name||'')}</h2><div class="meta"><span>${ic('clock',13)} ${esc(hero.time||'')}</span>${hero.location?`<span>${ic('pin',13)} ${esc(hero.location)}</span>`:''}</div></div></button>`:`<div class="vx639-feature empty"><div class="copy"><span class="badge">Programme preview</span><h2>${esc(weekday)}</h2><p>The public programme for this day is still being prepared. Choose another day or sign in for your complete stay experience.</p></div></div>`}
    ${moments.length?`<div class="vx639-ribbon">${moments.map(a=>`<div><span>${esc(type639(a))}</span><b>${esc(a.name||'')}</b><em>${esc(a.time||'')}</em></div>`).join('')}</div>`:''}
    <section class="vx639-section"><div class="vx639-sechead"><div><small>${esc(tx.activitiesEyebrow)}</small><h3>${esc(tx.activitiesTitle)}</h3></div><span>${normal.length} preview${normal.length===1?'':'s'}</span></div>${normal.length?`<div class="vx639-grid">${normal.map(card639).join('')}</div>`:`<div class="vx639-empty">No daytime activity preview is published for ${esc(weekday)} yet.</div>`}</section>
    <section class="vx639-section"><div class="vx639-sechead"><div><small>${esc(tx.eventsEyebrow)}</small><h3>${esc(tx.eventsTitle)}</h3></div><span>${special.length} preview${special.length===1?'':'s'}</span></div>${special.length?`<div class="vx639-grid">${special.map(card639).join('')}</div>`:`<div class="vx639-empty">No event, live music or show preview is published for ${esc(weekday)} yet.</div>`}</section>
    <section class="vx639-unlock"><div class="ey">${esc(tx.unlockEyebrow)}</div><h3>${esc(tx.unlockTitle)}</h3><p>${esc(tx.unlockText)}</p><div class="vx639-perks"><span>✓ Full weekly programme</span><span>✓ Activity booking</span><span>✓ Event tickets</span><span>✓ Chat with the team</span><span>✓ My bookings</span><span>✓ Personal stay</span></div><button type="button" id="vx637-signin">Sign in / First visit</button></section>
    <div class="vx639-privacy">Public Explore uses programme information only. Private guest, room, booking, ticket and message data never appears here.</div>
  </div></main>`;
}
window.visitorExploreView637=visitorExploreView639;

/* Keep the old detail behavior, but make leaving Explore explicit so render() does not send the user back. */
function openDetail639(a){
  if(!a)return;
  const wrap=baseModal(`<div class="vx637-detail">${img639(a)?`<div class="vx637-detail-photo"><img src="${esc(img639(a))}" alt=""></div>`:''}<span class="vx637-cardtype" style="position:static;display:inline-flex">${esc(type639(a))}</span><h3>${esc(a.name||'')}</h3><div class="meta">${ic('clock',13)} ${esc(a.time||'')}${a.location?' · '+ic('pin',13)+' '+esc(a.location):''}</div>${a.desc?`<p>${esc(a.desc)}</p>`:''}<div class="vx637-detail-lock">Sign in to see the complete programme and booking options for your stay.</div><button class="btn" id="vx639-detail-signin">Sign in to continue</button><button class="btn ghost" id="vx639-detail-close">Close</button></div>`);
  wrap.querySelector('#vx639-detail-close').onclick=()=>wrap.remove();
  wrap.querySelector('#vx639-detail-signin').onclick=()=>{wrap.remove();window.__PUBLIC_EXPLORE_EXITED_V639=true;window.__PUBLIC_EXPLORE_V637=false;loginMode='guest';guestMode='signin';render();};
}
function wireExplore639(){
  const leave=mode=>{window.__PUBLIC_EXPLORE_EXITED_V639=true;window.__PUBLIC_EXPLORE_V637=false;loginMode='guest';guestMode=mode;render();};
  const a=document.querySelector('#vx637-signin-top');if(a)a.onclick=()=>leave('signin');
  const b=document.querySelector('#vx637-signin');if(b)b.onclick=()=>leave('new');
  document.querySelectorAll('[data-vx637-day]').forEach(x=>x.onclick=()=>{window.__PUBLIC_EXPLORE_DAY_V637=+x.dataset.vx637Day;render();});
  document.querySelectorAll('[data-vx637-id]').forEach(x=>x.onclick=()=>openDetail639((S.activities||[]).find(a=>String(a.id)===String(x.dataset.vx637Id))));
}
window.wireVisitorExplore637=wireExplore639;

/* Login view: same authentication controls/IDs, public text comes from Manager settings. */
function loginView639(){
  const st=S.settings||{},tx=pubText639();
  const logo=st.logo?`<img src="${esc(st.logo)}" alt="">`:esc(String(st.name||'E').trim().charAt(0).toUpperCase());
  const languages=`<div class="login638-langs">${LANGS.map(([l,label])=>`<button type="button" data-lang="${l}" class="${S.lang===l?'on':''}">${label}</button>`).join('')}</div>`;
  if(loginMode==='guest'){
    const remRow=`<label class="remrow"><input type="checkbox" id="cb-rem" ${rememberMe?'checked':''}> ${t('rememberMe')}</label>`;
    const dots=`<div class="wz-dots">${[0,1,2,3,4,5,6].map(i=>`<span class="wz-dot ${wiz.step===i?'on':wiz.step>i?'done':''}"></span>`).join('')}</div>`;
    const backLink=wiz.step>0?`<button class="wz-back" id="wz-back">${ic('back',14)} ${t('backStep')}</button>`:'';
    let stepHtml='';
    if(wiz.step===0) stepHtml=`<label>${t('room')}</label><button class="pickfield" id="wz-pick">${wiz.room?`<b>${esc(wiz.room)}</b>`:t('chooseRoom')}<span class="pf-ch">${ic('back',16)}</span></button>`;
    else if(wiz.step===1) stepHtml=`<label>${t('nationality')}</label><button class="pickfield" id="wz-pick">${wiz.nat?`<b>${esc(wiz.nat)}</b>`:t('chooseNat')}<span class="pf-ch">${ic('back',16)}</span></button>`;
    else if(wiz.step===2) stepHtml=`<label>${t('name')}</label><input id="wz-in" value="${esc(wiz.name)}" placeholder="${t('name')}">`;
    else if(wiz.step===3) stepHtml=`<label>${t('phone')}</label><input id="wz-in" inputmode="tel" value="${esc(wiz.phone)}" placeholder="+49 ...">`;
    else if(wiz.step===4) stepHtml=`<label>${t('arrival')}</label><input id="wz-in" type="date" value="${esc(wiz.arr)}">`;
    else if(wiz.step===5) stepHtml=`<label>${t('departure')}</label><input id="wz-in" type="date" value="${esc(wiz.dep)}" min="${esc(wiz.arr)}">`;
    else stepHtml=`<label>${t('user')}</label><input id="wz-user" autocapitalize="none" value="${esc(wiz.username||wiz.room)}"><label>${t('pass')}</label><input id="wz-pass" autocapitalize="none" value="${esc(wiz.password)}" placeholder="••••••">${remRow}`;
    const fields=guestMode==='new'?`${dots}${stepHtml}${wiz.step<6?`<button class="btn" id="wz-next">${t('nextStep')}</button>`:`<button class="btn" id="wz-create">${t('createAccount')}</button>`}${backLink}`:`<label>${t('user')} · ${t('room')}</label><input id="f-room" inputmode="numeric" value="${esc(wiz.room)}" placeholder="4215"><label>${t('pass')}</label><input id="f-gpass" type="password" placeholder="••••••">${remRow}`;
    const ey=guestMode==='new'?tx.firstEyebrow:tx.signinEyebrow,title=guestMode==='new'?tx.firstTitle:tx.signinTitle,desc=guestMode==='new'?tx.firstText:tx.signinText;
    return `<div class="login-wrap login638 fadein"><div class="login638-shell"><div class="login638-top"><div class="login638-brand"><div class="login638-mark">${logo}</div><div class="login638-brandtxt"><b>${esc(st.name||'Entertainment')}</b><span>${esc(st.subtitle||t('appSub'))}</span></div></div><button type="button" class="login638-teamtop" id="btn-teamlink">${ic('users',14)} ${t('otherUsers')}</button></div><section class="login638-copy"><div class="ey">${esc(ey)}</div><h1>${esc(title)}</h1><p>${esc(desc)}</p></section>${languages}<div class="login638-tabs"><button data-gmode="signin" class="${guestMode==='signin'?'on':''}">${t('signin')}</button><button data-gmode="new" class="${guestMode==='new'?'on':''}">${t('firstVisit')}</button></div><div class="login638-card">${fields}${guestMode==='signin'?`<button class="btn" id="btn-login">${t('signin')}</button>`:''}<div class="err" id="login-err"></div>${!REMOTE?`<p class="hint">${t('demoNote')}</p>`:''}</div><button type="button" class="login638-explore" id="btn-public-explore"><span class="ico">${ic('sparkle',18)}</span><span class="txt"><b>${esc(tx.exploreCtaTitle)}</b><small>${esc(tx.exploreCtaText)}</small></span><span class="go">${ic('back',17)}</span></button><div class="login638-trust">Public Explore never shows room, booking, ticket, message or guest-account information.</div></div></div>`;
  }
  return `<div class="login-wrap login638 fadein"><div class="login638-shell"><div class="login638-top"><div class="login638-brand"><div class="login638-mark">${logo}</div><div class="login638-brandtxt"><b>${esc(st.name||'Entertainment')}</b><span>${esc(st.subtitle||t('appSub'))}</span></div></div><button type="button" class="login638-teamtop" id="btn-guestlink">${ic('back',13)} ${t('backToGuest')}</button></div><section class="login638-copy"><div class="ey">${esc(tx.teamEyebrow)}</div><h1>${esc(tx.teamTitle)}</h1><p>${esc(tx.teamText)}</p></section>${languages}<div class="login638-tabs">${['staff','manager'].map(r=>`<button data-role="${r}" class="${loginRole===r?'on':''}">${t(r)}</button>`).join('')}</div><div class="login638-card"><label>${t('user')}</label><input id="f-user" autocapitalize="none" placeholder="${loginRole}"><label>${t('pass')}</label><input id="f-pass" type="password" placeholder="••••"><button class="btn" id="btn-login">${t('signin')}</button><div class="err" id="login-err"></div></div><button type="button" class="login638-explore" id="btn-public-explore"><span class="ico">${ic('sparkle',18)}</span><span class="txt"><b>${esc(tx.exploreCtaTitle)}</b><small>${esc(tx.exploreCtaText)}</small></span><span class="go">${ic('back',17)}</span></button></div></div>`;
}
window.loginView=loginView639;try{loginView=loginView639;}catch(e){}

/* Override login wiring only to remember whether the visitor deliberately left Explore. */
const wireLoginBefore639=window.wireLogin||wireLogin;
window.wireLogin=wireLogin=function(){
  wireLoginBefore639();
  const px=document.querySelector('#btn-public-explore');if(px)px.onclick=()=>{window.__PUBLIC_EXPLORE_EXITED_V639=false;window.__PUBLIC_EXPLORE_V637=true;window.__PUBLIC_EXPLORE_DAY_V637=todayIndex();render();};
};

function setPublicExperienceView639(){
  const x=pubText639();
  const f=(id,label,val,area=false)=>`<label>${esc(label)}</label>${area?`<textarea id="${id}" rows="3">${esc(val)}</textarea>`:`<input id="${id}" value="${esc(val)}">`}`;
  return `<div class="screen fadein">${topBar('Public experience',S.session.name)}${hubBack()}<div class="card" style="padding:16px"><div class="pub639-preview"><small>Live public copy</small><h3>${esc(x.exploreTitle)}</h3><p>${esc(x.exploreIntro)}</p></div><div class="pub639-group"><h4>Explore page</h4>${f('pub-eey','Eyebrow',x.exploreEyebrow)}${f('pub-et','Main headline',x.exploreTitle)}${f('pub-ei','Introduction',x.exploreIntro,true)}${f('pub-aey','Activities eyebrow',x.activitiesEyebrow)}${f('pub-at','Activities title',x.activitiesTitle)}${f('pub-ve','Events eyebrow',x.eventsEyebrow)}${f('pub-vt','Events title',x.eventsTitle)}${f('pub-ue','Unlock eyebrow',x.unlockEyebrow)}${f('pub-ut','Unlock headline',x.unlockTitle)}${f('pub-ui','Unlock message',x.unlockText,true)}</div><div class="pub639-group"><h4>Guest sign in</h4>${f('pub-se','Sign-in eyebrow',x.signinEyebrow)}${f('pub-st','Sign-in headline',x.signinTitle)}${f('pub-si','Sign-in description',x.signinText,true)}${f('pub-fe','First visit eyebrow',x.firstEyebrow)}${f('pub-ft','First visit headline',x.firstTitle)}${f('pub-fi','First visit description',x.firstText,true)}${f('pub-ct','Explore button title',x.exploreCtaTitle)}${f('pub-ci','Explore button text',x.exploreCtaText,true)}</div><div class="pub639-group"><h4>Team access</h4>${f('pub-te','Eyebrow',x.teamEyebrow)}${f('pub-tt','Headline',x.teamTitle)}${f('pub-ti','Description',x.teamText,true)}</div><button class="btn" id="pub639-save" style="margin-top:16px">${t('save')}</button><button class="btn ghost" id="pub639-reset" style="margin-top:8px">Reset default text</button></div></div>`;
}
window.setPublicExperienceView639=setPublicExperienceView639;

const wireBefore639=window.wireCommon;
window.wireCommon=wireCommon=function(){
  wireBefore639();
  const save=document.querySelector('#pub639-save');if(save)save.onclick=async()=>{
    if(save.disabled)return;save.disabled=true;
    const val=id=>String((document.querySelector('#'+id)||{}).value||'').trim();
    const next={
      exploreEyebrow:val('pub-eey'),exploreTitle:val('pub-et'),exploreIntro:val('pub-ei'),activitiesEyebrow:val('pub-aey'),activitiesTitle:val('pub-at'),eventsEyebrow:val('pub-ve'),eventsTitle:val('pub-vt'),unlockEyebrow:val('pub-ue'),unlockTitle:val('pub-ut'),unlockText:val('pub-ui'),signinEyebrow:val('pub-se'),signinTitle:val('pub-st'),signinText:val('pub-si'),firstEyebrow:val('pub-fe'),firstTitle:val('pub-ft'),firstText:val('pub-fi'),exploreCtaTitle:val('pub-ct'),exploreCtaText:val('pub-ci'),teamEyebrow:val('pub-te'),teamTitle:val('pub-tt'),teamText:val('pub-ti')
    };
    try{await DB.saveSettings({...S.settings,[PUBKEY639]:next});toastOk(t('saved'));render();}catch(e){console.error('public text save',e);save.disabled=false;toastErr(t('errSave'));}
  };
  const reset=document.querySelector('#pub639-reset');if(reset)reset.onclick=async()=>{try{await DB.saveSettings({...S.settings,[PUBKEY639]:{...PUBDEFAULT639}});toastOk(t('saved'));render();}catch(e){toastErr(t('errSave'));}};
};

/* If the parser reached V6.39 before the asynchronous DB startup has painted, Explore becomes first screen. If it painted Login already, repaint once. */
if(!S.session && window.__PUBLIC_EXPLORE_EXITED_V639!==true){window.__PUBLIC_EXPLORE_V637=true;window.__PUBLIC_EXPLORE_DAY_V637=Number.isInteger(window.__PUBLIC_EXPLORE_DAY_V637)?window.__PUBLIC_EXPLORE_DAY_V637:todayIndex();setTimeout(()=>{try{if(!S.session)render();}catch(e){console.error('V6.39 public-first render',e)}},0);}

window.AUREA_PUBLIC_FIRST_V639={version:'6.39',view:visitorExploreView639,text:pubText639,settingsKey:PUBKEY639};
})();
