
(()=>{
'use strict';
if(window.__AUREA_PUBLIC_EXPLORE_CODE_V637)return;
window.__AUREA_PUBLIC_EXPLORE_CODE_V637=true;

function vxType637(a){
  const c=normCat(a||{});
  if(c==='mAdult')return'Activity';
  if(c==='mEvents')return'Day Event';
  if(c==='eLive'||c==='eBefore'||c==='eAfter')return'Live Music';
  if(c==='eShow'||c==='eKidsStage')return'Show';
  if(c==='eParty')return'Party';
  return'Entertainment';
}
function vxImage637(a){
  if(a&&a.image)return a.image;
  const c=normCat(a||{});
  if(c==='mEvents'||c==='eParty')return IMG.party||IMG.show;
  if(c==='eLive'||c==='eBefore'||c==='eAfter')return IMG.live||IMG.show;
  if(c==='eShow'||c==='eKidsStage')return IMG.show;
  return IMG.activity||IMG.yoga||IMG.show;
}
function vxDayDesign637(day){
  let identity='',theme='';
  try{
    if(typeof guestProgrammeDayDesignV610==='function'){
      const d=guestProgrammeDayDesignV610(day)||{};identity=String(d.dayName||d.identity||'').trim();theme=String(d.restaurantTheme||'').trim();
    }
  }catch(e){}
  try{
    const raw=S.settings&&S.settings.guestProgramDays&&S.settings.guestProgramDays[String(day)];
    if(raw){identity=identity||String(raw.dayName||raw.identity||'').trim();theme=theme||String(raw.restaurantTheme||raw.theme||'').trim();}
    const info=S.settings&&S.settings.dayInfoOverrides&&S.settings.dayInfoOverrides[String(day)];
    if(info&&Object.prototype.hasOwnProperty.call(info,'theme'))theme=String(info.theme||'').trim();
    if(!theme){const dp=dayPlanFor(day);theme=String(dp&&dp.theme||'').trim();}
  }catch(e){}
  return {identity,theme};
}
function vxActs637(day){
  return (S.activities||[]).filter(a=>a&&+a.day===+day).slice().sort((a,b)=>String(a.time||'').localeCompare(String(b.time||'')));
}
function vxCard637(a,event=false){
  return `<button type="button" class="vx637-card ${event?'vx637-event':''}" data-vx637-id="${esc(String(a.id))}">
    <div class="vx637-cardimg"><img src="${esc(vxImage637(a))}" alt="" loading="lazy"><span class="vx637-cardtype">${esc(vxType637(a))}</span></div>
    <div class="vx637-cardbody"><h4>${esc(a.name||'')}</h4><p>${esc(a.time||'')}${a.location?' · '+esc(a.location):''}</p></div>
  </button>`;
}
function visitorExploreView637(){
  const day=Number.isInteger(window.__PUBLIC_EXPLORE_DAY_V637)?window.__PUBLIC_EXPLORE_DAY_V637:todayIndex();
  const acts=vxActs637(day),normal=acts.filter(a=>normCat(a)==='mAdult').slice(0,3),special=acts.filter(a=>normCat(a)!=='mAdult').slice(0,3);
  const hero=acts.find(a=>a.highlight)||special[0]||normal[0]||acts[0];
  const dd=vxDayDesign637(day),weekday=(t('days')||[])[day]||'';
  const st=S.settings||{};
  return `<main class="vx637 fadein">
    <header class="vx637-top">
      <div class="vx637-brand"><div class="vx637-logo">${st.logo?`<img src="${esc(st.logo)}" alt="">`:esc(String(st.name||'E').trim().charAt(0).toUpperCase())}</div><div><b>${esc(st.name||'Entertainment')}</b><span>Entertainment preview</span></div></div>
      <button type="button" class="vx637-signin" id="vx637-signin-top">Sign in</button>
    </header>

    <section class="vx637-intro">
      <div class="vx637-kicker">Discover your holiday</div>
      <h1>Something is always happening.</h1>
      <p>Explore a preview of the entertainment programme. Sign in to unlock the complete programme, bookings, tickets, chat and your personal stay.</p>
    </section>

    <nav class="vx637-days" aria-label="Programme days">${(t('daysShort')||['Mon','Tue','Wed','Thu','Fri','Sat','Sun']).map((d,i)=>`<button type="button" class="vx637-day ${i===day?'on':''}" data-vx637-day="${i}">${esc(d)}</button>`).join('')}</nav>

    ${(dd.identity||dd.theme)?`<section class="vx637-identity"><div><small>${esc(weekday)} identity</small><b>${esc(dd.identity||weekday)}</b></div>${dd.theme?`<div class="vx637-theme">Restaurant theme<strong>${esc(dd.theme)}</strong></div>`:''}</section>`:''}

    ${hero?`<button type="button" class="vx637-hero" data-vx637-id="${esc(String(hero.id))}"><img src="${esc(vxImage637(hero))}" alt="" loading="eager"><div class="vx637-herotxt"><div class="vx637-badge">${esc(hero.highlight?'Highlight of the day':vxType637(hero))}</div><h2>${esc(hero.name||'')}</h2><p><span>${ic('clock',13)} ${esc(hero.time||'')}</span>${hero.location?`<span>${ic('pin',13)} ${esc(hero.location)}</span>`:''}</p></div></button>`:`<div class="vx637-empty">The programme for ${esc(weekday)} is being prepared.</div>`}

    <section class="vx637-sec"><div class="vx637-sechead"><div><small>Move & play</small><h3>Activities</h3></div><span>${normal.length} preview${normal.length===1?'':'s'}</span></div>${normal.length?`<div class="vx637-scroll">${normal.map(a=>vxCard637(a,false)).join('')}</div>`:`<div class="vx637-empty">No daytime activities in the public preview for this day.</div>`}</section>

    <section class="vx637-sec"><div class="vx637-sechead"><div><small>Moments to remember</small><h3>Events & tonight</h3></div><span>${special.length} preview${special.length===1?'':'s'}</span></div>${special.length?`<div class="vx637-scroll">${special.map(a=>vxCard637(a,true)).join('')}</div>`:`<div class="vx637-empty">No event or show preview for this day yet.</div>`}</section>

    <section class="vx637-lock">
      <small>Unlock your stay</small><h3>There’s more inside.</h3>
      <p>The public Explore area intentionally shows only a preview. Your guest account gives you the complete holiday experience.</p>
      <div class="vx637-unlocks"><span>✓ Full weekly programme</span><span>✓ Book activities</span><span>✓ Buy event tickets</span><span>✓ Chat with the team</span><span>✓ Your bookings</span><span>✓ Personal stay</span></div>
      <button type="button" id="vx637-signin">Sign in / First visit</button>
    </section>
    <div class="vx637-note">Public Explore contains programme information only. Guest and team information stays private.</div>
  </main>`;
}
window.visitorExploreView637=visitorExploreView637;

function vxOpenDetail637(a){
  if(!a)return;
  const wrap=baseModal(`<div class="vx637-detail"><div class="vx637-detail-photo"><img src="${esc(vxImage637(a))}" alt=""></div><span class="vx637-cardtype" style="position:static;display:inline-flex">${esc(vxType637(a))}</span><h3>${esc(a.name||'')}</h3><div class="meta">${ic('clock',13)} ${esc(a.time||'')}${a.location?' · '+ic('pin',13)+' '+esc(a.location):''}</div>${a.desc?`<p>${esc(a.desc)}</p>`:''}<div class="vx637-detail-lock">Sign in to see the complete programme and booking options for your stay.</div><button class="btn" id="vx637-detail-signin">Sign in to continue</button><button class="btn ghost" id="vx637-detail-close">Close</button></div>`);
  wrap.querySelector('#vx637-detail-close').onclick=()=>wrap.remove();
  wrap.querySelector('#vx637-detail-signin').onclick=()=>{wrap.remove();window.__PUBLIC_EXPLORE_V637=false;loginMode='guest';guestMode='signin';render();};
}

function wireVisitorExplore637(){
  const leave=(mode='signin')=>{window.__PUBLIC_EXPLORE_V637=false;loginMode='guest';guestMode=mode;render();};
  const s1=document.querySelector('#vx637-signin-top');if(s1)s1.onclick=()=>leave('signin');
  const s2=document.querySelector('#vx637-signin');if(s2)s2.onclick=()=>leave('new');
  document.querySelectorAll('[data-vx637-day]').forEach(b=>b.onclick=()=>{window.__PUBLIC_EXPLORE_DAY_V637=+b.dataset.vx637Day;render();});
  document.querySelectorAll('[data-vx637-id]').forEach(b=>b.onclick=()=>{const a=(S.activities||[]).find(x=>String(x.id)===String(b.dataset.vx637Id));vxOpenDetail637(a);});
}
window.wireVisitorExplore637=wireVisitorExplore637;
window.AUREA_PUBLIC_EXPLORE_V637={version:'6.37',view:visitorExploreView637,dayData:vxActs637,type:vxType637,image:vxImage637,dayDesign:vxDayDesign637};
})();
