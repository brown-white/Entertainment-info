
(()=>{
'use strict';
if(window.__AUREA_PERFORMANCE_ATTENDANCE_V636)return;
window.__AUREA_PERFORMANCE_ATTENDANCE_V636=true;

const PERFKEY636='performanceAttendanceV636';
const PERFLOCAL636='entapp_performance_attendance_v636';

function readPerfLocal636(){
  try{
    const x=JSON.parse(localStorage.getItem(PERFLOCAL636)||'{}');
    return x&&typeof x==='object'?x:{};
  }catch(e){return{};}
}
function writePerfLocal636(x){
  try{localStorage.setItem(PERFLOCAL636,JSON.stringify(x||{}));}catch(e){}
}
function perfStore636(){
  const remote=(S.settings&&S.settings[PERFKEY636])||{};
  const local=readPerfLocal636();
  const rTime=+remote._updatedAt||0,lTime=+local._updatedAt||0;
  const out=lTime>rTime?local:remote;
  if(out&&Object.keys(out).length)writePerfLocal636(out);
  return {
    _updatedAt:+out._updatedAt||0,
    fees:{...(out.fees||{})},
    attendance:{...(out.attendance||{})}
  };
}
async function savePerfStore636(st){
  st._updatedAt=Date.now();
  writePerfLocal636(st);
  S.settings={...(S.settings||{}),[PERFKEY636]:st};
  await DB.saveSettings(S.settings);
}
function perfType636(a){
  const c=normCat(a);
  if(c==='eShow'||c==='eKidsStage')return'show';
  if(c==='eLive'||c==='eBefore'||c==='eAfter')return'live';
  if(c==='mEvents'||c==='eParty')return'event';
  return'';
}
function perfTypeLabel636(k){return {show:'Show',live:'Live Music',event:'Event'}[k]||'Performance';}
function performanceItems636(){
  return (S.activities||[]).filter(a=>a&&perfType636(a));
}
function perfId636(a){
  return String(a&&a.id!=null?a.id:[
    perfType636(a),String(a&&a.name||'').trim().toLowerCase(),a&&a.day,a&&a.time,a&&a.location
  ].join('|'));
}
function fee636(a){
  const raw=perfStore636().fees[perfId636(a)]||{};
  return {amount:Math.max(0,+raw.amount||0),currency:String(raw.currency||'EGP').toUpperCase()==='USD'?'USD':'EGP'};
}
async function saveFee636(a,amount,currency){
  const st=perfStore636();
  st.fees[perfId636(a)]={amount:Math.max(0,+amount||0),currency:String(currency||'EGP').toUpperCase()==='USD'?'USD':'EGP'};
  await savePerfStore636(st);
}
function perfDate636(mk,d){return mk+'-'+String(d).padStart(2,'0');}
function scheduledDates636(a,mk){
  const n=monthDays(mk),out=[];
  for(let d=1;d<=n;d++)if(weekdayOf(mk,d)===+a.day)out.push(d);
  return out;
}
function isFuturePerf636(mk,d){return perfDate636(mk,d)>hotelDateStr();}
function attendanceKey636(a,mk,d){return mk+'|'+perfId636(a)+'|'+d;}
function perfStatus636(a,mk,d){
  const st=perfStore636(),manual=st.attendance[attendanceKey636(a,mk,d)];
  if(manual==='P'||manual==='A')return manual;
  if(isFuturePerf636(mk,d))return'';
  return'P';
}
async function setPerfStatus636(a,mk,d,status){
  const st=perfStore636(),k=attendanceKey636(a,mk,d);
  if(status==='P'||status==='A')st.attendance[k]=status;else delete st.attendance[k];
  await savePerfStore636(st);
}
function perfCalc636(a,mk){
  const dates=scheduledDates636(a,mk),f=fee636(a);
  let P=0,A=0;
  const occurrences=dates.map(d=>{
    const status=perfStatus636(a,mk,d);
    if(status==='P')P++;
    if(status==='A')A++;
    return {d,date:perfDate636(mk,d),status,future:isFuturePerf636(mk,d)};
  });
  return {a,mk,fee:f,occurrences,scheduled:dates.length,P,A,pay:P*f.amount};
}
function money636(v,c){
  const n=Math.round((+v||0)*100)/100;
  try{return new Intl.NumberFormat('en-US',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2}).format(n)+' '+c;}
  catch(e){return String(n)+' '+c;}
}
function perfMonth636(){return S.performanceMonth636||S.exportMonth||currentAttMonth();}
function perfRows636(mk=perfMonth636()){return performanceItems636().map(a=>perfCalc636(a,mk));}
function perfTeamTotals636(rows){
  const x={scheduled:0,P:0,A:0,EGP:0,USD:0};
  rows.forEach(r=>{x.scheduled+=r.scheduled;x.P+=r.P;x.A+=r.A;x[r.fee.currency]+=r.pay;});
  return x;
}
function weekdayName636(a){return (t('days')&&t('days')[a.day])||'';}

function performanceAttendanceInner636(){
  const mk=perfMonth636(),rows=perfRows636(mk),tot=perfTeamTotals636(rows);
  return `<div class="pf636">
    <div class="pf636-hero">
      <div class="ey">Monthly performance attendance</div>
      <h3>Shows · Events · Live Music</h3>
      <p>Mark every scheduled appearance P = Present or A = Absent. The amount to pay is calculated only from Present appearances × the saved fee.</p>
    </div>

    <label>Attendance month</label>
    <select id="pf636-month">${exportMonthOptions().map(([v,l])=>`<option value="${v}" ${v===mk?'selected':''}>${esc(l)}</option>`).join('')}</select>

    <div class="pf636-summary">
      <div class="pf636-stat"><b>${tot.scheduled}</b><span>Scheduled appearances</span></div>
      <div class="pf636-stat"><b>${tot.P}</b><span>Total Present · P</span></div>
      <div class="pf636-stat"><b>${tot.A}</b><span>Total Absent · A</span></div>
      <div class="pf636-stat"><b>${rows.length}</b><span>Show / event entries</span></div>
    </div>

    <div class="pf636-money">
      <div class="pf636-stat"><b>${money636(tot.EGP,'EGP')}</b><span>Total amount to pay · EGP</span></div>
      <div class="pf636-stat"><b>${money636(tot.USD,'USD')}</b><span>Total amount to pay · USD</span></div>
    </div>

    <div class="pf636-help"><b>Counting rule:</b> every weekly Program item automatically creates its scheduled dates for the selected month. Past dates are Present by default unless you mark them Absent. Future dates stay blank until they happen. An Absent appearance is counted in A and is not included in the amount to pay.</div>

    <div class="pf636-actions">
      <button class="btn" id="pf636-xlsx">${ic('download',16)} Export monthly Excel</button>
      <button class="btn ghost" id="pf636-pdf">${ic('download',16)} PDF / Print attendance</button>
    </div>

    ${rows.length?rows.map(r=>performanceCard636(r)).join(''):`<div class="pf636-empty">No Shows, Events or Live Music are currently saved in the Program.</div>`}
  </div>`;
}
window.performanceAttendanceInner636=performanceAttendanceInner636;

function performanceCard636(r){
  const a=r.a,f=r.fee;
  return `<article class="pf636-card">
    <div class="pf636-head">
      <div>
        <span class="pf636-type">${esc(perfTypeLabel636(perfType636(a)))}</span>
        <div class="pf636-name">${esc(a.name||'')}</div>
        <div class="pf636-meta">${esc(weekdayName636(a))} · ${esc(a.time||'')}${a.location?' · '+esc(a.location):''}</div>
      </div>
      <div class="pf636-fee">
        <div><label>Price / appearance</label><input type="number" min="0" step="0.01" inputmode="decimal" data-pf636-price="${esc(perfId636(a))}" value="${f.amount||''}" placeholder="0"></div>
        <div><label>Currency</label><select data-pf636-currency="${esc(perfId636(a))}"><option value="EGP" ${f.currency==='EGP'?'selected':''}>EGP</option><option value="USD" ${f.currency==='USD'?'selected':''}>USD</option></select></div>
      </div>
    </div>

    <div class="pf636-occ">
      ${r.occurrences.map(o=>`<button type="button" class="pf636-day ${o.status==='P'?'p':o.status==='A'?'a':'future'}" data-pf636-att="${esc(perfId636(a))}|${r.mk}|${o.d}" ${o.future?'disabled':''}><b>${o.d}</b><span>${o.status||'·'}</span></button>`).join('')}
    </div>

    <div class="pf636-totals">
      <div class="pf636-total"><b>${r.scheduled}</b><span>Scheduled</span></div>
      <div class="pf636-total"><b>${r.P}</b><span>Present · P</span></div>
      <div class="pf636-total"><b>${r.A}</b><span>Absent · A</span></div>
      <div class="pf636-total"><b>${money636(f.amount,f.currency)}</b><span>Price each</span></div>
      <div class="pf636-total"><b>${money636(r.pay,f.currency)}</b><span>Amount to pay</span></div>
    </div>
  </article>`;
}

function performanceDataset636(mk=perfMonth636()){
  const rows=perfRows636(mk),n=monthDays(mk),tot=perfTeamTotals636(rows);
  const headers=['Type','Show / Event / Live Music','Weekly schedule','Location','Price','Currency']
    .concat(Array.from({length:n},(_,i)=>String(i+1)))
    .concat(['Total P','Total A','Scheduled','Amount to pay']);
  const out=rows.map(r=>{
    const byDay={};r.occurrences.forEach(o=>byDay[o.d]=o.status);
    return [
      perfTypeLabel636(perfType636(r.a)),
      r.a.name||'',
      weekdayName636(r.a)+' · '+(r.a.time||''),
      r.a.location||'',
      r.fee.amount?r.fee.amount.toFixed(2):'0.00',
      r.fee.currency
    ].concat(Array.from({length:n},(_,i)=>byDay[i+1]||''))
     .concat([String(r.P),String(r.A),String(r.scheduled),r.pay.toFixed(2)]);
  });
  out.push([]);
  out.push(['MONTH TOTAL','','','','','EGP'].concat(Array.from({length:n},()=>'' )).concat([String(tot.P),String(tot.A),String(tot.scheduled),tot.EGP.toFixed(2)]));
  out.push(['MONTH TOTAL','','','','','USD'].concat(Array.from({length:n},()=>'' )).concat([String(tot.P),String(tot.A),String(tot.scheduled),tot.USD.toFixed(2)]));
  return {
    title:'Show Event Attendance — '+monthLabel(mk),
    landscape:true,
    headers,
    rows:out,
    sourceNote:'P = Present · A = Absent. Scheduled dates are generated from the live Program. Amount to pay = Present appearances × price per appearance. EGP and USD totals remain separate.'
  };
}
window.performanceDataset636=performanceDataset636;

function printPerformance636(mk=perfMonth636()){
  const rows=perfRows636(mk),n=monthDays(mk),tot=perfTeamTotals636(rows);
  const e=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const dayHead=Array.from({length:n},(_,i)=>`<th>${i+1}</th>`).join('');
  const body=rows.map(r=>{
    const by={};r.occurrences.forEach(o=>by[o.d]=o.status);
    return `<tr><td class="left"><b>${e(r.a.name)}</b><small>${e(perfTypeLabel636(perfType636(r.a)))} · ${e(weekdayName636(r.a))} · ${e(r.a.time||'')} · ${e(r.a.location||'')}</small></td><td>${e(money636(r.fee.amount,r.fee.currency))}</td>${Array.from({length:n},(_,i)=>`<td class="${by[i+1]==='P'?'p':by[i+1]==='A'?'a':''}">${e(by[i+1]||'')}</td>`).join('')}<td class="sum">${r.P}</td><td class="sum">${r.A}</td><td class="sum">${r.scheduled}</td><td class="money">${e(money636(r.pay,r.fee.currency))}</td></tr>`;
  }).join('');
  const html=`<div class="head"><div><div class="ey">ENTERTAINMENT DEPARTMENT</div><h1>MONTHLY SHOW / EVENT ATTENDANCE</h1><p>${e(monthLabel(mk))} · P = Present · A = Absent</p></div><div class="tot"><b>${tot.P} P</b><b>${tot.A} A</b><span>${tot.scheduled} scheduled</span></div></div>
    <table><thead><tr><th class="left">Show / Event / Live Music</th><th>Price</th>${dayHead}<th>P</th><th>A</th><th>Total</th><th>Amount</th></tr></thead><tbody>${body}</tbody></table>
    <div class="footer"><div><span>Total to pay · EGP</span><b>${e(money636(tot.EGP,'EGP'))}</b></div><div><span>Total to pay · USD</span><b>${e(money636(tot.USD,'USD'))}</b></div></div>`;
  const css=`@page{size:A3 landscape;margin:7mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#291e17;margin:0}.head{display:flex;justify-content:space-between;align-items:end;border-bottom:3px solid #ae7d54;padding-bottom:7px;margin-bottom:8px}.ey{font-size:7px;letter-spacing:.16em;color:#9b6d48;font-weight:800}.head h1{margin:2px 0;font-size:20px}.head p{margin:0;font-size:8px;color:#786b62}.tot{display:flex;gap:7px;align-items:center}.tot b,.tot span{border:1px solid #d8caba;border-radius:8px;padding:6px 8px;font-size:8px}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:6px}th,td{border:1px solid #c9bbad;text-align:center;padding:3px 1px;height:20px}th{background:#eee5da;font-size:5.8px}.left{text-align:left;width:150px;padding-left:5px}.left small{display:block;color:#80736a;font-size:5.5px;margin-top:2px}.p{background:#e0efe4;color:#356344;font-weight:800}.a{background:#f3dfdc;color:#9d493f;font-weight:800}.sum{font-weight:800;background:#f6f0e8;width:23px}.money{font-weight:800;width:54px}.footer{display:flex;justify-content:flex-end;gap:8px;margin-top:8px}.footer div{border:1px solid #c9bbad;border-radius:8px;padding:6px 10px}.footer span{display:block;font-size:6px;color:#75685f}.footer b{font-size:11px}`;
  const w=window.open('','_blank');if(!w){toastErr('Could not open the print window.');return;}
  w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Monthly Performance Attendance</title><style>'+css+'</style></head><body>'+html+'<scr'+'ipt>setTimeout(function(){window.print();},350);<\/scr'+'ipt></body></html>');
  w.document.close();
}

const buildBefore636=window.buildDataset;
window.buildDataset=buildDataset=function(kind){
  if(kind==='performanceatt')return performanceDataset636(S.exportMonth||perfMonth636());
  return buildBefore636(kind);
};

const wireBefore636=window.wireCommon;
window.wireCommon=wireCommon=function(){
  wireBefore636();

  const m=document.querySelector('#pf636-month');
  if(m)m.onchange=()=>{S.performanceMonth636=m.value;S.exportMonth=m.value;render();};

  const saveFeeFrom636=async(id)=>{
    const a=performanceItems636().find(x=>perfId636(x)===id);if(!a)return;
    const price=document.querySelector(`[data-pf636-price="${CSS.escape(id)}"]`);
    const curr=document.querySelector(`[data-pf636-currency="${CSS.escape(id)}"]`);
    if(!price||!curr)return;
    try{await saveFee636(a,price.value,curr.value);render();toastOk('Performance price saved');}
    catch(e){console.error('performance fee save',e);toastErr(t('errSave'));}
  };
  document.querySelectorAll('[data-pf636-price]').forEach(el=>el.onchange=()=>saveFeeFrom636(el.dataset.pf636Price));
  document.querySelectorAll('[data-pf636-currency]').forEach(el=>el.onchange=()=>saveFeeFrom636(el.dataset.pf636Currency));

  document.querySelectorAll('[data-pf636-att]').forEach(btn=>btn.onclick=async()=>{
    if(btn.disabled)return;
    const parts=String(btn.dataset.pf636Att).split('|');
    const d=+parts.pop(),mk=parts.pop(),id=parts.join('|');
    const a=performanceItems636().find(x=>perfId636(x)===id);if(!a)return;
    const now=perfStatus636(a,mk,d),next=now==='P'?'A':'P';
    btn.disabled=true;
    try{await setPerfStatus636(a,mk,d,next);render();}
    catch(e){console.error('performance attendance save',e);btn.disabled=false;toastErr(t('errSave'));}
  });

  const x=document.querySelector('#pf636-xlsx');
  if(x)x.onclick=async()=>{
    const mk=perfMonth636(),ds=performanceDataset636(mk);
    try{await smartExportExcel620([ds],'show-event-attendance-'+mk);toastOk(t('saved'));}
    catch(e){console.error('performance excel',e);toastErr(t('errSave'));}
  };
  const p=document.querySelector('#pf636-pdf');if(p)p.onclick=()=>printPerformance636(perfMonth636());
};

setTimeout(()=>{
  try{
    const local=readPerfLocal636(),remote=(S.settings&&S.settings[PERFKEY636])||{};
    if((+local._updatedAt||0)>(+remote._updatedAt||0))DB.saveSettings({...S.settings,[PERFKEY636]:local}).catch(()=>{});
  }catch(e){}
},1800);

window.AUREA_PERFORMANCE_ATTENDANCE_V636={
  version:'6.36',items:performanceItems636,calculate:perfCalc636,dataset:performanceDataset636,
  fee:fee636,saveFee:saveFee636,status:perfStatus636,setStatus:setPerfStatus636,print:printPerformance636
};
})();
