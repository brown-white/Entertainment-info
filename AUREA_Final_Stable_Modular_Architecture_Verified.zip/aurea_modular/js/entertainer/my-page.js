/* ================= ENTERTAINER: MY PAGE ================= */
const REQ_TYPES=[["dayoff","reqDayOff"],["problem","reqProblem"],["cannot","reqCannot"],["other","reqOther"]];
function reqTypeLabel(k){ const f=REQ_TYPES.find(x=>x[0]===k); return f?t(f[1]):k; }
function myStaffReqs(){
  const me=S.session?S.session.username:"";
  return (S.staffReqs||[]).filter(r=>r.username===me);
}
function myFeedbackList(){
  const me=S.session?S.session.username:"";
  return (S.feedback||[]).filter(f=>String(f.by_user||"")===me);
}
/* The entertainer's own page: attendance, ratings and a way to reach the manager */
function myPageView(){
  const mk=currentAttMonth(), me=S.session;
  const user=(S.users||[]).find(u=>u.username===me.username)||{username:me.username,display_name:me.name,number:me.number};
  const tot=attTotals(user,mk);
  const fb=myFeedbackList();
  const avg=fb.length ? Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10 : 0;
  const reqs=myStaffReqs();
  const n=monthDays(mk);
  const strip=Array.from({length:n},(_,i)=>{
    const d=i+1;
    if(isFutureDay(mk,d)) return `<span class="ms-d future" title="${d}">·</span>`;
    if(notYetHired(user,mk,d) || leftBefore(user,mk,d)) return `<span class="ms-d notyet" title="${d}">N</span>`;
    const st=attStatus(user,mk,d);
    return `<span class="ms-d s-${st}" title="${d}">${st}</span>`;
  }).join("");
  return `<div class="screen fadein">
    ${topBar(t("myAttendance"), monthLabel(mk))}
    <div class="att-head">
      <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button>
      <b class="att-month">${esc(monthLabel(mk))}</b>
      <button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button>
    </div>
    <div class="card attsum">
      <div class="as-row">
        <div class="as-n p"><b>${tot.P}</b><span class="mini">${t("workDays")}</span></div>
        <div class="as-n o"><b>${tot.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${tot.A}</b><span class="mini">${t("attTotalsA")}</span></div>
      </div>
      <div class="ms-strip">${strip}</div>
      <p class="mini" style="margin:8px 0 0">${t("attLegend")}</p>
    </div>

    <div class="sec"><h3>${ic("star",18)} ${t("myFeedback")}</h3>
      ${fb.length?`<div class="card">
        <div class="mf-top"><b class="mf-avg">${avg}</b><span class="mini">${t("avgRate")} · ${fb.length}</span></div>
        ${fb.slice(0,6).map(f=>`<div class="mf-row">
          <span class="mf-rate">${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</span>
          <span class="mf-c">${esc(f.comment||"")}</span>
          <span class="mini">${esc(f.nationality||"")} · ${fmtDate(f.created_at)}</span>
        </div>`).join("")}
      </div>`:`<div class="card"><p class="mini" style="padding:4px 2px">${t("noMyFeedback")}</p></div>`}
    </div>

    <div class="sec"><h3>${ic("chat",18)} ${t("myRequestsTeam")}</h3>
      <button class="btn" id="sr-new" style="margin-bottom:10px">${ic("plus",16)} ${t("askManager")}</button>
      ${reqs.length?`<div class="card">${reqs.map(r=>`
        <div class="sr-row">
          <div class="sr-mid"><b>${esc(reqTypeLabel(r.type))}</b>
            <span>${esc(r.detail||"")}</span>
            ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
            ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):r.status==="done"?t("done"):t("statusNew")}</span>
        </div>`).join("")}</div>`:""}
    </div>
  </div>`;
}
/* An entertainer can ask the manager to change their profile — they cannot edit it. */
function openProfileChangeModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("changeRequest")}</h3>
    <p class="mini">${t("profileReadOnly")}</p>
    <label>${t("whatToChange")}</label><textarea id="pc-d" rows="4"></textarea>
    <button class="btn" id="pc-go">${t("send")}</button>
    <button class="btn ghost" id="pc-x">${t("close")}</button>`);
  wrap.querySelector("#pc-x").onclick=()=>wrap.remove();
  wrap.querySelector("#pc-go").onclick=async ()=>{
    const detail=wrap.querySelector("#pc-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:"other", detail:t("changeRequest")+": "+detail, the_date:"", status:"new"});
      wrap.remove(); toastOk(t("reqSentMgr")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openStaffReqModal(){
  const wrap=baseModal(`
    <h3>${ic("chat",20)} ${t("newTeamReq")}</h3>
    <label>${t("taskType")}</label>
    <select id="sr-type">${REQ_TYPES.map(([k,lbl])=>`<option value="${k}">${t(lbl)}</option>`).join("")}</select>
    <label>${t("reqDetail")}</label><textarea id="sr-d" rows="3"></textarea>
    <label>${t("reqDateOpt")}</label><input id="sr-date" placeholder="${esc(t("reqDateOpt"))}">
    <button class="btn" id="sr-send">${t("send")}</button>
    <button class="btn ghost" id="sr-x">${t("close")}</button>`);
  wrap.querySelector("#sr-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sr-send").onclick=async ()=>{
    const detail=wrap.querySelector("#sr-d").value.trim();
    if(!detail){ toastWarn(t("fieldRequired")); return; }
    try{
      await DB.addStaffReq({username:S.session.username, display_name:S.session.name||"",
        type:wrap.querySelector("#sr-type").value, detail,
        the_date:wrap.querySelector("#sr-date").value.trim(), status:"new"});
      wrap.remove(); toastOk(t("reqSent")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
