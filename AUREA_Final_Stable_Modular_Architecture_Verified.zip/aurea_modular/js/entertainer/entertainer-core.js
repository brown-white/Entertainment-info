/* ---------------- staff ---------------- */
function staffView(){
  const todayIdx=todayIndex();
  // My Work Day is the entertainer's home screen
  const STAFF_TABS=["workday","mypage","quiz","gallery","weather","bus","today","week","bookings","tasks","chat","feedback","teaminfo"];
  if(!S.tab || (!STAFF_TABS.includes(S.tab) && !String(S.tab).startsWith("cp:") && !String(S.tab).startsWith("emp:"))) S.tab="workday";
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="workday") return myWorkDayView();
  if(S.tab==="mypage") return myPageView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="bus") return busView();
  if(S.tab==="today"){
    const acts=S.activities.filter(a=>a.day===todayIdx);
    const hl=acts.find(a=>a.highlight);
    const mine=acts.filter(a=>canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">
      ${topBar(t("schedule"),t("days")[todayIdx]+" · "+S.session.name)}
      ${heroCard(hl)}
      ${statusLegend()}
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${listByCat(acts.filter(a=>a!==hl),{staff:true,showBook:false,showFav:false})}</div>
    </div>`;
  }
  if(S.tab==="week") return browseView(t("program"));
  if(S.tab==="tasks"){
    const me=S.session.username;
    const mine=S.tasks.filter(x=>!x.assigned_to || x.assigned_to===me);
    const rk=rankingRows();
    return `<div class="screen fadein">
      ${topBar(t("myTasks"),S.session.name)}
      ${rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("rank")}</h3><div class="card">
        ${rk.map((r,i)=>`<div class="booking-line"><span>${rankBadge(i)} ${esc(r.u.display_name||r.u.username)}${r.u.username===me?" ✦":""}</span><span class="pill">${r.points} ${t("points")}</span></div>`).join("")}
      </div></div>`:""}
      ${mine.length?`<div class="card">${mine.map(x=>taskLine(x,false)).join("")}</div>`:`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`}
      ${myActsCard()}
    </div>`;
  }
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chatManager"),S.session.name)}
      ${threadView("staff:"+S.session.username,"guest")}
    </div>`;
  }
  if(S.tab==="feedback") return staffFeedbackView();
  if(S.tab==="teaminfo") return teamInfoView();
  return bookingsView(t("guestsBooked"));
}
function taskStatusChip(x,clickAttr){
  const map={open:[t("statusNew"),"res"],accepted:[t("accepted"),"res"],still:[t("still"),"res"],done:[x.was_still?t("done")+" · "+t("late"):t("done"),"ok"],cant:[t("cantDo"),"full"]};
  const [lb,cls]=map[x.status]||map.open;
  return `<${clickAttr?"button":"span"} class="chip ${cls}" ${clickAttr?clickAttr+'="'+x.id+'"':""}>${lb}</${clickAttr?"button":"span"}>`;
}
/* ================= TASK MANAGEMENT =================
   Flow: New → Accepted → In progress → Completed → Verified.
   Old statuses (open/accepted/still/done) still work. */
const TASK_FLOW=["new","accepted","progress","completed","verified"];
const PRIORITIES=[["low","prLow"],["normal","prNormal"],["high","prHigh"],["urgent","prUrgent"]];
function taskStatus(x){
  const st=String(x.status||"new");
  if(st==="open") return "new";
  if(st==="still") return "progress";
  if(st==="done") return "completed";
  return TASK_FLOW.includes(st)?st:"new";
}
function taskStatusLabel(st){
  return {new:t("stNew"),accepted:t("stAccepted"),progress:t("stProgress"),
    completed:t("stCompleted"),verified:t("stVerified")}[st]||st;
}
function taskPriorityLabel(p){ const f=PRIORITIES.find(x=>x[0]===p); return f?t(f[1]):t("prNormal"); }
function taskIsOverdue(x){
  const st=taskStatus(x);
  if(st==="completed"||st==="verified") return false;
  if(!x.due) return false;
  const d=new Date(String(x.due).replace(" ","T"));
  return !isNaN(d.getTime()) && d.getTime() < Date.now();
}
function taskNextStatus(st){
  const i=TASK_FLOW.indexOf(st);
  return (i<0||i>=TASK_FLOW.length-1)?null:TASK_FLOW[i+1];
}
function taskActionLabel(st){
  return {new:t("acceptTask"),accepted:t("startTask"),progress:t("completeTask"),
    completed:t("verifyTask")}[st]||"";
}
function taskHistory(x){ try{ return Array.isArray(x.history)?x.history:JSON.parse(x.history||"[]"); }catch(e){ return []; } }
function taskComments(x){ try{ return Array.isArray(x.comments)?x.comments:JSON.parse(x.comments||"[]"); }catch(e){ return []; } }
async function advanceTask(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const cur=taskStatus(x), next=taskNextStatus(cur);
  if(!next) return;
  const stamp=new Date().toISOString();
  const patch={status:next};
  if(next==="accepted")  patch.accepted_at=stamp;
  if(next==="progress")  patch.started_at=stamp;
  if(next==="completed") patch.completed_at=stamp;
  if(next==="verified")  patch.verified_at=stamp;
  patch.history=taskHistory(x).concat([{at:stamp, by:S.session.name||S.session.username||"", to:next}]);
  try{ await DB.updateTask(id,patch); toastOk(t("saved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
async function addTaskComment(id, text){
  const x=S.tasks.find(y=>y.id==id); if(!x||!text) return;
  const c={at:new Date().toISOString(), by:S.session.name||S.session.username||"", text};
  try{ await DB.updateTask(id,{comments:taskComments(x).concat([c])}); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* Full task detail — everything about one task in one place */
function openTaskModal(id){
  const x=S.tasks.find(y=>y.id==id); if(!x) return;
  const st=taskStatus(x), over=taskIsOverdue(x);
  const u=S.users.find(u=>u.username===x.assigned_to);
  const hist=taskHistory(x), cmts=taskComments(x);
  const isMgr=S.session.role==="manager";
  const canAdvance = isMgr || (x.assigned_to===S.session.username) || !x.assigned_to;
  const next=taskNextStatus(st);
  const wrap=baseModal(`
    <h3>${ic(TASK_ICON[x.type]||"check",20)} ${esc(x.title)}</h3>
    <div class="tk-badges">
      <span class="tk-st s-${st}">${taskStatusLabel(st)}</span>
      <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
      ${over?`<span class="tk-over">${t("overdue")}</span>`:""}
    </div>
    ${x.desc?`<p class="mini" style="margin-top:8px">${esc(x.desc)}</p>`:""}
    <div class="tk-meta">
      ${x.assigned_to?`<span>${mi("user")}${esc((u&&u.display_name)||x.assigned_to)}</span>`:`<span>${mi("users")}${t("allTeam")}</span>`}
      ${x.location?`<span>${mi("pin")}${esc(x.location)}</span>`:""}
      ${x.due?`<span>${mi("clock")}${esc(String(x.due).replace("T"," "))}</span>`:""}
      ${x.created_by?`<span>${mi("pen")}${t("createdBy")}: ${esc(x.created_by)}</span>`:""}
    </div>
    ${x.proof_url?`<img class="tk-proof" src="${esc(x.proof_url)}" alt="">`:""}
    ${(st==="progress"||st==="completed")&&canAdvance?`
      <div class="photo-pick" style="margin-top:12px"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("taskProof")}</b><span class="mini">${t("uploadPhoto")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>`:""}
    ${next&&canAdvance?`<button class="btn" id="tk-next">${taskActionLabel(st)}</button>`:""}
    <label style="margin-top:12px">${t("taskComments")}</label>
    ${cmts.length?`<div class="card tk-cmts">${cmts.map(cm=>`<div class="tk-cm">
      <b>${esc(cm.by)}</b><span>${esc(cm.text)}</span><span class="mini">${fmtDate(cm.at)}</span></div>`).join("")}</div>`:""}
    <div class="time-row"><input id="tk-cm" placeholder="${esc(t("addComment"))}">
      <button class="btn sm" id="tk-cmadd" type="button">${ic("send",14)}</button></div>
    ${hist.length?`<label style="margin-top:12px">${t("taskHistory")}</label>
      <div class="card tk-hist">${hist.map(h=>`<div class="tk-h">
        <span>${taskStatusLabel(h.to)}</span><span class="mini">${esc(h.by)} · ${fmtDate(h.at)}</span></div>`).join("")}</div>`:""}
    <button class="btn ghost" id="tk-x" style="margin-top:12px">${t("close")}</button>`);
  wrap.querySelector("#tk-x").onclick=()=>wrap.remove();
  let proof=x.proof_url||"";
  wirePhotoPicker(wrap, ()=>proof, async v=>{
    proof=v; try{ await DB.updateTask(x.id,{proof_url:v}); }catch(e){}
  });
  const nx=wrap.querySelector("#tk-next");
  if(nx) nx.onclick=async ()=>{ wrap.remove(); await advanceTask(x.id); };
  const ca=wrap.querySelector("#tk-cmadd");
  if(ca) ca.onclick=async ()=>{
    const el=wrap.querySelector("#tk-cm"); const v=el?el.value.trim():"";
    if(!v) return; wrap.remove(); await addTaskComment(x.id, v);
  };
}
function taskLine(x,managerMode){
  const u=S.users.find(u=>u.username===x.assigned_to);
  const assignee = x.assigned_to ? ((u&&u.display_name)||x.assigned_to) : t("allTeam");
  const due=x.due?String(x.due).replace("T"," "):"";
  const info=`<span style="min-width:0">${ic(TASK_ICON[x.type]||"check",15)} <b>${esc(x.title)}</b>
    <br><span class="mini">${taskTypeLabel(x.type)}${x.location?` · ${mi("pin")}${esc(x.location)}`:""}</span>
    ${x.desc?`<br><span class="mini">${esc(x.desc)}</span>`:""}
    ${due?`<br><span class="mini">${mi("clock")}${esc(due)}</span>`:""}
    ${managerMode?`<br><span class="mini">${mi("user")}${esc(assignee)}</span>`:""}</span>`;
  const st2=taskStatus(x), over2=taskIsOverdue(x);
  const badges=`<br><span class="tk-inline">
    <span class="tk-st s-${st2}">${taskStatusLabel(st2)}</span>
    <span class="tk-pr p-${esc(x.priority||"normal")}">${taskPriorityLabel(x.priority||"normal")}</span>
    ${over2?`<span class="tk-over">${t("overdue")}</span>`:""}</span>`;
  if(managerMode){
    return `<div class="booking-line ${over2?"row-over":""}">${info.replace("</span>", badges+"</span>")}
      <span style="display:flex;gap:6px;align-items:center;flex:none">
        <button class="btn sm ghost" data-taskopen="${x.id}">${ic("pen",14)}</button>
        ${taskStatusChip(x,"data-taskdone")}
        <button class="btn sm warn" data-taskdel="${x.id}">${ic("close",14)}</button>
      </span></div>`;
  }
  let actions="";
  if(x.status==="open") actions=`<button class="btn sm" data-taccept="${x.id}">${t("accept")}</button>`;
  else if(x.status==="accepted"||x.status==="still"){
    actions=`<button class="btn sm" data-tsdone="${x.id}">${t("done")}</button>
      ${x.status==="accepted"?`<button class="btn sm ghost" data-tstill="${x.id}">${t("still")}</button>`:""}
      <button class="btn sm warn" data-tcant="${x.id}">${t("cantDo")}</button>`;
  } else actions=taskStatusChip(x,null);
  return `<div class="booking-line">${info}
    <span style="display:flex;gap:6px;align-items:center;flex:none;flex-wrap:wrap;justify-content:flex-end;max-width:46%">${actions}</span></div>`;
}
function myActsCard(){
  const mine=S.activities.filter(a=>canSeeGuests(a));
  if(!mine.length) return "";
  const byDay={};
  mine.forEach(a=>{ (byDay[a.day]=byDay[a.day]||[]).push(a); });
  const order=Object.keys(byDay).map(Number).sort((a,b)=>a-b);
  return `<div class="sec"><h3>${ic("calendar",18)} ${t("myActs")}</h3>
    <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
    <div class="card">${order.map(d=>`
      <div class="booking-line"><span style="min-width:0"><b>${t("daysShort")[d]}</b>
        ${byDay[d].sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>`<br><span class="mini">${mi("clock")}${esc(a.time)} · ${esc(a.name)}</span>`).join("")}
      </span></div>`).join("")}</div>
  </div>`;
}
function busMinutes(tm){
  const m=String(tm||"").match(/(\d{1,2})[:.\s](\d{2})/);
  return m?(+m[1])*60+(+m[2]):-1;
}
/* next upcoming bus (today) among a list of bus rows */
function nextBusId(list){
  const now=new Date(); const cur=now.getHours()*60+now.getMinutes();
  let best=null, bestMin=Infinity;
  list.forEach(b=>{ const mins=busMinutes(b.time); if(mins>=cur && mins<bestMin){ bestMin=mins; best=b.id; } });
  return best;
}
function busColumn(dir, iconRot){
  const list=(S.buses||[]).filter(b=>b.direction===dir)
    .sort((a,b)=>busMinutes(a.time)-busMinutes(b.time));
  const nxt=nextBusId(list);
  const isManager=S.session.role==="manager";
  return `<div class="bus-col">
    <div class="bus-col-head"><span class="bus-ic" style="transform:scaleX(${iconRot})">${ic("bus",20)}</span>
      <b>${t(dir==="toHotel"?"busToHotel":"busToHouse")}</b></div>
    ${list.length?`<div class="bus-rows">${list.map(b=>{
      const isNext=b.id===nxt;
      return `<div class="bus-row ${isNext?"next":""}" ${isManager?`data-busedit="${b.id}"`:""}>
        <span class="bus-time">${esc(b.time)}</span>
        <span class="bus-mid">${b.note?`<span class="bus-note">${esc(b.note)}</span>`:""}${isNext?`<span class="bus-next">${t("busNextHint")}</span>`:""}</span>
        ${isManager?`<span class="bus-go">${ic("pen",15)}</span>`:""}
      </div>`;
    }).join("")}</div>`:`<p class="mini bus-empty">—</p>`}
    ${isManager?`<button class="btn sm ghost bus-add" data-busadd="${dir}">${ic("plus",15)} ${t("addBus")}</button>`:""}
  </div>`;
}
/* ================= EMPLOYEE PROFILE ================= */
/* profile pictures: the main photo first, then any extra ones */
function empPics(u){
  let extra=[];
  try{ extra=Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]"); }catch(e){ extra=[]; }
  return [u.photo].concat(extra).filter(Boolean);
}
function employeeRecord(u){
  const mk=currentAttMonth();
  const att=attTotals(u,mk);
  const myTasks=(S.tasks||[]).filter(x=>x.assigned_to===u.username);
  const doneT=myTasks.filter(x=>["completed","verified","done"].includes(String(x.status))).length;
  const lateT=myTasks.filter(x=>taskIsOverdue(x)).length;
  const acts=(S.activities||[]).filter(a=>String(a.entertainer||"").toLowerCase()===String(u.username||"").toLowerCase());
  const fb=(S.feedback||[]).filter(f=>String(f.by_user||"")===u.username);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  const points=doneT*10 - lateT*5 + Math.round(avg*4);
  return {u, att, myTasks, doneT, lateT, acts, fb, avg, points,
    onTime: myTasks.length?Math.round((myTasks.length-lateT)/myTasks.length*100):100};
}
function employeeRank(u){
  const rows=(S.users||[]).filter(x=>x.role==="staff").map(x=>employeeRecord(x))
    .sort((a,b)=>b.points-a.points);
  const i=rows.findIndex(r=>r.u.username===u.username);
  return {pos:i+1, total:rows.length};
}
function employeeView(username){
  const u=(S.users||[]).find(x=>x.username===username);
  if(!u) return `<div class="screen fadein">${topBar(t("employeeProfile"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=employeeRecord(u), rank=employeeRank(u);
  const isMgr=S.session.role==="manager";
  const isSelf=S.session.role==="staff" && S.session.username===u.username;
  const full=isMgr||isSelf;                 // guests see the public part only
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  const line=(lb,v)=>v?`<div class="ep-row"><span class="mini">${lb}</span><b>${esc(v)}</b></div>`:"";
  return `<div class="screen fadein">
    ${topBar(esc(u.display_name||u.username), u.number?("#"+u.number):"")}
    <button class="crumb" id="crumb-team">${ic("back",15)} ${isMgr?t("teamAccounts"):t("teamPage")}</button>
    <div class="card g3-head">
      <div class="g3-av${u.photo?" haspic":""}" ${u.photo?`data-pv="emp|0"`:""}>${u.photo?`<img src="${esc(u.photo)}" alt="">`:esc(String(u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${esc(u.position||roleForNumber(u.number||0))}${u.number?" · #"+u.number:""}</span>
        <span class="mini">${u.active===false?t("inactiveAcc"):t("activeAcc")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span>
      </div>
    </div>
    ${full?`<div class="g3-stats">
      ${stat(r.att.P, t("workDays"))}
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.doneT, t("tasksDone"))}
      ${stat(r.onTime+"%", t("onTime"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
      ${stat(r.points, t("pointsLbl"))}
      ${stat(rank.pos?("#"+rank.pos):"—", t("rankLbl"))}
      ${stat(r.att.A, t("attTotalsA"))}
    </div>`:`<div class="g3-stats">
      ${stat(r.acts.length, t("assignedActs"))}
      ${stat(r.fb.length?r.avg:"—", t("guestRatings"))}
    </div>`}
    ${empPics(u).length?`<div class="sec">${photoStrip(empPics(u),"emp")}</div>`:""}
    <div class="sec"><h3>${ic("user",17)} ${t("employeeProfile")}</h3>
      <div class="card ep-card">
        ${full?line(t("employeeId"), u.employee_id):""}
        ${line(t("positionLbl2"), u.position)}
        ${full?line(t("user"), u.username):""}
        ${full?line(t("phoneLbl2"), u.phone):""}
        ${full?line(t("whatsappLbl2"), u.whatsapp):""}
        ${line(t("instagramLbl2"), u.instagram)}
        ${line(t("languagesLbl"), u.languages)}
        ${line(t("skills"), u.skills)}
        ${full?line(t("hireDate"), u.hire_date):""}
        ${line(t("nationality"), u.nationality)}
      </div>
    </div>
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("assignedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}${a.location?" · "+esc(a.location):""}</span></div>`).join("")}</div></div>`:""}
    ${full&&r.myTasks.length?`<div class="sec"><h3>${ic("check",17)} ${t("tasks")}</h3>
      <div class="card">${r.myTasks.slice(0,8).map(x=>`<div class="g3-row" data-taskopen="${x.id}">
        <b>${esc(x.title)}</b><span class="mini">${taskStatusLabel(taskStatus(x))}${taskIsOverdue(x)?" · "+t("overdue"):""}</span></div>`).join("")}</div></div>`:""}
    ${isMgr?`<div class="sec">
      <button class="btn" data-uedit="${u.id}">${ic("pen",16)} ${t("editUser")}</button>
      <button class="btn ghost" data-ususpend="${u.id}">${ic(u.active===false?"bell":"belloff",16)} ${u.active===false?t("activate"):t("suspend")}</button>
    </div>`
    :`<div class="sec">
      <p class="mini" style="margin-bottom:8px">${t("profileReadOnly")}</p>
      ${S.session.role==="staff"&&S.session.username===u.username
        ? `<button class="btn ghost" id="prof-req">${ic("chat",15)} ${t("requestChange")}</button>` : ""}
    </div>`}
  </div>`;
}
