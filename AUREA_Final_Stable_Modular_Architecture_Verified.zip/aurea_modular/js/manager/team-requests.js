/* ================= MANAGER: TEAM REQUESTS ================= */
function teamRequestsInner(){
  const list=(S.staffReqs||[]);
  if(!list.length) return `<div class="card"><p class="mini" style="padding:4px 2px">${t("noTeamReqs")}</p></div>`;
  return `<div class="card">${list.map(r=>`
    <div class="sr-row">
      <div class="sr-mid"><b>${esc(r.display_name||r.username)} · ${esc(reqTypeLabel(r.type))}</b>
        <span>${esc(r.detail||"")}</span>
        ${r.the_date?`<span class="mini">${esc(r.the_date)}</span>`:""}
        <span class="mini">${fmtDate(r.created_at)}</span>
        ${r.reply?`<span class="mini sr-reply">${ic("chat",12)} ${esc(r.reply)}</span>`:""}</div>
      ${r.status==="new"?`<span class="sr-acts">
          <button class="btn sm" data-reqok="${r.id}">${t("reqApprove")}</button>
          <button class="btn sm ghost" data-reqno="${r.id}">${t("reqDecline")}</button>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`
        :`<span class="sr-acts">
          <span class="sr-st st-${esc(r.status)}">${r.status==="ok"?t("statusOk"):r.status==="no"?t("statusNo"):t("done")}</span>
          <button class="btn sm ghost warn" data-sreqdel="${r.id}" aria-label="${t("delete")}">${ic("trash",14)}</button>
        </span>`}
    </div>`).join("")}</div>`;
}
async function answerStaffReq(id, status){
  const wrap=baseModal(`
    <h3>${status==="ok"?t("reqApprove"):t("reqDecline")}</h3>
    <label>${t("reqReply")}</label><textarea id="ar-r" rows="3"></textarea>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-x">${t("close")}</button>`);
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-go").onclick=async ()=>{
    try{
      await DB.updateStaffReq(id,{status, reply:wrap.querySelector("#ar-r").value.trim()});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
