/* ================= TEAM ATTENDANCE =================
   P = present · O = day off · A = absent
   Normal days are worked out from the duty plan, so only real
   exceptions are stored. Tapping a cell cycles P -> O -> A -> auto. */
const ATT_CYCLE=["P","O","A","V"];
function monthKey(d){ d=d||hotelNow(); return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0"); }
function currentAttMonth(){ return S.attMonth || monthKey(hotelNow()); }
function monthDays(mk){
  const [y,m]=mk.split("-").map(Number);
  return new Date(y, m, 0).getDate();               // last day of that month
}
function monthLabel(mk){
  const [y,m]=mk.split("-").map(Number);
  const names=t("months");
  const nm=(Array.isArray(names)&&names[m-1])?names[m-1]:String(m);
  return nm+" "+y;
}
function dateStr(mk,day){ return mk+"-"+String(day).padStart(2,"0"); }
function shiftMonth(mk,delta){
  const [y,m]=mk.split("-").map(Number);
  const d=new Date(y, m-1+delta, 1);
  return monthKey(d);
}
function weekdayOf(mk,day){
  const [y,m]=mk.split("-").map(Number);
  return (new Date(y,m-1,day).getDay()+6)%7;        // 0 = Monday
}
/* what the plan says for this person on this date */
/* Before someone's hire date they simply were not employed — that shows as N
   and is never counted as present, day off or absent. */
/* Someone who left the hotel keeps every day they worked; days after their
   leaving date are blank, and their number is free for the next person. */
function hasLeft(user){ return !!(user && (user.archived || String(user.left_date||"").trim())); }
function leftBefore(user, mk, day){
  const ld=String(user && user.left_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(ld)) return false;
  return dateStr(mk,day) > ld;
}
function notYetHired(user, mk, day){
  const hd=String(user && user.hire_date || "").slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(hd)) return false;
  return dateStr(mk,day) < hd;
}
function attAuto(user, mk, day){
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return "N";
  if(isAttOnly(user)) return "P";        // not on the weekly rota — she marks them herself
  let num=user.number; if(!num && user.role==="manager") num=1;
  if(!num) return "P";
  const dp=dayPlanFor(weekdayOf(mk,day));
  return dp.off.includes(num) ? "O" : "P";
}
/* the value actually shown: a manual mark wins, otherwise the plan */
/* Days in the future have not happened yet — they are blank, never counted. */
function isFutureDay(mk, day){ return dateStr(mk,day) > hotelDateStr(); }
function daysSoFar(mk){
  const n=monthDays(mk);
  const today=hotelDateStr();
  if(mk > today.slice(0,7)) return 0;           // month not started
  if(mk < today.slice(0,7)) return n;           // month already finished
  return Math.min(n, +today.slice(8,10));        // current month -> up to today
}
function attStatus(user, mk, day){
  if(notYetHired(user,mk,day)) return "N";      // had not started yet
  if(leftBefore(user,mk,day)) return "N";       // already finished
  if(isFutureDay(mk,day)){
    /* nothing is assumed about a future day, but a holiday she has already
       planned should be visible */
    const dfut=dateStr(mk,day);
    const planned=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===dfut);
    return planned ? planned.status : "";
  }
  const d=dateStr(mk,day);
  const row=S.staffAtt.find(x=>x.username===user.username && String(x.date).slice(0,10)===d);
  return row ? row.status : attAuto(user,mk,day);
}
function attIsManual(user, mk, day){
  const d=dateStr(mk,day);
  return S.staffAtt.some(x=>x.username===user.username && String(x.date).slice(0,10)===d);
}
/* one tap: P -> O -> A -> automatic */
function attNext(user, mk, day){
  if(isFutureDay(mk,day)) return undefined;     // cannot mark a day that has not come
  if(notYetHired(user,mk,day) || leftBefore(user,mk,day)) return undefined; // not employed that day
  if(!attIsManual(user,mk,day)) return "P";
  const cur=attStatus(user,mk,day);
  const i=ATT_CYCLE.indexOf(cur);
  return (i<0 || i===ATT_CYCLE.length-1) ? null : ATT_CYCLE[i+1];
}
/* Totals across the whole team for the month */
function attMonthTotals(mk){
  const team=attTeamFor(mk); const sum={P:0,O:0,A:0,V:0,N:0};
  team.forEach(u=>{ const x=attTotals(u,mk); sum.P+=x.P; sum.O+=x.O; sum.A+=x.A; sum.V+=x.V; sum.N+=x.N; });
  return {...sum, people:team.length, days:daysSoFar(mk),
          working:sum.P, avg:team.length?Math.round(sum.P/team.length*10)/10:0};
}
/* The attendance sheet still lists people who left, so their record is kept.
   Everywhere else they are gone. */
function attTeam(){ return attTeamFor(currentAttMonth()); }
function attTeamFor(mk){
  return (S.users||[]).filter(u=>{
      if(u.role!=="staff" && u.role!=="manager" && u.role!=="attendance") return false;
      const hd=String(u.hire_date||"").slice(0,7);
      if(hd && hd>mk) return false;               // had not started in that month
      if(!hasLeft(u)) return true;
      const ld=String(u.left_date||"").slice(0,7);
      return !ld || ld>=mk;                       // show them in the months they worked
    })
    .slice().sort((a,b)=>(a.number||99)-(b.number||99));
}
/* month totals per person */
function attTotals(user, mk){
  const n=daysSoFar(mk); const c={P:0,O:0,A:0,V:0,N:0,days:n};
  for(let d=1;d<=n;d++){ const st=attStatus(user,mk,d); if(c[st]!==undefined) c[st]++; }
  c.days=n-c.N;                                  // only days they were actually employed
  return c;
}
function monthAttInner(){
  const __vacBtn=`<div class="att-tools">
    <button class="btn sm ghost" id="att-vac">${ic("sun",15)} ${t("setVacation")}</button>
    <button class="btn sm ghost" id="att-only">${ic("user",15)} ${t("addAttOnly")}</button>
  </div>`;
  const mk=currentAttMonth(), n=monthDays(mk), team=attTeamFor(mk);
  const todayMk=monthKey(hotelNow()), todayD=hotelNow().getDate();
  const head=Array.from({length:n},(_,i)=>{
    const d=i+1,wd=weekdayOf(mk,d),isToday=(mk===todayMk&&d===todayD);
    return `<th class="${wd>=5?"we":""} ${isToday?"td":""}">${d}<span>${(t("daysShort")[wd]||"").slice(0,2)}</span></th>`;
  }).join("");
  const rows=team.map(u=>{
    const tot=attTotals(u,mk),attTag=isAttOnly(u)?` <span class="att-only-tag">${t("attOnlyTag")}</span>`:"";
    const cells=Array.from({length:n},(_,i)=>{
      const d=i+1;
      if(notYetHired(u,mk,d)||leftBefore(u,mk,d))return `<td><span class="att-c notyet">N</span></td>`;
      if(isFutureDay(mk,d)){
        const st=attStatus(u,mk,d);
        return st?`<td><span class="att-c s-${st} planned" title="${esc(t("plannedAhead"))}">${st}</span></td>`:`<td><span class="att-c future">·</span></td>`;
      }
      const st=attStatus(u,mk,d),manual=attIsManual(u,mk,d);
      return `<td><button class="att-c s-${st} ${manual?"man":"auto"}" data-satt="${esc(u.username)}|${mk}|${d}" title="${esc(t("att"+st)||st)}">${st}</button></td>`;
    }).join("");
    return `<tr><th class="att-name${isAttOnly(u)?" tapname":""}"${isAttOnly(u)?` data-attedit="${u.id}"`:""}><b>${esc(u.display_name||u.username)}</b><span class="mini">${u.number?"#"+u.number:""}${attTag}</span></th>${cells}
      <td class="att-tot"><span class="s-P">${tot.P}</span></td><td class="att-tot"><span class="s-O">${tot.O}</span></td><td class="att-tot"><span class="s-A">${tot.A}</span></td><td class="att-tot"><span class="s-V">${tot.V}</span></td></tr>`;
  }).join("");
  const mt=attMonthTotals(mk);
  return `${__vacBtn}<div class="att-head">
    <button class="iconbtn" id="att-prev" aria-label="${t("prevMonth")}">${ic("back",18)}</button><b class="att-month">${esc(monthLabel(mk))}</b><button class="iconbtn att-next" id="att-next" aria-label="${t("nextMonth")}">${ic("back",18)}</button></div>
    <p class="mini att-legend">P = present · O = day off · A = absent · V = vacation · N = not counted</p>
    ${team.length?`<div class="card attsum"><span class="type-meta">${t("monthTotals")}</span>
      <div class="as-row as-row-v625">
        <div class="as-n total"><b>${mt.people}</b><span class="mini">${t("totalTeam")}</span></div>
        <div class="as-n p"><b>${mt.working}</b><span class="mini">${t("workingToday")} days</span></div>
        <div class="as-n o"><b>${mt.O}</b><span class="mini">${t("attTotalsO")}</span></div>
        <div class="as-n a"><b>${mt.A}</b><span class="mini">${t("attTotalsA")}</span></div>
        <div class="as-n vac"><b>${mt.V}</b><span class="mini">${t("attV")} days</span></div>
      </div>
      <p class="mini" style="margin:10px 0 0">${t("avgPerPerson")}: <b>${mt.avg}</b> ${t("workDays").toLowerCase()} · ${t("countedDays")}: <b>${mt.days}</b>/${monthDays(mk)}</p></div>`:""}
    ${team.length?`<div class="att-scroll"><table class="att-table"><thead><tr><th class="att-name"></th>${head}<th class="att-tot">P</th><th class="att-tot">O</th><th class="att-tot">A</th><th class="att-tot">V</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<div class="card"><p class="mini">—</p></div>`}
    <button class="btn" id="att-export" style="margin-top:14px">${ic("download",16)} ${t("attExport")}</button>`;
}

