/* ================= PAGE DESIGNER (blocks) =================
   The manager builds pages from blocks, like a simple website builder.
   Every block carries its own style, so no code is ever needed. */
const BLOCK_TYPES=[
  ["heading","blkHeading","pen"],["text","blkText","clipboard"],["image","blkImage","sparkle"],
  ["gallery","blkGallery","grid"],["button","blkButton","check"],["card","blkCard","clipboard"],
  ["list","blkList","check"],["video","blkVideo","sparkle"],["map","blkMap","pin"],
  ["divider","blkDivider","grid"],["spacer","blkSpacer","grid"]
];
const FONT_CHOICES=[["display","fontElegant"],["body","fontModern"]];
function blockDefaults(type){
  const base={id:"b"+Date.now()+Math.floor(Math.random()*999), type,
    align:"left", size:"m", color:"", bg:"", bold:false, font:"body"};
  if(type==="heading") return {...base, text:"", size:"l", font:"display"};
  if(type==="text")    return {...base, text:""};
  if(type==="image")   return {...base, url:"", caption:""};
  if(type==="gallery") return {...base, urls:[]};
  if(type==="button")  return {...base, text:"", url:"", shape:"round", size:"m", align:"center"};
  if(type==="card")    return {...base, title:"", text:"", url:""};
  if(type==="list")    return {...base, text:""};
  if(type==="video")   return {...base, url:""};
  if(type==="map")     return {...base, text:""};
  if(type==="spacer")  return {...base, size:"m"};
  return base;
}
const SIZE_PX={heading:{s:"20px",m:"26px",l:"32px",xl:"40px"},
  text:{s:"13px",m:"15px",l:"17px",xl:"20px"},
  spacer:{s:"10px",m:"22px",l:"40px",xl:"64px"}};
function blockStyle(b){
  const st=[];
  if(b.align) st.push("text-align:"+(b.align==="right"?"end":b.align==="center"?"center":"start"));
  if(b.color) st.push("color:"+b.color);
  if(b.bold) st.push("font-weight:700");
  if(b.font==="display") st.push("font-family:var(--font-display)");
  return st.join(";");
}
function ytEmbed(url){
  const m=String(url||"").match(/(?:youtu\.be\/|v=|embed\/)([A-Za-z0-9_-]{6,})/);
  return m?("https://www.youtube.com/embed/"+m[1]):"";
}
/* Draws one block for the real page */
function renderBlock(b, ix, pageKey){
  const st=blockStyle(b);
  const wrapBg=b.bg?` style="background:${esc(b.bg)};border-radius:var(--r-lg);padding:14px"`:"";
  switch(b.type){
    case "heading":
      return `<div class="pb-b"${wrapBg}><div class="pb-h" style="${st};font-size:${SIZE_PX.heading[b.size]||"26px"}">${esc(b.text||"")}</div></div>`;
    case "text":
      return `<div class="pb-b"${wrapBg}><p class="pb-t" style="${st};font-size:${SIZE_PX.text[b.size]||"15px"}">${esc(b.text||"")}</p></div>`;
    case "image":
      return b.url?`<div class="pb-b"${wrapBg}><img class="pb-img" src="${esc(b.url)}" alt="" loading="lazy" data-pvsingle="${esc(b.url)}">
        ${b.caption?`<p class="mini" style="${st};margin-top:6px">${esc(b.caption)}</p>`:""}</div>`:"";
    case "gallery":
      return (b.urls&&b.urls.length)?`<div class="pb-b"${wrapBg}>${photoStrip(b.urls,pageKey+"-g"+ix)}</div>`:"";
    case "button": {
      const shape={round:"var(--r-md)",pill:"999px",square:"6px"}[b.shape||"round"];
      const pad={s:"9px 16px",m:"13px 22px",l:"17px 30px"}[b.size||"m"];
      const fs={s:"13px",m:"15px",l:"17px"}[b.size||"m"];
      const align=b.align==="left"?"flex-start":b.align==="right"?"flex-end":"center";
      const bg=b.bg||"";
      return `<div class="pb-b" style="display:flex;justify-content:${align}">
        <a class="pb-btn" ${b.url?`href="${esc(b.url)}" target="_blank" rel="noopener"`:""}
          style="border-radius:${shape};padding:${pad};font-size:${fs}${bg?";background:"+esc(bg):""}${b.color?";color:"+esc(b.color):""}">${esc(b.text||"")}</a></div>`;
    }
    case "card":
      return `<div class="pb-b"><div class="card pb-card"${b.bg?` style="background:${esc(b.bg)}"`:""}>
        ${b.title?`<b style="${st}">${esc(b.title)}</b>`:""}
        ${b.text?`<p style="${st}">${esc(b.text)}</p>`:""}
        ${b.url?`<a class="pb-btn sm" href="${esc(b.url)}" target="_blank" rel="noopener">${t("openLink")}</a>`:""}
      </div></div>`;
    case "list": {
      const items=String(b.text||"").split("\n").map(x=>x.trim()).filter(Boolean);
      return items.length?`<div class="pb-b"${wrapBg}><ul class="pb-list" style="${st}">
        ${items.map(i=>`<li>${esc(i)}</li>`).join("")}</ul></div>`:"";
    }
    case "video": {
      const emb=ytEmbed(b.url);
      return emb?`<div class="pb-b"><div class="pb-video"><iframe src="${esc(emb)}" frameborder="0"
        allow="accelerometer;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen></iframe></div></div>`:"";
    }
    case "map": {
      const q=encodeURIComponent(b.text||"");
      return b.text?`<div class="pb-b"><a class="pb-btn" href="https://www.google.com/maps/search/?api=1&query=${q}"
        target="_blank" rel="noopener">${ic("pin",15)} ${esc(b.text)}</a></div>`:"";
    }
    case "divider": return `<div class="pb-b"><hr class="pb-hr"></div>`;
    case "spacer":  return `<div style="height:${SIZE_PX.spacer[b.size]||"22px"}"></div>`;
  }
  return "";
}
function renderBlocks(blocks, pageKey){
  const list=Array.isArray(blocks)?blocks:[];
  if(!list.length) return "";
  return list.map((b,i)=>renderBlock(b,i,pageKey||"pg")).join("");
}
/* ================= PAGE EDITOR SCREEN ================= */
function pbState(){
  if(!S.pb) S.pb={role:"guest", pageId:null, page:null};
  return S.pb;
}
function pbFindPage(role,id){ return (customPages(role)||[]).find(p=>p.id===id)||null; }
function pbOpen(role,id){
  const st=pbState();
  st.role=role;
  if(id){
    const p2=pbFindPage(role,id);
    st.pageId=id;
    st.page=p2?JSON.parse(JSON.stringify(p2)):null;
  } else {
    st.pageId=null;
    st.page={id:"p"+Date.now(), title:"", kind:"page", icon:"pin", url:"", text:"", blocks:[]};
  }
  if(st.page && !Array.isArray(st.page.blocks)) st.page.blocks=[];
  S.tab="pagedesign"; render();
}
async function pbSave(){
  const st=pbState();
  if(!st.page) return;
  if(!String(st.page.title||"").trim()){ toastWarn(t("fieldRequired")); return; }
  const list=(customPages(st.role)||[]).slice();
  const i=list.findIndex(x=>x.id===st.page.id);
  if(i>=0) list[i]=st.page; else list.push(st.page);
  const menu={...(S.settings.menu||{})};
  menu[st.role]={...menuConf(st.role), custom:list};
  try{
    await DB.saveSettings({...S.settings, menu});
    toastOk(t("pbSaved"));
    S.tab="builder"; render();
  }catch(e){ toastErr(t("errSave")); }
}
function pbAdd(type){
  const st=pbState(); if(!st.page) return;
  st.page.blocks.push(blockDefaults(type)); render();
}
function pbMove(id,dir){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const j=i+dir; if(j<0||j>=b.length) return;
  b.splice(j,0,b.splice(i,1)[0]); render();
}
function pbDup(id){
  const st=pbState(); const b=st.page.blocks;
  const i=b.findIndex(x=>x.id===id); if(i<0) return;
  const copy=JSON.parse(JSON.stringify(b[i]));
  copy.id="b"+Date.now()+Math.floor(Math.random()*999);
  b.splice(i+1,0,copy); render();
}
async function pbDel(id){
  if(!await confirmAction({question:t("delBlock"),danger:true})) return;
  const st=pbState();
  st.page.blocks=st.page.blocks.filter(x=>x.id!==id); render();
}
function pageDesignView(){
  const st=pbState();
  if(!st.page) return `<div class="screen fadein">${topBar(t("pageBuilder"),"")}<div class="empty">${t("none")}</div></div>`;
  const pg=st.page;
  return `<div class="screen fadein">
    ${topBar(pg.title||t("pbNewPage"), t("pageBuilder"))}
    <button class="crumb" id="crumb-pb">${ic("back",15)} ${t("setMenus")}</button>
    <div class="card" style="padding:14px">
      <label>${t("pbTitle")}</label><input id="pb-title" value="${esc(pg.title||"")}">
      <label>${t("pbWho")}</label>
      <select id="pb-role">
        ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
          `<option value="${k}" ${st.role===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="pb-addbar">
      <span class="type-meta">${t("pbAddBlock")}</span>
      <div class="pb-types">
        ${BLOCK_TYPES.map(([k,lb,icn])=>`<button class="pb-type" data-pbadd="${k}">
          <span>${ic(icn,16)}</span>${t(lb)}</button>`).join("")}
      </div>
    </div>
    ${pg.blocks.length?pg.blocks.map((b,i)=>`
      <div class="pb-edit">
        <div class="pb-eh">
          <b>${t((BLOCK_TYPES.find(x=>x[0]===b.type)||[,"blkText"])[1])}</b>
          <span class="pb-eacts">
            <button class="bd-b" data-pbup="${b.id}" ${i===0?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b down" data-pbdown="${b.id}" ${i===pg.blocks.length-1?"disabled":""}>${ic("back",13)}</button>
            <button class="bd-b" data-pbdup="${b.id}">${ic("plus",13)}</button>
            <button class="bd-b warn" data-pbdel="${b.id}">${ic("trash",13)}</button>
          </span>
        </div>
        ${pbBlockFields(b)}
        <div class="pb-prev">${renderBlock(b,i,"prev")||`<span class="mini">—</span>`}</div>
      </div>`).join("")
      :`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`}
    <button class="btn" id="pb-save" style="margin-top:14px">${ic("check",16)} ${t("save")}</button>
  </div>`;
}
/* the controls for one block */
function pbBlockFields(b){
  const sel=(id,val,opts)=>`<select data-pbf="${b.id}|${id}">${opts.map(([k,lb])=>
    `<option value="${k}" ${String(val)===k?"selected":""}>${t(lb)}</option>`).join("")}</select>`;
  const txt=(id,val,ph)=>`<input data-pbf="${b.id}|${id}" value="${esc(val||"")}" placeholder="${esc(ph||"")}">`;
  const area=(id,val,ph)=>`<textarea data-pbf="${b.id}|${id}" rows="3" placeholder="${esc(ph||"")}">${esc(val||"")}</textarea>`;
  const col=(id,val)=>`<input type="color" data-pbf="${b.id}|${id}" value="${esc(val||"#3E2A1E")}">`;
  const alignSel=sel("align",b.align,[["left","alignLeft"],["center","alignCenter"],["right","alignRight"]]);
  const sizeSel=sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"],["xl","fsXl"]]);
  let content="";
  if(b.type==="heading"||b.type==="text") content=area("text",b.text,t("pbContent"));
  else if(b.type==="list") content=area("text",b.text,t("listItems"));
  else if(b.type==="image") content=`${pbImageField(b,"url")}${txt("caption",b.caption,t("photoCaption"))}`;
  else if(b.type==="gallery") content=pbGalleryField(b);
  else if(b.type==="button") content=`${txt("text",b.text,t("blkButton"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="card") content=`${txt("title",b.title,t("infoTitle"))}${area("text",b.text,t("pbContent"))}${txt("url",b.url,t("btnLink"))}`;
  else if(b.type==="video") content=txt("url",b.url,t("videoUrl"));
  else if(b.type==="map") content=txt("text",b.text,t("mapAddr"));
  let style="";
  if(["heading","text","list","card"].includes(b.type))
    style=`<div class="row2"><div><label>${t("fontSizeB")}</label>${sizeSel}</div>
      <div><label>${t("alignLbl")}</label>${alignSel}</div></div>
      <div class="row2"><div><label>${t("fontFamilyB")}</label>${sel("font",b.font,FONT_CHOICES)}</div>
      <div><label>${t("colorLbl")}</label>${col("color",b.color)}</div></div>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:14px;color:var(--ink)">
        <input type="checkbox" style="width:auto" data-pbc="${b.id}|bold" ${b.bold?"checked":""}> ${t("boldLbl")}</label>`;
  else if(b.type==="button")
    style=`<div class="row2"><div><label>${t("btnShape")}</label>
        ${sel("shape",b.shape,[["round","shapeRound"],["pill","shapePill"],["square","shapeSquare"]])}</div>
      <div><label>${t("btnSize")}</label>${sel("size",b.size,[["s","sizeS"],["m","sizeM"],["l","sizeL"]])}</div></div>
      <div class="row2"><div><label>${t("alignLbl")}</label>${alignSel}</div>
      <div><label>${t("bgLbl")}</label>${col("bg",b.bg)}</div></div>`;
  else if(b.type==="spacer") style=`<label>${t("fontSizeB")}</label>${sizeSel}`;
  else if(b.type==="image") style=`<label>${t("alignLbl")}</label>${alignSel}`;
  return content+style;
}
function pbImageField(b,key){
  return `<div class="pedit" id="pbi-${b.id}">
      ${b[key]?`<div class="pedit-it"><img src="${esc(b[key])}" alt="">
        <button class="pedit-rm" type="button" data-pbimgrm="${b.id}|${key}">${ic("close",13)}</button></div>`:""}
    </div>
    <button class="btn sm ghost" type="button" data-pbimgadd="${b.id}|${key}">${ic("plus",14)} ${t("addPhoto")}</button>`;
}
function pbGalleryField(b){
  return `<div class="pedit">
      ${(b.urls||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
        <button class="pedit-rm" type="button" data-pbgrm="${b.id}|${ix}">${ic("close",13)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" type="button" data-pbgadd="${b.id}">${ic("plus",14)} ${t("addPhotos")}</button>`;
}
/* ================= MENU BUILDER SCREEN ================= */
function builderRole(){ return S.sub.builder || "guest"; }
async function saveMenuConf(role, patch){
  const menu={...(S.settings.menu||{})};
  menu[role]={...menuConf(role), ...patch};
  try{ await DB.saveSettings({...S.settings, menu}); toastOk(t("builderSaved")); render(); }
  catch(e){ toastErr(t("errSave")); }
}
/* The page the app opens on, per role — the manager chooses it in the builder. */
function defaultTabFor(role){
  const conf=menuConf(role)||{};
  const want=conf.start;
  if(want){
    const ok=navGroups(role).flatMap(g=>g.items).some(i=>i[0]===want);
    if(ok) return want;
  }
  return role==="manager" ? "dash" : (role==="staff" ? "workday" : "home");
}
function builderView(){
  const role=builderRole();
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{};
  const base=navGroupsBase(role);
  const items=base.flatMap(g=>g.items);
  const order=(conf.order&&conf.order.length)?conf.order:items.map(i=>i[0]);
  const sorted=items.slice().sort((a,b)=>{
    const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
    return (ia<0?999:ia)-(ib<0?999:ib);
  });
  return `<div class="screen fadein">
    ${topBar(t("builderTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 12px">${t("builderHint")}</p>
    <div class="bd-roles">
      ${[["guest","roleGuest"],["staff","roleStaff"],["manager","roleManager"]].map(([k,lb])=>
        `<button class="bd-role ${role===k?"on":""}" data-bdrole="${k}">${t(lb)}</button>`).join("")}
    </div>
    <label style="margin-top:4px">${t("startPage")}</label>
    <select id="bd-start">
      ${sorted.filter(it=>!hidden.includes(it[0])).map(it=>
        `<option value="${esc(it[0])}" ${conf.start===it[0]?"selected":""}>${esc(names[it[0]]||it[2])}</option>`).join("")}
    </select>
    <p class="mini" style="margin:-4px 0 12px">${t("startPageHint")}</p>
    <div class="bd-sec-head">${t("secTitles")}</div>
    <p class="mini" style="margin:-2px 0 8px">${t("secTitlesHint")}</p>
    <div class="card bd-list">
      ${base.filter(g=>g.key).map(g=>`<div class="bd-it">
        <span class="bd-ic">${ic("grid",17)}</span>
        <span class="bd-nm">${esc((conf.gnames||{})[g.key]||g.head)}${(conf.gnames||{})[g.key]?` <i>${esc(g.head)}</i>`:""}</span>
        <span class="bd-acts">
          <button class="bd-b" data-bdgname="${esc(g.key)}" aria-label="${t("renameGroup")}">${ic("pen",14)}</button>
        </span></div>`).join("")}
    </div>
    <div class="bd-sec-head">${t("menu")}</div>
    <div class="card bd-list">
      ${sorted.map((it,i)=>{
        const id=it[0], off=hidden.includes(id);
        return `<div class="bd-it ${off?"off":""}">
          <span class="bd-ic">${ic(it[1],17)}</span>
          <span class="bd-nm">${esc(names[id]||it[2])}${names[id]?` <i>${esc(it[2])}</i>`:""}</span>
          <span class="bd-acts">
            <button class="bd-b" data-bdup="${esc(id)}" aria-label="${t("moveUp")}" ${i===0?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b down" data-bddown="${esc(id)}" aria-label="${t("moveDown")}" ${i===sorted.length-1?"disabled":""}>${ic("back",14)}</button>
            <button class="bd-b" data-bdname="${esc(id)}" aria-label="${t("renameItem")}">${ic("pen",14)}</button>
            <button class="bd-b ${off?"":"on"}" data-bdhide="${esc(id)}" aria-label="${t("hideItem")}">${ic(off?"belloff":"bell",14)}</button>
          </span>
        </div>`;
      }).join("")}
    </div>
    <button class="btn" id="bd-add" style="margin-top:14px">${ic("plus",16)} ${t("addLink")}</button>
    ${(conf.custom&&conf.custom.length)?`<div class="card" style="margin-top:12px">
      ${conf.custom.map(pg=>`<div class="bd-it">
        <span class="bd-ic">${ic(pg.icon||"pin",17)}</span>
        <span class="bd-nm">${esc(pg.title)}<i>${pg.kind==="link"?t("kindLink"):t("kindPage")}</i></span>
        <span class="bd-acts">
          <button class="bd-b" data-bdedit="${esc(pg.id)}">${ic("pen",14)}</button>
          <button class="bd-b warn" data-bddel="${esc(pg.id)}">${ic("trash",14)}</button>
        </span></div>`).join("")}
    </div>`:""}
    <button class="btn ghost" id="bd-reset" style="margin-top:12px">${ic("back",15)} ${t("resetMenu")}</button>
  </div>`;
}
function moveMenuItem(id, dir){
  const role=builderRole(), conf=menuConf(role);
  const items=navGroupsBase(role).flatMap(g=>g.items).map(i=>i[0]);
  let order=(conf.order&&conf.order.length)?conf.order.slice():items.slice();
  items.forEach(k=>{ if(!order.includes(k)) order.push(k); });
  const i=order.indexOf(id); if(i<0) return;
  const j=i+dir; if(j<0||j>=order.length) return;
  order.splice(j,0,order.splice(i,1)[0]);
  saveMenuConf(role,{order});
}
function toggleMenuItem(id){
  const role=builderRole(), conf=menuConf(role);
  const hidden=(conf.hidden||[]).slice();
  const i=hidden.indexOf(id);
  if(i>=0) hidden.splice(i,1); else hidden.push(id);
  saveMenuConf(role,{hidden});
}
function openRenameModal(id){
  const role=builderRole(), conf=menuConf(role);
  const base=navGroupsBase(role).flatMap(g=>g.items).find(i=>i[0]===id);
  const cur=(conf.names||{})[id]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameItem")}</h3>
    <p class="mini">${esc(base?base[2]:id)}</p>
    <input id="rn-v" value="${esc(cur)}" placeholder="${esc(base?base[2]:"")}">
    <button class="btn" id="rn-go">${t("save")}</button>
    <button class="btn ghost" id="rn-x">${t("close")}</button>`);
  wrap.querySelector("#rn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#rn-go").onclick=()=>{
    const names={...(conf.names||{})};
    const v=wrap.querySelector("#rn-v").value.trim();
    if(v) names[id]=v; else delete names[id];
    wrap.remove(); saveMenuConf(role,{names});
  };
}
/* Rename a whole menu section — the grey heading above a group of items. */
function openGroupRenameModal(gkey){
  const role=builderRole(), conf=menuConf(role);
  const g=navGroupsBase(role).find(x=>x.key===gkey);
  const cur=(conf.gnames||{})[gkey]||"";
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("renameGroup")}</h3>
    <p class="mini">${esc(g?g.head:gkey)}</p>
    <input id="gn-v" value="${esc(cur)}" placeholder="${esc(g?g.head:"")}">
    <button class="btn" id="gn-go">${t("save")}</button>
    <button class="btn ghost" id="gn-x">${t("close")}</button>`);
  wrap.querySelector("#gn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#gn-go").onclick=()=>{
    const gnames={...(conf.gnames||{})};
    const v=wrap.querySelector("#gn-v").value.trim();
    if(v) gnames[gkey]=v; else delete gnames[gkey];
    wrap.remove(); saveMenuConf(role,{gnames});
  };
}
function openCustomPageModal(pgId){
  const role=builderRole(), conf=menuConf(role);
  const list=(conf.custom||[]);
  const pg=pgId?list.find(x=>x.id===pgId):null;
  const p2=pg||{id:"p"+Date.now(),title:"",kind:"page",url:"",text:"",icon:"pin"};
  const wrap=baseModal(`
    <h3>${ic("plus",20)} ${t("addLink")}</h3>
    <label>${t("linkTitle")}</label><input id="cp-t" value="${esc(p2.title)}">
    <label>${t("linkKind")}</label>
    <select id="cp-k">
      <option value="page" ${p2.kind==="page"?"selected":""}>${t("kindPage")}</option>
      <option value="link" ${p2.kind==="link"?"selected":""}>${t("kindLink")}</option>
    </select>
    <label>${t("linkUrl")}</label><input id="cp-u" value="${esc(p2.url||"")}" placeholder="https://...">
    <label>${t("linkText")}</label><textarea id="cp-x" rows="4">${esc(p2.text||"")}</textarea>
    <button class="btn" id="cp-go">${t("save")}</button>
    ${pg?`<button class="btn warn" id="cp-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=()=>{
    const title=wrap.querySelector("#cp-t").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const url=wrap.querySelector("#cp-u").value.trim();
    if(url && !/^https:\/\//i.test(url)){ toastErr(t("errHttps")); return; }
    const rec={...p2, title, kind:wrap.querySelector("#cp-k").value, url,
      text:wrap.querySelector("#cp-x").value};
    const next=list.filter(x=>x.id!==rec.id).concat([rec]);
    wrap.remove(); saveMenuConf(role,{custom:next});
  };
  const del=wrap.querySelector("#cp-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    wrap.remove(); saveMenuConf(role,{custom:list.filter(x=>x.id!==p2.id)});
  };
}
/* a page the manager created */
function customPageView(id){
  const role=S.session.role;
  const pg=customPages(role).find(p=>p.id===id);
  if(!pg) return `<div class="screen fadein">${topBar(t("customPage"),"")}<div class="empty">${t("none")}</div></div>`;
  const blocks=Array.isArray(pg.blocks)?pg.blocks:[];
  const isMgr=S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(pg.title,"")}
    ${blocks.length?renderBlocks(blocks,"cp"+id):""}
    ${(!blocks.length&&pg.text)?`<div class="card" style="padding:16px"><p style="white-space:pre-wrap;font-size:15px;line-height:1.55">${esc(pg.text)}</p></div>`:""}
    ${(!blocks.length&&pg.url)?`<a class="btn" href="${esc(pg.url)}" target="_blank" rel="noopener"
      style="display:block;text-align:center;margin-top:12px">${ic("back",15)} ${t("openLink")}</a>`:""}
    ${(!blocks.length&&!pg.text&&!pg.url)?`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("pbEmpty")}</div>`:""}
    ${isMgr?`<button class="btn ghost" data-pbedit="${esc(pg.id)}" style="margin-top:16px">${ic("pen",15)} ${t("pbEditPage")}</button>`:""}
  </div>`;
}
/* ================= QR CODE (spread the app) ================= */
function appUrl(){
  try{ return location.origin + location.pathname; }catch(e){ return ""; }
}
function qrView(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data="+encodeURIComponent(url);
  return `<div class="screen fadein">
    ${topBar(t("qrTab"),"")}
    ${hubBack()}
    <p class="mini" style="margin:-4px 0 14px">${t("qrHint")}</p>
    <div class="card qrcard">
      <img class="qr-img" src="${esc(img)}" alt="QR" loading="lazy">
      <p class="mini qr-url">${esc(url)}</p>
    </div>
    <button class="btn" id="qr-print" style="margin-top:14px">${ic("download",16)} ${t("qrDownload")}</button>
  </div>`;
}
function openQrPrint(){
  const url=appUrl();
  const img="https://api.qrserver.com/v1/create-qr-code/?size=900x900&margin=12&data="+encodeURIComponent(url);
  const name=esc(S.settings.name||"Entertainment");
  const w=window.open("","_blank");
  if(!w){ toastErr(t("errSave")); return; }
  w.document.write('<html><head><title>'+name+'</title><meta charset="utf-8">'+
    '<style>body{font-family:system-ui,sans-serif;text-align:center;padding:40px;color:#2B1F16}'+
    'h1{font-size:34px;margin:0 0 6px}p{color:#6b5a4a;margin:0 0 26px;font-size:18px}'+
    'img{width:70%;max-width:420px}small{display:block;margin-top:18px;color:#8a7a6a;word-break:break-all}</style>'+
    '</head><body><h1>'+name+'</h1><p>'+esc(t("qrHint"))+'</p>'+
    '<img src="'+img+'" alt="QR"><small>'+esc(url)+'</small>'+
    '<scr'+'ipt>setTimeout(function(){window.print();},600);<\/scr'+'ipt></body></html>');
  w.document.close();
}
