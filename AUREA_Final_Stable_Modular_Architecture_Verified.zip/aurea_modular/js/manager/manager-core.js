/* ---------------- manager (full access — manager role only) ---------------- */
function managerView(){
  if(S.tab==="dash") return dashView();
  if(S.tab==="req") return requirementsView();
  if(S.tab==="program"){
    const inner = S.sub.program==="tickets" ? managerTicketsInner()
      : S.sub.program==="performance" ? performanceAttendanceInner636()
      : managerActsInner();
    return `<div class="screen fadein">
      ${topBar(t("manage"),S.session.name)}
      ${arrangeBtn("program")}
      ${subTabs("program",[["acts",t("activities")],["tickets",t("tickets")],["performance","Shows / Events Attendance"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="guests"){
    const sub=S.sub.guests;
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    let inner="";
    if(sub==="history") inner=(typeof window.guestHistoryInnerV619==="function" ? window.guestHistoryInnerV619() : `<div class="empty">Guest history is loading…</div>`);
    else if(sub==="rooms") inner=roomsInner();
    else if(sub==="crm") inner=guestCrmInner();
    else if(sub==="bookings") inner=bookingsInner();
    else if(sub==="tickets") inner=(typeof window.guestTicketsManagerInnerV620==="function" ? window.guestTicketsManagerInnerV620() : `<div class="empty">Tickets are loading…</div>`);
    else if(sub==="chat") inner=chatInboxInner();
    else if(sub==="feedback") inner=feedbackInner();
    else inner=requestsInner();
    const gTabs=[["crm",t("guestCrm")],["rooms",t("rooms")],["bookings",t("bookings")],["tickets",t("tickets")],
                 ["chat",t("guestChatTab")],["requests",t("requests")],["feedback",t("feedback")],["history","Guest history"]];
    return `<div class="screen fadein">
      ${topBar(t("guestsTab"),S.session.name)}
      ${arrangeBtn("guests")}
      ${subTabs("guests",gTabs)}
      ${inner}
    </div>`;
  }
  if(String(S.tab||"").startsWith("g360:")) return guest360View(S.tab.slice(5));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="dayplan") return managerDayPlanView();
  if(S.tab==="bus") return busView();
  if(S.tab==="quiz") return quizCenterView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  if(S.tab==="qr") return qrView();
  if(S.tab==="weather") return weatherView();
  if(S.tab==="assign") return assignView();
  if(S.tab==="builder") return builderView();
  if(S.tab==="pagedesign") return pageDesignView();
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(S.tab==="settings") return settingsHubView();
  if(String(S.tab||"").startsWith("set:")){
    const k=S.tab.slice(4);
    if(k==="theme")    return setThemeView();
    if(k==="publictext") return setPublicExperienceView639();
    if(k==="brand")    return setBrandView();
    if(k==="features") return setFeaturesView();
    if(k==="location") return setLocationView();
    if(k==="links")    return setLinksView();
    if(k==="advanced") return setAdvancedView();
    if(k==="notif")    return setNotifView();
    return settingsHubView();
  }
  if(S.tab==="team"){
    let sub=S.sub.team;
    if(["tasks","profiles"].includes(sub)) sub=S.sub.team="accounts";  // moved to Assignments
    if(sub==="chat" && S.chatRoom) return chatThreadScreen();
    const inner = sub==="requests" ? teamRequestsInner() : sub==="monthatt" ? monthAttInner() : sub==="attendance" ? attendanceInner()
      : sub==="payroll" ? payrollManagerInner630() : sub==="chat" ? staffChatInbox() : accountsInner();
    return `<div class="screen fadein">
      ${topBar(t("teamTab"),S.session.name)}
      ${arrangeBtn("team")}
      ${subTabs("team",[["accounts",t("teamAccounts")],["chat",t("teamChatTab")],["requests",t("teamRequests")],["monthatt",t("monthAtt")],["attendance",t("attendance")],["payroll","Payroll"]])}
      ${inner}
    </div>`;
  }
  if(S.tab==="ai") return aiView();
  return dashView();   // unknown tab: go home, never Settings
}
/* Totals for the chosen day + the button to change duty */
function dutyBar(day){
  const st=dayDutyStats(day);
  const names=list=>(list||[]).map(u=>esc(u.display_name||u.username)).join(", ")||"—";
  return `<div class="card dutybar">
    <div class="db-nums db-nums-five">
      <div class="db-n"><b>${st.total}</b><span class="mini">${t("totalTeam")}</span></div>
      <div class="db-n ok"><b>${st.workingCount}</b><span class="mini">${t("workingToday")}</span></div>
      <div class="db-n off"><b>${st.offCount}</b><span class="mini">${t("dayOffToday")}</span></div>
      <div class="db-n absent"><b>${st.absentCount}</b><span class="mini">${t("attA")}</span></div>
      <div class="db-n vac"><b>${st.vacationCount}</b><span class="mini">${t("attV")}</span></div>
    </div>
    <div class="db-meta">
      <span class="mini">${st.date}</span>
      <span class="mini">${t("dayOff")}: ${names(st.off)}</span>
      ${st.absentCount?`<span class="mini">${t("attA")}: ${names(st.absent)}</span>`:""}
      ${st.vacationCount?`<span class="mini">${t("attV")}: ${names(st.vacation)}</span>`:""}
      ${dayIsCustom(day)?`<span class="db-tag">${t("customDay")}</span>`:""}
    </div>
    <button class="btn sm" data-dutyedit="${day}">${ic("pen",14)} ${t("editDayOff")}</button>
  </div>`;
}
/* ---- Day Plan sections she can reorder herself, no code ---- */
const DAYPLAN_SECTIONS=["info","times","team","standards"];
/* ---- Arrange this page: every manager page she can rearrange herself ----
   Pages built from cards list their sections; pages built from pills list
   their sub-tabs. The same button and the same modal handle both. */
const PAGE_SECTIONS={
  dayplan: ["team","standards"],
  dash:    ["attention","dayinfo","wholeday","tonight","live","export","stats","feedback","nations","activities","trends"],
  guests:  ["crm","rooms","bookings","tickets","chat","requests","feedback","history"],
  team:    ["accounts","chat","requests","monthatt","attendance","payroll"],
  program: ["acts","tickets","performance"],
  settings:["set:theme","set:publictext","set:brand","builder","set:features","set:notif","set:links",
            "bus","set:location","export","set:advanced"]
};
const SECTION_LABELS={
  dayplan: {team:"teamAccounts",standards:"standardsHead"},
  dash:    {attention:"attentionHead",dayinfo:"dayInfoSec",wholeday:"wholeDay",tonight:"tonightLbl",live:"liveOps",export:"exportData",stats:"overview",feedback:"fbAnalytics",
            nations:"natStats",activities:"activities",trends:"trendsHead"},
  guests:  {crm:"guestCrm",rooms:"rooms",bookings:"bookings",tickets:"tickets",chat:"guestChatTab",
            requests:"requests",feedback:"feedback",history:"Guest history"},
  team:    {accounts:"teamAccounts",chat:"teamChatTab",requests:"teamRequests",
            monthatt:"monthAtt",attendance:"attendance",payroll:"Payroll"},
  program: {acts:"activities",tickets:"tickets",performance:"Shows / Events Attendance"},
  settings:{"set:theme":"setTheme","set:publictext":"Public experience","set:brand":"setBrand","builder":"setMenus",
            "set:features":"setFeatures","set:notif":"setNotif","set:links":"setLinksT",
            "bus":"busItem","set:location":"setLocation","export":"setData","set:advanced":"setAdvanced"}
};
function sectionLabel(pageKey,k){ const m=SECTION_LABELS[pageKey]||{}; return m[k]?t(m[k]):k; }
function pageHidden(pageKey){
  const all=(S.settings && S.settings.pageHidden) || {};
  let hidden=(all[pageKey]||[]).slice();
  // V6.19.3 one-time migration: stale saved Guest layouts could hide the newly-added Tickets tab.
  // Until the migration is recorded, Tickets must remain visible. Afterwards normal Arrange Page control resumes.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193)) hidden=hidden.filter(k=>k!=="tickets");
  return hidden;
}
function pageOrder(pageKey,withHidden){
  const def=PAGE_SECTIONS[pageKey]||[];
  const all=(S.settings && S.settings.pageOrder) || {};
  let saved=all[pageKey];
  if(!saved && pageKey==="dayplan") saved=(S.settings && S.settings.dayPlanOrder);  // the older name
  const kept=(saved||[]).filter(k=>def.includes(k));
  let out=kept.concat(def.filter(k=>!kept.includes(k)));
  // V6.19.3 one-time migration: older/stale saved Guest layouts may already contain Tickets
  // in the wrong position, or may have hidden it. Force the intended location once.
  if(pageKey==="guests" && !(S.settings&&S.settings.guestTicketsTabMigrationV6193) && out.includes("tickets")){
    out=out.filter(k=>k!=="tickets");
    const bi=out.indexOf("bookings");
    out.splice(bi>=0?bi+1:Math.min(3,out.length),0,"tickets");
  }
  if(pageKey==="dash" && !(S.settings&&S.settings.dashboardDayOpsMigrationV626)){
    out=out.filter(k=>k!=="dayinfo"&&k!=="wholeday");
    const ai=out.indexOf("attention"),at=ai>=0?ai+1:0;
    out.splice(at,0,"dayinfo","wholeday");
  }
  if(!withHidden){ const h=pageHidden(pageKey); out=out.filter(k=>!h.includes(k)); }
  return out.length?out:def.slice();
}
function dayPlanOrder(){ return pageOrder("dayplan"); }
function arrangeBtn(pageKey){
  if(!S.session || S.session.role!=="manager") return "";
  if(!PAGE_SECTIONS[pageKey]) return "";
  return `<button class="btn sm ghost arrange-b" data-arrange="${pageKey}">${ic("grid",14)} ${t("arrangeSections")}</button>`;
}
function renderParts(pageKey,parts){
  return pageOrder(pageKey).map(k=>parts[k]?parts[k]():"").join("");
}
/* Everything that happens today, split into morning / afternoon / evening. */
/* Turn whatever is written in the entertainer field into a real name. */
function entertainerName(raw){
  const v=String(raw||"").trim();
  if(!v) return "";
  return v.split(/\s*[,;\/]\s*/).map(part=>{
    const p=part.trim(); if(!p) return "";
    const pl=p.toLowerCase();
    const hit=(S.users||[]).find(u=>
      String(u.display_name||"").toLowerCase()===pl ||
      String(u.username||"").toLowerCase()===pl ||
      String(u.number||"")===p.replace(/^#/,"") ||
      String(u.employee_id||"")===p ||
      String(u.phone||"").replace(/\s/g,"")===p.replace(/\s/g,"")
    );
    return hit ? (hit.display_name||hit.username) : p;
  }).filter(Boolean).join(", ");
}
/* is this the logged-in entertainer's own activity? */
function isMineAct(a){
  if(!S.session || S.session.role!=="staff") return false;
  const me=String(S.session.name||"").toLowerCase();
  const un=String(S.session.username||"").toLowerCase();
  return String(a && a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
    .map(x=>x.trim()).some(x=>x && (x===me || x===un || entertainerName(x).toLowerCase()===me));
}
function dayTimeline(day){
  const items=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>({a,slot:operationSlotFromMinutes(timeToMin(a.time))}))
    .filter(x=>["morning","afternoon","evening"].includes(x.slot))
    .sort((x,y)=>(timeToMin(x.a.time)||0)-(timeToMin(y.a.time)||0));
  const slots=[
    {k:"morning",label:"10:00 – 12:30"},
    {k:"afternoon",label:"15:00 – 17:30"},
    {k:"evening",label:"19:30 – 23:00"}
  ];
  return slots.map(sl=>{
    const rows=items.filter(x=>x.slot===sl.k).map(x=>x.a);
    return `<div class="tl-block">
      <div class="tl-head"><span class="tl-dot ${sl.k}"></span>${t(sl.k+"Part")}
        <span class="mini" style="margin-left:6px">${sl.label}</span><span class="tl-n">${rows.length}</span></div>
      ${rows.length?rows.map(x=>{
        const c=normCat(x), who=entertainerName(x.entertainer);
        const type=c==="mAdult"?"":(catLabel(c)||c);
        return `<div class="tl-row ${x._tag?("is-"+x._tag):""}${isMineAct(x)?" mine":""}">
          <span class="tl-t">${esc(x.time||"")}</span>
          <span class="tl-x"><b>${esc(x.name)}</b>${x.location?`<span class="mini">${esc(x.location)}</span>`:""}
            ${who?`<span class="mini who">${esc(who)}</span>`:""}</span>
          ${type?`<span class="tl-tag">${esc(type)}</span>`:""}
        </div>`;
      }).join(""):`<p class="mini tl-empty">${t("noneToday")}</p>`}
    </div>`;
  }).join("");
}
function dayPlanInfoCard(day){
  const dp=dayPlanFor(day);
  return `<div class="sec"><h3>${ic("calendar",18)} ${esc(t("days")[dp.day]||dp.name)}</h3>
    <div class="card daycard">
      <div class="dc-grid">
        <div class="dc-cell"><span>${t("restaurantTheme")}</span><b>${esc(dp.theme)}</b></div>
        <div class="dc-cell"><span>${t("dressCode")}</span><b>${esc(dp.dress)}</b></div>
        <div class="dc-cell"><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>
          ${dp.showTime?`<i class="mini">${esc(dp.showTime)}${dp.showLoc?" · "+esc(dp.showLoc):""}</i>`:""}</div>
        <div class="dc-cell"><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
        <div class="dc-cell"><span>${t("dayOff")}</span><b>${personTags(dp.off)||"—"}</b></div>
        <div class="dc-cell"><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
        <div class="dc-cell wide"><span>${t("eventsToday")}</span>
          ${(()=>{
            const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
              .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
            if(!evs.length) return `<b>—</b>`;
            return evs.map(e=>`<b class="ev-line">${esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])} · ${esc(e.name)}${e.location?` <i class="mini">${esc(e.location)}</i>`:""}</b>`).join("");
          })()}</div>
        <div class="dc-cell"><span>${t("practiceHead")}</span>
          <b>${dp.practice?t("practiceDays"):(dp.makeup?t("makeupPractice"):"—")}</b>
          ${dp.practice?`<i class="mini">${esc(t("practiceWindow"))}</i>`
            :(dp.makeup?`<i class="mini">${esc(makeupText(dp.makeup))}</i>`:"")}</div>
      </div>
    </div>
  </div>`;
}
function dayPlanTeamCard(day){
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const mk=currentAttMonth(), ds=assignDateStr(day), dd=+ds.slice(8,10);
  const isThisMonth=ds.slice(0,7)===mk;
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n]; const info=personDayInfo(n,day);
    let status="", cls="";
    const st = (u && isThisMonth) ? attStatus(u,mk,dd) : "";
    if(st==="A"){ status=t("attA"); cls="absent"; }        // marked absent
    else if(st==="V"){ status=t("attV"); cls="vac"; }      // on holiday
    else if(info.isOff){ status=t("dayOff"); cls="off"; }
    roster.push({n,u,role:roleForNumber(n),status,cls});
  }
  const away=roster.filter(r=>r.cls==="absent").length;
  const onHol=roster.filter(r=>r.cls==="vac").length;
  return `<div class="sec"><h3>${ic("users",18)} ${t("teamAccounts")}
      ${away?`<span class="hd-chip absent">${away} ${t("attA")}</span>`:""}
      ${onHol?`<span class="hd-chip vac">${onHol} ${t("attV")}</span>`:""}</h3>
    <div class="card rostercard">
      ${roster.map(r=>`<div class="roster-row ${r.cls}">
        <span class="rnum">${r.u&&r.u.photo?`<img src="${esc(r.u.photo)}" alt="">`:r.n}</span>
        <span class="rinfo"><b>${esc(r.u?(r.u.display_name||r.u.username):r.role)}</b>
          <span class="mini">#${r.n} · ${esc(r.role)}${r.u?"":" · —"}</span></span>
        ${r.status?`<span class="rstat ${r.cls}">${esc(r.status)}</span>`:`<span class="rstat working">${ic("check",14)}</span>`}
      </div>`).join("")}
    </div>
  </div>`;
}
function dayPlanStandards(day){
  const dp=dayPlanFor(day);
  const rows=DAILY_STANDARDS.map(r=>{
    let note=r.nk?t(r.nk):"";
    if(r.morning){ note = dp.practice ? t("practiceInline") : ""; }
    return `<div class="std-row"><span class="std-t">${esc(r.time)}</span>
      <span class="std-x"><b>${esc(t(r.k))}</b>${note?`<span class="mini"> · ${esc(note)}</span>`:""}</span></div>`;
  }).join("");
  return `<div class="sec"><h3>${ic("clock",18)} ${t("standardsHead")}</h3>
    <div class="card">${rows}</div></div>`;
}
function dayPlanTimes(day){
  return `<div class="sec"><h3>${ic("clock",18)} ${t("wholeDay")}</h3>
    <div class="card tlcard">${dayTimeline(day)}</div></div>`;
}
function managerDayPlanView(){
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  const dp=dayPlanFor(day);
  // roster: numbers 1-10; manager account -> slot #1, numbered staff -> their slot
  const byNum={}; S.users.forEach(u=>{ if(u.number) byNum[u.number]=u; });
  if(!byNum[1]){ const mgr=S.users.find(u=>u.role==="manager"); if(mgr) byNum[1]=mgr; }
  const roster=[];
  for(let n=1;n<=10;n++){
    const u=byNum[n];
    const info=personDayInfo(n,day);
    let status="", cls="";
    if(info.isOff){ status=t("dayOff"); cls="off"; }   // entrance duty lives in Assignments
    else { status=""; cls=""; }
    roster.push({n,u,role:roleForNumber(n),status,cls,info});
  }
  const parts={
    team:      ()=>dayPlanTeamCard(day),
    standards: ()=>dayPlanStandards(day)
  };
  return `<div class="screen fadein">
    ${topBar(t("dayPlan"),(t("days")[dp.day]||dp.name)+" · "+dp.theme)}
    ${dayChips()}
    ${dutyBar(day)}
    ${arrangeBtn("dayplan")}
    ${renderParts("dayplan",parts)}
  </div>`;
}
/* Move the sections of this page around — no code, just up and down. */
function openArrangeModal(pageKey){
  pageKey=pageKey||"dayplan";
  if(!PAGE_SECTIONS[pageKey]) return;
  let order=pageOrder(pageKey,true);
  let hidden=pageHidden(pageKey);
  const wrap=baseModal(`
    <h3>${ic("grid",20)} ${t("arrangeSections")}</h3>
    <p class="mini">${t("arrangeAnyHint")}</p>
    <div id="ar-box"></div>
    <button class="btn" id="ar-go">${t("save")}</button>
    <button class="btn ghost" id="ar-reset">${t("resetDefault")}</button>
    <button class="btn ghost" id="ar-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#ar-box");
  const paint=()=>{
    box.innerHTML=order.map((k,i)=>{
      const off=hidden.includes(k);
      return `<div class="ar-it" style="${off?"opacity:.45":""}">
      <span class="ar-nm">${esc(sectionLabel(pageKey,k))}</span>
      <span class="ar-acts">
        <button class="bd-b" data-arup="${i}" ${i===0?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b down" data-ardown="${i}" ${i===order.length-1?"disabled":""}>${ic("back",14)}</button>
        <button class="bd-b ${off?"":"on"}" data-arhide="${esc(k)}" aria-label="${off?t("showSection"):t("hideSection")}">${ic(off?"belloff":"bell",14)}</button>
      </span></div>`;}).join("");
    box.querySelectorAll("[data-arup]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.arup; [order[i-1],order[i]]=[order[i],order[i-1]]; paint();
    });
    box.querySelectorAll("[data-ardown]").forEach(b=>b.onclick=()=>{
      const i=+b.dataset.ardown; [order[i+1],order[i]]=[order[i],order[i+1]]; paint();
    });
    box.querySelectorAll("[data-arhide]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.arhide, i=hidden.indexOf(k);
      if(i>=0) hidden.splice(i,1);
      else if(order.length-hidden.length>1) hidden.push(k);   // never hide the last one
      paint();
    });
  };
  paint();
  const save=async (ord,hid)=>{
    const po={...((S.settings&&S.settings.pageOrder)||{})}; po[pageKey]=ord;
    const ph={...((S.settings&&S.settings.pageHidden)||{})}; ph[pageKey]=hid;
    const next={...S.settings, pageOrder:po, pageHidden:ph};
    if(pageKey==="dayplan") next.dayPlanOrder=ord;             // keep the old field in step
    try{ await DB.saveSettings(next); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ar-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ar-reset").onclick=()=>save(PAGE_SECTIONS[pageKey].slice(),[]);
  wrap.querySelector("#ar-go").onclick=()=>save(order,hidden);
}
function feedbackInner(){
  const list=S.feedback||[];
  const avg=fbAvgAll(list);
  return `<div class="row2" style="margin-bottom:12px">
      <button class="btn" id="btn-addfb">\uFF0B ${t("fbNew")}</button>
      <button class="btn ghost" id="btn-fbexport">${ic("download",15)} ${t("fbExport")}</button>
    </div>
    ${S.session && S.session.role==="manager"
      ? `<button class="btn ghost sm" id="btn-fbdepts" style="margin:0 0 12px">${ic("grid",14)} ${t("fbDeptsEdit")}</button>` : ""}
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${avg?avg.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${list.length}</b><span>${t("feedback")}</span></div>
    </div>
    <p class="mini" style="margin:-2px 0 8px">${t("fbTapOne")}</p>`
  + dayGroups("fb", list, "created_at", fbRowHtml, "feedback");
}
function dashView(){
  if(S.sub.dash==="rooms") S.sub.dash="overview";   // rooms live under Guests now
  const totalB=S.bookings.length;
  const wait=S.bookings.filter(b=>b.status==="waitlist").length;
  const withCap=S.activities.filter(a=>a.capacity>0);
  const occ=withCap.length?Math.round(withCap.reduce((n,a)=>n+Math.min(1,seatsTaken(a.id)/a.capacity),0)/withCap.length*100):0;
  const tSold=S.orders.reduce((n,o)=>n+(+o.qty||0),0);
  const rooms=new Set(S.bookings.map(b=>b.room)).size;
  const people=S.bookings.filter(b=>b.status==="booked").reduce((n,b)=>n+(+b.adults||0)+(+b.children||0),0);
  const natMap={};
  S.bookings.forEach(b=>{ if(b.nationality){ (natMap[b.nationality]=natMap[b.nationality]||new Set()).add(b.room); } });
  S.orders.forEach(o=>{ if(o.nationality){ (natMap[o.nationality]=natMap[o.nationality]||new Set()).add(o.room); } });
  const nats=Object.entries(natMap).map(([n,s])=>[n,s.size]).sort((x,y)=>y[1]-x[1]);
  const top=[...S.activities].map(a=>({a,n:seatsTaken(a.id)})).sort((x,y)=>y.n-x.n).slice(0,5).filter(x=>x.n>0);
  const parts={
    attention: ()=>attentionCard(),
    dayinfo:   ()=>dayPlanInfoCard(todayIndex()),
    wholeday:  ()=>dayPlanTimes(todayIndex()),
    tonight:   ()=>tonightCard(),
    live:      ()=>liveOpsCard(),
    export:    ()=>`<button class="btn ghost" id="btn-exportdata" style="margin:0 0 16px">${ic("download",16)} ${t("exportData")}</button>`,
    stats:     ()=>`<div class="stat-grid">
      <div class="stat"><b>${totalB}</b><span>${t("totalBookings")}</span></div>
      <div class="stat accent"><b>${occ}%</b><span>${t("occupancy")}</span></div>
      <div class="stat"><b>${tSold}</b><span>${t("tickets")}</span></div>
      <div class="stat"><b>${wait}</b><span>${t("waitlisted")}</span></div>
      <div class="stat"><b>${rooms}</b><span>${t("uniqueGuests")}</span></div>
      <div class="stat"><b>${people}</b><span>${t("totalPeople")}</span></div>
    </div>`,
    feedback:  ()=>feedbackAnalyticsCard(),
    nations:   ()=>nats.length?`<div class="sec"><h3>${t("natStats")}</h3><div class="card">
      ${nats.map(([n,c])=>`<div class="booking-line"><span>${esc(n)}</span><span class="pill">${c}</span></div>`).join("")}
    </div></div>`:"",
    activities:()=>`<div class="sec"><h3>${ic("star",18)} ${t("activities")}</h3>
      ${top.length?top.map(x=>`<div class="card booking-line" style="padding:12px 14px">
        <span><b>${esc(x.a.name)}</b> · ${t("daysShort")[x.a.day]} ${x.a.time}</span>
        <span class="pill">${x.n} ${t("guests")}</span></div>`).join(""):`<div class="empty"><div class="big">${ic("grid",30)}</div>${t("none")}</div>`}
    </div>`,
    trends:    ()=>trendsCard()
  };
  return `<div class="screen fadein">
    ${topBar(t("dashboard"),S.session.name)}
        ${!REMOTE?`<div class="setup">${t("demoNote")}</div>`:""}
    ${arrangeBtn("dash")}
    ${renderParts("dash",parts)}
  </div>`;
}
/* Tonight's show or party, and whether the hotel is actually ready for it.
   The readiness comes straight from its requirement sheet. */
function tonightAct(day){
  const d=(typeof day==="number")?day:todayIndex();
  const evening=(S.activities||[]).filter(a=>a && a.day===d && ["eShow","eParty"].includes(normCat(a)));
  if(!evening.length) return null;
  return evening.sort((x,y)=>(timeToMin(reqStartTime(y))||0)-(timeToMin(reqStartTime(x))||0))[0];
}
function reqSheetForAct(a){
  if(!a) return null;
  const all=reqSheets();
  return all.find(sh=>String(sh.actId||"")===String(a.id))
      || all.find(sh=>String(sh.title||"").toLowerCase()===String(a.name||"").toLowerCase())
      || null;
}
function tonightCard(){
  const a=tonightAct();
  if(!a) return "";
  const sh=reqSheetForAct(a);
  const rows=(sh && sh.rows) || [];
  const done=rows.filter(r=>r.done).length;
  const pct=rows.length?Math.round(done/rows.length*100):0;
  const who=String(a.entertainer||"").trim();
  const byDept={};
  rows.forEach(r=>{ const k=r.dept||"\u2014"; byDept[k]=byDept[k]||{n:0,d:0}; byDept[k].n++; if(r.done) byDept[k].d++; });
  const chips=Object.keys(byDept).slice(0,3).map(k=>{
    const v=byDept[k], full=v.d===v.n;
    return `<span class="schip ${full?"live":"warn"}"><i></i>${esc(k)} ${full?"\u2713":v.d+"/"+v.n}</span>`;
  }).join("");
  return `<div class="sec"><h3>${ic("sparkle",18)} ${t("tonightLbl")}</h3>
    <div class="card tn">
      <div class="tn-head" data-actopen="${esc(String(a.id))}">
        <span class="tn-mid"><b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}</span></span>
        <span class="tn-go">${ic("back",16)}</span>
      </div>
      <div class="tn-chips">
        <span class="schip ${who?"live":"warn"}"><i></i>${t("readyTeam")} ${who?esc(who):"\u2014"}</span>
        ${chips}
      </div>
      ${rows.length?`<div class="tn-bar"><i style="width:${pct}%"></i></div>
        <span class="mini">${t("readySetup")} ${pct}% \u00b7 ${done}/${rows.length}</span>`
        :`<button class="btn sm ghost" id="tn-make">${ic("clipboard",14)} ${t("readyMake")}</button>`}
    </div>
  </div>`;
}
/* What is running right now, what starts next, and whether anyone is on it.
   The manager's first question every afternoon. */
function liveOpsCard(){
  const day=todayIndex();
  const now=(()=>{ const d=new Date(); return d.getHours()*60+d.getMinutes(); })();
  const list=(S.activities||[]).filter(a=>a && a.day===day)
    .map(a=>{
      const w=actWindow(a);
      const s0=w?w.s0:(timeToMin(String(a.time||"").split(/\s*[\u2013\u2014-]\s*/)[0])||0);
      const s1=(w && (w.e0!=null?w.e0:w.s1)) ?? (s0+45);   // actWindow calls the end e0
      return {a, s0, s1};
    })
    .filter(x=>x.s1>=now-30)                       // still running, or still to come
    .sort((x,y)=>x.s0-y.s0)
    .slice(0,5);
  if(!list.length) return "";
  const staffOf=a=>entertainerName(a.entertainer);   // always show the team member display name
  const row=x=>{
    const a=x.a, who=staffOf(a), booked=seatsTaken(a.id);
    const live = x.s0<=now && now<=x.s1;
    const mins = Math.round(x.s0-now);
    const chip = live ? `<span class="schip live"><i></i>${t("liveNow")}</span>`
      : !who   ? `<span class="schip warn"><i></i>${t("liveNoStaff")}</span>`
      : mins<=60 ? `<span class="schip gold"><i></i>${t("liveSoon").replace("{n}",Math.max(0,mins))}</span>`
      : `<span class="schip"><i></i>${t("liveAssigned")}</span>`;
    return `<div class="booking-line" data-actopen="${esc(String(a.id))}" style="cursor:pointer">
      <span style="min-width:0"><b>${esc(a.name)}</b>
        <br><span class="mini">${esc(String(a.time||""))}${a.location?" \u00b7 "+esc(a.location):""}${
          booked?" \u00b7 "+booked+" "+t("guests"):""}${who?" \u00b7 "+esc(who):""}</span></span>
      ${chip}
    </div>`;
  };
  return `<div class="sec"><h3>${ic("clock",18)} ${t("liveOps")}</h3>
    <div class="card">${list.map(row).join("")}</div>
  </div>`;
}
/* The feedback picture at a glance — tap a department to read the ratings behind it. */
function feedbackAnalyticsCard(){
  const list=S.feedback||[];
  const sum=fbSummary(list);
  return `<div class="sec"><h3>${ic("star",18)} ${t("fbAnalytics")}</h3>
    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
      <div class="stat"><b>${sum.overall?sum.overall.toFixed(1)+" \u2605":"\u2014"}</b><span>${t("avgRate")}</span></div>
      <div class="stat"><b>${sum.count}</b><span>${t("feedback")}</span></div>
      <div class="stat good"><b>${sum.allFive}</b><span>${t("fbAllFiveN")}</span></div>
      <div class="stat ${sum.toReview?"warn":""}"><b>${sum.toReview}</b><span>${t("fbToReview")}</span></div>
    </div>
    ${sum.weak
      ? `<button class="fb-dept low" data-fbdept="${esc(sum.weak.k)}" style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:10px">
          <span class="fb-nm">${t("fbLowest")}<br><span class="mini">${esc(fbDeptLabel(sum.weak.k))}</span></span>
          <span class="fb-bar"><i style="width:${Math.round(sum.weak.avg/5*100)}%"></i></span>
          <span class="fb-val">${sum.weak.avg.toFixed(1)}</span></button>`
      : (sum.rated?`<p class="mini" style="margin:0 0 10px">${ic("star",13)} ${
          sum.perfect ? t("fbHotelGeneral")+" \u00b7 "+t("fbPerfect")
          : t("fbHotelGeneral")+" \u00b7 "+t("fbNoneWeak")}</p>`:"")}
    ${fbDeptListCard(list)}
    ${sum.rated?`<p class="mini" style="margin-top:6px">${t("fbTapHint")}</p>`:""}
  </div>`;
}
function managerActsInner(){
  const acts=S.activities.filter(a=>a.day===S.day);
  const head=dayTabs()+`<button class="btn" id="btn-add" style="margin:0 0 14px">＋ ${t("addActivity")}</button>`;
  if(!acts.length) return head+`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return head + OPS.map(o=>{
    const list=acts.filter(a=>actOp(a)===o.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    if(!list.length) return "";
    return `<div class="sec"><h3>${esc(opLabel(o.id))}</h3>${list.map(a=>activityCard(a,{manager:true,showBook:false,showFav:false})).join("")}</div>`;
  }).join("");
}
function managerTicketsInner(){
  return `<button class="btn" id="btn-addticket" style="margin:0 0 14px">＋ ${t("addTicket")}</button>`
  + (S.tickets.length?S.tickets.map(tk=>{
    const os=ordersFor(tk.id), sold=ticketsSold(tk.id);
    return `<div class="card">
      <div class="act" style="margin-bottom:${os.length?10:0}px">
        <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
        <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span>
          <h4>${esc(tk.name)}</h4>
          <div class="meta"><span>${esc(tk.price||"")}</span><span>${mi("ticket")}${sold}${tk.capacity>0?"/"+tk.capacity:""}</span></div></div>
        <div class="side"><button class="btn sm ghost" data-tedit="${tk.id}">${ic("pen",15)}</button></div>
      </div>
      ${os.map(o=>`<div class="booking-line">
        <span style="min-width:0"><b>${t("room")} ${esc(o.room)}</b> · ${esc(o.guest_name)} · ×${o.qty}${o.collect_from?`<br><span class="mini">${mi("user")}${t("handTo")}: ${esc(o.collect_from)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <button class="chip ${o.status==="paid"?"ok":"res"}" data-tpaid="${o.id}">${o.status==="paid"?t("paid"):t("reserved")}</button>
          <button class="btn sm warn" data-tdel="${o.id}">${ic("close",14)}</button>
        </span></div>`).join("")}
    </div>`;
  }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`);
}
function requestsInner(){
  return S.requests.length?dayGroups("req", S.requests, "created_at", r=>`<div class="booking-line">
    <span style="min-width:0">${ic(r.type==="song"?"music":"gift",15)} <b>${esc(r.detail)}</b>${r.date?` · ${esc(r.date)}`:""}
      <br><span class="mini">${t("room")} ${esc(r.room)} · ${esc(r.guest_name)}${r.note?` — ${esc(r.note)}`:""}
        ${r.created_at?` · ${whenLabel(r.created_at)}`:""}</span></span>
    <span style="display:flex;gap:6px;align-items:center;flex:none">
      <button class="chip ${r.status==="done"?"ok":"res"}" data-reqdone="${r.id}">${r.status==="done"?t("done"):t("statusNew")}</button>
      <button class="btn sm warn" data-reqdel="${r.id}">${ic("close",14)}</button>
    </span></div>`, "requests")
  :`<div class="empty"><div class="big">${ic("gift",30)}</div>${t("none")}</div>`;
}
function roomsInner(){
  return `<label>${t("addRooms")}</label>
    <textarea id="rooms-in" rows="3" placeholder="${t("roomsHint")}"></textarea>
    <button class="btn" id="btn-addrooms" style="margin:10px 0 16px">＋ ${t("addRooms")}</button>
    <input id="rooms-filter" placeholder="..." style="margin-bottom:10px">
    <div class="card roomgrid">
      ${S.rooms.length?S.rooms.map(r=>{
        const acc=S.accounts.find(a=>a.room===r.room && a.active!==false && !stayExpired(a));
        return `<div class="booking-line roomline" data-room="${esc(r.room)}">
          <span style="min-width:0"><b>${esc(r.room)}</b>${acc?` · ${esc(acc.name)}`:""}</span>
          <span style="display:flex;gap:6px;align-items:center;flex:none">
            ${acc?`<button class="btn sm ghost" data-gedit="${acc.id}">${ic("pen",15)}</button>`:""}
            <button class="chip ${r.active?"ok":"full"}" data-roomact="${r.id}">${t("activeLbl")}</button>
            <button class="btn sm warn" data-roomdel="${r.id}">${ic("close",14)}</button>
          </span></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("door",30)}</div>${t("none")}</div>`}
    </div>`;
}
function teamSummaryCard(){
  const st=teamStats();
  if(!st.total) return "";
  return `<div class="card tsum">
    <div class="ts-top">
      <div class="ts-big"><b>${st.total}</b><span class="mini">${t("totalEntertainers")}</span></div>
      <div class="ts-gen">
        <span class="ts-chip m">${ic("users",14)} ${st.byGender.male} ${t("genderM")}</span>
        <span class="ts-chip f">${ic("users",14)} ${st.byGender.female} ${t("genderF")}</span>
        ${st.byGender.none?`<span class="ts-chip n">${st.byGender.none} ${t("genderNone")}</span>`:""}
      </div>
    </div>
    ${st.natList.length?`<div class="ts-nat"><span class="type-meta">${t("byNationality")}</span>
      <div class="ts-nats">${st.natList.map(n=>`<span class="ts-chip">${esc(n.name)} · ${n.count}</span>`).join("")}</div>
    </div>`:""}
  </div>`;
}
function accountsInner(){
  const managerCount=S.users.filter(u=>u.role==="manager").length;
  return `${teamSummaryCard()}
    <button class="btn" id="btn-adduser" style="margin:0 0 12px">＋ ${t("addUser")}</button>
    <div class="card">
      ${S.users.filter(u=>!isAttOnly(u)).sort((a,b)=>(hasLeft(a)?1:0)-(hasLeft(b)?1:0) || (a.number||99)-(b.number||99)).map(u=>{
        const lastManager=u.role==="manager"&&managerCount<=1;
        return `<div class="acct-row">
        <div class="acct-av">${u.photo?`<img src="${esc(u.photo)}" alt="">`:`<span>${esc((u.display_name||u.username||"?").trim().charAt(0).toUpperCase())}</span>`}${u.number?`<span class="acct-num">${u.number}</span>`:""}</div>
        <div class="acct-info" data-uview="${esc(u.username)}"><b>${esc(u.display_name||u.username)}${hasLeft(u)?` <span class="off-tag">${t("leftTag")}</span>`:(u.active===false?` <span class="off-tag">${t("inactiveAcc")}</span>`:"")}</b><span class="mini">${esc(u.username)} · ${u.role==="manager"?t("manager"):t("staff")}${u.nationality?" · "+esc(u.nationality):""}${u.gender?" · "+genderLabel(u.gender):""}</span></div>
        <div style="display:flex;gap:6px;align-items:center;flex:none">
          <button class="btn sm ghost" data-uedit="${u.id}">${ic("pen",15)}</button>
          ${u.role==="staff"?`<button class="btn sm ghost" data-userleave="${u.id}" aria-label="${t("markLeft")}">${ic("exit",15)}</button>`:""}
          ${u.id===S.session.userId||lastManager?"":`<button class="btn sm warn" data-deluser="${u.id}">${ic("close",14)}</button>`}
        </div></div>`;}).join("")}
    </div>`;
}
function openProfileModal(p){
  const isNew=!p; p=p||{name:"",position:"",photo:"",nationality:"",languages:"",skills:"",instagram:""};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${isNew?t("addProfile"):t("profiles")}</h3>
    <label>${t("name")}</label><input id="pr-name" value="${esc(p.name)}">
    <label>${t("positionLbl")}</label><input id="pr-pos" value="${esc(p.position)}" placeholder="Entertainment Manager / Entertainer">
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="pr-photo" type="hidden" value="${esc(p.photo)}">
    <label>${t("nationality")}</label>
    <input id="pr-nat" list="prnatlist" value="${esc(p.nationality)}">
    <datalist id="prnatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <label>${t("languagesLbl")}</label><input id="pr-lang" value="${esc(p.languages)}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="pr-skills" value="${esc(p.skills)}" placeholder="Dance · Shows · Kids">
    <label>${t("instagramLbl")}</label><input id="pr-ig" value="${esc(p.instagram)}" placeholder="https://instagram.com/...">
    <button class="btn" id="pr-go">${t("save")}</button>
    <button class="btn ghost" id="pr-x">${t("close")}</button>`);
  wrap.querySelector("#pr-x").onclick=()=>wrap.remove();
  let prPhoto=p.photo||"";
  wirePhotoPicker(wrap, ()=>prPhoto, v=>{ prPhoto=v; wrap.querySelector("#pr-photo").value=v; });
  wrap.querySelector("#pr-go").onclick=async ()=>{
    const name=wrap.querySelector("#pr-name").value.trim();
    if(!name) return;
    await DB.saveProfile({...p,name,
      position:wrap.querySelector("#pr-pos").value.trim(),
      photo:prPhoto,
      nationality:wrap.querySelector("#pr-nat").value.trim(),
      languages:wrap.querySelector("#pr-lang").value.trim(),
      skills:wrap.querySelector("#pr-skills").value.trim(),
      instagram:wrap.querySelector("#pr-ig").value.trim()});
    wrap.remove(); toast(t("saved")); render();
  };
}
function tasksInner(){
  const rk=rankingRows();
  return `<button class="btn" id="btn-addtask" style="margin:0 0 12px">＋ ${t("addTask")}</button>
    <button class="btn ghost" id="btn-export" style="margin:0 0 14px">${ic("download",16)} ${t("exportReport")}</button>`
    + (rk.length?`<div class="sec"><h3>${ic("trophy",18)} ${t("taskStats")}</h3><div class="card">
      ${rk.map((r,i)=>`<div class="booking-line">
        <span style="min-width:0">${rankBadge(i)} <b>${esc(r.u.display_name||r.u.username)}</b>
          <br><span class="mini">${t("done")}: ${r.done} · ${t("late")}: ${r.late} · ${t("cantDo")}: ${r.cant} · ${t("statusNew")}: ${r.open}</span></span>
        <span class="pill" style="flex:none">${r.points} ${t("points")}</span></div>`).join("")}
    </div></div>`:"")
    + (S.tasks.length?`<div class="card">${S.tasks.map(x=>taskLine(x,true)).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("check",30)}</div>${t("noTasks")}</div>`);
}
