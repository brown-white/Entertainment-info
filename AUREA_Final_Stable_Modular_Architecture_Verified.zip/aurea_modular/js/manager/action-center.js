/* ================= MANAGER: WHAT NEEDS YOU ================= */
function attentionItems(){
  const items=[]; const today=todayIndex();
  // activities today that can be booked but nobody has
  const empty=S.activities.filter(a=>a.day===today && (+a.capacity)>0 && seatsTaken(a.id)===0);
  if(empty.length) items.push({n:empty.length, key:"attEmptyAct", tab:"program", tone:"warn"});
  // guest requests still new
  const waiting=(S.requests||[]).filter(r=>r.status==="new");
  if(waiting.length) items.push({n:waiting.length, key:"attWaitReq", tab:"guests", sub:"requests", tone:"bad"});
  // team requests still new
  const sreq=(S.staffReqs||[]).filter(r=>r.status==="new");
  if(sreq.length) items.push({n:sreq.length, key:"attStaffReq", tab:"team", sub:"requests", tone:"bad"});
  // low ratings in the last 7 days
  const weekAgo=Date.now()-7*864e5;
  const low=(S.feedback||[]).filter(f=>(+f.rate||5)<=3 && new Date(f.created_at).getTime()>weekAgo);
  if(low.length) items.push({n:low.length, key:"attLowRate", tab:"guests", sub:"feedback", tone:"bad"});
  return items;
}
function attentionCard(){
  const items=attentionItems();
  if(!items.length) return `<div class="card attn ok"><span class="attn-ic">${ic("check",20)}</span>
    <span>${t("allGood")}</span></div>`;
  return `<div class="card attn">
    <span class="type-meta">${t("attentionHead")}</span>
    <div class="attn-list">${items.map(i=>`
      <button class="attn-it ${i.tone}" data-attn="${i.tab}${i.sub?"|"+i.sub:""}">
        <span class="attn-n">${i.n}</span>
        <span class="attn-lb">${t(i.key)}</span>
        <span class="attn-go">${ic("back",15)}</span>
      </button>`).join("")}</div>
  </div>`;
}
/* ================= MANAGER: TRENDS ================= */
function last7Days(){
  const out=[];
  for(let i=6;i>=0;i--){ const d=new Date(Date.now()-i*864e5); out.push(d); }
  return out;
}
function trendsCard(){
  const days=last7Days();
  const counts=days.map(d=>{
    const k=d.toISOString().slice(0,10);
    return (S.bookings||[]).filter(b=>String(b.created_at||"").slice(0,10)===k).length;
  });
  const max=Math.max(1,...counts);
  // most and least popular activities by real bookings
  const byAct={};
  (S.bookings||[]).forEach(b=>{ byAct[b.activity_id]=(byAct[b.activity_id]||0)+1; });
  const ranked=S.activities.map(a=>({a, n:byAct[a.id]||0})).sort((x,y)=>y.n-x.n);
  const top=ranked.filter(r=>r.n>0).slice(0,3);
  const low=ranked.filter(r=>(+r.a.capacity)>0).slice(-3).reverse();
  return `<div class="sec"><h3>${ic("grid",18)} ${t("trendsHead")}</h3>
    <div class="card trend">
      <span class="type-meta">${t("bookingTrend")} · ${t("last7")}</span>
      <div class="tr-bars">${counts.map((c,i)=>`
        <div class="tr-b"><span style="height:${Math.round(c/max*100)}%"></span>
          <i>${(t("daysShort")[(days[i].getDay()+6)%7]||"").slice(0,2)}</i>
          <u>${c}</u></div>`).join("")}</div>
    </div>
    ${top.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("topActs")}</span>
      ${top.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
    ${low.length?`<div class="card" style="margin-top:12px">
      <span class="type-meta">${t("lowActs")}</span>
      ${low.map(r=>`<div class="tr-row"><b>${esc(r.a.name)}</b><span>${r.n}</span></div>`).join("")}
    </div>`:""}
  </div>`;
}
