/* ================= GUEST CRM (360° profile) ================= */
/* How the guest's holiday is going: which day they are on and what is left. */
function stayProgress(acc){
  if(!acc || !acc.arrival || !acc.departure) return null;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  if(isNaN(a)||isNaN(d)) return null;
  const now=hotelNow(); now.setHours(0,0,0,0);
  const total=Math.max(1, Math.round((d-a)/864e5));
  const done=Math.max(0, Math.min(total, Math.round((now-a)/864e5)));
  const left=Math.max(0, total-done);
  const dayNo=Math.max(1, Math.min(total+1, done+1));
  return {total, done, left, dayNo, arrival:acc.arrival, departure:acc.departure,
          pct: Math.round((done/total)*100), lastDay:left===0, firstDay:done===0};
}
function stayCard(acc){
  const p=stayProgress(acc);
  if(!p) return "";
  const fmt=x=>{ const d=new Date(x+"T12:00:00");
    return isNaN(d)?x:d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"}); };
  const headline = p.lastDay ? t("stayLastDay")
    : p.firstDay ? t("stayWelcome")
    : t("stayDayOf").replace("{n}", p.dayNo).replace("{t}", p.total);
  return `<div class="card staycard">
    <div class="sc-top">
      <span class="sc-day"><b>${p.dayNo}</b><span class="mini">${t("dayWord")}</span></span>
      <span class="sc-mid"><b>${esc(headline)}</b>
        <span class="mini">${fmt(p.arrival)} → ${fmt(p.departure)} · ${p.total} ${t("nightsWord")}</span></span>
    </div>
    <div class="sc-bar"><span style="width:${Math.max(3,Math.min(100,p.pct))}%"></span></div>
    <div class="sc-foot">
      <span>${p.left} ${t("nightsLeft")}</span>
      <span>${p.done}/${p.total}</span>
    </div>
  </div>`;
}
function guestStayNights(acc){
  if(!acc||!acc.arrival||!acc.departure) return 0;
  const a=new Date(acc.arrival+"T00:00:00"), d=new Date(acc.departure+"T00:00:00");
  const n=Math.round((d-a)/864e5);
  return isNaN(n)?0:Math.max(0,n);
}
function guestDaysInApp(acc){
  if(!acc||!acc.created_at) return 0;
  return Math.max(1, Math.round((Date.now()-new Date(acc.created_at).getTime())/864e5));
}
function guestRecord(acc){
  const room=String(acc.room);
  const bookings=(S.bookings||[]).filter(b=>String(b.room)===room);
  const actIds=bookings.map(b=>b.activity_id);
  const acts=(S.activities||[]).filter(a=>actIds.includes(a.id));
  const orders=(S.orders||[]).filter(o=>String(o.room)===room);
  const reqs=(S.requests||[]).filter(r=>String(r.room)===room);
  const fb=(S.feedback||[]).filter(f=>String(f.room)===room);
  const msgs=(S.messages||[]).filter(m=>String(m.room)===room);
  const quiz=(S.quizReplies||[]).filter(q=>String(q.who)===room);
  // favourites = the categories they book most
  const byCat={};
  acts.forEach(a=>{ const k=catLabel(normCat(a)); byCat[k]=(byCat[k]||0)+1; });
  const favs=Object.keys(byCat).sort((x,y)=>byCat[y]-byCat[x]).slice(0,3);
  const avg=fb.length?Math.round(fb.reduce((n,f)=>n+(+f.rate||0),0)/fb.length*10)/10:0;
  return {acc, bookings, acts, orders, reqs, fb, msgs, quiz, favs, avg,
    nights:guestStayNights(acc), daysApp:guestDaysInApp(acc)};
}
function guestCrmInner(){
  let list=(S.accounts||[]).filter(a=>a.active!==false && !stayExpired(a));
  list.sort((a,b)=>String(a.room).localeCompare(String(b.room),undefined,{numeric:true}));
  return `<input id="crm-q" enterkeyhint="done" autocomplete="off" autocorrect="off" placeholder="${esc(t("crmSearch"))}" value="${esc(S.crmQuery||"")}" style="margin-bottom:12px">
    ${list.length?`<div class="card" id="crm-results">${list.map(a=>{
      const r=guestRecord(a);
      const searchText=[a.room,a.name,a.nationality].map(v=>String(v||"").toLowerCase()).join(" ");
      return `<div class="crm-row" data-crm="${a.id}" data-crm-search="${esc(searchText)}">
        <div class="crm-av">${esc(String(a.name||"?").trim().charAt(0).toUpperCase())}</div>
        <div class="crm-mid"><b>${esc(a.name||"")}</b>
          <span class="mini">${t("room")} ${esc(a.room)}${a.nationality?" · "+esc(a.nationality):""}</span>
          <span class="mini">${r.bookings.length} ${t("bookings").toLowerCase()} · ${r.reqs.length} ${t("requests").toLowerCase()}${r.fb.length?" · ★ "+r.avg:""}</span>
        </div>
        <span class="crm-go">${ic("back",15)}</span>
      </div>`;
    }).join("")}</div><div class="empty" id="crm-search-empty" style="display:none"><div class="big">${ic("users",30)}</div>No matching guests</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("noGuests")}</div>`}`;
}
function guest360View(id){
  const acc=(S.accounts||[]).find(a=>a.id==id);
  if(!acc) return `<div class="screen fadein">${topBar(t("guest360"),"")}<div class="empty">${t("none")}</div></div>`;
  const r=guestRecord(acc);
  const stat=(n,lb)=>`<div class="g3-s"><b>${n}</b><span class="mini">${lb}</span></div>`;
  return `<div class="screen fadein">
    ${topBar(esc(acc.name||""), t("room")+" "+esc(acc.room))}
    <button class="crumb" id="crumb-crm">${ic("back",15)} ${t("guestCrm")}</button>
    <div class="card g3-head">
      <div class="g3-av">${esc(String(acc.name||"?").trim().charAt(0).toUpperCase())}</div>
      <div class="g3-info">
        <b>${esc(acc.name||"")}</b>
        <span class="mini">${esc(acc.nationality||"")}${acc.phone?" · "+esc(acc.phone):""}</span>
        <span class="mini">${esc(acc.arrival||"")} → ${esc(acc.departure||"")} · ${r.nights} ${t("nights")}</span>
      </div>
    </div>
    <div class="g3-stats">
      ${stat(r.bookings.length, t("bookings"))}
      ${stat(r.acts.length, t("attendedActs"))}
      ${stat(r.orders.length, t("tickets"))}
      ${stat(r.reqs.length, t("requests"))}
      ${stat(r.msgs.length, t("msgCount"))}
      ${stat(r.quiz.length, t("quizPart"))}
      ${stat(r.daysApp, t("appUsage"))}
      ${stat(r.fb.length?r.avg:"—", t("feedback"))}
    </div>
    ${r.favs.length?`<div class="sec"><h3>${ic("star",17)} ${t("favActs")}</h3>
      <div class="card"><div class="g3-tags">${r.favs.map(f=>`<span class="ts-chip">${esc(f)}</span>`).join("")}</div></div></div>`:""}
    ${r.acts.length?`<div class="sec"><h3>${ic("calendar",17)} ${t("attendedActs")}</h3>
      <div class="card">${r.acts.map(a=>`<div class="g3-row"><b>${esc(a.name)}</b>
        <span class="mini">${t("daysShort")[a.day]||""} · ${esc(a.time||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.reqs.length?`<div class="sec"><h3>${ic("chat",17)} ${t("requests")}</h3>
      <div class="card">${r.reqs.map(x=>`<div class="g3-row"><b>${esc(x.type||"")}</b>
        <span class="mini">${esc(x.detail||"")} · ${esc(x.status||"")}</span></div>`).join("")}</div></div>`:""}
    ${r.fb.length?`<div class="sec"><h3>${ic("star",17)} ${t("feedback")}</h3>
      <div class="card">${r.fb.map(f=>`<div class="g3-row"><b>${"\u2605".repeat(Math.max(0,Math.min(5,+f.rate||0)))}</b>
        <span class="mini">${esc(f.comment||"")} · ${fmtDate(f.created_at)}</span></div>`).join("")}</div></div>`:""}
  </div>`;
}
