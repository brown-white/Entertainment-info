/* ================= HOTEL INFO (guest) ================= */
function hotelInfoList(){ return Array.isArray(S.settings.hotelInfo)?S.settings.hotelInfo:[]; }
/* An entry can have several opening times (restaurant 3x, entertainment 3 operations).
   Older entries stored a single `time` string — both shapes work. */
function infoTimes(it){
  if(Array.isArray(it.times)) return it.times.filter(Boolean);
  return it.time?[it.time]:[];
}
/* an entry can hold several pictures; older entries had one `photo` */
function infoPics(it){
  if(Array.isArray(it.photos) && it.photos.length) return it.photos.filter(Boolean);
  return it.photo?[it.photo]:[];
}
function hotelInfoView(){
  const list=hotelInfoList();
  const isMgr=S.session && S.session.role==="manager";
  return `<div class="screen fadein">
    ${topBar(t("hotelInfoTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("hotelInfoHint")}</p>
    ${list.length?`<div class="infogrid">${list.map((it,i)=>`
      <div class="info-card" ${isMgr?`data-infoedit="${i}"`:""}>
        ${(()=>{const pics=infoPics(it);
          return pics.length===1
            ? `<img class="info-img" src="${esc(pics[0])}" alt="" loading="lazy" data-pv="info${i}|0">`
            : photoStrip(pics,"info"+i);})()}
        <div class="info-body">
          <b>${esc(it.title||"")}</b>
          ${it.value?`<span class="info-val">${esc(it.value)}</span>`:""}
          <div class="info-meta">
            ${infoTimes(it).map(tm=>`<span>${mi("clock")}${esc(tm)}</span>`).join("")}
            ${it.place?`<span>${mi("pin")}${esc(it.place)}</span>`:""}
          </div>
        </div>
        ${isMgr?`<span class="info-go">${ic("pen",15)}</span>`:""}
      </div>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noInfo")}</div>`}
    ${isMgr?`<button class="btn" id="info-add" style="margin-top:14px">${ic("plus",16)} ${t("addInfo")}</button>`:""}
  </div>`;
}
function openInfoModal(idx){
  const list=hotelInfoList();
  const editing=(typeof idx==="number");
  const it=editing?list[idx]:{title:"",value:"",time:"",place:"",photo:""};
  const wrap=baseModal(`
    <h3>${ic("pin",20)} ${editing?t("infoTitle"):t("addInfo")}</h3>
    ${photoListEditor("hi", infoPics(it))}
    <label>${t("infoTitle")}</label><input id="hi-t" value="${esc(it.title||"")}" placeholder="WiFi">
    <label>${t("infoValue")}</label><textarea id="hi-v" rows="3">${esc(it.value||"")}</textarea>
    <label>${t("timesLbl")}</label>
    <div id="hi-times">
      ${(infoTimes(it).length?infoTimes(it):[""]).map(tm=>`
        <div class="time-row"><input class="hi-t1" value="${esc(tm)}" placeholder="07:00 - 10:00">
          <button class="btn sm ghost hi-rm" type="button">${ic("close",14)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" id="hi-addtime" style="margin-bottom:10px">${ic("plus",14)} ${t("addTime")}</button>
    <label>${t("infoPlace")}</label><input id="hi-place" value="${esc(it.place||"")}" placeholder="Main restaurant">
    <button class="btn" id="hi-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="hi-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="hi-x">${t("close")}</button>`);
  wrap.querySelector("#hi-x").onclick=()=>wrap.remove();
  let hiPics=infoPics(it).slice();
  wirePhotoList(wrap,"hi",()=>hiPics,l=>{ hiPics=l; });
  const timesBox=wrap.querySelector("#hi-times");
  const wireRemove=()=>wrap.querySelectorAll(".hi-rm").forEach(b=>b.onclick=()=>{
    if(wrap.querySelectorAll(".time-row").length>1) b.parentElement.remove();
    else b.parentElement.querySelector(".hi-t1").value="";
  });
  wireRemove();
  const addT=wrap.querySelector("#hi-addtime");
  if(addT) addT.onclick=()=>{
    const row=document.createElement("div");
    row.className="time-row";
    row.innerHTML='<input class="hi-t1" placeholder="07:00 - 10:00"><button class="btn sm ghost hi-rm" type="button">'+ic("close",14)+'</button>';
    timesBox.appendChild(row); wireRemove();
  };
  wrap.querySelector("#hi-save").onclick=async ()=>{
    const title=wrap.querySelector("#hi-t").value.trim();
    const value=wrap.querySelector("#hi-v").value.trim();
    if(!title){ toastWarn(t("fieldRequired")); return; }
    const times=[...wrap.querySelectorAll(".hi-t1")].map(el=>el.value.trim()).filter(Boolean);
    const rec={title, value, times,
      place:wrap.querySelector("#hi-place").value.trim(),
      photos:hiPics, photo:hiPics[0]||""};
    const next=hotelInfoList().slice();
    if(editing) next[idx]=rec; else next.push(rec);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  const del=wrap.querySelector("#hi-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    const next=hotelInfoList().filter((_,i)=>i!==idx);
    try{ await DB.saveSettings({...S.settings, hotelInfo:next}); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
