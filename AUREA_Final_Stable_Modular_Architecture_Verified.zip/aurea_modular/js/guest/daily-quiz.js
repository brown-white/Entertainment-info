/* ================= DAILY QUIZ ================= */
/* one definition, on the hotel clock */
function todayISO(){ return hotelDateStr(); }
function quizForToday(audience){
  const today=todayISO();
  return (S.quizzes||[]).find(q=>q.audience===audience && String(q.quiz_date).slice(0,10)===today && q.active!==false)||null;
}
function myQuizKey(){
  if(!S.session) return "";
  return S.session.role==="guest" ? String(S.session.room||"") : String(S.session.username||"");
}
function myQuizReply(quizId){
  const me=myQuizKey();
  return (S.quizReplies||[]).find(r=>r.quiz_id===quizId && String(r.who)===me)||null;
}
/* The card guests and entertainers see */
function quizView(){
  const aud = S.session.role==="guest" ? "guest" : "staff";
  const q = quizForToday(aud);
  if(!q){
    return `<div class="screen fadein">
      ${topBar(t("quizTab"),"")}
      <div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("quizNone")}</div>
    </div>`;
  }
  const mine=myQuizReply(q.id);
  return `<div class="screen fadein">
    ${topBar(t("quizTab"),"")}
    <div class="card quizcard">
      <span class="type-meta">${t("quizToday")}</span>
      <h3 class="quiz-q">${esc(q.question)}</h3>
      ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
      ${mine?`<div class="quiz-done">${ic("check",18)} <div><b>${t("quizDone")}</b>
          <span class="mini">${t("quizMine")}: ${esc(mine.answer)}</span></div></div>`
        :`<textarea id="qz-ans" rows="3" placeholder="${esc(t("quizAnswerPh"))}" style="margin-top:12px"></textarea>
          <button class="btn" id="qz-send">${ic("sparkle",16)} ${t("quizSend")}</button>`}
    </div>
  </div>`;
}
async function submitQuizAnswer(){
  const q=quizForToday(S.session.role==="guest"?"guest":"staff"); if(!q) return;
  if(myQuizReply(q.id)){ toastWarn(t("quizAlready")); return; }
  const el=$("#qz-ans"); const val=el?el.value.trim():"";
  if(!val){ toastWarn(t("fieldRequired")); return; }
  try{
    await DB.addQuizReply({quiz_id:q.id, who:myQuizKey(), who_name:S.session.name||"",
      audience:S.session.role==="guest"?"guest":"staff", answer:val});
    toastOk(t("quizDone")); render();
  }catch(e){ toastErr(t("errSave")); }
}
/* Manager: write the question and read every answer */
function quizCenterView(){
  const today=todayISO();
  const gq=quizForToday("guest"), sq=quizForToday("staff");
  const block=(aud,q)=>{
    const replies=q?(S.quizReplies||[]).filter(r=>r.quiz_id===q.id):[];
    return `<div class="sec">
      <h3>${ic("sparkle",18)} ${aud==="guest"?t("quizForGuest"):t("quizForStaff")}</h3>
      ${q?`<div class="card quizcard">
        <h3 class="quiz-q">${esc(q.question)}</h3>
        ${q.hint?`<p class="mini">${esc(q.hint)}</p>`:""}
        ${q.answer_key?`<p class="mini"><b>${t("quizKey")}:</b> ${esc(q.answer_key)}</p>`:""}
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="btn sm ghost" data-quizedit="${q.id}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-quizdel="${q.id}">${ic("trash",14)}</button>
        </div>
      </div>
      <h3 style="margin-top:14px">${t("quizReplies")} (${replies.length})</h3>
      ${replies.length?`<div class="card qr-card">${replies.map(r=>`
        <div class="qr-row"><span class="qr-who">${esc(r.who_name||r.who)}${r.audience==="guest"?` · ${esc(r.who)}`:""}</span>
          <span class="qr-ans">${esc(r.answer)}</span>
          <span class="mini">${fmtDate(r.created_at)}</span></div>`).join("")}</div>`
        :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNoReplies")}</p></div>`}`
      :`<div class="card"><p class="mini" style="padding:4px 2px">${t("quizNone")}</p>
          <button class="btn sm" data-quiznew="${aud}" style="margin-top:10px">${ic("plus",14)} ${t("quizNew")}</button></div>`}
    </div>`;
  };
  return `<div class="screen fadein">
    ${topBar(t("quizCenter"),today)}
    ${hubBack()}
    ${block("guest",gq)}
    ${block("staff",sq)}
  </div>`;
}
function openQuizModal(quiz, audience){
  const editing=!!quiz;
  const q=quiz||{audience:audience||"guest",question:"",hint:"",answer_key:"",quiz_date:todayISO(),active:true};
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${editing?t("quizQuestion"):t("quizNew")}</h3>
    <label>${t("quizFor")}</label>
    <select id="qz-aud">
      <option value="guest" ${q.audience==="guest"?"selected":""}>${t("quizForGuest")}</option>
      <option value="staff" ${q.audience==="staff"?"selected":""}>${t("quizForStaff")}</option>
    </select>
    <label>${t("quizQuestion")}</label>
    <textarea id="qz-q" rows="3">${esc(q.question)}</textarea>
    <label>${t("quizHint")}</label><input id="qz-h" value="${esc(q.hint||"")}">
    <label>${t("quizKey")}</label><input id="qz-k" value="${esc(q.answer_key||"")}">
    <button class="btn" id="qz-save">${t("save")}</button>
    <button class="btn ghost" id="qz-x">${t("close")}</button>`);
  wrap.querySelector("#qz-x").onclick=()=>wrap.remove();
  wrap.querySelector("#qz-save").onclick=async ()=>{
    const rec={audience:wrap.querySelector("#qz-aud").value,
      question:wrap.querySelector("#qz-q").value.trim(),
      hint:wrap.querySelector("#qz-h").value.trim(),
      answer_key:wrap.querySelector("#qz-k").value.trim(),
      quiz_date:q.quiz_date||todayISO(), active:true};
    if(!rec.question){ toastWarn(t("fieldRequired")); return; }
    if(editing) rec.id=q.id;
    try{ await DB.saveQuiz(rec); wrap.remove(); toastOk(t("quizSaved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function busView(){
  const empty=!(S.buses||[]).length;
  return `<div class="screen fadein">
    ${topBar(t("busSchedule"),"")}
    ${hubBack()}
    ${empty && S.session.role!=="manager"?`<div class="empty"><div class="big">${ic("bus",30)}</div>${t("noBusTimes")}</div>`:`
      <div class="bus-grid">
        ${busColumn("toHotel", 1)}
        ${busColumn("toHouse", -1)}
      </div>`}
  </div>`;
}
/* Manager edits who is off and who has entrance duty for a weekday.
   Saved as an override on top of the standard rotation. */
function openDutyModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("clipboard",20)} ${t("editDayOff")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b>${dayIsCustom(day)?` · ${t("customDay")}`:` · ${t("standardDay")}`}</p>
    <label style="margin-top:10px">${t("selectDayOff")}</label>
    <div class="duty-list">
      ${roster.map(r=>`<label class="duty-it">
        <input type="checkbox" class="duty-off" value="${r.n}" ${dp.off.includes(r.n)?"checked":""}>
        <span class="duty-n">${r.n}</span>
        <span class="duty-nm">${esc(r.name||r.role)}</span></label>`).join("")}
    </div>
    <button class="btn" id="duty-save">${t("save")}</button>
    ${dayIsCustom(day)?`<button class="btn ghost" id="duty-reset">${ic("back",15)} ${t("resetDefault")}</button>`:""}
    <button class="btn ghost" id="duty-x">${t("close")}</button>`);
  wrap.querySelector("#duty-x").onclick=()=>wrap.remove();
  wrap.querySelector("#duty-save").onclick=async ()=>{
    const off=[...wrap.querySelectorAll(".duty-off")].filter(b=>b.checked).map(b=>+b.value);
    const ov={off, entrance: dp.entrance};      // entrance is set in Assignments
    const all={...(S.settings.dayOverrides||{})};
    all[String(day)]=ov;
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
  const rst=wrap.querySelector("#duty-reset");
  if(rst) rst.onclick=async ()=>{
    const all={...(S.settings.dayOverrides||{})};
    delete all[String(day)];
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function openBusModal(bus, dir){
  const editing=!!bus;
  const b=bus||{direction:dir||"toHotel",time:"08:00",note:""};
  const wrap=baseModal(`
    <h3>${ic("bus",20)} ${editing?t("editBus"):t("addBus")}</h3>
    <label>${t("busDirection")}</label>
    <select id="bs-dir">
      <option value="toHotel" ${b.direction==="toHotel"?"selected":""}>${t("busToHotel")}</option>
      <option value="toHouse" ${b.direction==="toHouse"?"selected":""}>${t("busToHouse")}</option>
    </select>
    <label>${t("busTimeLbl")}</label>
    <input id="bs-time" value="${esc(b.time||"")}" placeholder="08:00">
    <label>${t("busNoteLbl")}</label>
    <input id="bs-note" value="${esc(b.note||"")}" placeholder="${esc(t("busNoteHint"))}">
    <button class="btn" id="bs-save">${t("save")}</button>
    ${editing?`<button class="btn warn" id="bs-del">${ic("trash",15)} ${t("deleteActivity")}</button>`:""}
    <button class="btn ghost" id="bs-x">${t("close")}</button>`);
  wrap.querySelector("#bs-x").onclick=()=>wrap.remove();
  wrap.querySelector("#bs-save").onclick=async ()=>{
    const rec={direction:wrap.querySelector("#bs-dir").value,
      time:wrap.querySelector("#bs-time").value.trim(),
      note:wrap.querySelector("#bs-note").value.trim(),
      sort:busMinutes(wrap.querySelector("#bs-time").value.trim())};
    if(!rec.time){ return; }
    if(editing) rec.id=b.id;
    await DB.saveBus(rec);
    wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#bs-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delBusQ"),danger:true})) return;
    try{ await DB.deleteBus(b.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function dayChips(){
  const today=todayIndex();
  const sel=(typeof S.planDay==="number")?S.planDay:today;
  return `<div class="daychips">${t("daysShort").map((d,i)=>`<button class="daychip ${sel===i?"on":""} ${i===today?"istoday":""}" data-planday="${i}">${d}</button>`).join("")}</div>`;
}
function myWorkDayView(){
  const num=S.session.number;
  const today=todayIndex();
  const day=(typeof S.planDay==="number")?S.planDay:today;
  if(!num){
    return `<div class="screen fadein">
      ${topBar(t("myWorkDay"),S.session.name)}
      ${dayChips()}
      <div class="empty"><div class="big">${ic("users",30)}</div>${t("noNumber")}</div>
      ${workdayUnifiedTimeline(day,[])}
      ${workdayFeedbackCard()}
      ${dayPlanStandards(day)}
    </div>`;
  }
  const info=personDayInfo(num,day);
  const unavailableToday=info.isOff||info.isVacation||info.isAbsent;
  const myActs=(unavailableToday?[]:S.activities.filter(a=>a.day===day && canSeeGuests(a))).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  const liveAct = isToday(day) ? (myActs.find(a=>activityStatus(a)==="live") || myActs.find(a=>activityStatus(a)==="todo") || myActs[myActs.length-1]) : null;
  const photoRing = liveAct ? statusRing(liveAct) : "";
  const photoBlock = `<div class="wd-photo">
      <div class="wd-av avring ${photoRing}">${S.session.photo?`<img src="${esc(S.session.photo)}" alt="">`:`<span>${esc(String(S.session.name||"?").trim().charAt(0).toUpperCase())}</span>`}
        <span class="wd-num">${num}</span></div>
      <div class="wd-who"><b>${esc(S.session.name)}</b>
        <span class="mini">${esc(roleForNumber(num))}</span>
        ${liveAct?`<span style="margin-top:4px">${statusPill(liveAct)} <span class="mini">${esc(liveAct.name)}</span></span>`:""}</div>
    </div>`;
  let banner="";
  if(info.isVacation){
    banner=`<div class="wd-banner off">${ic("sun",22)} You are on vacation today — enjoy your holiday ☀️</div>`;
  }else if(info.isAbsent){
    banner=`<div class="wd-banner off">${ic("user",22)} You are marked absent today.</div>`;
  }else if(info.isOff){
    const nd=(day+1)%7, nu=info.u, tomorrowWorking=nu?availableOn(nu,nd,(typeof dayDutyDate==="function"?dayDutyDate(nd):assignDateStr(nd))):true;
    banner=`<div class="wd-banner off">${ic("sun",22)} Have a nice day — today is your day off. Enjoy${tomorrowWorking?", but sleep early — you have work tomorrow :)":" your day off :)"}</div>`;
  }else if(info.isEntrance){
    banner=`<div class="wd-banner entrance">${ic("door",20)} ${t("youHaveEntrance")} · ${esc(info.entranceWindow)}</div>`;
  }
  return `<div class="screen fadein workday-clean">
    ${topBar(t("myWorkDay"),"#"+num+" · "+S.session.name)}
    ${dayChips()}
    ${photoBlock}
    ${banner}
    ${info.makeupForMe?`<div class="wd-banner makeup">${ic("star",18)} ${t("makeupPractice")}: ${esc(makeupText(info.makeupForMe))}</div>`:""}
    ${info.isDJ?`<div class="wd-banner dj">${ic("bell",18)} ${t("djSchedule")}: ${esc(info.djNote)}</div>`:""}
    ${workdayUnifiedTimeline(day,myActs)}
    ${workdayCompactInfo(day)}
    ${workdayFeedbackCard()}
    ${dayPlanStandards(day)}
  </div>`;
}
function taskDueMinutes(x){
  if(!x || !x.due) return 24*60+1;
  const d=new Date(String(x.due).replace(" ","T"));
  if(isNaN(d.getTime())) return 24*60+1;
  return d.getHours()*60+d.getMinutes();
}
function taskBelongsToDay(x,day){
  if(!x || !(x.assigned_to===S.session.username || !x.assigned_to || x.assigned_to==="team")) return false;
  if(["verified"].includes(taskStatus(x))) return false;
  const target=assignDateStr(day);
  if(x.due){
    const d=new Date(String(x.due).replace(" ","T"));
    if(!isNaN(d.getTime())) return localDateKey(d)===target;
  }
  return isToday(day) && ["new","accepted","progress"].includes(taskStatus(x));
}
function workdayUnifiedTimeline(day,acts){
  const activityItems=(acts||[]).map(a=>({kind:"activity",sort:timeToMin(a.time)??9999,a}));
  const taskItems=(S.tasks||[]).filter(x=>taskBelongsToDay(x,day)).map(x=>({kind:"task",sort:taskDueMinutes(x),x}));
  const items=activityItems.concat(taskItems).sort((a,b)=>a.sort-b.sort);
  return `<div class="sec workday-yourday"><h3>${ic("clock",18)} ${t("yourDay")}</h3>
    <p class="mini wd-sub">Activities and manager tasks in one place.</p>
    ${items.length?`<div class="tlx unified">${items.map(it=>{
      if(it.kind==="task"){
        const x=it.x, st=taskStatus(x), over=taskIsOverdue(x);
        const due=x.due?new Date(String(x.due).replace(" ","T")):null;
        const tm=due&&!isNaN(due.getTime())?fmtTime(due.toISOString()):"";
        return `<div class="tlx-row task ${st} ${over?"overdue":""}">
          <span class="tlx-mark">${ic("check",12)}</span>
          <div class="tlx-body task-body" data-taskopen="${x.id}">
            <span class="eyebrow">${t("tasks")}</span>
            <b>${esc(x.title||x.type||t("tasks"))}</b>
            <span class="mini">${tm?esc(tm)+(x.location?" · "+esc(x.location):""):(x.location?esc(x.location):"")}</span>
            ${x.desc?`<span class="mini">${esc(x.desc)}</span>`:""}
            <span class="task-inline-status">${taskStatusLabel(st)}</span>
          </div>
        </div>`;
      }
      const a=it.a, st=isToday(day)?activityStatus(a):"todo", booked=seatsTaken(a.id);
      return `<div class="tlx-row ${st}">
        <span class="tlx-mark">${st==="done"?ic("check",13):(st==="live"?"":"")}</span>
        <div class="tlx-body" data-actopen="${esc(String(a.id))}">
          ${st==="live"?`<span class="eyebrow tlx-now">${t("nowLbl")}</span>`:""}
          <span class="eyebrow">${t("activities")||"Activity"}</span>
          <b>${esc(a.name)}</b>
          <span class="mini">${esc(String(a.time||""))}${a.location?" · "+esc(a.location):""}</span>
          ${booked?`<span class="mini">${booked} ${t("registered")}</span>`:""}
        </div>
      </div>`;
    }).join("")}</div>`:`<div class="empty compact-empty">${t("noneToday")}</div>`}
  </div>`;
}
function workdayCompactInfo(day){
  const dp=dayPlanFor(day);
  const evs=(S.activities||[]).filter(a=>a.day===day && activitySlot(a)==="event")
    .slice().sort((x,y)=>(timeToMin(x.time)||0)-(timeToMin(y.time)||0));
  return `<div class="sec wd-dayinfo"><h3>${ic("calendar",18)} ${t("dayInfoSec")}</h3>
    <div class="card wd-info-compact">
      <div><span>${t("dressCode")}</span><b>${esc(dp.dress||"—")}</b></div>
      <div><span>${t("eveningShowLbl")}</span><b>${esc(dp.eveningShow||"—")}</b>${dp.showTime?`<small>${esc(dp.showTime)}</small>`:""}</div>
      <div><span>${t("liveBandLbl")}</span><b>${esc(dp.liveBand||"—")}</b></div>
      <div><span>${t("entranceDuty")}</span><b>${personTag(dp.entrance)||"—"}</b></div>
      ${evs.length?`<div class="wide"><span>${t("eventsToday")}</span><b>${evs.map(e=>esc(String(e.time||"").split(/\s*[–—-]\s*/)[0])+" · "+esc(e.name)).join("<br>")}</b></div>`:""}
    </div>
  </div>`;
}
/* Collecting guest feedback is a daily job, so it sits inside the work day
   rather than behind a menu item they would have to go looking for. */
function workdayFeedbackCard(){
  const me=(S.session&&S.session.username)||"";
  const mine=(S.feedback||[]).filter(f=>String(f.by_user||"")===String(me))
    .sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
  const today=mine.filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    return ts && !isNaN(ts.getTime()) && localDateKey(ts)===localDateKey(new Date());
  });
  return `<div class="sec wd-feedback-compact">
    <div class="wd-fb-head"><div><h3>${ic("star",18)} ${t("fbMyFeedback")}</h3><p class="mini">${today.length} ${t("today")} · ${mine.length} ${t("feedback")}</p></div>
      <button class="btn sm" id="btn-addfb">＋ ${t("fbNew")}</button></div>
  </div>`;
}
/* full day detail: theme, dress, timings, show — used by staff + manager */
/* The day's special events (day events + parties) pulled from the real programme */
function staffFeedbackView(){
  const mine=S.feedback.filter(f=>f.by_user===S.session.username);
  return `<div class="screen fadein">
    ${topBar(t("feedback"),S.session.name)}
    <button class="btn" id="btn-addfb" style="margin:0 0 14px">\uFF0B ${t("fbNew")}</button>
    ${mine.length?`<p class="mini" style="margin:-4px 0 8px">${t("fbTapHint")}</p>
      <div class="card">${mine.map(fbRowHtml).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("star",30)}</div>${t("noMyFeedback")}</div>`}
  </div>`;
}
function chatThreadScreen(){
  const isStaff=String(S.chatRoom).startsWith("staff:");
  let title,sub;
  if(isStaff){ const un=S.chatRoom.slice(6); const u=S.users.find(x=>x.username===un);
    title=(u&&u.display_name)||un; sub=t("staff"); }
  else { title=accountName(S.chatRoom); sub=t("room")+" "+S.chatRoom; }
  return `<div class="screen fadein">
    <div class="top">
      <div class="who" style="display:flex;align-items:center;gap:10px">
        <button class="iconbtn" id="btn-chatback" aria-label="back">${ic("back",20)}</button>
        <div><h2 style="font-size:22px">${esc(title)}</h2><p>${esc(sub)}</p></div>
      </div>
    </div>
    ${chatTools(S.chatRoom)}
    ${threadView(S.chatRoom,"team")}
  </div>`;
}
/* Tidying a conversation: pick a few messages, or empty it completely. */
function chatSelOn(){ return Array.isArray(S.chatSel); }
function chatSelHas(id){ return chatSelOn() && S.chatSel.includes(id); }
function chatTools(room){
  if(!S.session || S.session.role!=="manager") return "";
  const total=(S.messages||[]).filter(m=>m.room===room).length;
  if(!total) return "";
  if(!chatSelOn()){
    return `<div class="chat-tools">
      <button class="btn sm ghost" id="ct-select">${ic("check",14)} ${t("selectMsgs")}</button>
      <button class="btn sm ghost warn" id="ct-clear">${ic("trash",14)} ${t("clearChat")}</button>
    </div>`;
  }
  const n=S.chatSel.length;
  return `<div class="chat-tools sel">
    <span class="ct-n">${n} ${t("selectedWord")}</span>
    <button class="btn sm ghost" id="ct-all">${n===total?t("selectNone"):t("selectAll")}</button>
    <button class="btn sm warn" id="ct-del" ${n?"":"disabled"}>${ic("trash",14)} ${t("delete")}</button>
    <button class="btn sm ghost" id="ct-cancel">${t("cancelBtn")}</button>
  </div>`;
}
function staffChatInbox(){
  const staff=S.users.filter(u=>u.role==="staff");
  const rows=staff.map(u=>{
    const room="staff:"+u.username;
    const ms=S.messages.filter(m=>m.room===room);
    const last=ms[ms.length-1];
    const unread=ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length;
    return {u,room,last,unread,ts:last?Date.parse(last.created_at):0};
  }).sort((a,b)=>b.ts-a.ts);
  return `<div class="chatlist">
    ${rows.map(c=>`<div class="card" data-staffchat="${esc(c.u.username)}">
      <div class="mb-av" style="width:44px;height:44px;flex:none">${esc((c.u.display_name||c.u.username).trim().charAt(0).toUpperCase())}</div>
      <div style="min-width:0;flex:1">
        <div class="nm">${esc(c.u.display_name||c.u.username)}</div>
        <div class="lastm">${c.last?esc(c.last.text):"—"}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
        ${c.last?`<span class="mini">${fmtTime(c.last.created_at)}</span>`:""}
        ${c.unread?`<span class="badge">${c.unread}</span>`:""}
      </div>
    </div>`).join("")||`<div class="empty"><div class="big">${ic("users",34)}</div>${t("none")}</div>`}
  </div>`;
}
/* A room name starting with "staff:" is an entertainer thread — it belongs
   in Team, never in the guest inbox. */
function isStaffRoom(room){ return String(room||"").startsWith("staff:"); }
function chatInboxInner(){
  const rooms={};
  S.messages.filter(m=>!isStaffRoom(m.room)).forEach(m=>{ (rooms[m.room]=rooms[m.room]||[]).push(m); });
  const list=Object.entries(rooms).map(([room,ms])=>({room,last:ms[ms.length-1],
    unread:ms.filter(m=>m.sender==="guest"&&!m.read_by_team).length}))
    .sort((a,b)=>new Date(b.last.created_at)-new Date(a.last.created_at));
  return `<div class="chatlist">
      ${list.length?list.map(c=>`<div class="card" data-chatroom="${esc(c.room)}">
        <div style="min-width:0">
          <div class="nm">${esc(accountName(c.room))} <span class="mini">· ${t("room")} ${esc(c.room)}</span></div>
          <div class="lastm">${esc(c.last.text)}</div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex:none">
          <span class="mini">${fmtTime(c.last.created_at)}</span>
          ${c.unread?`<span class="badge">${c.unread}</span>`:""}
        </div>
      </div>`).join(""):`<div class="empty"><div class="big">${ic("chat",34)}</div>${t("noMessages")}</div>`}
    </div>`;
}
function bookingsView(title){
  return `<div class="screen fadein">
    ${topBar(title,t("days")[S.day])}
    ${bookingsInner()}
  </div>`;
}
function bookingsInner(){
  const isMgr=S.session.role==="manager";
  let acts=S.activities.filter(a=>a.day===S.day);
  if(!isMgr) acts=acts.filter(a=>canSeeGuests(a));
  return dayTabs() + (acts.length?acts.sort((x,y)=>String(x.time).localeCompare(String(y.time))).map(a=>{
    const bks=bookingsFor(a.id);
    const visible=canSeeGuests(a);
    return `<div class="card">
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:${visible&&bks.length?8:0}px;gap:8px">
        <h4 style="font-size:17px;min-width:0">${visible?"":mi("lock")}${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></h4>
        <span class="pill">${a.capacity>0?seatsTaken(a.id)+"/"+a.capacity:bks.length+" "+t("guests")}</span></div>
      ${visible?bks.map(b=>`<div class="booking-line">
        <span style="min-width:0" ${isMgr&&accountForRoom(b.room)?`data-bkguest="${accountForRoom(b.room).id}"`:""}><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}${isMgr&&b.nationality?` · ${esc(b.nationality)}`:""}${isMgr&&b.phone?` · ${esc(b.phone)}`:""}
          ${b.created_at?`<br><span class="mini">${whenLabel(b.created_at)}</span>`:""}</span>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="pill">${((+b.adults)||0)+((+b.children)||0)} ${t("personsShort")}${b.status==="waitlist"?" · …":""}</span>
          ${isMgr?`<button class="btn sm ghost" data-bkedit="${b.id}" aria-label="${t("editBooking")}">${ic("pen",14)}</button>
          <button class="btn sm warn" data-bkdel="${b.id}" aria-label="${t("removeBooking")}">${ic("close",14)}</button>`:""}
        </span></div>`).join(""):""}
    </div>`;}).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
