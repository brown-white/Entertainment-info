/* ================= PHOTO GALLERY ================= */
function galleryView(){
  const isMgr=S.session && S.session.role==="manager";
  const isStaff=S.session && S.session.role==="staff";
  const canAdd=isMgr||isStaff;
  const list=(S.photos||[]);
  return `<div class="screen fadein">
    ${topBar(t("galleryTab"),"")}
    <p class="mini" style="margin:-4px 0 14px">${t("galleryHint")}</p>
    ${canAdd?`<button class="btn" id="ph-add" style="margin-bottom:14px">${ic("plus",16)} ${t("addPhoto")}</button>`:""}
    ${list.length?`<div class="photogrid">${list.map((ph,i)=>`
      <figure class="photo-it">
        <img src="${esc(ph.url)}" alt="${esc(ph.caption||"")}" loading="lazy" data-pv="gal|${i}">
        ${ph.caption?`<figcaption>${esc(ph.caption)}</figcaption>`:""}
        ${isMgr?`<button class="ph-del" data-phdel="${ph.id}" aria-label="${t("deleteActivity")}">${ic("trash",14)}</button>`:""}
      </figure>`).join("")}</div>`
      :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("noPhotos")}</div>`}
  </div>`;
}
function openPhotoModal(){
  const wrap=baseModal(`
    <h3>${ic("sparkle",20)} ${t("addPhoto")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("photoCaption")}</label><input id="ph-cap" placeholder="${esc(t("photoCaption"))}">
    <button class="btn" id="ph-save">${t("save")}</button>
    <button class="btn ghost" id="ph-x">${t("close")}</button>`);
  let url="";
  wirePhotoPicker(wrap, ()=>url, v=>{ url=v; });
  wrap.querySelector("#ph-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ph-save").onclick=async ()=>{
    if(!url){ toastWarn(t("uploadPhoto")); return; }
    try{
      await DB.addPhoto({url, caption:wrap.querySelector("#ph-cap").value.trim(),
        day:todayIndex(), created_by:S.session.username||S.session.name||""});
      wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
