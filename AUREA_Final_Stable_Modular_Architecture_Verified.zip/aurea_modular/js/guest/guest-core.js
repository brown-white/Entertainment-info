/* ---------------- guest ---------------- */
function guestWeatherChip(){
  if(!featureOn("weather")) return "";
  const w=S.weather;
  if(w && !w.error && w.cur){
    const c=w.cur;
    return `<button class="guest-weather" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
      <span class="gw-icon">${ic(wmoIcon(c.weather_code),18)}</span>
      <span class="gw-temp">${Math.round(c.temperature_2m)}°</span>
      <span class="gw-label">${esc(wmoLabel(c.weather_code))}</span>
    </button>`;
  }
  return `<button class="guest-weather loading" data-tab="weather" aria-label="${esc(t("weatherTab"))}">
    <span class="gw-icon">${ic("sun",18)}</span><span class="gw-label">${esc(t("weatherTab"))}</span>
  </button>`;
}
function guestHomeTopBar(g,todayIdx){
  const role="guest", anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top guest-top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow"><button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button></div>
  </div>
  <div class="guest-welcome-head">
    <div><h1>${esc(t("welcome"))}, ${esc(g.name)}</h1><p>${esc(t("room"))} ${esc(g.room)} · ${esc(t("days")[todayIdx])}</p></div>
    ${guestWeatherChip()}
  </div>`;
}
function guestQuickActions(){
  const items=[];
  if(featureOn("hotelinfo")) items.push(["hotelinfo","pin",t("hotelInfoTab")]);
  if(featureOn("gallery")) items.push(["gallery","sparkle",t("galleryTab")]);
  if(featureOn("quiz")) items.push(["quiz","sparkle",t("quizTab")]);
  if(!items.length) return "";
  return `<div class="guest-quick-actions">${items.map(([tab,icon,label])=>
    `<button data-tab="${tab}" class="gqa"><span class="gqa-ic">${ic(icon,22)}</span><span>${esc(label)}</span><i>${ic("back",14)}</i></button>`
  ).join("")}</div>`;
}
function openGuestActivityDetail(a){
  if(!a) return;
  const unlimited=!(+a.capacity), taken=seatsTaken(a.id), left=Math.max(0,(+a.capacity||0)-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id), status=isToday(a.day)?activityStatus(a):"";
  const wrap=baseModal(`<div class="guest-detail">
    <div class="gd-photo"><img src="${esc(a.image||IMG.show)}" alt=""><span class="gd-cat">${esc(catLabel(normCat(a)))}</span></div>
    <div class="gd-copy">
      <h3>${esc(a.name)}</h3>
      <div class="gd-meta"><span>${mi("clock")}${esc(a.time)}${a.end_time?" – "+esc(a.end_time):""}</span><span>${mi("pin")}${esc(a.location||"")}</span></div>
      ${a.desc?`<p class="gd-desc">${esc(a.desc)}</p>`:""}
      <div class="gd-facts">
        ${!unlimited?`<span>${ic("users",16)} <b>${full?t("full"):left+" "+t("seatsLeft")}</b></span>`:""}
        ${status?`<span>${statusDot(a)} <b>${status==="live"?t("st_live"):status==="done"?t("st_done"):t("st_todo")}</b></span>`:""}
      </div>
    </div>
    ${mine?`<div class="gd-booked">${ic("check",17)} ${mine.status==="booked"?t("booked"):t("onWaitlist")}</div>`:
      `<button class="btn guest-book-now" id="gd-book">${full?t("waitlist"):t("book")}</button>`}
    <button class="btn ghost" id="gd-close">${t("close")}</button>
  </div>`);
  wrap.querySelector("#gd-close").onclick=()=>wrap.remove();
  const book=wrap.querySelector("#gd-book");
  if(book) book.onclick=()=>{wrap.remove();openBookModal(a);};
}
function guestView(){
  if(String(S.tab||"").startsWith("cp:")) return customPageView(S.tab.slice(3));
  if(String(S.tab||"").startsWith("emp:")) return employeeView(S.tab.slice(4));
  if(S.tab==="weather") return weatherView();
  if(S.tab==="quiz") return quizView();
  if(S.tab==="gallery") return galleryView();
  if(S.tab==="hotelinfo") return hotelInfoView();
  const g=S.session;
  const todayIdx=todayIndex();
  if(S.tab==="home"){
    const todays=S.activities.filter(a=>a.day===todayIdx);
    const hl=todays.find(a=>a.highlight)||todays[0];
    const wm=(S.settings.welcomeMsg||"").trim();
    return `<div class="screen fadein">
      ${guestHomeTopBar(g,todayIdx)}
      ${stayCard((S.accounts||[]).find(a=>a.id===g.accountId)||(S.accounts||[]).find(a=>String(a.room)===String(g.room)))}
      ${wm?`<div class="card guest-welcome-msg">${esc(wm)}</div>`:""}
      ${guestQuickActions()}
      ${heroCarousel([hl].concat(todays.filter(a=>a!==hl && a.highlight)))}
      <div class="quickrow">
        <button id="btn-req-song"><span>${ic("music",22)}</span>${t("songRequest")}</button>
        <button id="btn-req-bday"><span>${ic("gift",22)}</span>${t("birthdayRequest")}</button>
      </div>
      <div class="sec"><h3>${t("todayProgram")}</h3>
        ${todays.filter(a=>a!==hl).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a)).join("")||`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
      </div>
      ${reviewDue(g)?reviewBlock():""}
      ${socialBlock()}
    </div>`;
  }
  if(S.tab==="program") return browseView(menuLabel("menuProgram",t("program")));
  if(S.tab==="social") return socialPageView();
  if(S.tab==="teaminfo") return teamInfoView();
  if(S.tab==="tickets") return guestTicketsView();
  if(S.tab==="chat"){
    return `<div class="screen fadein">
      ${topBar(t("chat"),accountName(g.room))}
      ${threadView(g.room,"guest")}
    </div>`;
  }
  const mine=S.bookings.filter(b=>b.room===g.room);
  const orders=myOrders();
  const reqs=myRequestsList();
  const favActs=S.activities.filter(a=>S.favorites.includes(a.id));
  return `<div class="screen fadein">
    ${topBar(t("myStay"),g.name)}
    <div class="card profcard">
      <div class="pf-ava">${ic("user",26)}</div>
      <div style="min-width:0">
        <h4>${esc(g.name)}</h4>
        <p class="mini">${t("room")} ${esc(g.room)}${g.nationality?` · ${esc(g.nationality)}`:""}</p>
        <p class="mini">${esc(g.arrival||"")} → ${esc(g.departure||"")}</p>
      </div>
      <button class="btn sm ghost" id="btn-chpass" style="flex:none">${ic("key",15)} ${t("changePass")}</button>
    </div>
    <div class="sec"><h3>${t("myBookings")} <span class="count">${mine.length}</span></h3>
      ${mine.length?mine.map(b=>{
        const a=S.activities.find(x=>x.id===b.activity_id); if(!a) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" data-pvsingle="${esc(a.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[a.day]}</span><h4>${esc(a.name)}</h4>
            <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div></div>
          <div class="side">
            <span class="chip ${b.status==="booked"?"ok":""}">${b.status==="booked"?t("booked"):t("onWaitlist")}</span>
            <button class="btn sm warn" data-cancel="${b.id}">${ic("close",14)}</button>
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("noBookings")}</div>`}
    </div>
    <div class="sec"><h3>${t("myTickets")} <span class="count">${orders.length}</span></h3>
      ${orders.length?orders.map(o=>{
        const tk=S.tickets.find(x=>x.id===o.ticket_id); if(!tk) return "";
        return `<div class="card act">
          <img class="thumb" src="${esc(tk.image||IMG.show)}" alt="" data-pvsingle="${esc(tk.image||IMG.show)}">
          <div class="mid"><span class="catbadge">${t("days")[tk.day]} · ${esc(tk.time)}</span><h4>${esc(tk.name)}</h4>
            <div class="meta"><span>${mi("ticket")}×${o.qty}</span><span>${esc(tk.price||"")}</span>${o.collect_from?`<span>${mi("user")}${esc(o.collect_from)}</span>`:""}</div></div>
          <div class="side">
            <span class="chip ${o.status==="paid"?"ok":"res"}">${o.status==="paid"?t("paid"):t("reserved")}</span>
            ${o.status==="paid"?"":`<button class="btn sm warn" data-cancelorder="${o.id}">${ic("close",14)}</button>`}
          </div></div>`;
      }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
    </div>
    ${reqs.length?`<div class="sec"><h3>${t("myRequests")} <span class="count">${reqs.length}</span></h3>
      <div class="card">${reqs.map(r=>`<div class="booking-line">
        <span>${ic(r.type==="song"?"music":"gift",15)} ${esc(r.detail)}${r.date?` · ${esc(r.date)}`:""}</span>
        <span style="display:flex;gap:6px;align-items:center">
          <span class="chip ${r.status==="done"?"ok":"res"}">${r.status==="done"?t("done"):t("statusNew")}</span>
          ${r.status==="done"?"":`<button class="btn sm warn" data-delreq="${r.id}">${ic("close",14)}</button>`}
        </span></div>`).join("")}</div>
    </div>`:""}
    <div class="sec"><h3>${t("favorites")} <span class="count">${favActs.length}</span></h3>
      ${favActs.length?favActs.map(a=>activityCard(a)).join(""):`<div class="empty"><div class="big">${ic("heart",30)}</div>${t("noFavs")}</div>`}
    </div>
    ${reviewDue(g)?reviewBlock():""}
  </div>`;
}
function socialPageView(){
  const st=S.settings;
  const socials=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube]].filter(x=>x[1]);
  const reviews=[["Google",st.google],["Facebook",st.facebook],["Tripadvisor",st.tripadvisor],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  const wa=waLink();
  return `<div class="screen fadein">
    ${topBar(t("socialPage"),S.settings.name)}
    ${S.session.role==="guest"?`<div class="card ratecard">
      <b>${t("howWasIt")}</b>
      <div class="rate-stars">${[1,2,3,4,5].map(r=>`<button class="rs" data-guestrate="${r}" aria-label="${r}">${ic("star",26)}</button>`).join("")}</div>
    </div>`:""}
    ${wa?`<a class="wa-cta" href="${esc(wa)}" target="_blank" rel="noopener">${brandIc("WhatsApp")} ${t("contactWa")}</a>`:""}
    ${socials.length?`<div class="sec"><h3>${t("followUs")}</h3>
      ${socials.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic">${brandIc(n)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
    ${reviews.length?`<div class="sec"><h3>${t("leaveReview")}</h3>
      ${reviews.map(([n,u])=>`<a class="card social-big" href="${esc(u)}" target="_blank" rel="noopener">
        <span class="sb-ic star">${ic("star",17)}</span><span class="sb-nm">${n}</span><span class="sb-go">${ic("back",16)}</span></a>`).join("")}
    </div>`:""}
  </div>`;
}
function teamInfoView(){
  /* one single team list — the real accounts the manager edits, so what she
     changes on a person is exactly what guests see. */
  const list=(S.users||[])
    .filter(u=>(u.role==="staff"||u.role==="manager") && u.active!==false)
    .map(u=>({...u, name:u.display_name||u.username}))
    .sort((a,b)=>{
      const am=/manager/i.test(a.position||"")?0:1, bm=/manager/i.test(b.position||"")?0:1;
      return am-bm || (a.number||99)-(b.number||99) || a.id-b.id;
    });
  const entCount=list.filter(p=>!/manager/i.test(p.position||"")).length;
  return `<div class="screen fadein">
    ${topBar(t("teamPage"),S.settings.name)}
    <div class="teamcount card"><b class="serif">${entCount}</b><span>${t("ourTeam")} · ${entCount} ${t("entertainersWord")}</span></div>
    ${list.length?list.map(p=>teamCard(p)).join(""):`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
  </div>`;
}
/* match a Meet-the-Team card to a real team account so it can open the profile */
function userForProfileName(name){
  const nm=String(name||"").trim().toLowerCase();
  if(!nm) return null;
  return (S.users||[]).find(u=>String(u.display_name||u.username||"").trim().toLowerCase()===nm)||null;
}
function teamCard(p){
  const chips=x=>String(x||"").split(/[·,;\/|]+/).map(v=>v.trim()).filter(Boolean)
    .map(v=>`<span class="tchip">${esc(v)}</span>`).join("");
  const linked=userForProfileName(p.name);
  return `<div class="card team-card${linked?" tappable":""}" ${linked?`data-uview="${esc(linked.username)}"`:""}>
    <div class="tc-photo">${p.photo?`<img src="${esc(p.photo)}" alt="" loading="lazy">`:`<div class="tc-mono serif">${esc((p.name||"?").trim().charAt(0).toUpperCase())}</div>`}</div>
    <div class="tc-body">
      <h4 class="serif">${esc(p.name)}</h4>
      <p class="tc-pos">${esc(p.position||"")}</p>
      <p class="mini">${esc(p.nationality||"")}${p.nationality&&p.languages?" · ":""}${esc(p.languages||"")}</p>
      ${p.skills?`<div class="tc-chips">${chips(p.skills)}</div>`:""}
      ${p.instagram?`<a class="btn sm ghost social-a" href="${esc(p.instagram)}" target="_blank" rel="noopener">${brandIc("Instagram")} Instagram</a>`:""}
    </div>
  </div>`;
}
function guestTicketsView(){
  return `<div class="screen fadein">
    ${topBar(t("tickets"),"")}
    <p class="mini" style="margin:-6px 0 16px">${t("payNote")}</p>
    ${S.tickets.length?S.tickets.map(tk=>{
      const sold=ticketsSold(tk.id), left=tk.capacity>0?Math.max(0,tk.capacity-sold):null;
      const soldOut=left!==null&&left<=0;
      return `<div class="tk">
        <img src="${esc(tk.image||IMG.show)}" alt="" loading="lazy">
        <div class="bd">
          <h4>${esc(tk.name)}</h4>
          <p class="mini">${t("days")[tk.day]} · ${mi("clock")}${esc(tk.time)} · ${mi("pin")}${esc(tk.location)}${left!==null?` · ${left} ${t("seatsLeft")}`:""}</p>
          <p class="desc">${esc(tk.desc)}</p>
          <div class="rowend">
            <span class="price">${esc(tk.price||"")}</span>
            ${soldOut?`<span class="chip full">${t("soldOut")}</span>`:`<button class="btn sm" data-buy="${tk.id}">${t("buyTicket")}</button>`}
          </div>
        </div>
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("ticket",30)}</div>${t("ticketsNone")}</div>`}
  </div>`;
}
function reviewBlock(){
  const st=S.settings;
  const links=[["Tripadvisor",st.tripadvisor],["Google",st.google],["HolidayCheck",st.holidaycheck]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("reviews")}</h3>
    <p class="mini" style="margin:4px 0 12px">${t("reviewsSub")}</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${links.map(([n,u])=>`<a class="btn sm ghost" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${ic("star",14)} ${n}</a>`).join("")}
    </div></div>`;
}
function socialBlock(){
  const st=S.settings;
  const links=[["Instagram",st.instagram],["TikTok",st.tiktok],["Facebook",st.facebook],["YouTube",st.youtube]].filter(x=>x[1]);
  if(!links.length) return "";
  return `<div class="sec card" style="padding:18px">
    <h3 style="font-size:22px">${t("followUs")}</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
      ${links.map(([n,u])=>`<a class="btn sm ghost social-a" style="text-decoration:none" href="${esc(u)}" target="_blank" rel="noopener">${brandIc(n)} ${n}</a>`).join("")}
    </div></div>`;
}

