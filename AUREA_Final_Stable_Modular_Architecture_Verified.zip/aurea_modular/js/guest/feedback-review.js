/* ================= FEEDBACK -> REVIEW ================= */
function reviewLinks(){
  const st=S.settings;
  return [["google",st.google],["tripadvisor",st.tripadvisor],["holidaycheck",st.holidaycheck]]
    .filter(([k,v])=>v&&/^https?:\/\//i.test(v));
}
/* After a happy rating, invite the guest to post it publicly. */
function openReviewInvite(rate){
  const links=reviewLinks();
  if(!links.length || S.settings.reviewAsk===false) return;
  if(rate<4) return;                       // unhappy guests are never pushed outside
  const wrap=baseModal(`
    <h3>${ic("star",20)} ${t("thankYou")}</h3>
    <p class="mini">${t("shareExp")}</p>
    <div style="margin-top:14px">
      ${links.map(([k,v])=>`<a class="btn" href="${esc(v)}" target="_blank" rel="noopener"
        style="display:block;text-align:center;margin-bottom:8px">${k==="google"?"Google":k==="tripadvisor"?"Tripadvisor":"HolidayCheck"}</a>`).join("")}
    </div>
    <button class="btn ghost" id="rv-x">${t("reviewLater")}</button>`);
  wrap.querySelector("#rv-x").onclick=()=>wrap.remove();
}
