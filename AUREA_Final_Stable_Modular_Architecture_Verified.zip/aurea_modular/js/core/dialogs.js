function openNotesModal(){
  const role=S.session?S.session.role:"guest";
  const list=visibleNotes(role);
  const wrap=baseModal(`
    <h3>${ic("bell",18)} ${t("notifications")}</h3>
    ${role==="manager"?`<button class="btn sm" id="n-new" style="margin-bottom:12px">＋ ${t("newAnnouncement")}</button>`:""}
    ${list.length?list.map(n=>`<div class="card" style="padding:12px 14px">
      <div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline">
        <b>${esc(n.title)}</b>
        <span style="display:flex;gap:6px;align-items:center;flex:none">
          <span class="mini">${fmtTime(n.created_at)}</span>
          ${role==="manager"?`<button class="btn sm warn" data-notedel="${n.id}">${ic("close",14)}</button>`:""}
        </span>
      </div>
      <p style="font-size:14.5px;margin-top:4px">${esc(n.body)}</p>
      ${role==="manager"?`<p class="mini" style="margin-top:4px">${n.audience==="all"?t("audAll"):n.audience==="guests"?t("audGuests"):t("audTeam")}</p>`:""}
    </div>`).join(""):`<div class="empty"><div class="big">${ic("bell",30)}</div>${t("noNotifs")}</div>`}
    <button class="btn ghost" id="n-x">${t("close")}</button>`);
  const maxId=list.reduce((m,n)=>Math.max(m,n.id),S.seenNote);
  if(maxId>S.seenNote){ S.seenNote=maxId; persist(); }
  wrap.querySelector("#n-x").onclick=()=>{ wrap.remove(); render(); };
  const nn=wrap.querySelector("#n-new");
  if(nn) nn.onclick=()=>{ wrap.remove(); openComposeNoteModal(); };
  wrap.querySelectorAll("[data-notedel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteNote(+b.dataset.notedel); wrap.remove(); openNotesModal();
  });
}
function openComposeNoteModal(){
  const wrap=baseModal(`
    <h3>＋ ${t("newAnnouncement")}</h3>
    <label>${t("actName")}</label><input id="nn-title">
    <label>${t("desc")}</label><textarea id="nn-body" rows="3"></textarea>
    <label>${t("audience")}</label>
    <select id="nn-aud">
      <option value="all">${t("audAll")}</option>
      <option value="guests">${t("audGuests")}</option>
      <option value="team">${t("audTeam")}</option>
    </select>
    <button class="btn" id="nn-go">${t("send")}</button>
    <button class="btn ghost" id="nn-x">${t("close")}</button>`);
  wrap.querySelector("#nn-x").onclick=()=>wrap.remove();
  wrap.querySelector("#nn-go").onclick=async ()=>{
    const title=wrap.querySelector("#nn-title").value.trim();
    const body=wrap.querySelector("#nn-body").value.trim();
    if(!title&&!body) return;
    await DB.addNote({title:title||"★",body,audience:wrap.querySelector("#nn-aud").value});
    S.seenNote=S.notes.reduce((m,n)=>Math.max(m,n.id),S.seenNote); persist();
    wrap.remove(); toast(t("saved")); render();
  };
}
function openAttendanceModal(a){
  const date=todayISO();
  const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
  const wrap=baseModal(`
    <h3>${ic("check",18)} ${t("attendance")}</h3>
    <p class="mini">${esc(a.name)} · ${esc(a.time)}</p>
    ${bks.length?`<div class="card" style="margin-top:12px">${bks.map(b=>{
      const on=S.attendance.some(x=>x.booking_id===b.id&&x.date===date);
      return `<div class="booking-line">
        <span><b>${t("room")} ${esc(b.room)}</b> · ${esc(b.guest_name)}</span>
        <button class="chip ${on?"ok":""}" data-attb="${b.id}">${t("present")}</button>
      </div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("users",30)}</div>${t("none")}</div>`}
    <button class="btn ghost" id="at-x">${t("close")}</button>`);
  wrap.querySelector("#at-x").onclick=()=>{ wrap.remove(); render(); };
  wrap.querySelectorAll("[data-attb]").forEach(b=>b.onclick=async ()=>{
    const id=+b.dataset.attb;
    const on=S.attendance.some(x=>x.booking_id===id&&x.date===date);
    await DB.setAttendance(id,date,!on);
    b.classList.toggle("ok",!on);
  });
}
function openTicketEditModal(tk){
  const isNew=!tk; tk=tk||{day:S.day,name:"",desc:"",location:"",time:"20:00",price:"",capacity:0,image:""};
  let ticketImage=String(tk.image||""),uploading=false;
  const wrap=baseModal(`
    <h3>${isNew?t("addTicket"):t("editTicket")}</h3>
    <label>${t("actName")}</label><input id="k-name" value="${esc(tk.name)}">
    <label>${t("desc")}</label><textarea id="k-desc" rows="2">${esc(tk.desc)}</textarea>
    <div class="row2"><div><label>${t("day")}</label><select id="k-day">${t("days").map((d,i)=>`<option value="${i}" ${tk.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
    <div><label>${t("time")}</label><input id="k-time" type="time" value="${esc(tk.time)}"></div></div>
    <div class="row2"><div><label>${t("price")}</label><input id="k-price" value="${esc(tk.price)}" placeholder="5 €"></div>
    <div><label>${t("capacity")} (0 = ∞)</label><input id="k-cap" type="number" min="0" value="${tk.capacity}"></div></div>
    <label>${t("location")}</label><input id="k-loc" value="${esc(tk.location)}">
    <label>${t("photo")}</label>
    <div class="photo-pick" id="k-photo-pick"><div class="photo-box" id="k-photo-box"></div><div class="pp-txt"><b>${t("photo")}</b><span class="mini">Tap to choose a photo from your phone</span></div><input type="file" id="k-photo-file" accept="image/*" hidden></div>
    <button class="btn ghost sm" id="k-photo-remove" style="${ticketImage?"":"display:none"}">Remove photo</button>
    <p class="mini" id="k-photo-status"></p>
    <button class="btn" id="k-save">${t("save")}</button>${isNew?"":`<button class="btn warn" id="k-del">${t("deleteActivity")}</button>`}<button class="btn ghost" id="k-x">${t("close")}</button>`);
  const box=wrap.querySelector("#k-photo-box"),file=wrap.querySelector("#k-photo-file"),rm=wrap.querySelector("#k-photo-remove"),status=wrap.querySelector("#k-photo-status"),save=wrap.querySelector("#k-save");
  const paint=()=>{box.innerHTML=ticketImage?`<img src="${esc(ticketImage)}" alt="">`:`<span>${ic("photo",26)}</span>`;rm.style.display=ticketImage?"":"none";};
  paint(); box.onclick=()=>file.click();
  file.onchange=async()=>{
    const f=file.files&&file.files[0]; if(!f)return;
    uploading=true;save.disabled=true;status.textContent="Uploading photo…";box.classList.add("uploading");
    try{ticketImage=await uploadAvatar(f);paint();status.textContent="Photo ready";}
    catch(e){console.error("ticket photo upload",e);status.textContent="Photo upload failed";toastErr(t("uploadErr"));}
    finally{uploading=false;save.disabled=false;box.classList.remove("uploading");file.value="";}
  };
  rm.onclick=()=>{ticketImage="";paint();status.textContent="Photo removed";};
  wrap.querySelector("#k-x").onclick=()=>wrap.remove();
  save.onclick=async()=>{
    if(uploading){toastWarn("Please wait for the photo upload.");return;}
    const upd={...tk,name:wrap.querySelector("#k-name").value.trim(),desc:wrap.querySelector("#k-desc").value.trim(),
      day:+wrap.querySelector("#k-day").value,time:wrap.querySelector("#k-time").value||"20:00",
      price:wrap.querySelector("#k-price").value.trim(),capacity:+wrap.querySelector("#k-cap").value||0,
      location:wrap.querySelector("#k-loc").value.trim(),image:ticketImage};
    if(!upd.name)return;
    save.disabled=true;
    try{await DB.saveTicket(upd);wrap.remove();toast(t("saved"));render();}
    catch(e){console.error("save ticket",e);save.disabled=false;toastErr(t("errSave"));}
  };
  const del=wrap.querySelector("#k-del");
  if(del)del.onclick=async()=>{await DB.deleteTicket(tk.id);wrap.remove();toast(t("deleted"));render();};
}

function splitTime(tm){
  const p=String(tm||"").split(/\s*[–—-]\s*/);
  return {start:(p[0]||"").trim(),end:(p[1]||"").trim()};
}
/* minutes-since-midnight from a "HH:MM" fragment, or -1 */
function hmToMin(x){ const m=String(x||"").match(/(\d{1,2})[:.\s](\d{2})/); return m?(+m[1])*60+(+m[2]):-1; }
/* start & end minutes for an activity (end defaults to start+45 if none) */
function actWindow(a){
  const {start,end}=splitTime(a.time);
  const s0=hmToMin(start); if(s0<0) return null;
  let e0=hmToMin(end); if(e0<0) e0=s0+45; if(e0<s0) e0+=1440;
  return {s0,e0};
}
/* status for TODAY only: 'todo' (green, not started), 'live' (yellow, running), 'done' (red, finished) */
function activityStatus(a, nowMin){
  const w=actWindow(a); if(!w) return "todo";
  const now=(typeof nowMin==="number")?nowMin:nowMinutes();
  if(now < w.s0) return "todo";
  if(now >= w.e0) return "done";
  return "live";
}
/* ===== HOTEL CLOCK =====
   With a timezone set, the app uses the HOTEL's local time everywhere, so a
   guest whose phone is on another timezone still sees the right day and gets
   alarms at the right moment. Without one, it falls back to the phone clock. */
const TIMEZONES=["","Africa/Cairo","Europe/Berlin","Europe/London","Europe/Moscow","Europe/Warsaw",
  "Europe/Prague","Europe/Amsterdam","Europe/Paris","Europe/Madrid","Europe/Rome","Europe/Istanbul",
  "Asia/Dubai","Asia/Riyadh","Atlantic/Canary","America/New_York"];
function hotelTz(){ try{ return (typeof S!=="undefined" && S.settings && S.settings.timezone) || ""; }catch(e){ return ""; } }
function hotelNow(){
  const tz=hotelTz();
  if(!tz) return new Date();
  try{ const d=new Date(new Date().toLocaleString("en-US",{timeZone:tz})); return isNaN(d.getTime())?new Date():d; }
  catch(e){ return new Date(); }
}
function nowMinutes(){ const d=hotelNow(); return d.getHours()*60+d.getMinutes(); }
function todayIndex(){ return (hotelNow().getDay()+6)%7; }
function hotelDateStr(){
  const d=hotelNow();
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}
/* only show status dots when looking at the actual current weekday */
function isToday(day){ return day===(todayIndex()); }
function statusDot(a){
  if(!isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-dot ${st}" title="${t("st_"+st)}"></span>`;
}
/* class that draws the coloured ring around a card / photo */
function statusRing(a){
  if(!a || !isToday(a.day)) return "";
  return "ring-"+activityStatus(a);
}
/* small coloured label used inside the ring */
function statusPill(a){
  if(!a || !isToday(a.day)) return "";
  const st=activityStatus(a);
  return `<span class="stat-pill ${st}">${t("st_"+st)}</span>`;
}
function statusLegend(){
  if(!isToday(S.day)) return "";
  return `<div class="stat-legend">
    <span><i class="stat-dot todo"></i>${t("st_todo")}</span>
    <span><i class="stat-dot live"></i>${t("st_live")}</span>
    <span><i class="stat-dot done"></i>${t("st_done")}</span>
  </div>`;
}
function joinTime(a,b){ a=(a||"").trim(); b=(b||"").trim(); return b?`${a} – ${b}`:a; }
function openEditModal(a){
  const isNew=!a; a=a||{day:S.day,category:(S.cat&&allCats().includes(S.cat)?S.cat:"mAdult"),name:"",desc:"",location:"",time:"10:00",capacity:20,entertainer:"",image:"",highlight:false};
  const cur=normCat(a);
  const tm=splitTime(a.time);
  const catOptions=OPS.map(o=>`<optgroup label="${esc(opLabel(o.id))}">${o.cats.map(c=>`<option value="${c}" ${cur===c?"selected":""}>${catLabel(c)}</option>`).join("")}</optgroup>`).join("");
  const staff=S.users.filter(u=>u.role==="staff");
  const entOptions=`<option value="">${t("allTeam")}</option>`
    + staff.map(u=>`<option value="${esc(u.username)}" ${String(a.entertainer||"").toLowerCase()===u.username.toLowerCase()?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("");
  const knownEnt=!a.entertainer || staff.some(u=>u.username.toLowerCase()===String(a.entertainer).toLowerCase());
  const wrap=baseModal(`
    <h3>${isNew?t("addActivity"):t("editActivity")}</h3>
    <label>${t("actName")}</label><input id="e-name" value="${esc(a.name)}">
    <label>${t("desc")}</label><textarea id="e-desc" rows="2">${esc(a.desc)}</textarea>
    <div class="row2">
      <div><label>${t("day")}</label><select id="e-day">${t("days").map((d,i)=>`<option value="${i}" ${a.day===i?"selected":""}>${d}</option>`).join("")}</select></div>
      <div><label>${t("category")}</label><select id="e-cat">${catOptions}</select></div>
    </div>
    <div class="row2">
      <div><label>${t("startTime")}</label><input id="e-start" type="time" value="${esc(tm.start)}"></div>
      <div><label>${t("endTime")}</label><input id="e-end" type="time" value="${esc(tm.end)}"></div>
    </div>
    <label>${t("capacity")} (0 = ∞)</label><input id="e-cap" type="number" min="0" value="${a.capacity}">
    <label>${t("location")}</label><input id="e-loc" value="${esc(a.location)}">
    <label>${t("entertainer")}</label>
    <select id="e-ent">${entOptions}${knownEnt?"":`<option value="${esc(a.entertainer)}" selected>${esc(a.entertainer)}</option>`}</select>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <input id="e-img" type="hidden" value="${esc(a.image)}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink)">
      <input id="e-hl" type="checkbox" style="width:auto" ${a.highlight?"checked":""}> ${ic("sparkle",14)} ${t("makeHighlight")}</label>
    <button class="btn" id="e-save">${t("save")}</button>
    ${isNew?"":`<button class="btn warn" id="e-del">${t("deleteActivity")}</button>`}
    <button class="btn ghost" id="e-x">${t("close")}</button>`);
  wrap.querySelector("#e-x").onclick=()=>wrap.remove();
  let ePhoto=a.image||"";
  wirePhotoPicker(wrap, ()=>ePhoto, v=>{ ePhoto=v; wrap.querySelector("#e-img").value=v; });
  wrap.querySelector("#e-save").onclick=async ()=>{
    const upd={...a,
      name:wrap.querySelector("#e-name").value.trim(),
      desc:wrap.querySelector("#e-desc").value.trim(),
      day:+wrap.querySelector("#e-day").value,
      category:wrap.querySelector("#e-cat").value,
      time:joinTime(wrap.querySelector("#e-start").value||"10:00",wrap.querySelector("#e-end").value),
      capacity:+wrap.querySelector("#e-cap").value||0,
      location:wrap.querySelector("#e-loc").value.trim(),
      entertainer:wrap.querySelector("#e-ent").value.trim(),
      image:ePhoto,
      highlight:wrap.querySelector("#e-hl").checked};
    if(!upd.name) return;
    await DB.saveActivity(upd); wrap.remove(); toast(t("saved")); render();
  };
  const del=wrap.querySelector("#e-del");
  if(del) del.onclick=async ()=>{
    if(!await confirmAction({question:t("delActivityQ"),danger:true})) return;
    try{ await DB.deleteActivity(a.id); wrap.remove(); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
}
function openUserModal(){
  const wrap=baseModal(`
    <h3>${t("addUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="u-name" autocapitalize="none">
    <label>${t("pass")}</label><input id="u-pass">
    <label>${t("displayName")}</label><input id="u-disp">
    <label>${t("roleLabel")}</label>
    <select id="u-role"><option value="staff">${t("staff")}</option><option value="manager">${t("manager")}</option></select>
    <label>${t("shirtNumber")} (2–10)</label><input id="u-num" type="number" min="2" max="10" placeholder="e.g. 4">
    <label>${t("nationality")}</label>${nationField("u-nat","u-natx","")}
    <label>${t("genderLbl")}</label><select id="u-gen">${genderOptions("")}</select>
    <div class="pay630-editbox">
      <div class="pay630-edithead"><b>Salary</b><span>Monthly payroll</span></div>
      <div class="row2">
        <div><label>Monthly salary</label><input id="u-salary" type="number" min="0" step="0.01" inputmode="decimal" placeholder="10000"></div>
        <div><label>Currency</label><select id="u-currency"><option value="EGP">EGP</option><option value="USD">USD</option></select></div>
      </div>
      <label class="pay630-toggle"><input id="u-vacpaid" type="checkbox" checked> Paid vacation</label>
      <p class="mini">Present and Day Off are paid. Absence is deducted automatically.</p>
    </div>
    <button class="btn" id="u-save">${t("save")}</button>
    <div class="err" id="u-err"></div>
    <button class="btn ghost" id="u-x">${t("close")}</button>`);
  wrap.querySelector("#u-x").onclick=()=>wrap.remove();
  let uPhoto="";
  wirePhotoPicker(wrap, ()=>uPhoto, v=>{ uPhoto=v; });
  wireNatPicker(wrap,"u-nat","u-natx");
  wrap.querySelector("#u-save").onclick=async ()=>{
    const username=wrap.querySelector("#u-name").value.trim();
    const password=wrap.querySelector("#u-pass").value;
    const display_name=wrap.querySelector("#u-disp").value.trim();
    const role=wrap.querySelector("#u-role").value;
    const numRaw=wrap.querySelector("#u-num").value;
    const number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    const err=wrap.querySelector("#u-err");
    if(!username||!password){ err.textContent=t("loginErr"); return; }
    if(S.users.some(x=>x.username===username)){ err.textContent=t("userExists"); return; }
    await DB.addUser({username,password,role,display_name,number,photo:uPhoto,
      nationality:readNatField(wrap,"u-nat","u-natx"),
      gender:wrap.querySelector("#u-gen").value});
    const created=(S.users||[]).find(x=>String(x.username).toLowerCase()===String(username).toLowerCase());
    if(created){
      const amount=Math.max(0,+wrap.querySelector("#u-salary").value||0);
      const currency=wrap.querySelector("#u-currency").value==="USD"?"USD":"EGP";
      await savePayrollConfig630(created,{amount,currency,vacationPaid:!!wrap.querySelector("#u-vacpaid").checked});
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openMsgEditModal(m){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editMsg")}</h3>
    <label>${t("desc")}</label><textarea id="me-txt" rows="3">${esc(m.text)}</textarea>
    <button class="btn" id="me-go">${t("save")}</button>
    <button class="btn warn" id="me-del">${t("deleteMsg")}</button>
    <button class="btn ghost" id="me-x">${t("close")}</button>`);
  wrap.querySelector("#me-x").onclick=()=>wrap.remove();
  wrap.querySelector("#me-go").onclick=async ()=>{
    const v=wrap.querySelector("#me-txt").value.trim();
    if(!v) return;
    await DB.updateMessage(m.id,v); wrap.remove(); toast(t("saved")); render();
  };
  wrap.querySelector("#me-del").onclick=async ()=>{
    await DB.deleteMessage(m.id); wrap.remove(); toast(t("deleted")); render();
  };
}
function openChangePassModal(){
  const wrap=baseModal(`
    <h3>${ic("key",22)} ${t("changePass")}</h3>
    <label>${t("newPass")}</label><input id="cp-new" type="text" autocapitalize="none">
    <button class="btn" id="cp-go">${t("save")}</button>
    <div class="err" id="cp-err"></div>
    <button class="btn ghost" id="cp-x">${t("close")}</button>`);
  wrap.querySelector("#cp-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cp-go").onclick=async ()=>{
    const v=wrap.querySelector("#cp-new").value.trim();
    if(v.length<4){ wrap.querySelector("#cp-err").textContent=t("loginErr"); return; }
    await DB.updateAccount(S.session.accountId,{password:v});
    wrap.remove(); toast(t("saved"));
  };
}
function openUserEditModal(u){
  const managerCount=S.users.filter(x=>x.role==="manager").length;
  const lastManager=u.role==="manager"&&managerCount<=1;
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editUser")}</h3>
    <div class="photo-pick"><div class="photo-box" data-photobox></div>
      <div class="pp-txt"><b>${t("photo")}</b><span class="mini">${t("uploadPhoto")}</span></div>
      <input type="file" accept="image/*" data-photoinput hidden></div>
    <label>${t("user")}</label><input id="ue-user" value="${esc(u.username)}" autocapitalize="none">
    <label>${t("displayName")}</label><input id="ue-disp" value="${esc(u.display_name||"")}">
    <label>${t("pass")}</label><input id="ue-pass" value="${esc(u.password||"")}">
    <label>${t("roleLabel")}</label>
    <select id="ue-role" ${lastManager?"disabled":""}>
      <option value="staff" ${u.role==="staff"?"selected":""}>${t("staff")}</option>
      <option value="manager" ${u.role==="manager"?"selected":""}>${t("manager")}</option>
    </select>
    <label>${t("shirtNumber")} (2–10)</label><input id="ue-num" type="number" min="2" max="10" value="${u.number||""}">
    <div class="row2">
      <div><label>${t("employeeId")}</label><input id="ue-eid" value="${esc(u.employee_id||"")}"></div>
      <div><label>${t("positionLbl2")}</label><input id="ue-pos" value="${esc(u.position||"")}"></div>
    </div>
    <div class="row2">
      <div><label>${t("phoneLbl2")}</label><input id="ue-phone" value="${esc(u.phone||"")}" inputmode="tel"></div>
      <div><label>${t("whatsappLbl2")}</label><input id="ue-wa" value="${esc(u.whatsapp||"")}" inputmode="tel"></div>
    </div>
    <label>${t("instagramLbl2")}</label><input id="ue-ig" value="${esc(u.instagram||"")}">
    <label>${t("languagesLbl")}</label><input id="ue-lang" value="${esc(u.languages||"")}" placeholder="DE · EN · RU">
    <label>${t("skills")}</label><input id="ue-skills" value="${esc(u.skills||"")}">
    <label>${t("hireDate")}</label><input id="ue-hire" type="date" value="${esc(u.hire_date||"")}">
    ${photoListEditor("uep", (()=>{try{return Array.isArray(u.photos)?u.photos:JSON.parse(u.photos||"[]");}catch(e){return [];}})())}
    <label>${t("nationality")}</label>${nationField("ue-nat","ue-natx",u.nationality||"")}
    <label>${t("genderLbl")}</label><select id="ue-gen">${genderOptions(u.gender||"")}</select>
    ${payrollEditorHtml630(u)}
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ue-active" type="checkbox" style="width:auto" ${u.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ue-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ue-go">${t("save")}</button>
    <button class="btn ghost" id="ue-x">${t("close")}</button>`);
  wrap.querySelector("#ue-x").onclick=()=>wrap.remove();
  let uePhoto=u.photo||"";
  wirePhotoPicker(wrap, ()=>uePhoto, v=>{ uePhoto=v; });
  wireNatPicker(wrap,"ue-nat","ue-natx");
  let uePics=(()=>{try{return Array.isArray(u.photos)?u.photos.slice():JSON.parse(u.photos||"[]");}catch(e){return [];}})();
  wirePhotoList(wrap,"uep",()=>uePics,l=>{ uePics=l; });
  const ueReset=wrap.querySelector("#ue-reset");
  if(ueReset) ueReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateUser(u.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ue-go").onclick=async ()=>{
    const newUser=wrap.querySelector("#ue-user").value.trim();
    const patch={display_name:wrap.querySelector("#ue-disp").value.trim(),
      password:wrap.querySelector("#ue-pass").value, photo:uePhoto,
      nationality:readNatField(wrap,"ue-nat","ue-natx"),
      gender:wrap.querySelector("#ue-gen").value,
      active:wrap.querySelector("#ue-active").checked,
      employee_id:wrap.querySelector("#ue-eid").value.trim(),
      position:wrap.querySelector("#ue-pos").value.trim(),
      phone:wrap.querySelector("#ue-phone").value.trim(),
      whatsapp:wrap.querySelector("#ue-wa").value.trim(),
      instagram:wrap.querySelector("#ue-ig").value.trim(),
      languages:wrap.querySelector("#ue-lang").value.trim(),
      skills:wrap.querySelector("#ue-skills").value.trim(),
      hire_date:wrap.querySelector("#ue-hire").value,
      photos:uePics};
    const numRaw=wrap.querySelector("#ue-num").value;
    patch.number=numRaw?Math.max(2,Math.min(10,+numRaw)):null;
    if(!lastManager) patch.role=wrap.querySelector("#ue-role").value;
    if(newUser && newUser!==u.username){
      if(S.users.some(x=>x.id!==u.id && String(x.username).toLowerCase()===newUser.toLowerCase())){ toast(t("userExists")); return; }
      patch.username=newUser;
    }
    if(!patch.password){ return; }
    await DB.updateUser(u.id,patch);
    await savePayrollConfig630(u,{
      amount:Math.max(0,+wrap.querySelector("#ue-salary").value||0),
      currency:wrap.querySelector("#ue-currency").value==="USD"?"USD":"EGP",
      vacationPaid:!!wrap.querySelector("#ue-vacpaid").checked
    });
    wrap.remove(); toast(t("saved")); render();
  };
}
function openGuestEditModal(acc){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("profile")} · ${t("room")} ${esc(acc.room)}</h3>
    <label>${t("name")}</label><input id="ge-name" value="${esc(acc.name||"")}">
    <label>${t("phone")}</label><input id="ge-phone" value="${esc(acc.phone||"")}">
    <label>${t("nationality")}</label>
    <input id="ge-nat" list="genatlist" value="${esc(acc.nationality||"")}">
    <datalist id="genatlist">${NATIONS.map(n=>`<option value="${n}">`).join("")}</datalist>
    <div class="row2">
      <div><label>${t("arrival")}</label><input id="ge-arr" type="date" value="${esc(acc.arrival||"")}"></div>
      <div><label>${t("departure")}</label><input id="ge-dep" type="date" value="${esc(acc.departure||"")}"></div>
    </div>
    <label>${t("pass")}</label><input id="ge-pass" value="${esc(acc.password||"")}">
    <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
      <input id="ge-active" type="checkbox" style="width:auto" ${acc.active!==false?"checked":""}> ${t("activeAcc")}</label>
    <button class="btn ghost" id="ge-reset" style="margin-top:8px">${ic("bell",15)} ${t("resetPass")}</button>
    <button class="btn" id="ge-go">${t("save")}</button>
    <button class="btn ghost" id="ge-x">${t("close")}</button>`);
  wrap.querySelector("#ge-x").onclick=()=>wrap.remove();
  const geReset=wrap.querySelector("#ge-reset");
  if(geReset) geReset.onclick=async ()=>{
    const pw=makePassword();
    try{ await DB.updateAccount(acc.id,{password:pw}); wrap.remove(); showNewPassword(pw); render(); }
    catch(e){ toastErr(t("errSave")); }
  };
  wrap.querySelector("#ge-go").onclick=async ()=>{
    const name=wrap.querySelector("#ge-name").value.trim();
    if(!name) return;
    await DB.updateAccount(acc.id,{name,
      phone:wrap.querySelector("#ge-phone").value.trim(),
      nationality:wrap.querySelector("#ge-nat").value.trim(),
      arrival:wrap.querySelector("#ge-arr").value,
      departure:wrap.querySelector("#ge-dep").value,
      password:wrap.querySelector("#ge-pass").value.trim(),
      active:wrap.querySelector("#ge-active").checked});
    if(S.session && S.session.role==="guest" && S.session.accountId===acc.id){
      const a2=S.accounts.find(x=>x.id===acc.id); if(a2) startGuestSession(a2);
    }
    wrap.remove(); toast(t("saved")); render();
  };
}
function openLangModal(){
  const wrap=baseModal(`
    <h3>${t("language")}</h3>
    <div class="langlist">
      ${LANGS.map(([l,label])=>`<button data-mlang="${l}" class="${S.lang===l?"on":""}">${label}</button>`).join("")}
    </div>
    <button class="btn ghost" id="l-x">${t("close")}</button>`);
  wrap.querySelector("#l-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-mlang]").forEach(b=>b.onclick=()=>{ wrap.remove(); setLang(b.dataset.mlang); });
}
