/* ---------------- shared pieces ---------------- */
function socialTopIcons(){
  const st=S.settings;
  const links=[["Facebook",st.facebook],["Instagram",st.instagram],["TikTok",st.tiktok],["YouTube",st.youtube],["WhatsApp",waLink()]].filter(x=>x[1]);
  return links.map(([n,u])=>`<a class="iconbtn socialtop" href="${esc(u)}" target="_blank" rel="noopener" aria-label="${n}">${brandIc(n)}</a>`).join("");
}
function waLink(){
  const num=String(S.settings.whatsapp||"").replace(/[^0-9]/g,"");
  return num?("https://wa.me/"+num):"";
}
function navGroupsBase(role){
  if(role==="guest"){
    const un=unreadFor("guest");
    return [
      {key:"secProgram", head:t("secProgram"), items:[
        ["home","home",menuLabel("menuHome",t("home")),0],
        ["program","calendar",menuLabel("menuProgram",t("program")),0],
        ["chat","chat",menuLabel("menuChat",t("chat")),un],
        ["teaminfo","users",t("teamPage"),0],
        ["stay","user",t("myActs"),0],
        ...(featureOn("tickets")?[["tickets","ticket",t("myTickets"),0]]:[])]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["social","star",t("socialPage"),0]]}
    ];
  }
  if(role==="staff"){
    const myRoom="staff:"+S.session.username;
    const un=S.messages.filter(m=>m.room===myRoom&&m.sender==="team"&&!m.read_by_guest).length;
    const taskN=S.tasks.filter(x=>["open","accepted","still"].includes(x.status)&&(!x.assigned_to||x.assigned_to===S.session.username)).length;
    return [
      {key:"secTeamwork", head:t("secTeamwork"), items:[
        ["workday","clipboard",t("myWorkDay"),0],
        ["mypage","user",t("myAttendance"),0],
        ...(featureOn("quiz")?[["quiz","sparkle",t("quizTab"),quizForToday("staff")&&!myQuizReply(quizForToday("staff").id)?1:0]]:[]),
        ...(featureOn("bus")?[["bus","bus",t("busTimes"),0]]:[]),
        ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[])]},
      {key:"secProgram", head:t("secProgram"), items:[
        ["today","calendar",t("todayProgram"),0],
        ["week","calendar",t("program"),0],
        ["bookings","ticket",t("bookings"),0]]},
      {key:"secConnect", head:t("secConnect"), items:[
        ["chat","chat",t("chatManager"),un],
        ...(featureOn("gallery")?[["gallery","sparkle",t("galleryTab"),0]]:[]),
        ["teaminfo","users",t("teamPage"),0]]}
    ];
  }
  const un=unreadFor("manager");
  const newReq=S.requests.filter(r=>r.status==="new").length;
  return [
    {key:"secManage", head:t("secManage"), items:[
      ["dash","grid",t("dashboard"),0],
      ["program","calendar",t("manage"),0],
      ["dayplan","clipboard",t("dayPlan"),0],
      ["req","clipboard",t("reqTab"),0],
      ["assign","check",t("assignCenter"),0],
      ["quiz","sparkle",t("quizCenter"),0],
      ["gallery","sparkle",t("galleryTab"),0],
      ["hotelinfo","pin",t("hotelInfoTab"),0],
      ...(featureOn("weather")?[["weather","sun",t("weatherTab"),0]]:[]),
      ["qr","sparkle",t("qrTab"),0]]},
    {key:"secGuests", head:t("secGuests"), items:[
      ["guests","chat",t("guestsTab"),unreadGuests()+newReq],
      ["team","users",t("teamTab"),unreadTeam()+teamReqCount()]]},
    {key:"secSettings", head:t("secSettings"), items:[
      ["settings","palette",t("settingsHub"),0]]}
  ];
}
/* ===== MENU BUILDER =====
   The manager can rename, reorder, hide and add items per role. Stored in
   settings.menu so it syncs to every device. */
function menuConf(role){
  const m=(S.settings && S.settings.menu) || {};
  return m[role] || {order:[], hidden:[], names:{}, custom:[]};
}
function customPages(role){ return (menuConf(role).custom||[]); }
function applyMenuConf(role, groups){
  const conf=menuConf(role);
  const hidden=conf.hidden||[], names=conf.names||{}, order=conf.order||[];
  // rename + hide
  const gnames=conf.gnames||{};
  let out=groups.map(g=>({key:g.key, head:(g.key&&gnames[g.key])||g.head, items:g.items
    .filter(it=>!hidden.includes(it[0]))
    .map(it=>[it[0], it[1], names[it[0]]||it[2], it[3]])}));
  // the manager's own pages go into the first section
  const extra=customPages(role).map(p=>[ "cp:"+p.id, p.icon||"pin", p.title, 0 ]);
  if(extra.length && out.length) out[0]={...out[0], items:out[0].items.concat(extra)};
  // a section whose title she blanked out simply loses its heading
  // custom order inside each section
  if(order.length){
    out=out.map(g=>({...g, items:g.items.slice().sort((a,b)=>{
      const ia=order.indexOf(a[0]), ib=order.indexOf(b[0]);
      if(ia<0&&ib<0) return 0;
      if(ia<0) return 1;
      if(ib<0) return -1;
      return ia-ib;
    })}));
  }
  return out.filter(g=>g.items.length);
}
function navGroups(role){
  const groups=applyMenuConf(role, navGroupsBase(role));
  if(role!=="guest") return groups;
  const wanted=["home","program","chat","teaminfo","stay","tickets","social"];
  const all=groups.flatMap(g=>g.items), byId=new Map(all.map(it=>[it[0],it]));
  // Re-add required guest destinations if an old Menu Builder configuration hid them.
  const base=navGroupsBase("guest").flatMap(g=>g.items);
  base.forEach(it=>{ if(!byId.has(it[0])) byId.set(it[0],it); });
  const primary=wanted.slice(0,6).map(id=>byId.get(id)).filter(Boolean);
  const social=byId.get("social");
  return [{key:"secProgram",head:t("secProgram"),items:primary}, ...(social?[{key:"secConnect",head:t("secConnect"),items:[social]}]:[])];
}
function navItems(role){ return navGroups(role).flatMap(g=>g.items); }
function topBar(title,sub){
  const role=S.session?S.session.role:"guest";
  const anyDot=navItems(role).some(x=>x[3]>0);
  return `<div class="top">
    <div class="toprow toprow-l">
      <button class="iconbtn" id="btn-menu" aria-label="${t("menu")}">${ic("menu",21)}${anyDot?'<span class="reddot"></span>':''}</button>
      <button class="iconbtn navbtn" id="btn-navback" aria-label="${t("navBack")}" ${canNavBack()?"":"disabled"}>${ic("back",19)}</button>
      <button class="iconbtn navbtn fwd" id="btn-navfwd" aria-label="${t("navForward")}" ${canNavForward()?"":"disabled"}>${ic("back",19)}</button>
      <span class="socialrow">${socialTopIcons()}</span>
    </div>
    <div class="toprow">
      <button class="iconbtn" id="btn-notes" aria-label="notifications">${ic("bell",19)}${unseenNotes(role)?'<span class="reddot"></span>':''}</button>
    </div>
  </div>
  <div class="who whobar"><h2>${esc(title)}</h2><p>${esc(sub||"")}</p></div>`;
}
function hubBack(){
  // shown on Settings sub-pages so the manager can go back to the hub
  if(S.session && S.session.role==="manager")
    return `<button class="crumb" id="crumb-hub">${ic("back",15)} ${t("settingsHub")}</button>`;
  return "";
}
/* Which menu sections are expanded — defaults to the one you are currently in. */
function drawerOpenSection(i, hasCurrent){
  if(!S.drawerOpen) S.drawerOpen={};
  if(S.drawerOpen[i]===undefined) return hasCurrent;
  return !!S.drawerOpen[i];
}
function openMenuDrawer(){
  askNotifPermission();
  const role=S.session?S.session.role:"guest";
  const wrap=document.createElement("div"); wrap.className="drawer-bg";
  wrap.innerHTML=`<div class="drawer">
    <div class="dr-head">
      <div class="mono serif sm">${esc((S.settings.name||"E").trim().charAt(0).toUpperCase())}</div>
      <div><h3>${esc(S.settings.name)}</h3><div class="dr-person"><p>${esc(S.session?S.session.name:"")}</p>${role==="guest"?guestWeatherChip():""}</div></div>
    </div>
    <div class="dr-items">
      ${navGroups(role).map((g,gi)=>{
        const hasCurrent=g.items.some(it=>it[0]===S.tab);
        const dots=g.items.reduce((n,it)=>n+(it[3]||0),0);
        const open=drawerOpenSection(gi, hasCurrent);
        return `
        <button class="dr-sec dr-sech ${open?"open":""}" data-drsec="${gi}">
          <span>${esc(g.head)}</span>
          ${dots?`<span class="badge">${dots}</span>`:""}
          <span class="dr-caret">${ic("back",14)}</span>
        </button>
        <div class="dr-group ${open?"open":""}">
          ${g.items.map(([id,icn,lb,dot])=>`<button class="dr-it ${S.tab===id?"on":""}" data-drtab="${id}">
            <span class="dr-ic">${ic(icn,19)}</span><span class="dr-lb">${lb}</span>${dot?`<span class="badge">${dot}</span>`:""}
          </button>`).join("")}
        </div>`;
      }).join("")}
    </div>
    <div class="dr-foot">
      <button class="iconbtn" id="dr-lang" aria-label="${t("language")}">${ic("globe",19)}</button>
      <button class="iconbtn" id="dr-theme" aria-label="theme">${ic(S.theme==="light"?"moon":"sun",19)}</button>
      <button class="iconbtn ${notifSoundOn()?"on-notif":""}" id="dr-notif" aria-label="${t("notifSound")}">${ic(notifSoundOn()?"bell":"belloff",19)}</button>
      <button class="dr-out" id="dr-out">${ic("power",16)} ${t("logout")}</button>
    </div>
    <div class="dr-build">${esc(APP_BUILD)}</div>
  </div>`;
  document.body.appendChild(wrap);
  requestAnimationFrame(()=>wrap.classList.add("open"));
  const close=(cb)=>{ wrap.classList.remove("open"); setTimeout(()=>{ wrap.remove(); if(cb) cb(); },240); };
  wrap.onclick=e=>{ if(e.target===wrap) close(); };
  wrap.querySelectorAll("[data-drsec]").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.drsec;
    if(!S.drawerOpen) S.drawerOpen={};
    const groups=navGroups(S.session?S.session.role:"guest");
    const hasCur=(groups[i]&&groups[i].items||[]).some(it=>it[0]===S.tab);
    S.drawerOpen[i]=!drawerOpenSection(i,hasCur);
    wrap.remove(); openMenuDrawer();
  });
  wrap.querySelectorAll("[data-drtab]").forEach(b=>b.onclick=()=>{
    close(()=>{ S.tab=b.dataset.drtab; S.chatRoom=null; render(); });
  });
  wrap.querySelector("#dr-lang").onclick=()=>close(openLangModal);
  wrap.querySelector("#dr-theme").onclick=()=>close(()=>setTheme(S.theme==="light"?"dark":"light"));
  wrap.querySelector("#dr-notif").onclick=()=>{
    const turningOn = !notifSoundOn();
    localStorage.setItem("ent_notif", turningOn ? "on" : "off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    close(()=>render());
  };
  wrap.querySelector("#dr-out").onclick=()=>close(()=>{AUREA_AUTH.logout();loginMode="guest";guestMode="new";resetWiz();render();});
}
function heroCard(a){
  if(!a) return "";
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken);
  return `<div class="hero" data-open="${a.id}">
    <img src="${esc(a.image||IMG.show)}" alt="">
    <div class="veil"></div>
    <div class="tag">${ic("sparkle",13)} ${t("highlight")}</div>
    <div class="body">
      <h3>${esc(a.name)}</h3>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span>${a.capacity?`<span>${mi("users")}${left} ${t("seatsLeft")}</span>`:""}</div>
      <div class="desc">${esc(a.desc)}</div>
    </div>
  </div>`;
}
/* Today's highlights, swiped sideways. One card behaves exactly as before, so
   a day with a single highlight looks the way it always did. */
function heroCarousel(list){
  list=(list||[]).filter(Boolean).slice(0,5);
  if(!list.length) return "";
  if(list.length===1) return heroCard(list[0]);
  return `<div class="hero-wrap">
    <div class="hero-rail" id="hero-rail">${list.map(a=>heroCard(a)).join("")}</div>
    <div class="hero-dots" id="hero-dots">${list.map((a,i)=>
      `<i class="${i===0?"on":""}" data-herodot="${i}"></i>`).join("")}</div>
  </div>`;
}
function activityCard(a,{showBook=true,showFav=true,manager=false,staff=false}={}){
  const unlimited=!(+a.capacity);
  const taken=seatsTaken(a.id), left=Math.max(0,a.capacity-taken), full=!unlimited&&left<=0;
  const mine=myBooking(a.id);
  const fav=S.favorites.includes(a.id);
  let side="";
  if(manager){
    side=`<button class="btn sm ghost" data-edit="${a.id}">${ic("pen",15)}</button><span class="seats">${taken}/${a.capacity}</span>`;
  } else if(staff){
    side=`${canSeeGuests(a)?`<button class="btn sm ghost" data-att="${a.id}">${ic("check",15)}</button>`:""}<span class="pill">${bookingsFor(a.id).length} ${t("guests")}</span>`;
  } else if(showBook){
    /* Once today's activity has finished (or the day has passed) it can no longer
       be booked — the guest sees that straight away instead of after tapping. */
    const over = isToday(a.day) && activityStatus(a)==="done";
    const running = isToday(a.day) && activityStatus(a)==="live";
    if(over){
      side = mine
        ? `<span class="chip done">${t("wasBooked")}</span>`
        : `<span class="chip done">${t("finishedChip")}</span>`;
    } else {
      side = mine
        ? `<span class="chip ${mine.status==="booked"?"ok":""}">${mine.status==="booked"?t("booked"):t("onWaitlist")}</span>`
        : full ? `<span class="chip full">${t("full")}</span>`
        : `<button class="btn sm" data-book="${a.id}">${running?t("bookNowLive"):t("book")}</button>`;
      side += `<span class="seats">${unlimited||full?"":left+" "+t("seatsLeft")}</span>`;
    }
  }
  // the coloured ring is drawn around the guest's own booked activity
  const ringCls = (mine && isToday(a.day)) ? (" "+statusRing(a)) : "";
  const overNow = isToday(a.day) && activityStatus(a)==="done";
  const guestCard=!manager&&!staff;
  return `<div class="card act${guestCard?" guest-act":""}${ringCls}${overNow?" is-over":""}" ${manager||staff||overNow?"":`data-open="${a.id}"`}>
    <img class="thumb" src="${esc(a.image||IMG.show)}" alt="" loading="lazy" ${guestCard?"":`data-pvsingle="${esc(a.image||IMG.show)}"` }>
    <div class="mid">
      <span class="catbadge">${catLabel(a.category)}</span>
      <h4>${statusDot(a)}${esc(a.name)}</h4>
      <div class="meta"><span>${mi("clock")}${esc(a.time)}</span><span>${mi("pin")}${esc(a.location)}</span></div>
      ${guestCard&&a.desc?`<p class="guest-act-desc">${esc(a.desc)}</p>`:""}
      ${mine&&isToday(a.day)?`<div class="guest-status-line">${statusPill(a)}</div>`:""}
    </div>
    <div class="side">
      ${showFav&&!manager&&!staff?`<button class="fav" data-fav="${a.id}">${fav?`<span class="hf">${ic("heart",19)}</span>`:ic("heart",19)}</button>`:""}
      ${side}
      ${guestCard&&!overNow?`<span class="guest-detail-arrow">${ic("back",15)}</span>`:""}
    </div>
  </div>`;
}
function dayTabs(){
  return `<div class="daytabs">${t("daysShort").map((d,i)=>
    `<button data-day="${i}" class="${S.day===i?"on":""}">${d}</button>`).join("")}</div>`;
}
function subTabs(group,items){
  if(PAGE_SECTIONS[group]){
    const ord=pageOrder(group);
    items=items.filter(it=>ord.includes(it[0]))
               .sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
    if(!items.some(it=>it[0]===S.sub[group]) && items.length) S.sub[group]=items[0][0];
  }
  return `<div class="pills">${items.map(([id,lb])=>
    `<button data-sub="${group}:${id}" class="${S.sub[group]===id?"on":""}">${lb}</button>`).join("")}</div>`;
}
function listByCat(acts,opts){
  if(!acts.length) return `<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`;
  return CAT_ORDER.filter(c=>acts.some(a=>a.category===c)).map(c=>`
    <div class="sec"><h3>${catLabel(c)}</h3>
      ${acts.filter(a=>a.category===c).sort((x,y)=>x.time.localeCompare(y.time)).map(a=>activityCard(a,opts)).join("")}
    </div>`).join("");
}
function operationCard(op){
  const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id);
  const img=opImage(op.id);
  return `<button class="opcard" data-op="${op.id}">
    <img src="${esc(img)}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h3>${esc(opLabel(op.id))}</h3><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",18)}</span>
  </button>`;
}
function categoryCard(cat){
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===cat);
  return `<button class="catcard ${acts.length?"":"empty-cat"}" data-cat="${cat}">
    <img src="${esc(catImage(cat))}" alt="" loading="lazy"><div class="veil"></div>
    <div class="opc-txt"><h4>${esc(catLabel(cat))}</h4><span>${acts.length} ${t("activities")}</span></div>
    <span class="opc-go">${ic("back",16)}</span>
  </button>`;
}
function browseView(title){
  // level 1: operations
  if(!S.op){
    let mineBanner="";
    if(S.session && S.session.role==="staff"){
      const mine=S.activities.filter(a=>a.day===S.day && canSeeGuests(a)).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
      if(mine.length) mineBanner=`<div class="sec"><h3>${ic("clipboard",18)} ${t("myActs")}</h3>
        <p class="mini" style="margin:-6px 0 10px">${t("myActsSub")}</p>
        ${mine.map(a=>activityCard(a,{staff:true,showBook:false,showFav:false})).join("")}</div>`;
    }
    const dp=dayPlanFor(S.day);
    const themeBanner=dp&&dp.theme?`<div class="theme-banner"><span class="tb-l">${t("restaurantTheme")}</span><b class="serif">${esc(dp.theme)}</b></div>`:"";
    return `<div class="screen fadein">${topBar(title,t("days")[S.day])}${dayTabs()}
      ${themeBanner}
      ${mineBanner}
      <div class="opgrid">${OPS.map(operationCard).join("")}</div></div>`;
  }
  const op=OPS.find(o=>o.id===S.op)||OPS[0];
  // Single-category operation -> show its activities directly (no middle level)
  if(op.cats.length===1){
    const acts=S.activities.filter(a=>a.day===S.day && actOp(a)===op.id).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      ${acts.length?statusLegend():""}
      ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
    </div>`;
  }
  // level 2: categories inside a multi-category operation
  if(!S.cat){
    return `<div class="screen fadein">${topBar(opLabel(op.id),t("days")[S.day])}
      <button class="crumb" id="crumb-ops">${ic("back",15)} ${t("backToCats")}</button>
      ${dayTabs()}
      <div class="catgrid">${op.cats.map(categoryCard).join("")}</div></div>`;
  }
  // level 3: the activities of the chosen category
  const acts=S.activities.filter(a=>a.day===S.day && normCat(a)===S.cat).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
  return `<div class="screen fadein">${topBar(catLabel(S.cat),opLabel(op.id))}
    <button class="crumb" id="crumb-cats">${ic("back",15)} ${esc(opLabel(op.id))}</button>
    ${dayTabs()}
    ${acts.length?acts.map(a=>activityCard(a,S.session.role==="guest"?{}:{staff:true,showBook:false,showFav:false})).join(""):`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`}
  </div>`;
}
/* ================= CHAT TRANSLATION =================
   Guests write in their language, the team reads in theirs. Uses a free
   public translation service (no key needed, so it works for guests too).
   Results are remembered for the session so nothing is fetched twice. */
const TRANS_CACHE={};
const TRANS_SHOWN={};
function transKey(id,lang){ return id+"|"+lang; }
async function translateText(text, to){
  const from="auto";
  const url="https://api.mymemory.translated.net/get?q="+encodeURIComponent(text)+
    "&langpair="+encodeURIComponent(from+"|"+to);
  const res=await fetch(url);
  if(!res.ok) throw new Error("translate "+res.status);
  const data=await res.json();
  const out=data && data.responseData && data.responseData.translatedText;
  if(!out || /^please select|invalid/i.test(out)) throw new Error("no translation");
  return String(out);
}
async function translateMessage(id){
  const m=S.messages.find(x=>String(x.id)===String(id));
  if(!m) return;
  const to=S.lang||"en";
  const k=transKey(id,to);
  if(TRANS_CACHE[k]){ TRANS_SHOWN[k]=!TRANS_SHOWN[k]; render(); return; }
  TRANS_SHOWN[k]=true; TRANS_CACHE[k]="__loading__"; render();
  try{
    TRANS_CACHE[k]=await translateText(m.text, to);
  }catch(e){
    delete TRANS_CACHE[k]; delete TRANS_SHOWN[k];
    toastErr(t("translateFail"));
  }
  render();
}
function bubbleTranslation(m){
  const to=S.lang||"en";
  const k=transKey(m.id,to);
  const val=TRANS_CACHE[k];
  if(!val || !TRANS_SHOWN[k]) return "";
  if(val==="__loading__") return `<span class="tr-line loading">${t("translating")}</span>`;
  return `<span class="tr-line"><i>${t("translatedTag")}</i>${esc(val)}</span>`;
}
function threadView(room,meSide){
  const msgs=S.messages.filter(m=>m.room===room);
  const isManager=S.session && S.session.role==="manager";
  const emptyTxt = String(room).startsWith("staff:") ? t("noStaffMsg") : t("noMessages");
  return `<div class="thread">
    ${msgs.length?msgs.map(m=>{
      const mine = m.sender===meSide;
      const picking=chatSelOn(), picked=chatSelHas(m.id);
      return `<div class="bubwrap ${mine?"me":"them"}${picking?" picking":""}${picked?" picked":""}"
        ${picking?`data-msgpick="${m.id}"`:""}>
        ${picking?`<span class="pick-dot">${picked?ic("check",13):""}</span>`:""}
        <div class="bub ${mine?"me":"them"}">${esc(m.text)}${bubbleTranslation(m)}<span class="tm">${mine?"":esc(m.sender_name)+" · "}${fmtTime(m.created_at)}</span></div>
        ${mine?"":`<button class="tr-btn" data-translate="${m.id}">${ic("sparkle",12)} ${TRANS_SHOWN[transKey(m.id,S.lang||"en")]?t("showOriginal"):t("translateBtn")}</button>`}
        ${isManager&&!chatSelOn()?`<div class="bub-tools">
          <button class="bubtool" data-msgedit="${m.id}" aria-label="${t("editMsg")}">${ic("pen",14)}</button>
          <button class="bubtool" data-msgdel="${m.id}" aria-label="${t("deleteMsg")}">${ic("exit",14)}</button>
        </div>`:""}
      </div>`;
    }).join(""):`<div class="empty"><div class="big">${ic("chat",30)}</div>${emptyTxt}</div>`}
  </div>
  <div class="chatbar">
    <input id="chat-in" placeholder="${t("typeMessage")}" autocomplete="off">
    <button id="chat-send" aria-label="${t("send")}">${ic("send",17)}</button>
  </div>`;
}
