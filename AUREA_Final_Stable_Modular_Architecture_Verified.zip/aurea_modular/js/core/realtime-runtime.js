function tickStatus(){ if(S.session && safeToRender()) render(); }
async function runPoll(){
  if(!REMOTE || __polling || !S.session) return;
  if(enforceAccess()){ render(); return; }
  __polling=true;
  try{ const before=notifySnapshot(); const changed=await DB.poll();
    if(changed){ detectAndNotify(before); if(safeToRender()) render(); }
  }catch(e){}
  __polling=false;
}
/* Phase 10: realtime table mapping and row patching are centralized. */
function applyRealtimeChange(payload){
  return AUREA_REALTIME.applyPayload(payload);
}

function startRealtime(){
  if(!REMOTE || window.__rt) return;
  window.__rt=true;
  const sc=document.createElement("script");
  sc.src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
  sc.onload=()=>{ try{
    const client=AUREA_REALTIME.createClient();
    let tmr=null, pending=false;
    AUREA_REALTIME.subscribe(client,payload=>{
      const before=notifySnapshot();
      const patched=applyRealtimeChange(payload);
      if(patched){
        // targeted update: state is already correct, just alert + repaint
        detectAndNotify(before);
        clearTimeout(tmr);
        tmr=setTimeout(()=>{ if(S.session && safeToRender()) render(); }, 120);
      } else if(!pending){
        // unknown table -> fall back to a single role-aware polling boundary
        pending=true;
        clearTimeout(tmr);
        tmr=setTimeout(()=>{ pending=false; runPoll(); }, 300);
      }
    });
  }catch(e){ console.warn("realtime unavailable",e); } };
  sc.onerror=()=>console.warn("realtime script blocked — polling continues");
  document.head.appendChild(sc);
}
(async function(){
  restore();
  document.documentElement.setAttribute("data-theme",S.theme);
  document.documentElement.lang=S.lang;
  document.documentElement.dir=(S.lang==="ar"?"rtl":"ltr");
  try{ await DB.load(); }
  catch(e){
    console.error(e);
    if(REMOTE){ S.loadError=true; applySettings(); render(); return; }
    S.activities=demoActivities(); S.bookings=demoBookings();
    S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
    S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
    S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
  }
  /* Validate/refresh a remembered session; otherwise record an anonymous boot.
     Phase 11 observation is non-destructive in legacy mode. */
  if(S.session) AUREA_AUTH.refreshCurrent();
  else if(window.AUREA_SESSION_LIFECYCLE) AUREA_SESSION_LIFECYCLE.observeCurrent("boot-anonymous");
  /* V5: resolve the final landing screen before the first paint, preventing the remembered-screen -> start-screen flash. */
  if(S.session) S.tab=defaultTabFor(S.session.role);
  enforceAccess();
  applyOpenParam();
  applySettings();
  render();
  startRealtime();
  // Fast polling backup — makes updates feel instant even if websockets are blocked.
  if(REMOTE){
    setInterval(()=>{ if(S.session) runPoll(); }, 5000);
    // Poll immediately when the app regains focus or becomes visible
    window.addEventListener("focus", ()=>{ if(S.session) runPoll(); });
    document.addEventListener("visibilitychange", ()=>{ if(!document.hidden && S.session) runPoll(); });
  }
  initPhotoTaps();
  setTimeout(()=>loadWeather(false), 800);
  initConnectionWatch();
  initErrorGuard();
  // ===== Activity alarms + live status dots =====
  // Check every 30s so a minute boundary is never missed; re-render keeps dots current.
  let __lastMin=-1;
  function alarmTick(){
    try{
      checkActivityAlarms();
      const m=nowMinutes();
      if(m!==__lastMin){ __lastMin=m; tickStatus(); }   // refresh dots once per minute
    }catch(e){}
  }
  setInterval(alarmTick, 30000);
  setTimeout(alarmTick, 1500);                            // run shortly after load
  window.addEventListener("focus", alarmTick);            // catch phone waking up
  document.addEventListener("visibilitychange", ()=>{ if(!document.hidden) alarmTick(); });
})();
