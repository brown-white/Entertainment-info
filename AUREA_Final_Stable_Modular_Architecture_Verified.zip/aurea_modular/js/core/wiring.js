/* ---------------- wiring ---------------- */
function wireCommon(){
  document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{S.tab=b.dataset.tab;S.chatRoom=null;S.op=null;S.cat=null;S.planDay=undefined;render();});
  document.querySelectorAll("[data-op]").forEach(b=>b.onclick=()=>{S.op=b.dataset.op;S.cat=null;render();});
  document.querySelectorAll("[data-planday]").forEach(b=>b.onclick=()=>{S.planDay=+b.dataset.planday;render();});
  document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{S.cat=b.dataset.cat;render();});
  const c1=$("#crumb-ops"); if(c1) c1.onclick=()=>{S.op=null;S.cat=null;render();};
  const c2=$("#crumb-cats"); if(c2) c2.onclick=()=>{S.cat=null;render();};
  document.querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>{S.day=+b.dataset.day;render();});
  document.querySelectorAll("[data-sub]").forEach(b=>b.onclick=()=>{
    const [g,v]=b.dataset.sub.split(":"); S.sub[g]=v; S.chatRoom=null; render();
  });
  const mn=$("#btn-menu"); if(mn) mn.onclick=openMenuDrawer;
  const nb=$("#btn-notes"); if(nb) nb.onclick=openNotesModal;
  document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const id=+b.dataset.fav;
    S.favorites=S.favorites.includes(id)?S.favorites.filter(x=>x!==id):[...S.favorites,id]; persist(); render();
  });
  document.querySelectorAll("[data-book]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.book); if(a) openBookModal(a);
  });
  document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.buy); if(tk) openTicketBuyModal(tk);
  });
  document.querySelectorAll("[data-cancel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await AUREA_BOOKING_SERVICE.cancel(+b.dataset.cancel); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-cancelorder]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation(); await AUREA_TICKET_SERVICE.remove(+b.dataset.cancelorder); toast(t("cancelled")); render();
  });
  document.querySelectorAll("[data-delreq]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRequest(+b.dataset.delreq); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.edit); openEditModal(a);
  });
  document.querySelectorAll("[data-att]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const a=S.activities.find(x=>x.id===+b.dataset.att); if(a) openAttendanceModal(a);
  });
  document.querySelectorAll("[data-tedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); const tk=S.tickets.find(x=>x.id===+b.dataset.tedit); openTicketEditModal(tk);
  });
  document.querySelectorAll("[data-tpaid]").forEach(b=>b.onclick=async ()=>{
    const o=S.orders.find(x=>x.id===+b.dataset.tpaid); if(!o) return;
    await AUREA_TICKET_SERVICE.setStatus(o.id, o.status==="paid"?"reserved":"paid"); render();
  });
  document.querySelectorAll("[data-tdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await AUREA_TICKET_SERVICE.remove(+b.dataset.tdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-deluser]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delUserQ"),danger:true})) return;
    try{ await DB.deleteUser(+b.dataset.deluser); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-reqdone]").forEach(b=>b.onclick=async ()=>{
    const r=S.requests.find(x=>x.id===+b.dataset.reqdone); if(!r) return;
    await DB.setRequestStatus(r.id, r.status==="done"?"new":"done"); render();
  });
  document.querySelectorAll("[data-reqdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("delReqQ"),danger:true})) return;
    try{ await DB.deleteRequest(+b.dataset.reqdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskdone]").forEach(b=>b.onclick=async ()=>{
    const x=S.tasks.find(y=>y.id===+b.dataset.taskdone); if(!x) return;
    await DB.updateTask(x.id,{status:x.status==="done"?"open":"done"}); render();
  });
  document.querySelectorAll("[data-taccept]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.taccept,{status:"accepted"}); render();
  });
  document.querySelectorAll("[data-tsdone]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tsdone,{status:"done"}); toast(t("saved")); render();
  });
  document.querySelectorAll("[data-tstill]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tstill,{status:"still",was_still:true}); render();
  });
  document.querySelectorAll("[data-tcant]").forEach(b=>b.onclick=async ()=>{
    await DB.updateTask(+b.dataset.tcant,{status:"cant"}); render();
  });
  document.querySelectorAll("[data-fbopen]").forEach(b=>b.onclick=()=>openFeedbackDetail(b.dataset.fbopen));
  document.querySelectorAll("[data-fbdept]").forEach(b=>b.onclick=()=>openDeptDetail(b.dataset.fbdept));
  const fbx=$("#btn-fbexport"); if(fbx) fbx.onclick=openFeedbackExport;
  const fbd=$("#btn-fbdepts"); if(fbd) fbd.onclick=openDeptEditor;
  const rail=$("#hero-rail"), dots=$("#hero-dots");
  if(rail && dots){
    const marks=dots.querySelectorAll("i");
    const sync=()=>{
      const w=rail.scrollWidth/Math.max(1,marks.length);
      const i=Math.min(marks.length-1, Math.round(rail.scrollLeft/Math.max(1,w)));
      marks.forEach((m,j)=>m.classList.toggle("on", j===i));
    };
    rail.onscroll=sync;
    marks.forEach((m,j)=>m.onclick=()=>{
      rail.scrollTo({left:(rail.scrollWidth/marks.length)*j, behavior:"smooth"});
    });
  }
  /* One tap on an activity does whatever that person can actually do with it:
     the manager edits it, an entertainer opens the guest list, a guest books. */
  const openAct=id=>{
    const a=S.activities.find(x=>String(x.id)===String(id));
    if(!a || !S.session) return;
    if(S.session.role==="manager") return openEditModal(a);
    if(S.session.role==="staff") return canSeeGuests(a) ? openAttendanceModal(a) : openEditModal(a);
    if(!myBooking(a.id)) openBookModal(a);
  };
  document.querySelectorAll("[data-actopen]").forEach(el=>el.onclick=()=>openAct(el.dataset.actopen));
  document.querySelectorAll("[data-startact]").forEach(b=>b.onclick=ev=>{
    if(ev && ev.stopPropagation) ev.stopPropagation();
    openAct(b.dataset.startact);
  });
  const tnMake=$("#tn-make");
  if(tnMake) tnMake.onclick=()=>{ S.tab="req"; render(); setTimeout(()=>openReqEditor(),0); };
  const rqN=$("#rq-new");    if(rqN) rqN.onclick=()=>openReqEditor();
  const rqP=$("#rq-pack");   if(rqP) rqP.onclick=openReqPack;
  const rqD=$("#rq-depts");  if(rqD) rqD.onclick=openReqDeptEditor;
  const rqT=$("#rq-tpl");    if(rqT) rqT.onclick=openReqTemplateEditor;
  const rqDate=$("#rq-date");
  if(rqDate) rqDate.onchange=()=>{ S.reqDate=rqDate.value; render(); };
  document.querySelectorAll("[data-rqopen]").forEach(b=>b.onclick=()=>openReqEditor(b.dataset.rqopen));
  const fbs=$("#btn-fbseeall"); if(fbs) fbs.onclick=()=>{ S.tab="feedback"; render(); };
  const fb=$("#btn-addfb"); if(fb) fb.onclick=()=>openFeedbackModal();
  const cp=$("#btn-chpass"); if(cp) cp.onclick=openChangePassModal;
  const ap=$("#btn-addprofile"); if(ap) ap.onclick=()=>openProfileModal(null);
  document.querySelectorAll("[data-pedit]").forEach(b=>b.onclick=()=>{
    const pr=S.profiles.find(x=>x.id===+b.dataset.pedit); if(pr) openProfileModal(pr);
  });
  document.querySelectorAll("[data-pdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteProfile(+b.dataset.pdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-uedit]").forEach(b=>b.onclick=()=>{
    const u=S.users.find(x=>x.id===+b.dataset.uedit); if(u) openUserEditModal(u);
  });
  document.querySelectorAll("[data-gedit]").forEach(b=>b.onclick=()=>{
    const a=S.accounts.find(x=>x.id===+b.dataset.gedit); if(a) openGuestEditModal(a);
  });
  const ex=$("#btn-export"); if(ex) ex.onclick=exportReport;
  const exd=$("#btn-exportdata"); if(exd) exd.onclick=openExportModal;
  document.querySelectorAll("[data-busedit]").forEach(el=>el.onclick=()=>{
    const b=S.buses.find(x=>x.id==el.dataset.busedit); if(b) openBusModal(b);
  });
  document.querySelectorAll("[data-busadd]").forEach(el=>el.onclick=()=>openBusModal(null, el.dataset.busadd));
  document.querySelectorAll("[data-hub]").forEach(el=>el.onclick=()=>{
    const h=el.dataset.hub;
    if(h==="export"){ openExportModal(); return; }
    S.tab=h; render();
  });
  const crumbHub=$("#crumb-hub"); if(crumbHub) crumbHub.onclick=()=>{ S.tab="settings"; render(); };
  const crumbPb=$("#crumb-pb"); if(crumbPb) crumbPb.onclick=()=>{ S.tab="builder"; render(); };
  document.querySelectorAll("[data-pbedit]").forEach(b=>b.onclick=()=>pbOpen(S.session.role, b.dataset.pbedit));
  document.querySelectorAll("[data-pbadd]").forEach(b=>b.onclick=()=>pbAdd(b.dataset.pbadd));
  document.querySelectorAll("[data-pbup]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbup,-1));
  document.querySelectorAll("[data-pbdown]").forEach(b=>b.onclick=()=>pbMove(b.dataset.pbdown,1));
  document.querySelectorAll("[data-pbdup]").forEach(b=>b.onclick=()=>pbDup(b.dataset.pbdup));
  document.querySelectorAll("[data-pbdel]").forEach(b=>b.onclick=()=>pbDel(b.dataset.pbdel));
  // live editing of block fields
  document.querySelectorAll("[data-pbf]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbf).split("|");
    const apply=()=>{
      const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.value; render();
    };
    if(el.tagName==="SELECT"||el.type==="color") el.onchange=apply; else el.onblur=apply;
  });
  document.querySelectorAll("[data-pbc]").forEach(el=>{
    const [bid,key]=String(el.dataset.pbc).split("|");
    el.onchange=()=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(!blk) return; blk[key]=el.checked; render(); };
  });
  const pbT=$("#pb-title"); if(pbT) pbT.onblur=()=>{ const st=pbState(); if(st.page) st.page.title=pbT.value; };
  const pbR=$("#pb-role"); if(pbR) pbR.onchange=()=>{ pbState().role=pbR.value; };
  const pbS=$("#pb-save"); if(pbS) pbS.onclick=()=>{ const t2=$("#pb-title"); if(t2&&pbState().page) pbState().page.title=t2.value; pbSave(); };
  // block images
  document.querySelectorAll("[data-pbimgadd]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgadd).split("|");
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk[key]=url; render(); } });
  });
  document.querySelectorAll("[data-pbimgrm]").forEach(b=>b.onclick=()=>{
    const [bid,key]=String(b.dataset.pbimgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk[key]=""; render(); }
  });
  document.querySelectorAll("[data-pbgadd]").forEach(b=>b.onclick=()=>{
    const bid=b.dataset.pbgadd;
    pickOneImage(url=>{ const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
      if(blk){ blk.urls=(blk.urls||[]).concat([url]); render(); } }, true);
  });
  document.querySelectorAll("[data-pbgrm]").forEach(b=>b.onclick=()=>{
    const [bid,ix]=String(b.dataset.pbgrm).split("|");
    const st=pbState(); const blk=(st.page&&st.page.blocks||[]).find(x=>x.id===bid);
    if(blk){ blk.urls=(blk.urls||[]).filter((_,i)=>i!==+ix); render(); }
  });
  document.querySelectorAll("[data-translate]").forEach(b=>b.onclick=()=>translateMessage(b.dataset.translate));
  const navB=$("#btn-navback"); if(navB) navB.onclick=navBack;
  const navF=$("#btn-navfwd");  if(navF) navF.onclick=navForward;
  const qzSend=$("#qz-send"); if(qzSend) qzSend.onclick=submitQuizAnswer;
  document.querySelectorAll("[data-dutyedit]").forEach(b=>b.onclick=()=>openDutyModal(+b.dataset.dutyedit));
  const qrP=$("#qr-print"); if(qrP) qrP.onclick=openQrPrint;
  document.querySelectorAll("[data-gotab]").forEach(b=>b.onclick=()=>{ S.tab=b.dataset.gotab; render(); });
  const crmQ=$("#crm-q"); if(crmQ && !crmQ.dataset.searchFixedV6242){
    crmQ.dataset.searchFixedV6242="1";
    const filterCrm=()=>{
      S.crmQuery=crmQ.value;
      const q=crmQ.value.trim().toLowerCase();
      const rows=[...document.querySelectorAll("[data-crm-search]")];
      let shown=0;
      rows.forEach(row=>{
        const ok=!q||String(row.dataset.crmSearch||"").includes(q);
        row.style.display=ok?"":"none";
        if(ok)shown++;
      });
      const empty=document.querySelector("#crm-search-empty");
      if(empty)empty.style.display=(rows.length&&shown===0)?"":"none";
    };
    crmQ.oninput=filterCrm;
    crmQ.onkeydown=e=>{ if(e.key==="Enter"){ e.preventDefault(); filterCrm(); crmQ.blur(); } };
    crmQ.onsearch=()=>{ filterCrm(); crmQ.blur(); };
    filterCrm();
  }
  document.querySelectorAll("[data-crm]").forEach(b=>b.onclick=()=>{ S.tab="g360:"+b.dataset.crm; render(); });
  const crumbCrm=$("#crumb-crm"); if(crumbCrm) crumbCrm.onclick=()=>{ S.tab="guests"; S.sub.guests="crm"; render(); };
  document.querySelectorAll("[data-uview]").forEach(b=>b.onclick=()=>{ S.tab="emp:"+b.dataset.uview; render(); });
  const profReq=$("#prof-req"); if(profReq) profReq.onclick=openProfileChangeModal;
  // any picture with data-pv opens the big viewer
  /* photo taps are handled globally by initPhotoTaps() */
  const crumbTeam=$("#crumb-team"); if(crumbTeam) crumbTeam.onclick=()=>{
    if(S.session.role==="manager"){ S.tab="team"; S.sub.team="accounts"; }
    else S.tab="teaminfo";
    render();
  };
  document.querySelectorAll("[data-ususpend]").forEach(b=>b.onclick=async ()=>{
    const u=S.users.find(x=>x.id==b.dataset.ususpend); if(!u) return;
    try{ await DB.updateUser(u.id,{active:u.active===false}); toastOk(t("saved")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-taskopen]").forEach(b=>b.onclick=()=>openTaskModal(b.dataset.taskopen));
  const wRe=$("#w-reload"); if(wRe) wRe.onclick=()=>loadWeather(true);
  document.querySelectorAll("[data-asub]").forEach(b=>b.onclick=()=>{ S.sub.assign=b.dataset.asub; render(); });
  document.querySelectorAll("[data-aday]").forEach(b=>b.onclick=()=>{ S.assignDay=+b.dataset.aday; render(); });
  const aAuto=$("#asg-auto"); if(aAuto) aAuto.onclick=()=>AUREA_PLANNER.open(assignDay());
  const aRepair=$("#asg-clearbad"); if(aRepair) aRepair.onclick=async ()=>{
    if(!AUREA_PERMISSIONS.can("planner.manage")){ toast(t("profileReadOnly")); return; }
    try{
      const changed=await AUREA_PLANNER.repair();
      if(changed){ toastOk(t("saved")); render(); }
      else toastOk("All current assignments are valid");
    }catch(e){ toastErr(t("errSave")); }
  };
  document.querySelectorAll("[data-arrange]").forEach(b=>b.onclick=()=>openArrangeModal(b.dataset.arrange));
  const ctSel=$("#ct-select"); if(ctSel) ctSel.onclick=()=>{ S.chatSel=[]; render(); };
  const ctCancel=$("#ct-cancel"); if(ctCancel) ctCancel.onclick=()=>{ S.chatSel=null; render(); };
  const ctAll=$("#ct-all"); if(ctAll) ctAll.onclick=()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    S.chatSel = (S.chatSel||[]).length===ids.length ? [] : ids;
    render();
  };
  document.querySelectorAll("[data-msgpick]").forEach(el=>el.onclick=()=>{
    const id=+el.dataset.msgpick;
    const cur=S.chatSel||[];
    S.chatSel = cur.includes(id) ? cur.filter(x=>x!==id) : cur.concat([id]);
    render();
  });
  const ctDel=$("#ct-del"); if(ctDel) ctDel.onclick=async ()=>{
    const ids=(S.chatSel||[]).slice();
    if(!ids.length) return;
    if(!(await confirmAction({title:t("deleteMsgsQ").replace("{n}",ids.length), body:t("cannotUndo"), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  const ctClear=$("#ct-clear"); if(ctClear) ctClear.onclick=async ()=>{
    const ids=(S.messages||[]).filter(m=>m.room===S.chatRoom).map(m=>m.id);
    if(!ids.length) return;
    if(!(await confirmAction({title:t("clearChatQ"), body:t("clearChatHint").replace("{n}",ids.length), danger:true}))) return;
    for(const id of ids){ await DB.deleteMessage(id); }
    S.chatSel=null; toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-sreqdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    if(!(await confirmAction({title:t("deleteReqQ"), body:t("cannotUndo"), danger:true}))) return;
    await DB.deleteStaffReq(+b.dataset.sreqdel); toastOk(t("saved")); render();
  });
  const avBtn=$("#att-vac"); if(avBtn) avBtn.onclick=()=>openVacationModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  const aoBtn=$("#att-only"); if(aoBtn) aoBtn.onclick=()=>openAttPersonModal();
  document.querySelectorAll("[data-attedit]").forEach(el=>el.onclick=()=>openAttPersonModal(+el.dataset.attedit));
  document.querySelectorAll("[data-dgopen]").forEach(b=>b.onclick=()=>{
    const [kind,key]=String(b.dataset.dgopen).split("|");
    S.openDay={...(S.openDay||{})};
    S.openDay[kind] = (S.openDay[kind]===key) ? null : key;   // tap again to close
    render();
  });
  const aEnt=$("#asg-ent"); if(aEnt) aEnt.onclick=()=>openEntranceModal(assignDay());
  document.querySelectorAll("[data-aopen]").forEach(el=>el.onclick=()=>{
    openEditModal(el.dataset.aopen);
  });
  document.querySelectorAll("[data-userleave]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openLeaveModal(+b.dataset.userleave);
  });
  document.querySelectorAll("[data-bkedit]").forEach(b=>b.onclick=e=>{
    e.stopPropagation(); openBookingEditor(+b.dataset.bkedit);
  });
  document.querySelectorAll("[data-bkguest]").forEach(b=>b.onclick=()=>{
    S.tab="g360:"+b.dataset.bkguest; render();
  });
  document.querySelectorAll("[data-bkdel]").forEach(b=>b.onclick=async e=>{
    e.stopPropagation();
    const id=+b.dataset.bkdel;
    const bk=S.bookings.find(x=>x.id===id); if(!bk) return;
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(id); toastOk(t("saved")); render();
  });
  document.querySelectorAll("[data-aemp]").forEach(el=>el.onclick=()=>openSkillEditor(el.dataset.aemp));
  if(S.tab==="weather" && !S.weather) loadWeather(false);
  document.querySelectorAll("[data-bdrole]").forEach(b=>b.onclick=()=>{ S.sub.builder=b.dataset.bdrole; render(); });
  const bdStart=$("#bd-start");
  if(bdStart) bdStart.onchange=async ()=>{
    const role=builderRole(), m={...(S.settings.menu||{})};
    m[role]={...(m[role]||{}), start:bdStart.value};
    await DB.saveSettings({...S.settings, menu:m});
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-bdup]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bdup,-1));
  document.querySelectorAll("[data-bddown]").forEach(b=>b.onclick=()=>moveMenuItem(b.dataset.bddown,1));
  document.querySelectorAll("[data-bdname]").forEach(b=>b.onclick=()=>openRenameModal(b.dataset.bdname));
  document.querySelectorAll("[data-bdhide]").forEach(b=>b.onclick=()=>toggleMenuItem(b.dataset.bdhide));
  document.querySelectorAll("[data-bdgname]").forEach(b=>b.onclick=()=>openGroupRenameModal(b.dataset.bdgname));
  document.querySelectorAll("[data-bdedit]").forEach(b=>b.onclick=()=>pbOpen(builderRole(), b.dataset.bdedit));
  document.querySelectorAll("[data-bddel]").forEach(b=>b.onclick=()=>openCustomPageModal(b.dataset.bddel));
  const bdAdd=$("#bd-add"); if(bdAdd) bdAdd.onclick=()=>pbOpen(builderRole(), null);
  const bdReset=$("#bd-reset"); if(bdReset) bdReset.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle")})) return;
    saveMenuConf(builderRole(),{order:[],hidden:[],names:{},custom:[]});
  };
  if($("#s-logo")){
    const fileIn=document.querySelector("[data-photoinput]");
    const box=document.querySelector("[data-photobox]");
    const paint=()=>{ if(!box) return; const u=$("#s-logo").value;
      box.innerHTML = u ? `<img src="${esc(u)}" alt="">` : `<span>${ic("user",26)}</span>`; };
    paint();
    if(box) box.onclick=()=>fileIn&&fileIn.click();
    if(fileIn) fileIn.onchange=()=>{
      const f=fileIn.files&&fileIn.files[0]; if(!f) return;
      openCropModal(f, url=>{ const el=$("#s-logo"); if(el) el.value=url; paint(); toastOk(t("saved")); });
      fileIn.value="";
    };
    const rmL=$("#s-logo-rm");
    if(rmL) rmL.onclick=()=>{ const el=$("#s-logo"); if(el) el.value=""; paint(); };
  }
  const infoAdd=$("#info-add"); if(infoAdd) infoAdd.onclick=()=>openInfoModal();
  document.querySelectorAll("[data-infoedit]").forEach(b=>b.onclick=()=>openInfoModal(+b.dataset.infoedit));
  const phAdd=$("#ph-add"); if(phAdd) phAdd.onclick=openPhotoModal;
  document.querySelectorAll("[data-phdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deletePhoto(+b.dataset.phdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const srNew=$("#sr-new"); if(srNew) srNew.onclick=openStaffReqModal;
  document.querySelectorAll("[data-reqok]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqok,"ok"));
  document.querySelectorAll("[data-reqno]").forEach(b=>b.onclick=()=>answerStaffReq(+b.dataset.reqno,"no"));
  document.querySelectorAll("[data-guestrate]").forEach(b=>b.onclick=async ()=>{
    const rate=+b.dataset.guestrate;
    try{
      await DB.addFeedback({room:String(S.session.room||""), nationality:S.session.nationality||"",
        rate, comment:"", by_user:""});
      toastOk(t("thankYou"));
      render();
      // happy guests are invited to post publicly; unhappy ones stay private with the manager
      setTimeout(()=>openReviewInvite(rate), 350);
    }catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-attn]").forEach(b=>b.onclick=()=>{
    const [tab,sub]=b.dataset.attn.split("|");
    S.tab=tab; if(sub) S.sub[tab]=sub; render();
  });
  document.querySelectorAll("[data-satt]").forEach(b=>b.onclick=async ()=>{
    const [un,mk,d]=b.dataset.satt.split("|");
    const u=S.users.find(x=>x.username===un); if(!u) return;
    const next=attNext(u,mk,+d);
    if(next===undefined) return;                 // future day — nothing to mark
    try{ await DB.setStaffAtt(un, dateStr(mk,+d), next); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  const attP=$("#att-prev"); if(attP) attP.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),-1); render(); };
  const attN=$("#att-next"); if(attN) attN.onclick=()=>{ S.attMonth=shiftMonth(currentAttMonth(),1); render(); };
  const attX=$("#att-export"); if(attX) attX.onclick=()=>openExportModal("monthatt");
  document.querySelectorAll("[data-quiznew]").forEach(b=>b.onclick=()=>openQuizModal(null,b.dataset.quiznew));
  document.querySelectorAll("[data-quizedit]").forEach(b=>b.onclick=()=>{
    const q=S.quizzes.find(x=>x.id==b.dataset.quizedit); if(q) openQuizModal(q);
  });
  document.querySelectorAll("[data-quizdel]").forEach(b=>b.onclick=async ()=>{
    if(!await confirmAction({question:t("confirmTitle"),danger:true})) return;
    try{ await DB.deleteQuiz(+b.dataset.quizdel); toastOk(t("deleted")); render(); }
    catch(e){ toastErr(t("errSave")); }
  });
  document.querySelectorAll("[data-palette]").forEach(b=>b.onclick=()=>openThemePreview(b.dataset.palette));
  const nt=$("#notif-toggle"); if(nt) nt.onclick=()=>{
    const turningOn=!notifSoundOn();
    localStorage.setItem("ent_notif",turningOn?"on":"off");
    if(turningOn){ askNotifPermission(); setTimeout(playChime,120); }
    render();
  };
  const aks=$("#ai-savekey"); if(aks) aks.onclick=()=>{
    const v=$("#ai-key").value.trim(); if(!v) return;
    localStorage.setItem("ent_ai_key",v); toast(t("saved")); render();
  };
  const ais=$("#ai-send");
  if(ais){
    const go=()=>{ const inp=$("#ai-in"); const v=inp.value.trim(); if(!v||S.aiBusy) return; inp.value=""; askAI(v); };
    ais.onclick=go;
    $("#ai-in").onkeydown=e=>{ if(e.key==="Enter") go(); };
  }
  document.querySelectorAll("[data-taskdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteTask(+b.dataset.taskdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-roomact]").forEach(b=>b.onclick=async ()=>{
    const r=S.rooms.find(x=>x.id==b.dataset.roomact); if(!r) return;
    await DB.setRoomActive(r.id,!r.active); render();
  });
  document.querySelectorAll("[data-roomdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteRoom(+b.dataset.roomdel||b.dataset.roomdel); toast(t("deleted")); render();
  });
  document.querySelectorAll("[data-chatroom]").forEach(el=>el.onclick=()=>{
    S.chatRoom=el.dataset.chatroom; render();
  });
  document.querySelectorAll("[data-staffchat]").forEach(el=>el.onclick=()=>{
    S.chatRoom="staff:"+el.dataset.staffchat; render();
  });
  document.querySelectorAll("[data-msgedit]").forEach(b=>b.onclick=()=>{
    const m=S.messages.find(x=>x.id==b.dataset.msgedit); if(m) openMsgEditModal(m);
  });
  document.querySelectorAll("[data-msgdel]").forEach(b=>b.onclick=async ()=>{
    await DB.deleteMessage(+b.dataset.msgdel||b.dataset.msgdel); toast(t("deleted")); render();
  });
  S.chatSel = S.chatRoom ? S.chatSel : null;
  const cb=$("#btn-chatback"); if(cb) cb.onclick=()=>{S.chatRoom=null;render();};
  const add=$("#btn-add"); if(add) add.onclick=()=>openEditModal(null);
  const addT=$("#btn-addticket"); if(addT) addT.onclick=()=>openTicketEditModal(null);
  const addU=$("#btn-adduser"); if(addU) addU.onclick=openUserModal;
  const addTk=$("#btn-addtask"); if(addTk) addTk.onclick=openTaskAddModal;
  const rs=$("#btn-req-song"); if(rs) rs.onclick=()=>openRequestModal("song");
  const rb=$("#btn-req-bday"); if(rb) rb.onclick=()=>openRequestModal("birthday");
  const ar=$("#btn-addrooms"); if(ar) ar.onclick=async ()=>{
    const raw=$("#rooms-in").value;
    const list=[...new Set(raw.split(/[\n,;]+/).map(x=>x.trim()).filter(Boolean))];
    if(!list.length) return;
    await DB.addRooms(list); toast(t("saved")); render();
  };
  const rf=$("#rooms-filter"); if(rf) rf.oninput=()=>{
    const q=rf.value.trim().toLowerCase();
    document.querySelectorAll(".roomline").forEach(el=>{
      el.style.display = !q || el.dataset.room.toLowerCase().includes(q) || el.textContent.toLowerCase().includes(q) ? "" : "none";
    });
  };
  const sv=$("#btn-savesettings"); if(sv) sv.onclick=async ()=>{
    // Each settings page shows only some fields — save exactly what is on screen,
    // and leave everything else untouched.
    const v=(id,fb)=>{ const el=$(id); return el?el.value:fb; };
    const has=id=>!!$(id);
    const st={...S.settings};
    if(has("#s-name"))    st.name=v("#s-name","").trim()||"Entertainment";
    if(has("#s-sub"))     st.subtitle=v("#s-sub","").trim();
    if(has("#s-welcome")) st.welcomeMsg=v("#s-welcome","").trim();
    if(has("#s-primary")){ st.primary=v("#s-primary",st.primary); st.accent=v("#s-accent",st.accent);
      st.bg=v("#s-bg",st.bg); st.textColor=v("#s-text",st.textColor);
      st.navBg=v("#s-navbg",st.navBg); st.navActive=v("#s-navon",st.navActive); }
    if(has("#s-font"))    st.fontStyle=v("#s-font",st.fontStyle);
    if(has("#s-btn"))     st.buttonStyle=v("#s-btn",st.buttonStyle);
    if(has("#s-mhome")){ st.menuHome=v("#s-mhome","").trim(); st.menuProgram=v("#s-mprog","").trim();
      st.menuTickets=v("#s-mtick","").trim(); st.menuChat=v("#s-mchat","").trim(); st.menuStay=v("#s-mstay","").trim(); }
    if(has("#s-trip")){ st.tripadvisor=v("#s-trip","").trim(); st.google=v("#s-goog","").trim();
      st.holidaycheck=v("#s-holi","").trim(); }
    if(has("#s-insta")){ st.instagram=v("#s-insta","").trim(); st.tiktok=v("#s-tiktok","").trim();
      st.facebook=v("#s-fb","").trim(); st.youtube=v("#s-yt","").trim(); st.whatsapp=v("#s-wa","").trim(); }
    if(has("#s-fs"))       st.fontScale=v("#s-fs",st.fontScale);
    if(has("#s-autodark")) st.autoDark=$("#s-autodark").checked;
    if(has("#s-logo"))     st.logo=v("#s-logo","").trim();
    if(has("#s-hotel"))    st.hotelName=v("#s-hotel","").trim();
    if(has("#s-contact"))  st.contact=v("#s-contact","").trim();
    if(has("#s-cur"))      st.currency=v("#s-cur","").trim();
    if(has("#s-tz"))       st.timezone=v("#s-tz",st.timezone);
    if(has("#s-lat")){ st.lat=v("#s-lat","").trim(); st.lon=v("#s-lon","").trim(); }
    const featBoxes=document.querySelectorAll(".feat-cb");
    if(featBoxes.length){ const f={}; ["quiz","tickets","gallery","bus","hotelinfo","weather"].forEach(k=>f[k]=false);
      featBoxes.forEach(cb=>{ if(cb.checked) f[cb.value]=true; }); st.features=f; }
    if(has("#s-aiep"))   st.aiEndpoint=v("#s-aiep","").trim();
    if(has("#s-pushep")) st.pushEndpoint=v("#s-pushep","").trim();
    // only accept secure https endpoints
    for(const f of ["aiEndpoint","pushEndpoint"]){
      if(st[f] && !/^https:\/\//i.test(st[f])){ toastErr(t("errHttps")); return; }
    }
    const coordsChanged = st.lat!==S.settings.lat || st.lon!==S.settings.lon || st.timezone!==S.settings.timezone;
    await DB.saveSettings(st); applySettings();
    if(coordsChanged) loadWeather(true);
    toastOk(t("saved")); render();
  };
  document.querySelectorAll("[data-open]").forEach(el=>el.onclick=()=>{
    if(!S.session || S.session.role!=="guest") return;
    const a=S.activities.find(x=>x.id===+el.dataset.open);
    if(a) openGuestActivityDetail(a);
  });
  /* chat send + read marking + scroll */
  const cs=$("#chat-send");
  if(cs){
    const g=S.session;
    let room, meSide, readSide;
    if(g.role==="guest"){ room=g.room; meSide="guest"; readSide="guest"; }
    else if(g.role==="staff"){ room="staff:"+g.username; meSide="guest"; readSide="guest"; }
    else { room=S.chatRoom; meSide="team"; readSide="team"; }
    if(room){
      const flag = readSide==="team"?"read_by_team":"read_by_guest";
      const sender = readSide==="team"?"guest":"team";
      if(S.messages.some(m=>m.room===room&&m.sender===sender&&!m[flag])){
        DB.markRead(room,readSide).then(()=>render());
      }
      window.scrollTo(0,document.body.scrollHeight);
      const doSend=async ()=>{
        const inp=$("#chat-in"); const txt=inp.value.trim(); if(!txt) return;
        inp.value="";
        await DB.addMessage({room,sender:meSide,sender_name:g.name,text:txt,
          read_by_team:meSide==="team",read_by_guest:meSide==="guest"});
        render();
      };
      cs.onclick=doSend;
      $("#chat-in").onkeydown=e=>{ if(e.key==="Enter") doSend(); };
    }
  }
}

