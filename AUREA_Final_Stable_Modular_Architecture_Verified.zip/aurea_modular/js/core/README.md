# Core
Shared application foundations only.

- `config.js`: environment/configuration and default app settings.
- `foundation.js`: translations, state, shared access helpers and preview-data foundation.
- `runtime.js`: shared runtime/UI helpers used across roles.

Avoid putting Guest-, Entertainer-, or Manager-specific business logic here.
