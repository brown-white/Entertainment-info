
/* ---------------- helpers ---------------- */
const $ = sel => document.querySelector(sel);
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function shade(hex,p){
  const n=parseInt(hex.slice(1),16); let r=n>>16,g=(n>>8)&255,b=n&255;
  r=Math.min(255,Math.round(r+(255-r)*p)); g=Math.min(255,Math.round(g+(255-g)*p)); b=Math.min(255,Math.round(b+(255-b)*p));
  return "#"+((r<<16)|(g<<8)|b).toString(16).padStart(6,"0");
}

/* ============ COLOUR PALETTES (each works in light AND dark) ============ */
const PALETTES = {
  /* Midnight navy, champagne gold, warm ivory. A palette carries an optional
     font and button shape so one tap sets the whole look. */
  aurea: { label:"Aurea Resort", font:"aurea", btn:"pill",
    light:{ primary:"#101820", accent:"#C9A96E", bg:"#F7F3EC", text:"#101820", card:"#FFFFFF", sand:"#EFE8DC", line:"#E2D8C8" },
    dark: { primary:"#C9A96E", accent:"#C9A96E", bg:"#0B1016", text:"#F1EBE1", card:"#151C24", sand:"#1D2731", line:"#2A3540" } },
  brownWhite: { label:"Brown & White",
    light:{ primary:"#3E2A1E", accent:"#B98A5C", bg:"#F7F2EA", text:"#2B1F16", card:"#FFFFFF", sand:"#EFE6D8", line:"#E2D6C4" },
    dark: { primary:"#D9B47F", accent:"#C9A26B", bg:"#17110C", text:"#F2E7D8", card:"#221913", sand:"#2C211A", line:"#3A2C22" } }
};
function paletteList(){ return Object.keys(PALETTES); }
function applyPalette(){
  if(S.settings && S.settings.palette && S.settings.palette!=="custom" && !PALETTES[S.settings.palette]){
    S.settings.palette="brownWhite";                 // an old theme that no longer exists
  }
  const key=S.settings.palette;
  const pal=PALETTES[key]; if(!pal) return false;      // custom colours -> skip
  const mode=(S.theme==="dark")?"dark":"light";
  const c=pal[mode], root=document.documentElement.style;
  root.setProperty("--espresso",c.primary);
  root.setProperty("--cacao",shade(c.primary,.18));
  root.setProperty("--bronze",c.accent);
  root.setProperty("--bg-light",pal.light.bg);
  root.setProperty("--ink-light",pal.light.text);
  root.setProperty("--bg-dark",pal.dark.bg);
  root.setProperty("--ink-dark",pal.dark.text);
  root.setProperty("--bg",c.bg);
  root.setProperty("--ink",c.text);
  root.setProperty("--card",c.card);
  root.setProperty("--sand",c.sand);
  root.setProperty("--line",c.line);
  root.setProperty("--muted",shade(c.text,mode==="dark"?-0.35:0.42));
  root.setProperty("--nav-bg",c.card);
  root.setProperty("--nav-on",c.primary);
  return true;
}
function applySettings(){
  const st=S.settings, root=document.documentElement.style;
  applyAutoDark();
  if(applyPalette()){
    const pack=PALETTES[st.palette]||{};
    const f0=FONTS[st.fontStyle]||FONTS[pack.font]||FONTS.elegant;
    root.setProperty("--font-display",f0[0]); root.setProperty("--font-body",f0[1]);
    const br0=BTN_R[st.buttonStyle]||BTN_R[pack.btn]||BTN_R.rounded;
    root.setProperty("--btn-radius",br0[0]); root.setProperty("--btn-radius-sm",br0[1]);
    document.title=st.name||"Entertainment";
    return;
  }
  root.setProperty("--espresso",st.primary);
  root.setProperty("--cacao",shade(st.primary,.22));
  root.setProperty("--bronze",st.accent);
  root.setProperty("--bg-light",st.bg||"#F7F2EA");
  root.setProperty("--ink-light",st.textColor||"#2B1F16");
  if(S.theme==="light"){
    root.setProperty("--nav-bg",st.navBg||"#FFFFFF");
    root.setProperty("--nav-on",st.navActive||shade(st.primary,.22));
  } else { root.removeProperty("--nav-bg"); root.removeProperty("--nav-on"); }
  const f=FONTS[st.fontStyle]||FONTS.elegant;
  root.setProperty("--font-display",f[0]); root.setProperty("--font-body",f[1]);
  const br=BTN_R[st.buttonStyle]||BTN_R.rounded;
  root.setProperty("--btn-radius",br[0]); root.setProperty("--btn-radius-sm",br[1]);
  applyFontScale();
  document.title=st.name||"Entertainment";
}
const FONT_SCALES={small:.92,normal:1,large:1.12,xl:1.25};
/* Try a theme before committing to it. Cancel puts everything back. */
function openThemePreview(key){
  const before=S.settings.palette, beforeFont=S.settings.fontStyle, beforeBtn=S.settings.buttonStyle;
  const trying=(key==="custom")?"":key;
  S.settings.palette=trying;
  const pack=PALETTES[trying];
  if(pack && pack.font){ S.settings.fontStyle=pack.font; S.settings.buttonStyle=pack.btn||S.settings.buttonStyle; }
  applySettings();
  const name=PALETTES[trying]?PALETTES[trying].label:t("themeCustom");
  const wrap=baseModal(`
    <h3>${ic("palette",20)} ${esc(name)}</h3>
    <p class="mini">${t("previewOn")}</p>
    <div class="tp-demo">
      <div class="tp-card"><b>${esc(S.settings.name||"Entertainment")}</b>
        <span class="mini">${esc(t("appSub"))}</span>
        <span class="tp-btn">${t("book")}</span></div>
    </div>
    <button class="btn" id="tp-use">${t("applyTheme")}</button>
    <button class="btn ghost" id="tp-x">${t("cancelBtn")}</button>`);
  const revert=()=>{
    S.settings.palette=before; S.settings.fontStyle=beforeFont; S.settings.buttonStyle=beforeBtn;
    applySettings();
  };
  wrap.querySelector("#tp-x").onclick=()=>{ revert(); wrap.remove(); render(); };
  wrap.onclick=e=>{ if(e.target===wrap){ revert(); wrap.remove(); render(); } };
  wrap.querySelector("#tp-use").onclick=async ()=>{
    try{
      await DB.saveSettings({...S.settings, palette:trying});
      applySettings(); wrap.remove(); toastOk(t("saved")); render();
    }catch(e){ revert(); toastErr(t("errSave")); }
  };
}
function applyFontScale(){
  const k=(S.settings&&S.settings.fontScale)||"normal";
  const v=FONT_SCALES[k]||1;
  document.documentElement.style.setProperty("--fscale", String(v));
}
/* follow the phone's dark mode when the manager switched it on */
function applyAutoDark(){
  if(!S.settings || !S.settings.autoDark) return;
  try{
    const m=window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)");
    if(!m) return;
    const want=m.matches?"dark":"light";
    if(S.theme!==want){ S.theme=want; document.documentElement.setAttribute("data-theme",want); }
    if(!window.__autoDarkHooked && m.addEventListener){
      window.__autoDarkHooked=true;
      m.addEventListener("change",()=>{ if(S.settings.autoDark){ applyAutoDark(); applySettings(); render(); } });
    }
  }catch(e){}
}
/* is a feature switched on? (missing = on, so nothing breaks) */
function featureOn(k){
  const f=(S.settings&&S.settings.features)||{};
  return f[k]!==false;
}
function menuLabel(key,fallback){ const v=(S.settings[key]||"").trim(); return v||fallback; }
function fmtTime(ts){ return whenLabel(ts); }
function bookingsFor(actId){ return S.bookings.filter(b=>b.activity_id===actId); }
function seatsTaken(actId){ return bookingsFor(actId).filter(b=>b.status==="booked").reduce((n,b)=>n+(+b.adults||0)+(+b.children||0),0); }
function myBooking(actId){ const g=S.session; if(!g||g.role!=="guest") return null;
  return S.bookings.find(b=>b.activity_id===actId && b.room===g.room); }
function ordersFor(tkId){ return S.orders.filter(o=>o.ticket_id===tkId); }
function ticketsSold(tkId){ return ordersFor(tkId).reduce((n,o)=>n+(+o.qty||0),0); }
function myOrders(){ const g=S.session; if(!g||g.role!=="guest") return [];
  return S.orders.filter(o=>o.room===g.room); }
function myRequestsList(){ const g=S.session; if(!g||g.role!=="guest") return [];
  return S.requests.filter(r=>r.room===g.room); }
function accountName(room){ const a=S.accounts.find(x=>x.room===room); return a?a.name:room; }
/* The registered guest behind a room number, matched loosely so 0102 finds 102. */
function guestForRoom(room){
  const r=String(room||"").trim();
  if(!r) return null;
  const list=S.accounts||[];
  return list.find(a=>String(a.room||"")===r)
      || list.find(a=>String(a.username||"")===r)
      || list.find(a=>String(a.room||"").replace(/^0+/,"")===r.replace(/^0+/,"") && r.replace(/^0+/,""))
      || null;
}
/* Every room the app knows about — the registered guests first, then any
   empty room from the room list, so she can pick instead of typing. */
function knownRooms(){
  const out=[];
  (S.accounts||[]).forEach(a=>{ const r=String(a.room||"").trim(); if(r&&!out.includes(r)) out.push(r); });
  (S.rooms||[]).forEach(x=>{ const r=String(x.room||"").trim(); if(r&&!out.includes(r)) out.push(r); });
  return out.sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));
}
function unreadFor(role){
  if(role==="guest"){ const g=S.session; return S.messages.filter(m=>m.room===g.room&&m.sender==="team"&&!m.read_by_guest).length; }
  return unreadGuests()+unreadTeam();
}
/* kept apart so a guest message never lights up Team, and the other way round */
function unreadGuests(){
  return S.messages.filter(m=>!isStaffRoom(m.room)&&m.sender==="guest"&&!m.read_by_team).length;
}
function unreadTeam(){
  return S.messages.filter(m=>isStaffRoom(m.room)&&m.sender==="guest"&&!m.read_by_team).length;
}
function teamReqCount(){
  return (S.staffReqs||[]).filter(r=>String(r.status||"new")==="new").length;
}
function visibleNotes(role){
  return S.notes.filter(n=>n.audience==="all" || (role==="guest"?n.audience==="guests":n.audience==="team"));
}
function unseenNotes(role){ return visibleNotes(role).some(n=>n.id>S.seenNote); }
function reviewDue(g){
  if(!g || !g.arrival || !g.departure) return false;
  const a=Date.parse(g.arrival), d=Date.parse(g.departure);
  if(isNaN(a)||isNaN(d)||d<a) return false;
  return Date.now() >= a+(d-a)/2;
}
/* ===== Universal toast: type = "success" | "error" | "warn" | "info" ===== */
function toast(msg, type){
  type = type || "success";
  const marks={success:"check",error:"close",warn:"bell",info:"sparkle"};
  const el=document.createElement("div");
  el.className="toast t-"+type;
  el.setAttribute("role", type==="error"?"alert":"status");
  el.innerHTML='<span class="t-ic">'+ic(marks[type]||"check",16)+'</span><span>'+esc(msg)+'</span>';
  document.body.appendChild(el);
  setTimeout(()=>{ el.classList.add("out"); setTimeout(()=>el.remove(),260); }, type==="error"?3600:2400);
}
function toastOk(m){ toast(m,"success"); }
function toastErr(m){ toast(m,"error"); }
function toastWarn(m){ toast(m,"warn"); }
/* ===== Premium confirmation dialog for dangerous actions =====
   confirmAction({question, detail, confirmLabel, danger}) -> Promise<boolean> */
function confirmAction(opts){
  const o=opts||{};
  return new Promise(resolve=>{
    const wrap=document.createElement("div");
    wrap.className="modal-bg confirm-bg";
    wrap.innerHTML=`<div class="modal confirm-modal" role="dialog" aria-modal="true">
      <div class="cf-ic ${o.danger?"danger":""}">${ic(o.danger?"trash":"bell",22)}</div>
      <h3>${esc(o.question||t("confirmTitle"))}</h3>
      <p class="mini cf-sub">${esc(o.detail||t("cannotUndo"))}</p>
      <div class="cf-row">
        <button class="btn ghost" data-cf="no">${t("cancelBtn")}</button>
        <button class="btn ${o.danger?"warn":""}" data-cf="yes">${esc(o.confirmLabel||t("deleteActivity"))}</button>
      </div>
    </div>`;
    const done=v=>{ wrap.remove(); document.removeEventListener("keydown",onKey); resolve(v); };
    function onKey(e){ if(e.key==="Escape") done(false); }
    wrap.querySelector('[data-cf="no"]').onclick=()=>done(false);
    wrap.querySelector('[data-cf="yes"]').onclick=()=>done(true);
    wrap.onclick=e=>{ if(e.target===wrap) done(false); };
    document.addEventListener("keydown",onKey);
    document.body.appendChild(wrap);
    setTimeout(()=>{ const b=wrap.querySelector('[data-cf="yes"]'); if(b) b.focus(); },40);
  });
}
/* ===== Connection banner: offline / back online ===== */
let __wasOffline=false;
function connBanner(show, msg, kind){
  let el=document.getElementById("conn-banner");
  if(!show){ if(el) el.remove(); return; }
  if(!el){ el=document.createElement("div"); el.id="conn-banner"; document.body.appendChild(el); }
  el.className="conn-banner "+(kind||"off");
  el.textContent=msg;
}
function initConnectionWatch(){
  function goOffline(){ __wasOffline=true; connBanner(true, t("offlineMsg"), "off"); }
  function goOnline(){
    if(!__wasOffline){ connBanner(false); return; }
    __wasOffline=false;
    connBanner(true, t("backOnlineMsg"), "on");
    if(typeof runPoll==="function") runPoll();
    setTimeout(()=>connBanner(false), 2600);
  }
  window.addEventListener("offline", goOffline);
  window.addEventListener("online", goOnline);
  if(navigator.onLine===false) goOffline();
}
/* ===== Global error safety net: never leave a broken screen silently ===== */
function initErrorGuard(){
  window.addEventListener("error", e=>{ console.error("app error:", e && e.message); });
  window.addEventListener("unhandledrejection", e=>{
    const r=e && e.reason;
    console.error("unhandled:", r);
    const txt=String((r && r.message)||r||"");
    if(/fetch|network|Failed to fetch|NetworkError/i.test(txt)) toastErr(t("errNet"));
  });
}
function setLang(l){ S.lang=l; document.documentElement.lang=l; document.documentElement.dir=(l==="ar"?"rtl":"ltr"); try{ localStorage.setItem("entapp_lang",l); }catch(e){} persist(); render(); }
function setTheme(th){ S.theme=th; document.documentElement.setAttribute("data-theme",th); applySettings(); persist(); render(); }
function catLabel(c){ return t("cats")[c]||c; }
/* Four clean operations (Kids removed). Sub-category ids kept for data mapping. */
const OPS=[
  {id:"daytime", cats:["mAdult"]},
  {id:"dayevents", cats:["mEvents"]},
  {id:"evening", cats:["eBefore","eLive","eShow","eAfter"]},
  {id:"special", cats:["eParty"]}
];
function opLabel(op){ return {daytime:t("opDaytime"),dayevents:t("opDayEvents"),evening:t("opEvening"),special:t("opSpecial")}[op]||op; }
function opOf(cat){ const o=OPS.find(o=>o.cats.includes(cat)); return o?o.id:"daytime"; }
function allCats(){ return [...new Set(OPS.flatMap(o=>o.cats))]; }
/* map ANY old/new category to one of the four operations' sub-categories */
function normCat(a){
  const c=a.category||"";
  if(allCats().includes(c)) return c;
  const legacy={
    // old morning/afternoon regular -> daytime activities
    morning:"mAdult", afternoon:"mAdult", mAdult:"mAdult", mKids:"mAdult", mTeen:"mAdult",
    // events -> day events
    mEvents:"mEvents", theme:"mEvents", kids:"mAdult",
    // evening buckets
    eLive:"eLive", eBefore:"eBefore", eShow:"eShow", eAfter:"eAfter", eKidsStage:"eShow",
    eParty:"eParty",
    evening: a.highlight?"eShow":"eLive"
  };
  return legacy[c]|| (a.highlight?"eShow":"mAdult");
}
function actOp(a){ return opOf(normCat(a)); }
const CAT_ORDER=["mAdult","mEvents","eBefore","eLive","eShow","eAfter","eParty"];
function catImage(cat){
  return {mAdult:IMG.yoga,mEvents:IMG.foam,eBefore:IMG.neon,eLive:IMG.show,eShow:IMG.dance,eAfter:IMG.neon,eParty:IMG.foam}[cat]||IMG.show;
}
/* operation cover images */
function opImage(op){
  return {daytime:IMG.yoga,dayevents:IMG.foam,evening:IMG.show,special:IMG.neon}[op]||IMG.show;
}
const TASK_TYPES=["come","leave","activity","feedback","collect"];
const TASK_ICON={come:"pin",leave:"exit",activity:"flag",feedback:"star",collect:"users"};
const ICONS={
menu:'<path d="M4 7h16M4 12h16M4 17h10"/>',
home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v11h14V10"/><path d="M10 21v-6h4v6"/>',
calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
ticket:'<path d="M4 8a2 2 0 012-2h12a2 2 0 012 2v1.5a2.5 2.5 0 000 5V16a2 2 0 01-2 2H6a2 2 0 01-2-2v-1.5a2.5 2.5 0 000-5z"/><path d="M14 6v12" stroke-dasharray="2.5 2.5"/>',
chat:'<path d="M21 11.5a8 8 0 01-8 8H5.5L3 22V11.5a8 8 0 018-8h2a8 8 0 018 8z"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4.5 21c1.4-3.8 4.6-5.5 7.5-5.5s6.1 1.7 7.5 5.5"/>',
users:'<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20c1-3.4 3.9-5 6.5-5s5.5 1.6 6.5 5"/><path d="M16 5.6a3.5 3.5 0 010 5.8M18.5 15.4c1.6.8 2.8 2.3 3.2 4.6"/>',
bell:'<path d="M6 9.5a6 6 0 0112 0c0 4.6 2 5.8 2 5.8H4s2-1.2 2-5.8z"/><path d="M10 19.5a2.2 2.2 0 004 0"/>',
belloff:'<path d="M6 9.5a6 6 0 0112 0c0 4.6 2 5.8 2 5.8H4s2-1.2 2-5.8z"/><path d="M10 19.5a2.2 2.2 0 004 0"/><path d="M3 3l18 18" stroke-width="2"/>',
moon:'<path d="M20.5 13.5A8.5 8.5 0 1110.5 3.5a7 7 0 0010 10z"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8"/>',
cloud:'<path d="M7 18h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 18z"/>',
rain:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M9 18l-1 3M13 18l-1 3M17 18l-1 3"/>',
snow:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M9 19h.01M13 19h.01M11 21h.01M15 21h.01"/>',
storm:'<path d="M7 15h9a4 4 0 000-8 5.5 5.5 0 00-10.6 1.4A3.5 3.5 0 006.5 15z"/><path d="M12 17l-2 3.5h3L11 24"/>',
globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.6 3 14.4 0 18M12 3c-3 3.6-3 14.4 0 18"/>',
power:'<path d="M12 3v8"/><path d="M6.3 6.6a8 8 0 1011.4 0"/>',
back:'<path d="M15 5l-7 7 7 7"/>',
send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
check:'<path d="M5 13l4 4L19 7"/>',
bus:'<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M3 11h18"/><circle cx="7.5" cy="17" r="1.6"/><circle cx="16.5" cy="17" r="1.6"/><path d="M6 17H5m14 0h-1"/>',
clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
pin:'<path d="M12 21.5s7-6.4 7-11.3a7 7 0 10-14 0c0 4.9 7 11.3 7 11.3z"/><circle cx="12" cy="10" r="2.5"/>',
star:'<path d="M12 3l2.7 5.7 6.3.8-4.6 4.3 1.2 6.2L12 17l-5.6 3 1.2-6.2L3 9.5l6.3-.8z"/>',
heart:'<path d="M12 20.5S3.8 15.5 2.5 10.7A5 5 0 0112 7a5 5 0 019.5 3.7C20.2 15.5 12 20.5 12 20.5z"/>',
pen:'<path d="M4 20l4.5-1L19.5 8a2.1 2.1 0 00-3-3L5.5 16 4 20z"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
trash:'<path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13"/>',
close:'<path d="M6 6l12 12M18 6L6 18"/>',
download:'<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
sparkle:'<path d="M12 2.5l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/><path d="M19 15.5l.9 2.6 2.6.9-2.6.9-.9 2.6-.9-2.6-2.6-.9 2.6-.9z"/>',
palette:'<path d="M12 21a9 9 0 110-18 9 9 0 019 8.6c0 2-1.4 2.6-2.9 2.6h-2A2.6 2.6 0 0013.5 17c0 1.4.6 4-1.5 4z"/><circle cx="8" cy="9" r="1.1"/><circle cx="12.5" cy="6.8" r="1.1"/><circle cx="16.5" cy="9.5" r="1.1"/>',
grid:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
clipboard:'<rect x="6" y="4.5" width="12" height="17" rx="2"/><path d="M9 4.5a3 3 0 016 0M9 11h6M9 15h6"/>',
flag:'<path d="M5.5 21V4"/><path d="M5.5 4.5h11.5l-2.5 4 2.5 4H5.5"/>',
exit:'<path d="M13.5 4.5H19v15h-5.5"/><path d="M10 8.5L6.5 12l3.5 3.5M6.5 12H15"/>',
gift:'<path d="M20 12.5V21H4v-8.5M2.5 7.5h19v5h-19zM12 7.5V21"/><path d="M12 7.5c-3 0-4.7-2.7-3-4.3C10.6 1.7 12 4.5 12 7.5c0-3 1.4-5.8 3-4.3 1.7 1.6 0 4.3-3 4.3z"/>',
music:'<path d="M9 18.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0zM20 16.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/><path d="M9 18.5V5.5l11-2v13"/>',
lock:'<rect x="5" y="11" width="14" height="9.5" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0z"/><path d="M7 6H4.2A2.8 2.8 0 007 9.8M17 6h2.8A2.8 2.8 0 0117 9.8"/>',
door:'<rect x="5" y="3" width="14" height="18" rx="1.5"/><circle cx="15" cy="12" r="1" fill="currentColor" stroke="none"/>',
key:'<circle cx="8" cy="14.5" r="4"/><path d="M11 11.5L20 3M16 7l2.5 2.5M13.5 9.5L16 12"/>'
};
const BRAND={
Instagram:'<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17.2" cy="6.8" r="1.2" fill="currentColor"/>',
TikTok:'<path fill="currentColor" d="M16.5 3c.4 2.3 1.8 3.8 4 4.1v3c-1.6 0-3-.5-4-1.3v6.7a5.75 5.75 0 11-5.75-5.75c.26 0 .5.02.75.06v3.1a2.7 2.7 0 102 2.6V3h3z"/>',
Facebook:'<path fill="currentColor" d="M14 8.5h3.2V5H14a4.2 4.2 0 00-4.2 4.2v2.3H7v3.5h2.8V22h3.6v-7h3l.6-3.5h-3.6V9.4c0-.5.3-.9.6-.9z"/>',
YouTube:'<rect x="2.5" y="6" width="19" height="12.5" rx="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path fill="currentColor" d="M10.3 9.4l5 2.85-5 2.85z"/>',
WhatsApp:'<path fill="currentColor" d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1112 20.2zm4.6-6.1c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.7.8-.8 1-.1.2-.3.2-.5.1a6.7 6.7 0 01-3.3-2.9c-.2-.4 0-.5.1-.7l.4-.5c.1-.2.1-.3.2-.5s0-.4 0-.5c-.1-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.6 1.1 2.8c.1.2 1.9 3 4.7 4.1.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.6-.3z"/>'
};
function ic(name,size=20){ return `<svg class="ic-s" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]||ICONS.star}</svg>`; }
function mi(name){ return `<span class="mi">${ic(name,13)}</span>`; }
function brandIc(name){ return `<svg class="ic-s" width="17" height="17" viewBox="0 0 24 24" aria-hidden="true">${BRAND[name]||""}</svg>`; }
function rankBadge(i){ return `<span class="rankb r${i<3?i:"x"}">${i+1}</span>`; }
function taskTypeLabel(ty){return {come:t("ttCome"),leave:t("ttLeave"),activity:t("ttActivity"),feedback:t("ttFeedback"),collect:t("ttCollect")}[ty]||ty;}
function canSeeGuests(a){
  if(!S.session) return false;
  if(S.session.role==="manager") return true;
  if(S.session.role!=="staff") return false;
  const e=(a.entertainer||"").toLowerCase().trim();
  if(!e) return false;
  if(e==="team"||e==="all team") return true;
  const u=(S.session.username||"").toLowerCase(), d=(S.session.name||"").toLowerCase();
  return (u&&e.includes(u))||(d&&e.includes(d));
}
function guestDaysHere(acc){
  if(!acc || !acc.created_at) return null;
  const d=Math.floor((Date.now()-Date.parse(acc.created_at))/864e5);
  return isNaN(d)?null:Math.max(0,d);
}
function guestActivities(room){
  return S.bookings.filter(b=>String(b.room)===String(room))
    .map(b=>{ const a=S.activities.find(x=>x.id===b.activity_id); return a?a.name:null; })
    .filter(Boolean);
}
function guestFullInfo(room){
  const acc=S.accounts.find(a=>String(a.room)===String(room) || String(a.username||"")===String(room));
  if(!acc) return null;
  return {room:acc.room,name:acc.name,username:acc.username||acc.room,phone:acc.phone||"",
    nationality:acc.nationality||"",arrival:acc.arrival||"",departure:acc.departure||"",
    days:guestDaysHere(acc),activities:guestActivities(acc.room),
    tickets:S.orders.filter(o=>String(o.room)===String(acc.room)).reduce((n,o)=>n+(+o.qty||0),0),
    requests:S.requests.filter(r=>String(r.room)===String(acc.room)).length};
}
function teamMemberList(){
  const out=[], seen=new Set();
  S.profiles.forEach(p=>{
    const nm=String(p.name||"").trim();
    if(nm && !seen.has(nm.toLowerCase())){ seen.add(nm.toLowerCase()); out.push({name:nm,photo:p.photo||""}); }
  });
  S.users.filter(u=>u.role==="staff").forEach(u=>{
    const nm=String(u.display_name||u.username||"").trim();
    if(nm && !seen.has(nm.toLowerCase())){ seen.add(nm.toLowerCase()); out.push({name:nm,photo:""}); }
  });
  return out;
}
function staffStats(username){
  const mine=S.tasks.filter(x=>x.assigned_to===username);
  const done=mine.filter(x=>x.status==="done"&&!x.was_still).length;
  const late=mine.filter(x=>x.status==="done"&&x.was_still).length;
  const cant=mine.filter(x=>x.status==="cant").length;
  const open=mine.filter(x=>["open","accepted","still"].includes(x.status)).length;
  return {done,late,cant,open,points:done*10+late*6};
}
function rankingRows(){
  return S.users.filter(u=>u.role==="staff")
    .map(u=>({u,...staffStats(u.username)}))
    .sort((a,b)=>b.points-a.points);
}
/* ================= RENDER ================= */
/* ================= SCREEN HISTORY (back / forward) =================
   Records every screen change automatically, so Back and Forward work
   everywhere without having to touch each button. */
let NAV_HIST=[], NAV_IDX=-1, NAV_LOCK=false;
function navSnapshot(){
  return JSON.stringify({tab:S.tab, sub:S.sub, op:S.op, cat:S.cat,
    chatRoom:S.chatRoom, planDay:S.planDay, day:S.day});
}
function navRecord(){
  if(NAV_LOCK) return;
  const snap=navSnapshot();
  if(NAV_IDX>=0 && NAV_HIST[NAV_IDX]===snap) return;   // nothing changed
  NAV_HIST=NAV_HIST.slice(0, NAV_IDX+1);               // drop any forward branch
  NAV_HIST.push(snap);
  if(NAV_HIST.length>60) NAV_HIST.shift();             // keep memory small
  NAV_IDX=NAV_HIST.length-1;
}
function navApply(snap){
  let o; try{ o=JSON.parse(snap); }catch(e){ return; }
  S.tab=o.tab; S.op=o.op; S.cat=o.cat; S.chatRoom=o.chatRoom;
  if(o.sub) S.sub=o.sub;
  S.planDay=o.planDay;
  if(typeof o.day==="number") S.day=o.day;
}
function canNavBack(){ return NAV_IDX>0; }
function canNavForward(){ return NAV_IDX < NAV_HIST.length-1; }
function navBack(){
  if(!canNavBack()) return;
  NAV_IDX--; NAV_LOCK=true; navApply(NAV_HIST[NAV_IDX]); render(); NAV_LOCK=false;
}
function navForward(){
  if(!canNavForward()) return;
  NAV_IDX++; NAV_LOCK=true; navApply(NAV_HIST[NAV_IDX]); render(); NAV_LOCK=false;
}
function navReset(){ NAV_HIST=[]; NAV_IDX=-1; }
function render(){
  const app=$("#app");
  document.documentElement.setAttribute("data-approle", S.session?S.session.role:"none");
  if(S.loadError){ app.innerHTML=errorView(); const r=$("#btn-retry"); if(r) r.onclick=()=>location.reload(); return; }
  if(!S.session){
    const __publicFirst639 = window.__PUBLIC_EXPLORE_EXITED_V639!==true;
    if((window.__PUBLIC_EXPLORE_V637 || __publicFirst639) && typeof window.visitorExploreView637==="function"){
      window.__PUBLIC_EXPLORE_V637=true;
      document.documentElement.setAttribute("data-approle","visitor");
      app.innerHTML=window.visitorExploreView637();
      if(typeof window.wireVisitorExplore637==="function") window.wireVisitorExplore637();
      return;
    }
    app.innerHTML=loginView(); wireLogin();
    // Connected but the database sent back nothing -> tell the user plainly
    if(REMOTE && !S.loadError && S.rooms.length===0 && S.users.length===0 && !window.__noDataWarned){
      window.__noDataWarned=true;
      setTimeout(()=>{ try{ toastErr(t("noDataTitle")); }catch(e){} }, 400);
      console.warn("Database reachable but returned no rooms and no users — check the access policies (run repair-access.sql).");
    }
    return;
  }
  const r=S.session.role;
  // V5.3: migrate Manager sessions that were accidentally saved on Program by the auth repair.
  if(r==="manager" && (!S.tab || S.tab==="home")){ S.tab="dash"; S.sub.dash="overview"; }
  let html="";
  try{
    html=(r==="guest" ? guestView() : r==="staff" ? staffView() : managerView());
  }catch(e){
    console.error("view render failed",e);
    // A broken landing widget must never make a valid login look like an authentication failure.
    try{
      if(r==="manager"){ S.tab="dash"; S.sub.dash="overview"; html=managerView(); }
      else if(r==="staff"){ S.tab="today"; html=staffView(); }
      else html=guestView();
    }catch(e2){
      console.error("fallback view failed",e2);
      html=`<div class="screen fadein"><div class="empty"><div class="big">!</div><b>Signed in, but this screen could not open.</b><br><span class="mini">A screen component failed to load. Please retry or open safe home.</span><button class="btn" id="safe-home" style="margin-top:18px">Open safe home</button></div></div>`;
    }
  }
  app.innerHTML=html;
  const sh=$("#safe-home"); if(sh) sh.onclick=()=>{ S.tab=r==="manager"?"dash":r==="staff"?"today":"home"; render(); };
  navRecord();
  wireCommon();
}
function errorView(){
  return `<div class="screen fadein" style="display:flex;flex-direction:column;justify-content:center">
    <div class="empty"><div class="big">${ic("globe",30)}</div>
      Could not reach the database.<br>Please check your internet connection.
      <button class="btn" id="btn-retry" style="margin-top:18px">${ic("back",16)}</button>
    </div></div>`;
}

