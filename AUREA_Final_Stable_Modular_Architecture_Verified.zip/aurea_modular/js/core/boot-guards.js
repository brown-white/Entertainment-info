/* ---------------- boot ---------------- */
function safeToRender(){
  if(document.querySelector(".modal-bg")) return false;
  const a=document.activeElement;
  return !(a && ["INPUT","TEXTAREA","SELECT"].includes(a.tagName));
}
