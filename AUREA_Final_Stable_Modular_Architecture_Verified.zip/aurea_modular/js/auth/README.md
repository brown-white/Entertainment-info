# Authentication
`login.js` contains the current login/authentication flow extracted from the original core without behavior changes.

Security modernization (for example moving staff authentication to Supabase Auth) is a separate high-risk phase and must not be mixed with structural extraction.
