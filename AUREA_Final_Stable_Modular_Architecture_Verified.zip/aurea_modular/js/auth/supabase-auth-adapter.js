/* AUREA Phase 7 — Supabase Auth compatibility adapter
   Default state: DISABLED because CONFIG.AUTH_MODE is "legacy".
   No service-role/admin secret belongs in this browser file. */
(function(){
  'use strict';
  if(window.AUREA_SUPABASE_AUTH)return;

  const STORE='aurea_supabase_auth_v1';
  let session=null;

  function enabled(){
    return !!(typeof CONFIG!=='undefined' && CONFIG.AUTH_MODE==='supabase_staff' &&
      CONFIG.SUPABASE_URL && CONFIG.SUPABASE_ANON_KEY);
  }

  function load(){
    if(!enabled())return null;
    try{
      const raw=localStorage.getItem(STORE);
      session=raw?JSON.parse(raw):null;
    }catch(_){session=null;}
    return session;
  }

  function save(next){
    session=next||null;
    try{
      if(session)localStorage.setItem(STORE,JSON.stringify(session));
      else localStorage.removeItem(STORE);
    }catch(_){}
    return session;
  }

  function accessToken(){
    if(!enabled())return null;
    if(!session)load();
    return session&&session.access_token||null;
  }

  function authHeaders(token){
    return {
      'apikey':CONFIG.SUPABASE_ANON_KEY,
      'Authorization':'Bearer '+(token||CONFIG.SUPABASE_ANON_KEY),
      'Content-Type':'application/json'
    };
  }

  async function parseResponse(res){
    const text=await res.text();
    let body=null;
    try{body=text?JSON.parse(text):null;}catch(_){body={message:text};}
    if(!res.ok){
      const err=new Error((body&&(body.msg||body.message||body.error_description||body.error))||('Supabase Auth '+res.status));
      err.status=res.status;err.body=body;throw err;
    }
    return body;
  }

  async function signInWithPassword(email,password){
    if(!enabled())throw new Error('Supabase staff auth is disabled');
    const res=await fetch(CONFIG.SUPABASE_URL+'/auth/v1/token?grant_type=password',{
      method:'POST',
      headers:authHeaders(),
      body:JSON.stringify({email:String(email||'').trim(),password:String(password||'')})
    });
    const data=await parseResponse(res);
    save(data);
    return data;
  }

  async function getUser(token){
    if(!enabled())return null;
    const jwt=token||accessToken();
    if(!jwt)return null;
    const res=await fetch(CONFIG.SUPABASE_URL+'/auth/v1/user',{
      headers:authHeaders(jwt)
    });
    return parseResponse(res);
  }

  async function refresh(){
    if(!enabled())return null;
    if(!session)load();
    if(!(session&&session.refresh_token))return null;
    const res=await fetch(CONFIG.SUPABASE_URL+'/auth/v1/token?grant_type=refresh_token',{
      method:'POST',
      headers:authHeaders(),
      body:JSON.stringify({refresh_token:session.refresh_token})
    });
    const refreshed=save(await parseResponse(res));
    if(window.AUREA_SESSION_LIFECYCLE){
      try{ AUREA_SESSION_LIFECYCLE.observeCurrent("auth-token-refresh",{provider:"supabase"}); }catch(_){}
    }
    return refreshed;
  }

  async function signOut(){
    if(!enabled()){save(null);return;}
    const jwt=accessToken();
    save(null); /* local logout is immediate even if the network is unavailable */
    if(jwt)await fetch(CONFIG.SUPABASE_URL+'/auth/v1/logout',{
      method:'POST',
      headers:authHeaders(jwt)
    });
  }

  function clear(){save(null);}

  load();
  window.AUREA_SUPABASE_AUTH={
    version:'phase7',
    enabled,load,accessToken,signInWithPassword,getUser,refresh,signOut,clear,
    session:()=>session
  };
})();