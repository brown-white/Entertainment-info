/* AUREA Phase 11 — session lifecycle orchestration boundary
   Active mode `legacy_observe` is intentionally non-destructive:
   it records session transitions but does not reload data, rebuild realtime,
   alter authentication, or make network requests. */
(function(){
  'use strict';
  if(window.AUREA_SESSION_LIFECYCLE)return;

  let seq=0;
  let last=null;
  const listeners=new Set();

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.SESSION_LIFECYCLE_MODE)||"legacy_observe";
  }

  function snapshot(session){
    const s=session||null;
    if(!s)return {authenticated:false,role:null,userId:null,accountId:null,username:null,room:null};
    return {
      authenticated:true,
      role:s.role||null,
      userId:s.userId==null?null:String(s.userId),
      accountId:s.accountId==null?null:String(s.accountId),
      username:s.username==null?null:String(s.username),
      room:s.room==null?null:String(s.room)
    };
  }

  function sameIdentity(a,b){
    if(!a||!b)return false;
    return a.authenticated===b.authenticated &&
      a.role===b.role &&
      a.userId===b.userId &&
      a.accountId===b.accountId &&
      a.username===b.username &&
      a.room===b.room;
  }

  function assertSafeMode(){
    if(mode()!=="legacy_observe"){
      throw new Error(
        "AUREA Phase 11 safety guard: active session orchestration is prepared but not enabled. "+
        "Keep SESSION_LIFECYCLE_MODE=legacy_observe until Auth, RLS, role-aware loading and scoped realtime pass staging tests."
      );
    }
  }

  function emit(reason,previous,next,meta){
    const evt=Object.freeze({
      id:++seq,
      reason:String(reason||"unknown"),
      previous,
      next,
      changed:!sameIdentity(previous,next),
      meta:meta||null,
      at:Date.now()
    });
    last=evt;

    /* Phase 12: identity changes pass through the state-isolation boundary.
       In the active legacy_transient mode this only clears transient UI residue. */
    if(window.AUREA_STATE_ISOLATION){
      try{ AUREA_STATE_ISOLATION.handleTransition(evt); }
      catch(e){ console.warn("state isolation transition skipped",e&&e.message); }
    }

    for(const fn of [...listeners]){
      try{fn(evt);}catch(e){console.warn("session lifecycle listener failed",e);}
    }
    return evt;
  }

  function transition(reason,previousSession,nextSession,meta){
    assertSafeMode();
    return emit(reason,snapshot(previousSession),snapshot(nextSession),meta);
  }

  function observeCurrent(reason,meta){
    assertSafeMode();
    const previous=last?last.next:snapshot(null);
    const next=snapshot(typeof S!=="undefined"?S.session:null);
    return emit(reason,previous,next,meta);
  }

  function onChange(fn){
    if(typeof fn!=="function")return ()=>{};
    listeners.add(fn);
    return ()=>listeners.delete(fn);
  }

  function status(){
    return {
      version:"phase12",
      mode:mode(),
      last:last,
      listenerCount:listeners.size
    };
  }

  /* Future active orchestration will live behind this method.
     In Phase 11 it intentionally does not touch data or realtime services. */
  async function reconcile(){
    assertSafeMode();
    return {ok:true,mode:mode(),action:"observe-only"};
  }

  window.AUREA_SESSION_LIFECYCLE={
    version:"phase12",
    mode,snapshot,sameIdentity,transition,observeCurrent,onChange,status,reconcile,assertSafeMode
  };
})();