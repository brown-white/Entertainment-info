/* AUREA Phase 12 — sensitive-state isolation boundary
   Active mode `legacy_transient` clears only transient UI/session residue.
   Database-backed arrays remain intact because legacy login still depends on
   app_users, guest_accounts and rooms being present before authentication. */
(function(){
  'use strict';
  if(window.AUREA_STATE_ISOLATION)return;

  const TRANSIENT_DEFAULTS=Object.freeze({
    chatRoom:null,
    aiChat:[],
    crmQuery:"",
    drawerOpen:null,
    pb:null,
    assignDay:null,
    openDay:{},
    chatSel:null,
    exportMonth:null,
    exportDay:"",
    exportSlot:"",
    attMonth:null,
    op:null,
    cat:null
  });

  const DATA_CLASSIFICATION=Object.freeze({
    shared:[
      "activities","tickets","notes","profiles","buses","quizzes","photos"
    ],
    guestSensitive:[
      "bookings","orders","accounts","messages","requests","quizReplies","rooms"
    ],
    teamSensitive:[
      "users","attendance","feedback","staffAtt","staffReqs","tasks"
    ]
  });

  /* Future role retention map. Not active in Phase 12. */
  const FUTURE_ALLOWED=Object.freeze({
    anonymous:["activities","tickets","notes","profiles","buses","quizzes","photos"],
    guest:["activities","tickets","notes","profiles","buses","quizzes","photos",
           "bookings","orders","accounts","messages","requests","quizReplies","rooms"],
    staff:["activities","tickets","notes","profiles","buses","quizzes","photos",
           "bookings","orders","messages","requests","tasks","attendance","feedback",
           "staffAtt","staffReqs","users"],
    manager:[
      "activities","bookings","users","tickets","orders","rooms","accounts","messages",
      "requests","tasks","notes","attendance","feedback","profiles","buses","quizzes",
      "quizReplies","staffAtt","photos","staffReqs"
    ]
  });

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.STATE_ISOLATION_MODE)||"legacy_transient";
  }

  function cloneDefault(v){
    if(Array.isArray(v))return [];
    if(v&&typeof v==="object")return {...v};
    return v;
  }

  function clearTransient(){
    if(typeof S==="undefined")return [];
    const cleared=[];
    for(const [key,value] of Object.entries(TRANSIENT_DEFAULTS)){
      if(Object.prototype.hasOwnProperty.call(S,key)){
        S[key]=cloneDefault(value);
        cleared.push(key);
      }
    }
    return cleared;
  }

  function assertSensitiveClearAllowed(){
    if(mode()!=="scoped_active"){
      throw new Error(
        "AUREA Phase 12 safety guard: sensitive database-state clearing is blocked while legacy login/data loading is active. "+
        "Keep STATE_ISOLATION_MODE=legacy_transient until Supabase Auth and scoped loading are proven in staging."
      );
    }
  }

  function clearDataKeys(keys){
    assertSensitiveClearAllowed();
    if(typeof S==="undefined")return [];
    const cleared=[];
    for(const key of keys||[]){
      if(Array.isArray(S[key])){
        S[key]=[];
        cleared.push(key);
      }
    }
    return cleared;
  }

  function roleKey(snapshot){
    if(!(snapshot&&snapshot.authenticated))return "anonymous";
    return snapshot.role||"anonymous";
  }

  function sensitiveKeysNotAllowed(snapshot){
    const allowed=new Set(FUTURE_ALLOWED[roleKey(snapshot)]||FUTURE_ALLOWED.anonymous);
    const all=[
      ...DATA_CLASSIFICATION.shared,
      ...DATA_CLASSIFICATION.guestSensitive,
      ...DATA_CLASSIFICATION.teamSensitive
    ];
    return [...new Set(all)].filter(k=>!allowed.has(k));
  }

  function handleTransition(evt){
    const result={mode:mode(),transientCleared:[],sensitiveCleared:[]};
    if(!evt)return result;

    /* Safe today: clear UI residue whenever identity changes or logout/invalid occurs. */
    if(evt.changed || evt.reason==="logout" || evt.reason==="session-invalid"){
      result.transientCleared=clearTransient();
    }

    /* Deliberately do NOT clear database arrays in legacy mode. */
    if(mode()==="scoped_active"){
      result.sensitiveCleared=clearDataKeys(sensitiveKeysNotAllowed(evt.next));
    }
    return result;
  }

  function status(){
    return {
      version:"phase12",
      mode:mode(),
      classification:JSON.parse(JSON.stringify(DATA_CLASSIFICATION)),
      futureAllowed:JSON.parse(JSON.stringify(FUTURE_ALLOWED))
    };
  }

  window.AUREA_STATE_ISOLATION={
    version:"phase12",
    mode,clearTransient,handleTransition,status,
    sensitiveKeysNotAllowed,clearDataKeys,assertSensitiveClearAllowed
  };
})();