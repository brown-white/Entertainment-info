/* AUREA Phase 6 — canonical application authorization boundary
   This is APPLICATION-LAYER authorization, not database RLS.
   It preserves current role behavior while giving future code one source of truth. */
(function(){
  'use strict';
  if(window.AUREA_PERMISSIONS)return;

  const RULES=Object.freeze({
    'program.read':        ['guest','staff','manager'],
    'program.manage':      ['manager'],
    'activity.book':       ['guest'],
    'booking.cancelOwn':   ['guest'],
    'booking.manage':      ['manager'],
    'ticket.order':        ['guest'],
    'ticket.cancelOwn':    ['guest'],
    'ticket.collect':      ['staff','manager'],
    'ticket.manage':       ['manager'],
    'attendance.readOwn':  ['staff','manager'],
    'attendance.manage':   ['staff','manager'],
    'planner.read':        ['staff','manager'],
    'planner.manage':      ['manager'],
    'team.read':           ['staff','manager'],
    'team.manage':         ['manager'],
    'guest.readSelf':      ['guest'],
    'guest.manage':        ['manager'],
    'chat.use':            ['guest','staff','manager'],
    'feedback.writeOwn':   ['staff','manager'],
    'feedback.manage':     ['manager'],
    'requests.create':     ['guest'],
    'requests.manage':     ['staff','manager'],
    'settings.manage':     ['manager'],
    'exports.use':         ['manager'],
    'ai.manager':          ['manager']
  });

  function role(){return S.session&&S.session.role||null;}
  function can(action,context){
    const r=role(), allowed=RULES[action]||[];
    if(!r||!allowed.includes(r))return false;

    /* Ownership constraints for guest-scoped mutations. */
    if(r==='guest' && context){
      const room=String(context.room==null?'':context.room);
      if(room && room!==String(S.session.room||''))return false;
      const accountId=context.accountId;
      if(accountId!=null && S.session.accountId!=null &&
         String(accountId)!==String(S.session.accountId))return false;
    }
    return true;
  }

  function requirePermission(action,context){
    if(can(action,context))return true;
    const err=new Error('AUREA permission denied: '+action);
    err.code='AUREA_PERMISSION_DENIED';
    err.action=action;
    throw err;
  }

  function isOwnGuestRow(row,roomField='room'){
    if(!(S.session&&S.session.role==='guest')||!row)return false;
    if(window.AUREA_GUEST_LIFECYCLE &&
       typeof window.AUREA_GUEST_LIFECYCLE.rowBelongs==='function'){
      const acc=(S.accounts||[]).find(a=>String(a.id)===String(S.session.accountId));
      if(acc)return window.AUREA_GUEST_LIFECYCLE.rowBelongs(row,acc,roomField);
    }
    return String(row[roomField]||'')===String(S.session.room||'');
  }

  function matrix(){return Object.fromEntries(
    Object.entries(RULES).map(([k,v])=>[k,v.slice()])
  );}

  window.AUREA_PERMISSIONS={
    version:'phase6',
    can,require:requirePermission,isOwnGuestRow,matrix,
    role
  };
})();