/* ============ NOTIFICATIONS (sound + vibrate + banner) ============ */
let AUDIO_CTX=null;
function notifSoundOn(){ return localStorage.getItem("ent_notif")!=="off"; }
function playChime(){
  if(!notifSoundOn()) return;
  try{
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    const ctx=AUDIO_CTX; if(ctx.state==="suspended") ctx.resume();
    const now=ctx.currentTime;
    // two-note soft "ding-dong" using sine tones
    [[880,0],[1174,0.14]].forEach(([f,dt])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.type="sine"; o.frequency.value=f;
      o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0,now+dt);
      g.gain.linearRampToValueAtTime(0.35,now+dt+0.02);
      g.gain.exponentialRampToValueAtTime(0.001,now+dt+0.42);
      o.start(now+dt); o.stop(now+dt+0.45);
    });
  }catch(e){}
}
function vibrate(){ if(notifSoundOn() && navigator.vibrate){ try{ navigator.vibrate([120,60,120]); }catch(e){} } }
let SW_REG=null;
let SW_READY=false;
/* Registers the REAL static service worker file (sw.js) that sits next to index.html.
   Relative path keeps the scope correct on GitHub Pages sub-paths. */
/* ===================== SERVICE WORKER =====================
   SAFE MODE: set USE_SERVICE_WORKER to true again only once sw.js
   is confirmed uploaded next to index.html and the app logs in fine.
   While false, this actively REMOVES any old/stuck service worker and
   clears its caches, so a bad cached copy can never keep the app broken. */
const APP_BUILD = "2026.09.07-aurea-stability-v6.2";   // shown in the menu, so an upload can be checked at a glance
const USE_SERVICE_WORKER = false;

function cleanupServiceWorkers(){
  if(!("serviceWorker" in navigator)) return;
  try{
    navigator.serviceWorker.getRegistrations().then(regs=>{
      regs.forEach(r=>{ r.unregister().catch(()=>{}); });
      if(regs.length){ console.warn("removed", regs.length, "old service worker(s)"); }
    }).catch(()=>{});
    if(window.caches && caches.keys){
      caches.keys().then(keys=>keys.forEach(k=>caches.delete(k).catch(()=>{}))).catch(()=>{});
    }
  }catch(e){ console.warn("sw cleanup:", e && e.message); }
}

function registerServiceWorker(){
  if(!("serviceWorker" in navigator)) return;
  if(!USE_SERVICE_WORKER){ cleanupServiceWorkers(); return; }
  try{
    navigator.serviceWorker.register("sw.js").then(reg=>{
      SW_REG=reg; SW_READY=true;
      if(reg.waiting) reg.waiting.postMessage({kind:"skip-waiting"});
      reg.addEventListener&&reg.addEventListener("updatefound",()=>{
        const nw=reg.installing;
        if(nw) nw.addEventListener("statechange",()=>{
          if(nw.state==="installed" && navigator.serviceWorker.controller) toastOk(t("updateReady"));
        });
      });
    }).catch(err=>{ console.warn("service worker not registered:", err && err.message); });

    navigator.serviceWorker.addEventListener("message", ev=>{
      const d=ev.data||{};
      if(d.kind==="notification-click"){ routeFromNotification(d.type); }
      if(d.kind==="resubscribe"){ subscribeForPush(); }
    });
  }catch(e){ console.warn("service worker error:", e && e.message); }
}
/* Opens the right page when a notification is tapped */
const NOTIF_ROUTE={
  booking:"bookings", booking_confirmed:"tickets", booking_cancelled:"tickets",
  activity_soon:"program", announcement:"home", message:"chat", chat:"chat",
  ticket:"tickets", request:"guests", task:"tasks", assignment:"tasks",
  attendance:"workday", feedback:"guests", occupancy:"dash"
};
function routeFromNotification(type){
  if(!S.session) return;
  const tab=NOTIF_ROUTE[type]; if(!tab) return;
  const allowed=navItems(S.session.role).map(x=>x[0]);
  if(allowed.includes(tab)){ S.tab=tab; S.op=null; S.cat=null; persist(); render(); }
}
/* If the app was opened fresh from a notification (?open=tab) */
function applyOpenParam(){
  try{
    const m=String(location.search||"").match(/[?&]open=([a-z]+)/i);
    if(!m || !S.session) return;
    const tab=m[1];
    const allowed=navItems(S.session.role).map(x=>x[0]);
    if(allowed.includes(tab)){ S.tab=tab; }
    history.replaceState({}, "", location.pathname);
  }catch(e){}
}
function showBanner(title,body){
  if(!notifSoundOn()) return;
  try{
    if("Notification" in window && Notification.permission==="granted"){
      // Prefer the service worker — its notifications persist even when the tab is in the background.
      if(SW_REG && SW_REG.showNotification){
        SW_REG.showNotification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true,vibrate:[120,60,120]});
      } else {
        const n=new Notification(title,{body:body||"",tag:"ent-"+Date.now(),renotify:true});
        setTimeout(()=>{ try{ n.close(); }catch(e){} },6000);
      }
    }
  }catch(e){}
}
function notify(title,body){ playChime(); vibrate(); showBanner(title,body); toast(title); }
/* Public push key — already set. Nothing to edit. */
const PUSH_PUBLIC_KEY="BBVFLaJhNy8JyyYiGPGOI7hFk9GVmgzWxo7ZSy5_Uo44xTg91TlQAppm8Y96xnmUHcr-4u81w4YxVrtZqqCSML8";
function urlB64ToUint8(base64){
  const pad="=".repeat((4-base64.length%4)%4);
  const b=(base64+pad).replace(/-/g,"+").replace(/_/g,"/");
  const raw=atob(b); const out=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++) out[i]=raw.charCodeAt(i);
  return out;
}
async function subscribeForPush(){
  try{
    if(!("serviceWorker" in navigator) || !("PushManager" in window)) return;
    if(!PUSH_PUBLIC_KEY || PUSH_PUBLIC_KEY.indexOf("__")===0) return; // key not set → skip silently
    const reg = SW_REG || await navigator.serviceWorker.ready;
    if(!reg || !reg.pushManager) return;
    let sub = await reg.pushManager.getSubscription();
    if(!sub){
      sub = await reg.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:urlB64ToUint8(PUSH_PUBLIC_KEY)});
    }
    const j = sub.toJSON();
    const sess = S.session||{};
    const row = {
      endpoint: j.endpoint,
      p256dh: j.keys && j.keys.p256dh,
      auth: j.keys && j.keys.auth,
      role: sess.role||"",
      username: sess.username||"",
      room: sess.role==="guest" ? String(sess.room||"") : ""
    };
    // upsert into push_subscriptions (endpoint is primary key)
    if(REMOTE){
      await sb("push_subscriptions?on_conflict=endpoint",{
        method:"POST",
        headers:{ "Prefer":"resolution=merge-duplicates" },
        body: JSON.stringify(row)
      });
    }
  }catch(e){}
}
function askNotifPermission(){
  try{
    registerServiceWorker();
    if("Notification" in window && Notification.permission==="default"){
      Notification.requestPermission().then(p=>{ if(p==="granted") subscribeForPush(); }).catch(()=>{});
    } else if("Notification" in window && Notification.permission==="granted"){
      subscribeForPush();
    }
    // unlock audio on this user gesture
    AUDIO_CTX = AUDIO_CTX || new (window.AudioContext||window.webkitAudioContext)();
    if(AUDIO_CTX.state==="suspended") AUDIO_CTX.resume();
  }catch(e){}
}
/* decide what changed after a poll and alert the current user accordingly */
function detectAndNotify(before){
  if(!S.session) return;
  const role=S.session.role, me=S.session.username;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  // MANAGER: new guest booking, new request, new incoming chat (from guest or staff)
  if(role==="manager"){
    if(S.bookings.length>before.bookings) notify(t("notifBooking"), "");
    if(S.requests.length>before.requests) notify(t("notifRequest"), "");
    const incoming=S.messages.filter(m=>m.sender==="guest").length;
    if(incoming>before.incomingMsgs) notify(t("notifMsg"), "");
  }
  // STAFF: new task assigned to me, or new chat reply from manager
  if(role==="staff"){
    const myTasks=S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length;
    if(myTasks>before.myTasks) notify(t("notifTask"), "");
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // GUEST: new chat reply from team, or new announcement
  if(role==="guest"){
    const myMsgs=S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length;
    if(myMsgs>before.myMsgs) notify(t("notifMsg"), "");
  }
  // EVERYONE: new announcement for them
  if(S.notes.length>before.notes) notify(t("notifNew"), "");
}
function notifySnapshot(){
  const role=S.session?S.session.role:null, me=S.session?S.session.username:null;
  const myRoom = role==="staff" ? ("staff:"+me) : role==="guest" ? String(S.session.room) : null;
  return {
    bookings:S.bookings.length, requests:S.requests.length, notes:S.notes.length,
    incomingMsgs:S.messages.filter(m=>m.sender==="guest").length,
    myTasks:role==="staff"?S.tasks.filter(x=>!x.assigned_to||x.assigned_to===me).length:0,
    myMsgs:myRoom?S.messages.filter(m=>m.room===myRoom&&m.sender==="team").length:0
  };
}
let __polling=false;
/* ============ ACTIVITY ALARMS (time-based, fire once each) ============
   For the current user, checks every minute and alerts:
   - 5 minutes before start, at start, and at end of each activity today.
   Targeting:
   - GUEST: only activities they booked.
   - ASSIGNED entertainer: personal messages (be there 5 min early / take feedback after).
   - OTHER staff + manager: a general heads-up for every activity.
   Each (activity, phase) fires only once per day per device (tracked in localStorage). */
function alarmSeen(){ try{ return JSON.parse(localStorage.getItem("ent_alarms")||"{}"); }catch(e){ return {}; } }
function alarmSeenSave(o){ try{ localStorage.setItem("ent_alarms", JSON.stringify(o)); }catch(e){} }
function alarmKey(day,id,phase){ const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); return stamp+":"+day+":"+id+":"+phase; }
function fireActivityAlarm(a, phase){
  if(!S.session) return;
  const role=S.session.role;
  const name=a.name||"";
  const assigned = role==="staff" && a.entertainer && String(a.entertainer).toLowerCase()===String(S.session.username).toLowerCase();
  let title="", body=name;
  if(role==="guest"){
    // only booked activities (checked by caller)
    if(phase==="soon") title=t("almSoonG");
    else if(phase==="start") title=t("almStartG");
    else title=t("almDoneG");
    body=name;
  } else if(assigned){
    if(phase==="soon"){ title=t("almSoonS"); body=name; }
    else if(phase==="start"){ title=t("almStartS"); body=name; }
    else { title=t("almDoneS"); body=name; } // feedback reminder with room number
  } else {
    // other staff + manager: general heads-up
    if(phase==="soon") title=t("almSoonTeam");
    else if(phase==="start") title=t("almStartTeam");
    else title=t("almDoneTeam");
    body=name;
  }
  notify(title, body);
}
function checkActivityAlarms(){
  if(!S.session) return;
  if(!notifSoundOn()) return;               // respect the sound/alerts toggle
  const role=S.session.role;
  const todayIdx=todayIndex();
  const now=nowMinutes();
  const seen=alarmSeen();
  let changed=false;
  const todays=S.activities.filter(a=>a.day===todayIdx);
  todays.forEach(a=>{
    const w=actWindow(a); if(!w) return;
    // Relevance filter
    if(role==="guest"){ if(!myBooking(a.id)) return; }        // only booked
    // staff & manager: everyone gets it (assigned gets personal copy inside fireActivityAlarm)
    const phases=[["soon", w.s0-5],["start", w.s0],["done", w.e0]];
    phases.forEach(([phase, mark])=>{
      // fire when we're within the same minute or just past it (catch-up window of 2 min)
      if(now>=mark && now<mark+2){
        const k=alarmKey(a.day,a.id,phase);
        if(!seen[k]){ seen[k]=1; changed=true; fireActivityAlarm(a, phase); }
      }
    });
  });
  if(changed) alarmSeenSave(seen);
  // prune old keys (keep it small) — drop anything not from today
  const d=new Date(); const stamp=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
  const pruned={}; let prunedChanged=false;
  Object.keys(seen).forEach(k=>{ if(k.indexOf(stamp+":")===0) pruned[k]=1; else prunedChanged=true; });
  if(prunedChanged) alarmSeenSave(pruned);
}
/* re-render the visible list each minute so the status dots stay current */
