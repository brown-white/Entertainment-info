/* AUREA Phase 15 — planner persistence boundary
   Active mode `legacy_sequential` preserves the exact current write path.
   Future `rpc_atomic` support is prepared but hard-blocked until trusted
   Supabase Auth + RLS + an installed/verified database function exist. */
(function(){
  'use strict';
  if(window.AUREA_PLANNER_APPLY)return;

  const RPC_NAME="aurea_apply_planner_assignments_atomic";

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.PLANNER_APPLY_MODE)||"legacy_sequential";
  }

  function normalize(list){
    return (Array.isArray(list)?list:[])
      .filter(x=>x&&x.activity&&x.activity.id!=null&&x.username)
      .map(x=>({
        activity_id:x.activity.id,
        username:String(x.username).trim(),
        expected_entertainer:String(x.activity.entertainer||""),
        day:Number(x.activity.day),
        slot:typeof activitySlot==="function"?activitySlot(x.activity):(x.slot||null)
      }));
  }

  function basicValidate(list){
    const rows=normalize(list);
    if(rows.length!==(Array.isArray(list)?list.filter(x=>x&&x.activity&&x.activity.id!=null&&x.username).length:0))
      return {ok:false,reason:"invalid-row",rows};
    const ids=new Set();
    for(const row of rows){
      const id=String(row.activity_id);
      if(ids.has(id))return {ok:false,reason:"duplicate-activity",rows};
      ids.add(id);
      if(!row.username)return {ok:false,reason:"missing-username",rows};
    }
    return {ok:true,rows};
  }

  function concurrencyCheck(list){
    if(!window.AUREA_PLANNER_CONCURRENCY)return {ok:true,captured:false,reason:"concurrency-module-unavailable"};
    return AUREA_PLANNER_CONCURRENCY.check(list);
  }

  function assertNotStale(list){
    const c=concurrencyCheck(list);
    if(!c.ok){
      const err=new Error("Planner changed since this plan was generated. Build a fresh plan before applying.");
      err.code="AUREA_STALE_PLAN";
      err.details=c;
      throw err;
    }
    return c;
  }

  function atomicPreconditions(){
    const authMode=(typeof CONFIG!=="undefined"&&CONFIG.AUTH_MODE)||"legacy";
    const hasAuth=!!(window.AUREA_SUPABASE_AUTH&&
      AUREA_SUPABASE_AUTH.enabled&&AUREA_SUPABASE_AUTH.enabled()&&
      AUREA_SUPABASE_AUTH.accessToken&&AUREA_SUPABASE_AUTH.accessToken());
    return {
      applyMode:mode(),
      authMode,
      remote:!!(typeof REMOTE!=="undefined"&&REMOTE),
      authenticated:hasAuth,
      permission:!!(window.AUREA_PERMISSIONS&&AUREA_PERMISSIONS.can("planner.manage")),
      rpcName:RPC_NAME
    };
  }

  function assertAtomicReady(){
    const p=atomicPreconditions();
    if(mode()!=="rpc_atomic"){
      throw new Error("AUREA Phase 15 safety guard: atomic planner RPC is prepared but not active. Keep PLANNER_APPLY_MODE=legacy_sequential until staging activation.");
    }
    if(p.authMode!=="supabase_staff"||!p.authenticated||!p.remote||!p.permission){
      throw new Error("AUREA Phase 15 safety guard: atomic planner RPC requires authenticated Manager Supabase Auth, remote database access, and planner.manage permission.");
    }
    /* A second explicit deployment flag is required even after changing mode.
       Phase 15 never sets this flag. */
    if(!(typeof CONFIG!=="undefined"&&CONFIG.PLANNER_ATOMIC_RPC_DEPLOYED===true)){
      throw new Error("AUREA Phase 15 safety guard: database RPC has not been marked as deployed and staging-verified.");
    }
    return p;
  }

  async function legacyApply(list){
    if(typeof window.applyAssignments!=="function")
      throw new Error("Legacy planner apply function unavailable");
    return window.applyAssignments(list||[]);
  }

  async function rpcApply(list){
    assertAtomicReady();
    const check=basicValidate(list);
    if(!check.ok)throw new Error("Planner RPC preflight failed: "+check.reason);

    const result=await sb("rpc/"+RPC_NAME,{
      method:"POST",
      body:JSON.stringify({p_assignments:check.rows})
    });

    /* Expected future RPC contract:
       [{id, entertainer, ...optional activity fields}]
       Only update local activity state when recognizable rows are returned. */
    if(Array.isArray(result)&&result.length&&typeof S!=="undefined"){
      const byId=new Map(result.filter(x=>x&&x.id!=null).map(x=>[String(x.id),x]));
      if(byId.size){
        S.activities=(S.activities||[]).map(a=>{
          const row=byId.get(String(a.id));
          return row?{...a,...row}:a;
        });
      }
    }
    return true;
  }

  async function apply(list){
    assertNotStale(list);
    if(mode()==="legacy_sequential")return legacyApply(list);
    return rpcApply(list);
  }

  function status(){
    const p=atomicPreconditions();
    return Object.freeze({
      version:"phase16",
      mode:mode(),
      rpcName:RPC_NAME,
      atomicActive:mode()==="rpc_atomic"&&p.authenticated&&
        (typeof CONFIG!=="undefined"&&CONFIG.PLANNER_ATOMIC_RPC_DEPLOYED===true),
      legacyFallbackActive:mode()==="legacy_sequential",
      preconditions:p
    });
  }

  window.AUREA_PLANNER_APPLY={
    version:"phase16",
    mode,normalize,basicValidate,concurrencyCheck,assertNotStale,atomicPreconditions,
    assertAtomicReady,legacyApply,rpcApply,apply,status
  };
})();