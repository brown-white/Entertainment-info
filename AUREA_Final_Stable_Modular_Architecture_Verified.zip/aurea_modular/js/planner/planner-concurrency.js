/* AUREA Phase 16 — planner stale-plan / concurrency boundary
   Active `local_snapshot` mode is client-side preflight only.
   It adds no network calls and no database schema changes. */
(function(){
  'use strict';
  if(window.AUREA_PLANNER_CONCURRENCY)return;

  const snapshots=new WeakMap();

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.PLANNER_CONCURRENCY_MODE)||"local_snapshot";
  }

  function stable(v){
    if(Array.isArray(v))return v.map(stable);
    if(v&&typeof v==="object"){
      const out={};
      Object.keys(v).sort().forEach(k=>{out[k]=stable(v[k]);});
      return out;
    }
    return v==null?null:v;
  }

  function activityShape(a){
    if(!a)return null;
    return {
      id:a.id,
      name:a.name||"",
      day:Number(a.day),
      time:a.time||"",
      cat:a.cat||a.category||"",
      entertainer:a.entertainer||"",
      required_gender:a.required_gender||a.needs_gender||a.gender_requirement||"",
      needs_skill:a.needs_skill||"",
      duration:a.duration==null?null:a.duration,
      end_time:a.end_time||a.end||"",
      sets:a.sets||null
    };
  }

  function userShape(u){
    if(!u)return null;
    return {
      id:u.id,
      username:u.username||"",
      display_name:u.display_name||"",
      role:u.role||"",
      number:u.number==null?null:Number(u.number),
      active:u.active!==false,
      archived:!!u.archived,
      left_date:u.left_date||"",
      hire_date:u.hire_date||u.start_date||"",
      gender:u.gender||"",
      can_do:u.can_do||"",
      cannot_do:u.cannot_do||""
    };
  }

  function relevantActivityIds(plan){
    return new Set((plan||[]).map(x=>x&&x.activity&&x.activity.id).filter(x=>x!=null).map(String));
  }

  function contextFor(plan){
    const ids=relevantActivityIds(plan);
    /* Use the full programme, not only target rows. Preserved assignments can
       change eligibility, same-operation conflicts, overlaps, and fairness. */
    const activities=(S.activities||[])
      .map(activityShape)
      .sort((a,b)=>String(a.id).localeCompare(String(b.id)));

    const users=(S.users||[])
      .map(userShape)
      .sort((a,b)=>String(a&&a.username||"").localeCompare(String(b&&b.username||"")));

    const settings=S.settings||{};
    return stable({
      activities,
      targetIds:[...ids].sort(),
      users,
      staffAtt:(S.staffAtt||[])
        .map(x=>({username:x.username||"",date:String(x.date||"").slice(0,10),status:x.status||""}))
        .sort((a,b)=>(a.username+"|"+a.date).localeCompare(b.username+"|"+b.date)),
      dayOverrides:settings.dayOverrides||{},
      activityGenderRequirements:settings.activityGenderRequirements||{}
    });
  }

  function stringifyContext(plan){
    return JSON.stringify(contextFor(plan));
  }

  function capture(plan){
    if(!Array.isArray(plan))return null;
    const snap={
      createdAt:Date.now(),
      context:stringifyContext(plan),
      targetIds:[...relevantActivityIds(plan)].sort()
    };
    snapshots.set(plan,snap);
    return snap;
  }

  function captureSet(plans){
    (plans||[]).forEach(capture);
    return plans;
  }

  function inherit(source,derived){
    if(!Array.isArray(source)||!Array.isArray(derived))return derived;
    const snap=snapshots.get(source);
    if(snap)snapshots.set(derived,snap);
    return derived;
  }

  function check(plan){
    if(mode()!=="local_snapshot"){
      throw new Error(
        "AUREA Phase 16 safety guard: unsupported planner concurrency mode. "+
        "Keep PLANNER_CONCURRENCY_MODE=local_snapshot until database-level version/locking is staged."
      );
    }
    if(!Array.isArray(plan))return {ok:false,reason:"invalid-plan"};
    const snap=snapshots.get(plan);
    if(!snap){
      /* Compatibility: callers outside the A/B/C UI may not own a captured snapshot.
         Do not break those legacy flows; report uncaptured rather than falsely stale. */
      return {ok:true,captured:false,reason:"uncaptured-legacy"};
    }
    const current=stringifyContext(plan);
    if(current!==snap.context){
      return {
        ok:false,
        captured:true,
        stale:true,
        reason:"planner-context-changed",
        createdAt:snap.createdAt,
        targetIds:snap.targetIds.slice()
      };
    }
    return {ok:true,captured:true,stale:false,createdAt:snap.createdAt,targetIds:snap.targetIds.slice()};
  }

  function refresh(plan){
    return capture(plan);
  }

  function forget(plan){
    if(Array.isArray(plan))snapshots.delete(plan);
  }

  function status(plan){
    const c=Array.isArray(plan)?check(plan):null;
    return {version:"phase16",mode:mode(),tracked:!!(Array.isArray(plan)&&snapshots.has(plan)),check:c};
  }

  window.AUREA_PLANNER_CONCURRENCY={
    version:"phase16",
    mode,capture,captureSet,inherit,check,refresh,forget,status,contextFor
  };
})();