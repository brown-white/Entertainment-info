# Planner
Future home for planner rules, scoring, generation, and validation.
