/* AUREA Phase 9 — role-aware data loader boundary
   Default active mode remains `legacy_full`, preserving current behavior.
   Role-aware profiles are prepared for staged activation after trusted Auth/RLS. */
(function(){
  'use strict';
  if(window.AUREA_DATA_LOADER)return;

  const Q=Object.freeze({
    activities:"activities?select=*&order=time",
    bookings:"bookings?select=*",
    users:"app_users?select=*",
    settings:"app_settings?select=*&id=eq.1",
    tickets:"tickets?select=*&order=time",
    orders:"ticket_orders?select=*",
    rooms:"rooms?select=*&order=room",
    accounts:"guest_accounts?select=*",
    messages:"messages?select=*&order=created_at",
    requests:"requests?select=*&order=created_at.desc",
    tasks:"tasks?select=*&order=created_at.desc",
    notes:"announcements?select=*&order=created_at.desc",
    attendance:"attendance?select=*",
    feedback:"feedback?select=*&order=created_at.desc",
    profiles:"team_profiles?select=*&order=id",
    buses:"buses?select=*&order=sort",
    quizzes:"quizzes?select=*&order=quiz_date.desc",
    quizReplies:"quiz_replies?select=*&order=created_at.desc",
    staffAtt:"staff_attendance?select=*",
    photos:"photos?select=*&order=created_at.desc",
    staffReqs:"staff_requests?select=*&order=created_at.desc"
  });


  const POLL_Q=Object.freeze({
    messages:"messages?select=*&order=created_at",
    requests:"requests?select=*&order=created_at.desc",
    notes:"announcements?select=*&order=created_at.desc",
    bookings:"bookings?select=*",
    orders:"ticket_orders?select=*",
    tasks:"tasks?select=*&order=created_at.desc"
  });

  const LEGACY_POLL=Object.freeze([
    "messages","requests","notes","bookings","orders","tasks"
  ]);

  const POLL_PROFILES=Object.freeze({
    bootstrap:[],
    guest:["messages","requests","notes","bookings","orders"],
    staff:["messages","requests","notes","bookings","orders","tasks"],
    manager:LEGACY_POLL.slice()
  });

  const LEGACY_FULL=Object.freeze([
    "activities","bookings","users","settings","tickets","orders","rooms","accounts",
    "messages","requests","tasks","notes","attendance","feedback","profiles","buses",
    "quizzes","quizReplies","staffAtt","photos","staffReqs"
  ]);

  /* Future role-aware profiles. They are intentionally NOT active while
     CONFIG.DATA_LOAD_MODE === "legacy_full". Final contents must be validated
     against RLS and UI dependencies before staged activation. */
  const PROFILES=Object.freeze({
    bootstrap:["activities","settings","tickets","profiles","buses","quizzes","photos"],
    guest:["activities","settings","tickets","profiles","buses","quizzes","photos",
           "rooms","accounts","bookings","orders","messages","requests","quizReplies","notes"],
    staff:["activities","settings","tickets","profiles","buses","quizzes","photos",
           "bookings","orders","messages","requests","tasks","notes","attendance",
           "feedback","staffAtt","staffReqs","users"],
    manager:LEGACY_FULL.slice()
  });

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.DATA_LOAD_MODE)||"legacy_full";
  }

  function assertSafeMode(){
    if(mode()!=="legacy_full"){
      throw new Error("AUREA Phase 9 safety guard: role-aware loading is prepared but not activated. Keep DATA_LOAD_MODE=legacy_full until trusted Auth, RLS and realtime filtering are tested in staging.");
    }
  }

  function keysFor(role){
    if(mode()==="legacy_full")return LEGACY_FULL.slice();
    if(role&&PROFILES[role])return PROFILES[role].slice();
    return PROFILES.bootstrap.slice();
  }

  async function fetchKeys(keys){
    const unique=[...new Set(keys)].filter(k=>Q[k]);
    const pairs=await Promise.all(unique.map(async key=>[key,await sb(Q[key])]));
    return Object.fromEntries(pairs);
  }

  async function apply(data){
    if(!data||typeof data!=="object")return;
    for(const [key,val] of Object.entries(data)){
      if(key==="settings"){
        const rr=reconcileSettingsV626((val&&val[0]&&val[0].data)?val[0].data:DEFAULT_SETTINGS);
        S.settings=rr.settings;
        if(rr.localNewer){
          try{ await cloudUpsertSettingsV626(S.settings); }
          catch(e){ console.warn("settings cloud reconcile pending",e); }
        }
      }else if(Object.prototype.hasOwnProperty.call(S,key) || [
        "activities","bookings","users","tickets","orders","rooms","accounts","messages",
        "requests","tasks","notes","attendance","feedback","profiles","buses","quizzes",
        "quizReplies","staffAtt","photos","staffReqs"
      ].includes(key)){
        S[key]=val||[];
      }
    }
  }

  async function load(role){
    assertSafeMode();
    const keys=keysFor(role);
    const data=await fetchKeys(keys);
    await apply(data);
    return {mode:mode(),role:role||null,keys,data};
  }


  function pollKeysFor(role){
    if(mode()==="legacy_full")return LEGACY_POLL.slice();
    if(role&&POLL_PROFILES[role])return POLL_PROFILES[role].slice();
    return POLL_PROFILES.bootstrap.slice();
  }

  async function poll(role){
    assertSafeMode();
    const keys=pollKeysFor(role);
    if(!keys.length)return false;
    const pairs=await Promise.all(keys.map(async key=>[key,await sb(POLL_Q[key])]));
    let changed=false;
    for(const [key,val] of pairs){
      const next=val||[];
      if(JSON.stringify(next)!==JSON.stringify(S[key]))changed=true;
      S[key]=next;
    }
    return changed;
  }

  function profile(role){return keysFor(role);}
  function allQueries(){return {...Q};}

  window.AUREA_DATA_LOADER={
    version:"phase9",
    load,poll,profile,mode,allQueries,assertSafeMode,
    pollProfile:role=>pollKeysFor(role),
    legacyKeys:()=>LEGACY_FULL.slice(),
    legacyPollKeys:()=>LEGACY_POLL.slice(),
    profiles:()=>JSON.parse(JSON.stringify(PROFILES)),
    pollProfiles:()=>JSON.parse(JSON.stringify(POLL_PROFILES))
  };
})();