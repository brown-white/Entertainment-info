/* ---------------- data layer ---------------- */
async function sb(path, opts={}){
  const authToken=(window.AUREA_SUPABASE_AUTH&&AUREA_SUPABASE_AUTH.accessToken&&AUREA_SUPABASE_AUTH.accessToken())||CONFIG.SUPABASE_ANON_KEY;
  const res = await fetch(CONFIG.SUPABASE_URL + "/rest/v1/" + path, {
    ...opts,
    headers:{
      "apikey":CONFIG.SUPABASE_ANON_KEY,
      "Authorization":"Bearer "+authToken,
      "Content-Type":"application/json",
      "Prefer": opts.method==="POST"||opts.method==="PATCH" ? "return=representation" : "",
      ...(opts.headers||{})
    }
  });
  if(!res.ok) throw new Error("Supabase "+res.status+" on "+path);
  const txt = await res.text();
  return __sbParse(txt);
}
/* Supabase normally returns the created row. If it ever returns nothing
   (blocked header, odd proxy, empty body), fall back to the row we sent so
   we never push `undefined` into the app data. */
function __row(res, sent){
  if(res && res[0] && typeof res[0]==="object") return res[0];
  return {...sent, id:(sent && sent.id) || Date.now()+Math.random()};
}
function __sbParse(txt){
  return txt ? JSON.parse(txt) : null;
}
/* Upload an image file to Supabase Storage bucket "avatars"; returns the public URL. */
async function uploadAvatar(file){
  if(!REMOTE) throw new Error("offline");
  const ext=(file.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"")||"jpg";
  const path="avatars/"+Date.now()+"-"+Math.random().toString(36).slice(2,8)+"."+ext;
  const res=await fetch(CONFIG.SUPABASE_URL+"/storage/v1/object/"+path,{
    method:"POST",
    headers:{ "apikey":CONFIG.SUPABASE_ANON_KEY,
      "Authorization":"Bearer "+((window.AUREA_SUPABASE_AUTH&&AUREA_SUPABASE_AUTH.accessToken&&AUREA_SUPABASE_AUTH.accessToken())||CONFIG.SUPABASE_ANON_KEY),
      "Content-Type":file.type||"image/jpeg", "x-upsert":"true" },
    body:file
  });
  if(!res.ok){ throw new Error("upload "+res.status); }
  return CONFIG.SUPABASE_URL+"/storage/v1/object/public/"+path;
}
/* Wire a photo picker: an avatar preview + hidden file input + upload-on-change. */
/* ================= PHOTO VIEWER (lightbox) =================
   Tap any picture anywhere to open it big, swipe or arrow between them. */
/* Any picture, anywhere: tapping it opens the big view and NEVER triggers the
   card or row underneath. Runs in the capture phase so it fires before anything else. */
function initPhotoTaps(){
  if(window.__photoTaps) return;
  window.__photoTaps=true;
  document.addEventListener("click", ev=>{
    const target=ev.target;
    if(!target || !target.closest) return;
    // never inside the viewer itself, an upload box, the crop tool or an editor thumbnail
    if(target.closest(".pv-bg,.photo-pick,.photo-box,.pedit,.crop-stage,.brandmark")) return;
    const holder=target.closest("[data-pv],[data-pvsingle]");
    let urls=[], start=0;
    if(holder && holder.hasAttribute("data-pvsingle")){
      urls=[holder.getAttribute("data-pvsingle")];
    } else if(holder && holder.hasAttribute("data-pv")){
      const parts=String(holder.getAttribute("data-pv")).split("|");
      start=+parts[1]||0;
      let strip=null;
      try{ strip=document.querySelector('[data-strip="'+String(parts[0]).replace(/["\\]/g,"")+'"]'); }catch(e){}
      if(strip) urls=[...strip.querySelectorAll("img")].map(i=>i.getAttribute("src"));
      else { const im=holder.tagName==="IMG"?holder:holder.querySelector("img"); if(im) urls=[im.getAttribute("src")]; }
    } else {
      // a plain photo with no marker (gallery grid, avatars, proof shots…)
      if(target.tagName!=="IMG") return;
      const src=target.getAttribute("src");
      if(!src || /^data:/.test(src)) return;
      urls=[src];
    }
    urls=(urls||[]).filter(Boolean);
    if(!urls.length) return;
    ev.preventDefault();
    ev.stopPropagation();
    if(ev.stopImmediatePropagation) ev.stopImmediatePropagation();
    openPhotoViewer(urls, start);
  }, true);
}
function openPhotoViewer(urls, start){
  const list=(Array.isArray(urls)?urls:[urls]).filter(Boolean);
  if(!list.length) return;
  let i=Math.max(0, Math.min(list.length-1, start||0));
  const wrap=document.createElement("div");
  wrap.className="pv-bg";
  const draw=()=>{
    wrap.innerHTML=`
      <button class="pv-x" aria-label="${t("close")}">${ic("close",20)}</button>
      ${list.length>1?`<button class="pv-nav prev" aria-label="prev">${ic("back",22)}</button>`:""}
      <img class="pv-img" src="${esc(list[i])}" alt="">
      ${list.length>1?`<button class="pv-nav next" aria-label="next">${ic("back",22)}</button>`:""}
      ${list.length>1?`<span class="pv-count">${i+1} ${t("photoOf")} ${list.length}</span>`:""}`;
    const x=wrap.querySelector(".pv-x"); if(x) x.onclick=close;
    const pv=wrap.querySelector(".prev"); if(pv) pv.onclick=e=>{ e.stopPropagation(); i=(i-1+list.length)%list.length; draw(); };
    const nx=wrap.querySelector(".next"); if(nx) nx.onclick=e=>{ e.stopPropagation(); i=(i+1)%list.length; draw(); };
  };
  function onKey(e){
    if(e.key==="Escape") close();
    if(e.key==="ArrowLeft"){ i=(i-1+list.length)%list.length; draw(); }
    if(e.key==="ArrowRight"){ i=(i+1)%list.length; draw(); }
  }
  function close(){ wrap.remove(); document.removeEventListener("keydown",onKey); }
  wrap.onclick=e=>{ if(e.target===wrap) close(); };
  // swipe on touch
  let sx=0;
  wrap.addEventListener("touchstart",e=>{ sx=e.touches[0].clientX; },{passive:true});
  wrap.addEventListener("touchend",e=>{
    const dx=e.changedTouches[0].clientX-sx;
    if(Math.abs(dx)>50 && list.length>1){ i=(dx>0?(i-1+list.length):(i+1))%list.length; draw(); }
  },{passive:true});
  document.addEventListener("keydown",onKey);
  draw();
  document.body.appendChild(wrap);
}
/* A horizontal strip of photos that opens the viewer on tap */
function photoStrip(urls, key){
  const list=(urls||[]).filter(Boolean);
  if(!list.length) return "";
  return `<div class="pstrip" data-strip="${esc(key||"")}">
    ${list.map((u,ix)=>`<img src="${esc(u)}" alt="" loading="lazy" data-pv="${esc(key||"")}|${ix}">`).join("")}
  </div>`;
}
/* Editable list of photos (add / remove) used in the editors */
function photoListEditor(idBase, urls){
  return `<label>${t("photosLbl")}</label>
    <div class="pedit" id="${idBase}-list">
      ${(urls||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
        <button class="pedit-rm" type="button" data-prm="${ix}" aria-label="${t("removePhoto")}">${ic("close",13)}</button></div>`).join("")}
    </div>
    <button class="btn sm ghost" id="${idBase}-add" type="button">${ic("plus",14)} ${t("addPhotos")}</button>
    <input type="file" accept="image/*" multiple id="${idBase}-file" hidden>`;
}
/* Wires the editor: uploads new files, removes existing ones. */
function wirePhotoList(wrap, idBase, getList, setList){
  const box=wrap.querySelector("#"+idBase+"-list");
  const btn=wrap.querySelector("#"+idBase+"-add");
  const file=wrap.querySelector("#"+idBase+"-file");
  const redraw=()=>{
    if(!box) return;
    box.innerHTML=(getList()||[]).map((u,ix)=>`<div class="pedit-it"><img src="${esc(u)}" alt="">
      <button class="pedit-rm" type="button" data-prm="${ix}">${ic("close",13)}</button></div>`).join("");
    box.querySelectorAll("[data-prm]").forEach(b=>b.onclick=()=>{
      const l=(getList()||[]).slice(); l.splice(+b.dataset.prm,1); setList(l); redraw();
    });
  };
  redraw();
  if(btn && file) btn.onclick=()=>file.click();
  if(file) file.onchange=async ()=>{
    const files=[...(file.files||[])];
    if(!files.length) return;
    if(btn) btn.disabled=true;
    for(const f of files){
      try{ const url=await uploadAvatar(f); setList((getList()||[]).concat([url])); redraw(); }
      catch(e){ toastErr(t("uploadErr")); }
    }
    if(btn) btn.disabled=false;
    file.value="";
  };
}
/* ================= CIRCLE CROP (logo) ================= */
function openCropModal(file, onDone){
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("cropLogo")}</h3>
    <p class="mini">${t("cropHint")}</p>
    <div class="crop-stage" id="cr-stage">
      <canvas id="cr-canvas" width="280" height="280"></canvas>
      <div class="crop-ring"></div>
    </div>
    <label>${t("zoomLbl")}</label>
    <input id="cr-zoom" type="range" min="100" max="300" value="100">
    <button class="btn" id="cr-ok">${t("useCrop")}</button>
    <button class="btn ghost" id="cr-x">${t("close")}</button>`);
  const canvas=wrap.querySelector("#cr-canvas");
  const ctx=canvas.getContext&&canvas.getContext("2d");
  const img=new Image();
  let zoom=1, ox=0, oy=0, drag=false, lx=0, ly=0;
  const paint=()=>{
    if(!ctx||!img.width) return;
    const S2=canvas.width;
    ctx.clearRect(0,0,S2,S2);
    ctx.fillStyle="#00000010"; ctx.fillRect(0,0,S2,S2);
    const base=Math.max(S2/img.width, S2/img.height);
    const sc=base*zoom;
    const w=img.width*sc, h=img.height*sc;
    ctx.drawImage(img, (S2-w)/2+ox, (S2-h)/2+oy, w, h);
  };
  img.onload=paint;
  try{ img.src=URL.createObjectURL(file); }catch(e){}
  const stage=wrap.querySelector("#cr-stage");
  const start=(x,y)=>{ drag=true; lx=x; ly=y; };
  const move=(x,y)=>{ if(!drag) return; ox+=x-lx; oy+=y-ly; lx=x; ly=y; paint(); };
  const stop=()=>{ drag=false; };
  if(stage){
    stage.addEventListener("mousedown",e=>start(e.clientX,e.clientY));
    stage.addEventListener("mousemove",e=>move(e.clientX,e.clientY));
    stage.addEventListener("mouseup",stop); stage.addEventListener("mouseleave",stop);
    stage.addEventListener("touchstart",e=>start(e.touches[0].clientX,e.touches[0].clientY),{passive:true});
    stage.addEventListener("touchmove",e=>move(e.touches[0].clientX,e.touches[0].clientY),{passive:true});
    stage.addEventListener("touchend",stop,{passive:true});
  }
  const zi=wrap.querySelector("#cr-zoom");
  if(zi) zi.oninput=()=>{ zoom=(+zi.value)/100; paint(); };
  wrap.querySelector("#cr-x").onclick=()=>wrap.remove();
  wrap.querySelector("#cr-ok").onclick=()=>{
    if(!ctx){ wrap.remove(); return; }
    // cut a circle out of the canvas
    const out=document.createElement("canvas");
    out.width=out.height=canvas.width;
    const octx=out.getContext("2d");
    octx.beginPath();
    octx.arc(canvas.width/2, canvas.width/2, canvas.width/2, 0, Math.PI*2);
    octx.closePath(); octx.clip();
    octx.drawImage(canvas,0,0);
    out.toBlob(async b=>{
      if(!b){ wrap.remove(); return; }
      try{
        const f2=new File([b], "logo.png", {type:"image/png"});
        const url=await uploadAvatar(f2);
        wrap.remove(); onDone(url);
      }catch(e){ toastErr(t("uploadErr")); wrap.remove(); }
    }, "image/png");
  };
}
/* Opens the phone's picker, uploads, then hands back the link. */
function pickOneImage(done, multi){
  const inp=document.createElement("input");
  inp.type="file"; inp.accept="image/*"; if(multi) inp.multiple=true;
  inp.onchange=async ()=>{
    const files=[...(inp.files||[])];
    for(const f of files){
      try{ const url=await uploadAvatar(f); done(url); }
      catch(e){ toastErr(t("uploadErr")); }
    }
  };
  inp.click();
}
function wirePhotoPicker(wrap, getUrl, setUrl){
  const box=wrap.querySelector("[data-photobox]"); if(!box) return;
  const input=wrap.querySelector("[data-photoinput]");
  const render=()=>{ const u=getUrl();
    box.innerHTML = u ? `<img src="${esc(u)}" alt="">` : `<span>${ic("user",26)}</span>`; };
  render();
  box.onclick=()=>input&&input.click();
  if(input) input.onchange=async ()=>{
    const f=input.files&&input.files[0]; if(!f) return;
    box.classList.add("uploading");
    try{ const url=await uploadAvatar(f); setUrl(url); render(); toast(t("saved")); }
    catch(e){ toastErr(t("uploadErr")); }
    box.classList.remove("uploading");
  };
}
const SETTINGS_BACKUP_KEY_V626="entapp_settings_v626";
function readSettingsBackupV626(){
  try{
    const x=JSON.parse(localStorage.getItem(SETTINGS_BACKUP_KEY_V626)||"null");
    return x&&typeof x==="object"?x:null;
  }catch(e){ return null; }
}
function writeSettingsBackupV626(st){
  try{ localStorage.setItem(SETTINGS_BACKUP_KEY_V626,JSON.stringify(st||{})); }catch(e){}
}
function settingsRevisionV626(st){ return +(st&&st._settingsUpdatedAtV626||0)||0; }
function reconcileSettingsV626(remoteSettings){
  const remote={...DEFAULT_SETTINGS,...(remoteSettings||{})};
  const local=readSettingsBackupV626();
  if(local && settingsRevisionV626(local)>settingsRevisionV626(remote)){
    const merged={...DEFAULT_SETTINGS,...local};
    writeSettingsBackupV626(merged);
    return {settings:merged,localNewer:true};
  }
  writeSettingsBackupV626(remote);
  return {settings:remote,localNewer:false};
}
async function cloudUpsertSettingsV626(st){
  if(!REMOTE)return null;
  /* First try the normal PATCH. If the settings row does not exist, use a safe upsert. */
  try{
    const r=await sb("app_settings?id=eq.1",{method:"PATCH",body:JSON.stringify({data:st})});
    if(r&&r.length)return r;
  }catch(e){}
  return await sb("app_settings?on_conflict=id",{
    method:"POST",
    headers:{"Prefer":"resolution=merge-duplicates,return=representation"},
    body:JSON.stringify({id:1,data:st})
  });
}

