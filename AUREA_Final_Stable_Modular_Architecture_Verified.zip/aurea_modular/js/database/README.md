# Database
Database and Supabase access boundary.

- `supabase-client.js`: REST/storage/persistence support from the original core.
- `database.js`: existing `DB` repository API used by the application.

Future work should gradually move direct database writes behind domain services instead of adding new direct Supabase calls to UI files.
