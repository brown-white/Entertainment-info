// Reserved for the consolidated AUREA application entry point.
// Phase 1 preserves legacy load order from index.html.
