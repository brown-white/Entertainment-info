/* AUREA Phase 4 — canonical ticket order service
   Consolidates ticket order writes and manager edits.
   Ticket event CRUD remains in DB/manager UI. */
(function(){
  'use strict';
  if(window.AUREA_TICKET_SERVICE)return;
  const pending=new Map();

  function keyFor(row){
    return [String(row&&row.ticket_id||''),String(row&&row.room||(S.session&&S.session.room)||''),
      String(row&&row.collect_from||''),String(row&&row.qty||1)].join('|');
  }
  async function create(row){
    if(!(S.session&&S.session.role==='guest')||!row)return DB.addOrder(row);
    AUREA_PERMISSIONS.require('ticket.order',{room:row.room||S.session.room});
    const key=keyFor(row);if(pending.has(key))return pending.get(key);
    const task=Promise.resolve().then(()=>DB.addOrder(row)).finally(()=>pending.delete(key));
    pending.set(key,task);return task;
  }
  async function update(id,patch){
    AUREA_PERMISSIONS.require('ticket.manage');
    if(id==null||!patch)return null;
    if(REMOTE)await sb('ticket_orders?id=eq.'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(patch)});
    const o=(S.orders||[]).find(x=>String(x.id)===String(id));if(o)Object.assign(o,patch);
    return o||null;
  }
  async function setStatus(id,status){
    AUREA_PERMISSIONS.require('ticket.collect');
    return DB.setOrderStatus(id,status);
  }
  async function remove(id){
    const row=(S.orders||[]).find(o=>String(o.id)===String(id));
    if(S.session&&S.session.role==='guest'){
      AUREA_PERMISSIONS.require('ticket.cancelOwn',{room:row&&row.room||S.session.room});
      if(!row||!AUREA_PERMISSIONS.isOwnGuestRow(row))
        throw Object.assign(new Error('Cannot cancel another guest ticket order'),{code:'AUREA_PERMISSION_DENIED'});
    }else{
      AUREA_PERMISSIONS.require('ticket.manage');
    }
    return DB.deleteOrder(id);
  }

  window.AUREA_TICKET_SERVICE={
    version:'phase4',create,update,setStatus,remove,pendingCount:()=>pending.size
  };
})();