/* AUREA Phase 4 — canonical guest booking service
   Consolidates V6.15 booking policy + duplicate-write protection.
   Database persistence remains in DB; this service owns booking rules. */
(function(){
  'use strict';
  if(window.AUREA_BOOKING_SERVICE) return;

  const BOOKABLE=new Set(['mAdult','mEvents','eParty']);
  const VIEW_ONLY=new Set(['eLive','eShow','eBefore','eAfter','eKidsStage']);
  const pending=new Map();

  function category(activity){
    try{return normCat(activity);}catch(_){return String((activity&&activity.category)||'');}
  }
  function canBook(activity){return !!activity && BOOKABLE.has(category(activity));}
  function isViewOnly(activity){return !!activity && !canBook(activity);}
  function guestAccount(){
    if(!(S.session&&S.session.role==='guest'))return null;
    if(window.AUREA_GUEST_LIFECYCLE && typeof window.AUREA_GUEST_LIFECYCLE.currentAccounts==='function'){
      return window.AUREA_GUEST_LIFECYCLE.currentAccounts().find(a=>String(a.id)===String(S.session.accountId))||null;
    }
    return null;
  }
  function existing(activityId,room){
    if(typeof myBooking==='function' && S.session&&S.session.role==='guest'){
      const mine=myBooking(activityId);if(mine)return mine;
    }
    return (S.bookings||[]).find(b=>String(b.activity_id)===String(activityId)&&String(b.room)===String(room||''));
  }
  async function create(row){
    if(!(S.session&&S.session.role==='guest')||!row||row.activity_id==null)return DB.addBooking(row);
    AUREA_PERMISSIONS.require('activity.book',{room:row.room||S.session.room});
    const activity=(S.activities||[]).find(x=>String(x.id)===String(row.activity_id));
    if(activity&&!canBook(activity))return null;
    const room=String(row.room||S.session.room||'');
    const found=existing(row.activity_id,room);if(found)return found;
    const key=room+'|'+String(row.activity_id);
    if(pending.has(key))return pending.get(key);
    const task=Promise.resolve().then(()=>DB.addBooking(row)).finally(()=>pending.delete(key));
    pending.set(key,task);return task;
  }
  async function cancel(id){
    const row=(S.bookings||[]).find(b=>String(b.id)===String(id));
    if(S.session&&S.session.role==='guest'){
      AUREA_PERMISSIONS.require('booking.cancelOwn',{room:row&&row.room||S.session.room});
      if(!row||!AUREA_PERMISSIONS.isOwnGuestRow(row))
        throw Object.assign(new Error('Cannot cancel another guest booking'),{code:'AUREA_PERMISSION_DENIED'});
    }
    return DB.removeBooking(id);
  }

  window.AUREA_BOOKING_SERVICE={
    version:'phase4',
    bookable:[...BOOKABLE],
    viewOnly:[...VIEW_ONLY],
    canBook,isViewOnly,create,cancel,
    pendingCount:()=>pending.size
  };
  window.AUREA_BOOKING_POLICY=window.AUREA_BOOKING_SERVICE;
  window.canGuestBookV615=canBook;
})();