/* ================= WEATHER =================
   Free open service, no key needed, so it works for guests too.
   Defaults to Hurghada; the manager can set exact coordinates. */
const WMO={0:["wSun","sun"],1:["wSun","sun"],2:["wPartly","cloud"],3:["wCloud","cloud"],
  45:["wFog","cloud"],48:["wFog","cloud"],51:["wDrizzle","rain"],53:["wDrizzle","rain"],55:["wDrizzle","rain"],
  61:["wRain","rain"],63:["wRain","rain"],65:["wRain","rain"],66:["wRain","rain"],67:["wRain","rain"],
  71:["wSnow","snow"],73:["wSnow","snow"],75:["wSnow","snow"],77:["wSnow","snow"],
  80:["wShower","rain"],81:["wShower","rain"],82:["wShower","rain"],85:["wSnow","snow"],86:["wSnow","snow"],
  95:["wStorm","storm"],96:["wStorm","storm"],99:["wStorm","storm"]};
function wmoLabel(code){ const e=WMO[code]; return e?t(e[0]):""; }
function wmoIcon(code){ const e=WMO[code]; return e?e[1]:"sun"; }
function weatherCoords(){
  const st=S.settings||{};
  const lat=parseFloat(st.lat), lon=parseFloat(st.lon);
  return { lat: isNaN(lat)?27.2579:lat, lon: isNaN(lon)?33.8116:lon };   // Hurghada
}
async function loadWeather(force){
  if(S.weatherBusy) return;
  const fresh = S.weather && (Date.now()-S.weather.at < 30*60*1000);      // 30 min cache
  if(fresh && !force) return;
  S.weatherBusy=true;
  const {lat,lon}=weatherCoords();
  const tz=hotelTz()||"auto";
  const url="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+
    "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"+
    "&daily=weather_code,temperature_2m_max,temperature_2m_min"+
    "&timezone="+encodeURIComponent(tz)+"&forecast_days=7";
  try{
    const res=await fetch(url);
    if(!res.ok) throw new Error("weather "+res.status);
    const d=await res.json();
    S.weather={at:Date.now(), cur:d.current||null, daily:d.daily||null};
  }catch(e){ S.weather={at:Date.now(), error:true}; }
  S.weatherBusy=false;
  if(S.session && safeToRender()) render();
}
function weatherView(){
  const w=S.weather;
  if(!w || w.error){
    return `<div class="screen fadein">${topBar(t("weatherTab"),"")}
      <div class="empty"><div class="big">${ic("sun",30)}</div>${w?t("weatherFail"):t("loadingMsg")}</div>
      <button class="btn ghost" id="w-reload">${t("close")}</button></div>`;
  }
  const cur=w.cur||{}, dly=w.daily||{};
  const days=(dly.time||[]).map((iso,i)=>({iso,
    code:(dly.weather_code||[])[i], max:(dly.temperature_2m_max||[])[i], min:(dly.temperature_2m_min||[])[i]}));
  return `<div class="screen fadein">
    ${topBar(t("weatherTab"),"")}
    <div class="card wnow">
      <div class="wn-ic">${ic(wmoIcon(cur.weather_code),44)}</div>
      <div class="wn-mid">
        <b class="wn-t">${Math.round(cur.temperature_2m)}°</b>
        <span>${esc(wmoLabel(cur.weather_code))}</span>
        <span class="mini">${t("feelsLike")} ${Math.round(cur.apparent_temperature)}° · ${t("windLbl")} ${Math.round(cur.wind_speed_10m)} km/h</span>
      </div>
    </div>
    <h3 style="margin-top:18px">${ic("calendar",17)} ${t("weatherWeek")}</h3>
    <div class="card wweek">
      ${days.map((d,i)=>{
        const dt=new Date(d.iso+"T12:00:00");
        const lbl=i===0?t("weatherToday"):(t("daysShort")[(dt.getDay()+6)%7]||"");
        return `<div class="ww-row">
          <span class="ww-d">${esc(lbl)}</span>
          <span class="ww-i">${ic(wmoIcon(d.code),19)}</span>
          <span class="ww-x">${esc(wmoLabel(d.code))}</span>
          <span class="ww-t"><b>${Math.round(d.max)}°</b> <i>${Math.round(d.min)}°</i></span>
        </div>`;
      }).join("")}
    </div>
  </div>`;
}
/* small strip for the home screens */
