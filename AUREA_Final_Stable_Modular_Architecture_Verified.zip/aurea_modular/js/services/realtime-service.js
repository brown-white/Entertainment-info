/* AUREA Phase 10 — realtime isolation boundary
   Default mode remains `legacy_broad`, preserving Phase 9 behavior.
   Scoped role/stay subscriptions are designed here but intentionally blocked
   until trusted Auth, RLS and row ownership are proven in staging. */
(function(){
  'use strict';
  if(window.AUREA_REALTIME)return;

  const TABLE_STATE=Object.freeze({
    activities:"activities",
    bookings:"bookings",
    app_users:"users",
    tickets:"tickets",
    ticket_orders:"orders",
    rooms:"rooms",
    guest_accounts:"accounts",
    messages:"messages",
    requests:"requests",
    tasks:"tasks",
    announcements:"notes",
    attendance:"attendance",
    feedback:"feedback",
    team_profiles:"profiles",
    buses:"buses",
    quizzes:"quizzes",
    quiz_replies:"quizReplies",
    staff_attendance:"staffAtt",
    photos:"photos",
    staff_requests:"staffReqs"
  });

  const LEGACY_TABLES=Object.freeze(Object.keys(TABLE_STATE).concat(["app_settings"]));

  /* Future intent only. These profiles are NOT active in Phase 10.
     Database RLS remains the authoritative security layer when later enabled. */
  const ROLE_TABLES=Object.freeze({
    bootstrap:["activities","tickets","announcements","team_profiles","buses","quizzes","photos","app_settings"],
    guest:[
      "activities","tickets","announcements","team_profiles","buses","quizzes","photos","app_settings",
      "bookings","ticket_orders","messages","requests","quiz_replies","guest_accounts","rooms"
    ],
    staff:[
      "activities","tickets","announcements","team_profiles","buses","quizzes","photos","app_settings",
      "bookings","ticket_orders","messages","requests","tasks","attendance","feedback",
      "staff_attendance","staff_requests","app_users"
    ],
    manager:LEGACY_TABLES.slice()
  });

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.REALTIME_MODE)||"legacy_broad";
  }

  function assertSafeMode(){
    if(mode()!=="legacy_broad"){
      throw new Error(
        "AUREA Phase 10 safety guard: scoped realtime is prepared but not activated. "+
        "Keep REALTIME_MODE=legacy_broad until trusted Auth, RLS and scoped realtime are tested in staging."
      );
    }
  }

  function tablesFor(role){
    if(mode()==="legacy_broad")return LEGACY_TABLES.slice();
    if(role&&ROLE_TABLES[role])return ROLE_TABLES[role].slice();
    return ROLE_TABLES.bootstrap.slice();
  }

  function stateKey(table){return TABLE_STATE[table]||null;}

  function applyPayload(payload){
    try{
      const table=payload&&payload.table;
      const ev=(payload&&payload.eventType)||(payload&&payload.type);

      if(table==="app_settings"){
        const row=payload.new;
        if(row&&row.data){
          S.settings={...DEFAULT_SETTINGS,...row.data};
          applySettings();
          return true;
        }
        return false;
      }

      const key=stateKey(table);
      if(!key||!Array.isArray(S[key]))return false;
      const list=S[key];

      if(ev==="INSERT"&&payload.new){
        if(!list.some(x=>x.id===payload.new.id))list.push(payload.new);
        return true;
      }
      if(ev==="UPDATE"&&payload.new){
        const i=list.findIndex(x=>x.id===payload.new.id);
        if(i>=0)list[i]={...list[i],...payload.new};
        else list.push(payload.new);
        return true;
      }
      if(ev==="DELETE"){
        const oldRow=payload.old||{};
        if(oldRow.id==null)return false;
        S[key]=list.filter(x=>x.id!==oldRow.id);
        return true;
      }
    }catch(e){
      console.warn("realtime patch failed:",e&&e.message);
    }
    return false;
  }

  function createClient(){
    if(!(window.supabase&&window.supabase.createClient))
      throw new Error("Supabase realtime client unavailable");

    /* Phase 10 deliberately preserves the existing anonymous client creation.
       Future scoped mode must use a trusted authenticated JWT and RLS before activation. */
    return window.supabase.createClient(CONFIG.SUPABASE_URL,CONFIG.SUPABASE_ANON_KEY);
  }

  function subscribeLegacy(client,onPayload){
    assertSafeMode();
    return client.channel("live-changes")
      .on("postgres_changes",{event:"*",schema:"public"},onPayload)
      .subscribe();
  }

  function subscribe(client,onPayload){
    assertSafeMode();
    return subscribeLegacy(client,onPayload);
  }

  window.AUREA_REALTIME={
    version:"phase10",
    mode,assertSafeMode,tablesFor,stateKey,applyPayload,
    createClient,subscribe,
    legacyTables:()=>LEGACY_TABLES.slice(),
    profiles:()=>JSON.parse(JSON.stringify(ROLE_TABLES))
  };
})();