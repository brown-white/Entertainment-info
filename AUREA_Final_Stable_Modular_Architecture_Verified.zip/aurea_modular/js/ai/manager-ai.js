/* ---------------- AI assistant (manager only) ---------------- */
function aiView(){
  const key=localStorage.getItem("ent_ai_key")||"";
  if(!key){
    return `<div class="screen fadein">
      ${topBar(t("aiTab"),S.session.name)}
      ${hubBack()}
      <div class="card" style="padding:16px">
        <p style="font-size:15px">${ic("sparkle",16)} ${t("aiIntro")}</p>
        <label>${t("aiKeyLbl")}</label>
        <input id="ai-key" type="password" placeholder="sk-ant-...">
        <p class="hint" style="text-align:start">${t("aiKeyHint")}<br>→ console.anthropic.com</p>
        <button class="btn" id="ai-savekey">${t("save")}</button>
      </div>
    </div>`;
  }
  return `<div class="screen fadein">
    ${topBar(t("aiTab"),S.session.name)}
    ${hubBack()}
    <div class="thread">
      ${S.aiChat.length?S.aiChat.map(m=>`<div class="bub ${m.role==="user"?"me":"them"}">${esc(m.content)}</div>`).join("")
        :`<div class="empty"><div class="big">${ic("sparkle",30)}</div>${t("aiIntro")}</div>`}
      ${S.aiBusy?`<div class="bub them">…</div>`:""}
    </div>
    <div class="chatbar">
      <input id="ai-in" placeholder="${t("aiAsk")}" autocomplete="off">
      <button id="ai-send" aria-label="${t("send")}">${ic("send",17)}</button>
    </div>
  </div>`;
}
function aiContext(){
  const days=t("days");
  const prog=S.activities.slice(0,200).map(a=>`${days[a.day]} ${a.time} ${a.name} @${a.location}${a.entertainer?" [entertainer:"+a.entertainer+"]":""}`).join("; ");
  const rk=rankingRows().map(r=>`${r.u.display_name||r.u.username}: ${r.points}pts (done ${r.done}, late ${r.late}, can't ${r.cant}, open ${r.open})`).join("; ");
  const avg=S.feedback.length?(S.feedback.reduce((n,f)=>n+(+f.rate||0),0)/S.feedback.length).toFixed(1):"n/a";
  // full guest directory — lets the assistant answer "tell me about room 1111"
  const guests=S.accounts.map(a=>{
    const info=guestFullInfo(a.room); if(!info) return "";
    return `Room ${info.room}: ${info.name} (user ${info.username}), ${info.nationality||"?"}, phone ${info.phone||"?"}, stay ${info.arrival||"?"}→${info.departure||"?"}, ${info.days!=null?info.days+" days in app":""}, joined: ${info.activities.join("/")||"none"}, ${info.tickets} tickets, ${info.requests} requests`;
  }).filter(Boolean).join(" | ");
  const reqs=S.requests.slice(0,40).map(r=>`${r.type} "${r.detail}" room ${r.room} (${r.status})`).join("; ");
  const team=S.profiles.map(p=>`${p.name} — ${p.position||""} (${p.languages||""})`).join("; ");
  return `App: ${S.settings.name}. Today totals — bookings ${S.bookings.length}, ticket orders ${S.orders.reduce((n,o)=>n+(+o.qty||0),0)}, open requests ${S.requests.filter(r=>r.status==="new").length}, registered guest rooms ${S.accounts.length}, feedback avg ${avg}/5 (${S.feedback.length}). 
TEAM: ${team||"none"}. 
TEAM RANKING: ${rk||"none"}. 
GUEST DIRECTORY: ${guests||"no guests yet"}. 
RECENT REQUESTS: ${reqs||"none"}. 
WEEKLY PROGRAM: ${prog}`;
}
function aiSystemPrompt(){
  return "You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
    "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
    "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
    "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
    "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
    "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
    "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
    "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext();
}
/* Preferred path: a deployed Supabase Edge Function, so the API key never touches the browser. */
async function askAIViaEndpoint(endpoint){
  const res=await fetch(endpoint,{
    method:"POST",
    headers:{"content-type":"application/json"},
    body:JSON.stringify({
      system:aiSystemPrompt(),
      max_tokens:1200,
      messages:S.aiChat.map(m=>({role:m.role,content:m.content}))
    })
  });
  if(!res.ok) throw new Error("AI "+res.status);
  const data=await res.json();
  if(data.error) throw new Error(data.error);
  return String(data.text||"").trim();
}
async function askAI(text){
  const key=localStorage.getItem("ent_ai_key");
  const endpoint=(S.settings.aiEndpoint||"").trim();
  S.aiChat.push({role:"user",content:text});
  S.aiBusy=true; render();
  // Secure path first — only fall back to the browser key if no endpoint is set up yet.
  if(endpoint){
    try{
      const reply=await askAIViaEndpoint(endpoint);
      S.aiChat.push({role:"assistant",content:reply||"…"});
      S.aiBusy=false; render();
      window.scrollTo(0,document.body.scrollHeight);
      return;
    }catch(e){
      console.error("AI endpoint failed:", e && e.message);
      // The server link is wrong or not deployed yet.
      if(!key){
        S.aiChat.pop(); toastErr(t("aiEndpointErr"));
        S.aiBusy=false; render();
        window.scrollTo(0,document.body.scrollHeight);
        return;
      }
      // A key is stored on this device -> keep the assistant working and say so.
      toastWarn(t("aiEndpointFallback"));
    }
  }
  try{
    const res=await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{"content-type":"application/json","x-api-key":key,
        "anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
      body:JSON.stringify({model:"claude-haiku-4-5-20251001",max_tokens:1000,
        system:"You are the professional entertainment assistant inside a luxury 5-star hotel management app in Hurghada, working directly for the entertainment manager.\n\n"+
          "ABSOLUTE RULE — NEVER INVENT DATA. Every number, name, room, nationality, rating or activity you state must come word-for-word from the LIVE DATA below. "+
          "If the answer is not in the LIVE DATA, reply exactly: \"I don\'t have this information in the current system.\" and then say what the manager could add so you could answer next time. "+
          "Never estimate, never guess, never fill gaps with plausible-sounding examples, and never invent a guest, a room, an entertainer or a statistic.\n\n"+
          "WHAT YOU CAN SEE: the full guest directory (room, name, nationality, phone, arrival/departure, days using the app, joined activities, tickets, requests), the whole team and their ranking, all guest requests, the feedback ratings, and the full weekly programme.\n\n"+
          "WHAT YOU DO WELL: look up a room or guest and answer with the concrete details; spot the most popular and the emptiest activities; compare nationalities; report team performance and open tasks; write guest announcements, team briefings, WhatsApp messages and department requests (F&B, engineering, housekeeping); summarise today\'s performance and suggest what to improve tomorrow.\n\n"+
          "PROACTIVE BUT SAFE: when the data clearly shows a problem (for example activities with very low participation, many open requests, or a low rating), say so plainly with the real numbers and offer to prepare a recommendation. Never take an action yourself — you only suggest, and anything that would change or delete data must be confirmed and carried out by the manager in the app.\n\n"+
          "STYLE: warm, concise, practical. Short paragraphs or small lists. Always reply in the same language the manager writes in.\n\nLIVE DATA:\n"+aiContext(),
        messages:S.aiChat.map(m=>({role:m.role,content:m.content}))})
    });
    if(!res.ok) throw new Error("AI "+res.status);
    const data=await res.json();
    const reply=(data.content||[]).map(c=>c.text||"").join("\n").trim();
    S.aiChat.push({role:"assistant",content:reply||"…"});
  }catch(e){ console.error(e); S.aiChat.pop(); toast(t("aiErr")); }
  S.aiBusy=false; render();
  window.scrollTo(0,document.body.scrollHeight);
}
