/* ===== THE GUEST FEEDBACK REPORT =====
   Its own printed document rather than a generic table: a proper letterhead,
   a summary band, colour-coded stars, and only the departments that were
   actually rated in this selection — so no walls of empty dashes. */
function exportFeedbackReport(){
  const list=exportFeedbackList();
  const E2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const hotel=(S.settings&&(S.settings.hotelName||S.settings.name))||"";
  const bits=fbFilterBits();
  const cover=bits.length?bits.join(" \u00b7 "):t("fbWholeStay");
  const sum=fbSummary(list);
  const avg=sum.overall;

  const tone=n=>{ n=+n||0; return n<3.5?"#B0392B":n<4.5?"#D08526":"#B98A5C"; };
  const stars=(v,exact,strict)=>{
    let n=Math.round(+v||0);
    // in the shortfall table a 4.5 must not print as a full five
    if(strict && n>=5 && (+v||0)<4.995) n=4;
    if(!n) return '<span class=nr>\u00b7</span>';
    return '<span class=s style="color:'+tone(v)+'">'+"\u2605".repeat(n)
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span></span>'
      +(exact?'<em>'+E2(exact)+'</em>':'');
  };
  const tile=(lb,val,sub)=>'<div class=tile><span class=tl>'+E2(lb)+'</span>'
    +'<b>'+val+'</b>'+(sub?'<span class=ts>'+E2(sub)+'</span>':'')+'</div>';

  const css=""
   +"@page{size:A4 portrait;margin:14mm}"
   +"*{box-sizing:border-box}"
   +"body{font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#2B1F16;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}"
   +".head{padding:0 0 14px;border-bottom:2px solid #B98A5C;margin-bottom:16px}"
   +".hotel{font-size:10px;letter-spacing:.32em;text-transform:uppercase;color:#B98A5C;font-weight:700}"
   +"h1{font-family:Georgia,'Times New Roman',serif;font-size:27px;font-weight:400;margin:5px 0 3px;letter-spacing:.01em}"
   +".cover{font-size:13px;color:#6B4A32;font-weight:600}"
   +".meta{font-size:10px;color:#9C8A74;margin-top:5px}"
   +".band{display:flex;gap:9px;margin-bottom:16px}"
   +".tile{flex:1;background:#FBF7F0;border:1px solid #EADFCC;border-radius:9px;padding:10px 13px}"
   +".tile .tl{display:block;font-size:8.5px;letter-spacing:.16em;text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +".tile b{display:block;font-family:Georgia,serif;font-size:20px;font-weight:400;margin-top:3px;line-height:1.15}"
   +".tile .ts{display:block;font-size:10px;color:#6B4A32;margin-top:2px}"
   +".tile.warn{background:#FBF0EC;border-color:#E8CFC5}"
   +".tile.warn .tl{color:#B0392B}"
   +".pct{font-family:Georgia,serif}"
   +"h2.sub{font-family:Georgia,'Times New Roman',serif;font-size:15px;font-weight:400;"
     +"margin:20px 0 2px;color:#5A4029;letter-spacing:.01em}"
   +".subnote{font-size:10px;color:#9C8A74;margin:0 0 8px}"
   +".legend{margin:10px 0 0;font-size:9px;color:#9C8A74}"
   +"tr.r.low td{background:#FBF0EC}tr.c.low td{background:#F9EDE8}"
   +"tr.r.low td:first-child{box-shadow:inset 3px 0 0 #B0392B}"
   +"tr.r.low td.room{color:#B0392B}"
   +"tr.r.good td{background:#F5F8F2}tr.c.good td{background:#F8FAF6}"
   +"tr.r.good td:first-child{box-shadow:inset 3px 0 0 #6E9155}"
   +"tr.r.good td.room{color:#4A6B36}"
   +"tr.r.mid td{background:#FDF6EE}tr.c.mid td{background:#FAEEDF}"
   +"tr.r.mid td:first-child{box-shadow:inset 3px 0 0 #D08526}"
   +"tr.r.mid td.room{color:#A9631A}"
   +".tile.good{background:#F5F8F2;border-color:#DCE7D4}"
   +".tile.good .tl{color:#4A6B36}.tile.good b{color:#3F5C2F}"
   +".tile.attn{background:#FDF6EE;border-color:#EDDCC6}"
   +".tile.attn .tl{color:#A9631A}.tile.attn b{color:#8A4E12}"
   +".g{border:1px solid #EADFCC;border-radius:9px;padding:10px 12px;margin-bottom:8px;"
     +"page-break-inside:avoid;border-left-width:4px}"
   +".g.priority{border-left-color:#B0392B;background:#FCF4F2}"
   +".g.attn{border-left-color:#D08526;background:#FDF9F3}"
   +".g.none{border-left-color:#6E9155;background:#F7FAF5}"
   +".ghead{display:flex;align-items:center;gap:9px}"
   +".gr{font-family:Georgia,serif;font-size:16px;font-weight:400;color:#2B1F16}"
   +".gov{font-size:11px;letter-spacing:.3px}"
   +".gov .s em{display:inline;font-style:normal;font-size:10px;color:#6B4A32;margin-left:3px}"
   +".gs{margin-left:auto;font-size:8px;letter-spacing:.13em;text-transform:uppercase;font-weight:700;"
     +"display:inline-flex;align-items:center;gap:5px}"
   +".gs i{width:7px;height:7px;border-radius:50%;display:inline-block}"
   +".gs.priority{color:#B0392B}.gs.priority i{background:#B0392B}"
   +".gs.attn{color:#A9631A}.gs.attn i{background:#D08526}"
   +".gs.none{color:#4A6B36}.gs.none i{background:#6E9155}"
   +".gmeta{font-size:8.5px;color:#9C8A74;margin-top:2px}"
   +".gchips{margin-top:6px}"
   +".cleanbox{border:1px solid #DCE7D4;border-radius:9px;background:#F7FAF5;padding:2px 12px}"
   +".g5{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:7px 0;page-break-inside:avoid}"
   +".g5+.g5{border-top:1px solid #E4EEDE}"
   +".g5 .gmeta{margin:0}"
   +".tick{color:#6E9155;font-weight:700;font-size:12px}"
   +".g5 p.note{flex:1 0 100%;margin:2px 0 0}"
   +"table.rooms{font-size:10px}"
   +"table.rooms td{padding:7px 6px}"
   +"td.by{font-size:9px;color:#6B4A32}"
   +".chip{display:inline-block;margin:0 5px 3px 0;padding:2px 7px;border-radius:999px;"
     +"font-size:8.5px;background:#F7EFE3;color:#6B4A32;border:1px solid #EADFCC;white-space:nowrap}"
   +".chip b{font-weight:700;letter-spacing:.5px}"
   +".chip.c4 b{color:#D08526}.chip.c3{background:#FBEDE9;border-color:#EBD3CB}.chip.c3 b{color:#B0392B}"
   +".chip.ok{background:#F1F6EC;border-color:#DCE7D4;color:#4A6B36}"
   +".dl{display:inline-block;margin:0 6px 3px 0;font-size:8px;letter-spacing:.12em;"
     +"text-transform:uppercase;color:#9C8A74;font-weight:700}"
   +"p.note{margin:5px 0 0;font-size:8.5px;line-height:1.5;color:#6B4A32}"
   +".okmark{color:#7C9A6B;font-size:22px;line-height:1}"
   +"table{border-collapse:collapse;width:100%;font-size:9.5px}"
   +"thead{display:table-header-group}"
   +"th{background:#F2E7D6;color:#5A4029;text-align:left;padding:6px 5px;border:1px solid #E4D3BC;"
     +"font-size:8.5px;letter-spacing:.05em;text-transform:uppercase;line-height:1.25;vertical-align:bottom}"
   +"td{padding:6px 5px;border-left:1px solid #F0E6D6;border-right:1px solid #F0E6D6;vertical-align:middle}"
   +"tr.r{page-break-inside:avoid}"
   +"tr.r td{border-top:1px solid #E4D3BC}"
   +"tr.r.alt td{background:#FDFBF7}"
   +"td.st{text-align:center;white-space:nowrap;letter-spacing:.3px;font-size:10px}"
   +"td.st .s em{display:block;font-style:normal;font-size:8px;color:#9C8A74;letter-spacing:0;margin-top:1px}"
   +".sg{color:#E2D6C2}.nr{color:#D9CDBA}"
   +"td.room{font-weight:700;font-size:11px}"
   +"td.dt{white-space:nowrap;font-size:9px;color:#6B4A32}"
   +"tr.c{page-break-inside:avoid}"
   +"tr.c td{background:#FBF7F0;border-top:0;color:#4A3826;font-size:9px;line-height:1.5;padding:3px 8px 8px}"
   +"tr.c b{color:#B98A5C;font-weight:700;font-size:8.5px;letter-spacing:.12em;text-transform:uppercase}"
   +".foot{margin-top:18px;padding-top:9px;border-top:1px solid #EADFCC;font-size:9px;color:#9C8A74;display:flex;justify-content:space-between}"
   +".none{padding:34px;text-align:center;color:#9C8A74;font-size:13px;background:#FBF7F0;border-radius:10px}";

  let html='<div class=head>'
    +(hotel?'<div class=hotel>'+E2(hotel)+'</div>':'')
    +'<h1>'+E2(t("fbReport"))+'</h1>'
    +'<div class=cover>'+E2(cover)+'</div>'
    +'<div class=meta>'+E2(t("fbPrepared"))+" "+E2(new Date().toLocaleString())
      +(S.session&&S.session.name?" \u00b7 "+E2(S.session.name):"")+'</div>'
    +'</div>';

  html+='<div class=band>'
    + tile(t("fbCollected"), String(sum.count), sum.rated+" "+t("fbDeptsRated").toLowerCase())
    + tile(t("avgRate"), avg?stars(avg, avg.toFixed(1)):'<span class=nr>\u2014</span>')
    + '<div class="tile good"><span class=tl>'+E2(t("fbAllFiveN"))+'</span>'
      +'<b>'+sum.allFive+'</b><span class=ts>'+E2(t("fbAllFiveSub"))+'</span></div>'
    + '<div class="tile '+(sum.toReview?"attn":"")+'"><span class=tl>'+E2(t("fbToReview"))+'</span>'
      +'<b>'+sum.toReview+'</b><span class=ts>'+E2(t("fbToReviewSub"))+'</span></div>'
    +'</div>';

  /* The guests who raised something come first, worst first, each with exactly
     what they marked down. The guests who gave straight fives are listed after,
     one line each — they need no follow-up. */
  if(!list.length){
    html+='<div class=none>'+E2(t("fbNothing"))+'</div>';
  } else {
    const rank={priority:0, attn:1, none:2};
    const marked=f=>{
      const d=fbDepts(f);
      return fbDeptKeys().filter(k=>+d[k]>0 && +d[k]<5).sort((a,b)=>d[a]-d[b])
        .map(k=>'<span class="chip '+(d[k]<=3?"c3":"c4")+'">'+E2(fbDeptLabel(k))
          +' <b>'+"\u2605".repeat(+d[k])+'</b></span>').join("");
    };
    const meta=f=>[f.guest_name, f.nationality, teamName(f.by_user), shortStamp(f.created_at)]
      .filter(Boolean).map(E2).join(" \u00b7 ");
    const sorted=list.slice().sort((a,b)=>
      (rank[fbStatus(a)]-rank[fbStatus(b)]) || (fbOverall(a)-fbOverall(b)));
    const review=sorted.filter(f=>fbStatus(f)!=="none");
    const clean=sorted.filter(f=>fbStatus(f)==="none");

    html+='<h2 class=sub>'+E2(t("fbReviewHead"))+'</h2>'
      +'<p class=subnote>'+E2(review.length?t("fbReviewSub"):t("fbNoReview"))+'</p>';
    if(review.length){
      html+=review.map(f=>{
        const st=fbStatus(f), ov=fbOverall(f), note=fbComment(f), chips=marked(f);
        return '<div class="g '+st+'">'
          +'<div class=ghead>'
            +'<span class=gr>'+E2(f.room)+'</span>'
            +'<span class=gov>'+stars(ov, ov?ov.toFixed(1):"")+'</span>'
            +'<span class="gs '+st+'"><i></i>'+E2(fbStatusLabel(st))+'</span>'
          +'</div>'
          +'<div class=gmeta>'+meta(f)+'</div>'
          +(chips?'<div class=gchips>'+chips+'</div>':'')
          +(note?'<p class=note>'+E2(note)+'</p>':'')
          +'</div>';
      }).join("");
    }

    if(clean.length){
      html+='<h2 class=sub>'+E2(t("fbPerfectHead"))+'</h2>'
        +'<p class=subnote>'+E2(t("fbPerfectSub"))+'</p>'
        +'<div class=cleanbox>'
        + clean.map(f=>{
            const note=fbComment(f);
            return '<div class=g5>'
              +'<span class=gr>'+E2(f.room)+'</span>'
              +'<span class=gov>'+stars(fbOverall(f), fbOverall(f)?fbOverall(f).toFixed(1):"")+'</span>'
              +'<span class=tick>\u2713</span>'
              +'<span class=gmeta>'+meta(f)+'</span>'
              +(note?'<p class=note>'+E2(note)+'</p>':'')
              +'</div>';
          }).join("")
        +'</div>';
    }
    html+='<p class=legend>'+E2(t("fbLegend2"))+'</p>';
  }

  html+='<div class=foot><span>'+E2(hotel||t("fbReport"))+'</span>'
    +'<span>'+E2(cover)+' \u00b7 '+list.length+' '+E2(t("feedback"))+'</span></div>';

  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+E2(t("fbReport"))+"</title><meta charset=utf-8>"
    +"<style>"+css+"</style></head><body>"+html
    +"<scr"+"ipt>setTimeout(function(){window.print();},400);<\/scr"+"ipt></body></html>");
  w.document.close();
}
function openFeedbackExport(){
  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("fbExport")}</h3>
    <p class="mini">${t("fbFilterHead")}</p>
    <label>${t("whichMonth")}</label>
    <select id="fe-month">
      <option value="">${t("allMonths")}</option>
      ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===S.fbMonth?"selected":""}>${esc(lb)}</option>`).join("")}
    </select>
    <label style="margin-top:12px">${t("fbExactDate")}</label>
    <input type="date" id="fe-date" value="${esc(S.fbDate||"")}">
    <p class="mini" style="margin:4px 0 0">${t("fbExactHint")}</p>
    <label style="margin-top:12px">${t("whichTime")}</label>
    <select id="fe-slot">
      <option value="">${t("allDayLong")}</option>
      ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
    </select>
    <p class="mini" id="fe-note" style="margin-top:8px"></p>
    <button class="btn" id="fe-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="fe-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="fe-x">${t("close")}</button>`);
  const mSel=wrap.querySelector("#fe-month");
  const sSel=wrap.querySelector("#fe-slot"), xDate=wrap.querySelector("#fe-date");
  const note=wrap.querySelector("#fe-note");
  const apply=()=>{
    if(xDate) S.fbDate=xDate.value;
    if(mSel) S.fbMonth=mSel.value;
    if(sSel) S.exportSlot=sSel.value;
    // an exact date makes the month meaningless — grey it out
    if(mSel) mSel.disabled=!!S.fbDate;
    const n=exportFeedbackList().length;
    const bits=fbFilterBits();
    if(note) note.textContent = bits.length
      ? t("filterNote")+" "+bits.join(" \u00b7 ")+" \u2014 "+n+" "+t("feedback")
      : t("noFilterNote")+" "+n+" "+t("feedback");
  };
  [mSel,sSel,xDate].forEach(el=>{ if(el){ el.onchange=apply; el.oninput=apply; } });
  apply();
  wrap.querySelector("#fe-x").onclick=()=>wrap.remove();
  wrap.querySelector("#fe-xlsx").onclick=async ()=>{
    apply();
    await exportExcelSets([buildDataset("feedback")].filter(Boolean),"guest-feedback-"+todayISO());
    toast(t("saved"));
  };
  wrap.querySelector("#fe-pdf").onclick=()=>{ apply(); exportFeedbackReport(); wrap.remove(); };
}
