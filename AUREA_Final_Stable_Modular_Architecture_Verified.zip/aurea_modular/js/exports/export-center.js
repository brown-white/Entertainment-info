function fmtDate(d){ return String(d||"").slice(0,16).replace("T"," "); }
/* build every exportable dataset as {title, headers, rows} */
function buildDataset(kind){
  const acts=id=>{ const a=S.activities.find(x=>x.id===id); return a?a.name:("#"+id); };
  const tkName=id=>{ const x=S.tickets.find(t=>t.id===id); return x?x.name:("#"+id); };
  if(kind==="bookings"){
   const okAct=new Set(exportActivities().map(a=>a.id));
   return {title:t("expBookings")+exportFilterNote(),
    headers:[t("room"),t("name"),t("nationality"),t("phone"),t("actName"),t("day"),t("time"),t("persons"),"Status"],
    rows:S.bookings.filter(b=>okAct.has(b.activity_id)).map(b=>{ const a=S.activities.find(x=>x.id===b.activity_id)||{};
      return [b.room,b.guest_name,b.nationality||"",b.phone||"",a.name||"",t("days")[a.day]||"",a.time||"",((+b.adults)||0)+((+b.children)||0),b.status||""]; })};
  }
  if(kind==="requests") return {title:t("expRequests"),
    headers:[t("room"),t("name"),t("taskType"),"Detail",t("day"),"Note","Status","Date"],
    rows:S.requests.map(r=>[r.room,r.guest_name||"",r.type,r.detail,r.date||"",r.note||"",r.status,fmtDate(r.created_at)])};
  if(kind==="chat") return {title:t("expChat"),
    headers:[t("room"),"From","Message","Date"],
    rows:S.messages.map(m=>[m.room,m.sender==="team"?"Team":"Guest",m.text,fmtDate(m.created_at)])};
  if(kind==="users") return {title:t("expUsers"),
    headers:[t("shirtNumber"),t("displayName"),t("user"),t("roleLabel"),t("nationality"),t("genderLbl")],
    rows:S.users.slice().sort((a,b)=>(a.number||99)-(b.number||99))
      .map(u=>[u.number?("#"+u.number):"", u.display_name||"", u.username, u.role,
               u.nationality||"", u.gender?genderLabel(u.gender):""])};
  if(kind==="monthatt"){
    /* export whichever month she picked, not only the one on screen */
    const mk=S.exportMonth || currentAttMonth();
    const n=monthDays(mk), team=attTeamFor(mk);
    const headers=[t("displayName")]
      .concat(Array.from({length:n},(_,i)=>String(i+1)))
      .concat([t("attTotalsP"), t("attTotalsO"), t("attTotalsA")]);
    /* On the official sheet a day off is a paid day, so it counts as present.
       The days-off column still shows them separately. */
    const rows=team.map(u=>{
      const tot=attTotals(u,mk);
      return [u.display_name||u.username]
        .concat(Array.from({length:n},(_,i)=>isFutureDay(mk,i+1)?"":attStatus(u,mk,i+1)))
        .concat([String(tot.P+tot.O), String(tot.O), String(tot.A)]);
    });
    if(team.length){
      const mt=attMonthTotals(mk);
      rows.push([t("totalRow")].concat(Array.from({length:n},()=>""))
        .concat([String(mt.P+mt.O), String(mt.O), String(mt.A)]));
    }
    const soFar=(mk===currentAttMonth()) ? daysSoFar(mk) : n;
    return {title:t("monthAtt")+" — "+monthLabel(mk)+(soFar<n?" ("+t("upToToday")+")":""),
            headers, rows, signatures:true};
  }
  if(kind==="teamsummary"){
    const st=teamStats();
    const rows=[
      [t("totalTeam"), String(st.total)],
      [t("totalEntertainers"), String(st.entertainers)],
      [t("genderM"), String(st.byGender.male)],
      [t("genderF"), String(st.byGender.female)]
    ];
    if(st.byGender.none) rows.push([t("genderNone"), String(st.byGender.none)]);
    const dToday=todayIndex(), dutyT=dayDutyStats(dToday);
    rows.push([t("workingToday"), String(dutyT.workingCount)]);
    rows.push([t("dayOffToday"), String(dutyT.offCount)]);
    st.natList.forEach(n=>rows.push([t("byNationality")+" · "+n.name, String(n.count)]));
    return {title:t("teamSummary"), headers:["",""], rows};
  }
  if(kind==="guests") return {title:t("expGuests"),
    headers:[t("room"),t("user"),t("name"),t("nationality"),t("phone"),t("arrival"),t("departure"),t("daysHere"),t("joinedActs"),t("tickets"),t("requests")],
    rows:S.accounts.map(a=>{ const info=guestFullInfo(a.room)||{};
      return [a.room,a.username||a.room,a.name,a.nationality||"",a.phone||"",a.arrival||"",a.departure||"",info.days!=null?info.days:"",(info.activities||[]).join(", "),info.tickets||0,info.requests||0]; })};
  if(kind==="tickets") return {title:t("expTickets"),
    headers:[t("room"),t("name"),"Ticket","Qty","Status",t("handTo"),"Date"],
    rows:S.orders.map(o=>[o.room,o.guest_name,tkName(o.ticket_id),o.qty,o.status,o.collect_from||"",fmtDate(o.created_at)])};
  if(kind==="feedback"){
    const list=exportFeedbackList();
    return {title:t("expFeedback")+fbFilterNote(),
      landscape:true,
      stars:{from:3, to:3+fbDeptKeys().length},          // Overall + every department
      notes:list.map(f=>fbComment(f)),                    // printed full width under the row
      noteLabel:t("comment"),
      headers:[t("room"),t("fbGuestName"),t("nationality"),t("fbOverall")]
        .concat(fbDeptKeys().map(fbDeptLabel))
        .concat([t("fbCollectedBy"),"Date"]),
      rows:list.map(f=>{ const d=fbDepts(f);
        return [f.room,f.guest_name||"",f.nationality||"",fbOverall(f)||""]
          .concat(fbDeptKeys().map(k=>+d[k]>0?+d[k]:""))
          .concat([teamName(f.by_user),fmtDate(f.created_at)]); })};
  }
  if(kind==="fbdepts"){
    const st=fbDeptStats(exportFeedbackList()).sort((a,b)=>b.avg-a.avg);
    return {title:t("fbDeptSheet")+fbFilterNote(),
      stars:{from:1, to:1},
      headers:[t("fbByDept"),t("avgRate"),t("fbResponses")],
      rows:st.map(d=>[fbDeptLabel(d.k), d.avg.toFixed(2), d.n])};
  }
  if(kind==="program") return {title:t("manage")+exportFilterNote(),
    headers:[t("day"),t("time"),t("actName"),t("category"),t("location"),t("entertainer"),t("capacity"),t("makeHighlight")],
    rows:exportActivities().slice().sort((x,y)=>(x.day-y.day)||String(x.time).localeCompare(String(y.time)))
      .map(a=>[t("days")[a.day]||"",a.time||"",a.name||"",catLabel(normCat(a)),a.location||"",a.entertainer||"",a.capacity||0,a.highlight?"★":""])};
  if(kind==="dayplan"){
    // One clean row per day — exactly what hotel management needs at a glance
    const onlyDay=expDay();
    const rows=DAY_PLAN.filter(dp=>onlyDay==null || dp.day===onlyDay).map(dp=>{
      const evs=S.activities.filter(a=>{
        const c=normCat(a); return a.day===dp.day && (c==="mEvents"||c==="eParty");
      }).sort((x,y)=>String(x.time).localeCompare(String(y.time)))
        .map(a=>String(a.time||"").split(/\s*[–—-]\s*/)[0]+" "+a.name+(a.location?" ("+a.location+")":""));
      const duty=dayDutyStats(dp.day);
      return [
        t("days")[dp.day]||dp.name,
        dp.theme,
        dp.dress,
        evs.length?evs.join(" | "):"—",
        dp.liveBand||"—",
        dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc,
        personTags(dp.off)||"—",
        personTag(dp.entrance),
        String(duty.workingCount),
        String(duty.offCount)
      ];
    });
    return {title:t("dayPlan"),
      headers:[t("day"),t("restaurantTheme"),t("dressCode"),t("eventsToday"),
               t("liveBandLbl"),t("eveningShowLbl"),t("dayOff"),t("entranceDuty"),
               t("workingToday"),t("dayOffToday")],
      rows};
  }
  if(kind==="todayplan"){
    // Just today — the sheet she sends to management each morning
    const d=todayIndex();
    const dp=dayPlanFor(d);
    const evs=S.activities.filter(a=>{
      const c=normCat(a); return a.day===d && (c==="mEvents"||c==="eParty");
    }).sort((x,y)=>String(x.time).localeCompare(String(y.time)));
    // Management sheet — the day first, then the team totals at the end.
    // Order exactly as the hotel reads it. No practice, no internal notes.
    const rows=[ [t("restaurantTheme"), dp.theme] ];
    evs.forEach(a=>rows.push([t("eventsToday"),
      String(a.time||"").split(/\s*[–—-]\s*/)[0]+" — "+a.name+(a.location?" ("+a.location+")":"")]));
    if(!evs.length) rows.push([t("eventsToday"),"—"]);
    rows.push([t("liveBandLbl"), dp.liveBand||"—"]);
    rows.push([t("eveningShowLbl"), dp.eveningShow+" · "+dp.showTime+" · "+dp.showLoc]);
    rows.push([t("dressCode"), dp.dress]);
    rows.push([t("entranceDuty"), personTag(dp.entrance)]);
    rows.push([t("dayOff"), personTags(dp.off)||"—"]);
    // ---- team totals ----
    const st=teamStats(), duty=dayDutyStats(d);
    if(st.total){
      // entertainers working today = entertainers minus the ones off (manager excluded)
      const offEnt=duty.off.filter(u=>u.role!=="manager").length;
      rows.push([t("workingEntToday"), String(Math.max(0, st.entertainers-offEnt))+" / "+st.entertainers]);
      rows.push([t("totalAllTeam"), String(st.total)]);
      if(st.natList.length) rows.push([t("byNationality"), st.natList.map(n=>n.name+" "+n.count).join(" · ")]);
      const gen=[st.byGender.male+" "+t("genderM"), st.byGender.female+" "+t("genderF")];
      if(st.byGender.none) gen.push(st.byGender.none+" "+t("genderNone"));
      rows.push([t("byGender"), gen.join(" · ")]);
    }
    return {title:(t("days")[d]||"")+" · "+t("dayPlan"), headers:["",""], rows};
  }
  return null;
}
const EXPORT_KINDS=["todayplan","dayplan","monthatt","teamsummary","program","guests","bookings","requests","chat","tickets","feedback","fbdepts","users"];
function exportKindLabel(k){ return {todayplan:t("todayPlanExp"),monthatt:t("attExport"),teamsummary:t("teamSummary"),program:t("manage"),dayplan:t("dayPlan"),guests:t("expGuests"),bookings:t("expBookings"),requests:t("expRequests"),chat:t("expChat"),tickets:t("expTickets"),feedback:t("expFeedback"),fbdepts:t("fbDeptSheet"),users:t("expUsers")}[k]; }
async function loadXLSX(){
  if(window.XLSX) return true;
  return new Promise(res=>{const sc=document.createElement("script");
    sc.src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
    sc.onload=()=>res(true); sc.onerror=()=>res(false); document.head.appendChild(sc);});
}
function downloadBlob(name,blob){
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=name;
  document.body.appendChild(a); a.click(); a.remove();
}
async function exportExcelSets(sets,fname){
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      const ws=XLSX.utils.aoa_to_sheet([headers,...rows]);
      const name=(ds.title||"Sheet").replace(/[\\/?*\[\]:]/g,"").slice(0,28)||"Sheet";
      XLSX.utils.book_append_sheet(wb,ws,name);
    });
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const lines=[];
    sets.forEach(ds=>{
      const headers=ds.notes ? ds.headers.concat([ds.noteLabel||"Note"]) : ds.headers;
      const rows=ds.notes ? ds.rows.map((r,i)=>r.concat([ds.notes[i]||""])) : ds.rows;
      lines.push([ds.title]); lines.push(headers); rows.forEach(r=>lines.push(r)); lines.push([]); });
    const csv=lines.map(r=>r.map(c=>'"'+String(c==null?"":c).replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
}
function exportPdfSets(sets,titleText){
  const esc2=x=>String(x==null?"":x).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
  const css="body{font-family:Arial,Helvetica,sans-serif;color:#2B1F16;padding:26px}"
    +"h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px;color:#6B4A32;border-bottom:2px solid #B98A5C;padding-bottom:4px}"
    +"table{border-collapse:collapse;width:100%;margin-bottom:10px;font-size:11px}"
    +"th{background:#F2E7D6;text-align:left;padding:6px 8px;border:1px solid #E4D3BC}"
    +"td{padding:5px 8px;border:1px solid #EEE3D2;vertical-align:top}"
    +".sub{color:#8A7358;font-size:12px;margin-bottom:6px}@media print{h2{page-break-after:avoid}}"
    +"table.sig{margin-top:26px;page-break-inside:avoid}"
    +"table.sig th{text-align:center;font-size:11px;letter-spacing:.04em;text-transform:uppercase}"
    +"td.sigbox{height:74px;border:1px solid #E4D3BC}"
    +"table.rated{font-size:10px}table.rated th{font-size:9px;padding:5px 3px;line-height:1.25}"
   +".band{flex-wrap:wrap}"
    +"table.rated td{padding:4px 3px}"
    +"td.st{text-align:center;white-space:nowrap;font-size:11px;letter-spacing:0}"
    +".sg{color:#DDD1BE}.nr{color:#CFC3B0}"
    +".sx{display:block;font-size:9px;color:#8A7358;letter-spacing:0}"
    +"tr.note td{background:#FBF7F0;color:#4A3826;font-size:11px;border-top:0;line-height:1.5}"
    +"tr.note b{color:#8A7358;font-weight:600}"
    +"tr.main td{border-bottom:0}"
    +(sets.some(d=>d.landscape)?"@page{size:A4 landscape;margin:12mm}":"");
  const starCell=(v,exact)=>{
    const n=Math.round(+v||0);
    if(!n) return '<span class=nr>\u2014</span>';
    const col = n<=3 ? "#C0392B" : n===4 ? "#E08A2E" : "#C9A227";
    return '<span style="color:'+col+'">'+"\u2605".repeat(n)+'</span>'
      +'<span class=sg>'+"\u2606".repeat(5-n)+'</span>'
      +(exact!=null?'<span class=sx>'+esc2(exact)+'</span>':'');
  };
  let html="<h1>"+esc2(titleText)+"</h1><div class=sub>"+esc2(new Date().toLocaleString())+"</div>";
  sets.forEach(ds=>{
    html+="<h2>"+esc2(ds.title)+"</h2><table"+(ds.stars?" class=rated":"")+"><thead><tr>"
      +ds.headers.map(h=>"<th>"+esc2(h)+"</th>").join("")+"</tr></thead><tbody>";
    html+=ds.rows.map((r,ri)=>{
      const hasNote=ds.notes && ds.notes[ri];
      let out="<tr"+(hasNote?" class=main":"")+">"+r.map((c,ci)=>{
        const isStar=ds.stars && ci>=ds.stars.from && ci<=ds.stars.to;
        if(!isStar) return "<td>"+esc2(c)+"</td>";
        const exact = ds.exact ? ds.exact[ri] : (ci===ds.stars.from && String(c).includes(".") ? c : null);
        return "<td class=st>"+starCell(c, exact)+"</td>";
      }).join("")+"</tr>";
      if(hasNote) out+="<tr class=note><td colspan="+ds.headers.length+"><b>"
        +esc2(ds.noteLabel||"")+":</b> "+esc2(ds.notes[ri])+"</td></tr>";
      return out;
    }).join("");
    if(!ds.rows.length) html+="<tr><td colspan="+ds.headers.length+" style=\"color:#999\">—</td></tr>";
    html+="</tbody></table>";
    if(ds.signatures){
      const sigRoles=[t("sigEntertainment"), t("sigSecurity"), t("sigFB"), t("sigGM")];
      html+="<table class=sig><tr>"
        +sigRoles.map(r=>"<th>"+esc2(r)+"</th>").join("")
        +"</tr><tr>"
        +sigRoles.map(()=>"<td class=sigbox></td>").join("")
        +"</tr></table>";
    }
  });
  const w=window.open("","_blank");
  if(!w){ toast(t("aiErr")); return; }
  w.document.write("<html><head><title>"+esc2(titleText)+"</title><meta charset=utf-8><style>"+css+"</style></head><body>"+html+"<scr"+"ipt>setTimeout(function(){window.print();},350);<\/scr"+"ipt></body></html>");
  w.document.close();
}
/* An attendance sheet gets an official heading; anything else keeps the plain one. */
/* Months she can export: this one and the seventeen before it. */
/* What she ticked in the export screen: a weekday, a part of the day, or both. */
function expDay(){
  if(S.exportDate){
    const dt=new Date(String(S.exportDate)+"T12:00:00");
    if(!isNaN(dt.getTime())) return (dt.getDay()+6)%7;
  }
  return S.exportDay===""||S.exportDay==null ? null : +S.exportDay;
}
function expSlot(){ return S.exportSlot || ""; }
function inExportSlot(time){
  const slot=expSlot(); if(!slot) return true;
  const m=timeToMin(time); if(m==null) return false;
  return operationSlotFromMinutes(m)===slot;
}
/* activities that survive the day and time filters */
function exportActivities(){
  const d=expDay();
  return (S.activities||[])
    .filter(a=>d==null || a.day===d)
    .filter(a=>inExportSlot(a.time));
}
/* Feedback the manager asked for: a month, a weekday and a part of the day.
   All three are optional and stack. */
function exportFeedbackList(){
  const mk=S.fbMonth||"", day=S.fbDate||"", slot=expSlot();
  const list=(S.feedback||[]).filter(f=>{
    const ts=f.created_at?new Date(f.created_at):null;
    if(!ts || isNaN(ts.getTime())) return !mk && !day && !slot;
    if(day) return localDateKey(ts)===day && slotOk(ts,slot);   // one exact date wins over the month
    if(mk && localMonthKey(ts)!==mk) return false;
    return slotOk(ts,slot);
  });
  return list.sort((a,b)=>String(b.created_at||"").localeCompare(String(a.created_at||"")));
}
function localMonthKey(dt){
  return dt.getFullYear()+"-"+String(dt.getMonth()+1).padStart(2,"0");
}
function localDateKey(dt){
  return localMonthKey(dt)+"-"+String(dt.getDate()).padStart(2,"0");
}
function slotOk(ts,slot){
  if(!slot) return true;
  const m=ts.getHours()*60+ts.getMinutes();
  return operationSlotFromMinutes(m)===slot;
}
/* Reads back as "Wednesday 3 September 2026" so the report says what it covers. */
/* 03/09 · 22:29 — short enough for a narrow column, still unambiguous. */
function shortStamp(iso){
  const dt=iso?new Date(iso):null;
  if(!dt || isNaN(dt.getTime())) return "";
  const p=n=>String(n).padStart(2,"0");
  return p(dt.getDate())+"/"+p(dt.getMonth()+1)+" \u00b7 "+p(dt.getHours())+":"+p(dt.getMinutes());
}
function niceDate(key){
  const bits=String(key||"").split("-");
  if(bits.length!==3) return key||"";
  const dt=new Date(+bits[0], +bits[1]-1, +bits[2]);
  if(isNaN(dt.getTime())) return key;
  return (t("days")[(dt.getDay()+6)%7]||"")+" "+dt.getDate()+" "+(t("months")[dt.getMonth()]||"")+" "+dt.getFullYear();
}
function fbFilterBits(){
  const bits=[];
  if(S.fbDate) bits.push(niceDate(S.fbDate));
  else if(S.fbMonth) bits.push(monthLabel(S.fbMonth));
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.filter(Boolean);
}
function fbFilterNote(){
  const bits=fbFilterBits();
  return bits.length ? " \u00b7 "+bits.join(" \u00b7 ") : "";
}
function exportFilterNote(){
  const bits=[];
  if(S.exportDate){
    const p=String(S.exportDate).split("-");
    if(p.length===3) bits.push((+p[2])+"/"+(+p[1])+"/"+p[0]);
  }else{
    const d=expDay(); if(d!=null) bits.push(t("days")[d]||"");
  }
  const sl=expSlot(); if(sl) bits.push(t(sl+"Part"));
  return bits.length ? " · "+bits.join(" · ") : "";
}
function exportMonthOptions(){
  const out=[]; const d=hotelNow(); d.setDate(1);
  for(let i=0;i<18;i++){
    const mk=d.toISOString().slice(0,7);
    out.push([mk, monthLabel(mk)]);
    d.setMonth(d.getMonth()-1);
  }
  return out;
}
function exportTitle(sets){
  const hotel=(S.settings && S.settings.name) || "";
  const onlyAtt = sets.length===1 && sets[0].signatures;
  return onlyAtt ? (t("officialAtt").replace("{hotel}", hotel).trim())
                 : (hotel+" — "+t("exportData"));
}
function openExportModal(){
  let picked=new Set(["guests"]);
  S.fbMonth=""; S.fbDate="";          // the month picker here belongs to attendance

  const wrap=baseModal(`
    <h3>${ic("download",20)} ${t("exportData")}</h3>
    <p class="mini" style="margin-bottom:10px">${t("exportWhat")}</p>
    <div class="explist">
      ${EXPORT_KINDS.map(k=>`<label class="exp-it"><input type="checkbox" data-exp="${k}" ${k==="guests"?"checked":""}> <span>${exportKindLabel(k)}</span></label>`).join("")}
      <label class="exp-it exp-all"><input type="checkbox" id="exp-all"> <span>${t("expAll")}</span></label>
    </div>
    <div id="exp-month-row" style="display:none">
      <label style="margin-top:12px">${t("whichMonth")}</label>
      <select id="exp-month">
        ${exportMonthOptions().map(([mk,lb])=>`<option value="${mk}" ${mk===(S.exportMonth||currentAttMonth())?"selected":""}>${esc(lb)}</option>`).join("")}
      </select>
    </div>
    <div class="row2" style="margin-top:12px">
      <div><label>${t("whichDay")}</label>
        <select id="exp-day">
          <option value="">${t("allDays")}</option>
          ${t("days").map((d,i)=>`<option value="${i}" ${String(S.exportDay)===String(i)?"selected":""}>${esc(d)}</option>`).join("")}
        </select></div>
      <div><label>${t("whichTime")}</label>
        <select id="exp-slot">
          <option value="">${t("allDayLong")}</option>
          ${["morning","afternoon","evening"].map(k=>`<option value="${k}" ${S.exportSlot===k?"selected":""}>${t(k+"Part")}</option>`).join("")}
        </select></div>
    </div>
    <p class="mini" id="exp-note" style="margin-top:6px"></p>
    <button class="btn" id="exp-xlsx">${ic("download",16)} ${t("exportExcel")}</button>
    <button class="btn ghost" id="exp-pdf">${ic("download",16)} ${t("exportPdf")}</button>
    <button class="btn ghost" id="exp-x">${t("close")}</button>`);
  const boxes=[...wrap.querySelectorAll("[data-exp]")];
  const monthRow=wrap.querySelector("#exp-month-row");
  const monthSel=wrap.querySelector("#exp-month");
  const showMonth=()=>{ if(monthRow) monthRow.style.display = picked.has("monthatt") ? "" : "none"; };
  const sync=()=>{ picked=new Set(boxes.filter(b=>b.checked).map(b=>b.dataset.exp)); showMonth(); };
  if(monthSel) monthSel.onchange=()=>{ S.exportMonth=monthSel.value; };
  const daySel=wrap.querySelector("#exp-day"), slotSel=wrap.querySelector("#exp-slot");
  const note=wrap.querySelector("#exp-note");
  const applyFilters=()=>{
    if(daySel)  S.exportDay  = daySel.value;
    if(slotSel) S.exportSlot = slotSel.value;
    if(note) note.textContent = (S.exportDay==="" && !S.exportSlot)
      ? t("noFilterNote") : t("filterNote")+exportFilterNote().replace(/^ · /," ");
  };
  if(daySel)  daySel.onchange=applyFilters;
  if(slotSel) slotSel.onchange=applyFilters;
  applyFilters();
  boxes.forEach(b=>b.onchange=sync);
  sync();
  wrap.querySelector("#exp-all").onchange=e=>{ boxes.forEach(b=>{b.checked=e.target.checked;}); sync(); };
  wrap.querySelector("#exp-x").onclick=()=>wrap.remove();
  const gather=()=>{
    if(monthSel) S.exportMonth=monthSel.value;      // whichever month she chose
    applyFilters();                                  // and the day / time she ticked
    return EXPORT_KINDS.filter(k=>picked.has(k)).map(buildDataset).filter(Boolean);
  };
  const fname="entertainment-data-"+todayISO();
  wrap.querySelector("#exp-xlsx").onclick=async ()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    await exportExcelSets(sets,fname); toast(t("saved"));
  };
  wrap.querySelector("#exp-pdf").onclick=()=>{
    sync(); const sets=gather(); if(!sets.length) return;
    exportPdfSets(sets, exportTitle(sets)); wrap.remove();
  };
}
async function exportReport(){
  const weekAgo=Date.now()-7*864e5;
  const weekTasks=S.tasks.filter(x=>!x.created_at||Date.parse(x.created_at)>=weekAgo);
  const rank=rankingRows().map((r,i)=>[i+1,r.u.display_name||r.u.username,r.done,r.late,r.cant,r.open,r.points]);
  const taskRows=weekTasks.map(x=>[String(x.created_at||"").slice(0,16).replace("T"," "),taskTypeLabel(x.type),x.title,
    x.assigned_to?((S.users.find(u=>u.username===x.assigned_to)||{}).display_name||x.assigned_to):t("allTeam"),
    x.location||"",String(x.due||"").replace("T"," "),
    x.status==="done"?(x.was_still?t("done")+" ("+t("late")+")":t("done")):x.status==="cant"?t("cantDo"):x.status==="still"?t("still"):x.status==="accepted"?t("accepted"):t("statusNew")]);
  const fbRows=S.feedback.filter(f=>!f.created_at||Date.parse(f.created_at)>=weekAgo)
    .map(f=>[String(f.created_at||"").slice(0,16).replace("T"," "),f.room,f.nationality||"",f.rate,f.comment||"",f.by_user||""]);
  const fname="entertainment-report-"+todayISO();
  const ok=await loadXLSX();
  if(ok){
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank]),"Ranking");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows]),"Tasks");
    XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]),"Feedback");
    XLSX.writeFile(wb,fname+".xlsx");
  } else {
    const csv=[["RANKING"],["#",t("displayName"),t("done"),t("late"),t("cantDo"),t("statusNew"),t("points")],...rank,[],
      ["TASKS"],["Date",t("taskType"),t("actName"),t("taskFor"),t("location"),t("dueLbl"),"Status"],...taskRows,[],
      ["FEEDBACK"],["Date",t("room"),t("nationality"),t("rate"),t("comment"),t("user")],...fbRows]
      .map(r=>r.map(c=>'"'+String(c??"").replace(/"/g,'""')+'"').join(";")).join("\n");
    downloadBlob(fname+".csv",new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}));
  }
  toast(t("saved"));
}
function attendanceInner(){
  const todayIdx=todayIndex(), date=todayISO();
  const acts=S.activities.filter(a=>a.day===todayIdx).sort((x,y)=>x.time.localeCompare(y.time));
  return `<p class="mini" style="margin-bottom:10px">${t("today")} · ${t("days")[todayIdx]}</p>`
    + (acts.length?`<div class="card">${acts.map(a=>{
      const bks=bookingsFor(a.id).filter(b=>b.status==="booked");
      const pres=bks.filter(b=>S.attendance.some(x=>x.booking_id===b.id&&x.date===date)).length;
      return `<div class="booking-line"><span>${esc(a.name)} <span class="mini">· ${esc(a.time)}</span></span>
        <span class="pill">${pres}/${bks.length} ${t("present")}</span></div>`;
    }).join("")}</div>`:`<div class="empty"><div class="big">${ic("pin",30)}</div>${t("noneToday")}</div>`);
}
/* Settings is a hub of small pages, not one long form. */
const SETTINGS_GROUPS=[
  {head:"secLook", items:[
    ["set:theme","palette","setTheme","setThemeSub"],
    ["set:publictext","sparkle","Public experience","Explore & sign-in text"],
    ["set:brand","sparkle","setBrand","setBrandSub"],
    ["builder","grid","setMenus","setMenusSub"]]},
  {head:"secManage", items:[
    ["set:features","check","setFeatures","setFeaturesSub"],
    ["set:notif","bell","setNotif","setNotifSub"],
    ["set:links","star","setLinksT","setLinksSub"],
    ["bus","bus","busItem","busItem"]]},
  {head:"secSettings", items:[
    ["set:location","pin","setLocation","setLocationSub"],
    ["export","download","setData","setDataSub"],
    ["set:advanced","grid","setAdvanced","setAdvancedSub"]]}
];
function settingsHubView(){
  return `<div class="screen fadein">
    ${topBar(t("settingsHub"),S.session.name)}
    <p class="mini" style="margin:-4px 0 16px">${t("settingsSub")}</p>
    ${arrangeBtn("settings")}
    ${SETTINGS_GROUPS.map(g=>{
      const ord=pageOrder("settings");
      const items=g.items.filter(it=>ord.includes(it[0])).sort((a,b)=>ord.indexOf(a[0])-ord.indexOf(b[0]));
      if(!items.length) return "";
      return `
      <div class="set-sec">${t(g.head)}</div>
      <div class="card set-list">
        ${items.map(([id,icn,lb,sub])=>`<button class="set-it" data-hub="${id}">
          <span class="set-ic">${ic(icn,19)}</span>
          <span class="set-mid"><b>${esc(t(lb))}</b>${sub&&sub!==lb?`<span class="mini">${esc(t(sub))}</span>`:""}</span>
          <span class="set-go">${ic("back",16)}</span>
        </button>`).join("")}
      </div>`;}).join("")}
  </div>`;
}
function setThemeView(){
  const st=S.settings;
  const fontOpts=[["elegant",t("fontElegant")],["royal",t("fontRoyal")],["modern",t("fontModern")],["soft",t("fontSoft")]];
  const btnOpts=[["rounded",t("btnRounded")],["pill",t("btnPill")],["square",t("btnSquare")]];
  return `<div class="screen fadein">
    ${topBar(t("setTheme"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("themeHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("themeHint")}</p>
      <div class="theme-grid">
        ${paletteList().map(k=>{
          const p=PALETTES[k], c=p.light;
          return `<button class="theme-card ${st.palette===k?"on":""}" data-palette="${k}">
            <span class="tc-sw"><i style="background:${c.primary}"></i><i style="background:${c.accent}"></i><i style="background:${c.bg};border:1px solid ${c.line}"></i></span>
            <span class="tc-lb">${esc(p.label)}</span></button>`;
        }).join("")}
        <button class="theme-card ${!PALETTES[st.palette]?"on":""}" data-palette="custom">
          <span class="tc-sw"><i style="background:${esc(st.primary)}"></i><i style="background:${esc(st.accent)}"></i><i style="background:${esc(st.bg)};border:1px solid var(--line)"></i></span>
          <span class="tc-lb">${t("themeCustom")}</span></button>
      </div>
      <label style="margin-top:14px">${t("fontSizeLbl")}</label>
      <select id="s-fs">
        ${[["small","fsSmall"],["normal","fsNormal"],["large","fsLarge"],["xl","fsXl"]].map(([k,lb])=>
          `<option value="${k}" ${(st.fontScale||"normal")===k?"selected":""}>${t(lb)}</option>`).join("")}
      </select>
      <label style="display:flex;align-items:center;gap:8px;text-transform:none;font-size:15px;color:var(--ink);margin-top:10px">
        <input id="s-autodark" type="checkbox" style="width:auto" ${st.autoDark?"checked":""}> ${t("autoDarkLbl")}</label>

      <label>${t("colorsHead")}</label>
      <div class="row2">
        <div><label style="margin-top:0">${t("primaryC")}</label><input id="s-primary" type="color" value="${esc(st.primary)}"></div>
        <div><label style="margin-top:0">${t("accentC")}</label><input id="s-accent" type="color" value="${esc(st.accent)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("bgC")}</label><input id="s-bg" type="color" value="${esc(st.bg)}"></div>
        <div><label>${t("textC")}</label><input id="s-text" type="color" value="${esc(st.textColor)}"></div>
      </div>
      <div class="row2">
        <div><label>${t("navC")}</label><input id="s-navbg" type="color" value="${esc(st.navBg)}"></div>
        <div><label>${t("navActiveC")}</label><input id="s-navon" type="color" value="${esc(st.navActive)}"></div>
      </div>
      <label>${t("styleHead")}</label>
      <select id="s-font">${fontOpts.map(([v,l])=>`<option value="${v}" ${st.fontStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <label>${t("buttonHead")}</label>
      <select id="s-btn">${btnOpts.map(([v,l])=>`<option value="${v}" ${st.buttonStyle===v?"selected":""}>${l}</option>`).join("")}</select>
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setBrandView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setBrand"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("secIdentity")}</label>
      <div class="photo-pick"><div class="photo-box" data-photobox></div>
        <div class="pp-txt"><b>${t("logoLbl")}</b><span class="mini">${t("logoHint")}</span></div>
        <input type="file" accept="image/*" data-photoinput hidden></div>
      <input id="s-logo" type="hidden" value="${esc(st.logo||"")}">
      ${st.logo?`<button class="btn sm ghost" id="s-logo-rm" type="button" style="margin-bottom:10px">${ic("trash",14)} ${t("removeLogo")}</button>`:""}
      <input id="s-hotel" value="${esc(st.hotelName||"")}" placeholder="${esc(t("hotelNameLbl"))}" style="margin-bottom:8px">
      <input id="s-contact" value="${esc(st.contact||"")}" placeholder="${esc(t("contactLbl"))}" style="margin-bottom:8px">
      <input id="s-cur" value="${esc(st.currency||"")}" placeholder="${esc(t("currencyLbl"))}" style="margin-bottom:8px">
      <label style="margin-top:16px">${t("appName")}</label><input id="s-name" value="${esc(st.name)}">
      <label>${t("appSubtitle")}</label><input id="s-sub" value="${esc(st.subtitle)}" placeholder="${t("appSub")}">
      <label>${t("welcomeMsgLbl")}</label><textarea id="s-welcome" rows="2">${esc(st.welcomeMsg)}</textarea>
      <label>${t("menuHead")}</label>
      <input id="s-mhome" value="${esc(st.menuHome)}" placeholder="${t("home")}" style="margin-bottom:8px">
      <input id="s-mprog" value="${esc(st.menuProgram)}" placeholder="${t("program")}" style="margin-bottom:8px">
      <input id="s-mtick" value="${esc(st.menuTickets)}" placeholder="${t("tickets")}" style="margin-bottom:8px">
      <input id="s-mchat" value="${esc(st.menuChat)}" placeholder="${t("chat")}" style="margin-bottom:8px">
      <input id="s-mstay" value="${esc(st.menuStay)}" placeholder="${t("myStay")}">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setFeaturesView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setFeatures"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:16px">${t("featuresLbl")}</label>
      <div class="feat-list">
        ${[["quiz","featQuiz"],["tickets","featTickets"],["gallery","featGallery"],["bus","featBus"],["hotelinfo","featInfo"],["weather","weatherTab"]].map(([k,lb])=>
          `<label class="feat-it"><input type="checkbox" class="feat-cb" value="${k}" ${featureOn(k)?"checked":""}> ${t(lb)}</label>`).join("")}
      </div>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLocationView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLocation"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("weatherLoc")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("weatherLocHint")}</p>
      <div class="row2">
        <div><input id="s-lat" value="${esc(st.lat||"")}" placeholder="27.2579" inputmode="decimal"></div>
        <div><input id="s-lon" value="${esc(st.lon||"")}" placeholder="33.8116" inputmode="decimal"></div>
      </div>
      <label>${t("timezoneLbl")}</label>
      <p class="mini" style="margin:-4px 0 6px">${t("timezoneHint")}</p>
      <select id="s-tz">${TIMEZONES.map(z=>`<option value="${esc(z)}" ${(st.timezone||"")===z?"selected":""}>${z||"—"}</option>`).join("")}</select>

      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setLinksView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setLinksT"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label>${t("linksHead")}</label>
      <input id="s-trip" value="${esc(st.tripadvisor)}" placeholder="Tripadvisor URL" style="margin-bottom:8px">
      <input id="s-goog" value="${esc(st.google)}" placeholder="Google URL" style="margin-bottom:8px">
      <input id="s-holi" value="${esc(st.holidaycheck)}" placeholder="HolidayCheck URL">
      <label>${t("socialHead")}</label>
      <input id="s-insta" value="${esc(st.instagram)}" placeholder="Instagram URL" style="margin-bottom:8px">
      <input id="s-tiktok" value="${esc(st.tiktok)}" placeholder="TikTok URL" style="margin-bottom:8px">
      <input id="s-fb" value="${esc(st.facebook)}" placeholder="Facebook URL" style="margin-bottom:8px">
      <input id="s-yt" value="${esc(st.youtube)}" placeholder="YouTube URL" style="margin-bottom:8px">
      <label style="margin-top:4px">${t("whatsappLbl")}</label>
      <input id="s-wa" value="${esc(st.whatsapp)}" placeholder="+20 100 000 0000" inputmode="tel">
      <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setAdvancedView(){
  const st=S.settings;
  return `<div class="screen fadein">
    ${topBar(t("setAdvanced"),S.session.name)}
    ${hubBack()}
    <div class="card" style="padding:16px">
      <label style="margin-top:10px">${t("serverHead")}</label>
      <p class="mini" style="margin:-4px 0 8px">${t("serverHint")}</p>
      <input id="s-aiep" value="${esc(st.aiEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/ai-assistant" style="margin-bottom:8px">
      <input id="s-pushep" value="${esc(st.pushEndpoint||"")}" placeholder="https://xxxx.supabase.co/functions/v1/send-push">
            <button class="btn" id="btn-savesettings">${t("save")}</button>
    </div>
  </div>`;
}
function setNotifView(){
  return `<div class="screen fadein">
    ${topBar(t("setNotif"),S.session.name)}
    ${hubBack()}
    <div class="card notif-card" id="notif-toggle">
      <div class="nt-l"><span class="nt-ic">${ic(notifSoundOn()?"bell":"belloff",20)}</span>
        <div><b>${t("notifSound")}</b><p class="mini">${t("enableNotif")}</p></div></div>
      <span class="switch ${notifSoundOn()?"on":""}"><span class="knob"></span></span>
    </div>
  </div>`;
}

