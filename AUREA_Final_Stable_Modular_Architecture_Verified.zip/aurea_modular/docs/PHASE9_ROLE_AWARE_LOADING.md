# AUREA Phase 9 — Role-Aware Data Loader Design

## Status

Prepared but NOT activated.

The active configuration remains:

```js
DATA_LOAD_MODE: "legacy_full"
```

This means startup and polling continue to request the same data sets as Phase 8.

## What changed

`js/database/data-loader.js` is now the canonical read-loading boundary.

`DB.load()` and `DB.poll()` delegate to it instead of owning their own parallel query lists.

This gives the app one place to later enforce role-aware data loading.

## Current active profile

`legacy_full`

It intentionally preserves the existing startup dataset because the legacy login still depends on browser-loaded identity data.

## Prepared profiles

The file also contains draft profiles for:

- bootstrap
- guest
- staff
- manager

and draft polling profiles for the same contexts.

These are planning profiles only. Phase 9 contains a hard runtime safety guard that throws if `DATA_LOAD_MODE` is changed away from `legacy_full`.

## Why activation is blocked

Role-aware loading must not be activated until all of these are true:

1. Supabase Auth staff identities are proven in staging.
2. RLS policies exist and have been tested.
3. Guest identity/current-stay ownership is finalized.
4. Realtime subscriptions are filtered by authenticated role/stay.
5. Login no longer depends on unrestricted `app_users` loading.
6. UI dependencies have been regression-tested against reduced datasets.

## Important remaining issue

Realtime currently subscribes broadly to public table changes. Even if startup loading becomes role-aware, realtime must also become role-aware before strict RLS is activated.

That should be handled in the next safe architecture phase.
