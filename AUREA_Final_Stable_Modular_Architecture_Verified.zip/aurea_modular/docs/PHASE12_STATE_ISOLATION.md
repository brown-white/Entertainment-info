# AUREA Phase 12 — Sensitive-State Isolation

## Status

Active only for transient UI/session cleanup.

```js
STATE_ISOLATION_MODE: "legacy_transient"
```

This mode clears temporary UI residue when identity changes, but deliberately retains database-backed arrays because the legacy login flow still depends on preloaded `app_users`, `guest_accounts`, and `rooms`.

## Canonical boundary

`js/auth/state-isolation.js`

## Transient state cleared on identity change/logout

Examples include:
- chatRoom
- aiChat
- CRM search text
- open drawer state
- purchase-builder/editing state
- assignment editor day
- open-day UI state
- chat selection
- export selections
- attendance month selection
- current operation/category filters

These values are not needed to authenticate another user and are safe to reset.

## Database-backed state deliberately retained in Phase 12

### Guest/stay-sensitive
- bookings
- ticket orders
- guest accounts
- messages
- requests
- quiz replies
- rooms

### Team/management-sensitive
- app users
- attendance
- feedback
- staff attendance
- staff requests
- tasks

### Shared/read-mostly
- activities
- tickets
- announcements
- team profiles
- buses
- quizzes
- photos

## Why sensitive arrays are not wiped yet

The current legacy login still validates:
- Manager/Entertainer against `S.users`
- Guest against `S.accounts`
- Guest room activity against `S.rooms`

Wiping those arrays on logout before role-aware bootstrap/authentication is active would make subsequent login fail.

## Future scoped mode

A future `scoped_active` mode is prepared conceptually, but Phase 12 hard-blocks sensitive database-state wiping unless that mode is deliberately enabled after:

1. Supabase Auth is active in staging.
2. Bootstrap/login no longer requires unrestricted staff/guest tables.
3. Role-aware data loading is active.
4. Realtime subscriptions rebuild per identity.
5. RLS is proven.
6. Guest current-stay ownership is enforced at database level.

## Local persistence audit

The main `persist()` function stores only:
- language
- theme
- favorites
- seen-note marker
- remember flag
- session metadata

It does not persist the large database arrays to `localStorage`.

That reduces cross-session persistence risk, but in-memory isolation is still needed for future same-tab role changes.
