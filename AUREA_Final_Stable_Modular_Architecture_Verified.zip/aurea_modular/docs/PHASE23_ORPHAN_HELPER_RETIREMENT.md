# AUREA Phase 23 — Orphan Planner Helper Retirement

## Scope

Phase 23 removes exactly two orphaned helpers from:

`js/planner/assignment-engine.js`

Removed:
- `fixRepeats()`
- `balancePlan()`

No other planner function is changed.

## Why these two were safe candidates

After Phase 22 retired the old base `autoAssignDay()` / `autoAssignWeek()`
implementations, a full active-JavaScript usage audit found:

- `fixRepeats` — definition only, zero callers
- `balancePlan` — definition only, zero callers

They were therefore dead base helpers.

## What was NOT removed

`planBalance()` remains active and is explicitly preserved.

It is still consumed by the Smart Planner UI, including canonical V6.24 and the
older compatibility layer.

The following helpers also remain because they still participate in active
runtime or compatibility behavior:

- `baseLoad`
- `bumpLoad`
- `loadOf`
- `repeatPenalty`
- `pickFairest`
- `eventsCrew`
- `assignableStaff`
- `activitySlot`
- `assignDateStr`

Base `applyAssignments()` also remains untouched.

## Exact-delta safety

The complete Phase 22 version of `assignment-engine.js` is preserved at:

`phase23_rollback/js/planner/assignment-engine.js`

The Phase 23 verifier reconstructs the current file from that rollback by
replacing only the `fixRepeats` + `balancePlan` block with the Phase 23
retirement marker.

This proves there was no unrelated edit to the engine.

## Safety posture

Unchanged:

- `AUTH_MODE = legacy`
- `DATA_LOAD_MODE = legacy_full`
- `REALTIME_MODE = legacy_broad`
- `SESSION_LIFECYCLE_MODE = legacy_observe`
- `STATE_ISOLATION_MODE = legacy_transient`
- `PLANNER_MODE = compat_v624`
- `PLANNER_APPLY_MODE = legacy_sequential`
- `PLANNER_CONCURRENCY_MODE = local_snapshot`

No database, Auth, RLS, realtime, planner generation, validation, concurrency,
or persistence behavior is changed.
