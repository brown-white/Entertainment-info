# AUREA — Supabase RLS Migration Plan

## Status

NOT IMPLEMENTED in Phase 6.

The current frontend still uses a browser-side account directory for staff/manager authentication.
Because Supabase does not yet receive a trusted authenticated role identity for those users, applying role-sensitive RLS now could lock valid users out or create unsafe workarounds.

## Required order

1. Keep Phase 6 application permissions as the behavioral source of truth.
2. Introduce Supabase Auth for Manager and Entertainer accounts.
3. Map authenticated `auth.uid()` values to an application profile containing role and active status.
4. Decide how hotel Guests receive an authenticated identity for a stay.
5. Add RLS table-by-table.
6. Test Guest, Entertainer and Manager separately on staging.
7. Only then remove readable legacy password fields.

## Intended policy direction

### Public/program data
Activities, Events, Shows, Live Music, ticket-event definitions and safe hotel entertainment information:
- authenticated Guest: SELECT
- authenticated Entertainer: SELECT
- authenticated Manager: SELECT/INSERT/UPDATE/DELETE where appropriate

### Guest-owned operational data
Bookings, ticket orders, guest requests, guest chat:
- Guest: SELECT/INSERT/UPDATE/DELETE only when the row belongs to the authenticated current stay
- Entertainer: only the minimum operational subset needed for assigned duties
- Manager: operational management access

Room number alone must not be the ownership key because rooms are reused between stays.

### Team/manager data
Users, assignments, attendance, payroll/configuration/settings:
- Guest: no access
- Entertainer: own/minimum necessary rows
- Manager: management access

### Sensitive configuration
Secrets and private credentials must never be readable through browser-accessible tables.

## Critical prerequisite

Do not copy the Phase 6 JavaScript matrix directly into SQL until the identity model is migrated.
RLS must derive authorization from trusted Supabase identity / server-side claims, not values supplied by the browser.
