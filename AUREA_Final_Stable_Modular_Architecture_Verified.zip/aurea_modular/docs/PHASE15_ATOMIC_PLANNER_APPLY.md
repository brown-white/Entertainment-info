# AUREA Phase 15 — Atomic Planner Apply Architecture

## Status

Prepared only. Not activated.

Active configuration:

```js
PLANNER_APPLY_MODE: "legacy_sequential"
```

`PLANNER_ATOMIC_RPC_DEPLOYED` is intentionally absent.

Therefore the current successful production path remains:

Planner UI
→ `AUREA_PLANNER.apply()`
→ `AUREA_PLANNER_APPLY.apply()`
→ legacy `window.applyAssignments()`
→ V6.24 validation
→ V6.22 validation
→ sequential `DB.saveActivity()`

## New boundary

`js/planner/planner-apply-service.js`

It owns the planner persistence strategy selection without changing the planner
generation algorithm or hard-rule engine.

### Active path

`legacy_sequential`

Delegates to the exact pre-Phase-15 `window.applyAssignments()` chain.

### Prepared future path

`rpc_atomic`

Prepared code can call:

`POST /rest/v1/rpc/aurea_apply_planner_assignments_atomic`

through the existing authenticated `sb()` helper.

It cannot activate in Phase 15 unless ALL of these are true:

1. `PLANNER_APPLY_MODE === "rpc_atomic"`
2. `AUTH_MODE === "supabase_staff"`
3. a real Supabase Auth access token exists
4. remote database mode is active
5. current application permission allows `planner.manage`
6. `CONFIG.PLANNER_ATOMIC_RPC_DEPLOYED === true`

Phase 15 does not set the sixth flag.

## Why a Database Function / RPC

The current client writes multiple activities one after another. The browser
cannot group those separate requests into one database transaction.

The future RPC should receive the full assignment set in one database call,
lock/validate the target rows, and either complete the intended set or fail.

## Server-side validation requirement

Atomicity alone is not enough.

A future database function must not blindly trust browser validation. Before
committing it should authorize the caller and re-check authoritative planner
constraints using database state.

At minimum the final design must cover:

- active Manager identity
- current target rows / concurrency
- Day Off
- Vacation
- Absent
- employment status
- Entrance Duty
- I can / I can't
- configured gender
- DJ restrictions
- overlap
- one activity per operation

## Concurrency

The prepared payload includes:

- activity ID
- selected username
- expected current entertainer
- day
- slot

The intended future function can use the expected value for optimistic
concurrency and lock the target activity rows before applying updates.

This prevents one Manager's stale plan from silently overwriting another
Manager's newer changes.

## SQL safety

`supabase/phase15/10_ATOMIC_PLANNER_RPC_TEMPLATE.sql.example`

is architecture documentation only.

The entire file is inside a SQL block comment and uses `.sql.example`, so
Phase 15 does not install, replace, grant, revoke, or execute any database
function.

## Activation sequence

Do not activate `rpc_atomic` directly in production.

Recommended staging order:

1. complete staff Supabase Auth mapping
2. enable/test Manager identity in staging
3. finalize RLS
4. implement server-side planner validation
5. install RPC in staging
6. run concurrency + rollback tests
7. run Phase 14 planner rule tests
8. compare legacy vs RPC results
9. explicitly set the deployment flag only after approval
