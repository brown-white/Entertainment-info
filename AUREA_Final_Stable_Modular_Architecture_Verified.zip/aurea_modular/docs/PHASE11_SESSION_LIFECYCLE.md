# AUREA Phase 11 — Session Lifecycle Orchestration

## Status

Prepared, observable, and backward-compatible.

The active mode remains:

```js
SESSION_LIFECYCLE_MODE: "legacy_observe"
```

This mode records session transitions only. It does NOT:
- reload data
- rebuild realtime subscriptions
- change authentication
- change RLS
- change current login behavior
- add extra network requests

## New boundary

`js/auth/session-lifecycle.js`

It receives normalized lifecycle events from:
- staff login
- guest login
- logout
- restored-session validation
- invalid/expired session removal
- anonymous boot
- future Supabase Auth token refresh

## Current lifecycle event examples

- `staff-login`
- `guest-login`
- `logout`
- `session-refresh`
- `session-invalid`
- `boot-anonymous`
- `auth-token-refresh`

## Why this boundary exists

Future secure mode will need one coordinated place to decide what happens when identity changes:

1. authenticate / validate identity
2. stop obsolete realtime subscriptions
3. clear role-sensitive state
4. load the permitted dataset for the new role/current stay
5. start the matching authenticated realtime subscriptions
6. render the correct landing screen

Phase 11 does NOT activate those actions. It only creates the transition boundary.

## Future transition plan

### Anonymous -> Guest
- validate exact current stay
- clear stale staff/guest-sensitive state
- load Guest-scoped data
- subscribe to Guest/current-stay realtime
- render Guest home

### Anonymous -> Entertainer
- verify Supabase Auth identity
- map `auth.uid()` to `app_users`
- load Entertainer-scoped data
- subscribe to Entertainer realtime
- render Today

### Anonymous -> Manager
- verify Supabase Auth identity
- map `auth.uid()` to active Manager
- load Manager data
- subscribe to Manager realtime
- render Dashboard

### Authenticated -> Logout
- unsubscribe authenticated realtime
- clear sensitive state
- clear Auth token/session
- return to bootstrap/anonymous dataset
- render login/public state

### Token refresh
- keep the same application identity
- update authenticated transport
- confirm realtime remains authorized
- do not duplicate subscriptions

## Activation gates

Do not change `SESSION_LIFECYCLE_MODE` until:
- Supabase Auth works in staging
- role-aware data loading is intentionally enabled
- scoped realtime lifecycle supports unsubscribe/rebuild
- RLS is verified
- Guest current-stay identity is finalized
- role transition tests pass
