# AUREA Phase 19 — Legacy Planner Runtime Reference Retirement

## Goal

Stop loading the old V6.22/V6.24 planner files in the live browser while
preserving those files unchanged for rollback and byte-level comparison.

## Runtime change

Removed from `index.html`:

- `js/legacy/23-aurea-smart-assignment-v622-script.js`
- `js/legacy/24-aurea-smart-plans-v624-script.js`

The files themselves are NOT deleted.

## Active planner runtime

The live planner chain is now:

1. `js/planner/assignment-engine.js`
2. `js/planner/smart-assignment-v622.js`
3. `js/planner/smart-plans-v624.js`
4. `js/planner/planner-concurrency.js`
5. `js/planner/planner-apply-service.js`
6. `js/planner/planner-service.js`

The canonical V6.22 and V6.24 files remain byte-for-byte equal to the preserved
legacy files.

## Why this is safe

Phases 17 and 18 already proved that:
- canonical V6.22 is byte-identical to legacy V6.22
- canonical V6.24 is byte-identical to legacy V6.24
- the legacy one-time guards made the second copies inert
- planner rule regressions passed with canonical ownership

Phase 19 therefore removes only redundant browser loading.

## What remains preserved

These files remain in the package:

- `js/legacy/23-aurea-smart-assignment-v622-script.js`
- `js/legacy/24-aurea-smart-plans-v624-script.js`

They remain available for:
- rollback
- audit
- exact diff/hash comparison
- historical reference

`phase19_rollback/` also contains the pre-Phase-19 `index.html` and affected
verification files.

## Regression test migration

Older phase verifiers were updated only where they previously assumed the
legacy filenames were active runtime files. They now validate the canonical
runtime locations.

Extraction-specific tests still load the preserved legacy files deliberately
to prove their byte equality and one-time guard behavior.

## No behavior changes

Phase 19 does not alter:
- V6.22 hard rules
- V6.24 Plan A/B/C generation
- persistence
- stale-plan protection
- atomic RPC status
- authentication
- RLS
- realtime
- database schema
