# AUREA Phase 21 — Base Smart Planner Modal Retirement

## Scope

Phase 21 retires exactly one superseded implementation:

`openAutoAssignModal()` from `js/planner/assignment-engine.js`

No other planner function is removed or rewritten.

## Why this function was selected

Phase 20 identified the base modal as a cleanup candidate because the final
runtime owner is V6.24:

`js/planner/smart-plans-v624.js`

A full source audit confirmed:
- the base engine contains the old modal body
- canonical V6.24 defines the final `window.openAutoAssignModal`
- `AUREA_PLANNER.open()` calls the final global modal
- no active module captures or invokes the base body
- the older V5 compatibility layer also replaces the modal before V6.24, so
  removing the original base declaration does not remove the final runtime API

## Exact change

The 75-line base modal body was removed and replaced with a short retirement
marker.

The exact original file is preserved at:

`phase21_rollback/js/planner/assignment-engine.js`

The Phase 21 verifier reconstructs the new engine from that rollback file and
proves that the only runtime change is replacement of the audited modal block.

## Explicitly unchanged

Phase 21 does not change:

- base `applyAssignments`
- V6.22 hard-rule wrapper
- V6.24 final apply wrapper
- V6.22 planner generation
- V6.24 Plan A/B/C generation
- `eventsCrew`
- `assignableStaff`
- `activitySlot`
- `planBalance`
- `assignDateStr`
- `activityType` (still provided by the active V5 compatibility layer)
- planner concurrency
- planner persistence strategy
- atomic RPC activation
- Supabase Auth
- RLS
- database schema
- realtime
- data loading

## Runtime ownership after Phase 21

The live Smart Planner modal remains:

`window.openAutoAssignModal` from `js/planner/smart-plans-v624.js`

The canonical facade remains:

`AUREA_PLANNER.open(day)`

## Historical Phase 20 hash lock

Phase 20 intentionally recorded a hash of the pre-cleanup runtime.

Because Phase 21 deliberately changes `assignment-engine.js`, the old Phase 20
hash baseline is now historical evidence rather than a current-runtime
invariant. Phase 21 therefore uses a stronger exact-delta verifier against its
own rollback copy.

## Safety verification

`tests/verify_phase21_base_modal_retirement.py` verifies:

- no base modal declaration remains
- canonical V6.24 modal remains
- only the audited modal block changed in `assignment-engine.js`
- base persistence remains present
- shared planner helpers remain present
- canonical load order remains unchanged
- no unexpected active source depends on the removed base body
- all conservative safety modes remain unchanged
- all active JavaScript parses
