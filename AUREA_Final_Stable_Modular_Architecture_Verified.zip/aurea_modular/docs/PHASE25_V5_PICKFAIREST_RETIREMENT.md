# AUREA Phase 25 — V5 `pickFairest` Retirement

## Scope

Phase 25 audits the V5 compatibility layer and retires exactly one V5 override:

- `window.pickFairest`

No other V5 behavior is removed.

## Why only this override

The ownership audit found that V5 contains a mixture of:
- superseded planner overrides
- chained wrappers still required by later code
- feedback/UI functions that remain final or relevant runtime owners

This means the V5 file is not safe to retire as a unit.

`pickFairest` is a clean candidate because:
1. V5 replaces `window.pickFairest`
2. no later module captures the V5 implementation
3. canonical V6.22 replaces `window.pickFairest` again
4. final live planner behavior therefore comes from V6.22

## Important blockers discovered

`openEditModal` cannot be removed from V5:
- V6.22 captures `window.openEditModal` as `oldEdit622`
- V6.22 calls that captured implementation before adding its own gender UI
- removing the V5 wrapper would lose the V5 activity-style UI

`bumpLoad` also cannot be removed:
- V5 captures the previous `window.bumpLoad` as `oldBump`
- the V5 wrapper extends the load object with activity-type counts

Several V5 feedback functions remain active and were not touched.

## Exact-delta verification

The original Phase 24 V5 file is preserved at:

`phase25_rollback/js/legacy/05-aurea-v5-smart-plans.js`

The Phase 25 verifier reconstructs the new V5 file from that rollback and proves
that only the V5 `pickFairest` block was replaced by the retirement marker.

## Explicitly unchanged

- V6.22 hard rules
- V6.24 plan generation
- planner persistence
- stale-plan protection
- database schema
- Auth
- RLS
- realtime
- data loading
- feedback behavior
- V5 activity-style editor behavior

## Safety modes

All remain unchanged:
- AUTH_MODE = legacy
- DATA_LOAD_MODE = legacy_full
- REALTIME_MODE = legacy_broad
- SESSION_LIFECYCLE_MODE = legacy_observe
- STATE_ISOLATION_MODE = legacy_transient
- PLANNER_MODE = compat_v624
- PLANNER_APPLY_MODE = legacy_sequential
- PLANNER_CONCURRENCY_MODE = local_snapshot
