# AUREA Phase 16 — Planner Concurrency / Stale-Plan Protection

## Status

Active as a local preflight only.

```js
PLANNER_CONCURRENCY_MODE: "local_snapshot"
```

This mode does not:
- add a database column
- lock database rows
- make extra network requests
- activate the Phase 15 atomic RPC
- change the planner generation algorithm
- change authentication or RLS

## Why this is needed

A Manager can generate Plan A/B/C and leave the modal open.

While that plan is open:
- realtime can update programme assignments
- another Manager can change an assignment
- attendance can change
- Day Off / Entrance Duty can change
- capability/gender configuration can change

Applying the old plan after those changes could overwrite newer decisions or
apply a plan generated under outdated eligibility rules.

## How Phase 16 works

`js/planner/planner-concurrency.js`

When V6.24 creates Plan A/B/C, each plan receives a hidden in-memory snapshot.

The snapshot covers planner-relevant state:

### Programme
All activities, including:
- id
- name
- day
- time
- category
- current entertainer
- gender requirement fields
- skill requirement
- duration / end time / sets where available

The full programme is included because preserved assignments outside the
selected target rows can affect:
- same-operation conflicts
- overlaps
- fairness
- available assignment choices

### Team
Planner-relevant staff fields:
- id / username
- role / staff number
- active state
- archived / left date
- hire/start date
- gender
- can-do
- can't-do

### Attendance
Normalized staff attendance:
- username
- date
- status

### Duty/configuration
- Day Plan overrides
- configured activity gender requirements

## Apply behavior

The final Apply flow is now:

Plan generated
→ capture local snapshot
→ Manager reviews/edits proposed names
→ filter assigned rows
→ filtered payload inherits original snapshot
→ `AUREA_PLANNER.apply()`
→ stale-plan preflight
→ if unchanged: existing Phase 15 apply path
→ if changed: block before any write

A stale plan receives:

`AUREA_STALE_PLAN`

and the UI tells the Manager to build a fresh A/B/C plan.

## Compatibility

Legacy callers that do not come from the A/B/C generator do not have a
snapshot. Phase 16 deliberately does not block those callers, to avoid breaking
older planner/repair paths.

This compatibility exception is temporary. Once all planner entry points are
fully canonical and database concurrency exists, uncaptured writes can be made
strict.

## Important limitation

This is not database-level concurrency protection.

There is still a small race window:

1. local snapshot passes
2. another client changes the database
3. this client begins sequential writes

The real solution remains the future Phase 15 atomic RPC with row locking /
optimistic concurrency checks on the database side.

Phase 16 therefore reduces stale-plan risk today without pretending to solve
cross-client transaction races.

## Regression coverage

`tests/phase16_planner_concurrency_smoke.js` verifies:

- fresh captured plans apply normally
- filtered apply payload preserves its snapshot
- changed programme assignment blocks before writes
- changed staff availability blocks before writes
- changed attendance blocks before writes
- uncaptured legacy caller still works
