# AUREA Phase 26 — V5 Planner Override Retirement

Phase 26 retires two V5 planner seams only:

- the V5 assignment-overview implementation (`userByAssignment`, `assignmentValid`, `displayAssignee`, `window.assignActsInner`)
- the V5 planner-modal implementation (`makePlan`, `window.openAutoAssignModal`)

The audit confirmed that neither V5 implementation is captured by a later module. Canonical V6.22 owns `assignActsInner`; canonical V6.24 owns `openAutoAssignModal`.

The V5 file is **not** retired as a whole. Its still-required behavior remains, including the `bumpLoad` chain, `activityType`, the `openEditModal` wrapper captured by V6.22, and feedback UI functions.

The exact Phase 25 V5 file is preserved in `phase26_rollback/`. The Phase 26 verifier reconstructs the current V5 file from that snapshot and proves that only the two audited blocks changed.

No planner rules, persistence, database schema, Auth, RLS, realtime, loading mode, or safety mode is changed.
