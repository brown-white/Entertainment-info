# AUREA Phase 24 — Base `pickFairest` Retirement

## Scope

Phase 24 retires exactly one superseded helper from:

`js/planner/assignment-engine.js`

Removed:
- base `pickFairest()`

No other planner helper or runtime rule is changed.

## Why this helper was safe to retire

A startup and dependency audit found:

- the base `pickFairest()` implementation had no direct caller before the V5
  compatibility script loaded
- V5 replaces `window.pickFairest`
- V5 does not capture or call the old base `pickFairest()` implementation
- canonical V6.22 replaces `window.pickFairest` again later in the startup
  sequence
- the live planner therefore never depends on the retired base body

Current relevant load order:

1. `js/planner/assignment-engine.js`
2. `js/legacy/05-aurea-v5-smart-plans.js`
3. `js/planner/smart-assignment-v622.js`

## What remains live and was explicitly preserved

The audit confirmed that these helpers are still active and must not be retired:

- `baseLoad`
- `baseCounts`
- `loadOf`
- `bumpLoad`
- `repeatPenalty`
- `planBalance`

In particular:

- `planBalance()` still uses `baseCounts()`
- `baseCounts()` still depends on `baseLoad()`
- V5 captures `window.bumpLoad` as `oldBump`
- V5's replacement `pickFairest()` still calls `repeatPenalty()` and `loadOf()`

Therefore those helpers remain untouched.

## Exact-delta safety

The complete Phase 23 version of `assignment-engine.js` is preserved at:

`phase24_rollback/js/planner/assignment-engine.js`

The Phase 24 verifier reconstructs the current file from that rollback and
proves that only the historical base `pickFairest()` block was replaced by the
Phase 24 retirement marker.

## Explicitly unchanged

Phase 24 does not change:

- base `applyAssignments`
- V6.22 hard-rule logic
- V6.24 Plan A/B/C logic
- V5 compatibility behavior
- `planBalance`
- stale-plan protection
- persistence
- Auth
- RLS
- database schema
- realtime
- data loading

## Safety modes

Unchanged:

- `AUTH_MODE = legacy`
- `DATA_LOAD_MODE = legacy_full`
- `REALTIME_MODE = legacy_broad`
- `SESSION_LIFECYCLE_MODE = legacy_observe`
- `STATE_ISOLATION_MODE = legacy_transient`
- `PLANNER_MODE = compat_v624`
- `PLANNER_APPLY_MODE = legacy_sequential`
- `PLANNER_CONCURRENCY_MODE = local_snapshot`
