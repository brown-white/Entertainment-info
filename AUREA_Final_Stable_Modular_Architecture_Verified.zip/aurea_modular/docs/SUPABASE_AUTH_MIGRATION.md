# AUREA Phase 7 — Supabase Auth Compatibility Migration

## Phase 7 status

Prepared, but NOT activated.

`CONFIG.AUTH_MODE` remains:

```js
AUTH_MODE: "legacy"
```

Therefore the currently working Manager / Entertainer login continues to use the legacy account directory and existing passwords.

## What Phase 7 adds

- `js/auth/supabase-auth-adapter.js`
- Password sign-in adapter for future Supabase Auth staff identities
- Server-verified `/auth/v1/user` identity check
- Refresh-token support
- Immediate local Auth logout
- REST and Storage requests can use a Supabase Auth access token when Auth is later enabled
- `AUREA_AUTH.authenticateStaff()` now supports legacy or future Supabase staff authentication through the same interface

## What Phase 7 does NOT do

- It does not create Auth users.
- It does not copy passwords into Supabase Auth.
- It does not change the `app_users` schema.
- It does not enable RLS.
- It does not activate Supabase Auth.
- It does not migrate hotel Guest login.
- It does not add a service-role key to the browser.

## Required identity mapping before activation

Each migrated Manager / Entertainer account will eventually need a trusted link between:

1. the existing AUREA `app_users` row, and
2. the corresponding Supabase Auth user.

The prepared adapter understands these future fields if/when they are deliberately added:

- `auth_email`
- `auth_user_id`

Do not add or populate these blindly. First create a staging migration and verify existing account ownership.

## Safe activation sequence

1. Make a database backup / export.
2. Use a staging Supabase project or staging copy.
3. Decide the staff Auth email/identity strategy.
4. Create Supabase Auth users from a SERVER-SIDE/admin environment.
5. Never expose the service-role key in this project or any browser JavaScript.
6. Link each existing `app_users` row to the exact Auth user ID.
7. Test one Manager account.
8. Test one Entertainer account.
9. Test logout, refresh, disabled accounts, wrong passwords, and role mismatch.
10. Only after those pass, set staging `AUTH_MODE` to `supabase_staff`.
11. Keep Guests on the existing stay-based login during this migration.
12. Build/test RLS only after authenticated staff requests carry trusted JWTs.

## Why Guest login is not migrated in Phase 7

Guest identity is tied to a temporary hotel stay and room reuse. It requires a separate design so a future Guest cannot inherit a previous Guest's records. The existing V6.19 stay-lifecycle protections remain the source of truth until a dedicated Guest Auth design is tested.
