# AUREA Phase 13 — Smart Planner Consolidation Audit

## Active planner stack

The current final planner behavior is layered:

1. `js/planner/assignment-engine.js`
   - original modularized planner foundation
   - baseline `autoAssignDay`, `autoAssignWeek`, `applyAssignments`, planner UI helpers

2. `js/legacy/23-aurea-smart-assignment-v622-script.js`
   - overrides assignment generation and apply validation
   - authoritative hard eligibility / repair layer
   - exports `AUREA_SMART_ASSIGNMENT_V622`

3. `js/legacy/24-aurea-smart-plans-v624-script.js`
   - wraps the V6.22 apply validator
   - authoritative A/B/C plan generation UI
   - exports `AUREA_SMART_PLANS_V624`

4. `js/planner/planner-service.js`
   - Phase 13 canonical facade
   - delegates to the final V6.22/V6.24 behavior
   - no planner algorithm rewrite in this phase

## Final hard rules preserved

V6.22/V6.24 currently enforce:

- Manager-only planner changes through the app permission boundary.
- DJ excluded from normal morning/afternoon activities.
- Event/show programme items are assigned to DJ when DJ is available.
- Day Off blocks assignment.
- Vacation blocks assignment.
- Absence blocks assignment.
- Inactive/left staff are unavailable through existing availability logic.
- `I can / I can't` capability rules are enforced.
- Optional Manager-configured gender requirement is enforced.
- Entrance Duty conflict is a hard block.
- Time overlap is blocked.
- Maximum one normal activity per entertainer per operation.
- Existing preserved assignments are considered when filling empty slots.
- Hard-invalid saved assignments can be repaired.
- Valid manual assignments are not silently rewritten by repair.
- Fairness considers weighted active/relaxing workload, total count, repeated activity,
  repeated clock time, activity type, and recent repetitions.
- Plan A/B/C alternatives try to vary near-equally fair assignments without violating hard rules.

## Phase 13 consolidation decision

Do not delete V6.22 or V6.24 yet.

Although they are legacy-named files, they contain the current final business behavior.
Deleting or folding them into the older base planner in one step would risk reintroducing:
- double assignments in one operation
- invalid Entrance Duty assignments
- DJ in normal activities
- ignored attendance status
- repeated/fairness regressions

The safe sequence is:
1. route external callers through `AUREA_PLANNER`
2. add rule-level regression tests
3. later move V6.22/V6.24 internals into canonical planner modules
4. prove equivalence
5. only then remove the legacy wrappers

## Bug fixed in Phase 13

The Manager assignment overview displayed a `↻` repair button (`#asg-clearbad`), but no active click handler existed in the final wiring.

Phase 13 wires that button through:

`AUREA_PLANNER.repair()`

This calls the existing V6.22 repair routine, which repairs only hard-invalid assignments.

## Active mode

`PLANNER_MODE = "compat_v624"`

Any future replacement mode is blocked by the Phase 13 safety guard.
