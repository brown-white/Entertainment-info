# AUREA Phase 8 — Rollback / Safety Notes

Phase 8 does not execute SQL and does not modify Supabase.

The SQL templates under `supabase/phase8/` intentionally contain an exception blocker.
Only `00_READ_ONLY_PRECHECK.sql` is designed to be safely runnable, and it uses SELECT statements only.

If a later staging migration is attempted:
1. Export/back up the database first.
2. Record current RLS policies from `pg_policies`.
3. Migrate one table at a time.
4. Test Manager, Entertainer, and Guest separately.
5. Keep `AUTH_MODE="legacy"` until the staff Auth path is proven.
6. Never test a first-time policy migration directly on the hotel production project.
