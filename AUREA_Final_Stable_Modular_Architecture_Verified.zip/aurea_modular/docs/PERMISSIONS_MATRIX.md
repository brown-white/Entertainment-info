# AUREA Phase 6 — Permissions Matrix

This document describes the application-layer permission model introduced in Phase 6.
It reflects the current app behavior and is deliberately conservative.

| Capability | Guest | Entertainer | Manager |
|---|:---:|:---:|:---:|
| Read entertainment program | ✓ | ✓ | ✓ |
| Create/edit/delete program items | — | — | ✓ |
| Book a bookable activity | Own stay | — | — |
| Cancel activity booking | Own stay only | — | ✓ via management workflows |
| Order ticket | Own stay | — | — |
| Cancel ticket order | Own stay only | — | ✓ |
| Mark ticket paid / handed over | — | ✓ | ✓ |
| Edit ticket order details | — | — | ✓ |
| Read own workday / planner | — | ✓ | ✓ |
| Change planner assignments | — | — | ✓ |
| Attendance operations | — | Limited/current workflow | ✓ |
| View team | — | ✓ | ✓ |
| Manage team accounts | — | — | ✓ |
| Read own guest/stay data | ✓ | — | ✓ |
| Manage guest records/history | — | — | ✓ |
| Chat | Own guest channel | Team channels/workflow | ✓ |
| Guest requests | Create own | Process current workflow | ✓ |
| Feedback | — | Own workflow | ✓ |
| Settings / page configuration | — | — | ✓ |
| Manager exports | — | — | ✓ |
| Manager AI tools | — | — | ✓ |

## Ownership rule

Guest-scoped records must be tied to the guest's CURRENT stay, not merely a reusable room number.
`AUREA_PERMISSIONS.isOwnGuestRow()` delegates to the existing V6.19 guest lifecycle rules when available.

## Enforcement status

Phase 6 enforces application-level permissions in the canonical Booking, Ticket and Planner mutation paths.
It does not yet provide database-enforced RLS because staff/manager identities are not yet represented by Supabase Auth JWTs.
