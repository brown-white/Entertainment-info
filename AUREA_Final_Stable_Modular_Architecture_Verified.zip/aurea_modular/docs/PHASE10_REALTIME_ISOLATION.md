# AUREA Phase 10 — Realtime Isolation Architecture

## Status

Prepared but NOT activated.

The active configuration remains:

```js
REALTIME_MODE: "legacy_broad"
```

This preserves the Phase 9 realtime subscription behavior.

## What changed

Realtime behavior now passes through:

`js/services/realtime-service.js`

The service owns:
- table -> application-state mapping
- realtime row INSERT / UPDATE / DELETE patching
- Supabase realtime client creation
- subscription creation
- future role-specific table profiles
- the activation safety guard

`js/core/realtime-runtime.js` remains responsible for:
- loading the Supabase realtime library
- notifications
- render scheduling
- polling fallback
- app boot

## Current active subscription

Phase 10 intentionally preserves:

- channel: `live-changes`
- event: `*`
- schema: `public`

No table/row filtering is activated.

## Prepared future profiles

Profiles are documented for:
- bootstrap
- guest
- staff
- manager

They are NOT security controls by themselves.

Even when scoped realtime is later enabled, Supabase RLS must remain the database authority.

## Why activation is blocked

Before scoped realtime can be activated safely:

1. Manager/Entertainer Supabase Auth must work in staging.
2. Requests must carry the authenticated JWT.
3. RLS must be tested table-by-table.
4. Guest identity must map to one exact hotel stay.
5. Realtime authorization behavior must be tested with RLS.
6. Session changes/login/logout must rebuild subscriptions safely.
7. Reduced-data UI regression tests must pass.

## Important future lifecycle requirement

The current legacy subscription starts once during app boot.

A future authenticated/scoped subscription must be lifecycle-aware:

- anonymous/bootstrap
- login -> unsubscribe/rebuild using authenticated identity
- role/session change -> unsubscribe/rebuild
- logout -> unsubscribe and return to safe bootstrap state
- token refresh -> authenticated realtime session remains valid

Phase 10 does not activate that lifecycle yet.
