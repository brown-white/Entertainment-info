# AUREA Phase 8 — Identity + RLS Staging Design

## Objective

Prepare the database security migration without changing production behavior.

## Current identity states

### Manager / Entertainer
Current production-compatible identity:
- legacy `app_users` username/password model
- application session in `S.session`

Prepared future identity:
- Supabase Auth user
- trusted `auth.uid()`
- explicit link from the corresponding `app_users` row

### Guest
Current identity:
- temporary hotel stay
- `guest_accounts`
- room + exact arrival/departure lifecycle
- V6.19 current-stay isolation

Future Guest Auth is deliberately NOT decided in Phase 8.

## Staff identity source of truth

The safest planned relationship is:

`auth.users.id` -> `public.app_users.auth_user_id`

The application role and active state should remain in a protected application-owned row.
Do not rely on user-editable metadata for authorization.

## Activation gates

RLS must remain unactivated until ALL of these are true:

1. Staging database backup exists.
2. Existing policies have been exported/reviewed.
3. At least one Manager and one Entertainer have verified Supabase Auth identities.
4. `auth_user_id` mappings have been manually checked.
5. Staff login works with `AUTH_MODE="supabase_staff"` in staging.
6. Database requests carry the staff JWT.
7. Role-specific loader changes are ready.
8. Guest ownership schema is designed before Guest-sensitive RLS is enabled.
9. Automated role regression tests pass.
10. Production has a rollback plan.

## Phase 8 output

- Read-only schema/policy precheck
- Blocked identity-link SQL template
- Blocked staff/manager RLS helper/policy templates
- Blocked Guest ownership/RLS template
- Data-access audit
- Rollback/safety instructions
- Automated guard test preventing accidental activation
