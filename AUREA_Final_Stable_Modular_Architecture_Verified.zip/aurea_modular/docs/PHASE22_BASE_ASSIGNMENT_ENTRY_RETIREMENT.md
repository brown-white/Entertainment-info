# AUREA Phase 22 — Base Assignment Entry-Point Retirement

## Scope

Phase 22 retires exactly two superseded base implementations from:

`js/planner/assignment-engine.js`

Removed:
- base `autoAssignDay()`
- base `autoAssignWeek()`

No other planner implementation is changed.

## Runtime owner

The authoritative runtime implementations remain in:

`js/planner/smart-assignment-v622.js`

which installs:

- `window.autoAssignDay`
- `window.autoAssignWeek`

## Compatibility audit

An earlier V5 compatibility file still contains:

`makePlan(...)`

which refers to `autoAssignDay` / `autoAssignWeek`.

This was audited carefully.

That function is defined during V5 script load but does not execute the
assignment functions at load time. The browser script order is:

1. `assignment-engine.js`
2. V5 compatibility
3. canonical V6.22
4. canonical V6.24

V6.22 therefore installs the final global assignment functions before the UI
can invoke the V5 planner path.

The Phase 22 verifier locks both the V5 call shape and this script order so
future changes cannot silently invalidate that assumption.

## Exact change

The base day/week block was removed and replaced with a short retirement marker.

The exact pre-change engine is preserved at:

`phase22_rollback/js/planner/assignment-engine.js`

The verifier reconstructs the Phase 22 engine from that rollback copy and
proves no other engine code changed.

## Explicitly preserved

Phase 22 does NOT remove or modify:

- `fixRepeats`
- `balancePlan`
- `planBalance`
- base `applyAssignments`
- `eventsCrew`
- `assignableStaff`
- `activitySlot`
- `assignDateStr`
- V6.22 hard-rule logic
- V6.24 Plan A/B/C logic
- stale-plan protection
- persistence strategy
- atomic RPC status
- Auth
- RLS
- database schema
- realtime
- data-loading behavior

## Safety modes

Unchanged:

- `AUTH_MODE = legacy`
- `DATA_LOAD_MODE = legacy_full`
- `REALTIME_MODE = legacy_broad`
- `SESSION_LIFECYCLE_MODE = legacy_observe`
- `STATE_ISOLATION_MODE = legacy_transient`
- `PLANNER_MODE = compat_v624`
- `PLANNER_APPLY_MODE = legacy_sequential`
- `PLANNER_CONCURRENCY_MODE = local_snapshot`

## Verification

`tests/verify_phase22_base_assignment_entry_retirement.py` checks:

- base `autoAssignDay` and `autoAssignWeek` declarations are gone
- V6.22 still installs both runtime globals
- exact-delta reconstruction against rollback
- V5 compatibility remains deferred
- base/V5/V6.22/V6.24 load order
- no unexpected active dependency exists
- all critical base helpers/persistence remain
- safety modes remain conservative
- active JavaScript parses
