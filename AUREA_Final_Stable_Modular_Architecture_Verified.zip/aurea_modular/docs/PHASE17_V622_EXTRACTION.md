# AUREA Phase 17 — V6.22 Planner Legacy-Layer Extraction

## Goal

Move ownership of the current V6.22 hard-rule engine into `js/planner/`
without rewriting or deleting the proven implementation.

## Canonical module

`js/planner/smart-assignment-v622.js`

This file is an exact byte-for-byte copy of:

`js/legacy/23-aurea-smart-assignment-v622-script.js`

Phase 17 intentionally makes no logic edits inside V6.22.

## Runtime order

The browser now loads:

1. `js/planner/smart-assignment-v622.js`
2. `js/legacy/23-aurea-smart-assignment-v622-script.js`
3. `js/legacy/24-aurea-smart-plans-v624-script.js`

The canonical file executes first and sets:

`window.__AUREA_SMART_ASSIGNMENT_V622 = true`

The preserved legacy file immediately reaches its existing guard:

```js
if(window.__AUREA_SMART_ASSIGNMENT_V622)return;
```

and exits without:
- re-wrapping `applyAssignments`
- re-wrapping `DB.setStaffAtt`
- re-wrapping `DB.saveSettings`
- replacing `AUREA_SMART_ASSIGNMENT_V622`
- creating duplicate repair behavior

## Why the legacy file remains

The old file is retained as an immediate rollback/reference artifact.

Deleting it in the same phase as ownership migration would remove an easy
comparison point and make rollback less transparent.

The migration sequence is therefore:

1. exact-copy into canonical location
2. canonical loads first
3. legacy remains but is inert through its own guard
4. prove byte identity
5. prove no duplicate wrappers
6. run planner hard-rule regressions
7. only in a later phase consider removing the active legacy reference

## What moved conceptually

The canonical module now owns the existing V6.22 behaviors:

- hard availability
- Day Off / Vacation / Absent checks
- Entrance Duty eligibility
- I can / I can't
- configured gender requirement
- time-overlap validation
- max one normal activity per operation
- DJ exclusion from normal activity rota
- fairness metrics / candidate choice
- `autoAssignDay` / `autoAssignWeek`
- apply validation wrapper
- hard-invalid assignment repair
- attendance-triggered repair
- Day Plan/settings-triggered repair
- Manager assignment overview integration

No behavior is newly invented in Phase 17.

## Verification

`tests/verify_phase17_v622_extraction.py` checks:

- canonical and legacy V6.22 bytes are exactly identical
- SHA-256 matches
- canonical loads before legacy
- legacy loads before V6.24
- all active JavaScript parses
- all Phase 14 planner hard-rule tests run using the canonical module
- loading the preserved legacy file afterward does not replace:
  - `applyAssignments`
  - `DB.setStaffAtt`
  - `DB.saveSettings`
  - `AUREA_SMART_ASSIGNMENT_V622`

## Safety status

Phase 17 does not change:
- planner algorithms
- planner persistence
- atomic RPC activation
- concurrency mode
- Supabase Auth
- RLS
- data loading
- realtime
- database schema
