# AUREA Phase 20 — Planner Consolidation Audit

## Status

Audit only. Runtime behavior is unchanged.

Phase 20 does not delete, rewrite, wrap, reorder, or replace any active planner
runtime module.

## Why this phase exists

The planner is now structurally cleaner after Phases 17–19, but
`assignment-engine.js`, canonical V6.22, and canonical V6.24 still share
responsibilities.

Removing code based only on similar function names would be risky because the
current runtime intentionally uses an override/wrapper chain.

Phase 20 maps that chain explicitly before any deletion is attempted.

## Current runtime ownership

### `autoAssignDay`

Base implementation:

`js/planner/assignment-engine.js`

Runtime override:

`js/planner/smart-assignment-v622.js`

The V6.22 implementation is authoritative at runtime.

### `autoAssignWeek`

Base implementation:

`js/planner/assignment-engine.js`

Runtime override:

`js/planner/smart-assignment-v622.js`

The V6.22 implementation is authoritative at runtime.

### `applyAssignments`

This symbol is NOT a simple duplicate.

Current chain:

1. base `assignment-engine.js`
2. wrapped by V6.22
3. wrapped again by V6.24
4. called through the canonical Phase 15 planner persistence boundary

All three layers participate in current behavior.

The base function is the sequential persistence implementation.
V6.22 adds hard-rule validation.
V6.24 adds final plan-level conflict validation.

Therefore none of those three layers is safe to remove yet.

### `openAutoAssignModal`

Base modal:

`js/planner/assignment-engine.js`

Runtime override:

`js/planner/smart-plans-v624.js`

V6.24 is authoritative at runtime.

### Hard-rule API

Authoritative owner:

`js/planner/smart-assignment-v622.js`

API:

`AUREA_SMART_ASSIGNMENT_V622`

### A/B/C plan generation API

Authoritative owner:

`js/planner/smart-plans-v624.js`

API:

`AUREA_SMART_PLANS_V624`

## Foundation helpers that are still required

The base assignment engine still supplies helpers consumed by V6.22/V6.24,
including:

- `eventsCrew`
- `assignableStaff`
- `activitySlot`
- `planBalance`
- `assignDateStr`
- `activityType` (provided by active V5 compatibility layer before V6.24)
- the current `DJ_NUMBER` contract

These are not safe deletion candidates.

## Potential future retirement candidates

The following base implementations appear superseded at runtime and may become
future cleanup candidates:

- base `autoAssignDay`
- base `autoAssignWeek`
- base `openAutoAssignModal`

They are NOT removed in Phase 20.

Before removing any one of them, a future phase must:
1. prove no active caller depends on the base body
2. preserve any helper side effects or closure dependencies
3. run all planner rule/persistence/concurrency regressions
4. maintain rollback
5. remove only one behavior group at a time

## Machine-readable audit

Phase 20 adds:

- `docs/PHASE20_PLANNER_CONSOLIDATION_AUDIT.json`
- `docs/PHASE20_PLANNER_SYMBOL_USAGE.json`

The first file records ownership, wrapper relationships, safe candidates, and
unsafe-to-remove components.

The second records current source-level symbol usage in active JS.

## Runtime hash lock

`tests/phase20_runtime_hashes.json`

records SHA-256 hashes for the active planner/runtime files at the Phase 20
baseline.

`tests/verify_phase20_planner_audit.py` confirms those runtime files are
unchanged during this audit phase.

## Safety posture

Unchanged:
- AUTH_MODE = legacy
- DATA_LOAD_MODE = legacy_full
- REALTIME_MODE = legacy_broad
- SESSION_LIFECYCLE_MODE = legacy_observe
- STATE_ISOLATION_MODE = legacy_transient
- PLANNER_MODE = compat_v624
- PLANNER_APPLY_MODE = legacy_sequential
- PLANNER_CONCURRENCY_MODE = local_snapshot

No database, Auth, RLS, realtime, planner algorithm, or persistence behavior is
changed in Phase 20.
