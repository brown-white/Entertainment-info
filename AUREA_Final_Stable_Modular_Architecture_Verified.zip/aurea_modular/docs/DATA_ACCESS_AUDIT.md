# AUREA Phase 8 — Data Access Audit

## Current finding

The current `DB.load()` performs one broad startup load and requests many operational tables together:

- activities
- bookings
- app_users
- app_settings
- tickets
- ticket_orders
- rooms
- guest_accounts
- messages
- requests
- tasks
- announcements
- attendance
- feedback
- team_profiles
- buses
- quizzes
- quiz_replies
- staff_attendance
- photos
- staff_requests

This architecture predates trusted Supabase Auth identities and role-sensitive RLS.

## Why this matters

Once strict RLS is enabled:

- A Guest must not be able to download the full `app_users` directory.
- A Guest must not receive another stay's bookings, ticket orders, messages, requests, or guest account.
- An Entertainer should receive only the operational data needed for their role.
- A Manager can receive broader management data, subject to the final policy design.

Therefore RLS activation and data-loading refactoring are linked migrations.

## Safe migration direction

Do NOT change the broad loader while `AUTH_MODE="legacy"` because the current staff login still needs the downloaded `app_users` data.

After staff Supabase Auth is proven in staging, split loading conceptually into:

### Public / shared entertainment load
Program content and safe shared guest-facing information.

### Guest authenticated load
Current-stay data only, enforced by RLS.

### Entertainer authenticated load
Team operational data needed by the signed-in entertainer.

### Manager authenticated load
Management datasets permitted to the Manager.

## Table classification draft

This is a migration planning classification, not an executed policy.

### Shared/read-mostly
- activities
- tickets
- buses
- announcements
- team_profiles
- photos
- quizzes
- app_settings (only if the stored data is confirmed safe for Guests)

### Guest-owned / stay-sensitive
- bookings
- ticket_orders
- messages
- requests
- quiz_replies
- guest_accounts

### Team/management-sensitive
- app_users
- attendance
- staff_attendance
- staff_requests
- tasks
- feedback
- rooms

The final classification must be verified against actual columns and current hotel workflows before RLS is activated.
