# AUREA Phase 18 — V6.24 Smart Plans Legacy-Layer Extraction

## Goal

Move ownership of the current V6.24 A/B/C Smart Plans layer into `js/planner/`
without rewriting its proven generation, validation, concurrency integration,
or UI behavior.

## Canonical module

`js/planner/smart-plans-v624.js`

It is an exact byte-for-byte copy of:

`js/legacy/24-aurea-smart-plans-v624-script.js`

No V6.24 business logic is edited in Phase 18.

## Browser load order

The planner stack now loads in this order:

1. `js/planner/assignment-engine.js`
2. `js/planner/smart-assignment-v622.js`
3. preserved `js/legacy/23-aurea-smart-assignment-v622-script.js`
4. `js/planner/smart-plans-v624.js`
5. preserved `js/legacy/24-aurea-smart-plans-v624-script.js`
6. `js/planner/planner-concurrency.js`
7. `js/planner/planner-apply-service.js`
8. `js/planner/planner-service.js`

The canonical V6.24 file executes first and sets:

`window.__AUREA_SMART_PLANS_V624 = true`

The preserved legacy copy then reaches its existing guard:

```js
if(window.__AUREA_SMART_PLANS_V624)return;
```

and exits immediately.

## Duplicate-wrapper protection

The Phase 18 test verifies that loading the preserved V6.24 file after the
canonical copy does not replace or re-wrap:

- `applyAssignments`
- `openAutoAssignModal`
- `AUREA_SMART_PLANS_V624`

This is especially important because duplicated `applyAssignments` wrappers
could stack validation multiple times or alter persistence behavior.

## Current canonical V6.24 responsibilities

The exact migrated implementation continues to own:

- Plan A/B/C alternative generation
- fairness scoring
- alternate-plan diversity
- preserved-assignment accounting
- max one activity per entertainer per operation
- DJ event rows
- final apply validation
- Smart Plan modal UI
- manual proposed-name changes inside the modal
- stale-plan snapshot integration from Phase 16
- canonical Apply routing from Phase 15/16

## Why the legacy file remains

The legacy V6.24 file remains present as a transparent reference and rollback
point. It is inert in normal browser execution because the canonical copy has
already set the one-time guard.

A later cleanup phase can remove the active legacy script reference only after
the extraction remains stable through broader regression/staging testing.

## Verification

Phase 18 verifies:

- byte-for-byte equality
- matching SHA-256
- correct canonical-before-legacy load order
- preserved one-time guard
- no duplicate apply wrapper
- no duplicate modal replacement
- no API replacement
- full Phase 14 planner rule regression using canonical V6.22 + canonical V6.24
- JavaScript syntax across active modules

## Unchanged safety posture

Phase 18 does not activate or alter:

- atomic planner RPC
- Supabase staff Auth
- RLS
- database schema
- role-aware loading
- scoped realtime
- planner concurrency strategy
- planner business rules
