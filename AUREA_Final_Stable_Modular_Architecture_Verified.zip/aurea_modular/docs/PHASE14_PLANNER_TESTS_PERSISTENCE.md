# AUREA Phase 14 — Planner Regression Suite + Persistence Audit

## Purpose

Phase 14 does not rewrite the planner algorithm.

It creates a deterministic safety net around the current Phase 13 stack before any deeper V6.22/V6.24 consolidation.

## Regression scenarios now tested

The test suite executes the real planner foundation + V6.22 + V6.24 stack and verifies:

1. Day Off blocks assignment.
2. Vacation (`V`) blocks assignment.
3. Absent (`A`) blocks assignment.
4. Inactive staff are unavailable.
5. Staff who have left are unavailable.
6. `I can` limits eligible activities.
7. `I can't` overrides `I can`.
8. Entrance Duty:
   - 15:30–16:00 is valid.
   - 15:45–16:15 is invalid.
   - unknown activity time is blocked conservatively.
9. Manager-configured gender requirement is enforced.
10. DJ is excluded from normal entertainer activities.
11. Event programme is assigned to the DJ when available.
12. Two activities in the same operation for one entertainer are invalid.
13. Overlapping activities are invalid.
14. Plan A/B/C are generated.
15. Generated plans respect max one activity per entertainer per operation.
16. Invalid plans are rejected before any assignment write occurs.
17. Valid plans persist each assignment through `DB.saveActivity()`.

## Persistence audit

### Current apply path

`AUREA_PLANNER.apply()`
→ final V6.24 validator
→ V6.22 validator
→ base `applyAssignments()`
→ sequential `DB.saveActivity()` calls
→ `activities` table PATCH

Before writes begin, the full incoming plan is checked for the hard constraints represented by V6.24/V6.22.

### Important limitation: not atomic

The actual persistence is sequential:

```text
save activity 1
save activity 2
save activity 3
...
```

There is currently no database transaction wrapping the full plan.

If activity 1 saves successfully and activity 2 fails because of a network/database error, activity 1 may remain saved while the remainder is not.

Phase 14 deliberately does NOT attempt to fake transactionality in the browser.

A browser-side rollback would itself be unreliable if the network is failing.

The correct future solution is a server/database transaction or RPC/Edge Function that validates and applies a complete assignment set atomically.

## Automatic repair persistence

V6.22 repairs hard-invalid assignments through `DB.saveActivity()`.

Repair can be triggered after:
- attendance status changes (`DB.setStaffAtt`)
- Day Plan / duty settings changes (`DB.saveSettings`)
- Manager boot-time repair check

Valid-but-suboptimal manual assignments are not intentionally changed by the repair routine.

## Phase 14 planner persistence diagnostic

`AUREA_PLANNER.persistenceStatus()` reports:

- strategy: `sequential-db-saveActivity`
- atomic: `false`
- validatesBeforeWrite: `true`
- repair persists through `saveActivity`
- attendance changes can trigger repair
- Day Plan changes can trigger repair

This is diagnostic only and changes no planner behavior.

## Recommended next persistence step

Do not replace the current apply mechanism until a staging-safe atomic design is available.

The preferred future architecture is:

Manager selects Plan
→ client preflight validation
→ one authenticated server/database call
→ transaction validates current rows again
→ all assignments commit together
→ or all assignments roll back together
