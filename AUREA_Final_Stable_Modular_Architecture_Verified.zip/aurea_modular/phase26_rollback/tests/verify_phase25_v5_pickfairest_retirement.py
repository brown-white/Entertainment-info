from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

current=ROOT/"js/legacy/05-aurea-v5-smart-plans.js"
rollback=ROOT/"phase25_rollback/js/legacy/05-aurea-v5-smart-plans.js"
v622=ROOT/"js/planner/smart-assignment-v622.js"
index=ROOT/"index.html"

cur=current.read_text(encoding="utf-8")
old=rollback.read_text(encoding="utf-8") if rollback.exists() else ""

marker=(
"  /* Phase 25: retired V5 pickFairest override.\n"
"     Canonical V6.22 owns the final runtime pickFairest implementation.\n"
"     No later module captures the V5 implementation. Exact original is in phase25_rollback. */\n"
)

if not rollback.exists():
    errors.append("missing Phase25 V5 rollback copy")

# Retired V5 override must be gone.
if "window.pickFairest=function" in cur:
    errors.append("V5 pickFairest override still present")

# Exact-delta proof.
if old:
    lines=old.splitlines(keepends=True)
    try:
        start=next(i for i,l in enumerate(lines) if re.match(r'^\s*window\.pickFairest\s*=\s*function',l))
        end=next(i for i in range(start+1,len(lines)) if re.match(r'^\s*function\s+userByAssignment\s*\(',lines[i]))
        removed="".join(lines[start:end])
        if "window.pickFairest=function" not in removed:
            errors.append("rollback block does not contain V5 pickFairest")
        reconstructed="".join(lines[:start])+marker+"".join(lines[end:])
        if reconstructed!=cur:
            errors.append("V5 file changed beyond audited pickFairest retirement")
    except StopIteration:
        errors.append("could not locate historical V5 pickFairest block")

# Chained/still-live V5 behavior must remain.
required_v5=[
    "const oldBump=window.bumpLoad;",
    "window.bumpLoad=function",
    "window.activityType=activityType;",
    "window.assignActsInner=function",
    "window.openAutoAssignModal=function",
    "const originalEdit=window.openEditModal;",
    "window.openEditModal=function",
    "window.feedbackAnalyticsCard=function",
    "window.feedbackInner=function",
    "window.openDeptDetail=function",
]
for needle in required_v5:
    if needle not in cur:
        errors.append("required V5 behavior missing: "+needle)

# V6.22 authoritative final override must remain.
v622txt=v622.read_text(encoding="utf-8")
if "window.pickFairest=function(pool,load,usedThisSlot,act,day)" not in v622txt:
    errors.append("canonical V6.22 pickFairest override missing")

# No later module may capture the V5 pickFairest implementation.
html=index.read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',html)
try:
    v5i=scripts.index("js/legacy/05-aurea-v5-smart-plans.js")
    v622i=scripts.index("js/planner/smart-assignment-v622.js")
    if not v5i < v622i:
        errors.append("V5/V6.22 load order changed")
    capture_pat=re.compile(r'(?:const|let|var)\s+\w+\s*=\s*(?:window\.)?pickFairest\b')
    for s in scripts[v5i+1:v622i+1]:
        p=ROOT/s
        if p.exists() and p.suffix==".js":
            txt=p.read_text(encoding="utf-8",errors="ignore")
            if capture_pat.search(txt):
                errors.append("later module captures pickFairest: "+s)
except ValueError as e:
    errors.append("required script missing: "+str(e))

# Safety modes remain conservative.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 25 retires only V5 pickFairest, preserves chained/final V5 behaviors, canonical V6.22 ownership, rollback exactness, and all conservative safety modes.")
