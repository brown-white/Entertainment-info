# AUREA Modular Migration — Phase 2

This build continues the safe migration from one large HTML file toward a maintainable folder-based application.

## What changed in Phase 2
The former `js/legacy/01-app-core.js` was split at top-level dependency boundaries without rewriting its internal logic:

- `js/core/config.js` — environment/configuration and default visual settings
- `js/core/foundation.js` — translations, shared state, access helpers, sample-data foundation
- `js/database/supabase-client.js` — Supabase REST/storage helpers plus the existing persistence-support code that currently depends on them
- `js/database/database.js` — the existing central `DB` repository object
- `js/core/runtime.js` — common runtime/UI helpers used by all roles
- `js/auth/login.js` — current login/authentication UI and flow
- `js/legacy/01-app-shell.js` — remaining application screens/features that still need controlled extraction

The exact Phase 1 core is preserved at:
`js/legacy/backups/01-app-core.phase1.js`

## Safety guarantees used for this migration
1. Original execution order is preserved in `index.html`.
2. The split files concatenate byte-for-byte to the preserved Phase 1 core.
3. Every active JavaScript file passes `node --check` syntax validation.
4. Every local CSS/JS reference in `index.html` resolves to an existing file.
5. No business rule, database schema, role behavior, or visual redesign was intentionally changed in this phase.

## Important limitation
A complete live Supabase/browser regression test cannot be performed inside the isolated build environment. Before replacing the live production build, test Manager, Entertainer, Guest and DJ workflows against the real Supabase project.

## Next safe phase
Do not start by deleting patch files. First extract the remaining `01-app-shell.js` by domain while preserving behavior:

1. Guest screens/controllers
2. Entertainer screens/controllers
3. Manager screens/controllers
4. Planner/assignment engine
5. AI integration
6. Export/reporting
7. Notifications/realtime

Only after those areas are isolated and regression-tested should duplicate historical patches be consolidated.

## Phase 3 — Feature boundary split

The former `js/legacy/01-app-shell.js` has been split into ordered feature/runtime files under `js/guest/`, `js/entertainer/`, `js/manager/`, `js/planner/`, `js/ai/`, `js/exports/`, `js/notifications/`, `js/services/`, and `js/core/`.

Phase 3 is boundary-preserving: code inside each extracted block was not redesigned. Script order in `index.html` is intentionally significant. The complete Phase 2 shell is retained at `js/legacy/backups/01-app-shell.phase2.js`.

Before changing a feature, inspect its feature file plus service/database/core dependencies. Do not delete legacy patches merely because a newer feature module exists.


## Phase 4 — Guest Booking + Tickets consolidation

Phase 4 introduces two authoritative write/policy boundaries:

- `js/services/booking-service.js`
- `js/services/ticket-service.js`

Guest booking creation/cancellation and ticket order creation/status/delete/edit now route through these services.
The existing database layer remains responsible for persistence. Existing V6.14 ticket UX, V6.15 view-only programme UX,
V6.19 guest-stay isolation, V6.20 manager ticket UI and V6.16 global write safety are intentionally retained.

### Important
Do not bypass these services from UI code with direct `DB.addBooking`, `DB.addOrder`, `DB.removeBooking` or
`DB.setOrderStatus` calls. The services are now the controlled boundary for these workflows.

`phase4_rollback/` contains the files changed at the beginning of this phase.


## Phase 5 — Authentication boundary

Phase 5 adds `js/auth/auth-service.js` as the canonical client-side authentication/session boundary.

What moved behind this boundary:
- Guest sign-in validation
- Team/Manager sign-in validation
- Guest/Team/Manager session creation
- Logout
- Session validity checks
- Remembered-session refresh after fresh database load
- Same-stay validation for guests

Important security status:
This phase intentionally preserves the current readable-password data model so existing accounts keep working.
It does NOT make client-side passwords secure. The next security migration should move staff/manager authentication
to Supabase Auth (or another server-side identity provider) and verify RLS before removing legacy password columns.

Do not add new direct password comparisons outside `auth-service.js`.
Do not create or clear `S.session` directly in new UI code; use `AUREA_AUTH`.


## Phase 6 — Authorization / permissions boundary

Phase 6 adds `js/auth/permissions.js` as the canonical application-layer authorization source.

Protected canonical paths now include:
- Guest activity booking and own-booking cancellation
- Guest ticket ordering and own-order cancellation
- Ticket paid/handed-over status actions for Team/Manager
- Manager ticket editing/deletion
- Manager-only Smart Planner changes

Guest ownership uses the existing V6.19 current-stay lifecycle logic when available, not room number alone.

Documentation:
- `docs/PERMISSIONS_MATRIX.md`
- `docs/SUPABASE_RLS_PLAN.md`

### Security boundary
This is not yet database RLS. Real RLS is intentionally deferred until Supabase Auth supplies trusted identities.
Do not treat hidden UI or JavaScript role checks as sufficient database security.


## Phase 7 — Supabase Auth compatibility

Phase 7 prepares staff/manager Supabase Auth without activating it.

- Default remains `CONFIG.AUTH_MODE = "legacy"`.
- `js/auth/supabase-auth-adapter.js` contains the future Auth HTTP adapter.
- `js/auth/auth-service.js` now has a provider-compatible staff authentication boundary.
- `js/database/supabase-client.js` can send a future Auth JWT to REST/Storage; legacy mode still sends the existing publishable/anon token.
- No Auth users, schema, RLS, or production passwords are changed.

See `docs/SUPABASE_AUTH_MIGRATION.md`.

Do not switch `AUTH_MODE` until staff Auth users and their exact application-account mapping have been tested in staging.


## Phase 8 — Identity + RLS staging design

Phase 8 is deliberately non-destructive. It does not execute SQL, change schema, create Auth users, enable RLS, or change `AUTH_MODE`.

New staging/security assets:
- `supabase/phase8/00_READ_ONLY_PRECHECK.sql`
- `supabase/phase8/10_IDENTITY_LINK_TEMPLATE.sql`
- `supabase/phase8/20_RLS_HELPERS_TEMPLATE.sql`
- `supabase/phase8/30_STAFF_MANAGER_RLS_TEMPLATE.sql`
- `supabase/phase8/40_GUEST_RLS_TEMPLATE.sql`
- `docs/PHASE8_IDENTITY_RLS_DESIGN.md`
- `docs/DATA_ACCESS_AUDIT.md`
- `docs/PHASE8_ROLLBACK_SAFETY.md`

All mutation SQL templates contain an intentional exception blocker. Only the precheck is designed to be runnable, and it is SELECT-only.

Important migration dependency:
the current broad `DB.load()` still downloads multiple operational datasets together. Strict RLS must not be activated until the loader is split by authenticated role/stay.


## Phase 9 — Role-aware data loading boundary

Phase 9 centralizes startup and polling reads in `js/database/data-loader.js`.

Safety status:
- `CONFIG.DATA_LOAD_MODE` remains `legacy_full`.
- Active startup and polling datasets are intentionally equivalent to Phase 8.
- Draft Guest / Staff / Manager profiles exist but cannot be activated accidentally.
- A runtime safety guard throws if `DATA_LOAD_MODE` is changed away from `legacy_full`.

`DB.load()` and `DB.poll()` now delegate to the canonical loader boundary.

See `docs/PHASE9_ROLE_AWARE_LOADING.md`.

Phase 9 does not enable RLS, change Supabase Auth, or reduce production data access yet.


## Phase 10 — Realtime isolation boundary

Phase 10 centralizes realtime behavior in `js/services/realtime-service.js`.

Safety status:
- `CONFIG.REALTIME_MODE` remains `legacy_broad`.
- The existing `live-changes` / `postgres_changes` / public-schema subscription is preserved.
- Role-aware realtime profiles are prepared but blocked from activation.
- Realtime table/state mapping and row patching now have one canonical owner.
- Polling fallback continues through the Phase 9 data-loader boundary.

See `docs/PHASE10_REALTIME_ISOLATION.md`.

Phase 10 does not activate authenticated realtime, RLS, row filters, or production role-scoped subscriptions.


## Phase 11 — Session lifecycle orchestration

Phase 11 adds `js/auth/session-lifecycle.js` as the canonical identity-transition boundary.

Active safety mode:
- `CONFIG.SESSION_LIFECYCLE_MODE = "legacy_observe"`

In this mode lifecycle transitions are observed only. They do not trigger data reloads, realtime rebuilds, Auth changes, RLS changes, or extra network requests.

Integrated transition sources:
- Guest login
- Staff/Manager login
- Logout
- Remembered-session refresh
- Invalid-session removal
- Anonymous boot
- Future Supabase token refresh

See `docs/PHASE11_SESSION_LIFECYCLE.md`.

Rollback snapshot: `phase11_rollback/`.


## Phase 12 — Sensitive-state isolation

Phase 12 adds `js/auth/state-isolation.js`.

Active mode:
- `CONFIG.STATE_ISOLATION_MODE = "legacy_transient"`

Current behavior:
- clears transient UI/session residue when identity changes
- does NOT clear database-backed arrays required by legacy login
- future sensitive-array wiping is hard-blocked until scoped Auth/data loading is intentionally activated

The session lifecycle boundary now routes identity transitions through the state-isolation service.

See `docs/PHASE12_STATE_ISOLATION.md`.

Rollback snapshot: `phase12_rollback/`.


## Phase 13 — Smart Planner canonical boundary

Phase 13 adds `js/planner/planner-service.js` as the stable planner API.

Active mode:
- `CONFIG.PLANNER_MODE = "compat_v624"`

The service deliberately delegates to the existing final V6.22 hard-rule engine and V6.24 A/B/C generator instead of rewriting them.

Main planner entry now uses:
- `AUREA_PLANNER.open()`

Repair now uses:
- `AUREA_PLANNER.repair()`

A previously inactive `#asg-clearbad` repair button is now wired to the existing hard-invalid assignment repair routine.

No V6.22/V6.24 planner algorithm is deleted in Phase 13.

See `docs/PHASE13_PLANNER_AUDIT.md`.

Rollback snapshot: `phase13_rollback/`.


## Phase 14 — Planner regression tests + persistence audit

Phase 14 does not replace the planner algorithm.

It adds deterministic rule-level tests covering:
- Day Off / Vacation / Absent / inactive / left
- I can / I can't
- Entrance Duty boundary behavior
- configured gender
- DJ exclusion + event assignment
- same-operation conflicts
- time overlap
- Plan A/B/C generation
- max one activity per operation
- pre-write validation
- valid assignment persistence

It also documents the current persistence limitation: plan assignments are saved sequentially through `DB.saveActivity()` and are not database-atomic.

`AUREA_PLANNER.persistenceStatus()` exposes this fact as diagnostics only.

See `docs/PHASE14_PLANNER_TESTS_PERSISTENCE.md`.

Rollback snapshot: `phase14_rollback/`.


## Phase 15 — Atomic planner apply architecture

Phase 15 adds `js/planner/planner-apply-service.js`.

Active behavior is still:
- `CONFIG.PLANNER_APPLY_MODE = "legacy_sequential"`

The final Plan A/B/C Apply action now goes through the canonical planner
persistence boundary, which delegates to the exact existing V6.24/V6.22
sequential apply chain.

A future authenticated Postgres RPC path is prepared but cannot activate
without Supabase staff Auth, Manager permission, remote mode, `rpc_atomic`,
and an explicit `PLANNER_ATOMIC_RPC_DEPLOYED === true` flag that Phase 15
does not set.

The SQL design file is non-executable and fully commented.

See `docs/PHASE15_ATOMIC_PLANNER_APPLY.md`.

Rollback snapshot: `phase15_rollback/`.


## Phase 16 — Planner stale-plan protection

Phase 16 adds `js/planner/planner-concurrency.js`.

Active mode:
- `CONFIG.PLANNER_CONCURRENCY_MODE = "local_snapshot"`

Plan A/B/C now captures planner-relevant programme/team/attendance/duty state.
Before Apply, the filtered payload inherits that snapshot and the persistence
boundary checks that the context is still current.

If programme or availability changed, Apply is blocked before any write and the
Manager is asked to generate a fresh A/B/C set.

This is local preflight protection only; database-level locking/version checks
still belong in the future atomic RPC.

See `docs/PHASE16_PLANNER_CONCURRENCY.md`.

Rollback snapshot: `phase16_rollback/`.


## Phase 17 — V6.22 planner extraction

Phase 17 adds:

- `js/planner/smart-assignment-v622.js`

It is an exact byte-for-byte copy of the proven V6.22 hard-rule implementation.

The canonical planner copy now loads first. The preserved legacy V6.22 script
loads immediately afterward and safely exits through its existing one-time
guard, so no planner wrappers or repair hooks are duplicated.

The legacy file is intentionally retained for rollback/reference.

See `docs/PHASE17_V622_EXTRACTION.md`.

Rollback snapshot: `phase17_rollback/`.
