-- AUREA Phase 8 — RLS HELPER TEMPLATE
-- TEMPLATE ONLY. DO NOT RUN AS-IS.
do $$ begin
  raise exception 'AUREA PHASE 8 TEMPLATE BLOCKER: review and adapt in STAGING before execution';
end $$;

-- These helpers are examples for the final RLS migration.
-- They intentionally derive role from a protected application row linked to auth.uid().
--
-- create or replace function public.aurea_current_role()
-- returns text
-- language sql
-- stable
-- security definer
-- set search_path = public
-- as $$
--   select role
--   from public.app_users
--   where auth_user_id = auth.uid()
--     and active is distinct from false
--   limit 1
-- $$;
--
-- revoke all on function public.aurea_current_role() from public;
-- grant execute on function public.aurea_current_role() to authenticated;
--
-- create or replace function public.aurea_is_manager()
-- returns boolean
-- language sql
-- stable
-- security definer
-- set search_path = public
-- as $$
--   select public.aurea_current_role() = 'manager'
-- $$;
