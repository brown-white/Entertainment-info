-- AUREA Phase 8 — GUEST OWNERSHIP / RLS TEMPLATE
-- TEMPLATE ONLY. DO NOT RUN AS-IS.
do $$ begin
  raise exception 'AUREA PHASE 8 TEMPLATE BLOCKER: guest identity design is not finalized';
end $$;

-- AUREA guests are temporary hotel stays. Room number alone is NOT a secure ownership key.
-- Before Guest RLS is implemented, each authenticated guest identity must map to one exact stay.
--
-- Required conceptual relationship:
-- authenticated guest identity -> guest stay identity -> guest-owned rows
--
-- Candidate future fields (names are placeholders, not approved schema):
--   guest_accounts.auth_user_id uuid references auth.users(id)
--   bookings.guest_account_id   <matching guest_accounts primary-key type>
--   ticket_orders.guest_account_id
--   messages.guest_account_id
--   requests.guest_account_id
--
-- Policies must compare rows to the authenticated CURRENT stay, not only `room`.
--
-- Existing V6.19 lifecycle logic remains the application source of truth until this schema
-- has been designed, migrated, and tested in staging.
