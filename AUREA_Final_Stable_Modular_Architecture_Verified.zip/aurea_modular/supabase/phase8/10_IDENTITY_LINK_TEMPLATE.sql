-- AUREA Phase 8 — IDENTITY LINK TEMPLATE
-- TEMPLATE ONLY. DO NOT RUN AS-IS.
-- This blocker intentionally stops accidental execution.
do $$ begin
  raise exception 'AUREA PHASE 8 TEMPLATE BLOCKER: review and adapt in STAGING before execution';
end $$;

-- Intended direction after review:
-- 1. Link public.app_users to auth.users using the auth.users PRIMARY KEY only.
-- 2. Keep application role/active status in a protected public table, not editable user_metadata.
-- 3. Never store secret/service-role keys in browser code.
--
-- Example shape ONLY — column names/types must first be confirmed by 00_READ_ONLY_PRECHECK.sql:
--
-- alter table public.app_users
--   add column if not exists auth_user_id uuid null references auth.users(id) on delete set null,
--   add column if not exists auth_email text null;
--
-- create unique index if not exists app_users_auth_user_id_uidx
--   on public.app_users(auth_user_id)
--   where auth_user_id is not null;
--
-- Validation queries before any switch:
-- select id, username, role, active, auth_user_id, auth_email from public.app_users order by id;
-- select id, email from auth.users order by created_at;
--
-- Do not auto-link by email without manual verification of every account.
