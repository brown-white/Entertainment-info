-- AUREA Phase 8 — READ-ONLY PRECHECK
-- Safe to run in a staging SQL editor. This file contains SELECTs only.
-- It does NOT alter schema, users, policies, or data.

select current_database() as database_name, current_user as database_user;

select
  n.nspname as schema_name,
  c.relname as table_name,
  c.relrowsecurity as rls_enabled,
  c.relforcerowsecurity as rls_forced
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relkind = 'r'
  and c.relname in (
    'activities','announcements','app_settings','app_users','attendance',
    'bookings','buses','feedback','guest_accounts','messages','photos',
    'push_subscriptions','quiz_replies','quizzes','requests','rooms',
    'staff_attendance','staff_requests','tasks','team_profiles',
    'ticket_orders','tickets'
  )
order by c.relname;

select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
from pg_policies
where schemaname='public'
order by tablename, policyname;

select table_name, column_name, data_type, is_nullable
from information_schema.columns
where table_schema='public'
  and table_name in ('app_users','guest_accounts','bookings','ticket_orders','messages','requests')
order by table_name, ordinal_position;
