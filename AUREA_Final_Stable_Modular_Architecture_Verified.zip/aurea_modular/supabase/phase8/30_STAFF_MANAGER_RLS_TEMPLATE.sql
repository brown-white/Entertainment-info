-- AUREA Phase 8 — STAFF / MANAGER RLS TEMPLATE
-- TEMPLATE ONLY. DO NOT RUN AS-IS.
do $$ begin
  raise exception 'AUREA PHASE 8 TEMPLATE BLOCKER: review and adapt in STAGING before execution';
end $$;

-- IMPORTANT:
-- Enable policies table-by-table only after Supabase Auth staff identities are verified.
-- The exact columns and current policies must first be reviewed using 00_READ_ONLY_PRECHECK.sql.

-- Example: program content
-- alter table public.activities enable row level security;
-- create policy "authenticated can read activities"
-- on public.activities for select to authenticated
-- using (true);
--
-- create policy "manager can manage activities"
-- on public.activities for all to authenticated
-- using (public.aurea_is_manager())
-- with check (public.aurea_is_manager());

-- Example: app_users
-- Guests must never receive the whole staff directory/password data.
-- A final policy should expose only the minimum row(s) needed by an authenticated staff member,
-- and Manager management access should be explicit.
--
-- DO NOT enable this until legacy browser-side password login has been retired.
