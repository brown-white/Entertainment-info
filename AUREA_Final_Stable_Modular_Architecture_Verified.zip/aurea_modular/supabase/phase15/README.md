# Phase 15 Supabase Planner RPC

This folder contains design material only.

`10_ATOMIC_PLANNER_RPC_TEMPLATE.sql.example` is deliberately non-executable:
the entire content is inside a SQL block comment and the file uses `.sql.example`.

Do not deploy it yet.

The frontend remains on:

`PLANNER_APPLY_MODE = "legacy_sequential"`

and `PLANNER_ATOMIC_RPC_DEPLOYED` is intentionally absent.

The future RPC must be authenticated, Manager-authorized, concurrency-aware,
and must re-check authoritative planner constraints on the database side.
