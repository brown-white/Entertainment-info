/* ---------------- login ---------------- */
let loginMode="guest";
let guestMode="new";
let rememberMe=true;
let wiz={step:0,room:"",nat:"",name:"",phone:"",arr:"",dep:"",username:"",password:""};
function resetWiz(){ wiz={step:0,room:"",nat:"",name:"",phone:"",arr:"",dep:"",username:"",password:""}; }
let loginRole="staff";
function loginView(){
  const st=S.settings;
  const brand=`
    <div class="brandmark">
      <div class="mono serif${st.logo?" haslogo":""}">${st.logo
        ?`<img src="${esc(st.logo)}" alt="${esc(st.name||"")}">`
        :esc((st.name||"E").trim().charAt(0).toUpperCase())}</div>
      <h1>${esc(st.name)}</h1>
      <p>${esc(st.subtitle||t("appSub"))}</p>
    </div>
    <div class="lang-row">
      ${LANGS.map(([l,label])=>`<button data-lang="${l}" class="${S.lang===l?"on":""}">${label}</button>`).join("")}
    </div>`;
  if(loginMode==="guest"){
    const remRow=`<label class="remrow"><input type="checkbox" id="cb-rem" ${rememberMe?"checked":""}> ${t("rememberMe")}</label>`;
    const dots=`<div class="wz-dots">${[0,1,2,3,4,5,6].map(i=>`<span class="wz-dot ${wiz.step===i?"on":wiz.step>i?"done":""}"></span>`).join("")}</div>`;
    const backLink=wiz.step>0?`<button class="wz-back" id="wz-back">${ic("back",14)} ${t("backStep")}</button>`:"";
    let stepHtml="";
    if(wiz.step===0) stepHtml=`<label>${t("room")}</label>
        <button class="pickfield" id="wz-pick">${wiz.room?`<b>${esc(wiz.room)}</b>`:t("chooseRoom")}<span class="pf-ch">${ic("back",16)}</span></button>`;
    else if(wiz.step===1) stepHtml=`<label>${t("nationality")}</label>
        <button class="pickfield" id="wz-pick">${wiz.nat?`<b>${esc(wiz.nat)}</b>`:t("chooseNat")}<span class="pf-ch">${ic("back",16)}</span></button>`;
    else if(wiz.step===2) stepHtml=`<label>${t("name")}</label><input id="wz-in" value="${esc(wiz.name)}" placeholder="${t("name")}">`;
    else if(wiz.step===3) stepHtml=`<label>${t("phone")}</label><input id="wz-in" inputmode="tel" value="${esc(wiz.phone)}" placeholder="+49 ...">`;
    else if(wiz.step===4) stepHtml=`<label>${t("arrival")}</label><input id="wz-in" type="date" value="${esc(wiz.arr)}">`;
    else if(wiz.step===5) stepHtml=`<label>${t("departure")}</label><input id="wz-in" type="date" value="${esc(wiz.dep)}" min="${esc(wiz.arr)}">`;
    else stepHtml=`<label>${t("user")}</label><input id="wz-user" autocapitalize="none" value="${esc(wiz.username||wiz.room)}">
        <label>${t("pass")}</label><input id="wz-pass" autocapitalize="none" value="${esc(wiz.password)}" placeholder="••••••">
        ${remRow}`;
    const wizard=`
        ${dots}
        ${stepHtml}
        ${wiz.step<6
          ? `<button class="btn" id="wz-next">${t("nextStep")}</button>`
          : `<button class="btn" id="wz-create">${t("createAccount")}</button>`}
        ${backLink}`;
    const fields = guestMode==="new" ? wizard : `
        <label>${t("user")} · ${t("room")}</label><input id="f-room" inputmode="numeric" value="${esc(wiz.room)}" placeholder="4215">
        <label>${t("pass")}</label><input id="f-gpass" type="password" placeholder="••••••">
        ${remRow}`;
    return `<div class="login-wrap fadein">
      ${brand}
      <div class="role-tabs">
        <button data-gmode="signin" class="${guestMode==="signin"?"on":""}">${t("signin")}</button>
        <button data-gmode="new" class="${guestMode==="new"?"on":""}">${t("firstVisit")}</button>
      </div>
      <div class="login-card">
        ${fields}
        ${guestMode==="signin"?`<button class="btn" id="btn-login">${t("signin")}</button>`:""}
        <div class="err" id="login-err"></div>
        ${!REMOTE?`<p class="hint">${t("demoNote")}</p>`:""}
      </div>
      <button class="visitor-explore-btn" id="btn-public-explore">${ic("sparkle",16)} <span>Explore the entertainment</span><small>No account needed</small></button>
      <button class="staff-link" id="btn-teamlink">${ic("sparkle",15)} <span>${t("otherUsers")}</span></button>
    </div>`;
  }
  return `<div class="login-wrap fadein">
    ${brand}
    <div class="role-tabs">
      ${["staff","manager"].map(r=>`<button data-role="${r}" class="${loginRole===r?"on":""}">${t(r)}</button>`).join("")}
    </div>
    <div class="login-card">
      <label>${t("user")}</label><input id="f-user" autocapitalize="none" placeholder="${loginRole}">
      <label>${t("pass")}</label><input id="f-pass" type="password" placeholder="••••">
      <button class="btn" id="btn-login">${t("signin")}</button>
      <div class="err" id="login-err"></div>
    </div>
    <button class="visitor-explore-btn" id="btn-public-explore">${ic("sparkle",16)} <span>Explore the entertainment</span><small>No account needed</small></button>
    <button class="staff-link" id="btn-guestlink"><span>${t("backToGuest")}</span></button>
  </div>`;
}
function wireLogin(){
  document.querySelectorAll("[data-lang]").forEach(b=>b.onclick=()=>setLang(b.dataset.lang));
  document.querySelectorAll("#app [data-role]").forEach(b=>b.onclick=()=>{loginRole=b.dataset.role;render();});
  document.querySelectorAll("[data-gmode]").forEach(b=>b.onclick=()=>{guestMode=b.dataset.gmode;render();});
  const tl=$("#btn-teamlink"); if(tl) tl.onclick=()=>{loginMode="team";render();};
  const gl=$("#btn-guestlink"); if(gl) gl.onclick=()=>{loginMode="guest";render();};
  const px=$("#btn-public-explore"); if(px) px.onclick=()=>{ window.__PUBLIC_EXPLORE_V637=true; window.__PUBLIC_EXPLORE_DAY_V637=todayIndex(); render(); };
  const wireWizard=()=>{
    const err=$("#login-err");
    const pick=$("#wz-pick");
    if(pick) pick.onclick=()=>{ wiz.step===0?openRoomPicker():openNatPicker(); };
    const back=$("#wz-back");
    if(back) back.onclick=()=>{ wiz.step=Math.max(0,wiz.step-1); render(); };
    const next=$("#wz-next");
    if(next) next.onclick=()=>{
      if(wiz.step===0){
        if(!wiz.room){ err.textContent=t("loginErr"); return; }
        const existing=S.accounts.find(a=>String(a.room)===String(wiz.room));
        if(existing && existing.active!==false && !stayExpired(existing)){ err.textContent=t("accountExists"); guestMode="signin"; setTimeout(render,1500); return; }
      }
      if(wiz.step===1 && !wiz.nat){ err.textContent=t("loginErr"); return; }
      if(wiz.step===2){ wiz.name=$("#wz-in").value.trim(); if(!wiz.name){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===3){ wiz.phone=$("#wz-in").value.trim(); if(!wiz.phone){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===4){ wiz.arr=$("#wz-in").value; if(!wiz.arr){ err.textContent=t("loginErr"); return; } }
      if(wiz.step===5){
        wiz.dep=$("#wz-in").value;
        if(!wiz.dep || Date.parse(wiz.dep)<Date.parse(wiz.arr)){ err.textContent=t("loginErr"); return; }
      }
      wiz.step++; render();
    };
    const create=$("#wz-create");
    if(create) create.onclick=async ()=>{
      wiz.username=$("#wz-user").value.trim();
      wiz.password=$("#wz-pass").value.trim();
      const cb=$("#cb-rem"); rememberMe=cb?cb.checked:true;
      if(wiz.username.length<3 || wiz.password.length<4){ err.textContent=t("loginErr"); return; }
      const recyclable=S.accounts.find(a=>String(a.room)===String(wiz.room) && (a.active===false || stayExpired(a)));
      const taken=S.accounts.some(a=>a!==recyclable && String(a.username||"").toLowerCase()===wiz.username.toLowerCase())
        || (S.rooms.some(r=>String(r.room)===wiz.username) && wiz.username!==String(wiz.room));
      if(taken){ err.textContent=t("userExists"); return; }
      const rm=S.rooms.find(x=>String(x.room)===String(wiz.room));
      if(!rm || !rm.active){ err.textContent=t("roomNotFound"); return; }
      if(S.accounts.some(a=>String(a.room)===String(wiz.room) && a.active!==false && !stayExpired(a))){ err.textContent=t("accountExists"); guestMode="signin"; setTimeout(render,1500); return; }
      let acc;
      try{ acc=await DB.addAccount({room:wiz.room,name:wiz.name,phone:wiz.phone,nationality:wiz.nat,
        arrival:wiz.arr,departure:wiz.dep,username:wiz.username,password:wiz.password}); }
      catch(e){ err.textContent=t("loginErr"); return; }
      S.remember=rememberMe;
      resetWiz();
      startGuestSession(acc);
    };
  };
  if(loginMode==="guest" && guestMode==="new") wireWizard();
  const bl=$("#btn-login");
  if(bl) bl.onclick=async ()=>{
    const err=$("#login-err");
    if(loginMode==="guest"){
      const room=$("#f-room").value.trim();
      if(!room){ err.textContent=t("loginErr"); return; }
      const existing=S.accounts.find(a=>String(a.room)===room || String(a.username||"")===room);
      if(!existing){ err.textContent=t("roomNotFound"); return; }
      const rm=S.rooms.find(x=>String(x.room)===String(existing.room));
      if(!rm || !rm.active){ err.textContent=t("roomNotFound"); return; }
      const p=$("#f-gpass").value;
      if(existing.password && existing.password!==p){ err.textContent=t("loginErr"); return; }
      const cb=$("#cb-rem"); S.remember=rememberMe=(cb?cb.checked:true);
      startGuestSession(existing);
    } else {
      const uRaw=String($("#f-user").value||"").trim();
      const pRaw=String($("#f-pass").value||"");
      const u=uRaw.toLowerCase();
      const p=pRaw.trim();
      if(!u || !p){ err.textContent=t("loginErr"); return; }

      // One predictable authentication path for both Team and Manager.
      // Usernames are case-insensitive; passwords tolerate accidental leading/trailing spaces.
      let found=(S.users||[]).find(x=>
        String(x.username||"").trim().toLowerCase()===u &&
        !isAttOnly(x) &&
        (loginRole==="manager" ? x.role==="manager" : x.role==="staff")
      );

      // Authenticate only against a real Manager/Team account in the loaded user directory.
      // No hard-coded recovery password is exposed or accepted in production.
      if(!found || String(found.password==null?"":found.password).trim()!==p){
        err.textContent=t("loginErr"); return;
      }

      if(!accountActive(found)){ err.textContent=t("accountOff"); return; }
      clearAttempts();
      const role=loginRole==="manager"?"manager":"staff";
      S.remember=true;
      S.session={role,name:found.display_name||found.username,username:found.username||u,userId:found.id,number:found.number||null,photo:found.photo||''};
      S.tab=defaultTabFor(role); navReset(); persist();
      try{ render(); }catch(e){
        console.error("login render failed",e);
        // Keep the session and retry on a simple, low-dependency screen.
        S.tab=role==="manager"?"dash":"today"; if(role==="manager") S.sub.dash="overview"; persist(); render();
      }
      askNotifPermission();
    }
  };
}

function openRoomPicker(){
  const rooms=S.rooms.filter(r=>r.active).map(r=>String(r.room))
    .sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  const wrap=baseModal(`
    <h3>${ic("door",20)} ${t("chooseRoom")}</h3>
    <input id="pk-q" placeholder="..." inputmode="numeric" style="margin-top:8px">
    <div class="picklist">${rooms.length?rooms.map(r=>`<button class="pick-it" data-pick="${esc(r)}">${esc(r)}</button>`).join(""):`<p class="mini" style="padding:14px 6px;text-align:center">${t("noDataRooms")}</p>`}</div>
    <button class="btn ghost" id="pk-x">${t("close")}</button>`);
  wrap.querySelector("#pk-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{ wiz.room=b.dataset.pick; wrap.remove(); render(); });
  wrap.querySelector("#pk-q").oninput=e=>{
    const q=e.target.value.trim().toLowerCase();
    wrap.querySelectorAll(".pick-it").forEach(el=>{ el.style.display=!q||el.dataset.pick.toLowerCase().includes(q)?"":"none"; });
  };
}
function openNatPicker(){
  const wrap=baseModal(`
    <h3>${ic("flag",20)} ${t("chooseNat")}</h3>
    <input id="pk-q" placeholder="..." style="margin-top:8px">
    <div class="picklist one">${NATIONS.map(n=>`<button class="pick-it" data-pick="${esc(n)}">${esc(n)}</button>`).join("")}</div>
    <button class="btn ghost" id="pk-x">${t("close")}</button>`);
  wrap.querySelector("#pk-x").onclick=()=>wrap.remove();
  wrap.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>{
    const picked=b.dataset.pick;
    if(picked==="Other"){ wrap.remove(); openNatTypeModal(); return; }
    wiz.nat=picked; wrap.remove(); render();
  });
  wrap.querySelector("#pk-q").oninput=e=>{
    const q=e.target.value.trim().toLowerCase();
    wrap.querySelectorAll(".pick-it").forEach(el=>{ el.style.display=!q||el.dataset.pick.toLowerCase().includes(q)?"":"none"; });
  };
}
/* Lets the guest type a nationality that is not in the list */
function openNatTypeModal(){
  const wrap=baseModal(`
    <h3>${ic("flag",20)} ${t("typeNationality")}</h3>
    <input id="nt-v" placeholder="${esc(t("typeNationality"))}" autocapitalize="words" style="margin-top:8px">
    <button class="btn" id="nt-ok">${t("save")}</button>
    <button class="btn ghost" id="nt-back">${t("close")}</button>`);
  wrap.querySelector("#nt-back").onclick=()=>{ wrap.remove(); openNatPicker(); };
  wrap.querySelector("#nt-ok").onclick=()=>{
    const v=wrap.querySelector("#nt-v").value.trim();
    if(!v){ toastWarn(t("fieldRequired")); return; }
    wiz.nat=v; wrap.remove(); render();
  };
  setTimeout(()=>{ const i=wrap.querySelector("#nt-v"); if(i) i.focus(); },60);
}
function startGuestSession(acc){
  // a finished stay or a switched-off account can never start a session
  if(stayExpired(acc)){ toastWarn(t("stayEnded")); return; }
  if(acc.active===false){ toastWarn(t("accountOff")); return; }
  S.session={role:"guest",room:acc.room,name:acc.name,phone:acc.phone||"",
    nationality:acc.nationality||"",arrival:acc.arrival,departure:acc.departure,
    accountId:acc.id,username:acc.username||acc.room};
  S.tab="home"; persist(); render();
  askNotifPermission();
}
