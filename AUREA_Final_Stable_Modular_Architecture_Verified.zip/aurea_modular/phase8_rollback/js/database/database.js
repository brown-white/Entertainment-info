const DB = {
  async load(){
    if(REMOTE){
      const [a,b,u,s,tk,o,rm,ac,ms,rq,ts,nt,at,fb,tp,bs,qz,qr,sa,ph,sr] = await Promise.all([
        sb("activities?select=*&order=time"), sb("bookings?select=*"),
        sb("app_users?select=*"), sb("app_settings?select=*&id=eq.1"),
        sb("tickets?select=*&order=time"), sb("ticket_orders?select=*"),
        sb("rooms?select=*&order=room"), sb("guest_accounts?select=*"),
        sb("messages?select=*&order=created_at"), sb("requests?select=*&order=created_at.desc"),
        sb("tasks?select=*&order=created_at.desc"), sb("announcements?select=*&order=created_at.desc"),
        sb("attendance?select=*"), sb("feedback?select=*&order=created_at.desc"),
        sb("team_profiles?select=*&order=id"), sb("buses?select=*&order=sort"),
        sb("quizzes?select=*&order=quiz_date.desc"), sb("quiz_replies?select=*&order=created_at.desc"),
        sb("staff_attendance?select=*"),
        sb("photos?select=*&order=created_at.desc"), sb("staff_requests?select=*&order=created_at.desc"),
      ]);
      S.activities=a||[]; S.bookings=b||[]; S.users=u||[]; S.tickets=tk||[]; S.orders=o||[];
      S.rooms=rm||[]; S.accounts=ac||[]; S.messages=ms||[]; S.requests=rq||[];
      S.tasks=ts||[]; S.notes=nt||[]; S.attendance=at||[]; S.feedback=fb||[]; S.profiles=tp||[]; S.buses=bs||[];
      S.quizzes=qz||[]; S.quizReplies=qr||[]; S.staffAtt=sa||[]; S.photos=ph||[]; S.staffReqs=sr||[];
      {
        const rr=reconcileSettingsV626((s&&s[0]&&s[0].data)?s[0].data:DEFAULT_SETTINGS);
        S.settings=rr.settings;
        if(rr.localNewer){
          try{ await cloudUpsertSettingsV626(S.settings); }catch(e){ console.warn("settings cloud reconcile pending",e); }
        }
      }
    } else {
      S.activities=demoActivities(); S.bookings=demoBookings();
      S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
      S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
      S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
      S.quizzes=[]; S.quizReplies=[]; S.staffAtt=[]; S.photos=[]; S.staffReqs=[];
      S.buses=[{id:1,direction:"toHotel",time:"08:00",note:"",sort:0},{id:2,direction:"toHotel",time:"15:00",note:"",sort:1},{id:3,direction:"toHouse",time:"00:30",note:"",sort:2},{id:4,direction:"toHouse",time:"13:15",note:"",sort:3}];
      S.settings=reconcileSettingsV626(DEFAULT_SETTINGS).settings;
    }
  },
  async poll(){
    if(!REMOTE) return false;
    const [ms,rq,nt,b,o,ts]=await Promise.all([
      sb("messages?select=*&order=created_at"), sb("requests?select=*&order=created_at.desc"),
      sb("announcements?select=*&order=created_at.desc"), sb("bookings?select=*"),
      sb("ticket_orders?select=*"), sb("tasks?select=*&order=created_at.desc")
    ]);
    const changed = JSON.stringify(ms)!==JSON.stringify(S.messages)
      || JSON.stringify(rq)!==JSON.stringify(S.requests)
      || JSON.stringify(nt)!==JSON.stringify(S.notes)
      || JSON.stringify(b)!==JSON.stringify(S.bookings)
      || JSON.stringify(o)!==JSON.stringify(S.orders)
      || JSON.stringify(ts)!==JSON.stringify(S.tasks);
    S.messages=ms||[]; S.requests=rq||[]; S.notes=nt||[]; S.bookings=b||[]; S.orders=o||[]; S.tasks=ts||[];
    return changed;
  },
  async addBooking(bk){
    if(REMOTE){ const r=await sb("bookings",{method:"POST",body:JSON.stringify(bk)}); S.bookings.push(__row(r,bk)); }
    else { bk.id=Date.now(); S.bookings.push(bk); }
  },
  async removeBooking(id){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"DELETE"});
    S.bookings=S.bookings.filter(b=>b.id!==id);
  },
  async saveActivity(act){
    if(act.id){
      if(REMOTE){ const {id,...rest}=act; await sb("activities?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.activities=S.activities.map(a=>a.id===act.id?act:a);
    } else {
      if(REMOTE){ const r=await sb("activities",{method:"POST",body:JSON.stringify(act)}); S.activities.push(__row(r,act)); }
      else { act.id=Date.now(); S.activities.push(act); }
    }
  },
  async deleteActivity(id){
    if(REMOTE) await sb("activities?id=eq."+id,{method:"DELETE"});
    S.activities=S.activities.filter(a=>a.id!==id);
    S.bookings=S.bookings.filter(b=>b.activity_id!==id);
  },
  async updateBooking(id, patch){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.bookings=S.bookings.map(b=>b.id===id?{...b,...patch}:b);
  },
  async deleteBooking(id){
    if(REMOTE) await sb("bookings?id=eq."+id,{method:"DELETE"});
    S.bookings=S.bookings.filter(b=>b.id!==id);
  },
  async addPhoto(ph){
    if(REMOTE){ const r=await sb("photos",{method:"POST",body:JSON.stringify(ph)}); S.photos.unshift(__row(r,ph)); }
    else { ph.id=Date.now(); ph.created_at=new Date().toISOString(); S.photos.unshift(ph); }
  },
  async deletePhoto(id){
    if(REMOTE) await sb("photos?id=eq."+id,{method:"DELETE"});
    S.photos=S.photos.filter(x=>x.id!==id);
  },
  async addStaffReq(rq){
    if(REMOTE){ const r=await sb("staff_requests",{method:"POST",body:JSON.stringify(rq)}); S.staffReqs.unshift(__row(r,rq)); }
    else { rq.id=Date.now(); rq.created_at=new Date().toISOString(); S.staffReqs.unshift(rq); }
  },
  async updateStaffReq(id, patch){
    if(REMOTE) await sb("staff_requests?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.staffReqs=S.staffReqs.map(x=>x.id===id?{...x,...patch}:x);
  },
  async deleteStaffReq(id){
    if(REMOTE) await sb("staff_requests?id=eq."+id,{method:"DELETE"});
    S.staffReqs=S.staffReqs.filter(x=>x.id!==id);
  },
  async setStaffAtt(username, date, status){
    const found=S.staffAtt.find(x=>x.username===username && String(x.date).slice(0,10)===date);
    if(status===null){                       // back to the automatic value
      if(found){
        if(REMOTE) await sb("staff_attendance?id=eq."+found.id,{method:"DELETE"});
        S.staffAtt=S.staffAtt.filter(x=>x.id!==found.id);
      }
      return;
    }
    if(found){
      if(REMOTE) await sb("staff_attendance?id=eq."+found.id,{method:"PATCH",body:JSON.stringify({status})});
      S.staffAtt=S.staffAtt.map(x=>x.id===found.id?{...x,status}:x);
    } else {
      const row={username,date,status};
      if(REMOTE){ const r=await sb("staff_attendance",{method:"POST",body:JSON.stringify(row)}); S.staffAtt.push(__row(r,row)); }
      else { row.id=Date.now()+Math.random(); S.staffAtt.push(row); }
    }
  },
  async saveQuiz(q){
    if(q.id){
      if(REMOTE){ const {id,...rest}=q; await sb("quizzes?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.quizzes=S.quizzes.map(x=>x.id===q.id?{...x,...q}:x);
    } else {
      if(REMOTE){ const r=await sb("quizzes",{method:"POST",body:JSON.stringify(q)}); S.quizzes.unshift(__row(r,q)); }
      else { q.id=Date.now(); q.created_at=new Date().toISOString(); S.quizzes.unshift(q); }
    }
  },
  async deleteQuiz(id){
    if(REMOTE) await sb("quizzes?id=eq."+id,{method:"DELETE"});
    S.quizzes=S.quizzes.filter(q=>q.id!==id);
    S.quizReplies=S.quizReplies.filter(r=>r.quiz_id!==id);
  },
  async addQuizReply(r){
    if(REMOTE){ const res=await sb("quiz_replies",{method:"POST",body:JSON.stringify(r)}); S.quizReplies.unshift(__row(res,r)); }
    else { r.id=Date.now(); r.created_at=new Date().toISOString(); S.quizReplies.unshift(r); }
  },
  async saveBus(bus){
    if(bus.id){
      if(REMOTE){ const {id,...rest}=bus; await sb("buses?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.buses=S.buses.map(b=>b.id===bus.id?bus:b);
    } else {
      if(REMOTE){ const r=await sb("buses",{method:"POST",body:JSON.stringify(bus)}); S.buses.push(__row(r,bus)); }
      else { bus.id=Date.now(); S.buses.push(bus); }
    }
  },
  async deleteBus(id){
    if(REMOTE) await sb("buses?id=eq."+id,{method:"DELETE"});
    S.buses=S.buses.filter(b=>b.id!==id);
  },
  async saveTicket(tk){
    if(tk.id){
      if(REMOTE){ const {id,...rest}=tk; await sb("tickets?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)}); }
      S.tickets=S.tickets.map(x=>x.id===tk.id?tk:x);
    } else {
      if(REMOTE){ const r=await sb("tickets",{method:"POST",body:JSON.stringify(tk)}); S.tickets.push(__row(r,tk)); }
      else { tk.id=Date.now(); S.tickets.push(tk); }
    }
  },
  async deleteTicket(id){
    if(REMOTE) await sb("tickets?id=eq."+id,{method:"DELETE"});
    S.tickets=S.tickets.filter(x=>x.id!==id);
    S.orders=S.orders.filter(o=>o.ticket_id!==id);
  },
  async addOrder(o){
    if(REMOTE){ const r=await sb("ticket_orders",{method:"POST",body:JSON.stringify(o)}); S.orders.push(__row(r,o)); }
    else { o.id=Date.now(); S.orders.push(o); }
  },
  async deleteOrder(id){
    if(REMOTE) await sb("ticket_orders?id=eq."+id,{method:"DELETE"});
    S.orders=S.orders.filter(o=>o.id!==id);
  },
  async setOrderStatus(id,status){
    if(REMOTE) await sb("ticket_orders?id=eq."+id,{method:"PATCH",body:JSON.stringify({status})});
    S.orders=S.orders.map(o=>o.id===id?{...o,status}:o);
  },
  async addUser(u){
    if(REMOTE){ const r=await sb("app_users",{method:"POST",body:JSON.stringify(u)}); S.users.push(__row(r,u)); }
    else { u.id=Date.now(); S.users.push(u); }
  },
  async deleteUser(id){
    if(REMOTE) await sb("app_users?id=eq."+id,{method:"DELETE"});
    S.users=S.users.filter(x=>x.id!==id);
  },
  async addRooms(list){
    const fresh=list.filter(r=>!S.rooms.some(x=>x.room===r)).map(r=>({room:r,active:true}));
    if(!fresh.length) return;
    if(REMOTE){ const r=await sb("rooms",{method:"POST",body:JSON.stringify(fresh)}); S.rooms.push(...r); }
    else { fresh.forEach(f=>{f.id=Date.now()+Math.random(); S.rooms.push(f);}); }
    S.rooms.sort((a,b)=>String(a.room).localeCompare(String(b.room),undefined,{numeric:true}));
  },
  async setRoomActive(id,active){
    if(REMOTE) await sb("rooms?id=eq."+id,{method:"PATCH",body:JSON.stringify({active})});
    S.rooms=S.rooms.map(r=>r.id===id?{...r,active}:r);
  },
  async deleteRoom(id){
    const rm=S.rooms.find(r=>r.id===id); if(!rm) return;
    if(REMOTE){
      await sb("rooms?id=eq."+id,{method:"DELETE"});
      await sb("guest_accounts?room=eq."+encodeURIComponent(rm.room),{method:"DELETE"});
    }
    S.rooms=S.rooms.filter(r=>r.id!==id);
    S.accounts=S.accounts.filter(a=>a.room!==rm.room);
  },
  async addAccount(acc){
    if(REMOTE){ const r=await sb("guest_accounts",{method:"POST",body:JSON.stringify(acc)}); const created=__row(r,acc); S.accounts.push(created); return created; }
    acc.id=Date.now(); S.accounts.push(acc); return acc;
  },
  async updateAccount(id,patch){
    if(REMOTE) await sb("guest_accounts?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.accounts=S.accounts.map(a=>a.id===id?{...a,...patch}:a);
  },
  async updateUser(id,patch){
    if(REMOTE) await sb("app_users?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.users=S.users.map(u=>u.id===id?{...u,...patch}:u);
  },
  async addMessage(m){
    if(REMOTE){ const r=await sb("messages",{method:"POST",body:JSON.stringify(m)}); S.messages.push(__row(r,m)); }
    else { m.id=Date.now(); m.created_at=new Date().toISOString(); S.messages.push(m); }
  },
  async updateMessage(id,text){
    if(REMOTE) await sb("messages?id=eq."+id,{method:"PATCH",body:JSON.stringify({text})});
    S.messages=S.messages.map(m=>m.id===id?{...m,text}:m);
  },
  async deleteMessage(id){
    if(REMOTE) await sb("messages?id=eq."+id,{method:"DELETE"});
    S.messages=S.messages.filter(m=>m.id!==id);
  },
  async markRead(room,side){
    const flag = side==="team" ? "read_by_team" : "read_by_guest";
    const sender = side==="team" ? "guest" : "team";
    const unread=S.messages.filter(m=>m.room===room&&m.sender===sender&&!m[flag]);
    if(!unread.length) return;
    if(REMOTE) await sb("messages?room=eq."+encodeURIComponent(room)+"&sender=eq."+sender,{method:"PATCH",body:JSON.stringify({[flag]:true})});
    S.messages=S.messages.map(m=>m.room===room&&m.sender===sender?{...m,[flag]:true}:m);
  },
  async addRequest(r){
    if(REMOTE){ const x=await sb("requests",{method:"POST",body:JSON.stringify(r)}); S.requests.unshift(x[0]); }
    else { r.id=Date.now(); r.created_at=new Date().toISOString(); S.requests.unshift(r); }
  },
  async setRequestStatus(id,status){
    if(REMOTE) await sb("requests?id=eq."+id,{method:"PATCH",body:JSON.stringify({status})});
    S.requests=S.requests.map(r=>r.id===id?{...r,status}:r);
  },
  async deleteRequest(id){
    if(REMOTE) await sb("requests?id=eq."+id,{method:"DELETE"});
    S.requests=S.requests.filter(r=>r.id!==id);
  },
  async addTask(tk){
    if(REMOTE){ const r=await sb("tasks",{method:"POST",body:JSON.stringify(tk)}); S.tasks.unshift(__row(r,tk)); }
    else { tk.id=Date.now(); tk.created_at=new Date().toISOString(); S.tasks.unshift(tk); }
  },
  async updateTask(id,patch){
    if(REMOTE) await sb("tasks?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)});
    S.tasks=S.tasks.map(x=>x.id===id?{...x,...patch}:x);
  },
  async addFeedback(f){
    if(REMOTE){
      try{
        const r=await sb("feedback",{method:"POST",body:JSON.stringify(f)});
        S.feedback.unshift(__row(r,f));
      }catch(e){
        // older database without the depts / guest_name columns: keep the ratings in the comment
        const base={room:f.room,nationality:f.nationality||"",rate:f.rate,by_user:f.by_user||"",comment:fbPackComment(f)};
        const r=await sb("feedback",{method:"POST",body:JSON.stringify(base)});
        S.feedback.unshift(__row(r,base));
        S.fbOldDb=true;
      }
    }
    else { f.id=Date.now(); f.created_at=new Date().toISOString(); S.feedback.unshift(f); }
  },
  async updateFeedback(id,patch){
    const cur=(S.feedback||[]).find(x=>String(x.id)===String(id))||{};
    if(REMOTE){
      try{ await sb("feedback?id=eq."+id,{method:"PATCH",body:JSON.stringify(patch)}); }
      catch(e){
        const merged={...cur,...patch};
        const base={room:merged.room,nationality:merged.nationality||"",rate:merged.rate,comment:fbPackComment(merged)};
        await sb("feedback?id=eq."+id,{method:"PATCH",body:JSON.stringify(base)});
        patch=base; S.fbOldDb=true;
      }
    }
    S.feedback=S.feedback.map(x=>String(x.id)===String(id)?{...x,...patch}:x);
  },
  async deleteFeedback(id){
    if(REMOTE) await sb("feedback?id=eq."+id,{method:"DELETE"});
    S.feedback=S.feedback.filter(x=>String(x.id)!==String(id));
  },
  async saveProfile(pr){
    if(REMOTE){
      if(pr.id){ const {id,...rest}=pr; await sb("team_profiles?id=eq."+id,{method:"PATCH",body:JSON.stringify(rest)});
        S.profiles=S.profiles.map(x=>x.id===id?pr:x); }
      else { const r=await sb("team_profiles",{method:"POST",body:JSON.stringify(pr)}); S.profiles.push(__row(r,pr)); }
    } else {
      if(pr.id) S.profiles=S.profiles.map(x=>x.id===pr.id?pr:x);
      else { pr.id=Date.now(); S.profiles.push(pr); }
    }
  },
  async deleteProfile(id){
    if(REMOTE) await sb("team_profiles?id=eq."+id,{method:"DELETE"});
    S.profiles=S.profiles.filter(x=>x.id!==id);
  },
  async deleteTask(id){
    if(REMOTE) await sb("tasks?id=eq."+id,{method:"DELETE"});
    S.tasks=S.tasks.filter(x=>x.id!==id);
  },
  async addNote(n){
    if(REMOTE){ const r=await sb("announcements",{method:"POST",body:JSON.stringify(n)}); S.notes.unshift(__row(r,n)); }
    else { n.id=Date.now(); n.created_at=new Date().toISOString(); S.notes.unshift(n); }
  },
  async deleteNote(id){
    if(REMOTE) await sb("announcements?id=eq."+id,{method:"DELETE"});
    S.notes=S.notes.filter(n=>n.id!==id);
  },
  async setAttendance(bookingId,date,present){
    if(present){
      const row={booking_id:bookingId,date};
      if(REMOTE){ const r=await sb("attendance",{method:"POST",body:JSON.stringify(row)}); S.attendance.push(__row(r,row)); }
      else { row.id=Date.now(); S.attendance.push(row); }
    } else {
      if(REMOTE) await sb("attendance?booking_id=eq."+bookingId+"&date=eq."+date,{method:"DELETE"});
      S.attendance=S.attendance.filter(x=>!(x.booking_id===bookingId&&x.date===date));
    }
  },
  async saveSettings(st){
    const next={...DEFAULT_SETTINGS,...st,_settingsUpdatedAtV626:Date.now()};
    S.settings=next;
    writeSettingsBackupV626(next);              // survives app/browser closing immediately
    if(REMOTE) await cloudUpsertSettingsV626(next); // shared source for every device
    return next;
  }
};
