from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

current=ROOT/"js/planner/assignment-engine.js"
rollback=ROOT/"phase22_rollback/js/planner/assignment-engine.js"
v5=ROOT/"js/legacy/05-aurea-v5-smart-plans.js"
v622=ROOT/"js/planner/smart-assignment-v622.js"
index=ROOT/"index.html"

if not rollback.exists():
    errors.append("missing Phase 22 rollback copy of assignment-engine.js")

cur=current.read_text(encoding="utf-8")
old=rollback.read_text(encoding="utf-8") if rollback.exists() else ""

marker=(
"/* Phase 22: retired base autoAssignDay/autoAssignWeek implementations.\n"
"   Canonical runtime owner: js/planner/smart-assignment-v622.js.\n"
"   Exact pre-retirement code is preserved in phase22_rollback/js/planner/assignment-engine.js. */\n"
)

# Base declarations must be gone.
for name in ["autoAssignDay","autoAssignWeek"]:
    if re.search(rf'^\s*function\s+{name}\s*\(',cur,re.M):
        errors.append("base "+name+" still exists in assignment-engine.js")

# Canonical V6.22 must still install the runtime globals.
v622txt=v622.read_text(encoding="utf-8")
for needle in [
    "window.autoAssignDay=function(day,opts,sharedLoad)",
    "window.autoAssignWeek=function(opts)"
]:
    if needle not in v622txt:
        errors.append("canonical V6.22 assignment entry point missing: "+needle)

# Exact-delta proof: only replace the historical day/week block.
if old:
    lines=old.splitlines(keepends=True)
    try:
        start=next(i for i,l in enumerate(lines) if re.match(r'^\s*function\s+autoAssignDay\s*\(',l))
        end=next(i for i in range(start+1,len(lines)) if lines[i].startswith("/* Last tidy-up:"))
        removed="".join(lines[start:end])
        if "function autoAssignWeek(opts)" not in removed:
            errors.append("rollback block does not contain expected autoAssignWeek")
        if "function fixRepeats(" in removed:
            errors.append("retirement block accidentally includes fixRepeats")
        reconstructed="".join(lines[:start])+marker+"".join(lines[end:])
        if reconstructed!=cur:
            errors.append("assignment-engine.js changed beyond the audited day/week block retirement")
    except StopIteration:
        errors.append("could not locate historical base day/week block in rollback")

# Critical base dependencies must remain.
for needle in [
    "function fixRepeats(",
    "function balancePlan(",
    "function planBalance(",
    "async function applyAssignments(list)",
    "function eventsCrew(",
    "function assignableStaff(",
    "function activitySlot(",
    "function assignDateStr("
]:
    if needle not in cur:
        errors.append("critical base planner dependency missing: "+needle)

# V5 is the only pre-V6.22 runtime source that refers to autoAssignDay/Week.
# Its references must stay deferred inside makePlan and not execute on script load.
v5txt=v5.read_text(encoding="utf-8")
m=re.search(r"function makePlan\(day,scope,onlyEmpty,variant\)\{([^}]|\}(?!finally))*",v5txt)
if "function makePlan(day,scope,onlyEmpty,variant)" not in v5txt:
    errors.append("V5 deferred makePlan shape changed")
if "scope==='week'?autoAssignWeek({onlyEmpty}):autoAssignDay(day,{onlyEmpty})" not in v5txt:
    errors.append("V5 assignment lookup shape changed; re-audit startup safety")

# Confirm browser order: base -> V5 -> canonical V6.22 -> canonical V6.24.
html=index.read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',html)
try:
    base=scripts.index("js/planner/assignment-engine.js")
    v5i=scripts.index("js/legacy/05-aurea-v5-smart-plans.js")
    v622i=scripts.index("js/planner/smart-assignment-v622.js")
    v624i=scripts.index("js/planner/smart-plans-v624.js")
    if not (base < v5i < v622i < v624i):
        errors.append("planner/V5/V6.22/V6.24 startup order changed")
except ValueError as e:
    errors.append("required planner script missing from index: "+str(e))

# No other active pre-V6.22 JS may invoke or capture these names.
for p in ROOT.joinpath("js").rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    rel=str(p.relative_to(ROOT))
    if rel in {
        "js/planner/assignment-engine.js",
        "js/legacy/05-aurea-v5-smart-plans.js",
        "js/planner/smart-assignment-v622.js",
        "js/legacy/23-aurea-smart-assignment-v622-script.js",
    }:
        continue
    txt=p.read_text(encoding="utf-8",errors="ignore")
    if re.search(r'\b(autoAssignDay|autoAssignWeek)\b',txt):
        errors.append("unexpected active assignment entry-point dependency: "+rel)

# Conservative modes unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 22 removes only the superseded base autoAssignDay/autoAssignWeek bodies, preserves V5 deferred compatibility, V6.22 runtime ownership, base persistence/helpers, rollback, and all conservative safety modes.")
