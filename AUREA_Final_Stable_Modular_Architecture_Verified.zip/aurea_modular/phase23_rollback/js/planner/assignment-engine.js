/* ================= AUTOMATIC ACTIVITY ROSTER =================
   Rules (agreed with the manager):
   - every entertainer gets ONE morning and ONE afternoon activity
   - EVENTS are joined by the whole team, so they are never assigned to one person
   - the MANAGER (#1) and the DJ (#3) never get activities
   - anyone on their day off is skipped
   - it is FAIR: whoever has done the least so far goes first, and the
     starting point rotates each day so it is never the same person. */
/* #2 social media (films) and #3 the DJ (music) — events and shows only, never
   the normal activity rota. #1 is the manager. */
/* Attendance-only people: numbers 11–50. They exist so their days can be
   recorded and nothing else — no login, no activities, not on the day plan,
   not counted in the team. */
const ATT_ONLY_MIN=11, ATT_ONLY_MAX=50;
function isAttOnly(u){ return !!u && u.role==="attendance"; }
function nextAttNumber(){
  const taken=new Set((S.users||[]).map(u=>+u.number).filter(Boolean));
  for(let n=ATT_ONLY_MIN;n<=ATT_ONLY_MAX;n++) if(!taken.has(n)) return n;
  return null;
}
const DJ_NUMBER=3;
const EVENTS_ONLY_NUMBERS=[DJ_NUMBER];
const NO_ACTIVITY_NUMBERS=[1,2,3];          // manager, social media and DJ never enter the normal activity rota
/* Shows, parties and events belong to the DJ. Entertainers only receive normal activities. */
function eventsCrew(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && +u.number===DJ_NUMBER && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
function isEventsOnly(u){ return !!u && +u.number===DJ_NUMBER; }
function assignableStaff(day, dateStr_){
  return (S.users||[])
    .filter(u=>u.role==="staff" && u.number && !NO_ACTIVITY_NUMBERS.includes(+u.number)
      && availableOn(u,day,dateStr_))
    .sort((a,b)=>(a.number||99)-(b.number||99));
}
/* Hotel operation windows — one source of truth across rota, Whole Day and exports.
   Morning 10:00–12:30 · Afternoon 15:00–17:30 · Evening 19:30–23:00. */
function operationSlotFromMinutes(m){
  if(m==null || !Number.isFinite(+m)) return "other";
  m=+m;
  if(m>=10*60 && m<12*60+30) return "morning";
  if(m>=15*60 && m<17*60+30) return "afternoon";
  if(m>=19*60+30 && m<=23*60) return "evening";
  return "other";
}
/* Only mAdult enters the entertainer activity rota. Other programme categories remain event/show/party operations. */
function activitySlot(a){
  const c=normCat(a);
  if(c!=="mAdult") return "event";
  const w=actWindow(a);
  if(!w) return "other";
  return operationSlotFromMinutes(w.s0);
}
/* What each person ALREADY has that we are not going to touch.
   When she replaces everything, nothing is kept, so everyone starts at zero. */
function baseLoad(opts){
  const o=opts||{};
  const load={c:{}, last:{}, tick:0};
  (S.activities||[]).forEach(a=>{
    const slot=activitySlot(a);
    if(slot!=="morning" && slot!=="afternoon") return;
    const who=String(a.entertainer||"").trim().toLowerCase();
    if(!who) return;
    if(o.onlyEmpty) load.c[who]=(load.c[who]||0)+1;   // this one stays, so it counts
  });
  return load;
}
function baseCounts(opts){ return baseLoad(opts).c; }
function loadKey(u){ return String(u.username).toLowerCase(); }
function loadOf(load,u){ return (load.c&&load.c[loadKey(u)])||0; }
function bumpLoad(load,u,act,day){
  const k=loadKey(u);
  load.c[k]=(load.c[k]||0)+1;
  load.last[k]=++load.tick;                    // remember when they last got one
  if(act && act.name){                         // and which activity, so it is not repeated
    load.acts=load.acts||{};
    const ak=k+"|"+actKey(act.name);
    load.acts[ak]=(load.acts[ak]||0)+1;
    load.days=load.days||{};
    load.days[ak]=load.days[ak]||[];
    if(typeof day==="number") load.days[ak].push(day);
  }
}
/* Picks whoever has the FEWEST activities; if several are equal, the one who
   has waited longest. That keeps everybody within one of each other. */
/* Who already has this same activity on the other days of the week?
   Yesterday counts hardest, then anywhere else in the week. */
/* how far apart two weekdays are, going the short way round the week */
function dayGap(a,b){ const d=Math.abs(a-b)%7; return Math.min(d, 7-d); }
function repeatPenalty(u, act, day, load){
  if(!act || !act.name) return 0;
  /* what this run has already given them counts as much as what is saved */
  let planned=0, plannedYesterday=false;
  if(load && load.acts){
    const ak=loadKey(u)+"|"+actKey(act.name);
    planned=load.acts[ak]||0;
    plannedYesterday=((load.days&&load.days[ak])||[]).some(d=>dayGap(d,day)<=1);
  }
  const key=actKey(act.name), me=String(u.username||"").toLowerCase();
  const mine=a=>String(a.entertainer||"").toLowerCase().split(/\s*[,;\/]\s*/)
      .map(x=>x.trim()).some(x=>{
        if(!x) return false;
        if(x===me) return true;
        const disp=String(u.display_name||"").toLowerCase();
        return disp && x===disp;
      });
  const sameAct=(S.activities||[]).filter(a=>actKey(a.name)===key && a.day!==day && mine(a));
  const didYesterday=sameAct.some(a=>dayGap(a.day,day)<=1)
    || plannedYesterday
    || (((load&&load.days&&load.days[loadKey(u)+"|"+actKey(act.name)])||[]).some(d=>dayGap(d,day)<=1));
  const times=sameAct.length + planned;
  if(!times && !didYesterday) return 0;
  return (didYesterday?4:0) + times;               // repeated yesterday hurts most
}
function pickFairest(pool, load, usedThisSlot, act, day){
  /* fairness first: never the same activity twice for one person if it can be
     avoided, then an even share of the work, then whoever went longest ago */
  const score=u=>repeatPenalty(u,act,day,load)*1e9 + loadOf(load,u)*1e6 + (load.last[loadKey(u)]||0);
  /* only people who are allowed to run this activity */
  const allowed=act ? pool.filter(u=>canRunActivity(u,act) && !entranceConflict(u,day,act)) : pool;
  if(!allowed.length) return null;             // nobody may do it — leave it empty
  let best=null, bestScore=Infinity;
  allowed.forEach(u=>{
    if(usedThisSlot.has(u.username)) return;
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  if(best) return best;
  allowed.forEach(u=>{                         // more activities than people
    const sc=score(u);
    if(sc<bestScore){ bestScore=sc; best=u; }
  });
  return best;
}
/* One day. Pass a shared `load` so a whole week stays balanced across days. */
/* Phase 22: retired base autoAssignDay/autoAssignWeek implementations.
   Canonical runtime owner: js/planner/smart-assignment-v622.js.
   Exact pre-retirement code is preserved in phase22_rollback/js/planner/assignment-engine.js. */
/* Last tidy-up: if anyone still ends up with the same activity on two days next
   to each other, swap it with another activity on that same day. */
function fixRepeats(plan){
  const clash=(p, list)=>list.some(x=>x!==p
    && String(x.username).toLowerCase()===String(p.username).toLowerCase()
    && actKey(x.activity.name)===actKey(p.activity.name)
    && dayGap(x.activity.day, p.activity.day)<=1);
  for(let round=0; round<40; round++){
    const bad=plan.find(p=>p.slot!=="event" && clash(p, plan));
    if(!bad) break;
    const sameDay=plan.filter(x=>x!==bad && x.slot!=="event" && x.activity.day===bad.activity.day);
    let fixed=false;
    for(const other of sameDay){
      const u1=(S.users||[]).find(u=>u.username===bad.username);
      const u2=(S.users||[]).find(u=>u.username===other.username);
      if(!u1||!u2) continue;
      if(!canRunActivity(u1, other.activity) || !canRunActivity(u2, bad.activity)) continue;
      /* pretend the swap happened and check nobody is worse off */
      const trial=plan.map(x=> x===bad ? {...x, username:other.username, name:other.name}
                            : x===other ? {...x, username:bad.username, name:bad.name} : x);
      const a2=trial.find(x=>x.activity===bad.activity), b2=trial.find(x=>x.activity===other.activity);
      if(clash(a2,trial) || clash(b2,trial)) continue;
      plan=trial; fixed=true; break;
    }
    if(!fixed) break;                                  // cannot do better honestly
  }
  return plan;
}
/* Final tidy-up: if anyone is still more than one ahead, hand one of their
   activities to somebody who has fewer — but only if that person is actually
   working that day and does not already have that half of the day. */
function balancePlan(plan, opts){
  for(let guard=0; guard<300; guard++){
    const bal=planBalance(plan, opts);
    if(bal.spread<=1) break;
    const hi=Object.keys(bal.per).filter(k=>bal.per[k]===bal.max);
    const lo=Object.keys(bal.per).filter(k=>bal.per[k]===bal.min);
    let moved=false;
    for(const h of hi){
      for(const l of lo){
        for(let i=0;i<plan.length && !moved;i++){
          const it=plan[i];
          if(String(it.username).toLowerCase()!==h) continue;
          const day=it.activity.day;
          const cand=assignableStaff(day,assignDateStr(day)).find(u=>String(u.username).toLowerCase()===l);
          if(!cand) continue;                                   // not working that day
          if(!canRunActivity(cand, it.activity)) continue;       // they are not allowed to run it
          const clash=plan.some(x=>x!==it && x.activity.day===day && x.slot===it.slot
            && String(x.username).toLowerCase()===l);
          if(clash) continue;                                   // already has that half-day
          /* and never hand them the same activity on the day before or after */
          const nextTo=plan.some(x=>x!==it && String(x.username).toLowerCase()===l
            && actKey(x.activity.name)===actKey(it.activity.name)
            && dayGap(x.activity.day, day)<=1);      // same activity on a neighbouring day
          if(nextTo) continue;
          plan[i]={...it, username:cand.username, name:cand.display_name||cand.username};
          moved=true;
        }
        if(moved) break;
      }
      if(moved) break;
    }
    if(!moved) break;                                           // cannot improve further
  }
  return plan;
}
/* How even the result is — she sees this before applying. */
function planBalance(list, opts){
  const per={};
  const everyone=new Set();
  for(let d=0; d<7; d++) assignableStaff(d,assignDateStr(d)).forEach(u=>everyone.add(u.username));
  if((opts||{}).onlyEmpty){
    const b=baseCounts(opts);
    Object.keys(b).forEach(k=>{ per[k]=b[k]; });
  }
  everyone.forEach(u=>{ if(per[String(u).toLowerCase()]===undefined) per[String(u).toLowerCase()]=0; });
  list.forEach(x=>{ const k=String(x.username).toLowerCase(); per[k]=(per[k]||0)+1; });
  const vals=Object.values(per);
  return {per, min:vals.length?Math.min(...vals):0, max:vals.length?Math.max(...vals):0,
          spread:vals.length?Math.max(...vals)-Math.min(...vals):0};
}
async function applyAssignments(list){
  for(const it of list){
    try{ await DB.saveActivity({...it.activity, entertainer:it.username}); }
    catch(e){ toastErr(t("errSave")); return false; }
  }
  return true;
}
/* She sees the proposal, can change ANY name, and only then applies it. */
/* Phase 21: retired base openAutoAssignModal implementation.
   Canonical runtime owner: js/planner/smart-plans-v624.js.
   The exact pre-retirement body is preserved in phase21_rollback/js/planner/assignment-engine.js. */
/* Manager sets what a person can and cannot do — this drives automatic assignment. */
/* When an entertainer leaves: keep every day they worked, take them out of
   today's plans, and free their number for whoever replaces them. */
/* Open one booking: change how many people, move to waiting list, or remove it. */
function accountForRoom(room){
  const r=String(room||"").trim();
  return (S.accounts||[]).find(a=>String(a.room).trim()===r) || null;
}
function openBookingEditor(id){
  const b=(S.bookings||[]).find(x=>x.id===id); if(!b) return;
  const act=(S.activities||[]).find(a=>a.id===b.activity_id)||{};
  const wrap=baseModal(`
    <h3>${ic("pen",20)} ${t("editBooking")}</h3>
    <p class="mini">${esc(act.name||"")}${act.time?" · "+esc(act.time):""}</p>
    <div class="card" style="margin:10px 0">
      <div class="bk-line"><span class="mini">${t("room")}</span><b>${esc(b.room)}</b></div>
      <div class="bk-line"><span class="mini">${t("name")}</span><b>${esc(b.guest_name||"")}</b></div>
      ${b.phone?`<div class="bk-line"><span class="mini">${t("phone")}</span><b>${esc(b.phone)}</b></div>`:""}
      ${b.nationality?`<div class="bk-line"><span class="mini">${t("nationality")}</span><b>${esc(b.nationality)}</b></div>`:""}
      ${b.created_at?`<div class="bk-line"><span class="mini">${t("bookedAt")}</span><b>${esc(whenLabel(b.created_at))}</b></div>`:""}
    </div>
    <label>${t("persons")}</label>
    <input id="bk-n" type="number" min="1" max="20" value="${(+b.adults||1)+(+b.children||0)}" inputmode="numeric">
    <label style="margin-top:10px">${t("status")}</label>
    <select id="bk-st">
      <option value="booked" ${b.status!=="waitlist"?"selected":""}>${t("booked")}</option>
      <option value="waitlist" ${b.status==="waitlist"?"selected":""}>${t("waitlist")}</option>
    </select>
    <button class="btn" id="bk-save">${t("save")}</button>
    <button class="btn ghost" id="bk-open">${ic("user",15)} ${t("openGuest")}</button>
    <button class="btn warn" id="bk-del">${ic("trash",15)} ${t("removeBooking")}</button>
    <button class="btn ghost" id="bk-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#bk-x").onclick=()=>wrap.remove();
  const acc=accountForRoom(b.room);
  const openBtn=wrap.querySelector("#bk-open");
  if(openBtn){
    if(acc) openBtn.onclick=()=>{ wrap.remove(); S.tab="g360:"+acc.id; render(); };
    else { openBtn.disabled=true; openBtn.textContent=t("noGuestAccount"); }
  }
  wrap.querySelector("#bk-save").onclick=async ()=>{
    const n=Math.max(1,+wrap.querySelector("#bk-n").value||1);
    const st=wrap.querySelector("#bk-st").value;
    await DB.updateBooking(b.id,{adults:n, children:0, status:st});
    wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#bk-del").onclick=async ()=>{
    if(!(await confirmAction({title:t("removeBookingQ"), body:t("removeBookingHint"), danger:true}))) return;
    await DB.deleteBooking(b.id); wrap.remove(); toastOk(t("saved")); render();
  };
}
/* Set someone on holiday from one date to another, instead of tapping day by day. */
/* A person who is only on the attendance sheet — a name and a number, nothing else. */
function openAttPersonModal(userId){
  const u=userId ? (S.users||[]).find(x=>x.id===userId && isAttOnly(x)) : null;
  const suggested=u ? u.number : nextAttNumber();
  const wrap=baseModal(`
    <h3>${ic(u?"pen":"plus",20)} ${u?esc(u.display_name||""):t("addAttOnly")}</h3>
    <p class="mini">${t("addAttOnlyHint")}</p>
    <label>${t("name")}</label>
    <input id="ao-name" type="text" autocomplete="off" value="${u?esc(u.display_name||""):""}">
    <label style="margin-top:10px">${t("attNumber")}</label>
    <input id="ao-num" type="number" min="${ATT_ONLY_MIN}" max="${ATT_ONLY_MAX}" value="${suggested||ATT_ONLY_MIN}" inputmode="numeric">
    <div class="row2" style="margin-top:10px">
      <div><label>${t("startedOn")}</label>
        <input id="ao-from" type="date" value="${u&&u.hire_date?esc(String(u.hire_date).slice(0,10)):hotelDateStr()}"></div>
      <div><label>${t("lastDayOpt")}</label>
        <input id="ao-to" type="date" value="${u&&u.left_date?esc(String(u.left_date).slice(0,10)):""}"></div>
    </div>
    <p class="mini">${t("attDatesHint")}</p>
    <p class="mini" id="ao-err" style="color:#BE3C3C;min-height:16px"></p>
    <button class="btn" id="ao-go">${t("save")}</button>
    ${u?`<button class="btn warn" id="ao-del">${ic("trash",15)} ${t("delete")}</button>`:""}
    <button class="btn ghost" id="ao-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#ao-x").onclick=()=>wrap.remove();
  const del=wrap.querySelector("#ao-del");
  if(del) del.onclick=async ()=>{
    if(!(await confirmAction({title:t("deleteQ"), body:t("attDeleteHint"), danger:true}))) return;
    await DB.deleteUser(u.id); wrap.remove(); toastOk(t("saved")); render();
  };
  wrap.querySelector("#ao-go").onclick=async ()=>{
    const err=wrap.querySelector("#ao-err");
    const name=wrap.querySelector("#ao-name").value.trim();
    const num=+wrap.querySelector("#ao-num").value;
    const from=wrap.querySelector("#ao-from").value;
    const to=wrap.querySelector("#ao-to").value;
    if(!name){ err.textContent=t("nameNeeded"); return; }
    if(!(num>=ATT_ONLY_MIN && num<=ATT_ONLY_MAX)){ err.textContent=t("attNumRange"); return; }
    if((S.users||[]).some(x=>+x.number===num && (!u || x.id!==u.id))){ err.textContent=t("numberTaken"); return; }
    if(to && from && to<from){ err.textContent=t("checkDates"); return; }
    const patch={ display_name:name, number:num,
      hire_date:from||"", left_date:to||"", archived:!!to, active:!to };
    if(u){ await DB.updateUser(u.id, patch); }
    else {
      await DB.addUser({ username:"att"+num+"_"+Date.now().toString(36),
        password:"", role:"attendance", ...patch });
    }
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openVacationModal(username){
  const team=(S.users||[]).filter(u=>(u.role==="staff"||u.role==="manager"||isAttOnly(u)) && !hasLeft(u));
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("sun",20)} ${t("setVacation")}</h3>
    <p class="mini">${t("setVacationHint")}</p>
    <label>${t("person")}</label>
    <select id="vc-who">
      ${team.map(u=>`<option value="${esc(u.username)}" ${u.username===username?"selected":""}>${esc(u.display_name||u.username)}</option>`).join("")}
    </select>
    <div class="row2" style="margin-top:10px">
      <div><label>${t("fromDate")}</label><input id="vc-from" type="date" value="${today}"></div>
      <div><label>${t("toDate")}</label><input id="vc-to" type="date" value="${today}"></div>
    </div>
    <p class="mini" id="vc-count" style="margin-top:8px"></p>
    <button class="btn" id="vc-go">${t("setVacation")}</button>
    <button class="btn ghost" id="vc-clear">${t("clearVacation")}</button>
    <button class="btn ghost" id="vc-x">${t("cancelBtn")}</button>`);
  const from=wrap.querySelector("#vc-from"), to=wrap.querySelector("#vc-to");
  const note=wrap.querySelector("#vc-count");
  const daysBetween=()=>{
    const a=from.value, b=to.value;
    if(!a||!b||b<a) return [];
    const out=[]; const d=new Date(a+"T12:00:00"), end=new Date(b+"T12:00:00");
    while(d<=end && out.length<200){ out.push(d.toISOString().slice(0,10)); d.setDate(d.getDate()+1); }
    return out;
  };
  const refresh=()=>{
    const n=daysBetween().length;
    note.textContent = n ? (n+" "+t("daysWord")) : t("checkDates");
  };
  from.onchange=()=>{ if(to.value<from.value) to.value=from.value; refresh(); };
  to.onchange=refresh; refresh();
  wrap.querySelector("#vc-x").onclick=()=>wrap.remove();
  const apply=async status=>{
    const who=wrap.querySelector("#vc-who").value;
    const days=daysBetween();
    if(!days.length){ toastErr(t("checkDates")); return; }
    for(const d of days){ await DB.setStaffAtt(who, d, status); }
    wrap.remove(); toastOk(days.length+" "+t("daysWord")); render();
  };
  wrap.querySelector("#vc-go").onclick=()=>apply("V");
  wrap.querySelector("#vc-clear").onclick=()=>apply(null);
}
function openLeaveModal(userId){
  const u=(S.users||[]).find(x=>x.id===userId); if(!u) return;
  const today=hotelDateStr();
  const wrap=baseModal(`
    <h3>${ic("exit",20)} ${t("markLeft")}</h3>
    <p class="mini">${esc(u.display_name||u.username)} · ${t("markLeftHint")}</p>
    <label style="margin-top:10px">${t("leftDate")}</label>
    <input id="lv-date" type="date" value="${esc(u.left_date||today)}">
    <button class="btn" id="lv-go">${t("markLeft")}</button>
    ${hasLeft(u)?`<button class="btn ghost" id="lv-undo">${t("undoLeft")}</button>`:""}
    <button class="btn ghost" id="lv-x">${t("cancelBtn")}</button>`);
  wrap.querySelector("#lv-x").onclick=()=>wrap.remove();
  wrap.querySelector("#lv-go").onclick=async ()=>{
    const d=wrap.querySelector("#lv-date").value || today;
    await DB.updateUser(u.id,{left_date:d, archived:true, active:false, number:null});
    wrap.remove(); toastOk(t("saved")); render();
  };
  const un=wrap.querySelector("#lv-undo");
  if(un) un.onclick=async ()=>{
    await DB.updateUser(u.id,{left_date:"", archived:false, active:true});
    wrap.remove(); toastOk(t("saved")); render();
  };
}
function openSkillEditor(username){
  const u=(S.users||[]).find(x=>x.username===username); if(!u) return;
  if(!AUREA_PERMISSIONS.can('planner.manage')){ toast(t("profileReadOnly")); return; }
  if(u.role==="manager") return; // manager is never part of the activity skill matrix
  let can=canDoList(u), cant=cannotDoList(u);
  const wrap=baseModal(`
    <h3>${esc(u.display_name||u.username)}</h3>
    <p class="mini">${t("skillEditHint2")}</p>
    <div id="sk-box"></div>
    <button class="btn" id="sk-go">${t("save")}</button>
    <button class="btn ghost" id="sk-x">${t("cancelBtn")}</button>`);
  const box=wrap.querySelector("#sk-box");
  if(isEventsOnly(u)){
    box.innerHTML=`<p class="mini">${t("eventsCrewHint")}</p>`;
    const go=wrap.querySelector("#sk-go"); if(go) go.style.display="none";
    return;
  }
  const list=programActivities();
  const paint=()=>{
    if(!list.length){ box.innerHTML=`<p class="mini">${t("noActsYet")}</p>`; return; }
    box.innerHTML=list.map(([k,label])=>{
      const st=cant.includes(k)?"cant":(can.includes(k)?"can":"none");
      return `<button class="sk-btn ${st}" data-sk="${esc(k)}">
        <span>${esc(label)}</span>
        <span class="sk-tag">${st==="can"?t("skCan"):st==="cant"?t("skCant"):t("skAny")}</span>
      </button>`;}).join("");
    box.querySelectorAll("[data-sk]").forEach(b=>b.onclick=()=>{
      const k=b.dataset.sk;
      if(can.includes(k)){ can=can.filter(x=>x!==k); cant.push(k); }        // can -> can't
      else if(cant.includes(k)){ cant=cant.filter(x=>x!==k); }              // can't -> not set
      else { can.push(k); }                                                 // not set -> can
      paint();
    });
  };
  paint();
  wrap.querySelector("#sk-x").onclick=()=>wrap.remove();
  wrap.querySelector("#sk-go").onclick=async ()=>{
    await DB.updateUser(u.id,{can_do:can.join(";"), cannot_do:cant.join(";")});
    wrap.remove(); toast(t("saved")); render();
  };
}
/* ================= ASSIGNMENT CENTER =================
   One screen: who is working, what still has nobody, tasks, and one-tap
   automatic assignment that the manager reviews before anything is saved. */
function assignDay(){
  if(S.assignDay==null) S.assignDay=todayIndex();
  return S.assignDay;
}
function assignDateStr(day){
  const base=hotelDateStr(), td=todayIndex();
  let diff=day-td; if(diff<0) diff+=7;
  const d=new Date(base+"T12:00:00"); d.setDate(d.getDate()+diff);
  return d.toISOString().slice(0,10);
}
/* how many of the team are allowed to run this activity */
function whoCanRun(a){
  if(activitySlot(a)==="event"){
    const dj=(S.users||[]).find(u=>u.role==="staff" && +u.number===DJ_NUMBER && u.active!==false && !hasLeft(u));
    return dj ? ((dj.display_name||dj.username)+" · DJ") : "DJ —";
  }
  const ds=assignDateStr(a.day);
  const team=assignableStaff(a.day,ds);
  const n=team.filter(u=>canRunActivity(u,a) && !entranceConflict(u,a.day,a)).length;
  return n+"/"+team.length+" "+t("canRunIt");
}
/* Entrance duty lives here now — Day Plan only handles days off. */
function openEntranceModal(day){
  const dp=dayPlanFor(day);
  const roster=[];
  for(let n=1;n<=10;n++) roster.push({n, name:nameForNumber(n), role:roleForNumber(n)});
  const wrap=baseModal(`
    <h3>${ic("door",20)} ${t("entranceDuty")}</h3>
    <p class="mini">${t("dutyFor")}: <b>${esc(t("days")[day]||"")}</b></p>
    <label style="margin-top:10px">${t("selectEntrance")}</label>
    <select id="ent-sel">
      <option value="">—</option>
      ${roster.map(r=>`<option value="${r.n}" ${dp.entrance===r.n?"selected":""}>#${r.n} ${esc(r.name||r.role)}</option>`).join("")}
    </select>
    <button class="btn" id="ent-save">${t("save")}</button>
    <button class="btn ghost" id="ent-x">${t("close")}</button>`);
  wrap.querySelector("#ent-x").onclick=()=>wrap.remove();
  wrap.querySelector("#ent-save").onclick=async ()=>{
    const raw=wrap.querySelector("#ent-sel").value;
    const all={...(S.settings.dayOverrides||{})};
    const cur=all[String(day)] || {off:[...dp.off], entrance:dp.entrance};
    all[String(day)]={...cur, entrance: raw?+raw:null};   // days off stay as they are
    try{
      await DB.saveSettings({...S.settings, dayOverrides:all});
      wrap.remove(); toastOk(t("dutySaved")); render();
    }catch(e){ toastErr(t("errSave")); }
  };
}
function assignView(){
  const day=assignDay(), ds=assignDateStr(day);
  const sub=S.sub.assign||"acts";
  const acts=(S.activities||[]).filter(a=>a.day===day)
    .sort((a,b)=>(timeToMin(a.time)||0)-(timeToMin(b.time)||0));
  const open=acts.filter(a=>!String(a.entertainer||"").trim());
  const team=(S.users||[]).filter(u=>u.role==="staff"); // manager never runs activities and has no can/can't profile
  const working=team.filter(u=>availableOn(u,day,ds));
  const offList=team.filter(u=>!availableOn(u,day,ds));
  const openTasks=(S.tasks||[]).filter(x=>taskStatus(x)!=="verified");
  return `<div class="screen fadein">
    ${topBar(t("assignCenter"),"")}
    <div class="seg" id="asg-tabs">
      <button class="${sub==="acts"?"on":""}" data-asub="acts">${t("asgActs")}${open.length?` <span class="seg-b">${open.length}</span>`:""}</button>
      <button class="${sub==="tasks"?"on":""}" data-asub="tasks">${t("tasks")}${openTasks.length?` <span class="seg-b">${openTasks.length}</span>`:""}</button>
      <button class="${sub==="who"?"on":""}" data-asub="who">${t("asgWho")}</button>
    </div>
    <div class="daypick" id="asg-days">
      ${t("daysShort").map((d,i)=>`<button class="${i===day?"on":""}" data-aday="${i}">${d}</button>`).join("")}
    </div>
    ${sub==="acts"?assignActsInner(day,ds,acts,open,working)
     :sub==="tasks"?`<div style="margin-top:12px">${tasksInner()}</div>`
     :assignWhoInner(day,ds,working,offList)}
  </div>`;
}
function assignActsInner(day, ds, acts, open, working){
  return `
    <div class="g3-stats" style="margin-top:12px">
      <div class="stat"><b>${acts.length}</b><span>${t("activities")}</span></div>
      <div class="stat"><b>${open.length}</b><span>${t("asgOpen")}</span></div>
      <div class="stat"><b>${working.length}</b><span>${t("workingToday")}</span></div>
    </div>
    <div class="card ent-card" id="asg-ent" style="margin-top:12px">
      <span class="ent-ic">${ic("door",20)}</span>
      <span class="asg-mid"><b>${t("entranceDuty")}</b>
        <span class="mini">${personTag(dayPlanFor(day).entrance)||t("noOneEntrance")}</span></span>
      <span class="ent-go">${ic("pen",15)}</span>
    </div>
    ${open.length?`<button class="btn" id="asg-auto" style="margin-top:12px">
        ${ic("sparkle",18)} ${t("autoAssign")}</button>
      <p class="mini" style="margin-top:6px">${t("autoAssignHint")}</p>`
      :`<div class="ok-note" style="margin-top:12px">${ic("check",18)} ${t("allAssigned")}</div>`}
    <div class="card" style="margin-top:12px">
      ${acts.length?acts.map(a=>{
        const who=String(a.entertainer||"").trim();
        const sk=activitySkill(a);
        return `<div class="asg-row" data-aopen="${a.id}">
          <span class="asg-t">${esc(a.time||"")}</span>
          <span class="asg-mid"><b>${esc(a.name)}</b>
            <span class="mini">${esc(whoCanRun(a))}${a.location?" · "+esc(a.location):""}</span></span>
          ${who?`<span class="asg-who">${esc(who)}</span>`
               :`<span class="asg-who none">${t("asgNobody")}</span>`}
        </div>`;}).join("")
        :`<p class="mini" style="padding:8px 2px">${t("noneToday")}</p>`}
    </div>`;
}
function assignWhoInner(day, ds, working, offList){
  const row=(u,ok)=>{
    const can=canDoList(u), cant=cannotDoList(u);
    const ent=onEntranceDuty(u,day);
    const n=assignedCount(u.username,day);
    return `<div class="asg-row" data-aemp="${esc(u.username)}">
      <span class="loc-av">${esc(String(u.display_name||u.username).trim().charAt(0).toUpperCase())}</span>
      <span class="asg-mid"><b>${esc(u.display_name||u.username)}</b>
        <span class="mini">${ok?`${n} ${t("activities")}${ent?" · "+t("entranceDuty"):""}`
          :(notYetHired(u,ds.slice(0,7),+ds.slice(8,10))?t("attN")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="A"?t("attA")
            :attStatus(u,ds.slice(0,7),+ds.slice(8,10))==="V"?t("attV")
            :t("dayOff"))}</span>
        ${isEventsOnly(u)?`<span class="skill-chips"><span class="chip evt">${t("eventsCrewTag")}</span></span>`
         :(can.length||cant.length?`<span class="skill-chips">
          ${can.map(k=>`<span class="chip can">${esc(prettyAct(k))}</span>`).join("")}
          ${cant.map(k=>`<span class="chip cant">${esc(prettyAct(k))}</span>`).join("")}
        </span>`:`<span class="mini dim">${t("noSkillsSet")}</span>`)}
      </span></div>`;};
  return `<p class="mini" style="margin:12px 0 6px">${t("asgWhoHint")}</p>
    <div class="card">${working.length?working.map(u=>row(u,true)).join(""):`<p class="mini">${t("nobodyWorking")}</p>`}</div>
    ${offList.length?`<h4 style="margin:16px 0 8px">${t("dayOffToday")}</h4>
      <div class="card dim-card">${offList.map(u=>row(u,false)).join("")}</div>`:""}`;
}
/* "Today 14:30", "Yesterday 09:15", otherwise the date — so nothing is a mystery. */
function whenLabel(ts){
  if(!ts) return "";
  const d=new Date(ts);
  if(isNaN(d.getTime())) return "";
  const time=d.toLocaleTimeString(S.lang||"en",{hour:"2-digit",minute:"2-digit"});
  const dayOf=x=>{ const y=new Date(x); y.setHours(0,0,0,0); return y.getTime(); };
  const today=dayOf(hotelNow()), that=dayOf(d);
  const diff=Math.round((today-that)/86400000);
  if(diff===0) return t("todayWord")+" "+time;
  if(diff===1) return t("yesterdayWord")+" "+time;
  if(diff>1 && diff<7) return t("days")[d.getDay()]+" "+time;
  return d.toLocaleDateString(S.lang||"en",{day:"2-digit",month:"short"})+" "+time;
}
/* Collect a dated list into one row per day, newest first. Tap a day to open it. */
function dayKeyOf(ts){ const d=new Date(ts); return isNaN(d)?"" : d.toISOString().slice(0,10); }
function dayHeading(key){
  const today=hotelDateStr();
  const y=new Date(today+"T12:00:00"); y.setDate(y.getDate()-1);
  const yest=y.toISOString().slice(0,10);
  if(key===today) return t("todayWord");
  if(key===yest)  return t("yesterdayWord");
  const d=new Date(key+"T12:00:00");
  return d.toLocaleDateString(S.lang||"en",{weekday:"short",day:"2-digit",month:"2-digit",year:"numeric"});
}
function groupByDay(list, tsField){
  const map=new Map();
  (list||[]).forEach(x=>{
    const k=dayKeyOf(x[tsField||"created_at"]) || "0000-00-00";
    if(!map.has(k)) map.set(k,[]);
    map.get(k).push(x);
  });
  return [...map.entries()].sort((a,b)=>b[0].localeCompare(a[0]));
}
function openDayKey(kind){ return (S.openDay && S.openDay[kind]) || null; }
function dayGroups(kind, list, tsField, rowFn, unitKey){
  const groups=groupByDay(list, tsField);
  if(!groups.length) return `<div class="empty"><div class="big">${ic("calendar",30)}</div>${t("none")}</div>`;
  const open=openDayKey(kind) || groups[0][0];
  return `<div class="dg-wrap">${groups.map(([key,items])=>{
    const isOpen=key===open;
    return `<div class="dg ${isOpen?"open":""}">
      <button class="dg-h" data-dgopen="${esc(kind)}|${esc(key)}">
        <span class="dg-t">${esc(dayHeading(key))}</span>
        <span class="dg-d">${esc(key.split("-").reverse().join("/"))}</span>
        <span class="dg-n">${items.length} ${t(unitKey||"itemsWord")}</span>
        <span class="dg-c">${ic("back",14)}</span>
      </button>
      ${isOpen?`<div class="dg-body">${items.map(rowFn).join("")}</div>`:""}
    </div>`;}).join("")}</div>`;
}
/* ================= SKILLS & AUTOMATIC ASSIGNMENT =================
   A person is only ever suggested for an activity when ALL of these hold:
     - they are employed on that date (hire date) and not on a day off
     - they are not marked absent
     - they are not on entrance duty at that hour
     - the activity's skill is in their "can do" and NOT in their "can't do"
     - they are not already busy at that time
   The manager always reviews the suggestions before anything is saved. */
/* The list she ticks is her OWN programme — the real activity names —
   so automatic assignment matches exactly what is on the plan. */
function actKey(name){ return String(name||"").trim().toLowerCase().replace(/\s+/g," "); }
function programActivities(){
  const seen=new Map();
  (S.activities||[]).forEach(a=>{
    if(activitySlot(a)!=="morning" && activitySlot(a)!=="afternoon") return; // no events/shows/parties in entertainer skills
    const k=actKey(a.name);
    if(k && !seen.has(k)) seen.set(k, String(a.name).trim());
  });
  return [...seen.entries()].sort((x,y)=>x[1].localeCompare(y[1]));
}
/* turn a stored key back into the activity name as she wrote it */
function prettyAct(k){
  const hit=programActivities().find(([key])=>key===k);
  return hit ? hit[1] : k;
}
function parseSkills(v){
  return String(v||"").split(/[;|\n]/).map(x=>actKey(x)).filter(Boolean);
}
function canDoList(u){ return parseSkills(u && u.can_do); }
function cannotDoList(u){ return parseSkills(u && u.cannot_do); }
/* the skill an activity needs — set on the activity, else guessed from its name */
function activitySkill(a){
  const explicit=String(a && a.needs_skill||"").trim().toLowerCase();
  if(explicit) return explicit;
  const n=String((a&&a.name)||"").toLowerCase();
  const guess=[["water",/aqua|water|pool|snorkel|swim/],["dance",/dance|zumba|salsa|show ?dance/],
    ["show",/show|theatre|theater|performance|stage/],["kids",/kids|mini ?disco|children/],
    ["dj",/\bdj\b|disco|party/],["music",/music|band|karaoke|sing/],
    ["fitness",/gym|fitness|yoga|pilates|stretch|workout/],
    ["sport",/football|volley|tennis|basket|boccia|petanque|dart|archer|bowl|table ?tennis|sport/],
    ["beach",/beach|sunset|sand/],["craft",/craft|paint|workshop|art/],
    ["games",/game|quiz|bingo|tournament|cocktail/]];
  for(const [k,re] of guess){ if(re.test(n)) return k; }
  return "host";
}
/* Can this person run THIS activity? */
function canRunActivity(u, act){
  const k=actKey(act && act.name);
  if(!k) return true;
  if(cannotDoList(u).includes(k)) return false;   // "can't do" always wins
  const can=canDoList(u);
  if(!can.length) return true;                     // nothing ticked = available for anything
  return can.includes(k);
}
/* is this person available on that weekday? */
function availableOn(u, day, dateStr_){
  if(!u || u.role==="guest") return false;
  if(u.active===false) return false;
  if(hasLeft(u)) return false;
  const mk=String(dateStr_||"").slice(0,7), dd=+String(dateStr_||"").slice(8,10);
  if(mk && dd && notYetHired(u,mk,dd)) return false;      // not employed yet
  if(mk && dd){
    const st=attStatus(u,mk,dd);
    if(st==="A" || st==="V") return false;               // absent or on vacation
  }
  let num=u.number; if(!num && u.role==="manager") num=1;
  const dp=dayPlanFor(day);
  if(num && dp.off.includes(num)) return false;            // day off
  return true;
}
function onEntranceDuty(u, day){
  let num=u.number; if(!num && u.role==="manager") num=1;
  return !!num && dayPlanFor(day).entrance===num;
}
/* Entrance duty takes the person out of activities from 16:00 until 18:30. */
function entranceConflict(u, day, act){
  if(!onEntranceDuty(u,day)) return false;
  const w=actWindow(act);
  if(!w) return true; // unknown time: safer not to create a mistaken assignment
  const dutyStart=16*60, dutyEnd=18*60+30;
  return w.s0 < dutyEnd && w.e0 > dutyStart;
}
/* activities already on this person for that day, to spot clashes and share the load */
function assignedCount(username, day, extra){
  const name=String(username||"").toLowerCase();
  let n=(S.activities||[]).filter(a=>a.day===day &&
    String(a.entertainer||"").toLowerCase().split(/[,;]/).map(x=>x.trim()).includes(name)).length;
  return n+((extra&&extra[username])||0);
}
function timeToMin(hhmm){
  const m=String(hhmm||"").match(/(\d{1,2}):(\d{2})/);
  return m ? (+m[1])*60+(+m[2]) : null;
}
/* Global time formatter used by manager Live Operations and later enhancement layers.
   It MUST live in base scope; keeping it inside a later IIFE caused runtime ReferenceError on login. */
function fmtCountdown(sec){
  sec=Math.max(0,Math.floor(Number(sec)||0));
  const h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), ss=sec%60;
  return (h?String(h).padStart(2,"0")+":":"")+String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");
}
window.fmtCountdown=fmtCountdown;
/* Suggest one person per unassigned activity on a given weekday. */
