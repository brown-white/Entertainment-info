function tickStatus(){ if(S.session && safeToRender()) render(); }
async function runPoll(){
  if(!REMOTE || __polling || !S.session) return;
  if(enforceAccess()){ render(); return; }
  __polling=true;
  try{ const before=notifySnapshot(); const changed=await DB.poll();
    if(changed){ detectAndNotify(before); if(safeToRender()) render(); }
  }catch(e){}
  __polling=false;
}
/* Maps a database table to the matching array in app state. */
const RT_TABLES={
  activities:"activities", bookings:"bookings", app_users:"users", tickets:"tickets",
  ticket_orders:"orders", rooms:"rooms", guest_accounts:"accounts", messages:"messages",
  requests:"requests", tasks:"tasks", announcements:"notes", attendance:"attendance",
  feedback:"feedback", team_profiles:"profiles", buses:"buses", quizzes:"quizzes", quiz_replies:"quizReplies", staff_attendance:"staffAtt", photos:"photos", staff_requests:"staffReqs"
};
/* Applies ONE row change straight into state — no full database reload. */
function applyRealtimeChange(payload){
  try{
    const table=payload.table, ev=payload.eventType||payload.type;
    // app_settings is a single row of config — merge it directly
    if(table==="app_settings"){
      const row=payload.new;
      if(row && row.data){ S.settings={...DEFAULT_SETTINGS,...row.data}; applySettings(); return true; }
      return false;
    }
    const key=RT_TABLES[table]; if(!key || !Array.isArray(S[key])) return false;
    const list=S[key];
    if(ev==="INSERT" && payload.new){
      if(!list.some(x=>x.id===payload.new.id)) list.push(payload.new);
      return true;
    }
    if(ev==="UPDATE" && payload.new){
      const i=list.findIndex(x=>x.id===payload.new.id);
      if(i>=0) list[i]={...list[i],...payload.new}; else list.push(payload.new);
      return true;
    }
    if(ev==="DELETE"){
      const oldRow=payload.old||{};
      if(oldRow.id==null) return false;
      S[key]=list.filter(x=>x.id!==oldRow.id);
      return true;
    }
  }catch(e){ console.warn("realtime patch failed:", e && e.message); }
  return false;
}
function startRealtime(){
  if(!REMOTE || window.__rt) return;
  window.__rt=true;
  const sc=document.createElement("script");
  sc.src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
  sc.onload=()=>{ try{
    const client=window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
    let tmr=null, pending=false;
    client.channel("live-changes")
      .on("postgres_changes",{event:"*",schema:"public"},payload=>{
        const before=notifySnapshot();
        const patched=applyRealtimeChange(payload);
        if(patched){
          // targeted update: state is already correct, just alert + repaint
          detectAndNotify(before);
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ if(S.session && safeToRender()) render(); }, 120);
        } else if(!pending){
          // unknown table -> fall back to a single full refresh
          pending=true;
          clearTimeout(tmr);
          tmr=setTimeout(()=>{ pending=false; runPoll(); }, 300);
        }
      })
      .subscribe();
  }catch(e){ console.warn("realtime unavailable",e); } };
  sc.onerror=()=>console.warn("realtime script blocked — polling continues");
  document.head.appendChild(sc);
}
(async function(){
  restore();
  document.documentElement.setAttribute("data-theme",S.theme);
  document.documentElement.lang=S.lang;
  document.documentElement.dir=(S.lang==="ar"?"rtl":"ltr");
  try{ await DB.load(); }
  catch(e){
    console.error(e);
    if(REMOTE){ S.loadError=true; applySettings(); render(); return; }
    S.activities=demoActivities(); S.bookings=demoBookings();
    S.users=DEMO_USERS.map(u=>({...u})); S.tickets=demoTickets(); S.orders=demoOrders();
    S.rooms=demoRooms(); S.accounts=demoAccounts(); S.messages=demoMessages();
    S.requests=demoRequests(); S.tasks=demoTasks(); S.notes=demoNotes(); S.attendance=[]; S.feedback=demoFeedback(); S.profiles=demoProfiles();
  }
  /* Phase 5: validate and refresh remembered session through one canonical boundary. */
  if(S.session) AUREA_AUTH.refreshCurrent();
  /* V5: resolve the final landing screen before the first paint, preventing the remembered-screen -> start-screen flash. */
  if(S.session) S.tab=defaultTabFor(S.session.role);
  enforceAccess();
  applyOpenParam();
  applySettings();
  render();
  startRealtime();
  // Fast polling backup — makes updates feel instant even if websockets are blocked.
  if(REMOTE){
    setInterval(()=>{ if(S.session) runPoll(); }, 5000);
    // Poll immediately when the app regains focus or becomes visible
    window.addEventListener("focus", ()=>{ if(S.session) runPoll(); });
    document.addEventListener("visibilitychange", ()=>{ if(!document.hidden && S.session) runPoll(); });
  }
  initPhotoTaps();
  setTimeout(()=>loadWeather(false), 800);
  initConnectionWatch();
  initErrorGuard();
  // ===== Activity alarms + live status dots =====
  // Check every 30s so a minute boundary is never missed; re-render keeps dots current.
  let __lastMin=-1;
  function alarmTick(){
    try{
      checkActivityAlarms();
      const m=nowMinutes();
      if(m!==__lastMin){ __lastMin=m; tickStatus(); }   // refresh dots once per minute
    }catch(e){}
  }
  setInterval(alarmTick, 30000);
  setTimeout(alarmTick, 1500);                            // run shortly after load
  window.addEventListener("focus", alarmTick);            // catch phone waking up
  document.addEventListener("visibilitychange", ()=>{ if(!document.hidden) alarmTick(); });
})();
