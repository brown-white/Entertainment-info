
const fs=require('fs'),vm=require('vm');

global.window=global;
global.document={querySelector(){return null},querySelectorAll(){return[]}};
global.setTimeout=()=>0;
global.clearTimeout=()=>{};
global.toastErr=(m)=>{global.__toastErr=String(m||'')};
global.toastWarn=()=>{};
global.toastOk=()=>{};
global.toast=()=>{};
global.render=()=>{};
global.t=(x)=>x;
global.ic=()=>''; global.esc=x=>String(x??'');
global.baseModal=()=>({innerHTML:'',querySelector(){return null},querySelectorAll(){return[]}});
global.confirmAction=async()=>true;
global.openEditModal=()=>{};
global.hotelDateStr=()=> '2026-09-14';
global.hotelNow=()=>new Date('2026-09-14T12:00:00');
global.todayIndex=()=>0;
global.assignDateStr=()=> '2026-09-14';
global.dayGap=(a,b)=>{const d=Math.abs(a-b)%7;return Math.min(d,7-d)};
global.normCat=a=>a&&a.cat||'mAdult';
global.activityType=a=>a&&a.type||'balanced';
global.activityWindows=a=>{
  if(!a||a.s0==null||a.e0==null)return [];
  return [{s0:a.s0,e0:a.e0,start:'',end:''}];
};
global.actWindow=a=>activityWindows(a)[0]||null;
global.timeToMin=s=>{
  const m=String(s||'').match(/(\d{1,2}):(\d{2})/);
  return m?(+m[1])*60+(+m[2]):null;
};
global.hasLeft=u=>!!(u&&(u.archived||u.left_date));
global.notYetHired=()=>false;
global.attStatus=(u)=>u&&u.__status||'';
global.dayPlanFor=()=>global.__dayPlan||{off:[],entrance:null};
global.personTag=()=>''; global.isFutureDay=()=>false;
global.leftBefore=()=>false;
global.programActivities=()=>[];
global.AUREA_PERMISSIONS={can:()=>true};

global.S={
  session:{role:'manager',username:'manager'},
  users:[],activities:[],settings:{activityGenderRequirements:{}},
  staffAtt:[], bookings:[], orders:[], rooms:[], accounts:[], messages:[], requests:[],
  tasks:[], notes:[], attendance:[], feedback:[], profiles:[], buses:[], quizzes:[],
  quizReplies:[], photos:[], staffReqs:[]
};

let saved=[];
global.DB={
  saveActivity:async row=>{saved.push({...row}); const i=S.activities.findIndex(a=>a.id===row.id); if(i>=0)S.activities[i]={...row};},
  setStaffAtt:async()=>{},
  saveSettings:async next=>{S.settings=next;}
};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[3],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[4],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[5],'utf8'));

function staff(number,extra={}){
  return {username:'u'+number,display_name:'U'+number,role:'staff',number,active:true,gender:'female',...extra};
}
function act(id,name,day,s0,e0,extra={}){
  return {id,name,day,s0,e0,time:'15:30',cat:'mAdult',type:'balanced',entertainer:'',...extra};
}
function assert(cond,msg){if(!cond)throw new Error(msg)}

// --- Availability hard rules ---
const u4=staff(4);
S.users=[u4];
global.__dayPlan={off:[4],entrance:null};
assert(availableOn(u4,0,'2026-09-14')===false,'day off not blocked');

global.__dayPlan={off:[],entrance:null};
u4.__status='V';
assert(availableOn(u4,0,'2026-09-14')===false,'vacation not blocked');
u4.__status='A';
assert(availableOn(u4,0,'2026-09-14')===false,'absence not blocked');
u4.__status='';
u4.active=false;
assert(availableOn(u4,0,'2026-09-14')===false,'inactive staff not blocked');
u4.active=true;
u4.left_date='2026-09-01';
assert(availableOn(u4,0,'2026-09-14')===false,'left staff not blocked');
delete u4.left_date;

// --- I can / I can't ---
u4.can_do='Yoga; Stretching';
u4.cannot_do='';
assert(canRunActivity(u4,{name:'Yoga'})===true,'can-do activity rejected');
assert(canRunActivity(u4,{name:'Water Gym'})===false,'unlisted activity accepted despite can-do list');
u4.cannot_do='Yoga';
assert(canRunActivity(u4,{name:'Yoga'})===false,"can't-do did not override can-do");
u4.can_do=''; u4.cannot_do='';

// --- Entrance boundary: 15:30-16:00 allowed; 15:45-16:15 blocked ---
global.__dayPlan={off:[],entrance:4};
assert(entranceConflict(u4,0,act(1,'Stretching',0,15*60+30,16*60))===false,'15:30-16:00 should be allowed');
assert(entranceConflict(u4,0,act(2,'Yoga',0,15*60+45,16*60+15))===true,'15:45-16:15 should be blocked');
assert(entranceConflict(u4,0,act(3,'Unknown',0,null,null))===true,'unknown time should be blocked for entrance duty');
global.__dayPlan={off:[],entrance:null};

// --- Gender rule ---
S.settings.activityGenderRequirements={'yoga':'male'};
assert(AUREA_SMART_ASSIGNMENT_V622.hardAvailable(u4,{name:'Yoga',day:0,s0:600,e0:630},0)===false,'configured gender rule not enforced');
u4.gender='male';
assert(AUREA_SMART_ASSIGNMENT_V622.hardAvailable(u4,{name:'Yoga',day:0,s0:600,e0:630},0)===true,'matching configured gender rejected');
u4.gender='female';
S.settings.activityGenderRequirements={};

// --- DJ excluded from normal pool, DJ owns event ---
const dj=staff(3,{username:'dj',display_name:'DJ'});
const u5=staff(5),u6=staff(6);
S.users=[dj,u4,u5,u6];
assert(assignableStaff(0,'2026-09-14').some(u=>u.number===3)===false,'DJ entered normal activity pool');
S.activities=[
  act(10,'Yoga',0,600,630),
  {id:11,name:'Beach Party',day:0,s0:1200,e0:1260,time:'20:00',cat:'eParty',entertainer:''}
];
const dayPlan=autoAssignDay(0,{onlyEmpty:false});
const ev=dayPlan.find(x=>x.activity.id===11);
assert(ev&&ev.username==='dj','event was not assigned to DJ');

// --- Same-operation and overlap validation ---
S.activities=[
  act(20,'Yoga',0,600,630,{entertainer:'u4'}),
  act(21,'Stretching',0,660,690,{entertainer:'u4'})
];
assert(AUREA_SMART_ASSIGNMENT_V622.valid(S.activities[0])===false,'two morning activities for same person not rejected');

S.activities=[
  act(22,'Yoga',0,600,660,{entertainer:'u4'}),
  act(23,'Stretching',0,630,690,{entertainer:'u4',cat:'mAdult'})
];
assert(AUREA_SMART_ASSIGNMENT_V622.valid(S.activities[0])===false,'overlapping activities not rejected');

// --- A/B/C generation + max one per operation + fairness sanity ---
S.users=[u4,u5,u6,staff(7)];
S.activities=[
  act(30,'Yoga',0,600,630),
  act(31,'Darts',0,630,660),
  act(32,'Stretching',0,900,930),
  act(33,'Boccia',0,930,960),
];
const plans=AUREA_SMART_PLANS_V624.generateSet('day',0,false,1);
assert(plans.length===3,'did not produce Plan A/B/C');
for(const p of plans){
  const normal=p.filter(x=>x.slot!=='event'&&x.username);
  const keys=normal.map(x=>x.username+'|'+x.day+'|'+x.slot);
  assert(new Set(keys).size===keys.length,'plan contains more than one activity per entertainer per operation');
}

// --- Apply validation occurs before writes for invalid same-operation plan ---
S.activities=[
  act(40,'Yoga',0,600,630),
  act(41,'Darts',0,660,690)
];
saved=[]; __toastErr='';
(async()=>{
  const invalid=[
    {activity:S.activities[0],username:'u4',slot:'morning',day:0},
    {activity:S.activities[1],username:'u4',slot:'morning',day:0}
  ];
  const ok=await applyAssignments(invalid);
  assert(ok===false,'invalid same-operation plan was applied');
  assert(saved.length===0,'invalid plan wrote rows before validation completed');

  // Valid plan writes each assignment.
  saved=[]; __toastErr='';
  const valid=[
    {activity:S.activities[0],username:'u4',slot:'morning',day:0},
    {activity:S.activities[1],username:'u5',slot:'morning',day:0}
  ];
  const ok2=await applyAssignments(valid);
  assert(ok2===true,'valid plan failed');
  assert(saved.length===2,'valid plan did not persist every assignment');

  const ps=AUREA_PLANNER.persistenceStatus();
  assert(ps.atomic===false&&ps.strategy==='sequential-db-saveActivity','persistence diagnostic is inaccurate');

  console.log('PASS: planner hard rules, A/B/C generation, pre-write validation, and persistence diagnostics');
})().catch(e=>{console.error(e);process.exit(1)});
