from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

service=(ROOT/"js/planner/planner-service.js").read_text(encoding="utf-8")
if "Phase 13 safety guard" not in service:
    errors.append("missing planner replacement safety guard")
for api in ["AUREA_SMART_ASSIGNMENT_V622","AUREA_SMART_PLANS_V624"]:
    if api not in service:
        errors.append("planner facade missing dependency: "+api)

wiring=(ROOT/"js/core/wiring.js").read_text(encoding="utf-8")
if "AUREA_PLANNER.open(assignDay())" not in wiring:
    errors.append("Generate Plans button is not routed through planner facade")
if 'const aRepair=$("#asg-clearbad")' not in wiring or "AUREA_PLANNER.repair()" not in wiring:
    errors.append("Repair Invalid button is not wired through planner facade")

# Ensure final legacy layers still exist and expose their APIs.
v622=(ROOT/"js/planner/smart-assignment-v622.js").read_text(encoding="utf-8")
v624=(ROOT/"js/planner/smart-plans-v624.js").read_text(encoding="utf-8")
for needle in ["window.AUREA_SMART_ASSIGNMENT_V622","hardAvailable622","repairSmartAssignmentsV622"]:
    if needle not in v622: errors.append("V6.22 authority changed/missing: "+needle)
for needle in ["window.AUREA_SMART_PLANS_V624","generateSet624","window.applyAssignments=applyAssignments"]:
    if needle not in v624: errors.append("V6.24 authority changed/missing: "+needle)

# Load order: facade after V6.24, wiring itself is earlier but executes only after full boot.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    if scripts.index("js/planner/planner-service.js") <= scripts.index("js/planner/smart-plans-v624.js"):
        errors.append("planner facade must load after V6.24")
except ValueError:
    errors.append("missing planner service/V6.24 script reference")

# Syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Facade behavior.
r=subprocess.run([
    "node",str(ROOT/"tests/phase13_planner_facade_smoke.js"),
    str(ROOT/"js/planner/planner-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("planner facade smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 13 keeps V6.22/V6.24 authoritative, routes planner entry/repair through one facade, preserves all safety modes, and fixes the inactive repair button.")
