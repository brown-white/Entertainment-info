
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={PLANNER_MODE:'compat_v624'};
global.S={session:{role:'manager'}};
global.t=()=> 'read only';
global.toast=()=>{};
let opened=null, applied=null, repaired=0;

global.AUREA_PERMISSIONS={can:(cap)=>cap==='planner.manage'};
global.AUREA_SMART_ASSIGNMENT_V622={
  version:'6.22',
  valid:a=>a && a.valid===true,
  hardAvailable:(u,a,d)=>!!(u&&a&&d===2)
};
global.AUREA_SMART_PLANS_V624={
  version:'6.24',
  generateSet:(scope,day,onlyEmpty,generation)=>[
    [{scope,day,onlyEmpty,generation,id:'A'}],
    [{scope,day,onlyEmpty,generation,id:'B'}],
    [{scope,day,onlyEmpty,generation,id:'C'}]
  ]
};
global.applyAssignments=async list=>{applied=list;return true;};
global.repairSmartAssignmentsV622=async()=>{repaired++;return true;};
global.openAutoAssignModal=day=>{opened=day;};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));

if(AUREA_PLANNER.apiStatus().assignmentApi!=='6.22')throw new Error('wrong assignment API');
if(AUREA_PLANNER.apiStatus().plansApi!=='6.24')throw new Error('wrong plans API');
const plans=AUREA_PLANNER.generate('week',4,false,7);
if(plans.length!==3 || plans[1][0].id!=='B')throw new Error('A/B/C generation delegation failed');
if(!AUREA_PLANNER.validateExisting({valid:true}))throw new Error('validation delegation failed');
if(!AUREA_PLANNER.hardAvailable({x:1},{x:1},2))throw new Error('hard availability delegation failed');
if(!AUREA_PLANNER.open(5)||opened!==5)throw new Error('modal delegation failed');

(async()=>{
  const rows=[{activity:{id:1},username:'solo'}];
  if(!(await AUREA_PLANNER.apply(rows))||applied!==rows)throw new Error('apply delegation failed');
  if(!(await AUREA_PLANNER.repair())||repaired!==1)throw new Error('repair delegation failed');
  const rules=AUREA_PLANNER.hardRules();
  if(!rules.maxOnePerOperation||!rules.djExcludedFromNormalActivities||rules.alternativePlans!==3)
    throw new Error('rule contract missing');
  console.log('PASS: planner facade delegates to V6.22/V6.24 without replacing planner behavior');
})().catch(e=>{console.error(e);process.exit(1)});
