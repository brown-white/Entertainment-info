from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

service=(ROOT/"js/planner/planner-service.js").read_text(encoding="utf-8")
for needle in ["persistenceStatus","sequential-db-saveActivity","atomic:false","validatesBeforeWrite:true"]:
    if needle not in service:
        errors.append("missing planner persistence diagnostic: "+needle)

# Confirm current persistence is still sequential and unchanged.
base=(ROOT/"js/planner/assignment-engine.js").read_text(encoding="utf-8")
m=re.search(r'async function applyAssignments\(list\)\{(.*?)\n\}',base,re.S)
if not m:
    errors.append("base applyAssignments not found")
else:
    body=m.group(1)
    if "for(const it of list)" not in body or "await DB.saveActivity" not in body:
        errors.append("base applyAssignments persistence structure changed")

v622=(ROOT/"js/legacy/23-aurea-smart-assignment-v622-script.js").read_text(encoding="utf-8")
for needle in ["await DB.saveActivity({...a,entertainer:pick.username})",
               "await DB.saveActivity({...a,entertainer:\"\"})",
               "DB.setStaffAtt=async function",
               "DB.saveSettings=async function"]:
    if needle not in v622:
        errors.append("V6.22 repair persistence hook changed/missing: "+needle)

# All active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Run real rule regression suite.
r=subprocess.run([
    "node",str(ROOT/"tests/phase14_planner_rules.js"),
    str(ROOT/"js/planner/assignment-engine.js"),
    str(ROOT/"js/planner/smart-assignment-v622.js"),
    str(ROOT/"js/planner/smart-plans-v624.js"),
    str(ROOT/"js/planner/planner-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("planner rule suite failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 14 hard-rule regression suite passes, persistence remains unchanged/sequential, diagnostics are accurate, and all safety modes stay conservative.")
