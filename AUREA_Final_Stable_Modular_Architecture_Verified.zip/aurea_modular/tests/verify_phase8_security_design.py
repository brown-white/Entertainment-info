from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

config=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
m=re.search(r'AUTH_MODE:\s*"([^"]+)"',config)
if not m or m.group(1)!="legacy":
    errors.append("AUTH_MODE must remain legacy in Phase 8")

pre=(ROOT/"supabase/phase8/00_READ_ONLY_PRECHECK.sql").read_text(encoding="utf-8")
# Strip comments and whitespace, then allow SELECT statements only.
pre_body="\n".join(line.split("--",1)[0] for line in pre.splitlines()).strip().lower()
for forbidden in ["alter ","create ","drop ","insert ","update ","delete ","grant ","revoke ","truncate "]:
    if forbidden in pre_body:
        errors.append("read-only precheck contains mutation keyword: "+forbidden.strip())

templates=[
    "10_IDENTITY_LINK_TEMPLATE.sql",
    "20_RLS_HELPERS_TEMPLATE.sql",
    "30_STAFF_MANAGER_RLS_TEMPLATE.sql",
    "40_GUEST_RLS_TEMPLATE.sql",
]
for name in templates:
    p=ROOT/"supabase/phase8"/name
    if not p.exists():
        errors.append("missing template: "+name); continue
    body=p.read_text(encoding="utf-8")
    if "PHASE 8 TEMPLATE BLOCKER" not in body:
        errors.append("missing execution blocker: "+name)

# No SQL is referenced/executed by index.html.
index=(ROOT/"index.html").read_text(encoding="utf-8")
if "supabase/phase8/" in index:
    errors.append("Phase 8 SQL must not be loaded by the browser")

# Active JS syntax must remain valid.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Legacy auth compatibility smoke must still pass.
smoke=ROOT/"tests/phase7_auth_smoke.js"
if smoke.exists():
    r=subprocess.run([
        "node",str(smoke),
        str(ROOT/"js/auth/supabase-auth-adapter.js"),
        str(ROOT/"js/auth/auth-service.js")
    ],capture_output=True,text=True)
    if r.returncode:
        errors.append("Phase 7 legacy auth smoke regressed")

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 8 is non-destructive, templates are blocked, AUTH_MODE is legacy, and active JS still parses.")
