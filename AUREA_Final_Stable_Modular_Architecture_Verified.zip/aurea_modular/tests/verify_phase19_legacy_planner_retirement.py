from pathlib import Path
import re,subprocess,sys,hashlib

ROOT=Path(__file__).resolve().parents[1]
errors=[]

legacy622=ROOT/"js/legacy/23-aurea-smart-assignment-v622-script.js"
legacy624=ROOT/"js/legacy/24-aurea-smart-plans-v624-script.js"
canon622=ROOT/"js/planner/smart-assignment-v622.js"
canon624=ROOT/"js/planner/smart-plans-v624.js"

# Legacy files must remain physically available for rollback/reference.
for p in [legacy622,legacy624]:
    if not p.exists():
        errors.append("legacy planner reference file was deleted: "+str(p.relative_to(ROOT)))

# Canonical copies must remain exact while we retire only browser references.
for c,l,label in [(canon622,legacy622,"V6.22"),(canon624,legacy624,"V6.24")]:
    if not c.exists():
        errors.append("missing canonical "+label)
    elif l.exists():
        if c.read_bytes()!=l.read_bytes():
            errors.append(label+" canonical/legacy bytes diverged during reference retirement")
        if hashlib.sha256(c.read_bytes()).hexdigest()!=hashlib.sha256(l.read_bytes()).hexdigest():
            errors.append(label+" canonical/legacy SHA mismatch")

index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)

# No live legacy planner scripts.
for old in [
    "js/legacy/23-aurea-smart-assignment-v622-script.js",
    "js/legacy/24-aurea-smart-plans-v624-script.js",
]:
    if old in scripts:
        errors.append("legacy planner script is still active in index: "+old)

# Canonical runtime ordering.
try:
    base=scripts.index("js/planner/assignment-engine.js")
    c622=scripts.index("js/planner/smart-assignment-v622.js")
    c624=scripts.index("js/planner/smart-plans-v624.js")
    conc=scripts.index("js/planner/planner-concurrency.js")
    apply=scripts.index("js/planner/planner-apply-service.js")
    facade=scripts.index("js/planner/planner-service.js")
    if not (base < c622 < c624 < conc < apply < facade):
        errors.append("unexpected canonical planner runtime load order")
except ValueError as e:
    errors.append("canonical planner runtime reference missing: "+str(e))

# Active HTML/JS must not dynamically load old filenames.
old_names=[
    "23-aurea-smart-assignment-v622-script.js",
    "24-aurea-smart-plans-v624-script.js",
]
for p in [ROOT/"index.html", *ROOT.joinpath("js").rglob("*.js")]:
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    txt=p.read_text(encoding="utf-8",errors="ignore")
    if p in (legacy622,legacy624):
        continue
    for name in old_names:
        if name in txt:
            errors.append("active runtime file still references old planner filename: "+str(p.relative_to(ROOT))+" -> "+name)

# Conservative safety modes remain unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# All active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 19 removes only live legacy planner script references, preserves exact rollback files, keeps canonical load order, and changes no safety mode.")
