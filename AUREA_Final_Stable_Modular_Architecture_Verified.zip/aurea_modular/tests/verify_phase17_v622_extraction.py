from pathlib import Path
import re,subprocess,sys,hashlib

ROOT=Path(__file__).resolve().parents[1]
errors=[]

canonical=ROOT/"js/planner/smart-assignment-v622.js"
legacy=ROOT/"js/legacy/23-aurea-smart-assignment-v622-script.js"

if not canonical.exists():
    errors.append("missing canonical V6.22 planner module")
if not legacy.exists():
    errors.append("legacy V6.22 compatibility file was deleted")

if canonical.exists() and legacy.exists():
    cb=canonical.read_bytes()
    lb=legacy.read_bytes()
    if cb!=lb:
        errors.append("canonical V6.22 is not byte-for-byte equal to preserved legacy V6.22")
    if hashlib.sha256(cb).hexdigest()!=hashlib.sha256(lb).hexdigest():
        errors.append("canonical/legacy V6.22 SHA mismatch")

# Guard is what makes preserved legacy file inert after canonical executes.
if canonical.exists():
    c=canonical.read_text(encoding="utf-8")
    for needle in [
        "if(window.__AUREA_SMART_ASSIGNMENT_V622)return;",
        "window.__AUREA_SMART_ASSIGNMENT_V622=true;",
        "window.AUREA_SMART_ASSIGNMENT_V622={",
        "window.applyAssignments=applyAssignments=async function(list)",
        "window.repairSmartAssignmentsV622=repairAll622"
    ]:
        if needle not in c:
            errors.append("canonical V6.22 missing expected behavior: "+needle)

# Actual browser order must be canonical -> preserved legacy -> V6.24.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    c=scripts.index("js/planner/smart-assignment-v622.js")
    v=scripts.index("js/planner/smart-plans-v624.js")
    if not (c < v):
        errors.append("expected canonical V6.22 before canonical V6.24")
    if "js/legacy/23-aurea-smart-assignment-v622-script.js" in scripts:
        errors.append("legacy V6.22 should no longer be a live browser script")
except ValueError:
    errors.append("missing canonical V6.22/V6.24 script reference")

# All active JS parses.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Run the real planner regression suite with canonical first AND legacy second.
r=subprocess.run([
    "node",str(ROOT/"tests/phase17_v622_extraction_smoke.js"),
    str(ROOT/"js/planner/assignment-engine.js"),
    str(canonical),
    str(legacy),
    str(ROOT/"js/planner/smart-plans-v624.js"),
    str(ROOT/"js/planner/planner-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("Phase 17 canonical/legacy behavior smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 17 canonical V6.22 is byte-identical, loads first, legacy V6.22 safely no-ops, and all hard-rule regressions pass.")
