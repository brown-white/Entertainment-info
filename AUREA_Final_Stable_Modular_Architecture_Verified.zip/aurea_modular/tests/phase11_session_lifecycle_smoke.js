
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={
  AUTH_MODE:'legacy',
  DATA_LOAD_MODE:'legacy_full',
  REALTIME_MODE:'legacy_broad',
  SESSION_LIFECYCLE_MODE:'legacy_observe'
};
global.localStorage={getItem(){return null},setItem(){},removeItem(){}};
global.S={
  users:[
    {id:1,username:'manager1',password:'secret',role:'manager',active:true,display_name:'Manager One'},
    {id:2,username:'staff1',password:'pass1',role:'staff',active:true,display_name:'Staff One'}
  ],
  accounts:[{id:10,room:'101',username:'g101',password:'gpass',name:'Guest',arrival:'2026-09-10',departure:'2026-09-20',active:true}],
  rooms:[{room:'101',active:true}],
  session:null,remember:true,tab:'home',chatRoom:null
};
global.isAttOnly=()=>false;
global.accountActive=u=>!u||u.active!==false;
global.stayExpired=()=>false;
global.persist=()=>{};
global.defaultTabFor=r=>r==='manager'?'dash':'today';
global.navReset=()=>{};

let forbiddenCalls=0;
global.AUREA_DATA_LOADER={load(){forbiddenCalls++;throw new Error('loader touched')},poll(){forbiddenCalls++;}};
global.AUREA_REALTIME={subscribe(){forbiddenCalls++},createClient(){forbiddenCalls++}};
global.AUREA_SUPABASE_AUTH={enabled:()=>false,signOut:()=>{},clear:()=>{}};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[3],'utf8'));

const events=[];
AUREA_SESSION_LIFECYCLE.onChange(e=>events.push(e));

(async()=>{
  const auth=await AUREA_AUTH.authenticateStaff('manager1','secret','manager');
  if(!auth.ok)throw new Error('legacy manager auth failed');
  AUREA_AUTH.startStaff(auth.account,'manager');

  const guest=AUREA_AUTH.findGuestAccount('101');
  AUREA_AUTH.startGuest(guest,true);

  AUREA_AUTH.logout();

  if(forbiddenCalls!==0)throw new Error('legacy observe mode touched loader/realtime');
  const reasons=events.map(e=>e.reason);
  for(const r of ['staff-login','guest-login','logout']){
    if(!reasons.includes(r))throw new Error('missing lifecycle event '+r);
  }
  if(AUREA_SESSION_LIFECYCLE.status().mode!=='legacy_observe')
    throw new Error('wrong lifecycle mode');

  console.log('PASS: lifecycle observes login/logout transitions without data/realtime side effects');
})().catch(e=>{console.error(e);process.exit(1)});
