from pathlib import Path
import re,subprocess,sys,hashlib

ROOT=Path(__file__).resolve().parents[1]
errors=[]

canonical=ROOT/"js/planner/smart-plans-v624.js"
legacy=ROOT/"js/legacy/24-aurea-smart-plans-v624-script.js"

if not canonical.exists():
    errors.append("missing canonical V6.24 planner module")
if not legacy.exists():
    errors.append("legacy V6.24 compatibility file was deleted")

if canonical.exists() and legacy.exists():
    cb=canonical.read_bytes()
    lb=legacy.read_bytes()
    if cb!=lb:
        errors.append("canonical V6.24 is not byte-for-byte equal to preserved legacy V6.24")
    if hashlib.sha256(cb).hexdigest()!=hashlib.sha256(lb).hexdigest():
        errors.append("canonical/legacy V6.24 SHA mismatch")

if canonical.exists():
    c=canonical.read_text(encoding="utf-8")
    for needle in [
        "if(window.__AUREA_SMART_PLANS_V624)return;",
        "window.__AUREA_SMART_PLANS_V624=true;",
        "function generateSet624",
        "window.applyAssignments=applyAssignments=async function(list)",
        "window.openAutoAssignModal=function(day)",
        "window.AUREA_SMART_PLANS_V624={"
    ]:
        if needle not in c:
            errors.append("canonical V6.24 missing expected behavior: "+needle)

# Browser order must be:
# canonical V6.22 -> inert legacy V6.22 -> canonical V6.24 -> inert legacy V6.24
# -> concurrency -> apply service -> planner service
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    c622=scripts.index("js/planner/smart-assignment-v622.js")
    c624=scripts.index("js/planner/smart-plans-v624.js")
    conc=scripts.index("js/planner/planner-concurrency.js")
    apply=scripts.index("js/planner/planner-apply-service.js")
    svc=scripts.index("js/planner/planner-service.js")
    if not (c622 < c624 < conc < apply < svc):
        errors.append("unexpected canonical planner load order after legacy reference retirement")
    if "js/legacy/23-aurea-smart-assignment-v622-script.js" in scripts:
        errors.append("legacy V6.22 should no longer be a live browser script")
    if "js/legacy/24-aurea-smart-plans-v624-script.js" in scripts:
        errors.append("legacy V6.24 should no longer be a live browser script")
except ValueError:
    errors.append("missing canonical planner script reference")

# All active JS parses.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Exercise actual planner behavior with canonical V6.22 + canonical V6.24,
# then load preserved V6.24 to prove it does not duplicate wrappers.
r=subprocess.run([
    "node",str(ROOT/"tests/phase18_v624_extraction_smoke.js"),
    str(ROOT/"js/planner/assignment-engine.js"),
    str(ROOT/"js/planner/smart-assignment-v622.js"),
    str(canonical),
    str(legacy),
    str(ROOT/"js/planner/planner-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("Phase 18 canonical/legacy behavior smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 18 canonical V6.24 is byte-identical, loads first, legacy V6.24 safely no-ops, and all planner regressions pass.")
