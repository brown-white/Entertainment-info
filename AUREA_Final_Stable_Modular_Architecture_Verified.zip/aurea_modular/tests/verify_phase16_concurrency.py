from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

conc=(ROOT/"js/planner/planner-concurrency.js").read_text(encoding="utf-8")
for needle in ["captureSet","inherit","planner-context-changed","local_snapshot","staffAtt","dayOverrides","activityGenderRequirements"]:
    if needle not in conc:
        errors.append("concurrency boundary missing: "+needle)

apply=(ROOT/"js/planner/planner-apply-service.js").read_text(encoding="utf-8")
for needle in ["assertNotStale(list)","AUREA_STALE_PLAN","concurrencyCheck"]:
    if needle not in apply:
        errors.append("planner apply stale preflight missing: "+needle)

v624=(ROOT/"js/planner/smart-plans-v624.js").read_text(encoding="utf-8")
for needle in [
    "AUREA_PLANNER_CONCURRENCY.captureSet(plans)",
    "AUREA_PLANNER_CONCURRENCY.inherit(plan,applying)",
    "e.code==='AUREA_STALE_PLAN'"
]:
    if needle not in v624:
        errors.append("V6.24 concurrency integration missing: "+needle)

# Load order.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    v=scripts.index("js/planner/smart-plans-v624.js")
    c=scripts.index("js/planner/planner-concurrency.js")
    a=scripts.index("js/planner/planner-apply-service.js")
    p=scripts.index("js/planner/planner-service.js")
    if not (v < c < a < p):
        errors.append("expected V6.24 -> concurrency -> apply-service -> planner-service load order")
except ValueError:
    errors.append("missing Phase 16 planner script reference")

# Syntax.
for pth in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in pth.parts):
        continue
    r=subprocess.run(["node","--check",str(pth)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(pth.relative_to(ROOT)))

# Behavior.
r=subprocess.run([
    "node",str(ROOT/"tests/phase16_planner_concurrency_smoke.js"),
    str(ROOT/"js/planner/planner-concurrency.js"),
    str(ROOT/"js/planner/planner-apply-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("concurrency smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 16 snapshots generated plans, blocks stale programme/team/attendance context before writes, preserves legacy callers, and keeps all active safety modes conservative.")
