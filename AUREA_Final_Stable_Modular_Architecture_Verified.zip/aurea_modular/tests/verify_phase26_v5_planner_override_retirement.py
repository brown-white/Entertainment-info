from pathlib import Path
import re, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]; errors=[]
curp=ROOT/"js/legacy/05-aurea-v5-smart-plans.js"
oldp=ROOT/"phase26_rollback/js/legacy/05-aurea-v5-smart-plans.js"
v622=ROOT/"js/planner/smart-assignment-v622.js"
v624=ROOT/"js/planner/smart-plans-v624.js"
cur=curp.read_text(encoding="utf-8"); old=oldp.read_text(encoding="utf-8") if oldp.exists() else ""
m1=("  /* Phase 26: retired superseded V5 assignment overview block "
    "(userByAssignment/assignmentValid/displayAssignee/assignActsInner). "
    "Canonical V6.22 owns assignActsInner. Exact original is in phase26_rollback. */\n")
m2=("  /* Phase 26: retired superseded V5 planner modal block "
    "(makePlan/openAutoAssignModal). Canonical V6.24 owns openAutoAssignModal. "
    "Exact original is in phase26_rollback. */\n")
if not oldp.exists(): errors.append("missing Phase26 rollback")
for needle in ["window.assignActsInner=function","window.openAutoAssignModal=function",
               "function userByAssignment(","function assignmentValid(","function displayAssignee(","function makePlan("]:
    if needle in cur: errors.append("retired V5 code remains: "+needle)

# Exact delta.
if old:
    lines=old.splitlines(keepends=True)
    try:
        s1=next(i for i,l in enumerate(lines) if re.match(r'^\s*function\s+userByAssignment\s*\(',l))
        e1=next(i for i in range(s1+1,len(lines)) if re.match(r'^\s*function\s+makePlan\s*\(',lines[i]))
        s2=e1
        e2=next(i for i in range(s2+1,len(lines)) if "Activity intensity selector" in lines[i])
        reconstructed="".join(lines[:s1])+m1+m2+"".join(lines[e2:])
        if reconstructed!=cur: errors.append("V5 changed beyond two audited retirement blocks")
    except StopIteration: errors.append("could not locate historical V5 blocks")

# Final canonical owners.
v622txt=v622.read_text(encoding="utf-8")
v624txt=v624.read_text(encoding="utf-8")
if "window.assignActsInner=function(day,ds,acts,openIgnored,working)" not in v622txt:
    errors.append("V6.22 assignActsInner owner missing")
if "window.openAutoAssignModal=function(day)" not in v624txt:
    errors.append("V6.24 openAutoAssignModal owner missing")

# No later capture of either V5 implementation.
html=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',html)
v5i=scripts.index("js/legacy/05-aurea-v5-smart-plans.js")
for name in ["assignActsInner","openAutoAssignModal"]:
    cap=re.compile(rf'(?:const|let|var)\s+\w+\s*=\s*(?:window\.)?{name}\b')
    for s in scripts[v5i+1:]:
        p=ROOT/s
        if p.exists() and p.suffix==".js" and cap.search(p.read_text(encoding="utf-8",errors="ignore")):
            errors.append("later capture of retired V5 "+name+": "+s)

# Important V5 chained/final behaviors remain.
for needle in [
 "const oldBump=window.bumpLoad;","window.bumpLoad=function","window.activityType=activityType;",
 "const originalEdit=window.openEditModal;","window.openEditModal=function",
 "window.feedbackAnalyticsCard=function","window.feedbackInner=function","window.openDeptDetail=function"
]:
    if needle not in cur: errors.append("required V5 behavior missing: "+needle)

# Safety modes.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={"AUTH_MODE":"legacy","DATA_LOAD_MODE":"legacy_full","REALTIME_MODE":"legacy_broad",
"SESSION_LIFECYCLE_MODE":"legacy_observe","STATE_ISOLATION_MODE":"legacy_transient",
"PLANNER_MODE":"compat_v624","PLANNER_APPLY_MODE":"legacy_sequential",
"PLANNER_CONCURRENCY_MODE":"local_snapshot"}
for k,v in expected.items():
    m=re.search(rf'{k}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=v: errors.append(f"{k} must remain {v}")

for p in ROOT.rglob("*.js"):
    if any("rollback" in x or "backup" in x for x in p.parts): continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode: errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL"); [print("-",e) for e in errors]; sys.exit(1)
print("PASS: Phase 26 retires only superseded V5 assignActsInner and planner-modal blocks; canonical V6.22/V6.24 owners and required V5 chained behavior remain intact.")
