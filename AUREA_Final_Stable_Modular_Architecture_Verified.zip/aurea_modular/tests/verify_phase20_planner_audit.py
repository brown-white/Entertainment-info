from pathlib import Path
import json,re,subprocess,sys,hashlib

ROOT=Path(__file__).resolve().parents[1]
errors=[]

# Runtime hash lock: Phase 20 must not modify active planner/runtime files.
hash_file=ROOT/"tests/phase20_runtime_hashes.json"
expected=json.loads(hash_file.read_text(encoding="utf-8"))
for rel,sha in expected.items():
    p=ROOT/rel
    if not p.exists():
        errors.append("missing runtime file: "+rel)
        continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=sha:
        errors.append("Phase 20 runtime file changed: "+rel)

# Audit files exist and contain critical ownership facts.
audit=json.loads((ROOT/"docs/PHASE20_PLANNER_CONSOLIDATION_AUDIT.json").read_text(encoding="utf-8"))
if audit.get("runtime_behavior_changed") is not False:
    errors.append("audit must mark runtime behavior unchanged")
entries=audit.get("authoritative_entry_points",{})
if entries.get("applyAssignments",{}).get("runtime_owner")!="wrapper chain V6.24 -> V6.22 -> base":
    errors.append("applyAssignments wrapper chain not documented correctly")
for helper in ["eventsCrew","assignableStaff","activitySlot","planBalance","assignDateStr","activityType"]:
    matches=[x for x in audit.get("shared_foundation_helpers",[]) if x.get("name")==helper]
    if not matches or matches[0].get("retire_now") is not False:
        errors.append("foundation helper not protected from premature retirement: "+helper)

# Canonical runtime remains clean after Phase19.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
for old in [
    "js/legacy/23-aurea-smart-assignment-v622-script.js",
    "js/legacy/24-aurea-smart-plans-v624-script.js"
]:
    if old in scripts:
        errors.append("legacy planner runtime reference returned: "+old)

try:
    base=scripts.index("js/planner/assignment-engine.js")
    v622=scripts.index("js/planner/smart-assignment-v622.js")
    v624=scripts.index("js/planner/smart-plans-v624.js")
    conc=scripts.index("js/planner/planner-concurrency.js")
    apply=scripts.index("js/planner/planner-apply-service.js")
    facade=scripts.index("js/planner/planner-service.js")
    if not (base<v622<v624<conc<apply<facade):
        errors.append("canonical planner load order changed")
except ValueError as e:
    errors.append("missing canonical planner script: "+str(e))

# Conservative modes must remain unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected_modes={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected_modes.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# All active JS parses.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 20 is audit-only, locks runtime hashes, documents authoritative planner ownership, and protects still-required wrapper/foundation layers from premature deletion.")
