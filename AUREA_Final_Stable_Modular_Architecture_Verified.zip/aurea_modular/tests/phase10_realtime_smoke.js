
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={
  SUPABASE_URL:'https://example.supabase.co',
  SUPABASE_ANON_KEY:'publishable-test',
  REALTIME_MODE:'legacy_broad'
};
global.DEFAULT_SETTINGS={name:'x'};
global.S={
  activities:[{id:1,name:'A'}],
  bookings:[],users:[],tickets:[],orders:[],rooms:[],accounts:[],
  messages:[],requests:[],tasks:[],notes:[],attendance:[],feedback:[],
  profiles:[],buses:[],quizzes:[],quizReplies:[],staffAtt:[],photos:[],staffReqs:[],
  settings:{}
};
global.applySettings=()=>{};

let createArgs=null, channelName=null, onArgs=null, subscribed=false;
const channel={
  on(type,filter,handler){onArgs={type,filter,handler};return this;},
  subscribe(){subscribed=true;return this;}
};
global.supabase={
  createClient(url,key){
    createArgs={url,key};
    return {channel(name){channelName=name;return channel;}};
  }
};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));

if(AUREA_REALTIME.mode()!=='legacy_broad')throw new Error('legacy realtime mode changed');
const client=AUREA_REALTIME.createClient();
AUREA_REALTIME.subscribe(client,()=>{});
if(createArgs.url!==CONFIG.SUPABASE_URL||createArgs.key!==CONFIG.SUPABASE_ANON_KEY)
  throw new Error('legacy realtime client creation changed');
if(channelName!=='live-changes')throw new Error('channel name changed');
if(!onArgs||onArgs.type!=='postgres_changes')throw new Error('event type changed');
if(onArgs.filter.event!=='*'||onArgs.filter.schema!=='public')throw new Error('legacy filter changed');
if(!subscribed)throw new Error('subscription not started');

if(!AUREA_REALTIME.applyPayload({table:'activities',eventType:'UPDATE',new:{id:1,name:'B'}}))
  throw new Error('update not patched');
if(S.activities[0].name!=='B')throw new Error('update patch regression');

AUREA_REALTIME.applyPayload({table:'activities',eventType:'INSERT',new:{id:2,name:'C'}});
if(S.activities.length!==2)throw new Error('insert patch regression');

AUREA_REALTIME.applyPayload({table:'activities',eventType:'DELETE',old:{id:2}});
if(S.activities.length!==1)throw new Error('delete patch regression');

AUREA_REALTIME.applyPayload({table:'app_settings',eventType:'UPDATE',new:{data:{name:'Hotel'}}});
if(S.settings.name!=='Hotel')throw new Error('settings patch regression');

console.log('PASS: legacy realtime subscription shape and payload patch behavior preserved');
