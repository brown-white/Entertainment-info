from pathlib import Path
import re, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
mods=['js/core/shared-ui.js','js/guest/guest-core.js','js/entertainer/entertainer-core.js','js/manager/guest-crm.js','js/planner/assignment-engine.js','js/services/weather-service.js','js/manager/page-designer.js','js/manager/action-center.js','js/entertainer/my-page.js','js/manager/team-requests.js','js/guest/hotel-info.js','js/guest/photo-gallery.js','js/guest/feedback-review.js','js/manager/attendance.js','js/guest/daily-quiz.js','js/manager/manager-core.js','js/ai/manager-ai.js','js/exports/export-center.js','js/core/modals.js','js/manager/requirements.js','js/exports/feedback-report.js','js/core/dialogs.js','js/core/wiring.js','js/core/boot-guards.js','js/notifications/notifications.js','js/core/realtime-runtime.js']
backup=ROOT/'js/legacy/backups/01-app-shell.phase2.js'
recombined=b''.join((ROOT/m).read_bytes() for m in mods)
assert backup.exists(), 'Phase 2 rollback backup missing'
assert recombined==backup.read_bytes(), 'Phase 3 modules no longer reconstruct Phase 2 shell exactly'
html=(ROOT/'index.html').read_text(encoding='utf-8')
refs=re.findall(r'(?:src|href)=[\"\']([^\"\']+)[\"\']',html)
local=[r for r in refs if not re.match(r'^(?:https?:|data:|#|mailto:|tel:)',r)]
missing=[r for r in local if not (ROOT/r.lstrip('./')).exists()]
assert not missing, f'Missing local refs: {missing}'
errors=[]
for r in local:
    if r.endswith('.js'):
        cp=subprocess.run(['node','--check',str(ROOT/r.lstrip('./'))],capture_output=True,text=True)
        if cp.returncode: errors.append((r,cp.stderr))
assert not errors, f'JS syntax errors: {errors}'
print(f'PASS: exact reconstruction of Phase 2 shell from {len(mods)} Phase 3 modules')
print(f'PASS: {len(local)} local references exist')
print(f'PASS: all active JavaScript files parse successfully')
