
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={
  AUTH_MODE:'legacy',
  PLANNER_APPLY_MODE:'legacy_sequential',
  PLANNER_CONCURRENCY_MODE:'local_snapshot'
};
global.REMOTE=true;
global.activitySlot=a=>a.slot||'morning';
global.AUREA_PERMISSIONS={can:x=>x==='planner.manage'};
global.AUREA_SUPABASE_AUTH={enabled:()=>false,accessToken:()=>null};

global.S={
  settings:{dayOverrides:{},activityGenderRequirements:{}},
  activities:[
    {id:1,name:'Yoga',day:0,time:'10:00',cat:'mAdult',entertainer:'',slot:'morning'},
    {id:2,name:'Darts',day:0,time:'10:30',cat:'mAdult',entertainer:'',slot:'morning'}
  ],
  users:[
    {id:10,username:'solo',display_name:'Solo',role:'staff',number:4,active:true,gender:'male',can_do:'',cannot_do:''},
    {id:11,username:'lina',display_name:'Lina',role:'staff',number:5,active:true,gender:'female',can_do:'',cannot_do:''}
  ],
  staffAtt:[]
};

let writes=0,last=null;
global.applyAssignments=async list=>{writes++;last=list;return true;};
global.sb=async()=>{throw new Error('RPC should not run')};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[3],'utf8'));

function assert(c,m){if(!c)throw new Error(m)}

(async()=>{
  const plan=[
    {activity:S.activities[0],username:'solo',slot:'morning',day:0},
    {activity:S.activities[1],username:'lina',slot:'morning',day:0}
  ];

  AUREA_PLANNER_CONCURRENCY.capture(plan);
  let c=AUREA_PLANNER_CONCURRENCY.check(plan);
  assert(c.ok&&c.captured&&!c.stale,'fresh plan reported stale');

  // Filtered payload must inherit the original snapshot.
  const filtered=plan.filter(x=>x.username);
  AUREA_PLANNER_CONCURRENCY.inherit(plan,filtered);
  c=AUREA_PLANNER_CONCURRENCY.check(filtered);
  assert(c.ok&&c.captured,'derived apply payload lost snapshot');

  let ok=await AUREA_PLANNER_APPLY.apply(filtered);
  assert(ok&&writes===1&&last===filtered,'fresh plan did not use legacy apply');

  // Target assignment changed after plan generation -> reject before write.
  writes=0;
  S.activities=S.activities.map(a=>a.id===1?{...a,entertainer:'someone-else'}:a);
  let stale=false;
  try{await AUREA_PLANNER_APPLY.apply(filtered);}
  catch(e){stale=e&&e.code==='AUREA_STALE_PLAN';}
  assert(stale,'changed target assignment was not detected as stale');
  assert(writes===0,'stale plan wrote before rejection');

  // Fresh snapshot, then team availability changes -> reject.
  S.activities=S.activities.map(a=>a.id===1?{...a,entertainer:''}:a);
  const plan2=[
    {activity:S.activities[0],username:'solo',slot:'morning',day:0},
    {activity:S.activities[1],username:'lina',slot:'morning',day:0}
  ];
  AUREA_PLANNER_CONCURRENCY.capture(plan2);
  S.users=S.users.map(u=>u.username==='solo'?{...u,active:false}:u);
  stale=false;
  try{await AUREA_PLANNER_APPLY.apply(plan2);}
  catch(e){stale=e&&e.code==='AUREA_STALE_PLAN';}
  assert(stale,'team availability change was not detected');
  assert(writes===0,'availability-stale plan wrote');

  // Attendance / day-plan context changes also stale the plan.
  S.users=S.users.map(u=>u.username==='solo'?{...u,active:true}:u);
  const plan3=[{activity:S.activities[0],username:'solo',slot:'morning',day:0}];
  AUREA_PLANNER_CONCURRENCY.capture(plan3);
  S.staffAtt.push({username:'solo',date:'2026-09-14',status:'A'});
  stale=false;
  try{await AUREA_PLANNER_APPLY.apply(plan3);}
  catch(e){stale=e&&e.code==='AUREA_STALE_PLAN';}
  assert(stale,'attendance change was not detected');

  // Uncaptured legacy callers remain compatible.
  S.staffAtt=[];
  writes=0;
  const legacy=[{activity:S.activities[0],username:'solo',slot:'morning',day:0}];
  ok=await AUREA_PLANNER_APPLY.apply(legacy);
  assert(ok&&writes===1,'uncaptured legacy caller was broken');

  console.log('PASS: fresh plans apply, stale programme/team/attendance plans are blocked before writes, and legacy uncaptured callers remain compatible');
})().catch(e=>{console.error(e);process.exit(1)});
