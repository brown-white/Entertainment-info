from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

if "PLANNER_ATOMIC_RPC_DEPLOYED" in cfg:
    errors.append("PLANNER_ATOMIC_RPC_DEPLOYED must not be enabled/present in Phase 15 config")

svc=(ROOT/"js/planner/planner-apply-service.js").read_text(encoding="utf-8")
for needle in [
    "legacy_sequential",
    "rpc_atomic",
    "Phase 15 safety guard",
    "AUTH_MODE",
    "PLANNER_ATOMIC_RPC_DEPLOYED",
    'sb("rpc/"+RPC_NAME'
]:
    if needle not in svc:
        errors.append("planner apply service missing: "+needle)

planner=(ROOT/"js/planner/planner-service.js").read_text(encoding="utf-8")
if "AUREA_PLANNER_APPLY.apply" not in planner:
    errors.append("canonical planner does not use planner apply boundary")

v624=(ROOT/"js/planner/smart-plans-v624.js").read_text(encoding="utf-8")
if "await AUREA_PLANNER.apply(" not in v624:
    errors.append("final V6.24 Apply button does not route through AUREA_PLANNER")
if "window.applyAssignments=applyAssignments=async function(list)" not in v624:
    errors.append("V6.24 validator wrapper was removed")

# Load order.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    a=scripts.index("js/planner/planner-apply-service.js")
    b=scripts.index("js/planner/planner-service.js")
    v=scripts.index("js/planner/smart-plans-v624.js")
    if not (v < a < b):
        errors.append("expected V6.24 -> planner-apply-service -> planner-service load order")
except ValueError:
    errors.append("missing planner apply/service script reference")

# SQL template must be non-executable architecture only.
tpl=ROOT/"supabase/phase15/10_ATOMIC_PLANNER_RPC_TEMPLATE.sql.example"
if not tpl.exists():
    errors.append("missing non-executable atomic SQL template")
else:
    t=tpl.read_text(encoding="utf-8").strip()
    if not (t.startswith("/*") and t.endswith("*/")):
        errors.append("atomic SQL template is not wholly block-commented")
    # Remove the one block comment; nothing executable should remain.
    remainder=re.sub(r'/\*.*\*/','',t,flags=re.S).strip()
    if remainder:
        errors.append("atomic SQL template has executable content outside block comment")

# JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Behavioral safety.
r=subprocess.run([
    "node",str(ROOT/"tests/phase15_atomic_apply_smoke.js"),
    str(ROOT/"js/planner/planner-apply-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("atomic apply smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 15 preserves legacy sequential planner writes, routes Apply through one persistence boundary, and keeps atomic RPC fully blocked/non-executable.")
