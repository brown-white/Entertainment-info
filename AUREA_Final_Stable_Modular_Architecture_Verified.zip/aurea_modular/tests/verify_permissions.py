from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)

required=[
    "js/auth/auth-service.js",
    "js/auth/permissions.js",
    "js/services/booking-service.js",
    "js/services/ticket-service.js",
]
for rel in required:
    if rel not in scripts: errors.append(f"missing script reference: {rel}")
    elif not (ROOT/rel).exists(): errors.append(f"missing file: {rel}")

if all(x in scripts for x in required):
    if scripts.index("js/auth/permissions.js") > scripts.index("js/services/booking-service.js"):
        errors.append("permissions must load before booking service")
    if scripts.index("js/auth/permissions.js") > scripts.index("js/services/ticket-service.js"):
        errors.append("permissions must load before ticket service")

booking=(ROOT/"js/services/booking-service.js").read_text(encoding="utf-8")
ticket=(ROOT/"js/services/ticket-service.js").read_text(encoding="utf-8")
planner=(ROOT/"js/planner/assignment-engine.js").read_text(encoding="utf-8")

checks=[
    ("activity.book",booking),
    ("booking.cancelOwn",booking),
    ("ticket.order",ticket),
    ("ticket.cancelOwn",ticket),
    ("ticket.collect",ticket),
    ("ticket.manage",ticket),
    ("planner.manage",planner),
]
for needle,body in checks:
    if needle not in body: errors.append(f"missing permission guard: {needle}")

for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts): continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode: errors.append(f"syntax: {p.relative_to(ROOT)}")

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)
print("PASS: Phase 6 permission boundary, load order, guards and JS syntax.")
