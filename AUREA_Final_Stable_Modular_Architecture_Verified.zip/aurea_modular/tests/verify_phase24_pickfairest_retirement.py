from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

current=ROOT/"js/planner/assignment-engine.js"
rollback=ROOT/"phase24_rollback/js/planner/assignment-engine.js"
v5=(ROOT/"phase25_rollback/js/legacy/05-aurea-v5-smart-plans.js") if (ROOT/"phase25_rollback/js/legacy/05-aurea-v5-smart-plans.js").exists() else ROOT/"js/legacy/05-aurea-v5-smart-plans.js"
v622=ROOT/"js/planner/smart-assignment-v622.js"
index=ROOT/"index.html"

if not rollback.exists():
    errors.append("missing Phase 24 rollback copy of assignment-engine.js")

cur=current.read_text(encoding="utf-8")
old=rollback.read_text(encoding="utf-8") if rollback.exists() else ""

marker=(
"/* Phase 24: retired superseded base pickFairest implementation.\n"
"   V5 replaces window.pickFairest without capturing the base function;\n"
"   canonical V6.22 replaces it again before live planner use.\n"
"   Exact pre-retirement code is in phase24_rollback/js/planner/assignment-engine.js. */\n"
)

# Base implementation must be gone.
if re.search(r'^\s*function\s+pickFairest\s*\(',cur,re.M):
    errors.append("base pickFairest still exists in assignment-engine.js")

# Exact-delta proof.
if old:
    lines=old.splitlines(keepends=True)
    try:
        start=next(i for i,l in enumerate(lines) if re.match(r'^\s*function\s+pickFairest\s*\(',l))
        end=next(i for i in range(start+1,len(lines)) if lines[i].startswith("/* One day."))
        removed="".join(lines[start:end])
        if "function repeatPenalty(" in removed:
            errors.append("retirement block accidentally includes repeatPenalty")
        reconstructed="".join(lines[:start])+marker+"".join(lines[end:])
        if reconstructed!=cur:
            errors.append("assignment-engine.js changed beyond audited pickFairest retirement")
    except StopIteration:
        errors.append("could not locate historical base pickFairest block")

# V5 must replace without capturing the old function.
v5txt=v5.read_text(encoding="utf-8")
if "window.pickFairest=function" not in v5txt:
    errors.append("V5 pickFairest override missing")
if re.search(r'(?:old\w*Pick|const\s+\w+\s*=\s*window\.pickFairest)',v5txt):
    errors.append("V5 now captures old pickFairest; base retirement is no longer safe")

# V6.22 final override must remain.
v622txt=v622.read_text(encoding="utf-8")
if "window.pickFairest=function(pool,load,usedThisSlot,act,day)" not in v622txt:
    errors.append("V6.22 pickFairest override missing")

# Startup order and no pre-V5 consumer.
html=index.read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',html)
try:
    base=scripts.index("js/planner/assignment-engine.js")
    v5i=scripts.index("js/legacy/05-aurea-v5-smart-plans.js")
    v622i=scripts.index("js/planner/smart-assignment-v622.js")
    if not (base < v5i < v622i):
        errors.append("assignment-engine/V5/V6.22 load order changed")
    for s in scripts[base+1:v5i]:
        p=ROOT/s
        if p.exists() and p.suffix==".js":
            if "pickFairest" in p.read_text(encoding="utf-8",errors="ignore"):
                errors.append("pre-V5 script now references pickFairest: "+s)
except ValueError as e:
    errors.append("required planner script missing: "+str(e))

# Still-live dependencies must remain.
for needle in [
    "function baseLoad(",
    "function baseCounts(",
    "function loadOf(",
    "function bumpLoad(",
    "function repeatPenalty(",
    "function planBalance(",
    "async function applyAssignments(list)",
    "function eventsCrew(",
    "function assignableStaff(",
    "function activitySlot(",
    "function assignDateStr("
]:
    if needle not in cur:
        errors.append("critical live planner helper missing: "+needle)

# Conservative modes unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 24 retires only superseded base pickFairest, preserves V5/V6.22 override chain, live fairness dependencies, rollback exactness, and conservative safety modes.")
