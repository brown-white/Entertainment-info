from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

life=(ROOT/"js/auth/session-lifecycle.js").read_text(encoding="utf-8")
auth=(ROOT/"js/auth/auth-service.js").read_text(encoding="utf-8")
runtime=(ROOT/"js/core/realtime-runtime.js").read_text(encoding="utf-8")

if "Phase 11 safety guard" not in life:
    errors.append("missing lifecycle activation safety guard")
for reason in ["staff-login","guest-login","logout","session-invalid","session-refresh"]:
    if reason not in auth:
        errors.append("auth service missing lifecycle event: "+reason)
if "boot-anonymous" not in runtime:
    errors.append("anonymous boot is not routed through lifecycle")

index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    if scripts.index("js/auth/session-lifecycle.js") > scripts.index("js/auth/auth-service.js"):
        errors.append("session lifecycle must load before auth service")
except ValueError:
    errors.append("missing lifecycle/auth script reference")

# JS syntax
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Lifecycle behavior must remain observation-only.
r=subprocess.run([
    "node",str(ROOT/"tests/phase11_session_lifecycle_smoke.js"),
    str(ROOT/"js/auth/session-lifecycle.js"),
    str(ROOT/"js/auth/auth-service.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("lifecycle smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 11 centralizes session transitions while all active security/data/realtime modes remain legacy-safe and observation-only.")
