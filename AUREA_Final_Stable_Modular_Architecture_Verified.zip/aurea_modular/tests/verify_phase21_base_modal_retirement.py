from pathlib import Path
import re, subprocess, sys, hashlib

ROOT=Path(__file__).resolve().parents[1]
errors=[]

current=(ROOT/"phase22_rollback/js/planner/assignment-engine.js") if (ROOT/"phase22_rollback/js/planner/assignment-engine.js").exists() else ROOT/"js/planner/assignment-engine.js"
rollback=ROOT/"phase21_rollback/js/planner/assignment-engine.js"
v624=ROOT/"js/planner/smart-plans-v624.js"
index=ROOT/"index.html"

if not rollback.exists():
    errors.append("missing Phase 21 rollback copy of assignment-engine.js")

cur=current.read_text(encoding="utf-8")
old=rollback.read_text(encoding="utf-8") if rollback.exists() else ""

marker=(
"/* Phase 21: retired base openAutoAssignModal implementation.\n"
"   Canonical runtime owner: js/planner/smart-plans-v624.js.\n"
"   The exact pre-retirement body is preserved in phase21_rollback/js/planner/assignment-engine.js. */\n"
)

# Current base definition must be gone.
if re.search(r'^\s*function\s+openAutoAssignModal\s*\(',cur,re.M):
    errors.append("base openAutoAssignModal still exists in assignment-engine.js")

# Canonical V6.24 modal must still exist.
v624txt=v624.read_text(encoding="utf-8")
if "window.openAutoAssignModal=function(day)" not in v624txt:
    errors.append("canonical V6.24 openAutoAssignModal missing")

# Exact-delta proof: reconstruct current file from rollback by replacing only
# the historical modal block with the Phase21 marker.
if old:
    lines=old.splitlines(keepends=True)
    try:
        start=next(i for i,l in enumerate(lines) if re.match(r'^\s*function\s+openAutoAssignModal\s*\(',l))
        end=next(i for i in range(start+1,len(lines))
                 if lines[i].startswith("/* Manager sets what a person can and cannot do"))
        removed="".join(lines[start:end])
        if "const ok=await applyAssignments(plan);" not in removed:
            errors.append("rollback modal body shape unexpected")
        reconstructed="".join(lines[:start])+marker+"".join(lines[end:])
        if reconstructed!=cur:
            errors.append("assignment-engine.js changed beyond the single audited base modal retirement")
    except StopIteration:
        errors.append("could not locate historical base modal in rollback")

# Critical base persistence and shared helpers must remain untouched/present.
for needle in [
    "async function applyAssignments(list)",
    "function eventsCrew(",
    "function assignableStaff(",
    "function activitySlot(",
    "function planBalance(",
    "function assignDateStr(",
]:
    if needle not in cur:
        errors.append("critical base planner dependency missing: "+needle)

# Canonical runtime ordering still valid.
html=index.read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',html)
try:
    base=scripts.index("js/planner/assignment-engine.js")
    v622=scripts.index("js/planner/smart-assignment-v622.js")
    v624i=scripts.index("js/planner/smart-plans-v624.js")
    conc=scripts.index("js/planner/planner-concurrency.js")
    apply=scripts.index("js/planner/planner-apply-service.js")
    facade=scripts.index("js/planner/planner-service.js")
    if not (base < v622 < v624i < conc < apply < facade):
        errors.append("canonical planner load order changed")
except ValueError as e:
    errors.append("canonical planner runtime reference missing: "+str(e))

# No unexpected active source caller depends specifically on the base body.
allowed={
    "js/planner/smart-plans-v624.js",
    "js/planner/planner-service.js",
    "js/legacy/05-aurea-v5-smart-plans.js",
    "js/legacy/24-aurea-smart-plans-v624-script.js",
}
for p in ROOT.joinpath("js").rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    rel=str(p.relative_to(ROOT))
    if rel=="js/planner/assignment-engine.js":
        continue
    txt=p.read_text(encoding="utf-8",errors="ignore")
    if "openAutoAssignModal" in txt and rel not in allowed:
        errors.append("unexpected active source depends on openAutoAssignModal: "+rel)


# activityType is intentionally supplied by the active V5 compatibility layer
# before canonical V6.24 loads; verify that dependency remains intact.
v5=(ROOT/"js/legacy/05-aurea-v5-smart-plans.js").read_text(encoding="utf-8")
if "function activityType(a)" not in v5:
    errors.append("active V5 activityType provider missing")
try:
    v5i=scripts.index("js/legacy/05-aurea-v5-smart-plans.js")
    v624i=scripts.index("js/planner/smart-plans-v624.js")
    if not (v5i < v624i):
        errors.append("activityType provider must load before canonical V6.24")
except ValueError as e:
    errors.append("activityType provider/load-order reference missing: "+str(e))

# Conservative safety modes unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 21 removes only the superseded base Smart Planner modal, preserves canonical V6.24 ownership, base persistence/helpers, rollback, and all conservative safety modes.")
