
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={
  AUTH_MODE:'legacy',
  PLANNER_APPLY_MODE:'legacy_sequential',
  SUPABASE_URL:'https://example.supabase.co',
  SUPABASE_ANON_KEY:'publishable'
};
global.REMOTE=true;
global.S={activities:[{id:1,entertainer:'',day:0}]};
global.activitySlot=()=> 'morning';
global.AUREA_PERMISSIONS={can:(x)=>x==='planner.manage'};
global.AUREA_SUPABASE_AUTH={
  enabled:()=>false,
  accessToken:()=>null
};

let calls=0,last=null,fetchCalls=0;
global.applyAssignments=async list=>{calls++;last=list;return true;};
global.sb=async()=>{fetchCalls++;return [];};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));

(async()=>{
  const rows=[{activity:{id:1,entertainer:'',day:0},username:'solo'}];

  const ok=await AUREA_PLANNER_APPLY.apply(rows);
  if(!ok||calls!==1||last!==rows)throw new Error('legacy sequential delegation changed');
  if(fetchCalls!==0)throw new Error('legacy mode attempted RPC');

  const n=AUREA_PLANNER_APPLY.normalize(rows);
  if(n.length!==1||n[0].activity_id!==1||n[0].username!=='solo'||n[0].expected_entertainer!=='')
    throw new Error('atomic payload normalization failed');

  CONFIG.PLANNER_APPLY_MODE='rpc_atomic';
  let blocked=false;
  try{await AUREA_PLANNER_APPLY.apply(rows);}
  catch(e){blocked=/safety guard/.test(String(e.message));}
  if(!blocked)throw new Error('atomic mode was not blocked under legacy auth');
  if(fetchCalls!==0)throw new Error('blocked atomic mode reached RPC');

  const st=AUREA_PLANNER_APPLY.status();
  if(st.atomicActive)throw new Error('atomic mode reported active');
  console.log('PASS: legacy apply is unchanged and atomic RPC cannot activate under current safety modes');
})().catch(e=>{console.error(e);process.exit(1)});
