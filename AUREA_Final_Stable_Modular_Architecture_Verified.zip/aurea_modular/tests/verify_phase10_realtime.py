from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
m=re.search(r'REALTIME_MODE:\s*"([^"]+)"',cfg)
if not m or m.group(1)!="legacy_broad":
    errors.append("REALTIME_MODE must remain legacy_broad")

service=(ROOT/"js/services/realtime-service.js").read_text(encoding="utf-8")
runtime=(ROOT/"js/core/realtime-runtime.js").read_text(encoding="utf-8")

if "Phase 10 safety guard" not in service:
    errors.append("missing realtime activation safety guard")
if "AUREA_REALTIME.applyPayload" not in runtime:
    errors.append("runtime does not delegate payload patching")
if "AUREA_REALTIME.createClient" not in runtime:
    errors.append("runtime does not delegate realtime client creation")
if "AUREA_REALTIME.subscribe" not in runtime:
    errors.append("runtime does not delegate subscription creation")

# The broad postgres subscription must exist in the service only as compatibility behavior.
if 'client.channel("live-changes")' not in service:
    errors.append("legacy channel behavior missing")
if '.on("postgres_changes",{event:"*",schema:"public"},onPayload)' not in service:
    errors.append("legacy postgres_changes shape changed")

# Runtime should no longer own the table map.
if "const RT_TABLES=" in runtime:
    errors.append("duplicate realtime table map remains in runtime")

# Browser load order.
index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    if scripts.index("js/services/realtime-service.js") > scripts.index("js/core/realtime-runtime.js"):
        errors.append("realtime service must load before runtime")
except ValueError as e:
    errors.append("missing realtime script reference")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

# Behavioral smoke.
smoke=ROOT/"tests/phase10_realtime_smoke.js"
r=subprocess.run(["node",str(smoke),str(ROOT/"js/services/realtime-service.js")],
                 capture_output=True,text=True)
if r.returncode:
    errors.append("realtime behavioral smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 10 preserves legacy realtime behavior, centralizes realtime ownership, and blocks accidental scoped activation.")
