
const fs=require('fs'),vm=require('vm');

global.window=global;
global.CONFIG={STATE_ISOLATION_MODE:'legacy_transient',SESSION_LIFECYCLE_MODE:'legacy_observe'};
global.S={
  session:{role:'manager',username:'manager1',userId:1},
  chatRoom:'staff:manager1',
  aiChat:[{x:1}],
  crmQuery:'guest 101',
  drawerOpen:'menu',
  pb:{x:1},
  assignDay:3,
  openDay:{3:true},
  chatSel:'abc',
  exportMonth:'2026-09',
  exportDay:'2026-09-14',
  exportSlot:'Morning',
  attMonth:'2026-09',
  op:'Morning',
  cat:'mAdult',

  activities:[{id:1}],
  bookings:[{id:2}],
  users:[{id:3}],
  tickets:[{id:4}],
  orders:[{id:5}],
  rooms:[{room:'101'}],
  accounts:[{id:6}],
  messages:[{id:7}],
  requests:[{id:8}],
  tasks:[{id:9}],
  notes:[{id:10}],
  attendance:[{id:11}],
  feedback:[{id:12}],
  profiles:[{id:13}],
  buses:[{id:14}],
  quizzes:[{id:15}],
  quizReplies:[{id:16}],
  staffAtt:[{id:17}],
  photos:[{id:18}],
  staffReqs:[{id:19}]
};

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[3],'utf8'));

const before={
  bookings:S.bookings,
  users:S.users,
  accounts:S.accounts,
  messages:S.messages,
  attendance:S.attendance,
  feedback:S.feedback,
  staffAtt:S.staffAtt,
  staffReqs:S.staffReqs,
  tasks:S.tasks
};

AUREA_SESSION_LIFECYCLE.transition(
  'logout',
  {role:'manager',username:'manager1',userId:1},
  null,
  null
);

if(S.chatRoom!==null)throw new Error('chatRoom not cleared');
if(S.aiChat.length!==0)throw new Error('aiChat not cleared');
if(S.crmQuery!=='')throw new Error('crmQuery not cleared');
if(S.pb!==null||S.assignDay!==null||S.chatSel!==null)throw new Error('editor state not cleared');
if(S.exportMonth!==null||S.exportDay!==''||S.exportSlot!=='')throw new Error('export state not cleared');
if(S.attMonth!==null||S.op!==null||S.cat!==null)throw new Error('filter state not cleared');

for(const [k,v] of Object.entries(before)){
  if(S[k]!==v)throw new Error('database-backed state was replaced in legacy mode: '+k);
}

let blocked=false;
try{AUREA_STATE_ISOLATION.clearDataKeys(['users']);}
catch(e){blocked=/Phase 12 safety guard/.test(String(e.message));}
if(!blocked)throw new Error('sensitive clearing was not blocked');

console.log('PASS: transient residue is cleared, legacy-required database state is retained, sensitive wipe is blocked');
