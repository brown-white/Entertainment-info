
const fs=require('fs'), vm=require('vm');

global.window=global;
global.localStorage={
  _m:new Map(),
  getItem(k){return this._m.has(k)?this._m.get(k):null},
  setItem(k,v){this._m.set(k,String(v))},
  removeItem(k){this._m.delete(k)}
};
global.CONFIG={
  SUPABASE_URL:'https://example.supabase.co',
  SUPABASE_ANON_KEY:'publishable-test',
  AUTH_MODE:'legacy'
};
global.S={
  users:[
    {id:1,username:'manager1',password:' secret ',role:'manager',active:true,display_name:'Manager One'},
    {id:2,username:'staff1',password:'pass1',role:'staff',active:true,display_name:'Staff One'}
  ],
  accounts:[],rooms:[],session:null,remember:true
};
global.isAttOnly=()=>false;
global.accountActive=u=>!u||u.active!==false;
global.persist=()=>{};
global.defaultTabFor=r=>r==='manager'?'dash':'today';
global.navReset=()=>{};
global.stayExpired=()=>false;

vm.runInThisContext(fs.readFileSync(process.argv[2],'utf8'));
vm.runInThisContext(fs.readFileSync(process.argv[3],'utf8'));

(async()=>{
  if(AUREA_SUPABASE_AUTH.enabled()) throw new Error('adapter should be disabled in legacy mode');
  const good=await AUREA_AUTH.authenticateStaff(' MANAGER1 ','secret','manager');
  if(!good.ok || good.provider!=='legacy' || good.account.id!==1) throw new Error('legacy manager login regression');
  const bad=await AUREA_AUTH.authenticateStaff('manager1','wrong','manager');
  if(bad.ok) throw new Error('wrong password accepted');
  const role=await AUREA_AUTH.authenticateStaff('manager1','secret','staff');
  if(role.ok) throw new Error('role mismatch accepted');
  console.log('PASS: legacy auth compatibility and disabled Supabase adapter');
})().catch(e=>{console.error(e);process.exit(1)});
