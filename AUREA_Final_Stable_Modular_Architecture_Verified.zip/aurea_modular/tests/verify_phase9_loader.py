from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
m=re.search(r'DATA_LOAD_MODE:\s*"([^"]+)"',cfg)
if not m or m.group(1)!="legacy_full":
    errors.append("DATA_LOAD_MODE must remain legacy_full")

loader=(ROOT/"js/database/data-loader.js").read_text(encoding="utf-8")
if "Phase 9 safety guard" not in loader:
    errors.append("missing role-aware activation safety guard")

db=(ROOT/"js/database/database.js").read_text(encoding="utf-8")
if "AUREA_DATA_LOADER.load(" not in db:
    errors.append("DB.load does not delegate to data loader")
if "AUREA_DATA_LOADER.poll(" not in db:
    errors.append("DB.poll does not delegate to data loader")

# Exact active query coverage against Phase 9 rollback of Phase 8 database.js.
rollback=(ROOT/"phase9_rollback/js/database/database.js").read_text(encoding="utf-8")
load_old=rollback.split("async load(){",1)[1].split("async poll(){",1)[0]
poll_old=rollback.split("async poll(){",1)[1].split("async addBooking",1)[0]
old_load=set(re.findall(r'sb\("([^"]+)"',load_old))
old_poll=set(re.findall(r'sb\("([^"]+)"',poll_old))

q=dict(re.findall(r'^\s*([A-Za-z][A-Za-z0-9_]*)\s*:\s*"([^"]+)"',loader,re.M))
# Restrict to query strings actually present in old sets.
new_load={v for v in q.values() if v in old_load}
new_poll={v for v in q.values() if v in old_poll}

if new_load!=old_load:
    errors.append(f"legacy load query set changed: missing={sorted(old_load-new_load)} extra={sorted(new_load-old_load)}")
if new_poll!=old_poll:
    errors.append(f"legacy poll query set changed: missing={sorted(old_poll-new_poll)} extra={sorted(new_poll-old_poll)}")

# JS syntax
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 9 preserves legacy read coverage, centralizes load/poll, keeps legacy_full active, and blocks accidental role-aware activation.")
