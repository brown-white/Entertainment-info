from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

current=(ROOT/"phase24_rollback/js/planner/assignment-engine.js") if (ROOT/"phase24_rollback/js/planner/assignment-engine.js").exists() else ROOT/"js/planner/assignment-engine.js"
rollback=ROOT/"phase23_rollback/js/planner/assignment-engine.js"

if not rollback.exists():
    errors.append("missing Phase 23 rollback copy of assignment-engine.js")

cur=current.read_text(encoding="utf-8")
old=rollback.read_text(encoding="utf-8") if rollback.exists() else ""

marker=(
"/* Phase 23: retired orphaned base fixRepeats/balancePlan helpers.\n"
"   They had no active callers after Phase 22.\n"
"   planBalance and compatibility helpers remain active and are preserved.\n"
"   Exact pre-retirement code is in phase23_rollback/js/planner/assignment-engine.js. */\n"
)

# Retired helpers must be gone.
for name in ["fixRepeats","balancePlan"]:
    if re.search(rf'^\s*function\s+{name}\s*\(',cur,re.M):
        errors.append(name+" still exists in assignment-engine.js")

# Exact delta against Phase22 output.
if old:
    lines=old.splitlines(keepends=True)
    try:
        start=next(i for i,l in enumerate(lines) if re.match(r'^\s*function\s+fixRepeats\s*\(',l))
        end=next(i for i in range(start+1,len(lines)) if re.match(r'^\s*function\s+planBalance\s*\(',lines[i]))
        removed="".join(lines[start:end])
        if "function balancePlan(plan, opts)" not in removed:
            errors.append("rollback block missing balancePlan")
        if "function planBalance(" in removed:
            errors.append("retirement block accidentally includes planBalance")
        reconstructed="".join(lines[:start])+marker+"".join(lines[end:])
        if reconstructed!=cur:
            errors.append("assignment-engine.js changed beyond audited orphan-helper retirement")
    except StopIteration:
        errors.append("could not locate historical helper block in rollback")

# planBalance and critical compatibility/base helpers must remain.
for needle in [
    "function planBalance(",
    "function baseLoad(",
    "function bumpLoad(",
    "function loadOf(",
    "function repeatPenalty(",
    "function pickFairest(",
    "async function applyAssignments(list)",
    "function eventsCrew(",
    "function assignableStaff(",
    "function activitySlot(",
    "function assignDateStr("
]:
    if needle not in cur:
        errors.append("critical planner dependency missing: "+needle)

# Prove retired helpers have no executable callsites/definitions left anywhere in JS.
# Plain text mentions in comments/retirement markers are intentionally ignored.
for name in ["fixRepeats","balancePlan"]:
    for p in ROOT.joinpath("js").rglob("*.js"):
        if any("rollback" in part or "backup" in part for part in p.parts):
            continue
        src=p.read_text(encoding="utf-8",errors="ignore")
        if re.search(rf'^\s*(?:async\s+)?function\s+{re.escape(name)}\s*\(',src,re.M):
            errors.append("unexpected active definition of retired helper "+name+": "+str(p.relative_to(ROOT)))
        if re.search(rf'(?<!function\s)\b{re.escape(name)}\s*\(',src):
            errors.append("unexpected active call to retired helper "+name+": "+str(p.relative_to(ROOT)))

# planBalance must still have live non-definition consumers.
consumers=0
for p in ROOT.joinpath("js").rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    txt=p.read_text(encoding="utf-8",errors="ignore")
    for line in txt.splitlines():
        if "planBalance" in line and "function planBalance" not in line:
            consumers+=1
if consumers < 2:
    errors.append("planBalance live usage unexpectedly disappeared")

# Conservative modes unchanged.
cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
  "PLANNER_MODE":"compat_v624",
  "PLANNER_APPLY_MODE":"legacy_sequential",
  "PLANNER_CONCURRENCY_MODE":"local_snapshot",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

# Active JS syntax.
for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 23 removes only orphaned fixRepeats/balancePlan, preserves planBalance and all still-live compatibility/persistence helpers, with exact rollback-delta proof.")
