from pathlib import Path
import re,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
errors=[]

cfg=(ROOT/"js/core/config.js").read_text(encoding="utf-8")
expected={
  "AUTH_MODE":"legacy",
  "DATA_LOAD_MODE":"legacy_full",
  "REALTIME_MODE":"legacy_broad",
  "SESSION_LIFECYCLE_MODE":"legacy_observe",
  "STATE_ISOLATION_MODE":"legacy_transient",
}
for key,value in expected.items():
    m=re.search(rf'{key}:\s*"([^"]+)"',cfg)
    if not m or m.group(1)!=value:
        errors.append(f"{key} must remain {value}")

service=(ROOT/"js/auth/state-isolation.js").read_text(encoding="utf-8")
life=(ROOT/"js/auth/session-lifecycle.js").read_text(encoding="utf-8")

if "Phase 12 safety guard" not in service:
    errors.append("missing sensitive-clear safety guard")
if "AUREA_STATE_ISOLATION.handleTransition" not in life:
    errors.append("session lifecycle does not invoke state isolation")

index=(ROOT/"index.html").read_text(encoding="utf-8")
scripts=re.findall(r'<script[^>]+src=["\']([^"\']+)["\']',index)
try:
    if scripts.index("js/auth/state-isolation.js") > scripts.index("js/auth/session-lifecycle.js"):
        errors.append("state isolation must load before session lifecycle")
except ValueError:
    errors.append("missing state isolation/lifecycle script reference")

# The canonical persist() must not serialize the large DB arrays.
foundation=(ROOT/"js/core/foundation.js").read_text(encoding="utf-8")
persist=foundation.split("function persist(){",1)[1].split("function restore(){",1)[0]
for key in ["users","accounts","bookings","messages","attendance","feedback","staffAtt","staffReqs","tasks"]:
    if re.search(rf'\b{re.escape(key)}\s*:',persist):
        errors.append("persist unexpectedly serializes sensitive array: "+key)

for p in ROOT.rglob("*.js"):
    if any("rollback" in part or "backup" in part for part in p.parts):
        continue
    r=subprocess.run(["node","--check",str(p)],capture_output=True,text=True)
    if r.returncode:
        errors.append("syntax: "+str(p.relative_to(ROOT)))

r=subprocess.run([
    "node",str(ROOT/"tests/phase12_state_isolation_smoke.js"),
    str(ROOT/"js/auth/state-isolation.js"),
    str(ROOT/"js/auth/session-lifecycle.js")
],capture_output=True,text=True)
if r.returncode:
    errors.append("state-isolation smoke failed: "+(r.stderr or r.stdout).strip())

if errors:
    print("FAIL")
    for e in errors: print("-",e)
    sys.exit(1)

print("PASS: Phase 12 clears transient cross-session residue, retains legacy-required data, blocks sensitive wipes, and keeps all compatibility modes safe.")
