/* AUREA Phase 5 — canonical authentication/session boundary
   IMPORTANT: This phase preserves the existing client-side credential model.
   It centralizes it so a later Supabase Auth migration can replace one service
   instead of rewriting Login, Session restore, Logout and role checks separately. */
(function(){
  'use strict';
  if(window.AUREA_AUTH)return;

  const norm=v=>String(v==null?'':v).trim();
  const normUser=v=>norm(v).toLowerCase();

  function findStaffAccount(username, role){
    const u=normUser(username);
    return (S.users||[]).find(x=>
      normUser(x&&x.username)===u &&
      !(typeof isAttOnly==='function'&&isAttOnly(x)) &&
      (role==='manager'?x.role==='manager':x.role==='staff')
    )||null;
  }

  function authenticateStaff(username,password,role){
    const u=normUser(username), p=norm(password);
    if(!u||!p)return {ok:false,reason:'invalid'};
    const account=findStaffAccount(u,role);
    if(!account || norm(account.password)!==p)return {ok:false,reason:'invalid'};
    if(typeof accountActive==='function'&&!accountActive(account))return {ok:false,reason:'inactive'};
    return {ok:true,account};
  }

  function findGuestAccount(identity){
    const key=norm(identity);
    return (S.accounts||[]).find(a=>String(a.room)===key || String(a.username||'')===key)||null;
  }

  function authenticateGuest(identity,password){
    const account=findGuestAccount(identity);
    if(!account)return {ok:false,reason:'not_found'};
    const room=(S.rooms||[]).find(x=>String(x.room)===String(account.room));
    if(!room||!room.active)return {ok:false,reason:'not_found'};
    if(account.active===false)return {ok:false,reason:'inactive'};
    if(typeof stayExpired==='function'&&stayExpired(account))return {ok:false,reason:'expired'};
    if(account.password && String(account.password)!==String(password||''))return {ok:false,reason:'invalid'};
    return {ok:true,account};
  }

  function staffSession(account,role){
    return {
      role:role==='manager'?'manager':'staff',
      name:account.display_name||account.username,
      username:account.username,
      userId:account.id,
      number:account.number||null,
      photo:account.photo||''
    };
  }

  function guestSession(account){
    return {
      role:'guest',room:account.room,name:account.name,phone:account.phone||'',
      nationality:account.nationality||'',arrival:account.arrival,departure:account.departure,
      accountId:account.id,username:account.username||account.room
    };
  }

  function startStaff(account,role){
    S.remember=true;
    S.session=staffSession(account,role);
    S.tab=defaultTabFor(S.session.role);
    if(typeof navReset==='function')navReset();
    persist();
    return S.session;
  }

  function startGuest(account,remember=true){
    S.remember=remember!==false;
    S.session=guestSession(account);
    S.tab='home';
    persist();
    return S.session;
  }

  function logout(){
    S.session=null;
    S.chatRoom=null;
    persist();
  }

  function currentRole(){return S.session&&S.session.role||null;}
  function hasRole(...roles){return !!S.session&&roles.includes(S.session.role);}
  function isGuest(){return hasRole('guest');}
  function isStaff(){return hasRole('staff');}
  function isManager(){return hasRole('manager');}

  function validateCurrent(){
    if(!S.session)return {ok:false,reason:'none'};
    if(S.session.role==='guest'){
      const acc=(S.accounts||[]).find(a=>String(a.id)===String(S.session.accountId))
        || (S.accounts||[]).find(a=>String(a.room)===String(S.session.room));
      if(!acc)return {ok:false,reason:'missing'};
      const room=(S.rooms||[]).find(x=>String(x.room)===String(acc.room));
      if(!room||!room.active)return {ok:false,reason:'missing',account:acc};
      const sameStay=String(S.session.arrival||'')===String(acc.arrival||'')
        && String(S.session.departure||'')===String(acc.departure||'');
      if(!sameStay)return {ok:false,reason:'stay_changed',account:acc};
      if(acc.active===false)return {ok:false,reason:'inactive',account:acc};
      if(typeof stayExpired==='function'&&stayExpired(acc))return {ok:false,reason:'expired',account:acc};
      return {ok:true,account:acc};
    }
    if(S.session.role==='staff'||S.session.role==='manager'){
      const account=findStaffAccount(S.session.username,S.session.role);
      if(!account)return {ok:false,reason:'missing'};
      if(typeof accountActive==='function'&&!accountActive(account))return {ok:false,reason:'inactive',account};
      return {ok:true,account};
    }
    return {ok:false,reason:'role'};
  }


  function refreshCurrent(){
    const check=validateCurrent();
    if(!check.ok){
      S.session=null;
      S.tab='home';
      persist();
      return check;
    }
    const account=check.account;
    if(S.session.role==='guest')S.session=guestSession(account);
    else S.session={...S.session,...staffSession(account,S.session.role)};
    persist();
    return {ok:true,account,session:S.session};
  }

  window.AUREA_AUTH={
    version:'phase5',
    authenticateGuest,authenticateStaff,
    startGuest,startStaff,logout,
    validateCurrent,refreshCurrent,currentRole,hasRole,isGuest,isStaff,isManager,
    findGuestAccount,findStaffAccount
  };
})();