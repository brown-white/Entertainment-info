
/* ================================================================
   ⚙️ SETUP — make it real in 2 steps:
   1) In Supabase: SQL Editor -> run supabase-setup.sql (one time)
   2) Paste your project values below (Supabase -> Settings -> API)
   While both are empty the app runs on sample data for preview.
================================================================ */
const CONFIG = {
  SUPABASE_URL: "https://smecztwnxieovszndxga.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_qY_DPSrOOR7nclHgXC05lQ_BMNSaf3V"
};
const REMOTE = !!(CONFIG.SUPABASE_URL && CONFIG.SUPABASE_ANON_KEY);
const LS_KEY = "entapp_v3";

const DEFAULT_SETTINGS = {
  name:"Entertainment", subtitle:"", welcomeMsg:"",
  primary:"#3E2A1E", accent:"#B98A5C", bg:"#F7F2EA", textColor:"#2B1F16",
  navBg:"#FFFFFF", navActive:"#6B4A32",
  fontStyle:"elegant", buttonStyle:"rounded",
  menuHome:"", menuProgram:"", menuTickets:"", menuChat:"", menuStay:"",
  tripadvisor:"https://www.tripadvisor.com", google:"https://www.google.com/maps", holidaycheck:"https://www.holidaycheck.de",
  instagram:"", facebook:"", tiktok:"", youtube:"", whatsapp:"",
  busToHotel:"", busToHouse:"",
  aiEndpoint:"", pushEndpoint:"", palette:"brownWhite", dayOverrides:{}, hotelInfo:[], reviewAsk:true,
  logo:"", hotelName:"", timezone:"", currency:"EUR", contact:"", fontScale:"normal", autoDark:false,
  lat:"", lon:"",
  features:{quiz:true,tickets:true,gallery:true,bus:true,hotelinfo:true,weather:true}
};
const FONTS={
  aurea:["'DM Serif Display',serif","'Inter',sans-serif"],
  elegant:["'Cormorant Garamond',serif","'Jost',sans-serif"],
  royal:["'Playfair Display',serif","'Jost',sans-serif"],
  modern:["'Jost',sans-serif","'Jost',sans-serif"],
  soft:["'Nunito',sans-serif","'Nunito',sans-serif"]
};
const BTN_R={rounded:["14px","11px"],pill:["999px","999px"],square:["8px","7px"]};

