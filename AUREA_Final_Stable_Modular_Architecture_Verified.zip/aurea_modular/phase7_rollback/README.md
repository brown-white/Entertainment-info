# AUREA Modular Migration — Phase 2

This build continues the safe migration from one large HTML file toward a maintainable folder-based application.

## What changed in Phase 2
The former `js/legacy/01-app-core.js` was split at top-level dependency boundaries without rewriting its internal logic:

- `js/core/config.js` — environment/configuration and default visual settings
- `js/core/foundation.js` — translations, shared state, access helpers, sample-data foundation
- `js/database/supabase-client.js` — Supabase REST/storage helpers plus the existing persistence-support code that currently depends on them
- `js/database/database.js` — the existing central `DB` repository object
- `js/core/runtime.js` — common runtime/UI helpers used by all roles
- `js/auth/login.js` — current login/authentication UI and flow
- `js/legacy/01-app-shell.js` — remaining application screens/features that still need controlled extraction

The exact Phase 1 core is preserved at:
`js/legacy/backups/01-app-core.phase1.js`

## Safety guarantees used for this migration
1. Original execution order is preserved in `index.html`.
2. The split files concatenate byte-for-byte to the preserved Phase 1 core.
3. Every active JavaScript file passes `node --check` syntax validation.
4. Every local CSS/JS reference in `index.html` resolves to an existing file.
5. No business rule, database schema, role behavior, or visual redesign was intentionally changed in this phase.

## Important limitation
A complete live Supabase/browser regression test cannot be performed inside the isolated build environment. Before replacing the live production build, test Manager, Entertainer, Guest and DJ workflows against the real Supabase project.

## Next safe phase
Do not start by deleting patch files. First extract the remaining `01-app-shell.js` by domain while preserving behavior:

1. Guest screens/controllers
2. Entertainer screens/controllers
3. Manager screens/controllers
4. Planner/assignment engine
5. AI integration
6. Export/reporting
7. Notifications/realtime

Only after those areas are isolated and regression-tested should duplicate historical patches be consolidated.

## Phase 3 — Feature boundary split

The former `js/legacy/01-app-shell.js` has been split into ordered feature/runtime files under `js/guest/`, `js/entertainer/`, `js/manager/`, `js/planner/`, `js/ai/`, `js/exports/`, `js/notifications/`, `js/services/`, and `js/core/`.

Phase 3 is boundary-preserving: code inside each extracted block was not redesigned. Script order in `index.html` is intentionally significant. The complete Phase 2 shell is retained at `js/legacy/backups/01-app-shell.phase2.js`.

Before changing a feature, inspect its feature file plus service/database/core dependencies. Do not delete legacy patches merely because a newer feature module exists.


## Phase 4 — Guest Booking + Tickets consolidation

Phase 4 introduces two authoritative write/policy boundaries:

- `js/services/booking-service.js`
- `js/services/ticket-service.js`

Guest booking creation/cancellation and ticket order creation/status/delete/edit now route through these services.
The existing database layer remains responsible for persistence. Existing V6.14 ticket UX, V6.15 view-only programme UX,
V6.19 guest-stay isolation, V6.20 manager ticket UI and V6.16 global write safety are intentionally retained.

### Important
Do not bypass these services from UI code with direct `DB.addBooking`, `DB.addOrder`, `DB.removeBooking` or
`DB.setOrderStatus` calls. The services are now the controlled boundary for these workflows.

`phase4_rollback/` contains the files changed at the beginning of this phase.


## Phase 5 — Authentication boundary

Phase 5 adds `js/auth/auth-service.js` as the canonical client-side authentication/session boundary.

What moved behind this boundary:
- Guest sign-in validation
- Team/Manager sign-in validation
- Guest/Team/Manager session creation
- Logout
- Session validity checks
- Remembered-session refresh after fresh database load
- Same-stay validation for guests

Important security status:
This phase intentionally preserves the current readable-password data model so existing accounts keep working.
It does NOT make client-side passwords secure. The next security migration should move staff/manager authentication
to Supabase Auth (or another server-side identity provider) and verify RLS before removing legacy password columns.

Do not add new direct password comparisons outside `auth-service.js`.
Do not create or clear `S.session` directly in new UI code; use `AUREA_AUTH`.


## Phase 6 — Authorization / permissions boundary

Phase 6 adds `js/auth/permissions.js` as the canonical application-layer authorization source.

Protected canonical paths now include:
- Guest activity booking and own-booking cancellation
- Guest ticket ordering and own-order cancellation
- Ticket paid/handed-over status actions for Team/Manager
- Manager ticket editing/deletion
- Manager-only Smart Planner changes

Guest ownership uses the existing V6.19 current-stay lifecycle logic when available, not room number alone.

Documentation:
- `docs/PERMISSIONS_MATRIX.md`
- `docs/SUPABASE_RLS_PLAN.md`

### Security boundary
This is not yet database RLS. Real RLS is intentionally deferred until Supabase Auth supplies trusted identities.
Do not treat hidden UI or JavaScript role checks as sufficient database security.
