# Migration Map

## CSS
- 01: `base` → `css/legacy/01-base.css` (109063 chars)
- 02: `aurea-vnext-system` → `css/legacy/02-aurea-vnext-system.css` (9267 chars)
- 03: `aurea-signature-luxury` → `css/legacy/03-aurea-signature-luxury.css` (17696 chars)
- 04: `workday-v3-cleanup` → `css/legacy/04-workday-v3-cleanup.css` (2488 chars)
- 05: `guest-experience-v68` → `css/legacy/05-guest-experience-v68.css` (8268 chars)
- 06: `aurea-ops-v2-style` → `css/legacy/06-aurea-ops-v2-style.css` (4700 chars)
- 07: `aurea-v4-manager-polish` → `css/legacy/07-aurea-v4-manager-polish.css` (4265 chars)
- 08: `aurea-v5-smart-plans-style` → `css/legacy/08-aurea-v5-smart-plans-style.css` (1970 chars)
- 09: `day-info-v6-style` → `css/legacy/09-day-info-v6-style.css` (1646 chars)
- 10: `legacy-style-10` → `css/legacy/10-legacy-style-10.css` (631 chars)
- 11: `legacy-style-11` → `css/legacy/11-legacy-style-11.css` (2709 chars)
- 12: `aurea-final-luxury-v67` → `css/legacy/12-aurea-final-luxury-v67.css` (13101 chars)
- 13: `guest-program-luxury-v69` → `css/legacy/13-guest-program-luxury-v69.css` (12841 chars)
- 14: `guest-program-modern-v610-style` → `css/legacy/14-guest-program-modern-v610-style.css` (6310 chars)
- 15: `aurea-v611-guest-modern` → `css/legacy/15-aurea-v611-guest-modern.css` (10873 chars)
- 16: `aurea-v612-guest-signature` → `css/legacy/16-aurea-v612-guest-signature.css` (11947 chars)
- 17: `aurea-v613-manager-day-branding` → `css/legacy/17-aurea-v613-manager-day-branding.css` (2259 chars)
- 18: `aurea-v614-booking-ticket-style` → `css/legacy/18-aurea-v614-booking-ticket-style.css` (6043 chars)
- 19: `aurea-v615-stability-style` → `css/legacy/19-aurea-v615-stability-style.css` (1808 chars)
- 20: `aurea-purchase-catalog-v618-style` → `css/legacy/20-aurea-purchase-catalog-v618-style.css` (1652 chars)
- 21: `aurea-guest-lifecycle-v619-style` → `css/legacy/21-aurea-guest-lifecycle-v619-style.css` (2585 chars)
- 22: `aurea-guest-ticket-manager-v620-style` → `css/legacy/22-aurea-guest-ticket-manager-v620-style.css` (2722 chars)
- 23: `aurea-smart-export-v620-style` → `css/legacy/23-aurea-smart-export-v620-style.css` (811 chars)
- 24: `aurea-today-ops-v621-style` → `css/legacy/24-aurea-today-ops-v621-style.css` (854 chars)
- 25: `aurea-smart-assignment-v622-style` → `css/legacy/25-aurea-smart-assignment-v622-style.css` (376 chars)
- 26: `aurea-smart-plans-v624-style` → `css/legacy/26-aurea-smart-plans-v624-style.css` (566 chars)
- 27: `aurea-attendance-export-v625-style` → `css/legacy/27-aurea-attendance-export-v625-style.css` (776 chars)
- 28: `aurea-persistence-dayplan-v626-style` → `css/legacy/28-aurea-persistence-dayplan-v626-style.css` (34 chars)
- 29: `aurea-manager-action-center-v627-style` → `css/legacy/29-aurea-manager-action-center-v627-style.css` (3289 chars)
- 30: `aurea-v628-style` → `css/legacy/30-aurea-v628-style.css` (3533 chars)
- 31: `aurea-theme-studio-v629-style` → `css/legacy/31-aurea-theme-studio-v629-style.css` (8254 chars)
- 32: `aurea-payroll-v630-style` → `css/legacy/32-aurea-payroll-v630-style.css` (3700 chars)
- 33: `aurea-payroll-v631-fix-style` → `css/legacy/33-aurea-payroll-v631-fix-style.css` (1601 chars)
- 34: `aurea-payroll-v632-corrected-style` → `css/legacy/34-aurea-payroll-v632-corrected-style.css` (837 chars)
- 35: `aurea-v633-modal-purchase-style` → `css/legacy/35-aurea-v633-modal-purchase-style.css` (4288 chars)
- 36: `aurea-info-board-v635-style` → `css/legacy/36-aurea-info-board-v635-style.css` (1415 chars)
- 37: `aurea-performance-attendance-v636-style` → `css/legacy/37-aurea-performance-attendance-v636-style.css` (3959 chars)
- 38: `aurea-public-explore-v637-style` → `css/legacy/38-aurea-public-explore-v637-style.css` (7790 chars)
- 39: `aurea-experience-audit-v638-style` → `css/legacy/39-aurea-experience-audit-v638-style.css` (12900 chars)
- 40: `aurea-public-first-v639-style` → `css/legacy/40-aurea-public-first-v639-style.css` (7886 chars)
- 41: `aurea-v640-stability-style` → `css/legacy/41-aurea-v640-stability-style.css` (4145 chars)

## JavaScript
- 01: `app-core` → `js/legacy/01-app-core.js` (734356 chars)
- 02: `aurea-vnext-enhancements` → `js/legacy/02-aurea-vnext-enhancements.js` (1295 chars)
- 03: `aurea-operations-v2` → `js/legacy/03-aurea-operations-v2.js` (18640 chars)
- 04: `aurea-v4-manager-logic` → `js/legacy/04-aurea-v4-manager-logic.js` (6583 chars)
- 05: `aurea-v5-smart-plans` → `js/legacy/05-aurea-v5-smart-plans.js` (13610 chars)
- 06: `day-info-v6-patch` → `js/legacy/06-day-info-v6-patch.js` (5910 chars)
- 07: `legacy-script-07` → `js/legacy/07-legacy-script-07.js` (12182 chars)
- 08: `legacy-script-08` → `js/legacy/08-legacy-script-08.js` (12400 chars)
- 09: `guest-program-luxury-v69-logic` → `js/legacy/09-guest-program-luxury-v69-logic.js` (1075 chars)
- 10: `guest-program-modern-v610-logic` → `js/legacy/10-guest-program-modern-v610-logic.js` (9012 chars)
- 11: `aurea-v611-guest-modern-js` → `js/legacy/11-aurea-v611-guest-modern-js.js` (11106 chars)
- 12: `aurea-v612-guest-signature-js` → `js/legacy/12-aurea-v612-guest-signature-js.js` (15438 chars)
- 13: `aurea-v613-manager-day-branding-logic` → `js/legacy/13-aurea-v613-manager-day-branding-logic.js` (11874 chars)
- 14: `aurea-v614-booking-ticket-logic` → `js/legacy/14-aurea-v614-booking-ticket-logic.js` (23392 chars)
- 15: `aurea-v615-system-stability` → `js/legacy/15-aurea-v615-system-stability.js` (6724 chars)
- 16: `aurea-write-safety-v616` → `js/legacy/16-aurea-write-safety-v616.js` (2595 chars)
- 17: `aurea-purchase-catalog-v618-script` → `js/legacy/17-aurea-purchase-catalog-v618-script.js` (4597 chars)
- 18: `aurea-guest-lifecycle-v619-script` → `js/legacy/18-aurea-guest-lifecycle-v619-script.js` (22722 chars)
- 19: `aurea-guest-ticket-manager-v620-script` → `js/legacy/19-aurea-guest-ticket-manager-v620-script.js` (8677 chars)
- 20: `aurea-guest-ticket-tab-migration-v6193` → `js/legacy/20-aurea-guest-ticket-tab-migration-v6193.js` (1591 chars)
- 21: `aurea-smart-export-v620-script` → `js/legacy/21-aurea-smart-export-v620-script.js` (18615 chars)
- 22: `aurea-operations-date-v621-script` → `js/legacy/22-aurea-operations-date-v621-script.js` (2503 chars)
- 23: `aurea-smart-assignment-v622-script` → `js/legacy/23-aurea-smart-assignment-v622-script.js` (17133 chars)
- 24: `aurea-smart-plans-v624-script` → `js/legacy/24-aurea-smart-plans-v624-script.js` (13004 chars)
- 25: `aurea-attendance-export-v625-script` → `js/legacy/25-aurea-attendance-export-v625-script.js` (4732 chars)
- 26: `aurea-persistence-dayplan-v626-script` → `js/legacy/26-aurea-persistence-dayplan-v626-script.js` (1554 chars)
- 27: `aurea-manager-action-center-v627-script` → `js/legacy/27-aurea-manager-action-center-v627-script.js` (14525 chars)
- 28: `aurea-v628-script` → `js/legacy/28-aurea-v628-script.js` (11594 chars)
- 29: `aurea-theme-studio-v629-script` → `js/legacy/29-aurea-theme-studio-v629-script.js` (10955 chars)
- 30: `aurea-payroll-v630-script` → `js/legacy/30-aurea-payroll-v630-script.js` (22634 chars)
- 31: `aurea-v633-purchase-script` → `js/legacy/31-aurea-v633-purchase-script.js` (15089 chars)
- 32: `aurea-info-board-v635-script` → `js/legacy/32-aurea-info-board-v635-script.js` (12265 chars)
- 33: `aurea-performance-attendance-v636-script` → `js/legacy/33-aurea-performance-attendance-v636-script.js` (15091 chars)
- 34: `aurea-public-explore-v637-script` → `js/legacy/34-aurea-public-explore-v637-script.js` (7729 chars)
- 35: `aurea-experience-audit-v638-script` → `js/legacy/35-aurea-experience-audit-v638-script.js` (11076 chars)
- 36: `aurea-public-first-v639-script` → `js/legacy/36-aurea-public-first-v639-script.js` (19050 chars)
- 37: `aurea-v640-stability-script` → `js/legacy/37-aurea-v640-stability-script.js` (11888 chars)

## Phase 2 core split
The Phase 1 `js/legacy/01-app-core.js` was replaced in the active load order by:

1. `js/core/config.js`
2. `js/core/foundation.js`
3. `js/database/supabase-client.js`
4. `js/database/database.js`
5. `js/core/runtime.js`
6. `js/auth/login.js`
7. `js/legacy/01-app-shell.js`

Rollback source: `js/legacy/backups/01-app-core.phase1.js`.

## Phase 3 map

`js/legacy/01-app-shell.js` was decomposed at explicit existing section boundaries. No statements were reordered.

Major destinations: Guest -> `js/guest/`; Entertainer -> `js/entertainer/`; Manager -> `js/manager/`; Planner -> `js/planner/assignment-engine.js`; AI -> `js/ai/manager-ai.js`; exports -> `js/exports/`; notifications -> `js/notifications/notifications.js`; shared wiring/runtime -> `js/core/`.

Verification invariant: concatenating the 26 Phase 3 files in `index.html` order must reproduce `js/legacy/backups/01-app-shell.phase2.js` exactly.


## Phase 4 map — Booking and Tickets

- V6.15 booking category policy -> `js/services/booking-service.js`
- V6.15 duplicate booking/ticket pending guards -> booking/ticket services
- Core booking modal writes -> booking service
- Core ticket modal + V6.11/V6.12/V6.14 ticket writes -> ticket service
- V6.20 manager ticket edit/delete -> ticket service
- V6.28 ticket paid/reserved status update -> ticket service
- V6.15 remains as a compatibility/UI policy layer; it no longer monkey-patches DB write methods.
- V6.16 global mutation safety remains active as a second generic safety layer.
- V6.19 guest lifecycle remains unchanged because it is the stay-isolation source of truth.


## Phase 5 map — Authentication

- Guest login validation -> `js/auth/auth-service.js`
- Staff/Manager login validation -> `js/auth/auth-service.js`
- Session creation -> `AUREA_AUTH.startGuest/startStaff`
- Logout -> `AUREA_AUTH.logout`
- Access enforcement -> `AUREA_AUTH.validateCurrent`
- Remembered-session boot validation -> `AUREA_AUTH.refreshCurrent`
- Guest same-stay protection retained

Rollback snapshot: `phase5_rollback/`


## Phase 6 map — Authorization

- Central permission rules -> `js/auth/permissions.js`
- Booking permission/ownership enforcement -> `js/services/booking-service.js`
- Ticket permission/ownership enforcement -> `js/services/ticket-service.js`
- Planner manager-write guard -> `js/planner/assignment-engine.js`
- Role capability reference -> `docs/PERMISSIONS_MATRIX.md`
- Future Supabase RLS design -> `docs/SUPABASE_RLS_PLAN.md`

Phase 6 does not modify Supabase policies or schema.
Rollback snapshot: `phase6_rollback/`


## Phase 7 map — Supabase Auth compatibility

- Future Supabase staff Auth HTTP adapter -> `js/auth/supabase-auth-adapter.js`
- Provider switch / staff authentication boundary -> `js/auth/auth-service.js`
- JWT-ready REST + Storage bearer header -> `js/database/supabase-client.js`
- Activation flag -> `CONFIG.AUTH_MODE` (`legacy` by default)
- Migration procedure -> `docs/SUPABASE_AUTH_MIGRATION.md`

No production identity migration, schema change or RLS change is performed in Phase 7.
Rollback snapshot: `phase7_rollback/`


## Phase 8 map — Identity + RLS staging

- Current database/policy inspection -> `supabase/phase8/00_READ_ONLY_PRECHECK.sql`
- Future staff Auth link template -> `supabase/phase8/10_IDENTITY_LINK_TEMPLATE.sql`
- Future trusted role helpers -> `supabase/phase8/20_RLS_HELPERS_TEMPLATE.sql`
- Future staff/manager policy template -> `supabase/phase8/30_STAFF_MANAGER_RLS_TEMPLATE.sql`
- Future Guest stay-ownership template -> `supabase/phase8/40_GUEST_RLS_TEMPLATE.sql`
- Broad startup data-load risk/dependency -> `docs/DATA_ACCESS_AUDIT.md`
- Activation gates -> `docs/PHASE8_IDENTITY_RLS_DESIGN.md`

No Supabase mutation is performed in Phase 8.
Rollback snapshot: `phase8_rollback/`


## Phase 9 map — Role-aware loading

- Canonical startup/poll read boundary -> `js/database/data-loader.js`
- Existing `DB.load()` -> delegates to `AUREA_DATA_LOADER.load()`
- Existing `DB.poll()` -> delegates to `AUREA_DATA_LOADER.poll()`
- Current active mode -> `CONFIG.DATA_LOAD_MODE = "legacy_full"`
- Future role profiles -> prepared but blocked from activation
- Safety/runtime rationale -> `docs/PHASE9_ROLE_AWARE_LOADING.md`

No database schema, Auth mode, or RLS change is performed in Phase 9.
Rollback snapshot: `phase9_rollback/`


## Phase 10 map — Realtime isolation

- Realtime table/state ownership -> `js/services/realtime-service.js`
- Realtime row patching -> `AUREA_REALTIME.applyPayload()`
- Realtime client creation -> `AUREA_REALTIME.createClient()`
- Subscription creation -> `AUREA_REALTIME.subscribe()`
- Existing runtime/notification/render orchestration -> `js/core/realtime-runtime.js`
- Active compatibility mode -> `CONFIG.REALTIME_MODE = "legacy_broad"`
- Future role profiles -> prepared but blocked
- Design/safety notes -> `docs/PHASE10_REALTIME_ISOLATION.md`

No Auth, RLS, schema, or live subscription scope change is activated in Phase 10.
Rollback snapshot: `phase10_rollback/`


## Phase 11 map — Session lifecycle

- Session transition owner -> `js/auth/session-lifecycle.js`
- Login/logout/session validation notifications -> `js/auth/auth-service.js`
- Anonymous boot notification -> `js/core/realtime-runtime.js`
- Future Auth token refresh notification -> `js/auth/supabase-auth-adapter.js`
- Active mode -> `CONFIG.SESSION_LIFECYCLE_MODE = "legacy_observe"`
- Transition design -> `docs/PHASE11_SESSION_LIFECYCLE.md`

No active data-loader or realtime orchestration is enabled in Phase 11.


## Phase 12 map — Sensitive-state isolation

- Canonical state isolation -> `js/auth/state-isolation.js`
- Identity-transition hook -> `js/auth/session-lifecycle.js`
- Active compatibility mode -> `CONFIG.STATE_ISOLATION_MODE = "legacy_transient"`
- Safe active cleanup -> transient UI/session state only
- Sensitive database-array wipe -> prepared conceptually but blocked
- Design notes -> `docs/PHASE12_STATE_ISOLATION.md`

No Auth, RLS, data-profile, or realtime-profile activation occurs in Phase 12.


## Phase 13 map — Smart Planner

- Canonical external planner API -> `js/planner/planner-service.js`
- Hard eligibility / repair authority -> `AUREA_SMART_ASSIGNMENT_V622`
- A/B/C generation authority -> `AUREA_SMART_PLANS_V624`
- Manager Generate Plans button -> `AUREA_PLANNER.open()`
- Manager Repair Invalid button -> `AUREA_PLANNER.repair()`
- Active mode -> `CONFIG.PLANNER_MODE = "compat_v624"`
- Planner dependency/rule audit -> `docs/PHASE13_PLANNER_AUDIT.md`

V6.22 and V6.24 remain active compatibility layers in Phase 13.
