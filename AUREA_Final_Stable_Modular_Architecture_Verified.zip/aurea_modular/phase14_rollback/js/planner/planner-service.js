/* AUREA Phase 13 — canonical Smart Planner boundary
   Active mode `compat_v624` preserves the final V6.22 + V6.24 behavior.
   This file does NOT replace the planner algorithm yet; it gives the rest of
   the app one stable API so later consolidation can happen behind it safely. */
(function(){
  'use strict';
  if(window.AUREA_PLANNER)return;

  function mode(){
    return (typeof CONFIG!=="undefined"&&CONFIG.PLANNER_MODE)||"compat_v624";
  }

  function assertReady(){
    if(mode()!=="compat_v624"){
      throw new Error(
        "AUREA Phase 13 safety guard: planner algorithm replacement is not activated. "+
        "Keep PLANNER_MODE=compat_v624 until the compatibility facade and rule tests pass in staging."
      );
    }
    if(!window.AUREA_SMART_ASSIGNMENT_V622)
      throw new Error("Smart assignment V6.22 API is unavailable");
    if(!window.AUREA_SMART_PLANS_V624)
      throw new Error("Smart plans V6.24 API is unavailable");
    return true;
  }

  function hardRules(){
    assertReady();
    return Object.freeze({
      maxOnePerOperation:true,
      djExcludedFromNormalActivities:true,
      djOwnsEvents:true,
      blocksDayOff:true,
      blocksVacation:true,
      blocksAbsent:true,
      respectsEntranceDuty:true,
      respectsCapability:true,
      respectsConfiguredGender:true,
      preventsTimeOverlap:true,
      fairnessWeighted:true,
      alternativePlans:3
    });
  }

  function validateExisting(activity){
    assertReady();
    return window.AUREA_SMART_ASSIGNMENT_V622.valid(activity);
  }

  function hardAvailable(user,activity,day){
    assertReady();
    return window.AUREA_SMART_ASSIGNMENT_V622.hardAvailable(user,activity,day);
  }

  function generate(scope,day,onlyEmpty,generation){
    assertReady();
    return window.AUREA_SMART_PLANS_V624.generateSet(
      scope==="week"?"week":"day",
      Number(day)||0,
      !!onlyEmpty,
      Number(generation)||1
    );
  }

  async function apply(list){
    assertReady();
    if(typeof window.applyAssignments!=="function")
      throw new Error("Planner apply function unavailable");
    return window.applyAssignments(list||[]);
  }

  async function repair(){
    assertReady();
    if(typeof window.repairSmartAssignmentsV622!=="function")return false;
    return window.repairSmartAssignmentsV622();
  }

  function open(day){
    assertReady();
    if(!window.AUREA_PERMISSIONS || !AUREA_PERMISSIONS.can("planner.manage")){
      if(typeof toast==="function")toast(t("profileReadOnly"));
      return false;
    }
    if(typeof window.openAutoAssignModal!=="function")
      throw new Error("Planner modal unavailable");
    window.openAutoAssignModal(Number(day)||0);
    return true;
  }

  function apiStatus(){
    return {
      version:"phase13",
      mode:mode(),
      assignmentApi:window.AUREA_SMART_ASSIGNMENT_V622&&window.AUREA_SMART_ASSIGNMENT_V622.version||null,
      plansApi:window.AUREA_SMART_PLANS_V624&&window.AUREA_SMART_PLANS_V624.version||null,
      applyWrapped:typeof window.applyAssignments==="function",
      modalAvailable:typeof window.openAutoAssignModal==="function"
    };
  }

  window.AUREA_PLANNER={
    version:"phase13",
    mode,assertReady,hardRules,validateExisting,hardAvailable,
    generate,apply,repair,open,apiStatus
  };
})();